import 'dart:io';

import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

class AdHelper {
  var controller = Get.find<NewsfeedController>();

  static String get bannerAdUnitId {
    if (Platform.isAndroid) {
      // for production
      return 'ca-app-pub-1417085788581438/8959086489';
      //for test
      // return 'ca-app-pub-3940256099942544/6300978111';
    } else if (Platform.isIOS) {
      //for production
      return 'ca-app-pub-1417085788581438/2084053921';
      // return 'ca-app-pub-3940256099942544/2934735716';
    }
    throw new UnsupportedError("Unsupported platform");
  }

  // static String get nativeAdUnitId {
  //   if (Platform.isAndroid) {
  //     return 'ca-app-pub-3940256099942544/2247696110';
  //   } else if (Platform.isIOS) {
  //     return 'ca-app-pub-3940256099942544/3986624511';
  //   }
  //   throw new UnsupportedError("Unsupported platform");
  // }
  // NativeAdListener get adListener => _adListener;
  BannerAdListener get adListener => _adListener;
  BannerAdListener _adListener = BannerAdListener(
      onAdLoaded: (ad) {
        // print('Ad loaded: ${ad.adUnitId}.');
        Get.find<NewsfeedController>().isAdLoaded = true;
        Get.find<NewsfeedController>().update();
      },
      onAdClosed: (ad) => print('Ad closed: ${ad.adUnitId}. '),
      onAdFailedToLoad: (ad, error) =>
          print('Ad failed to load: ${ad.adUnitId}, $error.'),
      onAdOpened: (ad) => print('Ad opened: ${ad.adUnitId}.'),
      // onAppEvent: (ad, name, data) =>
      //     print('App event : ${ad.adUnitId}, $name, $data.'),
      // onApplicationExit: (ad) => print('App Exit: ${ad.adUnitId}. '),
      onAdClicked: (nativeAd) =>
          print('Native ad clicked: ${nativeAd.adUnitId}. '),
      onAdImpression: (nativeAd) {
        print('Native ad impression: ${nativeAd.adUnitId}. ');
      }
      // onRewardedAdUserEarnedReward: (ad, reward) => print(
      //     'User rewarded: ${ad.adUnitId}, ${reward.amount} ${reward.type}.'),
      );
}
