//
// import 'dart:async';
//
// import 'package:socket_io_client/socket_io_client.dart' as IO;
//
// class StreamSocket{
//   final socketResponse= StreamController<String>();
//
//   void Function(String) get addResponse => socketResponse.sink.add;
//
//   Stream<String> get getResponse => socketResponse.stream;
//
//   // void dispose(){
//   //   socketResponse.close();
//   // }
// }
// class SocketService {
//   // Socket socket;
//
//   void connectAndListen() {
//     try {
//     StreamSocket streamSocket =StreamSocket();
//
//       IO.Socket socket = IO.io('http://54.215.53.4:9002?token=d7b07a9f80902c0009ea83e1c9b182f6006081520a295a5e98b3c68d0739e3a96be536d569390d6629e7a16d1ed59a57b025887be885f01b1c0d935e',<String, dynamic>{
//         'transports': ['websocket'],
//         'autoConnect': false,
//       });
//       socket.connect();
//       socket.onConnect((_) {
//         print('connect');
//         socket.emit('new_message',{
//           "body":"SHAMSHAD message" ,
//           "conversation_id":5,
//           "post_type":'video',
//           "mode":'new'
//
//         });
//         print("emit");
//         socket.on('new_message', (data) => streamSocket.addResponse);
//         streamSocket.getResponse.forEach((element) {
//           print(element.toString());
//         });
//       });
//       // socket.on('connect', (_) => print('connect: ${socket.connected}'));
//       // socket.on('message', handleMessage);
//       // socket.on('fromServer', (_) => print(_));
//
//       // socket.on('new_message',  (data) async{
//       //   print("ndflkshfhdfkjlhdjkfhdj" + data);
//       // });
//
//
//
//
//       // Socket socket = io(
//       //     // 'http://184.169.185.200:4040/'
//       //     'http://54.215.53.4:9002?token=d7b07a9f80902c0009ea83e1c9b182f6006081520a295a5e98b3c68d0739e3a96be536d569390d6629e7a16d1ed59a57b025887be885f01b1c0d935e'
//       //     , OptionBuilder()
//       //     .setTransports(['websocket']) // for Flutter or Dart VM
//       //     .disableAutoConnect()
//       // // .setExtraHeaders({'token': 'd7b07a9f80902c0009ea83e1c9b182f6006081520a295a5e98b3c68d0739e3a96be536d569390d6629e7a16d1ed59a57b025887be885f01b1c0d935e'})
//       //     .build());
//       // print("start");
//       // socket.connect();
//       // socket.onConnect((_) {
//       //   print('connect');
//       //   print(socket.connected);
//       //   socket.emit('new_message',{
//       //     "body":"now2 message" ,
//       //     "conversation_id":5,
//       //     "post_type":'video',
//       //     "mode":'new'
//       //
//       //   });
//         // socket.emit('new_message', {
//         //   'body': "newwwww msg from this pc",
//         //   'conversation_id': 5,
//         //   'post_type': 'post',
//         //   'starting_point_id': 1,
//         //   'mode': 'new',
//         //   'link': null,
//         //   'link_title': "kjskdjs",
//         //   'link_meta': null,
//         //   'link_image': null,
//         //   'replied_to_message_id': 19
//         // });
//
//       // });
//       print("after emit");
//
//       // socket.on('new_message', (data) => print(data));
//       // socket.onDisconnect((_) => print('disconnect'));
//       // socket.on('fromServer', (_) => print(_));
//     } catch (e) {
//       print(e);
//     }
//
//   }
// }
