import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:infinite_scroll_pagination/infinite_scroll_pagination.dart';

import '../models/post.dart';
import '../network/api.dart';
import '../utils/urls.dart';

class InfiniteScrollPaginatorDemo extends StatefulWidget {
  @override
  _InfiniteScrollPaginatorDemoState createState() =>
      _InfiniteScrollPaginatorDemoState();
}

class _InfiniteScrollPaginatorDemoState
    extends State<InfiniteScrollPaginatorDemo> {
  final _numberOfPostsPerRequest = 10;

  final PagingController<int, Post> _pagingController =
      PagingController(firstPageKey: 0);
  final storage = GetStorage();
  var api = Api();

  @override
  void initState() {
    _pagingController.addPageRequestListener((pageKey) {
      _fetchPage(pageKey);
    });
    super.initState();
  }

  Future<void> _fetchPage(int pageKey) async {
    try {
      String getResponse = await api.get(
        Uri.parse(Url.getBrowsePostUrl + '?page_no=' + pageKey.toString()),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      final response = jsonDecode(getResponse);
      if (response['meta']["code"] == 200) {
        if (response['data'] != null) {
          var postData = response['data'] as List;

          List<Post> postList = postData.map((e) => Post.fromJson(e)).toList();
          final isLastPage = postList.length < _numberOfPostsPerRequest;
          if (isLastPage) {
            _pagingController.appendLastPage(postList);
          } else {
            final nextPageKey = pageKey + 1;
            _pagingController.appendPage(postList, nextPageKey);
          }
        }
      }
    } catch (e) {
      // print("error --> $e");
      _pagingController.error = e;
    }
  }

  @override
  void dispose() {
    _pagingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
