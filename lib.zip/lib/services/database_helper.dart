import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final _databaseName = "werfie.db";
  static final _databaseVersion = 1;

  static final table = 'post';
  static final notificationsTable = 'notifications';
  static final savedPostTable = 'savedPost';
  static final profileTable = 'profile';
  static final myLang = 'myLang';
  static final newsFeed = 'newsFeed';

  static final postId = 'id';
  static final postData = 'data';

  // make this a singleton class
  DatabaseHelper._privateConstructor();

  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  // only have a single app-wide reference to the database
  static Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;
    // lazily instantiate the db the first time it is accessed
    _database = await _initDatabase();
    return _database;
  }

  // this opens the database (and creates it if it doesn't exist)
  _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(path,
        version: _databaseVersion, onCreate: _onCreate);
  }

  // SQL code to create the database table
  Future _onCreate(Database db, int version) async {
    await db.execute('''
          CREATE TABLE $table (
            $postId INTEGER PRIMARY KEY,
            $postData TEXT NOT NULL
          )
          ''');
    await db.execute('''
          CREATE TABLE $notificationsTable (
            id INTEGER PRIMARY KEY,
            sender_name TEXT ,
            user_id INTEGER ,
            on_user INTEGER ,
            text TEXT ,
            type TEXT ,
            is_read INTEGER ,
            post_id INTEGER ,
            comment_id TEXT ,
            re_post_id TEXT ,
            created_at TEXT ,
            updated_at TEXT ,
            profile_image TEXT
          )
          ''');
    await db.execute('''
          CREATE TABLE $savedPostTable (
            post_id INTEGER PRIMARY KEY,
            author_name TEXT ,
            profile_image TEXT ,
            username TEXT ,
            author_id INTEGER ,
            posted_on TEXT,
            post_type TEXT,
            post_type_color_code TEXT,
            body TEXT,
            location TEXT,
            simple_like_count INTEGER,
            simple_dislike_count INTEGER,
            comments_count INTEGER,
            shares_count INTEGER,
            post_files TEXT,
            posted_time_ago TEXT,
            comments TEXT,
            isLiked INTEGER,
            isDisliked INTEGER,
            you_retweet INTEGER,
            retweet_count INTEGER,
            following_likes TEXT,
            following_retweets TEXT,
            quote_info TEXT
       
          )
          ''');
    await db.execute('''
          CREATE TABLE $myLang (
            id INTEGER PRIMARY KEY,
            name TEXT ,
            code TEXT ,
            pivot TEXT
          )
          ''');
    await db.execute('''
          CREATE TABLE $newsFeed (
            post_id INTEGER PRIMARY KEY,
            author_name TEXT ,
            profile_image TEXT ,
            username TEXT ,
            author_id INTEGER ,
            posted_on TEXT,
            post_type TEXT,
            post_type_color_code TEXT,
            body TEXT,
            location TEXT,
            simple_like_count INTEGER,
            simple_dislike_count INTEGER,
            comments_count INTEGER,
            shares_count INTEGER,
            post_files TEXT,
            posted_time_ago TEXT,
            comments TEXT,
            isLiked INTEGER,
            isDisliked INTEGER,
            you_retweet INTEGER,
            retweet_count INTEGER,
            following_likes TEXT,
            following_retweets TEXT,
            quote_info TEXT
          )
          ''');
  }

  // Helper methods

  // Inserts a row in the database where each key in the Map is a column name
  // and the value is the column value. The return value is the id of the
  // inserted row.
  Future<int> insert(table, row) async {
    Database db = await instance.database;
    return await db.insert(
      table,
      row,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // All of the rows are returned as a list of maps, where each map is
  // a key-value list of columns.
  Future<List<Map<String, dynamic>>> queryAllRows(table) async {
    Database db = await instance.database;
    return await db.query(table);
  }

  // All of the methods (insert, query, update, delete) can also be done using
  // raw SQL commands. This method uses a raw query to give the row count.
  Future<int> queryRowCount(table) async {
    Database db = await instance.database;
    return Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM $table'));
  }

  // We are assuming here that the id column in the map is set. The other
  // column values will be used to update the row.
  Future<int> update(table, row, id, idKey) async {
    Database db = await instance.database;
    return await db.update(table, row, where: '$idKey = ?', whereArgs: [id]);
  }

  //drop table if exist
  void dropTable(table) async {
    Database db = await instance.database;
    await db.execute("DROP TABLE IF EXISTS $table");
  }

  // Deletes the row specified by the id. The number of affected rows is
  // returned. This should be 1 as long as the row exists.
  Future<int> delete(int id) async {
    Database db = await instance.database;
    return await db.delete(table, where: '$postId = ?', whereArgs: [id]);
  }
}
