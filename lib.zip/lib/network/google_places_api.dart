import 'package:flutter/foundation.dart';
import 'package:get/get.dart';

import '../models/fetch_address_model/fetch_address_model.dart';
import '../models/geomery_latlng/geomatry_latlng.dart';
import '../models/map_autocomplete_model/map_auto_complete_model.dart';
import 'package:werfieapp/utils/urls.dart';

class MapClient extends GetConnect {
  static const _address =
      'https://maps.googleapis.com/maps/api/geocode/json?latlng=';
  static const _baseUrl = 'https://maps.googleapis.com/maps/api/place';

  static const _epAutocomplete = kIsWeb
      ? 'https://cors-anywhere.herokuapp.com/https://maps.googleapis.com/maps/api/place/autocomplete/json'
      : "https://maps.googleapis.com/maps/api/place/autocomplete/json";

  // static const _epAutocomplete = "https://maps.googleapis.com/maps/api/place/autocomplete/json";

  static const _epDetails =
      "https://maps.googleapis.com/maps/api/place/details/json";
  static const _epnearBy =
      'https://maps.googleapis.com/maps/api/place/nearbysearch/json';

// parameters
  static const _androidKey = 'AIzaSyCQHRrt1z3MFoRAe1UctDLBsr8rt87C0DU';
  static const _webKey = 'AIzaSyC0lIkjxgGAoMTQFPQTnv6pSbaDKjkwN18';
  static const _iosKey = 'AIzaSyBVwV5dNaoJopNMROPl1dCvPwulah_B4Hk';

  static const _pfields = 'fields';
  static const _pKey = 'key';
  static const _pLanguage = 'language';
  static const _pQuery = 'input';
  static const _pPlaceid = 'place_id';
  static const _pOrigin = 'origin';
  static const _pDestination = 'destination';
  static const _pInput = 'input';

  Future<AutoComplete> getPlaces(String searchString) async {

    // var response = await api.get(Uri.parse());

    String getPlacesUrl = "${Url.getGooglePlaceAutocomplete}?search=$searchString&language=en" ;

    try {
      // print("places api");

      final response = await get(getPlacesUrl,
          headers: {
        "Access-Control-Allow-Origin": "*",
        'Content-Type': 'application/json',
        'Accept': '*/*'
      });
      // print('bdd${query}');
      // print("new places api: " + response.toString());
      if (response.statusCode == 200) {
        // print("response.body ${response.body}  ");

        return AutoComplete.fromJson(response.body["data"]);
      }
      throw (response.statusText ?? "Exception");
    } catch (e) {
      // print(e.toString());
    }
  }

  Future<AutoComplete> getPlacesDeprecated(String str) async {
    String _key = "";
    if (defaultTargetPlatform == TargetPlatform.iOS) {
      _key = _iosKey;
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      _key = _androidKey;
    } else {
      _key = _webKey;
    }

    try {
      // print("places api");

      final response = await get(_epAutocomplete, query: {
        _pInput: str,
        _pKey: _key,
        _pLanguage: 'en',

        // 'types':'postal_code',
        // "components": "country:${''}"
      }, headers: {
        "Access-Control-Allow-Origin": "*",
        'Content-Type': 'application/json',
        'Accept': '*/*'

        // 'X-Requested-With': 'XMLHttpRequest',
        // "Access-Control-Allow-Origin": "*", // Required for CORS support to work
        // "Access-Control-Allow-Credentials":
        // 'true', // Required for cookies, authorization headers with HTTPS
        // "Access-Control-Allow-Headers":
        // "Origin,Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token,locale",
        // "Access-Control-Allow-Methods": "POST, OPTIONS"
      });
      // print('bdd${query}');
      // print(response.toString());
      if (response.statusCode == 200) {
        // print("response.body ${response.body}  ");

        return AutoComplete.fromJson(response.body);
      }
      throw (response.statusText ?? "Exception");
    } catch (e) {
      // print(e.toString());
    }
  }

  Future<GeomatryLatLng> getPlacesLatLong(String str,
      {String key, String language}) async {
    String _key = "";

    if (defaultTargetPlatform == TargetPlatform.iOS) {
      _key = _iosKey;
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      _key = _androidKey;
    } else {
      _key = _webKey;
    }
    try {
      final response = await get(
        _epDetails,
        query: {_pPlaceid: str, _pKey: _key, _pfields: 'geometry'},
      );
      if (response.statusCode == 200) {
        return GeomatryLatLng.fromJson(response.body);
      }
    } catch (e) {
      // print(e);
    }
    // throw (response.body);
  }

  Future<FetchAddress> fetchAddress(
      {@required double latitude, @required double longitude}) async {
    String _key = "";

    if (defaultTargetPlatform == TargetPlatform.iOS) {
      _key = _iosKey;
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      _key = _androidKey;
    } else {
      _key = _webKey;
    }

    try {
      final response = await get(
        _address + '${latitude.toString()},${longitude.toString()}&key=${_key}',
      );
      return FetchAddress.fromJson(response.body);
    } catch (e) {
      // print(e);
    }
  }
}
