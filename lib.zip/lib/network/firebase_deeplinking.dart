import 'dart:async';
import 'dart:convert';

import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uni_links/uni_links.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/widgets/comments_screen.dart';

import '../models/post.dart';

class FirebaseDeepLink {
  String _linkMessage;
  bool _isCreatingLink = false;
  FirebaseDynamicLinks dynamicLinks = FirebaseDynamicLinks.instance;
  static const kUriPrefix = "https://werfieapp.page.link";

  Uri _initialUri;
  Uri _latestUri;
  Object _err;
  bool _initialUriIsHandled = false;

  StreamSubscription _sub;
  final storage = GetStorage();
  SharedPreferences shared;

  Future<void> initDynamicLinks(BuildContext context) async {
    final PendingDynamicLinkData data = await dynamicLinks.getInitialLink();
    _handleDynamicLink(data, false);

    dynamicLinks.onLink.listen((dynamicLinkData) async {
      _handleDynamicLink(dynamicLinkData, true);
    }).onError((error) {
      // print('onLink error');
      // print(error.message);
    });
  }

  //handle from background to foreground => background=true.
  void handleIncomingLinks(bool isBackground) {
    // print("handleincominglinks called");
    NewsfeedController controller;

    if (!kIsWeb) {
      // It will handle app links while the app is already started - be it in
      // the foreground or in the background.
      _sub = uriLinkStream.listen((Uri deepLink) async {
        // print('got uri: $deepLink');
        if (deepLink != null) {
          if (deepLink != null) {
            // print('deep link is found at location ' + deepLink.toString());

            final queryParams = deepLink.queryParameters;
            List<String> pathSegments = deepLink.pathSegments;
            if (pathSegments.isNotEmpty) {
              // String idProfile = queryParams["profileId"];
              // String profilePostId = queryParams["profilePostId"];

              String postID = pathSegments[pathSegments.length - 1];
              String page = pathSegments[pathSegments.length - 2];
              // print('PostId${postID}');
              // print('PostId${page}');

              // print('PostId${postID}');
              // print('if deep link id part init');
              // print('profile id:${idProfile}');
              SingleTone.instance.profileId = null;
              SingleTone.instance.postId = null;
              if (page == "profile") {
                SingleTone.instance.profileId = postID;
                /*  Get.snackbar('User 123', idProfile.toString(),
              snackPosition: SnackPosition.BOTTOM,
              duration: Duration(seconds: 3));*/
                // print('SingleTone store profile Id:${SingleTone.instance.profileId}');
                // print('profileidsession1nn:${postID}');
                controller = Get.find<NewsfeedController>();

                UserProfile profile =
                    await controller.getOtherUserProfile(int.parse(postID));
                controller.otherUserId = int.parse(postID);
                controller.update();
                /* Navigator.of(context).push(MaterialPageRoute(
              builder: (context) =>  OtherUsersProfile(controller: controller, userInfo: profile),));*/
                !isBackground
                    ? WidgetsBinding.instance.addPostFrameCallback((_) {
                        // MyApp().navigatorKey.currentState.pu
                        Get.to(
                          OtherUsersProfile(
                              controller: controller, userInfo: profile),
                          // arguments: {
                          //   "userName": null,
                          //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                          // }
                        );
                      })
                    : Get.to(
                        OtherUsersProfile(
                            controller: controller, userInfo: profile),
                        // arguments: {
                        //   "userName": null,
                        //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                        // }
                      );
                ;
                // Get.to(Session(
                //   postId: null,
                //   profileId:idProfile,
                // ));
              } else if (page == "postDetail") {
                SingleTone.instance.postId = postID;
                // print('postIdsession1nnn:${postID}');
                // print('Singletone post id :${SingleTone.instance.postId}');

                List<Post> postDetail;
                /* if(kIsWeb){
            SavedPostController   savedController = Get.put(SavedPostController());
            BrowseController   browseController = Get.put(BrowseController());
            controller.isPostDetails = true;
            controller.isTrendsScreen = false;
            controller.isNewsFeedScreen = false;
            controller.isBrowseScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            if (controller.isSavedPostScreen) {
              savedController.update();
            }
            if (controller.isBrowseScreen) {
              browseController.update();
            }
            controller.postDetail2 = await controller
                .getSingleNewsFeedItem(
                postID);
            controller.update();
          }else {*/
                postDetail = await getPostDetails(postID);
                if (postDetail != null) {
                  !isBackground
                      ? WidgetsBinding.instance.addPostFrameCallback((_) {
                          Get.to(CommentsScreen(
                            postId: postDetail[0].postId,
                            thread_no: null,
                          ));
                        })
                      : Get.to(CommentsScreen(
                          postId: postDetail[0].postId,
                          thread_no: null,
                        ));
                  ;
                }
                //}
                /*if (postDetail !=null){
   Get.to(PostDetail(
     controller: Get.isRegistered<NewsfeedController>()
         ? Get.put(NewsfeedController())
         : Get.find<NewsfeedController>(),
     post: postDetail[0],
   ));
 }*/
              }
              // Navigator.pushNamed(context,
              //     dynamicLinkData.link.path,
              //     arguments: {"productId": });
            } else {
              // print('else part');
              // Navigator.pushNamed(
              //   context,
              //   dynamicLinkData.link.path,
              // );
            }
            //   }
          }

          //   }
        }
      }, onError: (Object err) {
        // print('got err: $err');
      });
    }
  }

  /// Handle the initial Uri - the one the app was started with
  ///
  /// **ATTENTION**: `getInitialLink`/`getInitialUri` should be handled
  /// ONLY ONCE in your app's lifetime, since it is not meant to change
  /// throughout your app's life.
  ///
  ///
  Future<void> call() async {
    /* if (widget.initialLink != null) {
      final Uri deepLink = widget.initialLink.link;
      Fluttertoast.showToast(
          msg: deepLink.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.TOP,
          timeInSecForIosWeb: 5);
      FirebaseDynamicLinks.instance.onLink.listen((dynamicLinkData) {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => ProfileScreen(
                controller: Get.isRegistered<NewsfeedController>()
                    ? Get.put(NewsfeedController())
                    : Get.find<NewsfeedController>(),
                profileId: "429")));
        // Navigator.pushNamed(context, dynamicLinkData.link.path);
      }).onError((error) {
        // Handle errors
      });
      // Example of using the dynamic link to push the user to a different screen
      // Navigator.pushNamed(context, ProfileScreen());
      Get.to(() =>  ProfileScreen(
          controller: Get.isRegistered<NewsfeedController>()
              ? Get.put(NewsfeedController())
              : Get.find<NewsfeedController>(),
          profileId: "429"));
      // Navigator.of(context).push(MaterialPageRoute(
      //     builder: (context) => ProfileScreen(
      //         controller: Get.isRegistered<NewsfeedController>()
      //             ? Get.put(NewsfeedController())
      //             : Get.find<NewsfeedController>(),
      //         profileId: "429")));
    }*/
    shared = await SharedPreferences.getInstance();
    // print("yes token print");
    Future.delayed(Duration(milliseconds: 1000), () async {
      // print("put start");

      // Future.delayed(Duration(seconds: 2), () async {
      // Get.offAllNamed(AppRoute.mainScreen,arguments: {
      //   "userName": shared.getString("userName"),
      //   "postId": postId != null ? postId : null,
      //   "profileId": profileId != null ? profileId : null,
      // });
      // Future.delayed(Duration(seconds: 3), () {
      // if (Get.isRegistered<NewsfeedController>()) {
      // print('i am here in if session controller');
      /*  if (kIsWeb) {
          print("changeeeee");
          // Get.offAllNamed(FluroRouters.mainScreen);
          context.go(AppRoute.mainScreen);

        } else {
          // if(widget.profileId!=null){
          //   print('HERE IN ELSE CONDITION'+widget.profileId.toString());
          //   // Go to profile route with ID
          //   Get.to(MobileProfileScreen(),arguments: {
          //     "userName": shared.getString("userName"),
          //     "profileId": widget.profileId != null ? widget.profileId : null
          //   });
          //
          // }
          // else{
          Get.offAll(MainScreen(), arguments: {
            "userName": shared.getString("userName"),
            "postId": widget.postId != null ? widget.postId : null,
            "profileId": widget.profileId != null ? widget.profileId : null
          });
        }*/
      // }
      // }
      // else {
      //   // print('i am here in else session controller');
      //   // Get.put(NewsfeedController(
      //   //   linkId: postId != null ? postId : null,
      //   //   profileId: profileId != null ? profileId : null,
      //   // ));
      //   if (kIsWeb) {
      //     Routemaster.of(context)
      //         .replace(AppRoute.mainScreen, queryParameters: {
      //       "userName": shared.getString("userName"),
      //       "postId": widget.postId != null ? widget.postId : null,
      //       "profileId": widget.profileId != null ? widget.profileId : null
      //     });
      //   } else {
      //
      //     if(widget.profileId!=null){
      //       // Go to profile route with ID
      //       Get.to(MobileProfileScreen(),arguments: {
      //         "userName": shared.getString("userName"),
      //         "profileId": widget.profileId != null ? widget.profileId : null
      //       });
      //
      //     }else{
      //     Get.offAll(MainScreen(), arguments: {
      //       "userName": shared.getString("userName"),
      //       "postId": widget.postId != null ? widget.postId : null,
      //       "profileId": widget.profileId != null ? widget.profileId : null
      //     });}
      //   }
      //   // Get.offAll(MainScreen(
      //   //   userName: shared.getString("userName"),
      //   //   postId: widget.postId != null ? widget.postId : null,
      //   //   profileId: widget.profileId != null ? widget.profileId : null,
      //   // ));
      // }
      Get.put(NewsfeedController());
      // print("put end");
      String userData = storage.read("user_profile");
      // print(storage.read('token')+" user data"+userData);
      Get.find<NewsfeedController>().userProfile =
          UserProfile.fromJson(jsonDecode(userData));
      Get.find<NewsfeedController>().userProfile.username =
          storage.read("user_name");
      Get.find<NewsfeedController>().userProfile.notificationAllowed =
          storage.read("notificationAllowed");
      if (Get.find<NewsfeedController>().userProfile.notificationAllowed == 1) {
        Get.find<NewsfeedController>().notificationStatus = true;
      } else {
        Get.find<NewsfeedController>().notificationStatus = false;
      }
      Get.find<NewsfeedController>().update();
      Get.find<NewsfeedController>().languageData =
          await Get.find<NewsfeedController>().getLanguages();

      Get.find<NewsfeedController>().selectedAppLanguageInfoId =
          Get.find<NewsfeedController>().languageData.appLang.id;

      Get.find<NewsfeedController>().upDateLocale(
          Get.find<NewsfeedController>().languageData.appLang.code);
      // Get.find<NewsfeedController>().update();
      if (Get.find<NewsfeedController>().languageData != null) {
        Get.find<NewsfeedController>().isAutoTranslate =
            Get.find<NewsfeedController>()
                        .languageData
                        .autoTranslateSettings
                        .autoTranslate ==
                    1
                ? true
                : false;
        Get.find<NewsfeedController>().selectedLanguage =
            Get.find<NewsfeedController>().languageData.myLang;
      }
      // print('CALL SHARED INIT WITH ID');
      // });

      // Get.delete<SessionController>();
      // });
    });
  }

  /// We handle all exceptions, since it is called from initState.
  Future<void> handleInitialUri(bool isBackground) async {
    // print("handleincominglinks called");
    // call();
    NewsfeedController controller;

    // In this example app this is an almost useless guard, but it is here to
    // show we are not going to call getInitialUri multiple times, even if this
    // was a weidget that will be disposed of (ex. a navigation route change).
    if (!_initialUriIsHandled) {
      _initialUriIsHandled = true;
      // print("_handleInitialUri called");
      try {
        final deepLink = await getInitialUri();
        if (deepLink == null) {
          print('no initial uri');
        } else {
          print('got initial uri: $deepLink');
          if (deepLink != null) {
            print('deep link is found at location ' + deepLink.toString());

            final queryParams = deepLink.queryParameters;
            List<String> pathSegments = deepLink.pathSegments;
            if (pathSegments.isNotEmpty) {
              // String idProfile = queryParams["profileId"];
              // String profilePostId = queryParams["profilePostId"];

              String postID = pathSegments[pathSegments.length - 1];
              String page = pathSegments[pathSegments.length - 2];
              print('PostId${postID}');
              print('PostId${page}');

              print('PostId${postID}');
              print('if deep link id part init');
              // print('profile id:${idProfile}');
              SingleTone.instance.profileId = null;
              SingleTone.instance.postId = null;
              if (page == "profile") {
                SingleTone.instance.profileId = postID;
                /*  Get.snackbar('User 123', idProfile.toString(),
              snackPosition: SnackPosition.BOTTOM,
              duration: Duration(seconds: 3));*/
                print(
                    'SingleTone store profile Id:${SingleTone.instance.profileId}');
                print('profileidsession1nn:${postID}');
                controller = Get.find<NewsfeedController>();

                UserProfile profile =
                    await controller.getOtherUserProfile(int.parse(postID));
                controller.otherUserId = int.parse(postID);
                controller.update();
                /* Navigator.of(context).push(MaterialPageRoute(
              builder: (context) =>  OtherUsersProfile(controller: controller, userInfo: profile),));*/
                !isBackground
                    ? WidgetsBinding.instance.addPostFrameCallback((_) {
                        // MyApp().navigatorKey.currentState.pu
                        Get.to(
                          OtherUsersProfile(
                              controller: controller, userInfo: profile),
                          // arguments: {
                          //   "userName": null,
                          //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                          // }
                        );
                      })
                    : Get.to(
                        OtherUsersProfile(
                            controller: controller, userInfo: profile),
                        // arguments: {
                        //   "userName": null,
                        //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                        // }
                      );
                ;
                // Get.to(Session(
                //   postId: null,
                //   profileId:idProfile,
                // ));
              } else if (page == "postDetail") {
                SingleTone.instance.postId = postID;
                // print('postIdsession1nnn:${postID}');
                // print('Singletone post id :${SingleTone.instance.postId}');

                List<Post> postDetail;
                /* if(kIsWeb){
            SavedPostController   savedController = Get.put(SavedPostController());
            BrowseController   browseController = Get.put(BrowseController());
            controller.isPostDetails = true;
            controller.isTrendsScreen = false;
            controller.isNewsFeedScreen = false;
            controller.isBrowseScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            if (controller.isSavedPostScreen) {
              savedController.update();
            }
            if (controller.isBrowseScreen) {
              browseController.update();
            }
            controller.postDetail2 = await controller
                .getSingleNewsFeedItem(
                postID);
            controller.update();
          }else {*/
                postDetail = await getPostDetails(postID);
                if (postDetail != null) {
                  !isBackground
                      ? WidgetsBinding.instance.addPostFrameCallback((_) {
                          Get.to(CommentsScreen(
                            postId: postDetail[0].postId,
                            thread_no: null,
                          ));
                        })
                      : Get.to(CommentsScreen(
                          postId: postDetail[0].postId,
                          thread_no: null,
                        ));
                  ;
                }
                //}
                /*if (postDetail !=null){
   Get.to(PostDetail(
     controller: Get.isRegistered<NewsfeedController>()
         ? Get.put(NewsfeedController())
         : Get.find<NewsfeedController>(),
     post: postDetail[0],
   ));
 }*/
              }
              // Navigator.pushNamed(context,
              //     dynamicLinkData.link.path,
              //     arguments: {"productId": });
            } else {
              print('else part');
              // Navigator.pushNamed(
              //   context,
              //   dynamicLinkData.link.path,
              // );
            }
            //   }
          }
        }
      } on PlatformException {
        // Platform messages may fail but we ignore the exception
        print('falied to get initial uri');
      }
    }
  }

  _handleDynamicLink(PendingDynamicLinkData data, bool isBackground) async {
    final Uri deepLink = data?.link;
    NewsfeedController controller;
    if (deepLink != null) {
      final queryParams = deepLink.queryParameters;
      print('deep link is found at location ');
      if (queryParams.isNotEmpty) {
        String idProfile = queryParams["profileId"];
        String profilePostId = queryParams["profilePostId"];

        String postID = queryParams["postId"];

        print('PostId${postID}');
        print('if deep link id handle dynamic link');
        print('profile id:${idProfile}');
        SingleTone.instance.profileId = null;
        SingleTone.instance.postId = null;
        if (idProfile != null) {
          SingleTone.instance.profileId = idProfile;
          /*  Get.snackbar('User 123', idProfile.toString(),
              snackPosition: SnackPosition.BOTTOM,
              duration: Duration(seconds: 3));*/
          print('SingleTone store profile Id:${SingleTone.instance.profileId}');
          print('profileidsession1nn:${idProfile}');
          controller = Get.find<NewsfeedController>();

          UserProfile profile = await controller
              .getOtherUserProfile(int.parse(idProfile), postId: profilePostId);
          controller.otherUserId = int.parse(idProfile);
          controller.update();
          /* Navigator.of(context).push(MaterialPageRoute(
              builder: (context) =>  OtherUsersProfile(controller: controller, userInfo: profile),));*/
          !isBackground
              ? WidgetsBinding.instance.addPostFrameCallback((_) {
                  // MyApp().navigatorKey.currentState.pu
                  Get.to(
                    OtherUsersProfile(
                        controller: controller, userInfo: profile),
                    // arguments: {
                    //   "userName": null,
                    //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                    // }
                  );
                })
              : Get.to(
                  OtherUsersProfile(controller: controller, userInfo: profile),
                  // arguments: {
                  //   "userName": null,
                  //   "profileId": idProfile != null ? idProfile : SingleTone.instance.profileId
                  // }
                );
          ;
          // Get.to(Session(
          //   postId: null,
          //   profileId:idProfile,
          // ));
        } else if (postID != null) {
          SingleTone.instance.postId = postID;
          // print('postIdsession1nnn:${postID}');
          // print('Singletone post id :${SingleTone.instance.postId}');

          List<Post> postDetail;
          /* if(kIsWeb){
            SavedPostController   savedController = Get.put(SavedPostController());
            BrowseController   browseController = Get.put(BrowseController());
            controller.isPostDetails = true;
            controller.isTrendsScreen = false;
            controller.isNewsFeedScreen = false;
            controller.isBrowseScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            if (controller.isSavedPostScreen) {
              savedController.update();
            }
            if (controller.isBrowseScreen) {
              browseController.update();
            }
            controller.postDetail2 = await controller
                .getSingleNewsFeedItem(
                postID);
            controller.update();
          }else {*/
          postDetail = await getPostDetails(postID);
          if (postDetail != null) {
            !isBackground
                ? WidgetsBinding.instance.addPostFrameCallback((_) {
                    Get.to(CommentsScreen(
                      postId: postDetail[0].postId,
                      thread_no: null,
                    ));
                  })
                : Get.to(CommentsScreen(
                    postId: postDetail[0].postId,
                    thread_no: null,
                  ));
            ;
          }
          //}
          /*if (postDetail !=null){
   Get.to(PostDetail(
     controller: Get.isRegistered<NewsfeedController>()
         ? Get.put(NewsfeedController())
         : Get.find<NewsfeedController>(),
     post: postDetail[0],
   ));
 }*/
        }
        // Navigator.pushNamed(context,
        //     dynamicLinkData.link.path,
        //     arguments: {"productId": });
      } else {
        print('else part');
        // Navigator.pushNamed(
        //   context,
        //   dynamicLinkData.link.path,
        // );
      }
      //   }
    }
  }

  /* Future<String> createDynamicLink(bool short, String link) async {


    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: kUriPrefix,
      link: Uri.parse(kUriPrefix + link),
      androidParameters: const AndroidParameters(
        packageName: 'com.ogoul.werfieapp',
        minimumVersion: 0,
      ),
      socialMetaTagParameters:
      SocialMetaTagParameters(title: title, imageUrl: Uri.parse(image)),
      dynamicLinkParametersOptions: DynamicLinkParametersOptions(
        shortDynamicLinkPathLength: ShortDynamicLinkPathLength.short,
      ),
      iosParameters: IOSParameters(
        bundleId: 'ios bundleId',
        minimumVersion: '0',
      ),ion: '0',
      ),
    );

    Uri url;
    if (short) {
      final ShortDynamicLink shortLink =
      await dynamicLinks.buildShortLink(parameters);
      url = shortLink.shortUrl;
    } else {
      url = await dynamicLinks.buildLink(parameters);
    }

   return url.toString();
  }*/
  Future<String> createDynamicLink(
      {@required bool short, @required String link}) async {
    SingleTone.instance.profileId = null;
    SingleTone.instance.postId = null;
    _isCreatingLink = true;
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    print(packageInfo.packageName);
    // short=true;
    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: kUriPrefix,
      link: Uri.parse(kUriPrefix + link),
      androidParameters: AndroidParameters(
        packageName: "com.ogoul.werfieapp",
        minimumVersion: 0,
      ),
      // NOT ALL ARE REQUIRED ===== HERE AS AN EXAMPLE =====
      iosParameters: IOSParameters(
        bundleId: 'com.ogoul.werfieapp',
        minimumVersion: '1.0.1',
        appStoreId: '1599453650',
      ),

      // itunesConnectAnalyticsParameters: ItunesConnectAnalyticsParameters(
      //   providerToken: '123456',
      //   campaignToken: 'example-promo',
      // ),
      socialMetaTagParameters: SocialMetaTagParameters(
        title: 'Werfie',
        description: '',
        imageUrl: Uri.parse(
            // "https://images.pexels.com/photos/3841338/pexels-photo-3841338.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"),
            "https://api.werfie.com/werfie_logo1.png"),
      ),
    );

    Uri url;
    if (short) {
      final ShortDynamicLink shortLink =
          await dynamicLinks.buildShortLink(parameters);
      url = shortLink.shortUrl;
    } else {
      url = await dynamicLinks.buildLink(parameters);
    }

    _linkMessage = url.toString();
    _isCreatingLink = false;
    return _linkMessage;
  }

  /// get post detail of data

  Future<List<Post>> getPostDetails(String id) async {
    List<Post> postDetails;
    NewsfeedController controller;
    if (!Get.isRegistered<NewsfeedController>()) {
      controller = await Get.put(NewsfeedController());
      Future.delayed(Duration(seconds: 5), () {
        postDetails = controller
            .getSingleNewsFeedItem(SingleTone.instance.postId) as List<Post>;
        return postDetails;
      });
    } else {
      controller = await Get.find<NewsfeedController>();
      // controller = Get.put(NewsfeedController());
      postDetails =
          (await controller.getSingleNewsFeedItem(SingleTone.instance.postId));
      return postDetails;
    }
  }
}
