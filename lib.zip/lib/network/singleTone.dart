class SingleTone {
  String selectedLocation;
  double lat;
  double lng;
  String profileId;
  String postId;
  String userId;
  int post_Id;
  int momentId;
  bool buttonDisable = false;
  bool socialLogin = false;

  String searchId;
  String searchType;
  String isSearch;
  String searchTag;
  String searchTab;
  int commentId;

  SingleTone._privateConstructor();

  static SingleTone get instance => _instance;
  static final SingleTone _instance = SingleTone._privateConstructor();

  factory SingleTone() {
    return _instance;
  }
}

bool isDarkMode = false;
