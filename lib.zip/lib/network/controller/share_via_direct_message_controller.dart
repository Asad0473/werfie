import 'dart:convert';

import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:http/http.dart' as http;
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import '../../models/share_via_dm_model.dart';
import '../../utils/urls.dart';

class ShareViaDirectMessage {
  Future<bool> sharePostApi(Object queryParameters) async {
    final storage = GetStorage();

    var token = {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    };

    var response = await http.post(Uri.parse(Url.sharePostViaDirectMessage),
        body: jsonEncode(queryParameters),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          // Specify content-type as JSON to prevent empty response body
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        });
    LoggingUtils.printValue("ShareViaDirectMessage ", response);

    if (response.statusCode == 200) {
      return true;
    } else {
      return false;
    }
  }
}
