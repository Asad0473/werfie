import 'dart:convert';

import 'package:country_ip/country_ip.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:phone_form_field/phone_form_field.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/notification/app_notification.dart';

class SignupController extends GetxController {
  String name = "";
  String handle = "";
  String email = "";
  String phone = "";
  String password = "";
  String region = "";
  String dob = "";
  String isoCountryCode = '';
  IsoCode isoCode;
  bool isSignupUsingEmail = true;
  LoginController loginController = Get.find<LoginController>();

  bool isStepOne = true;
  bool isStepTwo = false;
  bool isStepThree = false;
  bool isStepFour = false;
  bool isStepFive = false;

  int currentStep = 1;

  String fcmToken ='';

  List<String> listMonths = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  bool isCountryApiCalled = false;


  @override
  void onInit() async {
    FirebaseNotifications().getToken().then((value) {
      if(value == null){
        //onInit();
        Fluttertoast.showToast(
            msg: 'Please enable notifications. If you choose not to, you will not receive any.',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 5,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }
      fcmToken = value;
      //print("FCM TOKEN SIGNUP CONTROLLER");
      //print(fcmToken);
    });
    if (kIsWeb && !isCountryApiCalled) {
      await getCountryCodeFromIP();
      isCountryApiCalled = true;
    } else {
      await getCountryISOCode();
    }
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  setDob(String dob) {
    //  DOB FORMAT
    //  DD/MM/YYYY
    String day = "";
    String month = "";
    String year = "";

    List<String> listDob = dob.split("/");
    day = listDob[0];

    if (listDob[1].startsWith("0")) {
      month = listMonths[int.parse(listDob[1].split("0")[1]) - 1];
    } else {
      month = listMonths[int.parse(listDob[1]) - 1];
    }
    year = listDob[2];
    this.dob = month + " " + day + "," + " " + year;
  }

  updateUI(int step) {
    currentStep = step;
    update();
/*    switch (step) {
      case 1:
        isStepOne = true;
        isStepTwo = false;
        isStepThree = false;
        isStepFour = false;
        isStepFive = false;
        update();
        break;
      case 2:
        isStepOne = false;
        isStepTwo = true;
        isStepThree = false;
        isStepFour = false;
        isStepFive = false;
        update();
        break;
      case 3:
        isStepOne = false;
        isStepTwo = false;
        isStepThree = true;
        isStepFour = false;
        isStepFive = false;
        update();
        break;
      case 4:
        isStepOne = false;
        isStepTwo = false;
        isStepThree = false;
        isStepFour = true;
        isStepFive = false;
        update();
        break;
      case 5:
        isStepOne = false;
        isStepTwo = false;
        isStepThree = false;
        isStepFour = false;
        isStepFive = true;
        update();
        break;
      default:
        isStepOne = true;
        isStepTwo = false;
        isStepThree = false;
        isStepFour = false;
        isStepFive = false;
        update();
        break;
    }*/
  }

  getCountryISOCode() {
    final WidgetsBinding instance = WidgetsBinding.instance;
    if (instance != null) {
      final List<Locale> systemLocales = instance.window.locales;
      String isoCountryCode = systemLocales.first.countryCode;
      if (isoCountryCode != null) {
        this.isoCountryCode = isoCountryCode;
        getEnumFromString(isoCountryCode);
      } else {
        throw Exception("Unable to get Country ISO code");
      }
    } else {
      throw Exception("Unable to get Country ISO code");
    }
  }

  getCountryCodeFromIP() async {
    try {

      final countryIpResponse = await CountryIp.find();

      if(countryIpResponse !=null){
        isoCountryCode = countryIpResponse?.countryCode;
        getEnumFromString(countryIpResponse?.countryCode);
      }
     /* final response = await http.get(Uri.parse('https://ipinfo.io/json'));
      print(response.body);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        isoCountryCode = data['country'];
        getEnumFromString(data['country']);
        return data['country'];
      }*/
    } catch (e) {
      print('Error getting country code from IP: $e');
    }
  }

  getEnumFromString(String value) {
    try {
      for (var element in IsoCode.values) {
        if (element.toString().split('.')[1] == value) {
          isoCode = element;
          update();
        }
      }
    } catch (e) {
      return null; // If the string does not exist in the enum
    }
  }


}
