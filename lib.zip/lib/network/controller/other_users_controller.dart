import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

import '../singleTone.dart';
import 'login_controller.dart';

class OtherUserController extends GetxController {
  bool isLoading = false;
  UserProfile userProfile;
  List<Post> userPosts = [];
  var userToken = "";
  final storage = GetStorage();
  var userId;
  var api = Api();
  String otherUserName = "";

  //Tabs
  bool isTweets = true;
  bool isTweetsReply = false;
  bool isMedia = false;
  bool isLikes = false;

  bool isFilter = false;

  String selectedTab = "isTweets";
  String selectedView = "isProfile";

  NewsfeedController newsFeedController;

  @override
  void onInit() async {
    newsFeedController = Get.find<NewsfeedController>();

    userId = Get.find<NewsfeedController>().otherUserId;
    // print("YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY" + userId.toString());
    userToken = storage.read('token');
    otherUserName = Get.find<NewsfeedController>().otherUserName;
    update();
    super.onInit();
  }

  // @override
  // onReady() async {
  //   isLoading = true;
  //   update();
  //
  //   // userProfile = await newsFeedController.getOtherUserProfile(userId);
  //   // print("userProfile $userProfile");
  //   // print('USER ' + userProfile.is_follow.toString());
  //   // print('USERID ' + userProfile.is_follow.toString());
  //   // print('USER DATA' + userProfile.toJson().toString());
  //   isLoading = false;
  //   update();
  //   userPosts = await newsFeedController.filterUsersPost('posts');
  //   update();
  //   if (userPosts != null) {
  //     userPosts.forEach((element) {
  //       element.likeCount.value = element.simpleLikeCount;
  //       element.rebuzzCount.value = element.retweetCount;
  //       element.commentCount.value = element.commentsCount;
  //       element.reactionType.value = element.isLiked;
  //
  //       // element.comments.forEach((element) {
  //       //   element.reactionType.value = element.isLiked;
  //       //   element.commentCount.value  = element.simpleLikeCount;
  //       // });
  //       element.reactionType.refresh();
  //       // if (element.isLiked == true) {
  //       //   element.like.value = true;
  //       //   element.like.refresh();
  //       // }
  //     });
  //     update();
  //     super.onReady();
  //   }
  //   // userPosts.forEach((element) {
  //   //   element.likeCount.value = element.simpleLikeCount;
  //   //   element.rebuzzCount.value = element.retweetCount;
  //   //   element.commentCount.value = element.commentsCount;
  //   //   element.reactionType.value = element.isLiked;
  //   //
  //   //   // element.comments.forEach((element) {
  //   //   //   element.reactionType.value = element.isLiked;
  //   //   //   element.commentCount.value  = element.simpleLikeCount;
  //   //   // });
  //   //   element.reactionType.refresh();
  //   //   // if (element.isLiked == true) {
  //   //   //   element.like.value = true;
  //   //   //   element.like.refresh();
  //   //   // }
  //   // });
  //   update();
  //   super.onReady();
  // }

  @override
  void dispose() {
    super.dispose();
  }

  List<Post> postPaged = [];

  Future<List<Post>> filterUsersPostPagged(tab, {int page, int userid}) async {
    // print("filterUsersPostPagged");
    // print(Get.find<NewsfeedController>().otherUserId);
    // print('page other user$page');
    // print(tab);
    isFilter=true;
    try {
      if (page == 1 || page == null) {
        userPosts = [];
      }

      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterUserPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        // "user_id":     Get.find<NewsfeedController>().userId.toString(),
        "user_id": Get.find<NewsfeedController>().otherUserId.toString(),
        "tab": tab.toString(),
        "page_no": page.toString(),
      });
      if (resBody["meta"]["code"] == 200) {
        if (resBody['data'] != null) {
          var postData = resBody['data'] as List;
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();
          userPosts.addAll(postList2);
          if (userPosts != null) {
            for (var element in userPosts) {
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;
              element.reactionType.refresh();
            }
          }
          update();
          isFilter = false;
          return postData.map((e) => Post.fromJson(e)).toList();
        } else {
          isFilter = false;
          update();
          return [];

        }

        // resBody["data"].forEach((element) {
        //   print("element");
        //   print(element);
        //   print("element");
        //   // if (seletedTab == "people") {
        //   //   print("people");
        //   //   filteredPeople.add(FilteredPeople.fromJson(element));
        //   // } else {
        //   print("other");
        //   userPosts.add(Post.fromJson(element));
        //
        //   // }
        // });
        // if(page == 1 || page == null) {
        //   userPosts.addAll(postList2);
        // }
      } else {
        isFilter = false;
        update();
        return [];

      }
      // return userPosts;
    } catch (e) {
      print(e.toString());
      return [];
    }
  }
}
