import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/topic_model/not_interested_topic_model.dart';
import 'package:werfieapp/models/topic_model/topic_model.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../models/post.dart';
import '../../models/topic_model/suggested_following_topic_for_other_profile_model.dart';
import '../../models/topic_model/suggested_following_topic_model.dart';
import '../../models/topic_model/topic_details_model.dart';

class TopicController extends GetxController {
  bool isFollowed = true;
  bool isSuggested = false;
  bool isNotIntrested = false;

  int screenCheck = 0;

  bool isLoading = false;
  var userToken = "";

  List<Post> topicList = [];

  FollowingAndSuggestedTopics followingAndSuggestedTopics;
  SuggestedFollowingTopicForOtherProfile suggestedFollowingTopicForOtherProfile;

  NotInterestedTopic notInterestedTopic;
  Topic topic;

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  var api = Api();

  List<TopicData> modelData = [
    TopicData(mainCateName: 'Support', subCategory: [
      SubCategory(
          subCategoryName: 'Sub support1 ASDFFSDFSDFSFSDF',
          subSubCategory: [
            SubSubCategory(
              subSubCateName: 'Sub Sub Support 1',
            ),
            SubSubCategory(
              subSubCateName: 'Sub Sub Support 2',
            ),
            SubSubCategory(
              subSubCateName: 'Sub Sub Support 3',
            ),
            SubSubCategory(
              subSubCateName: 'Sub Sub Support 4',
            ),
            SubSubCategory(
              subSubCateName: 'Sub Sub Support 5',
            ),
          ]),
      SubCategory(subCategoryName: 'Sub support21', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 21 1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 21 2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 21 3',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 21 4',
        ),
      ]),
      SubCategory(subCategoryName: 'Sub support3', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :3',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :4',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :5',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :6',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :7',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 3 :8',
        ),
      ]),
      SubCategory(subCategoryName: 'Sub support 4', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:3',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:4',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:4',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:5',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:6',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:7',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:8',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 4:9',
        ),
      ]),
      SubCategory(subCategoryName: 'Sub support 5', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 5:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 5:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 5:3',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 5:4',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
      SubCategory(subCategoryName: 'Sub support 6', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:1',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:2',
        ),
        SubSubCategory(
          subSubCateName: 'Sub Sub Support 6:3',
        )
      ]),
    ]),
    TopicData(mainCateName: 'Fassion', subCategory: [
      SubCategory(subCategoryName: 'Fassion 1', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Fassion 1:1',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 1:2',
        ),
      ]),
      SubCategory(subCategoryName: 'Fassion 2', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Fassion 2:1',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 2:2',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 2:3',
        ),
      ]),
      SubCategory(subCategoryName: 'Fassion 3', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Fassion 3:1',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 3:2',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 3:3',
        ),
      ]),
      SubCategory(subCategoryName: 'Fassion 4', subSubCategory: [
        SubSubCategory(
          subSubCateName: 'Fassion 4:1',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 4:2',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 4:3',
        ),
        SubSubCategory(
          subSubCateName: 'Fassion 4:4',
        ),
      ])
    ]),
    TopicData(mainCateName: 'Food', subCategory: [
      SubCategory(subCategoryName: 'Food 1', subSubCategory: [
        SubSubCategory(subSubCateName: 'Food 1:1'),
        SubSubCategory(subSubCateName: 'Food 1:2'),
        SubSubCategory(subSubCateName: 'Food 1:3'),
        SubSubCategory(subSubCateName: 'Food 1:4'),
      ]),
      SubCategory(subCategoryName: 'Food 2', subSubCategory: [
        SubSubCategory(subSubCateName: 'Food 2:1'),
        SubSubCategory(subSubCateName: 'Food 2:2'),
        SubSubCategory(subSubCateName: 'Food 2:3'),
      ]),
      SubCategory(subCategoryName: 'Food 3', subSubCategory: [
        SubSubCategory(subSubCateName: 'Food 3:1'),
        SubSubCategory(subSubCateName: 'Food 3:2'),
      ]),
    ]),
    TopicData(mainCateName: 'Animation', subCategory: [
      SubCategory(subCategoryName: 'Animation 1', subSubCategory: [
        SubSubCategory(subSubCateName: 'Animation 1:1'),
        SubSubCategory(subSubCateName: 'Animation 1:2'),
        SubSubCategory(subSubCateName: 'Animation 1:3'),
        SubSubCategory(subSubCateName: 'Animation 1:4'),
        SubSubCategory(subSubCateName: 'Animation 1:4')
      ]),
      SubCategory(subCategoryName: 'Animation 2', subSubCategory: [
        SubSubCategory(subSubCateName: 'Animation 2:1'),
        SubSubCategory(subSubCateName: 'Animation 2:2'),
        SubSubCategory(subSubCateName: 'Animation 2:3'),
      ]),
    ])
  ];

  @override
  void onInit() {
    scrollController = ScrollController()..addListener(scrollListener);

    isFollowed = true;
    isSuggested = false;
    isNotIntrested = false;

    suggestedTopic();

    // TODO: implement onInit
    super.onInit();
  }

  void scrollListener() {
    if (isShrink != lastStatus) {
      {
        lastStatus = isShrink;
        update();
      }
      update();
    }
  }

  ScrollController scrollController;

  bool lastStatus = true;
  double height = 200;

  bool get isShrink {
    // print("shrink");
    return scrollController != null &&
        scrollController.hasClients &&
        scrollController.offset > (height - kToolbarHeight);
  }

  @override
  void dispose() {
    scrollController?.removeListener(scrollListener);
    scrollController?.dispose();
    super.dispose();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  /// implemented the selected tab
  ///

  void followedTab() {
    suggestedTopic();
    isFollowed = true;
    isSuggested = false;
    isNotIntrested = false;

    update();
  }

  void suggestedTab() {
    suggestedTopic();
    isFollowed = false;
    isSuggested = true;
    isNotIntrested = false;
    update();
  }

  void notIntrestedTab() {
    notInterestedTopicFunction();
    isFollowed = false;
    isSuggested = false;
    isNotIntrested = true;
    update();
  }

  Future<FollowingAndSuggestedTopics> suggestedTopic() async {
    isLoading = true;
    update();
    var response = await api.get(Uri.parse(Url.followedTabUrl), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': newsfeedController.storage.read('token'),
    });
    var data = json.decode(response);
    // print("response data  $data");
    if (data["meta"]["code"] == 200) {
      var data_ = FollowingAndSuggestedTopics.fromJson(data);
      followingAndSuggestedTopics = data_;
      isLoading = false;
      update();
      return followingAndSuggestedTopics;
    } else {
      isLoading = false;
      update();
      return null;
    }
  }



  Future<dynamic> topicPost({int topicId, int pageNO, bool isFromRoute = false}) async {
    isLoading = true;
    if (!isFromRoute) {
      update();
    }

    // print("topicid ${topicId}");

    // print(userToken.toString());
    var response = await http.post(
      Uri.parse(Url.topicsDetails),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'topic_id': topicId,
          "page_no": pageNO,
        },
      ),
    );
    // print(userToken.toString());

    // print("response topic details: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data_ = Topic.fromJson(parsedJson);
      topic = data_;

      var data = parsedJson["data"]["newsfeed"] as List;

      topicList = [];
      data.forEach((element) {
        var datax = Post.fromJson(element);
        topicList.add(datax);
      });

      topicList.forEach((element) {
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;

        // element.comments.forEach((element) {
        //   element.reactionType.value = element.isLiked;
        //   element.commentCount.value = element.simpleLikeCount;
        // });
        // element.comments.forEach((element) {
        //   element.reactionType.value = element.isLiked;
        //   element.commentCount.value = element.simpleLikeCount;
        // });

        element.reactionType.refresh();
      });

      // print("topicList.length  ${topicList.length} ");

      isLoading = false;
      if (!isFromRoute) {
        update();
      }
    }
  }

  Future<List<Post>> topic_Post({int topicId, int pageNO}) async {
    // isLoading = true;
    // update();

    // print("pageNO  $pageNO");

    if (pageNO == 1 || pageNO == null) {
      topicList = [];
    }

    // print("topicid ${topicId}");

    print(userToken.toString());
    var response = await http.post(
      Uri.parse(Url.topicsDetails),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'topic_id': topicId,
          "page_no": pageNO,
        },
      ),
    );
    print(userToken.toString());

    // print("response topic details: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson["data"]["newsfeed"] as List;

      if (data.isEmpty) {
        return [];
      }

      data.forEach((element) {
        var datax = Post.fromJson(element);
        topicList.add(datax);
      });

      topicList.forEach((element) {
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;

        // element.comments.forEach((element) {
        //   element.reactionType.value = element.isLiked;
        //   element.commentCount.value = element.simpleLikeCount;
        // });
        // element.comments.forEach((element) {
        //   element.reactionType.value = element.isLiked;
        //   element.commentCount.value = element.simpleLikeCount;
        // });

        element.reactionType.refresh();
      });

      // print("topicList.length  ${topicList.length} ");

      return topicList;

      isLoading = false;
      update();
    }
  }



  Future<dynamic> followUnFollowTopic({int topicId}) async {
    // print("topicid ${topicId}");
    var response = await http.post(
      Uri.parse(Url.followUnFollowTopic),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'topic_id': topicId,
        },
      ),
    );
    // print("response followUnFollow: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      return true;
    } else {
      return false;
    }
  }

  Future<dynamic> addRemoveNotInterested({int topicId}) async {
    // print("topicid ${topicId}");
    var response = await http.post(
      Uri.parse(Url.addRemoveNotInterested),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'topic_id': topicId,
        },
      ),
    );
    // print("response add_remove_not_interested: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      return true;
    } else {
      return false;
    }
  }

  Future<NotInterestedTopic> notInterestedTopicFunction(
      {bool isFromRoute = false}) async {
    isLoading = true;
    update();
    var response = await api.get(Uri.parse(Url.notInterestTopic), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': newsfeedController.storage.read('token'),
    });
    var data = json.decode(response);
    // print("response data  $data");
    if (data["meta"]["code"] == 200) {
      var data_ = NotInterestedTopic.fromJson(data);

      notInterestedTopic = data_;
      isLoading = false;
      update();
      return notInterestedTopic;
    } else {
      notInterestedTopic = null;
      isLoading = false;
      update();
      return null;
    }
  }
}
