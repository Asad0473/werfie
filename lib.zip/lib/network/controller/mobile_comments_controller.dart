import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

class MobileCommentsController extends GetxController {
  final postIdFromNotificationScreen;
  final thread_no;

  Post post;

  MobileCommentsController({this.postIdFromNotificationScreen, this.thread_no,this.post});

  // Post postDetail;
  bool isLoading = false;
  bool isError = false;
  String commentText = '';
  bool isCommentPost = false;

  var userToken = "";
  bool mentionTag = false;
  var api = Api();
  final controller = Get.find<NewsfeedController>();

  @override
  onInit() async {
    isLoading = true;
    // update();

    if (!kIsWeb) {
      getSingleNewFeed();
      getCommentsPostLists(postId: postIdFromNotificationScreen);
    } else {
      getCommentsPostLists(postId: postIdFromNotificationScreen);
    }
    super.onInit();
  }

  @override
  void onReady() async {

    getSingleNewFeed();
//
// if(thread_no ==null){
//
//
//
//   // controller.postDetail2 = await controller.getSingleNewsFeedItem(postIdFromNotificationScreen ?? controller.postId);
//   //
//   // controller.postDetail2.forEach((element){
//   //   element.rebuzz.value   = element.isRetweeted;
//   //   element.likeCount.value = element.simpleLikeCount;
//   //   element.rebuzzCount.value = element.retweetCount;
//   //   element.commentCount.value = element.commentsCount;
//   //   element.reactionType.value = element.isLiked;
//   //   element.comments.forEach((element) {
//   //     element.reactionType.value = element.isLiked;
//   //     element.commentCount.value  = element.simpleLikeCount;
//   //   });
//   //
//   //   element.reactionType.refresh();
//   //
//   //
//   // });
//
//
//   controller.selectedPost2 = await controller.getSingleNewsFeedItem( postIdFromNotificationScreen);
//
//
//
//   controller.selectedPost2.forEach((element) {
//     element.rebuzz.value   = element.isRetweeted;
//     element.likeCount.value = element.simpleLikeCount;
//     element.rebuzzCount.value = element.retweetCount;
//     element.commentCount.value = element.commentsCount;
//     element.reactionType.value = element.isLiked;
//     // element.comments.forEach((element) {
//     //   element.reactionType.value = element.isLiked;
//     //   element.commentCount.value  = element.simpleLikeCount;
//     // });
//
//     element.reactionType.refresh();
//
//
//   });
//
//
// }
//
//     else
//     {
//
//   // controller.postDetail2 = await controller.getSingleNewsFeedItemThread(postIdFromNotificationScreen ?? controller.threadNumber) ;
//   //
//   // controller.postDetail2.forEach((element){
//   //   element.rebuzz.value   = element.isRetweeted;
//   //   element.likeCount.value = element.simpleLikeCount;
//   //   element.rebuzzCount.value = element.retweetCount;
//   //   element.commentCount.value = element.commentsCount;
//   //   element.reactionType.value = element.isLiked;
//   //   element.comments.forEach((element) {
//   //     element.reactionType.value = element.isLiked;
//   //     element.commentCount.value  = element.simpleLikeCount;
//   //   });
//   //
//   //   element.reactionType.refresh();
//   //
//   //
//   // });
//
//   controller.selectedPost2 = await controller.getSingleNewsFeedItemThread( thread_no);
//
//
//   controller.selectedPost2.forEach((element) {
//     element.rebuzz.value   = element.isRetweeted;
//     element.likeCount.value = element.simpleLikeCount;
//     element.rebuzzCount.value = element.retweetCount;
//     element.commentCount.value = element.commentsCount;
//     element.reactionType.value = element.isLiked;
//     // element.comments.forEach((element) {
//     //   element.reactionType.value = element.isLiked;
//     //   element.commentCount.value  = element.simpleLikeCount;
//     // });
//
//     element.reactionType.refresh();
//
//
//   });
//
// }
//
//     print('selected Posted listed${controller.selectedPost2}');
//     isLoading = false;
    //  update();
    super.onReady();
  }

  void getSingleNewFeed() async {
    try {
      isError = false;
      if (thread_no == null) {
        controller.selectedPost2 =
        await getSingleNewsFeedItem(postIdFromNotificationScreen);

        if (controller.post?.translation?.value == true &&
            controller.selectedPost2.isNotEmpty) {
          controller.isShowMoreCheck = true;
          // controller.update();
          //  var value  = await  controller.newsFeedTranslation( controller.post.postId, controller.languageData.myLang.code);
          controller.selectedPost2[0].translationData =
              controller.post.translationData;
          controller.selectedPost2[0].translation.value = true;

          controller.isShowMoreCheck = false;

          //print(" controller.isShowMoreCheck ${ controller.isShowMoreCheck}");
          update();
          // controller.update();
          //print("post.translationData ${ controller.selectedPost2[0].translationData.data[0].body}");
          controller.update(['translate']);
        }


        controller.selectedPost2.forEach((element) {
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value  = element.simpleLikeCount;
          // });

          element.reactionType.refresh();
        });
      } else {
        // controller.postDetail2 = await controller.getSingleNewsFeedItemThread(postIdFromNotificationScreen ?? controller.threadNumber) ;
        //
        // controller.postDetail2.forEach((element){
        //   element.rebuzz.value   = element.isRetweeted;
        //   element.likeCount.value = element.simpleLikeCount;
        //   element.rebuzzCount.value = element.retweetCount;
        //   element.commentCount.value = element.commentsCount;
        //   element.reactionType.value = element.isLiked;
        //   element.comments.forEach((element) {
        //     element.reactionType.value = element.isLiked;
        //     element.commentCount.value  = element.simpleLikeCount;
        //   });
        //
        //   element.reactionType.refresh();
        //
        //
        // });

        controller.selectedPost2 = await getSingleNewsFeedItemThread(thread_no);

        controller.selectedPost2.forEach((element) {
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          element.reactionType.refresh();
        });
      }
    }catch(e){
      isLoading = false;
      isError = true;
      update();
      print("<====== EXCEPTION MOBILE COMMENTS CONTROLLER =====> getSingleNewFeed()");
      print(e);
    }
  }

  deleteComment(commentId) async {
    // print("$userToken");

    // ignore: unused_local_variable
    var response = await api.delete(
      Uri.parse(Url.deleteCommentUrl),
      queryParameters: {'comment_id': commentId.toString()},
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': GetStorage().read("token"),
      },
    );

    controller.selectedPost2 = await controller
        .getSingleNewsFeedItem(controller.postId, commentCheck: false);

    controller.selectedPost2.forEach((element) {
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      // element.comments.forEach((element) {
      //   element.reactionType.value = element.isLiked;
      //   element.commentCount.value  = element.simpleLikeCount;
      // });
      element.reactionType.refresh();
    });

    controller.update();

    update();

    // print(response.toString());
  }

  /// get Comments api
  ///
  ///
  Future<List<Post>> getSingleNewsFeedItem(postId,
      {bool isReload = true,
      int threadNumber,
      bool commentCheck,
      int index}) async {

    try {
      isError = false;
      if (isReload && commentCheck != false) {
        isLoading = true;
        update();
      }
      controller.getDataSingleNews = [];
      controller.selectedPost2 = [];
      var response;
      if (threadNumber == null) {
        // print("ye wali chali");
        response = await api.get(
          Uri.parse("${Url.getSingleNewsFeedItemUrl + "?post_id=$postId"}"),
          token: {
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': GetStorage().read("token"),
          },
        );
      } else {
        response = await api.get(
          Uri.parse(
              "${Url.getSingleNewsFeedItemUrl + "?thread_no=$threadNumber"}"),
          token: {
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': GetStorage().read("token"),
          },
        );
      }

      // print("response post detail xx: ${response}");

      var posts = json.decode(response);

      var singlePostData = posts['data'] as List;
      isLoading = false;
      update();
      //print('get data ');
      // print(singlePostData);

      controller.selectedPost2.clear();
      controller.getDataSingleNews.clear();
      singlePostData.forEach((element) {
        var data2 = Post.fromJson(element);
        controller.getDataSingleNews.add(data2);
      });
      // singlePostData.forEach((element) {
      //   var data2 = Post.fromJson(element);
      //   controller.selectedPost2.add(data2);
      // });

      controller.getDataSingleNews.forEach((element) {
        element.rebuzz.value = element.isRetweeted;
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
        element.reactionType.refresh();
      });
      // controller.selectedPost2.forEach((element){
      //   element.rebuzz.value   = element.isRetweeted;
      //   element.likeCount.value = element.simpleLikeCount;
      //   element.rebuzzCount.value = element.retweetCount;
      //   element.commentCount.value = element.commentsCount;
      //   element.reactionType.value = element.isLiked;
      //   element.reactionType.refresh();
      // });
      update();

      commentCheck = true;

      return controller.getDataSingleNews;
    }catch(e){
      isLoading = false;
      isError = true;
      update();
      print("<====== EXCEPTION MOBILE COMMENTS CONTROLLER =======> getSingleNewsFeedItem()");
      print(e);
    }
  }

  Future<List<Post>> getCommentsPostLists({int postId}) async {
    controller.getCommentsList = [];
    var response = await http.post(
      Uri.parse(Url.getCommentsListPosts),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': GetStorage().read("token"),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
        },
      ),
    );
    //print("response of comments post list   ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var jsonData = parsedJson['data'] as List;
      jsonData.forEach((element) {
        var data2 = Post.fromJson(element);
        controller.getCommentsList.add(data2);
      });

      controller.getCommentsList.forEach((element) {
        element.rebuzz.value = element.isRetweeted;
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
      });
      update();
      return controller.getCommentsList;
    } else {
      return controller.getCommentsList = [];
    }
  }

  Future<List<Post>> getSingleNewsFeedItemThread(threadNumber,
      {bool isReload = true}) async {
    if (isReload) {
      isLoading = true;

      update();
    }

    controller.getDataSingleNews = [];
    var response = await api.get(
      Uri.parse("${Url.getSingleNewsFeedItemUrl + "?thread_no=$threadNumber"}"),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': GetStorage().read("token"),
      },
    );

    var posts = json.decode(response);

    var singlePostData = posts['data'] as List;
    isLoading = false;
    update();
    //print('get data ');
    // print(singlePostData);

    //  List <Post> postData = [];
    controller.getDataSingleNews.clear();

    singlePostData.forEach((element) {
      var data2 = Post.fromJson(element);
      controller.getDataSingleNews.add(data2);
    });

    controller.getDataSingleNews.forEach((element) {
      element.rebuzz.value = element.isRetweeted;
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      // element.comments.forEach((element) {
      //   // replyMentionTag.add(false);
      //   element.reactionType.value = element.isLiked;
      //   element.commentCount.value  = element.simpleLikeCount;
      // });

      element.reactionType.refresh();
    });

    return controller.getDataSingleNews;

    //
    // });
    // return Post.fromJson(singlePostData);
  }
}
