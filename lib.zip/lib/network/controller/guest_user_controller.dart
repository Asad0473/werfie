import 'dart:async';
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/api.dart';

import '../../models/guest_user_model/guest_user_model.dart';
import '../../models/guest_user_model/guest_user_search_query_model.dart';
import '../../models/guest_user_model/guest_user_search_result_model.dart';
import '../../models/guest_user_model/guest_user_trends.dart';
import '../../utils/app_languages.dart';
import '../../utils/debounce_search.dart';
import '../../utils/urls.dart';

class GuestUserController extends GetxController {
  /// Get Image of Dimension
  // Future<Widget> getImage(String url,) async {
  //   final Completer<Widget> completer = Completer();
  //
  //   // String url = '';
  //   final image = NetworkImage(url);
  //   // final config = await image.obtainKey(const ImageConfiguration());
  //   // final load = image.load(config, (buffer, {allowUpscaling, cacheHeight, cacheWidth}) => null);
  //
  //   final listener = new ImageStreamListener((ImageInfo info, isSync) async {
  //     print(info.image.width);
  //     print(info.image.height);
  //
  //     if (info.image.width == 80 && info.image.height == 160) {
  //       completer.complete(Container(child: Text('AZAZA')));
  //     } else {
  //       completer.complete(
  //         ConstrainedBox(
  //           constraints: BoxConstraints(
  //             maxWidth: Get.width,
  //             maxHeight:  info.image.width == info.image.height ? 504 :650,
  //             minHeight: 284,
  //             minWidth:  info.image.width >info.image.height ? Get.width :384,
  //           ),
  //           child:  Image(image: image,fit: BoxFit.fill,),
  //         ),
  //         //     Container(
  //         //       height :info.image.height == info.image.width
  //         //           ? 504 : info.image.height > info.image.width && info.image.height >= 1500
  //         //           ? 590 : info.image.height > info.image.width && info.image.height >= 1000
  //         //           ? 550 : info.image.height > info.image.width && info.image.height >= 800
  //         //           ? 510 : info.image.height > info.image.width && info.image.height >= 600
  //         //           ? 510 :  info.image.height > info.image.width && info.image.height >= 500
  //         //           ? 420 : info.image.height < info.image.width && info.image.height >= 400
  //         //           ? 330 :  info.image.height < info.image.width && info.image.height >= 300
  //         //           ? 330 :info.image.height < info.image.width && info.image.height <= 300
  //         //            ? 280 :info.image.height,
  //         //       width : info.image.height == info.image.width
  //         //           ? Get.width : info.image.height > info.image.width && info.image.height >= 1500
  //         //           ? 430 : info.image.height > info.image.width && info.image.height >= 1000
  //         //           ? 410 : info.image.height > info.image.width && info.image.height >= 800
  //         //           ? 382 : info.image.height > info.image.width && info.image.height >= 500
  //         //           ? 382 : info.image.height < info.image.width && info.image.height >= 300
  //         //           ? Get.width : info.image.height < info.image.width && info.image.height <= 300
  //         //           ? Get.width : Get.width,
  //         //     child: Image(image: image,fit: BoxFit.cover,),
  //         // )
  //       );
  //      // update();
  //     }
  //   });
  //
  //   image.resolve(ImageConfiguration()).addListener(listener);
  //   return completer.future;
  // }
  AppLanguage selectedLanguage=AppLanguage();
  AppLanguage dropDownValue ;
  // = AppLanguage(
  //   id: 1,
  //   name: 'English',
  //   code: 'en',
  // );

  List<AppLanguage> languageList=[
    AppLanguage(
        id: 1,
        name: 'English',
        code:'en'
    ),AppLanguage(
        id: 2,
        name: 'Arabic',
        code:'ar'
    ),AppLanguage(
        id: 3,
        name: 'French',
        code:'fr'
    ),AppLanguage(
        id: 4,
        name: 'German',
        code:'de'
    ),AppLanguage(
        id: 5,
        name: 'Italian',
        code:'it'
    ),

    AppLanguage(
        id: 9,
        name: 'Hindi',
        code:'hi'
    ),
  ];

  bool isGuestUserNewsFeedScreen = false;
  bool isGuestUserSettingScreen = false;
  bool isGuestUserTopicsData = false;
  var navRoute = "isNewsFeedScreen";
  bool isTrendingTab = true;
  bool isSuggestedTab = false;
  bool isTopicTab = false;
  bool isMusicTab = false;
  bool isTravelTab = false;
  bool isSearchTab = false;
  bool trendingShowWidget = false;
  bool isGuestUserLoading = false;

  /// show the search from api
  bool searchFilter = false;

  /// show the search post in veiw
  bool searchPostsView = false;
  bool isGuestSearch = false;
  GuestUserModelTopicData userModelData;
  List<GuestUserTrends> userTrendsData;
  GuestUserSearchQueryModel guestUserSearchModel;
  GuestUserSearchResultModel guestUserSearchResultModel;
  var imagesListForCarousel = [];
  bool isTrendsDataLoading = false;
  TextEditingController searchFieldController = TextEditingController();
  final delaySearch = DelayInSearch(milliseconds: 50);

  @override
  Future<void> onInit() async {
    isTrendingTab = true;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = true;
    searchFilter = false;
    searchPostsView = false;
    await getGuestUserTrendsData();
    // await  getGuestUserTopicsId();
    await getGuestUserTopicsData(1);
    update(['topicData']);
    // print('guestUser init controller ');
    // TODO: implement onInit
    super.onInit();
  }

  ///tab controller

  trendingTab() async {
    isTrendingTab = true;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = true;
    searchFilter = false;
    searchPostsView = false;
    // await getGuestUserTrendsData();
    update();
    await getGuestUserTopicsData(1);
    update(['topicData']);
  }

  newsAndSocialTabs() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = true;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    update();
    await getGuestUserTopicsData(5);
    update(['topicData']);
  }

  filmsTvTabs() async {
    isTrendingTab = false;
    isSuggestedTab = true;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    update();
    await getGuestUserTopicsData(2);
    update(['topicData']);
  }

  musicTab() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = true;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    update();
    await getGuestUserTopicsData(6);
    update(['topicData']);
  }

  travelTab() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = true;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    update();
    await getGuestUserTopicsData(3);
    update(['topicData']);
  }

  searchTab({String type, int id}) {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    trendingShowWidget = false;
    isSearchTab = true;
    searchFilter = false;
    searchPostsView = true;
    update();
    getGuestUserSearchPost(type: type, id: id);
  }

  // Convert Map to List of Images
  mapToList(post) {
    imagesListForCarousel.clear();
    for (int i = 0; i < post.postFiles.length; i++) {
      imagesListForCarousel.add(post.postFiles[i]['file_path']);
    }
  }

  var api = Api();

  /// guest user api hit  topics

  Future<GuestUserModelTopicData> getGuestUserTopicsData(int id) async {
    isGuestUserLoading = true;
    //  userModelData=null;
    update(['topicData']);
    var responseData;
    try {
      responseData = await api.get(
          Uri.parse(
              Url.guestUserTopicData + "?type=${'topics'}" + "&" + "id=${id}"),
          token: {
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',

            //'Token': storage.read('token'),
          });

      var data = json.decode(responseData);
if(responseData==null){
  debugPrint('Error show again null : ');
}
      if (data["meta"]["code"] == 200) {
        if (data['data'] != null) {
          // print('response data guestUserTopicData :${data['data']}');
          var jasonData = data['data'];
          userModelData = GuestUserModelTopicData.fromJson(jasonData);
          isGuestUserLoading = false;
          update(['topicData']);
          return userModelData;
        }
      }

      else {
        isGuestUserLoading = false;
        update(['topicData']);
        return userModelData = null;
      }
    } catch (e) {
      if(responseData==null){
        isGuestUserLoading = false;
        update(['topicData']);
      }
      else{
        debugPrint('Error show11 : $e');

        throw Exception(e);
      }

    }
  }

  /// guest user api trends api
  Future<List<GuestUserTrends>> getGuestUserTrendsData() async {
    isTrendsDataLoading = true;
    userTrendsData = [];
    update();
    var responseData;
    try {

       responseData = await api
          .get(Uri.parse(Url.guestUserTopicData + "?type=${'trends'}"), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',

        //'Token': storage.read('token'),
      });

      var data = json.decode(responseData);

      if (data["meta"]["code"] == 200) {
        if (data['data'] != null || data['data'] != []) {
          // print('response data guestUserTrendsData :${data['data']}');
          data['data'].forEach((element) {
            userTrendsData.add(GuestUserTrends.fromJson(element));
          });
          isTrendsDataLoading = false;
          update();
          return userTrendsData;
        }
      }
      else {
        isTrendsDataLoading = false;
        update();
        return userTrendsData = [];
      }
    }
    catch (e) {
      debugPrint('call it execption :$e');
if(responseData==null ){
  isTrendsDataLoading = false;
  update();
  debugPrint('call it execption in ineer if :$e');
}
      throw Exception(e);
    }
  }

  /// guest user search query
  Future<GuestUserSearchQueryModel> getGuestUserSearch(String search) async {
    isGuestSearch = true;
    // guestUserSearchModel=null;
    update();
    var responseData ;
    try {

      responseData = await api.get(Uri.parse(Url.guestSearch + "?q=${search}"), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',

        //'Token': storage.read('token'),
      });
      var data = json.decode(responseData);

      if (data["meta"]["code"] == 200) {
        if (data['data'] != null || data['data'] != []) {
          // print('response guest Search :${data['data']}');
          var jasonData = data['data'];
          guestUserSearchModel = GuestUserSearchQueryModel.fromJson(jasonData);
          isGuestSearch = false;
          searchFilter = true;
          update();
          return guestUserSearchModel;
        }
      }
      else {
        isGuestSearch = false;
        searchFilter = true;
        update();
        return guestUserSearchModel = null;
      }
    }
    catch (e) {
      if(responseData ==null){
        isGuestSearch = false;
        searchFilter = true;
        update();
      }else{
        throw Exception(e);
      }

    }
  }

  /// guest user Search result
  Future<GuestUserSearchResultModel> getGuestUserSearchPost(
      {@required String type, @required int id}) async {
    isGuestUserLoading = true;
    //  guestUserSearchResultModel=null;

    update(['searchFilter']);
    var responseData;
    try {

      responseData = await api.get(
          Uri.parse(Url.guestSearchResult + "?type=${type}" + "&" + "id=${id}"),
          token: {
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',

            //'Token': storage.read('token'),
          });
      var data = json.decode(responseData);

      if (data["meta"]["code"] == 200) {
        if (data['data'] != null || data['data'] != []) {
          // print('response guest Search :${data['data']}');
          var jasonData = data['data'];
          guestUserSearchResultModel =
              GuestUserSearchResultModel.fromJson(jasonData);
          isGuestUserLoading = false;
          update(['searchFilter']);
          return guestUserSearchResultModel;
        }
      }
      else {
        isGuestUserLoading = false;
        update(['searchFilter']);
        return guestUserSearchResultModel = null;
      }
    }
    catch (e) {
      if(responseData==null){
        isGuestUserLoading = false;
        update(['searchFilter']);
      }
      else{
        throw Exception(e);
      }

    }
  }
}

/// using delay for some time when typing  is finished what you want do at search

