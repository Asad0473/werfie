import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_rx/src/rx_workers/rx_workers.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/apis/accountLockout/AccountLockoutApi.dart';
import 'package:werfieapp/utils/strings.dart';

class AccountLockoutController extends GetxController {
  final incorrectAttempts = RxInt(0);
  final lastAttemptTime = Rx<DateTime>(null);
  final GetStorage _getStorage = GetStorage();
  final String keyIncorrectAttemptsCount = "incorrectAttempts";
  final String keyLasAttemptTime = "lastAttemptTime";

  @override
  void onInit() {
    super.onInit();
    loadLastAttemptTime(); // Load data on initialization
    //ever(incorrectAttempts, (_) => startResetTimer(""));
  }

  void resetAttempts() {
    incorrectAttempts.value = 0;
    lastAttemptTime.value = null;
    update(); // Notify listeners of changes
  }

  Future<void> saveLastAttemptTime(DateTime time) async {
    _getStorage.write(keyLasAttemptTime, time.toIso8601String());
    _getStorage.write(keyIncorrectAttemptsCount, incorrectAttempts);
  }
  Future<void> resetAttemptTime() async {
    _getStorage.remove(keyLasAttemptTime );
    _getStorage.remove(keyIncorrectAttemptsCount);
  }


  Future<void> loadLastAttemptTime() async {
    final timeString = _getStorage.read(keyLasAttemptTime);
    incorrectAttempts.value = _getStorage.read(keyIncorrectAttemptsCount) ?? 0;
    lastAttemptTime.value = timeString?.parseIso8601();
  }

  Future<void> callApi(String email) async {
    // API CALL TO BLOCK ACCOUNT
    //print("<============ Account Locked for 30 minutes ============>");
    AccountLockoutAPIRes accountLockoutAPIRes = await AccountLockoutApi().lockAccount(email);
    if(accountLockoutAPIRes.success) {
      resetAttempts();
      resetAttemptTime();
      Fluttertoast.showToast(
          msg:
          "You\'r Account is locked for 30 Minutes please try again after 30 Minutes",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 5,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          webBgColor: "linear-gradient(to right, #FF0000FF, #FF0000FF)",
          webPosition: "center",
          fontSize: kIsWeb ? 18 : 16.0);
    }else{
      Fluttertoast.showToast(
          msg:
          Strings.someThingWentWrong,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 5,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          webBgColor: "linear-gradient(to right, #FF0000FF, #FF0000FF)",
          webPosition: "center",
          fontSize: kIsWeb ? 18 : 16.0);
    }
  }

  void startResetTimer(String email) {
    if (incorrectAttempts.value >= 5 &&
        (lastAttemptTime.value == null ||
            DateTime.now().difference(lastAttemptTime.value) <
                const Duration(minutes: 3))) {
      callApi(email);
    } else {
      final timer = Timer(
          const Duration(minutes: 3) -
              (lastAttemptTime.value?.difference(DateTime.now()) ??
                  const Duration(minutes: 3)), () {
        //resetAttempts();
      });
      ever(incorrectAttempts,
          (_) => timer?.cancel()); // Cancel timer on successful login
    }
  }
}
