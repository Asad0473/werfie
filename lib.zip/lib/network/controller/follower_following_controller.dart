import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/get_follower.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get_storage/get_storage.dart';

class FollowerController extends GetxController {
  var api = Api();
  final storage = GetStorage();
  var isLoading = false;
  int followingCheck = 0;
  List<GetFollowerModel> followerList = [];
  List<GetFollowingModel> followingList = [];
  List<GetFollowerModel> verifiedFollowerList = [];
  @override
  void onInit() async {
    LoggingUtils.printValue("ON INT FOLLOER FOLLOEING", followerList.length);
    super.onInit();
  }

  Future<List<GetFollowerModel>> getFollower(
      {userId, bool isFromRoute = false}) async {
    print(userId);
    followerList = [];
    isLoading = true;
    if(kIsWeb) {
      if (!isFromRoute) {
        update();
      }
    }else{
      update();

    }
    var responseBody = await api.post(Uri.parse(Url.getFollower), token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "other_user_id": userId == storage.read("id") ? "" : userId.toString()
    });
    LoggingUtils.printValue("OtherUserId ", userId);
    LoggingUtils.printValue("LOGGED IN USER ID ", storage.read("id"));

    followerList = [];

    var follower = json.decode(responseBody);
    if (follower['meta']["code"] == 200) {
      if (follower['data'] != null) {
        follower['data'].forEach((element) {
          followerList.add(GetFollowerModel.fromJson(element));
        });
      }
    }
    verifiedFollowerList=[];
    verifiedFollowerList=followerList.where((element) => element.accountVerified=="verified").toList();
    isLoading = false;

    if(kIsWeb) {
      if (!isFromRoute) {
        update();
      }
    }else{
      update();

    }
    return followerList;
  }

  Future<List<GetFollowingModel>> getFollowing(
      {userId, bool isFromRoute = false}) async {
    // print(userId);

    followingList = [];
    isLoading = true;
    if(kIsWeb) {
      if (!isFromRoute) {
        update();
      }
    }else{
      update();

    }
    var responseBody = await api.post(Uri.parse(Url.getFollowing), token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "other_user_id": userId == storage.read("id") ? "" : userId.toString()
    });
    followingList = [];

    var follower = json.decode(responseBody);
    if (follower['meta']["code"] == 200) {
      if (follower['data'] != null) {
        follower['data'].forEach((element) {
          followingList.add(GetFollowingModel.fromJson(element));
        });
      }
    }

    isLoading = false;
    if (!isFromRoute) {
      update();
    }
    return followingList;
  }
}
