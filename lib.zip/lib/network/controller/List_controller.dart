import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/list_detail_model.dart';
import 'package:werfieapp/models/list_follower_add_model.dart';
import 'package:werfieapp/models/list_follower_model.dart';
import 'package:werfieapp/models/list_get_member_model.dart';
import 'package:werfieapp/models/list_model.dart';
import 'package:werfieapp/models/list_pin_unpin_model.dart';
import 'package:werfieapp/models/list_remove_member_unfollow_model.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/seach_suggestion_model.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../models/getListMemberModel.dart';
import '../../models/list_create_model.dart';
import '../../models/suggested_user_list_model.dart';
import '../../utils/debounce_search.dart';
import '../../web_views/web_main_screen.dart';
import 'guest_user_controller.dart';

class ListController extends GetxController {
  final DummyData dataController = Get.find<DummyData>();
  TextEditingController userNameController = TextEditingController();
  String createListId;
  String userName;
  String crateId;
  bool isSettingsScreen = false;
  var navRoute = "isListScreen";
  bool isFilterScreen = false;
  bool isTrendsScreen = false;
  bool isNewsFeedScreen = false;
  bool isBrowseScreen = false;
  bool isNotificationScreen = false;
  bool isWhoToFollowScreen = false;
  bool isSavedPostScreen = false;
  bool isChatScreen = false;
  bool isPostDetails = false;
  bool isFollwerScreen = false;
  bool isProfileScreen = false;
  bool isListScreen = true;
  bool isListDetailScreen = false;
  bool isButtonActive = true;
  TextEditingController descriptionController = TextEditingController();
  bool isSearch = false;
  var showLoading=false.obs;

  // Future<Uint8List> callGetImage() async {
  //   Uint8List image;
  //   var img = await dataController.getImage();
  //   image = await img.readAsBytes();
  //
  //   print('NAHI ATA IDHAR');
  //
  //   return image;
  // }

  ListController controller;

  // BrowseController controller1;
  bool searchField = false;
  bool isUserNameTaken = false;
  bool isUpdateProfile = false;
  TextEditingController searchTextController = TextEditingController();
  TextEditingController bioText = TextEditingController();
  TextEditingController usernameText = TextEditingController();
  UserProfile userProfile;

  //Tabs
  String selectedTab = "isTweets";
  String selectedView = "isProfile";
  bool isTweets = true;
  bool isTweetsReply = false;
  bool isMedia = false;
  bool isLikes = false;
  bool isFilter = true;
  var noSuggest;
  List<Post> userPosts = [];
  List<Post> tempUserPosts = [];
  int pinCheck = 0;
  bool isProfileUpdating = false;
  List<MemberGetModel> alreadyAddedMember = [];

  //Profile Dialog
  bool isProfile = false;
  Uint8List profileImage;
  bool isCover = false;
  Uint8List coverImage;
  String nameList;
  String descriptionList;

  bool isBio = false;
  bool isUsername = false;

  File imageSelected;
  String name = '';
  String description = '';
  String isChecked = '0';
  bool imageAvailable = false;
  bool isDelete = false;
  File pickedImage;

  File imageFile;

  // List <DiscoverListElement> listOfDiscover=[];
  ListModel listModel;

  // SuggesteduserListModel modelSuggest;
  List<SuggestUser> modelSuggestList = [];
  PinUnPinListModel pinUnPinListModel;
  FollowListModel followListModel;
  FollowListModel folowListModel;

  //Tabs
  // List dataList=[];

  final List dummyList = List.generate(3, (index) {
    return {
      "id": index,
      "title": "This is the title $index",
      "subtitle": "This is the subtitle $index"
    };
  });
  bool isNewsfeedLoading = false;
  final storage = GetStorage();

  Future<File> getImage1(Function onCallBack) async {
    try {
      final picker = ImagePicker();

      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        final imageTemporary = File(pickedFile.path);

        onCallBack();
        update();
        return imageTemporary;
      } else {
        return null;
      }
    } catch (e) {
      // print("errrrrrrrrrrrrrrrrrrrr$e");
    }
  }

  bool isLoading = false;
  List<Post> browsePostList = [];


  var userToken = "";

  bool isDiscoverLoading = false;
bool searchFilter=false;
  // TextEditingController searchText = TextEditingController();
  var newsfeedController = Get.find<NewsfeedController>();
  ListDetailModel selectedList;

  List<SuggestUser> addMemberList = [];
  GetListMembers getListMembers;
 List<GetMemberListData>  getMemberListData=[];
  bool isListMemberLoading=false;
  DiscoverListElement list;
  List<DiscoverListElement> setListMembers=[];
  int list_Id;

  int list_id;
  List<SearchSuggestion> searchResult = [];
  var api = Api();
bool listDetailsLoading=false;
  final delaySearch = DelayInSearch(milliseconds: 50);
  final newsFeedControloler = Get.find<NewsfeedController>();

  // crateId =selectedList.listDetail.id.toString();

  @override
  void onInit() async {
    // print("init      >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

    userToken = storage.read('token');
    isLoading = true;
    // newsfeedController.isTrendingLoading = true;
    update();
    await getListData();

    // newsfeedController.trendingList = await newsfeedController.getTrendings();
    // browsePostList = await newsFeedControloler.getBrowsePost();

    update(["discover"]);

    // if(listOfDiscover.isEmpty){
    //   listModel = await getListData();
    // }
    isLoading = false;
    update();

    super.onInit();
  }

  Uint8List image;
  var img;

  Future<Uint8List> callGetImage() async {
    img = await dataController.getImage();
    update();
    // print("image $img");
    image = await img.readAsBytes();
    // print('NAHI ATA IDHAR');
    // print("image $image");
    return image;
  }

  @override
  void onReady() async {


    browsePostList.forEach((element) {
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      if (element.isLiked == true) {
        element.like.value = true;
        element.like.refresh();
      }
    });

    update();

    super.onReady();
  }

  Future<void> getListData({bool isFromRoute = false}) async {
    // print("calling data >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
   showLoading(true);
    isDiscoverLoading = true;
    if (!isFromRoute) {
      update();
    }
    var response = await api.get(Uri.parse(Url.getList), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });

    // print(response);

    var jsonResponse = jsonDecode(response);
    if ( jsonResponse['meta']['code'] == 200){
      listModel = ListModel.fromJson(jsonResponse);

      if(listModel.data.lists.isNotEmpty){
        listModel.data.lists.forEach((element) {
          element.isPinRX.value=element.isPinValue;
        });
      }

      isDiscoverLoading = false;
      if (!isFromRoute) {
        update();
        newsfeedController.update();
      }
      showLoading(false);
      update();
    }
   else {
      isDiscoverLoading = false;
      showLoading(false);
      update();
    }
  }

  onSearchTextChanged(String text) async {
    searchResult.clear();
    if (text.isEmpty) {
      searchResult.clear();
      update();
      return;
    } else if (text.isNotEmpty && text.split(" ").join("") != "") {
      var response =
          await api.post(Uri.parse(Url.searchSuggestions), queryParameters: {
        'search_text': text.toString(),
      }, token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
      });
      searchResult.clear();
      update();
      var jsonResponse = jsonDecode(response);

      if (jsonResponse["meta"]["code"] == 200) {
        searchResult.clear();
        jsonResponse["data"].forEach((ele) {
          searchResult.add( SearchSuggestion.fromJson(ele));
        });
        // print('First name   ' + searchResult[0].firstname);

        update();
      }
    }
    // return jsonResponse['data']['post_counts']['simple_like_count'];
  }

  // Get already added members
  Future<List<MemberGetModel>> getAlreadyMembers({
    String list_Id,
  }) async {
    // print('First name   ' + list_Id.toString());

    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/get_members'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': list_Id,
        },
      ),
    );

    var parsedJson = jsonDecode(response.body);
    List<MemberGetModel> membersListModel = [];
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // print("response  ${response.body.toString()}");

      parsedJson["data"].forEach((element) {
        // print("inside response>>>>>>>>>>>>>>>>>>>>>>>>>>>>$element");
        membersListModel.add(MemberGetModel.fromJson(element));
        // print(" inside 2 response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        alreadyAddedMember.add(MemberGetModel.fromJson(element));
      });
      // print("after response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      // print(membersListModel.length);
      // print(alreadyAddedMember.length);
      // print("after response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      update();
      // controller.update();
      return membersListModel;
      // print("add member check data");
      // print("chech pin data");
      // var data = parsedJson['data'];
    } else {
      membersListModel = [];
      return membersListModel;
    }
  }

  // get follower
  Future<List<MemberGetModel>> getAlreadyFollower({
    String list_Id,
  }) async {
    print('First name   ' + list_Id.toString());

    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/get_followers'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': list_Id,
        },
      ),
    );

    var parsedJson = jsonDecode(response.body);
    List<MemberGetModel> membersListModel = [];

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // print("response  ${response.body.toString()}");

      parsedJson["data"].forEach((element) {
        // print("inside response>>>>>>>>>>>>>>>>>>>>>>>>>>>>$element");
        membersListModel.add(MemberGetModel.fromJson(element));
        // print(" inside 2 response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        alreadyAddedMember.add(MemberGetModel.fromJson(element));
      });
      // print("after response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      // print(membersListModel.length);
      // print(alreadyAddedMember.length);
      // print("after response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      update();
      // controller.update();
      return membersListModel;
      // print("add member check data");
      print("chech pin data");
      // var data = parsedJson['data'];
    } else {
      membersListModel = [];
      return membersListModel;
    }
  }

  var bodyData;

  Future<DataListCreated> createList(
      {String isChecked,
      String type,
      String listId,
      Uint8List CoverImageBytes,
      String nameList,
      String description}) async {
    print("coverImage  ${coverImage}");

    Map<String, String> upDateListData;

    if (type == 'create') {
      upDateListData = {
        'name': userNameController.text,
        'description': descriptionController.text,
        'make_private': isChecked
      };
    } else {
      upDateListData = {
        'name': userNameController.text,
        'description': descriptionController.text,
        'make_private': isChecked,
        'list_id': listId,
      };
    }

    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      "Access-Control-Allow-Origin": "*",
    };

    var request;

    request = http.MultipartRequest(
        'POST', Uri.parse(Url.baseUrl + 'list/create_update_list'));
    request.headers.addAll(headers);
    request.fields.addAll(upDateListData);

    if (coverImage != null) {
      request.files.add(http.MultipartFile.fromBytes('cover_image', coverImage,
          filename: "Name"));
    }

    var response = await request.send();
    final respStr = await response.stream.bytesToString();
    var jsonData = jsonDecode(respStr);

    if (response.statusCode == 200 && jsonData['meta']['code'] == 200) {
      DataListCreated modeldata = DataListCreated.fromJson(jsonData["data"]);
      DiscoverListElement dataList=DiscoverListElement.fromJson(jsonData["data"]);
      listModel.data.lists.add(dataList);

      print("list is created $jsonData");
      print("model hai yeeee${modeldata}");
      update();
      return modeldata;
    }
  }

  Future<dynamic> PinUnpinPost({String list_Id, String pin_unpin_list}) async {
    if (!isNewsfeedLoading) isNewsfeedLoading = false;
    // print(mediaData);
    print('data' +
        jsonEncode(
          {'list_id': list_Id, 'pin_unpin_list': pin_unpin_list},
        ).toString());
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/pin_unpin_list'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': list_Id, 'pin_unpin_list': pin_unpin_list},
      ),
    );
    print(userToken.toString());
    print("pinpost post by asad");

    print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // print("response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      // PinListData  pinListModel= PinListData.fromJson(parsedJson["data"]);
      // print("model hai yeeee${pinListModel.toString()}");
      // return  pinListModel;
      print("chech pin data");
      // var data = parsedJson['data'];
    }
  }

  Future<dynamic> deletePost(id) async {
    isDelete = true;
    update(["delete"]);
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/delete'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': id,
        },
      ),
    );

    var parsedJson = jsonDecode(response.body);
    print(response.body.toString());
    isDelete = false;
    update(["delete"]);

    /// move to the list screen

    onListChange = true;
    onSettingChange = false;
    onProfileChange = false;
    onChatsChange = false;
    onBookMarksChange = false;
    onTrendsChange = false;
    onHomeChange = false;

    onBrowsChange = false;
    onMoreChange = false;
    onNotificationChange = false;

    newsfeedController.isSearch = false;
    newsfeedController.isFilter = false;
    newsfeedController.isFilterScreen = false;
    newsfeedController.isTrendsScreen = false;
    newsfeedController.isNewsFeedScreen = false;
    newsfeedController.isTopWerfsScreen = false;
    newsfeedController.isBrowseScreen = false;
    newsfeedController.isNotificationScreen = false;
    newsfeedController.isWhoToFollowScreen = false;
    newsfeedController.isSavedPostScreen = false;
    newsfeedController.isChatScreen = false;
    newsfeedController.isPostDetails = false;
    newsfeedController.isFollwerScreen = false;
    newsfeedController.isProfileScreen = false;
    newsfeedController.isListScreen = true;
    newsfeedController.isListDetailScreen = false;
    newsfeedController.isTopicScreen = false;
    newsfeedController.isCommunitesScreen = false;
    newsfeedController.isOtherUserProfileScreen = false;
    newsfeedController.searchText.text = '';

    newsfeedController.isSettingsScreen = false;
    newsfeedController.navRoute = "isListScreen";
    newsfeedController.update();
    // controller.update();
    /*if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {


    }*/
  }

  Future<dynamic> SuggestedPost({String list_Id, String name}) async {
    if (!isNewsfeedLoading) isNewsfeedLoading = false;
    // print(mediaData);
    print('data' +
        jsonEncode(
          {'list_id': list_Id, 'name': name},
        ).toString());
    modelSuggestList = [];
    update(["suggestion"]);
    update([
      "edit_suggestion",
    ]);

    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/suggested_users'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': list_Id,
          'name': name
          //
        },
      ),
    );
    print(userToken.toString());
    print("pinpost post by asad");

    print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      print("response>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      // modelSuggest= SuggesteduserListModel.fromJson(parsedJson);
      modelSuggestList = [];
      parsedJson["data"].forEach((element) {
        modelSuggestList.add(SuggestUser.fromJson(element));
      });
      print("suggested model ki lenght");
      print("length of model${modelSuggestList.length}");
      // print("model hai yeeee${modelSuggest.toString()}");
      searchFilter=true;
      update(["suggestion"]);
      update(["edit_suggestion"]);
      update();

      return modelSuggestList;
      print("chech pin data");
      // var data = parsedJson['data'];
    } else if (parsedJson['meta']['code'] == 400) {
      noSuggest = parsedJson['meta']['message'];
      print("no Suggested  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
      print(noSuggest.toString());
      searchFilter=true;
      update();
      // return noSuggest;
      return modelSuggestList; // When there is no suggestion, returning a string to the list will give error. So, returning the suggestion we already have.
    }
  }

  //List Detail
  Future<ListDetailModel> listDetail({int listId, isFromRoute = false,int clickId}) async {
    //print('list details print');
    listDetailsLoading = true;
    update();
    if (!isFromRoute) {
      update();
    }
    //debugPrint('list id ---->>>> ${listId}');
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/get_list'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': listId,
          'page_no': 1,
        },
      ),
    );
    //print("pinpost post by asad");

    //print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      selectedList = ListDetailModel.fromJson(parsedJson["data"]);
      //print('got data');
      //print("data is here ${selectedList.newsfeed}");

      if(kIsWeb){
        await getListData(isFromRoute: isFromRoute);
      }


if(clickId==1){
  listModel.data.pinnedLists.forEach((element) {
    if (element.id == selectedList.listDetail.id) {
      list = element;
    }
  });
}
else if (clickId==2){
  listModel.data.discoverLists.forEach((element) {
    if (element.id == selectedList.listDetail.id) {
      list = element;
    }
  });
}
else if (clickId==3){
  listModel.data.lists.forEach((element) {
    if (element.id == selectedList.listDetail.id) {
      list = element;
    }
  });
}
else if(clickId==4){

  if(setListMembers!=[]){

    setListMembers.forEach((element) {

      if (element.id == selectedList.listDetail.id){
        print('match id list');

        print(element.name);
        list=element;

        print(list.name);


      }
    });
  }
}


      selectedList.newsfeed.forEach((element) {
        newsfeedController.threadNumber = element.thread_no;

        element.rebuzz.value = element.isRetweeted;
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
      });

  //   controller.update();
      if (!isFromRoute) {
        update();
        newsfeedController.update();
      }
      listDetailsLoading = false;
      update();
      return selectedList;
      // var data = parsedJson['data'];
    } else {
      listDetailsLoading = false;
      update();
    }
  }

  // on Remove Member List ...........Suggestion list

  Future<FollowerListModel> unFollowRemoveMethod(
      {String member_id, String list_Id, type}) async {
    print(member_id.toString() + "member_id");
    print(list_Id.toString() + "list_Id");
    print(type.toString() + "type");

    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/remove_member_un_follow'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': list_Id, 'member_id': member_id, 'type': type},
      ),
    );
    print("pinpost post by asad");

    print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // FollowerListModel modeldata= FollowerListModel.fromJson(parsedJson["data"]);
      //
      // return  modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  // on unFollow List ...........Discover list

  Future<FollowerListModel> unFollowMember({String list_Id, type}) async {
    print(list_Id.toString() + "list_Id");
    print(type.toString() + "type");

    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/remove_member_un_follow'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': list_Id, 'type': type},
      ),
    );
    print("pinpost post by asad");

    print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // FollowerListModel modeldata= FollowerListModel.fromJson(parsedJson["data"]);
      //
      // return  modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  // on aaember List ...........Suggestion list
  Future<void> memberAdd(String listId, memberId, type) async {
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/add_member_followers'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': listId, 'member_id': memberId, 'type': type},
      ),
    );
    print("pinpost post by asad");

    print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // AddMemberListModel modeldata= AddMemberListModel.fromJson(parsedJson["data"]);
      //
      // return  modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  Future<FollowerListModel> AddMemberList(listId) async {
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/get_followers'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'list_id': listId,
        },
      ),
    );
    // print("pinpost post by asad");

    // print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      FollowerListModel modeldata =
          FollowerListModel.fromJson(parsedJson["data"]);

      return modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  // on Follow List ...........Discover list
  Future<FollowListModel> OnFollow({
    String listId,
    String type,
  }) async {
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/add_member_followers'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': listId, 'type': type},
      ),
    );
    // print("pinpost post by asad");

    // print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // FollowListModel modeldata= FollowListModel.fromJson(parsedJson["data"]);
      //
      // return  modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  Future<RemoveUnfollowModel> removeMember(
      String listId, memberId, type) async {
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'list/add_member_followers'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'list_id': listId, 'member_id': memberId, 'type': "member"},
      ),
    );
    // print("pinpost post by asad");

    // print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // RemoveUnfollowModel modeldata= RemoveUnfollowModel.fromJson(parsedJson["data"]);
      //
      // return  modeldata;
      // var data = parsedJson['data'];
    } else {}
  }

  Future<List<GetMemberListData>> getMemberListDataApi({bool isFromRoute = false}) async {
    // print("calling data >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

    isListMemberLoading = true;

    update();
    var response = await api.get(Uri.parse(Url.getMemberList), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });

    // print(response);

    var jsonResponse = jsonDecode(response);
    if ( jsonResponse['meta']['code'] != 200){
// print('get member list data $jsonResponse');
// print('Get member list data is empty');

isListMemberLoading = false;

update();
return null;

    }
    else {
      if( jsonResponse['meta']['code'] == 200) {

        var getListData = jsonResponse['data'] as List;
        getMemberListData =
            getListData.map((e) => GetMemberListData.fromJson(e)).toList();
        setListMembers =
            getListData.map((e) => DiscoverListElement.fromJson(e)).toList();

        isListMemberLoading = false;


        update();
        return getMemberListData;
      }
    }
  }
}
