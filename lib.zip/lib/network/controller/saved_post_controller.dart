import 'dart:developer';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';

class SavedPostController extends GetxController {
  final NewsfeedController newsfeedController;

  SavedPostController({this.newsfeedController});

  bool isLoading = false;
  List<Post> savedPostList = [];
  final storage = GetStorage();
  var userToken = "";

  final newsFeedControloler = Get.find<NewsfeedController>();
  bool isInternetConnected;

  @override
  void onInit() async {
    // print("initialize");
    userToken = storage.read('token');
    if(!kIsWeb)
    {
      // print("asdasd");
      isLoading = true;
      update();
      savedPostList = [];
      savedPostList = await newsFeedControloler.getSavedPost();

      if (savedPostList.isEmpty) {
        isLoading = false;
        update();
      }

      savedPostList.forEach((element) {
        newsFeedControloler.threadNumber = element.thread_no;
        element.rebuzz.value = element.isRetweeted;
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;

        // element.comments.forEach((element) {
        //     element.reactionType.value = element.isLiked;
        //     element.commentCount.value = element.simpleLikeCount;
        // });

        element.reactionType.refresh();
      });
      isLoading = false;
      update();
      newsFeedControloler.update();


    }

    super.onInit();
  }

  // void showSavedPost() async {
  //     if (!kIsWeb) {
  //         var savedPostData = await DatabaseHelper.instance
  //             .queryAllRows(DatabaseHelper.savedPostTable);
  //         // print('Saved post Data >>>. $savedPostData');
  //         print('Saved post Data >>>. ${savedPostData.length}');
  //         savedPostData.forEach((element) {
  //             print('Saved post element >>>. ${element}');
  //
  //             var data = Post.fromLocalDbJson(element);
  //             savedPostList.add(data);
  //         });
  //         savedPostList = new List.from(savedPostList.reversed);
  //         savedPostList.forEach((element) {
  //             element.likeCount.value = element.simpleLikeCount;
  //             element.rebuzzCount.value = element.retweetCount;
  //             element.commentCount.value = element.commentsCount;
  //             if (element.isLiked == true) {
  //                 element.like.value = true;
  //                 element.like.refresh();
  //             }
  //         });
  //         update();
  //         return;
  //     }
  // }

  @override
  onReady() async {




    if(kIsWeb)
      {

        // print("asdasd");
        // if(isInternetConnected){
        isLoading = true;
        update();
        savedPostList = [];
        savedPostList = await newsFeedControloler.getSavedPost();

        if (savedPostList.isEmpty) {
          isLoading = false;
          update();
        }

        savedPostList.forEach((element) {
          newsFeedControloler.threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //     element.reactionType.value = element.isLiked;
          //     element.commentCount.value = element.simpleLikeCount;
          // });

          element.reactionType.refresh();
        });
        isLoading = false;
        update();
        newsFeedControloler.update();


      }




    // }
// else{
//     if(!isInternetConnected)showSavedPost();
// }
  }

  @override
  void dispose() {
    // print("dispose");
    // TODO: implement dispose
    super.dispose();
  }

  @override
  onClose() {
    // print("close");
    super.onClose();
  }

  Future<void> removePost(postId) async {
    // print("clicked method start");
    isLoading = true;
    update();

    LoginController authController = LoginController();
    var resBody;
    resBody = await authController.removeSavedPost(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": userToken.toString(),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "saved_item_id": postId.toString(),
    });
    print(resBody);

    if (resBody["data"].runtimeType.toString() != "_JsonMap") {}
    savedPostList = await newsFeedControloler.getSavedPost();
    update();
    isLoading = false;
    update();
  }
}
