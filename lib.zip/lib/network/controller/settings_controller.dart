import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/create_update_mute_word_model.dart';
import 'package:werfieapp/models/mute_word_list_model.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../models/mute_user_model.dart';
import '../../models/privacy_safety_model/privacy_safety_model.dart';
import 'login_controller.dart';
import 'news_feed_controller.dart';

class SettingController extends GetxController {
  TextEditingController newPasswordTxt = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  TextEditingController currentPassword = TextEditingController();
  final storage = GetStorage();

  final newsfeedController = Get.find<NewsfeedController>();

  LoginController signupController = Get.find<LoginController>();

  String currentEmail;
  bool passwordValidator = false;

  bool isPhotoTagging = false;


  bool isHomeTimeLine = true;


  bool isDisplayMediaThatMayContainSensitiveContent = false;




  bool isMarkMediaYouWerfAsHavingMaterialThatMayBeSensitive =  false;


  bool isLoading = false;


  bool wordNotification = true;

  bool isProtectYourTweets= false;


  bool isFilterLowQualityMessages= false;

  bool isShowReadReceipts= false;

  bool isExploreSettingPersonalization= false;

  bool isShowContentInThisLocation = true;


  bool isSearchSettingHideSensitiveContent = true;

  bool isSearchSettingRemoveBlockedAccounts = true;




  bool isAddLocationInformationToYourWerfs = false;


  String action = "insert";

   String countryName = "";

  bool isAnyoneCanTagYou = true;


  bool isForever = false;
  bool is24Hours = false;
  bool is7days = false;
  bool is30days = false;

  int muteWordId=0;

  TextEditingController addMuteWordController= TextEditingController();




  bool isFromAnyone = true;
  bool isFromPeopleYouDontFollow = false;

  bool isOnlyPeopleYouFollowCanTagYou = false;


  bool isAllowMessagesOnlyFromPeopleYouFollow = false;
  bool isAllowMessageRequestsOnlyFromVerifiedUsers = false;
  bool isAllowMessagesRequestsFromEveryone = false;


  bool isCountryScreen= false;


  PrivacyAndSafetyModel privacyAndSafety = PrivacyAndSafetyModel();

  CreateMuteWord createMuteWord = CreateMuteWord();



  @override
  Future<void> onInit() async {


    currentEmail = await storage.read('CurrentEmail');

    super.onInit();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  Future<int> verifyPassword(int userId, String password) async {
    // print("country user id ${userId}");

    var response = await http.post(
      Uri.parse(Url.verifyPassword),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'user_id': userId,
          'current_password': password,
        },
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 && jsonResponse["meta"]["code"] == 200) {
      passwordValidator = false;
      update();
      return 1;
    } else {
      if (password.isEmpty) {
        passwordValidator = false;
        update();
      } else {
        passwordValidator = true;
        update();
      }

      return 2;
    }
  }

  Future<int> sendVerification(String email) async {
    // print("email ${email}");

    int responseCode = await signupController.forgotPassword(queryParameters: {
      "email": email,
      "reset_password": "1"
    }, token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "X-Requested-With": "XMLHttpRequest"
    });

    if (responseCode == 200) {
      return 1;
    } else {
      return 2;
    }
  }

  Future<int> Verification(String email) async {
    // print("code ${code}");
    // print("newPasswordTxt.text ${newPasswordTxt.text}");
    // print("confirmPassword.text ${confirmPassword.text}");

    int responseCode = await signupController.renewPassword(queryParameters: {
      "email": email.toString(),
      "password": newPasswordTxt.text,
      "password_confirmation": confirmPassword.text
    }, token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "X-Requested-With": "XMLHttpRequest"
    });

    if (responseCode == 200) {
      return 1;
    } else {
      return 2;
    }
  }


  Future<dynamic> privacyAndSafetyApi({String action, int protectWerfs,
  int allowPhotoTagging,
  String whoCanPhotoTagYou,
  int markMediaSensitive,
  int addLocationToWerfs,
  int displaySensitiveContentMedia,
  int exploreSettingsLocation,
  int exploreSettingsPersonalization,
  int searchSettingsHideSensitiveContent,
  int searchSettingsRemoveBlockedAccounts,
  String directMessages,
  int filterLowQualityMessages,
  int showReadReceipts,
  int spacesSettingAllowFollowers,
  int discoverSettingsEmail,
  int discoverSettingsPhone,
  int personalizedAdsSwitch,
  int inferredIdentitySwitch,
  int shareDataWithBusinessPartners,
  int locationInfoYouHaveBeen

  }) async {


    // print("protectWerfs ${protectWerfs}");




    isLoading = true;
    update();



    var response = await http.post(
      Uri.parse(Url.privacyAndSafety),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },


          body: action=="read"?
          jsonEncode(
                {
                  'action': action,
                },
              ):
          action=="update"?
          jsonEncode(
            {
              "action":action,
              "protect_werfs": protectWerfs,
              "allow_photo_tagging": allowPhotoTagging,
              "who_can_photo_tag_you": whoCanPhotoTagYou,
              "mark_media_sensitive":  markMediaSensitive,
              "add_location_to_werfs": addLocationToWerfs,
              "display_sensitive_content_media": displaySensitiveContentMedia,
              "explore_settings_location":  exploreSettingsLocation,
              "explore_settings_personalization": exploreSettingsPersonalization,
              "search_settings_hide_sensitive_content": searchSettingsHideSensitiveContent,
              "search_settings_remove_blocked_accounts": searchSettingsRemoveBlockedAccounts,
              "direct_messages":  directMessages,
              "filter_low_quality_messages": filterLowQualityMessages,
              "show_read_receipts": showReadReceipts,
              "spaces_setting_allow_followers": spacesSettingAllowFollowers,
              "discover_settings_email": discoverSettingsEmail,
              "discover_settings_phone": discoverSettingsPhone,
              "personalized_ads_switch": personalizedAdsSwitch,
              "inferred_identity_switch": inferredIdentitySwitch,
              "share_data_with_business_partners": shareDataWithBusinessPartners,
              "location_info_you_have_been": locationInfoYouHaveBeen,
            },
          ):{



          }



    );


    // print("response privacy and safety: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {

      privacyAndSafety = PrivacyAndSafetyModel.fromJson(parsedJson);

      isProtectYourTweets = privacyAndSafety.data.protectWerfs ==0?false:true;
      isPhotoTagging  = privacyAndSafety.data.allowPhotoTagging ==0?false:true;


      isExploreSettingPersonalization = privacyAndSafety.data.exploreSettingsPersonalization  ==0?false:true;
      isMarkMediaYouWerfAsHavingMaterialThatMayBeSensitive = privacyAndSafety.data.markMediaSensitive  ==0?false:true;


      isFilterLowQualityMessages= privacyAndSafety.data.filterLowQualityMessages  ==0?false:true;

      isShowReadReceipts= privacyAndSafety.data.showReadReceipts  ==0?false:true;

      isSearchSettingHideSensitiveContent = privacyAndSafety.data.searchSettingsHideSensitiveContent ==0?false:true;
      isSearchSettingRemoveBlockedAccounts = privacyAndSafety.data.searchSettingsRemoveBlockedAccounts==0?false:true;

      isShowContentInThisLocation = privacyAndSafety.data.exploreSettingsLocation==0?false:true;
      isDisplayMediaThatMayContainSensitiveContent = privacyAndSafety.data.displaySensitiveContentMedia  ==0?false:true;
      isAddLocationInformationToYourWerfs = privacyAndSafety.data.addLocationToWerfs  ==0?false:true;
      isAnyoneCanTagYou = privacyAndSafety.data.whoCanPhotoTagYou =="anyone"?true:false;
      isOnlyPeopleYouFollowCanTagYou = privacyAndSafety.data.whoCanPhotoTagYou=="who_follows_you"?true:false;

       isAllowMessagesOnlyFromPeopleYouFollow = privacyAndSafety.data.directMessages=="people_you_follow"? true:false;
      isAllowMessageRequestsOnlyFromVerifiedUsers = privacyAndSafety.data.directMessages=="message_requests_from_verified"? true:false;
       isAllowMessagesRequestsFromEveryone = privacyAndSafety.data.directMessages=="from_everyone"? true:false;


      isLoading = false;
      update();

    }
    else{
      isLoading = false;
      update();
    }
  }


  MuteUser muteUserList;

  MuteWordListModel muteWordList;


  Future<dynamic> removeLocationApi() async {
    isLoading = true;
    update();
    var response = await http.post(
        Uri.parse(Url.removeLocation),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': newsfeedController.userToken.toString(),
          'X-Requested-With': 'XMLHttpRequest',
        },
    );


    // print("response remove location: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {

      isLoading = false;
      update();

    }
    else{
      isLoading = false;
      update();
    }
  }


  void getMuteUsersList() async {

    try {
      isLoading = true;
      update();
      var response = await newsfeedController.api.post(
        Uri.parse(Url.muteUsersList),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );

      //print("mute api response $response");
      var muteUsersData = json.decode(response);
      if (muteUsersData['meta']['code'] == 200) {
        muteUserList = MuteUser.fromJson(muteUsersData);
        isLoading = false;
        update();
      } else {
        isLoading = false;
        update();
      }
    }catch(e){
      isLoading = false;
      muteUserList = null;
      update();
    }
  }


  Future<String> unMuteWord({ int muteWordID}) async {
    // print("idhr aya hai ");

    var response = await http.post(
      Uri.parse(Url.unMuteWord),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'muted_word_id': muteWordID
        },
      ),
    );

    // print("response unmute word  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      String data = parsedJson['meta']["message"];
      // print("data message  $data");
      return data;
    } else {
      return null;
    }
  }

  void getMuteWordsList() async {

    isLoading =true;
    update();
    var response = await newsfeedController.api.post(
      Uri.parse(Url.muteWordsList),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );

    // print("mute word api response ${response}");
    var muteWordsData = json.decode(response);
    if (muteWordsData['meta']['code'] == 200) {
      muteWordList  =  MuteWordListModel.fromJson(muteWordsData);
      isLoading =false;
      update();

    } else {

      muteWordList = null;
      isLoading =false;
      update();




    }
  }



  Future<dynamic> createAndMuteWordApi({

    String action,
    int id,
    String word,
    String muteFromHome,
    String notificationSwitch,
    String notificationValue,
    String muteDuration,
  }) async {

    isLoading = true;
    update();



    var response = await http.post(
        Uri.parse(Url.addMuteWord),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': newsfeedController.userToken.toString(),
          'X-Requested-With': 'XMLHttpRequest',
        },


        body: action=="insert"?
        jsonEncode(
          {
            'action': action,
            "word": word,
            "mute_from_home": muteFromHome,
            "notification_switch":notificationSwitch,
            "notification_value": notificationValue,
            "mute_duration": muteDuration,
          },
        ):
        action=="update"?
        jsonEncode(
          {
            'action': action,
            "word": word,
            "mute_from_home": muteFromHome,
            "notification_switch":notificationSwitch,
            "notification_value": notificationValue,
            "mute_duration": muteDuration,
            "mute_word_id":id,
          },
        ):{



        }



    );


    // print("response createMuteWord: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      createMuteWord = CreateMuteWord.fromJson(parsedJson);
      isLoading = false;
      update();

    }
    else{
      isLoading = false;
      update();
    }
  }








}
