import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/list_detail_model.dart';
import 'package:werfieapp/models/list_follower_model.dart';
import 'package:werfieapp/models/list_get_member_model.dart';
import 'package:werfieapp/models/list_model.dart';
import 'package:werfieapp/models/list_pin_unpin_model.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/seach_suggestion_model.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../models/suggested_user_list_model.dart';
import '../../utils/debounce_search.dart';

class BrowseController extends GetxController {
  final DummyData dataController = Get.find<DummyData>();
  TextEditingController userNameController = TextEditingController();
  String createListId;
  String userName;
  String crateId;
  SearchSuggestion searchSelected;
  bool isSettingsScreen = false;
  bool isSearchLoading=false;
  var navRoute = "isListScreen";
  bool isFilterScreen = false;
  bool isTrendsScreen = false;
  bool isNewsFeedScreen = false;
  bool isBrowseScreen = false;
  bool isNotificationScreen = false;
  bool isWhoToFollowScreen = false;
  bool isSavedPostScreen = false;
  bool isChatScreen = false;
  bool isPostDetails = false;
  bool isFollwerScreen = false;
  bool isProfileScreen = false;
  bool isListScreen = true;
  bool isListDetailScreen = false;
  bool isButtonActive = true;
  TextEditingController descriptionController = TextEditingController();
  bool isSearch = false;

  bool isTrendingTab = true;
  bool isSuggestedTab = false;
  bool isTopicTab = false;
  bool isMusicTab = false;
  bool isTravelTab = false;
  bool isSearchTab = false;
  bool trendingShowWidget = false;
  bool UserLoading = false;

  /// show the search from api
  bool searchFilter = false;

  /// show the search post in veiw
  bool searchPostsView = false;

  // Color mainThemeButton;
  Future<Uint8List> callGetImage() async {
    Uint8List image;
    var img = await dataController.getImage();
    image = await img.readAsBytes();

    // print('NAHI ATA IDHAR');

    return image;
  }

  BrowseController controller;
  bool searchField = false;
  bool isUserNameTaken = false;
  bool isUpdateProfile = false;
  TextEditingController searchText = TextEditingController();
  TextEditingController bioText = TextEditingController();
  TextEditingController usernameText = TextEditingController();
  UserProfile userProfile;

  //Tabs
  String selectedTab = "isTweets";
  String selectedView = "isProfile";
  bool isTweets = true;
  bool isTweetsReply = false;
  bool isMedia = false;
  bool isLikes = false;
  bool isFilter = true;
  var noSuggest;
  List<Post> userPosts = [];
  List<Post> tempUserPosts = [];
  int pinCheck = 0;
  bool isProfileUpdating = false;
  List<MemberGetModel> alreadyAddedMember = [];

  //Profile Dialog
  bool isProfile = false;
  Uint8List profileImage;
  bool isCover = false;
  Uint8List coverImage;
  bool isBio = false;
  bool isUsername = false;

  File imageSelected;
  String name = '';
  String description = '';
  String isChecked = '0';
  bool imageAvailable = false;
  bool isDelete = false;
  File pickedImage;

  File imageFile;

  // List <DiscoverListElement> listOfDiscover=[];
  ListModel listModel;

  // SuggesteduserListModel modelSuggest;
  List<SuggestUser> modelSuggestList = [];
  PinUnPinListModel pinUnPinListModel;
  FollowListModel followListModel;
  FollowListModel folowListModel;
  List<Post> browseList = [];
  final delaySearch = DelayInSearch(milliseconds: 50);
  //Tabs
  // List dataList=[];

  final List dummyList = List.generate(3, (index) {
    return {
      "id": index,
      "title": "This is the title $index",
      "subtitle": "This is the subtitle $index"
    };
  });
  bool isNewsfeedLoading = false;
  final storage = GetStorage();

  // final picker = ImagePicker();
  // Future getImage() async {
  //   final image=await ImagePicker().pickImage(source: ImageSource.gallery);
  //   if(image==null)return;
  //   final imageTemporary=File(image.path);
  //   imageSelected=imageTemporary;
  //   update();
  // }

  // bool isChecked = false;
  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.red;
  }

  Future<File> getImage1(Function onCallBack) async {
    try {
      final picker = ImagePicker();

      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        final imageTemporary = File(pickedFile.path);

        onCallBack();
        update();
        return imageTemporary;
      } else {
        return null;
      }
    } catch (e) {
      // print("errrrrrrrrrrrrrrrrrrrr$e");
    }
  }

  bool isLoading = false;
  List<Post> browsePostList = [];
  List<Post> topicList = [];

  var userToken = "";

  bool isDiscoverLoading = false;

  // TextEditingController searchText = TextEditingController();
  var newsfeedController = Get.find<NewsfeedController>();
  ListDetailModel selectedList;

  List<SuggestUser> addMemberList = [];

  DiscoverListElement list;
  int list_Id;

  int list_id;
  List<SearchSuggestion> searchResult = [];
  var api = Api();

  // crateId =selectedList.listDetail.id.toString();
// mainThemeButton=storage.read("themeButton")==null?Colorss.yellow:storage.read("themeButton");
  @override
  void onInit() async {
    // print("init      >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

    // update();
    //  await getListData();

    trendingTab();
    // controller.update();

    // update(["discover"]);

    // if(listOfDiscover.isEmpty){
    //   listModel = await getListData();
    // }
    // update();

    super.onInit();
  }

  ///tab controller

  trendingTab() async {
    userToken = storage.read('token');
    newsfeedController.isTrendingLoading = true;
    isTrendingTab = true;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = true;
    searchFilter = false;
    searchPostsView = false;
    newsfeedController.trendingList = await newsfeedController.getTrendings();
    isLoading = true;
    browsePostList = await getBrowsePost();
    // await getGuestUserTrendsData();
    update();
    // await getGuestUserTopicsData(1);
  }

  newsAndSocialTabs() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = true;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    isLoading = true;
    update();
    await getTopicPostPaged(topicId: 2, page: 1);
    //await getGuestUserTopicsData(2);
  }

  filmsTvTabs() async {
    isTrendingTab = false;
    isSuggestedTab = true;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    isLoading = true;
    update();
    await getTopicPostPaged(topicId: 3, page: 1);
    // await getGuestUserTopicsData(3);
  }

  musicTab() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = true;
    isTravelTab = false;
    isSearchTab = false;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    isLoading = true;
    update();
    await getTopicPostPaged(topicId: 6, page: 1);
    // await getGuestUserTopicsData(6);
  }

  travelTab() async {
    isTrendingTab = false;
    isSuggestedTab = false;
    isTopicTab = false;
    isMusicTab = false;
    isTravelTab = true;
    trendingShowWidget = false;
    searchFilter = false;
    searchPostsView = false;
    isLoading = true;
    update();
    await getTopicPostPaged(topicId: 5, page: 1);
    // await getGuestUserTopicsData(5);
  }

  getBrowsePost() async {
    List<Post> list = [];
    browsePostList = [];
    String getResponse = await api.get(
      Uri.parse(Url.getBrowsePostUrl),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );

    final response = jsonDecode(getResponse);
    isLoading = false;
    if (response["meta"]["code"] == 200) {
      response["data"].forEach((element) {
        browsePostList.add(Post.fromJson(element));
      });
      update();
    }

    browsePostList.forEach((element) {
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      // element.comments.forEach((element) {
      //   element.reactionType.value = element.isLiked;
      //   element.commentCount.value = element.simpleLikeCount;
      // });

      element.reactionType.refresh();
    });
    update();

    return browsePostList;
  }

  Future<List<Post>> getTopicPostPaged({int topicId, int page}) async {
    try {
      // controller.isLoading = true;
      // update();
      // print("btopicid ${topicId}");
      // print("bpageid ${page}");

      String getResponse = await api.get(
        Uri.parse(Url.getTopicPostUrl +
            '?topicID=' +
            topicId.toString() +
            "&pageID=" +
            page.toString()),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      final response = jsonDecode(getResponse);

      if (response['meta']["code"] == 200) {
        if (response['data'] != null) {
          var postData = response['data'] as List;

          if (page == 1) {
            topicList = [];

            response["data"].forEach((element) {
              topicList.add(Post.fromJson(element));
            });

            topicList.forEach((element) {
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;

              element.reactionType.refresh();
            });
            isLoading = false;
            update();
          } else if (page != 1) {
            // print(topicList.length);
            // print("dsasdasdawerwerwerwervsdfs");
            List<Post> postList3 =
                postData.map((e) => Post.fromJson(e)).toList();
            topicList.addAll(postList3);

            print(topicList[10].body);

            topicList.forEach((element) {
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;
              // element.comments.forEach((element) {
              //   element.reactionType.value = element.isLiked;
              //   element.commentCount.value = element.simpleLikeCount;
              // });

              element.reactionType.refresh();
            });
            isLoading = false;

            update();
          } else {
            isLoading = false;
            return [];
          }
        }
      } else {
        isLoading = false;
        return [];
      }
    } catch (_) {}

    update();
    isLoading = false;
    return topicList;
  }

  Future<List<Post>> getBrowsePostPaged({int page}) async {
    try {
      /* if (page == 1 || page == null) {
        return browseList = [];
      }*/
      String getResponse = await api.get(
        Uri.parse(Url.getBrowsePostUrl + '?page_no=' + page.toString()),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      final response = jsonDecode(getResponse);

      if (response['meta']["code"] == 200) {
        if (response['data'] != null) {
          var postData = response['data'] as List;
          if (page != 1) {
            List<Post> postList3 =
                postData.map((e) => Post.fromJson(e)).toList();
            browsePostList.addAll(postList3);
            browsePostList.forEach((element) {
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;
              // element.comments.forEach((element) {
              //   element.reactionType.value = element.isLiked;
              //   element.commentCount.value = element.simpleLikeCount;
              // });

              element.reactionType.refresh();
            });
            update();
          }
        }
      }
    } catch (_) {}

    update();

    return browsePostList;
  }

  @override
  void onReady() async {
    // print("ready      >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
    update();
    browsePostList.forEach((element) {
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      if (element.isLiked == true) {
        element.like.value = true;
        element.like.refresh();
      }
    });
    update();
    super.onReady();
  }

  onSearchTextChanged(String text) async {
    isSearchLoading=true;
    searchResult.clear();
    print(text);

    if (text.isEmpty) {
      searchResult.clear();
      searchResult = [];
      isSearchLoading=false;
      update();
      return ;
    }
    else if (text.isNotEmpty && text.split(" ").join("") != "") {
      isSearchLoading=true;
      var response =
          await api.post(Uri.parse(Url.searchSuggestions), queryParameters: {
        'search_text': text.toString(),
      }, token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
      });
      // searchResult.clear();
      // update();
      var jsonResponse = jsonDecode(response);

      if (jsonResponse["meta"]["code"] == 200) {
        List searchMapData = jsonResponse["data"];
        searchResult.clear();
        searchResult = [];
        searchResult  = searchMapData.map((searchMapData) => SearchSuggestion.fromJson(searchMapData)).toList();
      //   jsonResponse["data"].forEach((ele) {
      //     searchResult.addAll(ele);
      //     searchResult.insert(0, SearchSuggestion.fromJson(ele));
      //   });
        // print('First name   ' + searchResult[0].firstname);
        isSearchLoading=false;
        update();

      }
    }

  }
}
