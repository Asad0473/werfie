import 'dart:convert';

// import 'package:web_scraper/web_scraper.dart';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/state_manager.dart';
import 'package:get_storage/get_storage.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:werfieapp/models/GetCountriesResponse.dart' as cr;
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/utils/app_languages.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/video_call/utilities/video_call_utilities.dart';

import '../../notification/app_notification.dart';
import 'news_feed_controller.dart';

class LoginController extends GetxController {
  // var formKey ;

  String selectedMonth = "";
  String selectedDay = "";
  String selectedYear = "";
  AppLanguage selectedLanguage;
  var isShowWelcomeMsg=false.obs;
  var isLoginWithPoshDialogShown=false.obs;


  List<AppLanguage> languageList=[
    AppLanguage(
    id: 1,
    name: 'English',
    code:'en'
    ),AppLanguage(
    id: 2,
    name: 'Arabic',
    code:'ar'
    ),AppLanguage(
    id: 3,
    name: 'French',
    code:'fr'
    ),AppLanguage(
    id: 4,
    name: 'German',
    code:'de'
    ),AppLanguage(
    id: 5,
    name: 'Italian',
    code:'it'
    ),

    AppLanguage(
    id: 9,
    name: 'Hindi',
    code:'hi'
    ),
  ];



  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List<int> years = [
    2022,
    2021,
    2020,
    2019,
    2018,
    2017,
    2016,
    2015,
    2014,
    2013,
    2012,
    2011,
    2010,
    2009,
    2008,
    2007,
    2006,
    2005,
    2004,
    2003,
    2002,
    2001,
    2000,
    1999,
    1998,
    1997,
    1996,
    1995,
    1994,
    1993,
    1992,
    1991,
    1990,
    1989,
    1988,
    1987,
    1986,
    1985,
    1984,
    1983,
    1982,
    1981,
    1980,
    1979,
    1978,
    1977,
    1976,
    1975,
    1974,
    1973,
    1972,
    1971,
    1970,
    1969,
    1968,
    1967,
    1966,
    1965,
    1964,
    1963,
    1962,
    1961,
    1960,
    1959,
    1958,
    1957,
    1956,
    1955,
    1954,
    1953,
    1952,
    1951,
    1950,
    1949,
    1948,
    1947,
    1946,
    1945,
    1944,
    1943,
    1942,
    1941,
    1940,
    1939,
    1938,
    1937,
    1936,
    1935,
    1934,
    1933,
    1932,
    1931,
    1930,
    1929,
    1928,
    1927,
    1926,
    1925,
    1924,
    1923,
    1922,
    1921,
    1920,
    1919,
    1918,
    1917,
    1916,
    1915,
    1914,
    1913,
    1912,
    1911,
    1910,
    1909,
    1908,
    1907,
    1906,
    1905,
    1904,
    1903,
    1902,
    1901,
    1900,
  ];
  String dobSelected = "";


  void updateInitialWelcomeMsg(bool value){
    // debugPrint('Initial Msg Called');
    isShowWelcomeMsg(value);
    // update();
  }
  String functionStoreDate() {
    dobSelected =
        "${selectedMonth + " " + selectedDay + "," + " " + selectedYear}";
    update();
    return dobSelected;
  }

  var TermsFocusNode = FocusNode();
  var PrivacyFocusNode = FocusNode();
  var LoginFocusNode = FocusNode();
  var CheckBoxFocusNode = FocusNode();
  var focus1 = FocusNode();
  var focus2 = FocusNode();
  var focus3 = FocusNode();
  var focus4 = FocusNode();
  var focus5 = FocusNode();
  var focus6 = FocusNode();
  var focus7 = FocusNode();
  var focus8 = FocusNode();
  var focus9 = FocusNode();
  var confirmPassNode = FocusNode();
  var SignUpFocusNode = FocusNode();
  bool isLoggedIn = false;

  RxBool termAndPrivacyCheck = false.obs;
  RxBool checkBoxColor = false.obs;
  RxBool countrySelectColor = false.obs;
  TapGestureRecognizer tapGestureRecognizer;

  static final formKey = GlobalKey<FormState>();
  String postId;
  String profileId;
  String code;

  LoginController({this.postId, this.profileId});

  bool showSignUpForm = false;
  bool showRegistrationSuccessful = false;
  var isChecked = false;
  Api api = Api();
  var storage = GetStorage();

  TextEditingController email = TextEditingController(
      // text: storage.read("email") != null ? storage.read("email") : ""
      );
  TextEditingController password = TextEditingController(
      // text: storage.read("password") != null ? storage.read("email") : ""
      );
  ModalRoute mountRoute;


  @override
  void onInit() async {
    initRecognizer() {
      tapGestureRecognizer = TapGestureRecognizer();
      tapGestureRecognizer.onTapUp = (_) {};
    }

    _initPackageInfo();
    list = await getCountries();
    getDeviceLanguage();

    // print("list country ${list}");

    // scrapper();
    super.onInit();
  }

  getDeviceLanguage(){
    // final controller = Get.isRegistered<NewsfeedController>() ? Get.find<NewsfeedController>() : Get.put(NewsfeedController());
    selectedLanguage = languageList.last;
    String deviceLangCode = Get.deviceLocale.languageCode.toLowerCase();
    //debugPrint("Locale: ${Get.deviceLocale}");
    //debugPrint("LanguageCode: ${Get.deviceLocale.languageCode}");
    //debugPrint("LanguageTag: ${Get.deviceLocale.toLanguageTag()}");
    updateLanguage(deviceLangCode);
    // controller.upDateLocale(selectedLanguage.code);

  }

  updateLanguage(String langCode){
    AppLanguage localLanguage = languageList.firstWhere((language) => language.code == langCode, orElse: () => null);
    if (localLanguage != null){
      selectedLanguage = localLanguage;
    }
    debugPrint("selectedLanguage: $selectedLanguage");
    update();
    Get.updateLocale(Locale(selectedLanguage.code));
  }

  PackageInfo packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
    buildSignature: 'Unknown',
  );

  Future<void> _initPackageInfo() async {
    final info = await PackageInfo.fromPlatform();

    packageInfo = info;
    update();
  }

  // @override
  // void didChangeDependencies() {
  //   _mountRoute ??= ModalRoute.of(context);
  //   super.didChangeDependencies();
  // }


  void changeLanguageLogin(AppLanguage language){
    final newsFeedController = Get.put(NewsfeedController());
    newsFeedController.languagesRequest(
      autoTranslate: 1.toString(),
      languageId: language.id ??
          1.toString(),
      appLanguage: language.name,
      appLanguageCode: language.code,
      appLanguageId: language.id,
    );
  }

  @override
  void onClose() {
    super.onClose();
  }

  // @override
  // void dispose() {
  //   // formKey.currentState?.dispose();
  //   super.dispose();
  // }

  Future<String> login(
      {Map<String, String> queryParameters, Map<String, String> token}) async {

/*    try{
      String fcmToken = FirebaseNotifications.deviceToken == null ? await FirebaseNotifications().getToken() : FirebaseNotifications.deviceToken;
      debugPrint("FcmToken: $fcmToken");
      queryParameters.addAll({
        "fcm_c_token": fcmToken});
    } catch (e){
      debugPrint("FCM Error: $e");
    }*/

      var response = await api.post(Uri.parse(Url.login),
          queryParameters: queryParameters, token: token);

      return response;


  }

  generateFCMToken(BuildContext context) async {
    // ignore: unused_local_variable
    var response = await FirebaseMessaging.instance.getToken(vapidKey: "BNG1ZQDff2Kkygun-sMgncG0UDl84FiyCxmELo0WlMWKVLNL5EqYSDJalek1pm4GbEfylyjv-q47HtAv4cYXPNM").then((value) {
      String token = value;
      // print('FCM FCM FCM FCM FCM FCM FCM FCM FCXM ' + token.toString());
      if (token != null) {
        storage.write("fcm_token", token);
        sendFCMTokenToServer(token, context);
      }
    });
  }

  sendFCMTokenToServer(fcmToken, BuildContext context) async {
    String voipToken;
    if (Theme.of(context).platform == TargetPlatform.iOS){
      voipToken = await VideoCallUtilities.getIosVoipToken();
    }

    var response =  api.post(
      Uri.parse(Url.fcmUrl),
      queryParameters: {
        'fcm_token': fcmToken,
        'voip_token': voipToken,
        'device_type': kIsWeb
            ? 'web'
            : Theme.of(context).platform == TargetPlatform.iOS
                ? 'ios'
                : Theme.of(context).platform == TargetPlatform.android
                    ? 'android'
                    : '',
      },
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );
    // print('FCM API APIA PAIAPAI APIA APAI APIA :' + response.toString());
  }

  Future<String> loginVerify(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.loginVerify),
        queryParameters: queryParameters, token: token);
    return response;
  }

  //ye hai

  TextEditingController firstName = TextEditingController();
  TextEditingController lastName = TextEditingController();
  TextEditingController signupEmail = TextEditingController();
  TextEditingController username = TextEditingController();
  TextEditingController signupPassword = TextEditingController();
  TextEditingController signupPasswordCon = TextEditingController();

  bool isSuggested = false;
  RxBool isSuggestedUsername = false.obs;

  List<cr.Data> list = [];
  int countryId;
  cr.Data chosenValue;

  // List<dynamic> listt = [];
  // final formKey = GlobalKey<FormState>();

  Future<String> register(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    /*queryParameters.addAll({
      "fcm_c_token": FirebaseNotifications.deviceToken == null ? await FirebaseNotifications().getToken() : FirebaseNotifications.deviceToken});
    */
    var response = await api.post(Uri.parse(Url.registerationUrl),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    LoggingUtils.printValue("register", json);

    try {
      return response;
    } catch (_) {
      // print("MY EXCEPTION" + "$_");
      return json['errors']['email'][0];
    }
  }

  Future<int> forgotPassword(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.forgotPassword),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    return json['meta']['code'];
  }

  Future<int> verificationCode(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.verificationCode),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    return json['meta']['code'];
  }

  Future<int> renewPassword(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.renewPassword),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    return json['meta']['code'];
  }

  // Future<List<dynamic>> usernameSuggestion(
  Future<String> usernameSuggestion(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.usernameSuggestion),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    // print(json['data']['username_suggestion']);
    // return json['data']['username_suggestion'];
    return json['meta']['message'].toString();
  }

  Future<List<dynamic>> getCountries() async {
    Api api = Api();
    var response = await api.get(Uri.parse(Url.getCountries), token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "X-Requested-With": "XMLHttpRequest"
    });

    var json = jsonDecode(response);
    cr.GetCountriesResponse getCountriesResponse =
        cr.GetCountriesResponse.fromJson(json);
    list = getCountriesResponse.data;
    // print("Get Countries Response"+response);
    // json["data"].forEach((element) {
    //   list.add(element['name']);
    // });

    update();

    return list;
  }

  Future<List<dynamic>> searchUsers(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.searchUsers),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    if (json["meta"]["code"] == 200) {
      return json['data'];
    } else if (json["meta"]["code"] == 400) {
      return [];
    }
    // print(response);
    // return ;
  }

  Future<Map<String, dynamic>> followSuggestions(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.get(Uri.parse(Url.followSuggestions),
        queryParameters: queryParameters, token: token);
    // print("MY RESP BODY neww $response");

    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> followUser(
      {Map<String, String> queryParameters,
      Map<String, String> token,
      String text}) async {
    Api api = Api();
    var response;
    if (text == "follow") {
      // print("yyy");
      // print(" queryParameters  $queryParameters");
      response = await api.post(
        Uri.parse(Url.followUser),
        queryParameters: queryParameters,
        token: token,
      );
    } else {
      response = await api.post(
        Uri.parse(Url.unFollowUser),
        queryParameters: queryParameters,
        token: token,
      );
    }

    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> reportPost({
    Map<String, String> queryParameters,
    Map<String, String> token,
  }) async {
    Api api = Api();
    var response = await api.post(
      Uri.parse(Url.reportPost),
      queryParameters: queryParameters,
      token: token,
    );
    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> reportUser({
    Map<String, String> queryParameters,
    Map<String, String> token,
  }) async {
    Api api = Api();
    var response = await api.post(
      Uri.parse(Url.reportUser),
      queryParameters: queryParameters,
      token: token,
    );
    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> filterPost({
    Map<String, String> queryParameters,
    Map<String, String> token,
  }) async {
    // print(queryParameters.toString());
    Api api = Api();
    var response = await api.post(
      Uri.parse(Url.searchPosts),
      queryParameters: queryParameters,
      token: token,
    );
    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> filterUserPost({
    Map<String, String> queryParameters,
    Map<String, String> token,
  }) async {
    Api api = Api();
    var response = await api.post(
      Uri.parse(Url.profileNewsFeedUrl),
      queryParameters: queryParameters,
      token: token,
    );
    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> getTrendings(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.getTrendings),
        queryParameters: queryParameters, token: token);
    // print("MY RESP BODY $response");

    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> getCategory(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.get(Uri.parse(Url.getReportCategory),
        queryParameters: queryParameters, token: token);
    // print("MY RESP BODY $response");

    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> hidePost(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.hidePostUrl),
        queryParameters: queryParameters, token: token);
    // print("MY RESP BODY $response");

    var json = jsonDecode(response);
    return json;
  }

  Future<Map<String, dynamic>> removeSavedPost(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.unSavePostUrl),
        queryParameters: queryParameters, token: token);
    // print("MY RESP BODY $response");

    var json = jsonDecode(response);
    return json;
  }

  ///socaial login  method

  Future<String> SocialLogin(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    /*queryParameters.addAll({
      "fcm_c_token": FirebaseNotifications.deviceToken == null ? await FirebaseNotifications().getToken() : FirebaseNotifications.deviceToken});
    */
    var response = await api.post(Uri.parse(Url.socialLogin),
        queryParameters: queryParameters, token: token);

    return response;
  }
}
