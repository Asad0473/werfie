import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../../models/moments_models/create_moments_models.dart';
import '../../utils/strings.dart';
import '../../utils/urls.dart';
import '../api.dart';
import 'add_moment_controller.dart';

class MomentsListController extends GetxController {
  final newsFeedController = Get.find<NewsfeedController>();
  List<MomentData> momentsDataList = [];

  bool getMomentListLoading = false;

  var api = Api();
  final storage = GetStorage();

  @override
  Future<void> onInit() async {
    // print('init function call it  getmoments list  controller ');
    await getMomentsList();
    //  momentsDataList= await getMomentsList();
    super.onInit();
  }

  Future<List<MomentData>> getMomentsList({bool isFromRoute = false}) async {
    getMomentListLoading = true;
    momentsDataList = [];

    if (kIsWeb) {
      if (!isFromRoute) {
        update();
      }
    }

    var responseData = await api.get(Uri.parse(Url.getMomentsPostList), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });
    var data = json.decode(responseData);

    if (data["meta"]["code"] == 200) {
      if (data['data'] != null || data['data'] != []) {
        // print('response data get momentsList :${data['data']}');
        data['data'].forEach((element) {
          momentsDataList.add(MomentData.fromJson(element));
        });
        getMomentListLoading = false;
        if(kIsWeb) {
          if (!isFromRoute) {
            update();
          }
        }else{
          update();

        }
        return momentsDataList;
      }
    } else {
      getMomentListLoading = false;
      if(kIsWeb) {
        if (!isFromRoute) {
          update();
        }
      }else{
        update();

      }

      return momentsDataList = [];
    }
  }

  void arrowBackFunction() {
    newsFeedController.isSearch = false;
    newsFeedController.isFilter = false;
    newsFeedController.isFilterScreen = false;
    newsFeedController.isTrendsScreen = false;
    newsFeedController.isNewsFeedScreen = true;
    newsFeedController.isWhoToFollowScreen = false;
    newsFeedController.isBrowseScreen = false;
    newsFeedController.isNotificationScreen = false;
    newsFeedController.isListScreen = false;
    newsFeedController.isChatScreen = false;
    newsFeedController.isSavedPostScreen = false;
    newsFeedController.isListDetailScreen = false;
    newsFeedController.isPostDetails = false;
    newsFeedController.isProfileScreen = false;
    newsFeedController.isFollwerScreen = false;
    newsFeedController.isSettingsScreen = false;
    newsFeedController.drawerLeftMoment = false;
    newsFeedController.navRoute = "isNewsFeedScreen";
    newsFeedController.searchText.text = '';
    if (Get.isRegistered<MomentsListController>()) {
      Get.delete<MomentsListController>();
    }
    if (Get.isRegistered<AddMomentsController>()) {
      Get.delete<AddMomentsController>();
    }
    // newsFeedController.getNewsFeed(shouldUpdate: true, reload: true);
    newsFeedController.update();
  }

  bool deleteLoading = false;

  Future<bool> deleteMomentApi({int momentId}) async {
    deleteLoading = true;
    update();
    var responseData =
        await api.delete(Uri.parse(Url.deleteMoments), queryParameters: {
      'moment_id': momentId.toString()
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });
    var data = json.decode(responseData);
    if (data["meta"]["code"] == 200) {
      // print(" delete hello");

      Fluttertoast.showToast(
          msg: Strings.momentDeleteSuccessfully,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      getMomentListLoading = true;
      await getMomentsList();
      getMomentListLoading = false;
      deleteLoading = false;
      update();
      return true;
    } else {
      // print(" delete hello");

      Fluttertoast.showToast(
          msg: 'Something Went Wrong',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      deleteLoading = false;
      update();

      return false;
    }
  }
}
