import 'package:get/get.dart';
import 'package:werfieapp/models/notifications/NotificationsFilterRespnse.dart';

import '../../models/notifications/EmailNotificationsSettingsResponse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';

class NotificationSettingsController extends GetxController{

  NotificationsFilterResponse notificationsFilterResponse;
  PushNotificationsSettingsResponse pushNotificationsSettingsResponse;
  EmailNotificationsSettingsResponse emailNotificationsSettingsResponse;



}