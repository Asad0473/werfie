import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:location/location.dart' as loc;
import 'package:werfieapp/network/google_places_api.dart';

import '../../models/geomery_latlng/geomatry_latlng.dart';
import '../../models/map_autocomplete_model/map_auto_complete_model.dart';
import '../../models/profile.dart';
import '../../utils/strings.dart';

class GoogleSearchLocation extends GetxController {
  UserProfile userInfo;

  MapClient _mapClient = MapClient();
  AutoComplete getAutoComplete;
  GeomatryLatLng geomatryLatLng;
  Rx<AutoComplete> searchPlaces = AutoComplete(status: "", predict: []).obs;
  String _currentSearch = ' ';
  var lat = 31.4914.obs;
  var lng = 74.2385.obs;
  LatLng latLng1 = LatLng(31.4643687, 74.2414678);
  final locationTextController = TextEditingController();

  //Location location = new Location();
  LocationData locationData;
  String mainText = ' ';
  String secondaryText = ' ';
  String prr = '   ';
  String lll;
  static final String selectedLocation = '';
  var customLocation = 'Getting Location..'.obs;

  @override
  Future<void> onInit() async {
    // print("locations");
    if (kIsWeb) {
      determinePosition().then((value) {
        getCurrentLocation();
      });
    } else {
      bool permission = await checkLocation();

      if (permission == true) {
        await getCurrentLocation().then((value) async {
          // await callApi(customLocation.value);
        });
      }
    }

    super.onInit();
  }

  @override
  Future<void> onReady() async {
    if (kIsWeb) {
      determinePosition().then((value) async {
        await callApi(customLocation.value);
      });
    } else {
      bool permission = await checkLocation();
      if (permission == true) {
        await callApi(customLocation.value);
      }
    }

    // TODO: implement onReady
    super.onReady();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  /// Get current location of the device
  ///
  Future getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition();
      lat.value = position.latitude;
      lng.value = position.longitude;
      if (kIsWeb) {
        customLocation.value = 'johar town';
      } else {
        getCustomLocation(lat.value, lng.value);
      }
      // print("current lat: ${lat.value}");
      // print("current lng: ${lng.value}");
      update();
    } catch (e) {
      return LatLng(31.427789, 74.239181);
    }
  }

  /// location permission of the location
  Future<bool> checkLocation() async {
    try {
      final location = loc.Location();

      if (await location.serviceEnabled()) {
        final perm = await location.hasPermission();
        if (perm == loc.PermissionStatus.granted ||
            perm == loc.PermissionStatus.grantedLimited) {
          Strings.locationPermission = 'granted';
          return true;
        } else if (perm == loc.PermissionStatus.denied) {
          final perm = await location.requestPermission();
          if (perm == loc.PermissionStatus.granted ||
              perm == loc.PermissionStatus.grantedLimited) {
            Strings.locationPermission = 'granted';
            return true;
          } else if (perm == loc.PermissionStatus.denied) {
            Strings.locationPermission = 'denied';
            return false;
          } else if (perm == loc.PermissionStatus.deniedForever) {
            Strings.locationPermission = 'deniedForever';
            return false;
          } else {
            return false;
          }
        } else if (perm == loc.PermissionStatus.deniedForever) {
          Strings.locationPermission = 'deniedForever';
          return false;
        } else {
          return false;
        }
      } else {
        final service = await location.requestService();
        if (service) {
          final perm = await location.hasPermission();
          if (perm == loc.PermissionStatus.granted ||
              perm == loc.PermissionStatus.grantedLimited) {
            Strings.locationPermission = 'granted';
            return true;
          } else if (perm == loc.PermissionStatus.denied) {
            final perm = await location.requestPermission();
            if (perm == loc.PermissionStatus.granted ||
                perm == loc.PermissionStatus.grantedLimited) {
              Strings.locationPermission = 'granted';
              return true;
            } else if (perm == loc.PermissionStatus.denied) {
              Strings.locationPermission = 'denied';
              return false;
            } else if (perm == loc.PermissionStatus.deniedForever) {
              Strings.locationPermission = 'deniedForever';
              return false;
            } else {
              return false;
            }
          } else if (perm == loc.PermissionStatus.deniedForever) {
            Strings.locationPermission = 'deniedForever';
            return false;
          } else {
            return false;
          }
        } else {
          return false;
        }
      }
    } catch (e) {
      return false;
    }
  }

  /// Determine the current position of the device.
  ///
  /// When the location services are not enabled or permissions
  /// are denied the `Future` will return an error.
  Future<Position> determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled don't continue
      // accessing the position and request users of the
      // App to enable the location services.
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permissions are denied, next time you could try
        // requesting permissions again (this is also where
        // Android's shouldShowRequestPermissionRationale
        // returned true. According to Android guidelines
        // your App should show an explanatory UI now.
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle appropriately.
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    // Position position = await Geolocator.getCurrentPosition();

    return await Geolocator.getCurrentPosition();
  }

  getCustomLocation(double lat, double lng) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lng);
      customLocation.value =
          "${placemarks[0].street},${' '}${placemarks[0].subLocality},${' '}${placemarks[0].locality},${' '}${placemarks[0].administrativeArea},${' '}${placemarks[0].country}";
      locationTextController.text = customLocation.value;
      // print("Address: ${customLocation.value}");

      update();
    } catch (e) {
      print(e.toString());
    }
  }

  /// get address from the google geocoding api
  Future<String> getAddress() async {
    try {
      var addresses = await _mapClient.fetchAddress(
          latitude: latLng1.latitude, longitude: latLng1.longitude);
      var first = addresses.results.first;
      return first.formattedAddress;
    } catch (e) {
      return 'UnKnown';
    }
  }

  void callApi(String str) async {
    _currentSearch = str;
    if (_currentSearch != prr) {
      searchPlaces.value = await getPlaces(_currentSearch);
      prr = _currentSearch;
      //print('printrrr:${prr}');
      update();
    }
  }

  Future callApiLatLong(String placeId) async {
    geomatryLatLng = await getPlacesLatLong(placeId);
    lat.value = geomatryLatLng.result.geometry.location.lat;
    lng.value = geomatryLatLng.result.geometry.location.lng;
    print('lat ${lat.value}');
    print('lng${lng.value}');
    update();
  }

  void updateText(String str) {
    if (str.isEmpty) {
      callApi(' ');
    }
    callApi(str);
  }

  /// get places of the latlng
  Future<GeomatryLatLng> getPlacesLatLong(String str) async {
    final response = await _mapClient.getPlacesLatLong(str);
    return response;
  }

  ///  search through the places google places api
  Future<AutoComplete> getPlaces(String str) async {
    // await  _mapClient.getPlace(str);
    getAutoComplete = await _mapClient.getPlaces(str);
    return getAutoComplete;
  }
}
