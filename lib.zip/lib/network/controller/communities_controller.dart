import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:video_player/video_player.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../../dummy_data.dart';

class CommunitiesController extends GetxController {
  RxBool hoverCheck = false.obs;
  bool isHome = true;
  bool isPhotos = false;
  bool isVideos = false;
  bool isAbout = false;
  VideoPlayerController videoPlayerController;

  bool isSelectedTimelinePhotos = true;
  bool isSelectedCoverPhotos = false;
  bool isSelectedAdminPhotos = false;

  int scrollValue = 0;
  int scrollValue2 = 0;
  int scrollValue3 = 0;
  int scrollValue4 = 0;

  Timer timer;
  Timer timer2;
  Timer timer3;
  Timer timer4;

  final itemScrollController1 = ItemScrollController();
  final itemScrollController2 = ItemScrollController();
  final itemScrollController3 = ItemScrollController();
  final itemScrollController4 = ItemScrollController();

  int listLength = 10;
  int listLength2 = 13;
  int listLength3 = 15;
  int listLength4 = 16;

  String CategoryName = "";
  String CategoryImage = "";

  final itemKey = GlobalKey();
  final scrollControl = ScrollController();

  final List<String> list = <String>[
    'General',
    'Animal',
    'Arts',
    'Business',
    'Science & Tech',
    'health',
    'Humor',
    'Style',
    'Food and Drinks',
    'Travel',
    'Civics & Community',
    'Education',
    'Faith & Spirituality',
    'Hobbies & Interests',
    'Relationships & Identity',
    'Sports & Fitness',
    'Family & Parenting',
    'Buy & Sell',
    'Vehicles & Commutes'
  ];

  final List<String> membersOptionList = <String>[
    'All',
    'Blocked',
  ];

  final List<String> privacyList = <String>[
    'Public',
    'Private',
  ];

  final List<String> visibilityList = <String>[
    'Visible to public',
    'Private',
  ];

  String dropdownValue = '';
  String dropdownValueForPrivateList = '';
  String dropdownValueForVisibilityList = '';
  String dropdownValueForMembersOptionList = '';
  Uint8List coverImage;

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  final DummyData dataController = Get.find<DummyData>();

  var api = Api();

  Future scrollToItem(int index,
      {ItemScrollController itemScrollController}) async {
    itemScrollController.scrollTo(index: index, duration: Duration(seconds: 1));
  }

  @override
  void onClose() {
    // print("close");
    timer?.cancel();
    // timer.cancel();
    timer4?.cancel();
    // timer2.cancel();
    // timer3.cancel();
    // TODO: implement onClose
    super.onClose();
  }

  @override
  void onInit() {
    if (kIsWeb) {
      timer = Timer.periodic(Duration(seconds: 10), (Timer t) {
        if (scrollValue < listLength - 2) {
          scrollValue = scrollValue + 2;
          print(scrollValue);
          // print("+");

          update();

          if (scrollValue <= listLength - 2) {
            scrollToItem(scrollValue,
                itemScrollController: itemScrollController1);
          }
        }
        if (listLength - 1 == scrollValue || listLength - 2 == scrollValue) {
          scrollValue = 0;
          scrollToItem(scrollValue,
              itemScrollController: itemScrollController1);
        }
      });

      timer2 = Timer.periodic(Duration(seconds: 7), (Timer t) {
        if (scrollValue2 < listLength2 - 2) {
          scrollValue2 = scrollValue2 + 2;
          print(scrollValue2);

          update();

          if (scrollValue2 <= listLength2 - 2) {
            scrollToItem(scrollValue2,
                itemScrollController: itemScrollController2);
          }
        }
        if (listLength2 - 1 == scrollValue2 ||
            listLength2 - 2 == scrollValue2) {
          scrollValue2 = 0;
          scrollToItem(scrollValue2,
              itemScrollController: itemScrollController2);
        }
      });

      timer3 = Timer.periodic(Duration(seconds: 9), (Timer t) {
        if (scrollValue3 < listLength3 - 2) {
          scrollValue3 = scrollValue3 + 2;
          print(scrollValue3);
          print("+");

          update();

          if (scrollValue3 <= listLength3 - 2) {
            scrollToItem(scrollValue3,
                itemScrollController: itemScrollController3);
          }
        }
        if (listLength3 - 1 == scrollValue3 ||
            listLength3 - 2 == scrollValue3) {
          print("jjj");
          scrollValue3 = 0;
          scrollToItem(scrollValue3,
              itemScrollController: itemScrollController3);
        }
      });

      timer4 = Timer.periodic(Duration(seconds: 9), (Timer t) {
        if (scrollValue4 < listLength4 - 2) {
          scrollValue4 = scrollValue4 + 2;
          print(scrollValue4);
          print("+");
          update();
          if (scrollValue4 <= listLength4 - 2) {
            scrollToItem(scrollValue4,
                itemScrollController: itemScrollController4);
          }
        }
        if (listLength4 - 1 == scrollValue4 ||
            listLength4 - 2 == scrollValue4) {
          print("jjj");
          scrollValue4 = 0;
          scrollToItem(scrollValue4,
              itemScrollController: itemScrollController4);
        }
      });
    }

    scrollValue = 0;
    videoPlayerController = VideoPlayerController.network(
        "https://storage.googleapis.com/buzznbees/files/UbEm1GpQYjKRmUHYdNRaaxFKFjQitJuvRBEEbAau.mp4",
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: false));

    dropdownValue = 'General';
    dropdownValueForPrivateList = "Public";
    dropdownValueForVisibilityList = "Visible to public";
    dropdownValueForMembersOptionList = 'All';

    scrollController = ScrollController()..addListener(scrollListener);

    // print( "dropdownValue $dropdownValue");
    // TODO: implement onInit
    super.onInit();
  }

  void scrollListener() {
    print(scrollController.offset);
    if (isShrink != lastStatus) {
      {
        lastStatus = isShrink;
        update();
      }
      update();
    }
  }

  ScrollController scrollController;
  bool lastStatus = true;
  double height = 370;

  bool get isShrink {
    return scrollController != null &&
        scrollController.hasClients &&
        scrollController.offset > (height - 70);
  }

  @override
  void dispose() {
    print("dispose");
    timer.cancel();
    timer4.cancel();
    timer3.cancel();
    timer2.cancel();

    itemScrollController1;
    itemScrollController2;
    itemScrollController3;
    itemScrollController4;

    scrollController?.removeListener(scrollListener);
    scrollController?.dispose();
    super.dispose();
  }

  @override
  void onReady() {
    dropdownValueForMembersOptionList = 'All';
    // videoPlayerController = VideoPlayerController.network(
    //     "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
    //     videoPlayerOptions: VideoPlayerOptions(
    //         allowBackgroundPlayback: false
    //     )
    // );
    dropdownValue = 'General';
    // TODO: implement onReady
    super.onReady();
  }

  void HomeTab() {
    isHome = true;
    isPhotos = false;
    isVideos = false;
    isAbout = false;

    update();
  }

  void AboutTab() {
    isAbout = true;
    isHome = false;
    isPhotos = false;
    isVideos = false;

    update();
  }

  void PhotosTab() {
    isHome = false;
    isPhotos = true;
    isAbout = false;
    isVideos = false;
    update();
  }

  void VideosTab() {
    isHome = false;
    isPhotos = false;
    isAbout = false;
    isVideos = true;
    update();
  }

  Uint8List image;
  var img;

  Future<Uint8List> callGetImage() async {
    img = await dataController.getImage();
    update();

    print("image $img");

    image = await img.readAsBytes();

    // pickedMedia = await dataController.getImageWeb();
    // _pickedImage.add(imageBytes);
    print('NAHI ATA IDHAR');
    print("image $image");

    // if (_pickedImage != null) {
    //   print('I D H A R A J A T A H A I');
    //   isMediaAttached = true;
    //
    //   setState(() {});
    // }
    return image;
  }
}
