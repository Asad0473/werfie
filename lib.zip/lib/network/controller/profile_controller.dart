import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:image_cropper/image_cropper.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/seach_suggestion_model.dart';
import 'package:werfieapp/models/update_profile.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/utils/urls.dart';

class ProfileController extends GetxController {
  /// Edit and cancel button
  bool visible = true;
  bool changeText = true;
  bool dob = true;
  int deletePostId = 2;

  bool threadCreated = false;
  bool monthValidatedSuccessfully = true;
  bool dayValidatedSuccessfully = true;
  bool hourValidatedSuccessfully = true;
  bool minutesValidatedSuccessfully = true;
  bool showScheduledWerfs = false;
  bool isEditable = false;
  bool isCheckBoxSelected = false;
  List<int> minutes = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59
  ];
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  bool selectedDOB = true;
  List<String> list = <String>[
    'Public',
    'Your followers',
    'People you follow',
    'You follow each other',
    'Only you'
  ];
  String dropdownValue = 'Public';
  String dropdownValueYear = 'Your followers';

  List<String> yearsSees = [
    'Public',
    'Your followers',
    'People you follow',
    'You follow each other',
    'Only you',
  ];
  bool isLoading = false;
  UserProfile userProfile;
  UpdateProfile updateProfile;
  final storage = GetStorage();
  final DummyData dataController = Get.find<DummyData>();
  var userToken = "";
  bool isSearch = false;
  bool searchField = false;
  bool isUserNameTaken = false;
  bool isUpdateProfile = false;
  List<int> years = [
    2022,
    2021,
    2020,
    2019,
    2018,
    2017,
    2016,
    2015,
    2014,
    2013,
    2012,
    2011,
    2010,
    2009,
    2008,
    2007,
    2006,
    2005,
    2004,
    2003,
    2002,
    2001,
    2000,
    1999,
    1998,
    1997,
    1996,
    1995,
    1994,
    1993,
    1992,
    1991,
    1990,
    1989,
    1988,
    1987,
    1986,
    1985,
    1984,
    1983,
    1982,
    1981,
    1980,
    1979,
    1978,
    1977,
    1976,
    1975,
    1974,
    1973,
    1972,
    1971,
    1970,
    1969,
    1968,
    1967,
    1966,
    1965,
    1964,
    1963,
    1962,
    1961,
    1960,
    1959,
    1958,
    1957,
    1956,
    1955,
    1954,
    1953,
    1952,
    1951,
    1950,
    1949,
    1948,
    1947,
    1946,
    1945,
    1944,
    1943,
    1942,
    1941,
    1940,
    1939,
    1938,
    1937,
    1936,
    1935,
    1934,
    1933,
    1932,
    1931,
    1930,
    1929,
    1928,
    1927,
    1926,
    1925,
    1924,
    1923,
    1922,
    1921,
    1920,
    1919,
    1918,
    1917,
    1916,
    1915,
    1914,
    1913,
    1912,
    1911,
    1910,
    1909,
    1908,
    1907,
    1906,
    1905,
    1904,
    1903,
    1902,
    1901,
    1900,
  ];

  // String scheduleMonthValue = DateTime.now().month.toString();
  // String scheduleDayValue = DateTime.now().day.toString();
  // String scheduleYearValue = 2022.toString();
  // String scheduleHourValue = DateTime.now().hour.toString();
  // String selectedMonthValue = DateTime.now().month.toString();
  // String selectedDayValue = DateTime.now().day.toString();
  // String selectedYearValue = 2022.toString();
  // String selectedHourValue = DateTime.now().hour.toString();
  // String selectedMinutesValue = DateTime.now().minute.toString();
  // String scheduleMinutesValue = DateTime.now().minute.toString();

  FocusNode focusNode;
  String selectedDateTime;

  //Tabs
  bool isTweets = true;
  bool isHiddenPost = false;
  bool isTweetsReply = false;
  bool isMedia = false;
  bool isLikes = false;
  bool isFilter = true;
  List<Post> userPosts = [];
  List<Post> tempUserPosts = [];
  int pinCheck = 0;
  bool isProfileUpdating = false;

  //Profile Dialog
  bool isProfile = false;
  Uint8List profileImage;
  bool isCover = false;
  Uint8List coverImage;
  bool isBio = false;
  bool isUsername = false;

  String selectedTab = "isTweets";
  String selectedView = "isProfile";

  TextEditingController searchText = TextEditingController();
  TextEditingController bioText = TextEditingController();
  TextEditingController usernameText = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController websiteController = TextEditingController();
  List<SearchSuggestion> searchResult = [];

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  var api = Api();
  var userName = "";
  var profileId;

  final newsFeedControler = Get.find<NewsfeedController>();

  int page;
  bool doesUsernameExist = false;

  @override
  void onInit() async {
    page = -1;

    userToken = storage.read('token');
    // profileId = Get.arguments["profileId"];
    // userName = Get.arguments["userName"];
    isLoading = true;
    update();
    // print("profile ID:" + profileId.toString());
    // print('singleTone profileid:${SingleTone.instance.profileId}');
    if (!kIsWeb) {
      if (SingleTone.instance.profileId == null) {
        userProfile = newsFeedControler.userProfile;
      } else {
        userProfile = await newsFeedControler.getUserProfile();

        // userProfile = newsFeedControler.userProfile;
        // userProfile = await newsFeedControler.getUserProfile(SingleTone.instance.profileId);
      }
    }

    isLoading = false;

    update();
    super.onInit();
  }

  @override
  void onReady() async {
    userProfile = await newsFeedControler.getUserProfile();

    if (userProfile.dob != null) {
      MonthDob();
      DayDob();
      YearDob();
    }

    // print("userProfile.dob ${userProfile.dob} ");

    bioText.text = userProfile != null
        ? userProfile.bio != null
            ? userProfile.bio
            : ""
        : "";

    usernameText.text = userProfile != null
        ? userProfile.firstname != null
            ? userProfile.firstname + userProfile.lastname
            : ''
        : '';

    /// dob
    dobSelected = userProfile != null
        ? userProfile.dob != null
            ? userProfile.dob
            : ''
        : '';




    userPosts = await filterUsersPost("posts");
    update();

    userPosts.forEach((element) {
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      // element.comments.forEach((element) {
      //   element.reactionType.value = element.isLiked;
      //   element.commentCount.value  = element.simpleLikeCount;
      // });
      element.reactionType.refresh();

      // if (element.isLiked == true) {
      //   element.like.value = true;
      //   element.like.refresh();
      // }
    });
    // likeUnlike();
    // likeUnlikeComment();
    // createDeleteComment();
    // createDeleteBuzz();
    update();
    super.onReady();
  }

  String MonthDob() {
    String DobMonth = userProfile.dob;
    final SplitMonth = DobMonth.split(" ");

    selectedMonth = SplitMonth[0];
    return SplitMonth[0];
  }

  String DayDob() {
    String DobMonth = userProfile.dob;
    final SplitMonth = DobMonth.split(" ");
    final MonthSplit = SplitMonth[1].split(",");

    selectedDay = MonthSplit[0];

    return MonthSplit[0];
  }

  String YearDob() {
    String DobMonth = userProfile.dob;
    final SplitMonth = DobMonth.split(",");

    selectedYear = SplitMonth[1];
    return SplitMonth[1];
  }

  Future<Uint8List> callGetImage({String imageType}) async {
    Uint8List image;
    var img = await dataController.getImage();

    if(!kIsWeb && imageType != null && imageType == "cover"){
      CroppedFile croppedFile = await ImageCropper().cropImage(
        sourcePath: img.path,
        aspectRatio: const CropAspectRatio(ratioX: 16, ratioY: 9),
        aspectRatioPresets: [
          // CropAspectRatioPreset.square,
          // CropAspectRatioPreset.ratio3x2,
          // CropAspectRatioPreset.original,
          // CropAspectRatioPreset.ratio4x3,
          CropAspectRatioPreset.ratio16x9
        ],
        uiSettings: [
          AndroidUiSettings(
              toolbarTitle: '',
              toolbarColor: Colors.deepOrange,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: true),
          IOSUiSettings(
            title: '',
            aspectRatioLockEnabled: true,
          ),
          // WebUiSettings(
          //   context: context,
          // ),
        ],
      );
      image = await croppedFile?.readAsBytes();
      return image;
    }

    image = await img?.readAsBytes();

    // pickedMedia = await dataController.getImageWeb();
    // _pickedImage.add(imageBytes);
    // print("img ${image}");

    // if (_pickedImage != null) {
    //   print('I D H A R A J A T A H A I');
    //   isMediaAttached = true;
    //
    //   setState(() {});
    // }
    return image;
  }

  // ignore: missing_return
  String dobSelected = "";
  String Month = "";

  /// dob
  String selectedMonth = "";
  String selectedDay = "";
  String selectedYear = "";

  String functionstoreDate() {
    dobSelected = "${selectedMonth + " " + selectedDay + ", " + selectedYear}";
    update();
    return dobSelected;
  }

  bool coverImageDelete = false;
  bool profileImageDelete = false;

  Future<bool> createData({
    String Bio,
    String userName,
    Uint8List coverImageBytes,
    bool delete_cover_picture,
    Uint8List profileImageBytes,
    bool delete_profile_picture,
    String dob,
    String firstName,
    String lastName,
    String gender,
  }) async {
    isUpdateProfile = true;
    update();

    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      "Access-Control-Allow-Origin": "*",
    };
    final request =
        await http.MultipartRequest("Post", Uri.parse(Url.updateProfileUrl));
    request.headers.addAll(headers);

    if (gender != null) {
      request.fields['gender'] = gender;
    }

    if (firstName != null) {
      request.fields['firstname'] = firstName;
    }

    if (lastName != null) {
      request.fields['lastname'] = lastName;
    }


    if (Bio != null) {
      request.fields['about_me'] = Bio;
    }
    if (dob != null) {
      request.fields["dob"] = dob;
    }
    if (coverImageBytes != null) {
      request.files.add(http.MultipartFile.fromBytes(
        'cover_image',
        coverImageBytes,
        filename: "Name",
      ));
    }
    if (profileImageBytes != null) {
      request.files.add(http.MultipartFile.fromBytes(
        'profile_image',
        profileImageBytes,
        filename: "Name",
      ));
    }

    if (delete_cover_picture == true) {
      request.fields["delete_cover_picture"] = 1.toString();
    } else if (delete_cover_picture == false) {
      request.fields["delete_cover_picture"] = 0.toString();
    }

    if (delete_profile_picture == true) {
      request.fields['delete_profile_picture'] = 1.toString();
    } else if (delete_profile_picture == false) {
      request.fields['delete_profile_picture'] = 0.toString();
    }

    var response = await request.send();

    response.stream.bytesToString().asStream().listen((event) {
      var parsedJson = json.decode(event);


      if (parsedJson['errors'] != null) {
        if (parsedJson['errors']['username'] != null) {
          //  if (parsedJson['errors']['username'].length > 0) {
          //    isUserNameTaken = true;

          update();

          return '0';

          // }
        }
        return "0";
      } else {
        //   isUserNameTaken = false;
        update();
        return parsedJson['meta']['code'].toString();
      }
    });

    userProfile = await newsFeedControler.getUserProfile();
    storage.write("user_profile", jsonEncode(userProfile));
    storage.write("username", userProfile.username);
    storage.write("dob", userProfile.dob);
    String userData = storage.read("user_profile");

    Get.find<NewsfeedController>().userProfile =
        UserProfile.fromJson(jsonDecode(userData));

    Get.find<NewsfeedController>().userProfile.username =
        storage.read("user_name");
    Get.find<NewsfeedController>().update();
    update();
    return isUserNameTaken;
  }

  Future<List<Post>> filterUsersPost(tab, {bool isFromRoute = false}) async {


    try {
      userPosts = [];
      isFilter = true;
      update();

      if (!isFromRoute) {
        update();
      }
      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterUserPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        "user_id": "${storage.read("id")}",
        "tab": tab.toString(),
      });

      if (!isFromRoute) {
        update();
      }
      // print(resBody);
      if (resBody["meta"]["code"] == 200) {
        List<Post> tempUserPosts01 = [];
        resBody["data"].forEach((element) {
          // print("element");
          // print(element);
          // print("element");
          // if (seletedTab == "people") {
          //   print("people");
          //   filteredPeople.add(FilteredPeople.fromJson(element));
          // } else {
          // print("other");
          tempUserPosts01.add(Post.fromJson(element));
          // }
        });
        if (!isFromRoute) {
          update();
        }
        userPosts = tempUserPosts01;
        userPosts.forEach((element) {
          tempUserPosts.add(element);
        });

        userPosts.forEach((element) {
          
          newsFeedControler.threadNumber = element.thread_no;

          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          // });

          element.reactionType.refresh();
          // if (element.isLiked == nul) {
          //   element.like.value = true;
          //
          // }
        });

        isFilter = false;

        if (!isFromRoute) {
          update();
          // newsFeedControler.update();
        }

        return userPosts;
      } else {
        isFilter = false;
        update();
        return [];
      }
    } catch (e) {
    }
  }



  /// hidden replies
  Future<List<Post>> filterUsersPostForHiddenReplies({int page}) async {


    try {
      userPosts = [];
      isFilter = true;
      update();

      var resBody = await api.get(Uri.parse("${Url.baseUrl}hidden/newsfeed?page_no=${page}"),
          token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsFeedControler.storage.read('token'),
      });
      var data = json.decode(resBody);
      //print("resBody  ${data}");


      if (data["meta"]["code"] == 200) {
        data["data"].forEach((element) {
          userPosts.add(Post.fromJson(element));

        });




        userPosts.forEach((element) {
          
          newsFeedControler.threadNumber = element.thread_no;

          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          element.reactionType.refresh();

        });

        isFilter = false;
        update();

        return userPosts;
      } else {
        isFilter = false;
        update();
        return [];
      }
    } catch (e) {
      isFilter = false;
      update();
      return [];

    }
  }

  Future<List<Post>> filterUsersPostPaggedForHiddenReplies({int page}) async {
    // print("page no  $page} ");

    try {
      if (page == 1 || page == null) {
        // userPosts = [];
      }

      var resBody = await api.get(Uri.parse("${Url.baseUrl}hidden/newsfeed?page_no=${page}"),
          token: {
            'X-Requested-With': 'XMLHttpRequest',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': newsFeedControler.storage.read('token'),
          });
      var data = json.decode(resBody);

      if (data["meta"]["code"] == 200) {
        if (data['data'] != null) {
          var postData = data['data'] as List;
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();
          data["data"].forEach((element) {
            userPosts.add(Post.fromJson(element));

          });
          userPosts.forEach((element) {
            
            newsFeedControler.threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
            element.reactionType.refresh();

          });

          update();
          return  postData.map((e) => Post.fromJson(e)).toList();
        } else {
          return [];
        }
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }

    //return userPosts;
  }



  List<Post> postPaged = [];

  Future<List<Post>> filterUsersPostPagged(tab, {int page}) async {
    // print("page no  $page} ");

    try {
      if (page == 1 || page == null) {
        // userPosts = [];
      }

      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterUserPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        "user_id": "${storage.read("id")}",
        "tab": tab.toString(),
        "page_no": page.toString(),
      });
      if (resBody["meta"]["code"] == 200) {
        if (resBody['data'] != null) {
          var postData = resBody['data'] as List;
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();
          userPosts.addAll(postList2);

          userPosts.forEach((element) {
            
            newsFeedControler.threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });

            element.reactionType.refresh();
            // if (element.isLiked == nul) {
            //   element.like.value = true;
            //
            // }
          });

          update();
          // newsFeedControler.update();

          // userPosts = postData.map((e) => Post.fromJson(e)).toList();
          return postData.map((e) => Post.fromJson(e)).toList();
        } else {
          return [];
        }
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }

    //return userPosts;
  }

  Future<bool> checkUsername(String username) async {
    var response = await api.post(Uri.parse(Url.checkUsername), token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      'username': username.toString()
    });
    var res = jsonDecode(response);
    if (res['data']['found']) {
      return true;
    }
    if (!res['data']['found']) {
      return false;
    }
  }
}
