import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/moments_screen/get_moments_list.dart';

import '../../dummy_data.dart';
import '../../models/moments_models/create_moments_models.dart';
import '../../models/post.dart';
import '../../models/profile.dart';
import '../../models/seach_suggestion_model.dart';
import '../../screens/moments_screen/edit_moments_screen.dart';
import '../../utils/fluro_router.dart';
import '../../utils/urls.dart';
import '../api.dart';
import 'get_moment_list_controller.dart';
import 'news_feed_controller.dart';

class AddMomentsController extends GetxController {
  String momentid;

  AddMomentsController({this.momentid});

  ScrollController scrollController = ScrollController();

  // ScrollController scrollController;
  bool lastStatus = true;
  double height = 200;
  bool isLikedWerfs = true;
  bool isWerfsByAccount = false;
  bool isWerfSearch = false;
  String momentCoverImage;
  bool isSwitchButton = false;
  bool publishButton = false;
  bool isLoading = false;
  bool createApiCall = false;
  final List<String> list = <String>['End', 'Beginning'];
  String dropdownValue = '';
  bool isAdLoaded = false;
  bool disableButton = false;
  String userName;
  bool isSearch = false;
  bool momentDetailApi = false;
  List<SearchSuggestion> searchResult = [];
  int selectId;

  final DummyData dataController = Get.find<DummyData>();
  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();
  UserProfile userProfile;
  var img;
  Uint8List image;
  int userId;
  TextEditingController searchByAccount = TextEditingController();
  TextEditingController searchByWerfs = TextEditingController();
  TextEditingController tittleFiled = TextEditingController();
  TextEditingController descriptionFiled = TextEditingController();

  ///show moments  post
  List<Post> searchMomentsList = [];

  /// localcy data sgow in post

  List<Post> tempMomentsList = [];

  /// moments list dealis post

  List<Post> momentsListDetailsPosts = [];

  /// tepmerary id store in locacally ids
  List<int> addId = [];

  /// get Moments list data
  List<MomentData> momentsDataList = [];

  bool getMomentListLoading = false;

  ///edit moment true call
  bool momentEdit = false;

  /// used in dealits api call
  MomentData momentsData;
  String selectedTab = "liked";
  var api = Api();
  final storage = GetStorage();
  String tittleMoments;
  String descrptionMoments;
  int page;
  List<bool> checkList = [];

  void scrollListener() {
    if (isShrink != lastStatus) {
      {
        lastStatus = isShrink;
        update();
      }
      update();
    }
  }

  bool get isShrink {
    return scrollController != null &&
        scrollController.hasClients &&
        scrollController.offset > (height - 70);
  }

  @override
  Future<void> onInit() async {
    // print("momentid intit  ${momentid}");

    if (momentid != null && kIsWeb) {
      await momentsDetailsApi(pageNo: 1, momentId: int.parse(momentid));
    }

    // print(' momentsListDetailsPosts ${momentsListDetailsPosts.length}');
    //
    // print('init function call it ');
    scrollController = ScrollController()..addListener(scrollListener);
    isLikedWerfs = true;
    isWerfsByAccount = false;
    isWerfSearch = false;
    dropdownValue = list.first;
    // momentsDataList=await getMomentsList();
    //  page = -1;

    if (SingleTone.instance.momentId != null) {
      // print("ooooo34234o");
      await momentSearchPost(
          tab: 'liked', pageNo: 1, momentId: SingleTone.instance.momentId);
    } else {
      // print("oooooo");

      await momentSearchPost(tab: 'liked', pageNo: 1);
      userProfile = await newsfeedController.getUserProfile();
    }

    update();
    userName = userProfile.username;
    // print('user profile info ${userProfile.username}');
    isSearch = false;
    searchResult = [];

    super.onInit();
  }

  @override
  Future<void> onReady() async {
    // print('on ready function call');
    // momentsDataList=await getMomentsList();
    isLoading = true;
    // userProfile= await newsfeedController.getUserProfile();
    userProfile = await newsfeedController.getUserProfile();
    // userName=userProfile.username;
    userName = storage.read('userName');
    // print('user profile info ${userProfile.username}');

    isSearch = false;
    searchResult = [];

    isLoading = false;

    update();
    super.onReady();
  }

  @override
  void dispose() {
    scrollController?.removeListener(scrollListener);
    scrollController?.dispose();
    super.dispose();
  }

  @override
  void onClose() {
    super.onClose();
  }

  Future<void> LikedWerfs() async {
    isLikedWerfs = true;
    isWerfsByAccount = false;
    isWerfSearch = false;
    selectedTab = "liked";
    searchByAccount.clear();
    isSearch = false;
    searchResult = [];
    if (momentEdit == true && SingleTone.instance.momentId != null) {
      await momentSearchPost(
          tab: 'liked', pageNo: 1, momentId: SingleTone.instance.momentId);
    }
    // page=1;
    else {
      await momentSearchPost(tab: 'liked', pageNo: 1);
    }

    //  await fetchData(page);
  }

  Future<void> WerfsByAccount() async {
    isLikedWerfs = false;
    isWerfsByAccount = true;
    isWerfSearch = false;
    selectedTab = "by_account";
    searchByAccount.clear();
    searchResult = [];
    searchMomentsList = [];
    isSearch = true;
    // await momentSearchPost(tab: 'by_account',pageNo: 1,user_id:142 );
  }

  Future<void> SerachWerfs() async {
    isLikedWerfs = false;
    isWerfsByAccount = false;
    isWerfSearch = true;
    selectedTab = "text";
    searchByAccount.clear();
    isSearch = false;
    searchResult = [];
    if (momentEdit == true && SingleTone.instance.momentId != null) {
      await momentSearchPost(
          tab: 'text',
          pageNo: 1,
          text: 'Werfie',
          momentId: SingleTone.instance.momentId);
    } else {
      await momentSearchPost(tab: 'text', pageNo: 1, text: 'Werfie');
    }
  }

  void SwitchButton() {
    isSwitchButton = true;
  }

  Future<Uint8List> callGetImage() async {
    img = await dataController.getImage();
    image = await img.readAsBytes();
    update();
    return image;
  }

  /// search posted  method implemented

  Future<List<Post>> momentSearchPostPagenation(
      {String tab, int pageNo, int user_id, String text, int momentId}) async {
    try {
      // print("pageNO  $pageNo");
      //  isLoading=true;
      if (pageNo == 1 || pageNo == null) {
        searchMomentsList = [];
        update();
      }

      // print('function call it for pagenation');

      // update();

      // print('token print ${storage.read('token')}');

      final responseData = await http.post(
        Uri.parse(Url.searchMomentsPosts),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: jsonEncode(
          tab == 'liked' && momentId == null
              ? {
                  'tab': tab,
                  'page_no': pageNo,
                }
              : tab == 'liked' && momentId != null
                  ? {
                      'tab': tab,
                      'page_no': pageNo,
                      'moment_id': momentId,
                    }
                  : tab == 'by_account' && momentId == null
                      ? {
                          'tab': tab,
                          'page_no': pageNo,
                          'user_id': user_id,
                        }
                      : tab == 'by_account' && momentId != null
                          ? {
                              'tab': tab,
                              'page_no': pageNo,
                              'user_id': user_id,
                              'moment_id': momentId,
                            }
                          : tab == 'text' && momentId != null
                              ? {
                                  'tab': tab,
                                  'page_no': pageNo,
                                  'text': text,
                                  'moment_id': momentId,
                                }
                              : {'tab': tab, 'page_no': pageNo, 'text': text},
        ),
      );

      update();

      // print(responseData);
      var parsedJson = jsonDecode(responseData.body);

      if (responseData.statusCode == 200 && parsedJson['meta']['code'] == 200) {
        // print('Api response data2 ${parsedJson['data']}');
        if (parsedJson['data'] != null || parsedJson['data'] != []) {
          parsedJson["data"].forEach((element) {
            // print('response from pagenation function call it ');
            //   print(element);
            //  print("element");

            searchMomentsList.add(Post.fromJson(element));
          });
          searchMomentsList.forEach((element) {
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });
            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });

            element.reactionType.refresh();
          });
          update();
          // searchMomentsList.forEach((element) {
          //   tempMomentsList.add(element);
          // });
          // isLoading=false;
        } else {
          searchMomentsList = [];
          //  isLoading=false;
        }

        return searchMomentsList;
      } else
        //  isLoading=false;
        return [];
    } catch (e) {
      print(e.toString());
    }
  }

  Future<List<Post>> momentSearchPost({
    String tab,
    int pageNo,
    int user_id,
    String text,
    int momentId,
  }) async {
    try {
      // print("pageNO  $pageNo");
      isLoading = true;

      print('simple api call it ');
      // update();


      final responseData = await http.post(
        Uri.parse(Url.searchMomentsPosts),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: jsonEncode(
          tab == 'liked' && momentId == null
              ? {
                  'tab': tab,
                  'page_no': pageNo,
                }
              : tab == 'liked' && momentId != null
                  ? {
                      'tab': tab,
                      'page_no': pageNo,
                      'moment_id': momentId,
                    }
                  : tab == 'by_account' && momentId == null
                      ? {
                          'tab': tab,
                          'page_no': pageNo,
                          'user_id': user_id,
                        }
                      : tab == 'by_account' && momentId != null
                          ? {
                              'tab': tab,
                              'page_no': pageNo,
                              'user_id': user_id,
                              'moment_id': momentId,
                            }
                          : tab == 'text' && momentId != null
                              ? {
                                  'tab': tab,
                                  'page_no': pageNo,
                                  'text': text,
                                  'moment_id': momentId,
                                }
                              : {'tab': tab, 'page_no': pageNo, 'text': text},
        ),
      );

      update();

      print(responseData);
      var parsedJson = jsonDecode(responseData.body);

      if (responseData.statusCode == 200 && parsedJson['meta']['code'] == 200) {
        print('Api response data2 ${parsedJson['data']}');
        searchMomentsList = [];
        print('response from the simple api call ');
        if (parsedJson['data'] != null || parsedJson['data'] != []) {
          parsedJson["data"].forEach((element) {
            //   print(element);
            //  print("element");
            searchMomentsList.add(Post.fromJson(element));
          });
          final ids = Set();
          searchMomentsList.retainWhere((moment) => ids.add(moment.postId));

          searchMomentsList.forEach((element) {
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });
            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });

            element.reactionType.refresh();
          });
          update();
          isLoading = false;
        } else {
          searchMomentsList = [];
          isLoading = false;
        }

        return searchMomentsList;
      } else
        isLoading = false;
      return [];
    } catch (e) {
      print(e.toString());
    }
  }

  ///get pages
  int checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int pageNoL;
        pageNoL = (list / 10).toInt();
        page = pageNoL;
        // print('page function call it:${pageNoL} ');
        // print("Page add moment" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  /// fetch data  from api
  Future<List<Post>> fetchData(
    int page, {
    int user_id,
    String text,
  }) async {
    // print("fetchdata");
    // print('page No fectch data: ${page}');
    if (selectedTab == 'liked') {
      if (SingleTone.instance.momentId != null) {
        return await momentSearchPostPagenation(
            tab: 'liked', pageNo: page, momentId: SingleTone.instance.momentId);
      } else {
        return await momentSearchPostPagenation(
          tab: 'liked',
          pageNo: page,
        );
      }
    } else if (selectedTab == 'by_account') {
      if (SingleTone.instance.momentId != null) {
        return await momentSearchPostPagenation(
            tab: 'by_account',
            pageNo: page,
            user_id: userId,
            momentId: SingleTone.instance.momentId);
      } else {
        return await momentSearchPostPagenation(
            tab: 'by_account', pageNo: page, user_id: userId);
      }
    } else if (selectedTab == 'text') {
      if (SingleTone.instance.momentId != null) {
        return await momentSearchPostPagenation(
            tab: 'text',
            pageNo: page,
            text: 'Werfie',
            momentId: SingleTone.instance.momentId);
      } else {
        return await momentSearchPostPagenation(
            tab: 'text', pageNo: page, text: 'Werfie');
      }
    }
  }

  ///fectch search user

  Future<List<SearchSuggestion>> onSearchTextChanged(String text) async {
    try {
      searchResult.clear();
      if (text.isEmpty) {
        searchResult.clear();
        update();
        return searchResult = [];
      } else if (text.isNotEmpty && text.split(" ").join("") != "") {
        var response =
            await api.post(Uri.parse(Url.searchSuggestions), queryParameters: {
          'search_text': text.toString(),
        }, token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        //  searchResult.clear();
        // update();
        var jsonResponse = jsonDecode(response);

        if (jsonResponse["meta"]["code"] == 200) {
          searchResult.clear();
          jsonResponse["data"].forEach((ele) {
            searchResult.add(SearchSuggestion.fromJson(ele));
          });
          // print('First name   ' + searchResult[0].firstname);

          update();
          return searchResult;
        } else {
          return searchResult = [];
        }
      }
    } catch (e) {
      print('error${e}');
    }

    // return jsonResponse['data']['post_counts']['simple_like_count'];
  }

  /// create api  hit for moments

  Future<bool> createMomentsApi({
    String tittle,
    String description,
    String privacyType,
    Uint8List coverImage,
    int momentId,
    List<int> postIds,
  }) async {
    createApiCall = true;
    update();
    var seprateIds = postIds.join(',');

    print('comma seperateId${seprateIds}');

    Map<String, String> data2 = {
      "title": tittle,
      "description": description == null ? '' : description,
      "privacy_type": 'public',
      "post_ids": seprateIds,
      "moment_id": momentId.toString()
    };

    Map<String, String> data = {
      "title": tittle,
      "description": description == null ? '' : description,
      "privacy_type": 'public',
      "post_ids": seprateIds,
    };
    Map<String, String> data3 = {
      "title": tittle,
      "description": description == null ? '' : description,
      "privacy_type": 'public',
    };

    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      "Access-Control-Allow-Origin": "*",
    };

    var request = http.MultipartRequest('POST', Uri.parse(Url.createMoments));
    request.headers.addAll(headers);

    if (coverImage != null) {
      request.files.add(http.MultipartFile.fromBytes('cover_image', coverImage,
          filename: "Name"));
    }

    if (momentId != null) {
      request.fields.addAll(data2);
    } else if (momentId != null && postIds.length == 0) {
      request.fields.addAll(data3);
    } else {
      request.fields.addAll(data);
    }

    var response = await request.send();
    final respStr = await response.stream.bytesToString();
    var jsonData = jsonDecode(respStr);
    if (response.statusCode == 200 && jsonData['meta']['code'] == 200) {
      var dataResponse = jsonData['data'];
      print('response print of 200 ${dataResponse}');
      // MomentData momentData=MomentData.fromJson(dataResponse);
      tempMomentsList = [];
      addId = [];
      SingleTone.instance.buttonDisable == false;

      createApiCall = false;
      if (momentId == null) {
        Fluttertoast.showToast(
            msg: 'Created moment Successfully',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      } else {
        Fluttertoast.showToast(
            msg: 'Updated moment Successfully',
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      }

      update();
      if (kIsWeb) {
        if (Get.isRegistered<MomentsListController>()) {
          Get.delete<MomentsListController>();
          final momentListController = Get.put(MomentsListController());
          momentListController.update();
          addId = [];
          Get.delete<AddMomentsController>();
        } else {
          final momentListController = Get.put(MomentsListController());
          momentListController.update();
          addId = [];
          Get.delete<AddMomentsController>();
        }

        // Navigator.pop(context);
        Get.toNamed(FluroRouters.mainScreen + "/moments");

      } else {

        if (Get.isRegistered<MomentsListController>()) {
          Get.delete<MomentsListController>();
          final momentListController = Get.put(MomentsListController());
          momentListController.update();
          addId = [];
          Get.delete<AddMomentsController>();
        }
        else {
          final momentListController = Get.put(MomentsListController());
          momentListController.update();
          addId = [];
          Get.delete<AddMomentsController>();
        }

        SingleTone.instance.momentId = null;
        Get.off(MomentListScreen());
      }
      return true;
    } else {
      createApiCall = false;
      Fluttertoast.showToast(
          msg: 'SomeThing Went Wrong',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      update();
      return false;
    }
  }

  ///  momentsDetails
  Future<List<Post>> momentsDetailsApi({
    int momentId,
    int pageNo,
  }) async {
    momentDetailApi = true;
    momentsListDetailsPosts = [];
    image = null;
    update();
    final responseData = await http.post(
      Uri.parse(Url.momentsDetails),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'moment_id': momentId, 'page_no': 1},
      ),
    );

    var parsedJson = jsonDecode(responseData.body);
    print('moment Details list Api response:${parsedJson}');
    if (responseData.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson['data']['detail'];
      print('data of details api responc${data}');
      momentsData = MomentData.fromJson(data);

      momentCoverImage = momentsData.coverImage;
      tittleMoments = momentsData.title;
      descrptionMoments = momentsData.description;
      tittleFiled.text = tittleMoments;
      descriptionFiled.text = descrptionMoments;
      // if(momentsData.coverImage!=null){
      //
      //   String coverImage=momentsData.coverImage ;
      //   Uint8List _image = base64Decode(coverImage);
      //   image = _image;
      //
      //
      // }

      if (parsedJson['data']['newsFeed'] != null ||
          parsedJson['data']['newsFeed']) {
        parsedJson['data']['newsFeed'].forEach((element) {
          momentsListDetailsPosts.add(Post.fromJson(element));
        });

        // momentsListDetailsPosts.forEach((element) {
        //   addId.add(element.postId);
        // });
        momentsListDetailsPosts.forEach((element) {
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          // });
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          // });

          element.reactionType.refresh();
        });
        print(' momentsListDetailsPosts ${momentsListDetailsPosts.length}');

        momentDetailApi = false;
        update();
        return momentsListDetailsPosts;
      } else {
        momentDetailApi = false;
        update();
        return momentsListDetailsPosts = [];
      }
    } else {
      momentDetailApi = false;
      update();
      return momentsListDetailsPosts = [];
    }
  }

  /// add post
  Future<bool> addPostApi({
    int momentId,
    List<int> postIds,
  }) async {
    var seprateIds = postIds.join(',');
    final responseData = await http.post(
      Uri.parse(Url.addMomentsPost),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode({'moment_id': momentId, 'post_ids': seprateIds}),
    );

    update();

    print(responseData);
    var parsedJson = jsonDecode(responseData.body);
    if (responseData.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      Fluttertoast.showToast(
          msg: 'Post added successfully',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);

      update();
      if (!kIsWeb) {
        Get.to(EditMomentsScreen());
      }
      return true;
    } else {
      Fluttertoast.showToast(
          msg: 'Something went Wrong',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      update();
      return false;
    }
  }

  ///remove post
  Future<bool> removePost({int momentId, int postId}) async {
    // print(" 34234234234${momentId}    ");

    final responseData = await http.post(
      Uri.parse(Url.removePostFromMoments),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode({'moment_id': momentId, 'post_id': postId}),
    );

    print("responseData ${responseData}");

    print("status code ${responseData.statusCode}");
    var parsedJson = jsonDecode(responseData.body);

    if (responseData.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      Fluttertoast.showToast(
          msg: 'Post deleted successfully',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);

      update();
      return true;
    } else {
      print("sdfsdfsdf");
      Fluttertoast.showToast(
          msg: 'SomeThing went Wrong',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      update();
      return false;
    }
  }

  /// delete moments
  void deleteMoments() {}

  void arrowBackFunction() {
    newsfeedController.isSearch = false;
    newsfeedController.isFilter = false;
    newsfeedController.isFilterScreen = false;
    newsfeedController.isTrendsScreen = false;
    newsfeedController.isNewsFeedScreen = true;
    newsfeedController.isWhoToFollowScreen = false;
    newsfeedController.isBrowseScreen = false;
    newsfeedController.isNotificationScreen = false;
    newsfeedController.isListScreen = false;
    newsfeedController.isChatScreen = false;
    newsfeedController.isSavedPostScreen = false;
    newsfeedController.isListDetailScreen = false;
    newsfeedController.isPostDetails = false;
    newsfeedController.isProfileScreen = false;
    newsfeedController.isFollwerScreen = false;
    newsfeedController.isSettingsScreen = false;
    newsfeedController.drawerLeftMoment = false;
    newsfeedController.navRoute = "isNewsFeedScreen";
    newsfeedController.searchText.text = '';
    if (Get.isRegistered<MomentsListController>()) {
      Get.delete<MomentsListController>();
    }
    if (Get.isRegistered<AddMomentsController>()) {
      Get.delete<AddMomentsController>();
    }
    newsfeedController.getNewsFeed(shouldUpdate: true, reload: true);
  }
}
