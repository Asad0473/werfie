import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/topic_model/not_interested_topic_model.dart';
import 'package:werfieapp/models/topic_model/topic_model.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../models/post.dart';
import '../../models/topic_model/suggested_following_topic_for_other_profile_model.dart';
import '../../models/topic_model/suggested_following_topic_model.dart';
import '../../models/topic_model/topic_details_model.dart';
import '../../utils/utils_methods.dart';

class HiddenReplayController extends GetxController {
  int screenCheck = 0;
  bool isLoading = false;
  List<Post> hiddenReplyList = [];
  NotInterestedTopic notInterestedTopic;
  Topic topic;
  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();
  var api = Api();
  @override
  void onInit() {

    // TODO: implement onInit
    super.onInit();
  }
  @override
  void dispose() {

    super.dispose();
  }


  Future<dynamic> hiddenReplyPostList({int postId, int pageNO}) async {
    isLoading = true;
    update();
    var response = await http.post(
      Uri.parse(Url.hiddenComments),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
          "page_no": pageNO,
        },
      ),
    );


    print("response topic details: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {

        var data  = parsedJson["data"] as List;

      hiddenReplyList = [];
      data.forEach((element) {
        var datax = Post.fromJson(element);
        hiddenReplyList.add(datax);
      });

      hiddenReplyList.forEach((element) {
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
        element.reactionType.refresh();
      });

      print("hiddenReplyList.length  ${hiddenReplyList.length} ");

      isLoading = false;
        update();

    }
    else{

      hiddenReplyList = [];
      UtilsMethods
          .toastMessageShow(
        newsfeedController
            .displayColor,
        newsfeedController
            .displayColor,
        newsfeedController
            .displayColor,
        message: 'No Hidden Replies',
      );
      isLoading = false;
      update();


    }



  }



  Future<List<Post>> hiddenReplyPostListPagged({int postId, int pageNO}) async {
    // isLoading = true;
    // update();

    // print("pageNO  $pageNO");

    if (pageNO == 1 || pageNO == null) {
      hiddenReplyList = [];
    }



    var response = await http.post(
      Uri.parse(Url.hiddenComments),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': newsfeedController.userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
          "page_no": pageNO,
        },
      ),
    );

    print("response topic details: ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson["data"] as List;
      if (data.isEmpty) {
        return [];
      }
      data.forEach((element) {
        var datax = Post.fromJson(element);
        hiddenReplyList.add(datax);
      });
      hiddenReplyList.forEach((element) {
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
        element.reactionType.refresh();
      });
      return hiddenReplyList;
    }
    else{
      isLoading = false;
      update();
      return [];




    }
  }




}
