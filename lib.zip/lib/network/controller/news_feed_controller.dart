import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:video_compress/video_compress.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/gcs/UploadFileToGCS.dart';
import 'package:werfieapp/models/blocked_user.dart';
import 'package:werfieapp/models/chatUserModel.dart';
import 'package:werfieapp/models/filtered_people.dart';
import 'package:werfieapp/models/languages.dart';
import 'package:werfieapp/models/message.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/reaction.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/models/seach_suggestion_model.dart';
import 'package:werfieapp/models/shceduled_post.dart';
import 'package:werfieapp/models/socket_like.dart';
import 'package:werfieapp/models/trends_model.dart';
import 'package:werfieapp/models/werf_analytics.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/mobile_comments_controller.dart';
import 'package:werfieapp/network/controller/profile_controller.dart';
import 'package:werfieapp/network/controller/saved_post_controller.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/network/controller/topic_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/services/ad_helper.dart';
import 'package:werfieapp/services/database_helper.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:dio/dio.dart' as _dio;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:werfieapp/models/category.dart';
import 'package:werfieapp/models/get_follower.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:get/get.dart' hide Response, FormData, MultipartFile;
import 'package:get_storage/get_storage.dart';

import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:werfieapp/utils/utils_methods.dart';

import '../../models/FileBytesModel.dart';
import '../../models/comment_who_reacted.dart';
import '../../models/create_post_model/create_post_model.dart';
import '../../models/translationData_model.dart';
import '../../models/view_edit_history.dart';
import '../../utils/app_languages.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../widgets/web_createpostModule/create_PostWeb.dart';
import '../../widgets/web_createpostModule/video_playerchat.dart';
import 'List_controller.dart';
import 'other_topic_controller.dart';
import 'other_users_controller.dart';

class NewsfeedController extends GetxController {
  WerfAnalytics werfAnalytics;
  ViewEditHistory viewEditHistoryList;
  bool deactivateColor = false;
  Widget chatViewChanger;



  bool isShowMoreCheck= false;

  bool isComingFromlocationScreen = false;

  // List<Reaction1> reactions;
  /// Get Image of Dimension
  // Size imageSize = const Size(0.00, 0.00);
  //  Future<Widget> getImage(String url,) async {
  //    final Completer<Widget> completer = Completer();
  //
  //   // String url = '';
  //    final image = NetworkImage(url);
  //    // final config = await image.obtainKey(const ImageConfiguration());
  //    // final load = image.load(config, (buffer, {allowUpscaling, cacheHeight, cacheWidth}) => null);
  //
  //    final listener = new ImageStreamListener((ImageInfo info, isSync) async {
  //      print(info.image.width);
  //      print(info.image.height);
  //      // imageSize =
  //      //         Size(info.image.width.toDouble(), info.image.height.toDouble());
  //      if (info.image.width == 80 && info.image.height == 160) {
  //        completer.complete(Container(child: Text('AZAZA')));
  //      }
  //      else {
  //        completer.complete(
  //          ConstrainedBox(
  //              constraints: BoxConstraints(
  //                maxWidth: Get.width,
  //                maxHeight:  info.image.width == info.image.height ? 504 :650,
  //                minHeight: 284,
  //                minWidth:  info.image.width >info.image.height ? Get.width :384,
  //              ),
  //            child:  Image(image: image,fit: BoxFit.fill,),
  //          ),
  //        //     Container(
  //        //       height :info.image.height == info.image.width
  //        //           ? 504 : info.image.height > info.image.width && info.image.height >= 1500
  //        //           ? 590 : info.image.height > info.image.width && info.image.height >= 1000
  //        //           ? 550 : info.image.height > info.image.width && info.image.height >= 800
  //        //           ? 510 : info.image.height > info.image.width && info.image.height >= 600
  //        //           ? 510 :  info.image.height > info.image.width && info.image.height >= 500
  //        //           ? 420 : info.image.height < info.image.width && info.image.height >= 400
  //        //           ? 330 :  info.image.height < info.image.width && info.image.height >= 300
  //        //           ? 330 :info.image.height < info.image.width && info.image.height <= 300
  //        //            ? 280 :info.image.height,
  //        //       width : info.image.height == info.image.width
  //        //           ? Get.width : info.image.height > info.image.width && info.image.height >= 1500
  //        //           ? 430 : info.image.height > info.image.width && info.image.height >= 1000
  //        //           ? 410 : info.image.height > info.image.width && info.image.height >= 800
  //        //           ? 382 : info.image.height > info.image.width && info.image.height >= 500
  //        //           ? 382 : info.image.height < info.image.width && info.image.height >= 300
  //        //           ? Get.width : info.image.height < info.image.width && info.image.height <= 300
  //        //           ? Get.width : Get.width,
  //        //     child: Image(image: image,fit: BoxFit.cover,),
  //        // )
  //        );
  //      }
  //      // update();
  //    });
  //
  //    image.resolve(ImageConfiguration()).addListener(listener);
  //    return completer.future;
  //
  //  }
  bool isRequestScreen = false;
  String tempValue = '';
  String temp = '';
  String tempUsername = '';
  final commentController = TextEditingController();
  bool mentionUser = false;
  bool mentionTag = false;
  List<dynamic> users = [];
  List<dynamic> tags = [];

  bool forwardMsgLoading = false;
  int pageRunCount = 0;
  int imagePickCount = 0;

  // int imageCounter=0;
  // List<TextEditingController> imageDescriptionController = List.generate(4, (i) => TextEditingController());
  // // bool imageSave =
  // int descriptionCounter=0;

  // List<bool> imageSave = [false, false, false];

  final ReplyCommentController = TextEditingController();
  String replyTempValue = '';
  String replyTemp = '';
  String replyTempUsername = '';
  bool replyMentionUser = false;

  List<dynamic> replyUsers = [];
  List<dynamic> replyTags = [];

  bool buttonCheck = false;

  Reactions reaction;
  int deletePostId = 1;
  int pathCheck = 0;

  Color displayColor;
  bool isFABExpanded=false;

  bool disableButton = false;
  bool reactionLoading = false;
  bool checkPin = true;
  bool isAnalyticsLoading = false;
  List mediaData = [];
  bool isSavedPostScreenExists = false;
  NativeAd ad;

  bool otherProfileScreen = false;

  int userid;

  RxBool reactionCheck = false.obs;
  List<Post> getCommentsList = [];
  bool noScheduledPost = true;
  bool isAdLoaded = false;
  List<Object> ads = [];
  bool isVideoOnFullScreen = false;
  Subscription _subscription;
  bool wait = false;
  String linkId;
  String profileId;
  String noEditHistoryMessage = "";
  bool isMuted = false;

  NewsfeedController({this.linkId, this.profileId});

  TextEditingController chatSearchTEC = TextEditingController();
  FocusNode chatSearchTextFocus = FocusNode();
  bool isImagePickedChat = false;
  bool isVideoPickedChat = false;
  bool isDocumentPickedChat = false;
  bool isNewsFeedScreen = true;
  bool isListDetailScreen = false;
  bool isTagInfoScreen = false;
  bool isTagWerfsScreen = false;
  bool isTrendsScreen = false;
  bool isTopWerfsScreen = false;
  bool isProfileScreen = false;
  bool isDiscoverListScreen = false;
  bool isFollwerScreen = false;
  bool isBrowseScreen = false;
  bool isNotificationScreen = false;
  bool isSavedPostScreen = false;
  bool isSpacesScreen = false;
  bool isVideoCallScreen = false;
  bool isCommunitesScreen = false;
  bool isCommunityScreen = false;
  bool isAllGroupScreen = false;
  bool isChatScreen = false;
  bool isPostDetails = false;
  bool isHiddenReplay = false;
  bool isLoading = true;
  bool isFollowLoading = false;

  bool onHomeChange = true;
  bool onBrowsChange = false;
  bool onTrendsChange = false;
  bool onBookMarksChange = false;
  bool onChatsChange = false;
  bool onProfileChange = false;
  bool onSettingChange = false;
  bool onListChange = false;
  bool onNotificationChange = false;
  bool onMoreChange = false;
  bool onMomentChange = false;

  bool isTrendingLoading = false;
  bool isWhoToFollow = true;
  bool isSearch = false;
  bool isFilter = false;
  bool isFilterScreen = false;
  bool isWhoToFollowScreen = false;
  bool isOtherUserProfileScreen = false;
  bool isClickWhoToFollow = false;
  bool topTab = true;
  bool lattestTab = false;
  bool peopleTab = false;
  bool photosTab = false;
  bool videosTab = false;
  bool filesTab = false;
  bool notificationStatus = false;
  bool isSettingsScreen = false;
  bool isListScreen = false;
  bool isListMemberShipScreen=false;
  bool isTopicScreen = false;
  bool isTopicsCategoriesDetailsScreen = false;
  bool isSuggestedListScreen = false;

  /// moment screen
  bool isCreateMomentsScreen = false;
  bool addMomentsScreen = false;
  bool showMomentsScreen = false;
  bool drawerLeftMoment = false;
  bool getListMomentScreen = false;
  bool editMomentScreen = false;
  bool momentCreateScreen = false;
  bool momentListScreen = false;

  bool isMainTopicScreen = false;

  bool isTopicTrendingUserList = false;

  bool isOtherTopicTabScreen = false;

  bool isOtherMainTopicScreen = false;

  bool isPostListScreen = false;

  String seletedTab = "top";
  SearchSuggestion searchSelected;
  String otherUserName = "";
  int people = 1;
  int place = 1;
  int otherUserId = 0;
  int threadNumber = null;

  // int ostId = null;
  bool isBlockedUsersLoading = true;
  int postUserId;
  String tagText;
  RxInt index = 0.obs;

  RxBool checkDeactivate = true.obs;

  var verification;
  bool verificationCheck = true;

  RxInt bottomNavIndex = 0.obs;

  int userIdInt = 0;

  UserProfile userInfo;

  bool isComingBackFromPostDetail = false;

  AppLanguage lang = AppLanguage();
  List<AppLanguage> languagesList = [
    AppLanguage(
      id: 1,
      name: "English",
      code: "en",
    ),
    AppLanguage(
      id: 2,
      name: "Arabic",
      code: "ar",
    ),
    AppLanguage(
      id: 3,
      name: "French",
      code: "fr",
    ),
    AppLanguage(
      id: 4,
      name: "German",
      code: "de",
    ),
    AppLanguage(
      id: 5,
      name: "Italian",
      code: "it",
    ),
    AppLanguage(
      id: 6,
      name: "Japanese",
      code: "so",
    ),
    AppLanguage(
      id: 7,
      name: "Russian",
      code: "ru",
    ),
    AppLanguage(
      id: 8,
      name: "Spanish",
      code: "es",
    ),
    AppLanguage(
      id: 9,
      name: "Hindi",
      code: "hi",
    ),

    // AppLanguage(
    //   id:0,
    //   name:"Select Language",
    //   code: "en",
    // ),
    //
    // AppLanguage(
    //   id:1,
    //   name:"English",
    //   code: "en",
    // ),
    // AppLanguage(
    //   id:2,
    //   name:"عربي",
    //   code: "ar",
    // ),
    // AppLanguage(
    //   id:3,
    //   name:"French",
    //   code: "fr",
    // ),
    // AppLanguage(
    //   id:4,
    //   name:"Deutsche",
    //   code: "du",
    // ),
    // AppLanguage(
    //   id:5,
    //   name:"Española",
    //   code: "es",
    // ),
    // AppLanguage(
    //   id:6,
    //   name:"िंदी",
    //   code: "hi",
    // ),
    // AppLanguage(
    //   id:7,
    //   name:"Bahasa_Indonesia",
    //   code: "indo",
    // ),
    // AppLanguage(
    //   id:8,
    //   name:"Português",
    //   code: "po",
    // ),
    // AppLanguage(
    //   id:9,
    //   name:"Turca",
    //   code: "tu",
    // ),
    // AppLanguage(
    //   id:10,
    //   name:"Shoomaali",
    //   code: "so",
    // ),
    // AppLanguage(
    //   id:11,
    //   name:"فارسی",
    //   code: "fa",
    // ),
  ];

  List<AppLanguage> translationLanguage = [
    AppLanguage(
      id: 1,
      name: "English",
      code: "en",
    ),
    AppLanguage(
      id: 2,
      name: "Arabic",
      code: "ar",
    ),
    AppLanguage(
      id: 3,
      name: "French",
      code: "fr",
    ),
    AppLanguage(
      id: 4,
      name: "German",
      code: "de",
    ),
    AppLanguage(
      id: 9,
      name: "Hindi",
      code: "hi",
    ),
    AppLanguage(
      id: 7,
      name: "Russian",
      code: "ru",
    ),
    AppLanguage(
      id: 8,
      name: "Spanish",
      code: "es",
    ),
    AppLanguage(
      id: 5,
      name: "Italian",
      code: "it",
    ),
    AppLanguage(
      id: 6,
      name: "Japanese",
      code: "so",
    ),
    AppLanguage(
      id: 2,
      name: "Arabic",
      code: "ar",
    ),
  ];

  // List languagesList = [
  //   {
  //     "name": "English",
  //     "id": 1,
  //     "code": "en",
  //   },
  //   {
  //     "name": "عربي",
  //     "id": 2,
  //     "code": "ar",
  //   },
  //   {
  //     "name": "Français",
  //     "id": 3,
  //     "code": "fr",
  //   },
  //   {
  //     "name": "Deutsche",
  //     "id": 4,
  //     "code": "du",
  //   },
  //   {
  //     "name": "Española",
  //     "id": 5,
  //     "code": "es",
  //   },
  //   {
  //     "name": "हिंदी",
  //     "id": 6,
  //     "code": "hi",
  //   },
  //   {
  //     "name": "Bahasa_Indonesia",
  //     "id": 7,
  //     "code": "indo",
  //   },
  //   {
  //     "name": "Português",
  //     "id": 8,
  //     "code": "po",
  //   },
  //   {
  //     "name": "Turca",
  //     "id": 9,
  //     "code": "tu",
  //   },
  //   {
  //     "name": "Shoomaali",
  //     "id": 10,
  //     "code": "so",
  //   },
  //   {
  //     "name": "فارسی",
  //     "id": 11,
  //     "code": "fa",
  //   },
  // ];

  // final List<String> list = <String>[
  //   'English','عربي','Français','Deutsche','Española',' "हिंदी"','Bahasa_Indonesia','Português','Turca',
  //   'Shoomaali','فارسی'
  // ];
  AppLanguage dropdownValue;

  // = AppLanguage(
  //   id:1,
  //   name:"English",
  //   code: "en",
  // );
  AppLanguage dropdownValue1 = AppLanguage(
    id: 1,
    name: "English",
    code: "en",
  );

  //Settings Screen Booleans
  bool isViewEditHistoryLoading = false;
  bool isBlockedAccounts = false;
  bool isLanguageSettings = true;
  bool isTranslations = false;
  bool isAccountPrivacy = false;
  bool isAudienceTagging = false;
  bool isPhotoTagging = false;

  bool isAddLocationInformationToYourWerfs = false;

  bool isContentYouSee = false;

  bool isMuteAndBlock = false;

  bool isAddMuteWords = false;
  bool isMuteWords = false;

  bool isDirectMessage = false;

  bool isLocationInformation = false;

  bool isSeePlacesYouHaveBeen = false;

  bool isYourWerfs = false;

  bool isNotificationsSettings = false;
  bool isNotificationsFiltersScreen = false;
  bool isMutedNotificationsScreen = false;
  bool isNotificationPreferencesScreen = false;
  bool isPushNotificationScreen = false;
  bool isEmailNotificationScreen = false;
  bool isChangeUserName = false;
  bool isAccountInformation = false;
  bool isAccountPrivacySettings = false;
  bool isLanguageType = false;
  bool isSettingDetail = false;
  bool isSettingTypeDetail = false;
  bool isSettinggender = false;
  bool isChangePassword = false;

  bool isChangeEmail = false;
  bool isChangeCountry = false;
  bool isYourAccount = false;

  bool emailValidator = false;

  bool isProfileLanguagetype = false;
  bool isListOfBlockedAccounts = false;
  bool isMutedAccounts = false;
  bool isSecurityAndAccountAccess = false;
  bool isSecurity = false;

  bool isLang = false;
  LanguageModel languageData;
  TranslationData translationData;
  Lang selectedLanguage;
  Lang selectedAppLanguage;
  Lang selectedAppLanguageAtLogin;
  int selectedAppLanguageInfoId;
  bool showAd = false;
  int radioValueAccount = 2;

  int radioValueGender = -1;

  bool isAutoTranslate = false;
  bool isMentionUser = false;

  UserProfile userProfile;

//  List<ModelClass>modelList=[];

  var navRoute = "isNewsFeedScreen";
  String selectedCategory = "";

  //  String selectType = "Everyone";
  // String selectedType = "";
  int selectcategoryId;
  int detailPageCounter = 0;

//  Post postDetail;
  // List<Post> postDetail2 = [];
  List<Post> selectedPost2 = [];
  Post selectedPost;

  String currentlyPlayingVideoURLInChat = "";
  bool isChatScreenWeb = false;
  bool infoChatInfo = false;
  String groupName = "";
  String tempGroupName = "";

  bool messageLoader = false;
  bool isChatLoad = false;
  bool isSendMsg = true;
  int postId;
  String hashTag;
  Post post;
  bool isVideoThumbnail = false;
  bool isVideoUpload = false;
  bool isDocUpload = false;
  bool isImageUpload = false;
  Uint8List videoThumbnail;
  Uint8List ImageThumbnail;
  List<Post> threadList = [];
  List<Post> saveThreadList = [];

  //CHAT SCREEN BOOLEANS
  List<int> idList = [];
  List<String> selectedPeople = [];
  String randomGroup = "";
  ChatUserModel chatName;
  bool chatAcceptLoading = false;
  bool isAdmin = false;
  bool isWerfScheduled = false;
  bool isChatSnoozeNotification = false;
  bool isChatSnoozeMention = false;

  OtherUserController otherUserController = OtherUserController();

  final DummyData dataController = Get.put(DummyData());

  final commentTextController = TextEditingController();

  RxBool isCommentField = false.obs;
  bool isReplyComment = false;
  bool isNewsfeedLoading = false;
  bool isNewsFeedFollowingLoading = false;
  bool isNewsFeedForYouLoading = false;
  bool isPostListOneLoading = false;
  bool isPostListTwoLoading = false;
  bool isPostListThreeLoading = false;
  bool isPostListFourLoading = false;
  bool isPostListFiveLoading = false;
  bool isNewsfeedAdded = false;
  bool showOverlay = false;

  TextEditingController searchText = TextEditingController();
  TextEditingController searchTextForDM = TextEditingController();
  TextEditingController messageController = TextEditingController();
  bool isChatTextEmpty = true;
  var focusNode = FocusNode();
  int messageId;

  List<SearchSuggestion> searchResult = [];
  List<SearchSuggestion> searchResultForDM = [];

  ///postlist
  List<Post> postList = [];
  List<Post> postListFollowing = [];
  List<Post> postListOne = [];
  List<Post> postListTwo = [];
  List<Post> postListThree = [];
  List<Post> postListFour = [];
  List<Post> postListFive = [];

  bool mediaApiCheck = false;

  // RxList<Comment> commentsList = <Comment>[].obs;
  // RxList<RxList<Comment>> commentsListindex = <RxList<Comment>>[].obs;
  List<Post> filteredPost = [];
  List<Post> hashTagList = [];
  List<FilteredPeople> filteredPeople = [];
  int searchPeopleIndex = 0;

  String username = "";
  List<CategoryModel> categoryList = [];
  List<ChatUserModel> chatUserList = [];
  List<ChatUserModel> chatRequestUserList = [];

  //Search Chat Items
  TextEditingController messageSearchController = TextEditingController();
  bool isChatSearchActive = false;
  List<MessageModel> chatSearchMessageList = [];
  List<MessageModel> chatSearchPeopleList = [];
  List<ChatUserModel> chatSearchGroupList = [];

  bool undoRewerf = false;

  bool isChatUsersLoad = false;
  String userPrivacy = "";
  String gender = "";

  List<GetFollowerModel> followSuggestionsList = [];
  TrendsModel trendingList;
  final storage = GetStorage();
  SharedPreferences shared;
  var userToken = "";
  var userName = "";
  var api = Api();
  List<Post> _posts = [];
  List<Post> getDataSingleNews = [];

  // int postIndex ;
  // int commentIndex
  // List<Comment> comments = [];
  List<dynamic> usersList;
  List<BlockedUser> blockedUser = [];
  List<ScheduledPost> scheduledPosts = [];
  List checkData = [
    {
      'thumbnail_url': 'false',
      'name': 'kdsakdaks',
      'size': 1200,
      'url': 'false',
    },
    {
      'thumbnail_url': 'false',
      'name': '21cr',
      'size': 1200,
      'url': 'false',
    },
    {
      'thumbnail_url': 'false',
      'name': '21czdas',
      'size': 1200,
      'url': 'false',
    }
  ];

  List<ModelClass> modelList2 = [];

  /// CreatePostWeb List
  List<ModelClass> modelList3 = [];

  // TextEditingController writeSomethingHere = TextEditingController();
  List<TextEditingController> writeSomethingHere =
      List.generate(30, (i) => TextEditingController());
  List<bool> showPolls = [];
  bool showPollsCreate = false;
  bool postHideModel3 = false;
  bool dropDownValue = false;
  bool isPostScheduled = false;

  ///replay model list
  List<ModelClass> replayModelList = [];

  TextEditingController textController;
  int currentIndexText = 0;
  List<int> saveId = [];

  // int indexOfText() {
  //
  //   currentIndexText= modelList2.indexWhere((element) =>
  //   element.text ==modelList2[currentIndexText].text );
  //   print('index of text:$currentIndexText');
  //   update();
  //   print('index of text:$currentIndexText');
  //   return currentIndexText;
  //
  // }
  var imagesListForCarousel = [];
  var videoListForCarousel = [];

  UserProfile otherUserProfile;
  List<Post> userPosts = [];

  bool checkUpdateGroupName = false;

  int highlighteTheChat = -1;
  Uint8List profileImageGroupChat;

  Uint8List tempProfileImageGroupChat;
  List<MessageModel> messages = [];
  ScrollController scrollController;
  int postIndex = 0;
  bool isSocketSuccess = false;
  int forwardToUserId = 0;
  bool alreadyVoted = false;
  int newPosts = 0;
  bool isNewPost = false;

  Map<String, dynamic> likesSocketData = {
    'isLikedSocket': null,
    'totalLikes': null,
  };

  SocketLike socketLike;
  bool isMessageSelected = false;

  // Post DialogBox Url Scrapping
  bool postText = false;

  bool chatText = false;

  String scrapUrl;
  var profileUserId;
  bool scrapLoading = false;
  bool ListModelLoading = false;
  bool cardOpen = true;
  bool isChatCreatedYet = true;
  int scrapUrlMatchesLength = 0;


  void updateAppLanguage(AppLanguage value)async{
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('languageCode', value.code);
    prefs.setInt('languageId', value.id);
    prefs.setString('languageName', value.name);
    update();
  }

  void updateOtherUserId(int newUserId) {
    otherUserId = newUserId;
  }

  // int urlCount = 0;
  bool urlOrNot(String paragraph) {
    scrapUrlMatchesLength = 0;
    // r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+'
    RegExp exp =
        new RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');
    Iterable<RegExpMatch> matches = exp.allMatches(paragraph);
    if (matches != null && matches.isNotEmpty)
      scrapUrlMatchesLength = matches.length;
    if (matches.length == 1) {
      // if(urlCount == 0){
      //   urlCount = matches.length;
      // } else {
      //   if()
      // }
      scrapUrl = paragraph.substring(matches.first.start, matches.first.end);
      // urlScraping(scrapUrl);
      if(scrapUrl.startsWith("//")){
        scrapUrl = scrapUrl.substring(2,scrapUrl.length);
      }

      return true;
    } else
      return false;
    // matches.forEach((match) {
    //   print(postTextController.text.substring(match.start, match.end));
    // });
  }

  Future<ScrappingData> scrappingData;

  ChatScrappingData chatScrappingData;

  bool chatScrapLoading = false;

  void chatUrlScraping(String url) async {
    chatScrapLoading = true;
    update();
    // update([5]);
    var response =
        await api.get(Uri.parse(Url.urlScraping + "?link=$url"), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);

    // print("response urlScraping ${response} ");

    // update();
    chatScrappingData = ChatScrappingData.fromJson(jsonResponse["data"]);

    if (chatScrappingData.link == null ||
        chatScrappingData.title == null ||
        chatScrappingData.images == null ||
        chatScrappingData.images.isEmpty ||
        chatScrappingData.meta == null ||
        (scrapUrlMatchesLength != null &&
            (scrapUrlMatchesLength == 0 || scrapUrlMatchesLength > 1))) {
      chatScrappingData = null;
    }
    // else {
    //   if (chatScrappingData.title == null) {
    //     chatScrappingData.title = "  ";
    //   } else {
    //   }
    //   if (chatScrappingData.images == null || chatScrappingData.images.isEmpty) {
    //     chatScrappingData.images = [];
    //     chatScrappingData.images.add("https://www.challengetires.com/assets/img/placeholder.jpg");
    //   }
    // }

    chatScrapLoading = false;
    update();
  }

  Future<ScrappingData> urlScraping(String url) async {
    scrapLoading = true;

    // update([5]);
    var response =
        await api.get(Uri.parse(Url.urlScraping + "?link=$url"), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);

    // print("response urlScraping ${response} ");

    scrapLoading = false;

    // update();
    return ScrappingData.fromJson(jsonResponse["data"]);
  }

  int postPage = 1;
  bool scrooled = false;
  bool scrooledAboved = false;

  // sockets
  IO.Socket socket;
  var userId;
  Uint8List imageBytesChat;
  Uint8List videoBytesChat;
  Uint8List documentBytesChat;
  bool fromNotificationsScreen = false;
  RxInt likeCount = 0.obs;
  RxInt commentCount = 0.obs;
  RxInt rebuzzCount = 0.obs;
  List<int> selecteMessagesId = [];
  List<MessageModel> selectedMessages = [];

  Map<String, String> uploadMedia_;

  Color werfieBlue;

  String email;

  // For Follow Tab: On web if any action like follow or unfollow is done on the second tab
  // its resetting the tab index to 0.
  // To avoid that we save the current tab index and apply it when the page reloads
  int followTabIndex = 0;

  bool isMessagePopupChatSelected = false;
  bool isMessagePopupRequestChatSelected = false;
  bool isMessagePopupRequestScreen = false;
  double messagePopupSize = 47.0;
  int newMessageCount = 0;

  bool isWebWebWerfDialogOpen = false;
  bool isDeletingConversation = false;

  // Chats
  MessageModel replyToMsgModel;

  @override
  void onInit() async {
    // if(languageData!=null)
    //   {
    //
    //     print("hello sdfsdfs");
    //     dropdownValue =AppLanguage(
    //       id:languageData.myLang.id,
    //       name:languageData.myLang.name,
    //       code: languageData.myLang.code,
    //     );
    //
    //
    //
    //
    //   }
    // else{
    //   print("hello llll");
    // print('newsfeed controller is initalize');

    dropdownValue1 = translationLanguage[0];

    // int length  =   languagesList.length;
    //
    // for(int i=1;i<length;i++)
    // {
    //   if(languagesList[0].name ==languagesList[i].name )
    //   {
    //     languagesList.removeAt(i);
    //   }
    //
    // }

    //
    // }

    // print('INSIDE ON INIT');

    displayColor = storage.read("color") == null
        ? const Color(0xFF1D9BF0)
        : Color(storage.read("color"));
    shared = await SharedPreferences.getInstance();
    userToken = await storage.read('token');
    userName = storage.read('userName');
    userId = await storage.read('id');
    email = await storage.read('email');
    // print("colorr1111111 email   $email");
    _initPackageInfo();
    // modelList.add(ModelClass.fromJson({
    //   "text":null,
    //   'list_of_images':[]
    // }));
    // print("model list");
    // print("model list"+modelList.length.toString());
    // print("model list");
    // userIdInt = int.parse(userId);
    if (isSearch == false) {
      NativeAd _ad;
      AdHelper _adHelper = AdHelper();
      postList = await getNewsFeed();
      postListFollowing = await getNewsFeedFollowing();
      connectAndListen();
      getChat();
      getMessageRequest();
      // postList.forEach((element) {
      //
      //   if(element.authorId == GetStorage().read('id'))
      //     {
      //       verification = element.userInfo.accountVerified;
      //       print("verification   $verification" );
      //
      //     }
      //
      // });

      // postList.forEach((element) {
      //   threadNumber=element.thread_no;
      // });
      // print('thread Number:${threadNumber}');
      if (!isNewsfeedLoading) {
        if (storage.read("user_profile") == null) {
          await getUserProfile();
        }
        try {
          trendingList = await getTrendings();
        }catch(e){
          trendingList = TrendsModel(trends: []);
          print(e);
        }
        followSuggestionsList = await followSuggestions();

        await getCategories();
      }
      // print('Singletone instance post id :${SingleTone.instance.postId}');
      // if(SingleTone.instance.postId!=null){
      //   postDetail = await getSingleNewsFeedItem(SingleTone.instance.postId);
      // }

      update();

      // update();
    }
    // connectAndListen();
    //getChat();
    // _subscription = VideoCompress.compressProgress$.subscribe((progress) {
    //   // debugPrint('progress: $progress');
    // });
    // connectAndListen();
    // update();

    // if(languageData!=null)
    // {
    //
    //   print("hello sdfsdfs");
    //   dropdownValue =AppLanguage(
    //     id:languageData.myLang.id,
    //     name:languageData.myLang.name,
    //     code: languageData.myLang.code,
    //   );
    //   update();
    //
    //
    //
    //
    // }
    // languageData = await getLanguages();
    // languagesList[0].name =  languageData.appLang.name;
    // languagesList[0].id =   languageData.appLang.id;
    // languagesList[0].code =  languageData.appLang.code;
    //
    //
    //
    //
    // // print(languagesList[0]);
    //
    //
    // print(" language ooo ${ languagesList[0].name}");
    //
    //
    //
    // dropdownValue =  languagesList[0];
    // print("newsfeed controller is initalize");
    super.onInit();
  }

  @override
  void onReady() async {
    // print('INSIDE ONREADY');
    // likeUnlike();
    // likeUnlikeComment();
    // createDeleteComment();
    // createDeleteBuzz();

    // update();

    if (linkId != null) {
      if (kIsWeb) {
        isPostDetails = true;
        isTrendsScreen = false;
        isNewsFeedScreen = false;
        isBrowseScreen = false;
        isNotificationScreen = false;
        isChatScreen = false;
        isSavedPostScreen = false;
        // if (isSavedPostScreen) {
        //   savedController.update();
        // }
        // if (controller.isBrowseScreen) {
        //   browseController.update();
        // }

        // commented this check because we have field thread number in newsfeed controller and we are populating it when we get newsfeed from backend and at time that threadnumber fields have value that's why its navigating to wrong post link.
        //if (threadNumber == null) {
          selectedPost2 = await getSingleNewsFeedItem(linkId);
        /*} else {
          selectedPost2 = await getSingleNewsFeedItemThread(linkId);
        }*/

        update();
      } else {
        //

        // Navigator.push(
        //     context,
        //     MaterialPageRoute(
        //         builder: (BuildContext context) =>
        //             CommentsScreen(postId:int.parse(linkId)
        //                 )));
        // Get.toNamed(AppRoute.mobileCommentRoute, arguments: {
        //   "postId": ,
        //   "controller": Get.find<NewsfeedController>()
        // });
      }
    }

    if (profileId != null) {
      if (kIsWeb) {
        otherUserId = int.parse(profileId);
        isOtherUserProfileScreen = false;
        isProfileScreen = false;
        isClickWhoToFollow = true;
        isWhoToFollowScreen = false;
        isOtherUserProfileScreen = false;
        isTrendsScreen = false;
        isNewsFeedScreen = false;
        isBrowseScreen = false;
        isNotificationScreen = false;
        isChatScreen = false;
        isPostDetails = false;
        try {
          Get.find<OtherUserController>().userProfile =
              await getOtherUserProfile(int.parse(profileId));
        } catch (_) {}
        // Get.to(() => OtherUsersProfile(controller: controller));
        update();
      } else {
        otherUserId = int.parse(profileId);
        update();
        // Other user profile for share profile to other
        // Get.to((OtherUsersProfile(
        //   controller: Get.find<NewsfeedController>(),
        // )));
      }
    }

    super.onReady();
  }
  PackageInfo packageInfo = PackageInfo(
    appName: 'Unknown',
    packageName: 'Unknown',
    version: 'Unknown',
    buildNumber: 'Unknown',
    buildSignature: 'Unknown',
  );

  Future<void> _initPackageInfo() async {
    final info = await PackageInfo.fromPlatform();

    packageInfo = info;
  //  update();
  }
  void functionRoute(String postId) async {
    if (postId != null) {
      isPostDetails = true;
      isTrendsScreen = false;
      isNewsFeedScreen = false;
      isBrowseScreen = false;
      isNotificationScreen = false;
      isChatScreen = false;
      isSavedPostScreen = false;
      if (isSavedPostScreen) {
        update();
      }
      if (isBrowseScreen) {
        // browseController.update();
      }
      if (threadNumber == null) {
        selectedPost2 = await getSingleNewsFeedItem(postId);
      } else {
        selectedPost2 = await getSingleNewsFeedItemThread(threadNumber);
      }

      update();
    }
  }

  @override
  void onClose() {
    if (socket != null) {
      socket.close();
    }

    super.onClose();
  }

  void connectAndListen() {
    try {
      socket = IO.io(
          '${Url.nodeBaseUrl}?token=${storage.read('token')}',
          // '$chatBaseUrl?token=${storage.read('token')}',
          <String, dynamic>{
            'transports': ['websocket'],
            'autoConnect': false,
            'force new connection': true,
            // when logout and login to new account its not establishing new connection. Got lot of bugs due to this. - K
          });

      // print('going to connect');
      socket.connect();
      socket.onConnect((data) {
        // print("conectted");
      });

      socket.on('connect_error', (data){
        debugPrint("Socket connection error: $data");
      });
      socket.on('new_message', (data) {
        isImagePickedChat = false;
        //print(data);
        // print("New message on socket: " + data.toString());
        // print("data");

        MessageModel emitMessage = MessageModel.fromJson(data);
        // for(int i = 0; i <= messages.length ; i++){

        if (messages.length != 0) {
          if (messages[0].conversationId.toString() ==
              emitMessage.conversationId.toString()) {
            if (data["mode"] != null && data["mode"] == "edit") {
              messages.forEach((element) {
                if (element.id == data["id"]) {
                  element.body = emitMessage.body;

                  update();
                }
              });
            }
          }
        }
        if (chatName != null &&
            chatName.conversationId.toString() ==
                emitMessage.conversationId.toString()) {
          if (data["mode"] != null && data["mode"] == "new") {
            messages.insert(0, emitMessage);
          }
        }

        // For Notification
        if (data["mode"] != null &&
            data["mode"] == "new" &&
            navRoute != "isChatScreen" &&
            !isChatScreen &&
            bottomNavIndex.value != 2 &&
            emitMessage.userId != userId) {
          newMessageCount++;
        }

        messageId = null;
        // print(data);
        // controller.getChatForMessageScreen() is moved here from sending message methods in chat_screen_mobile.dart and forward_message_dialog.dart
        // While sending message this is helpful there but the user receiving the message should also have
        // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
        // Below is the link to one of the bug related to this on Asana:  - K
        // https://app.asana.com/0/1203291929645086/1204450039764493/f
        //
        getChatForMessageScreen();
        update();
      });
      socket.on('message_recation', (data) {
        // socket message_reaction : {status: warning, message_id: 2898, reaction_id: 9, message: Already reacted}
        // socket message_reaction : {status: success, message_id: 2898, reaction_id: 8, message: reaction updated}
        // response in the chat: reactionInfo: [{user_id: 461, type: smile}]
        // reaction_count: 1 - What is this for, we need reaction count for all seperate reations
        // what is the syntax to undo remove reaction
        //multiple reactions in response:  reactionInfo: [{user_id: 461, type: smile}, {user_id: 459, type: love}]
        // flutter: socket message_reaction : {status: success, message_id: 2900, reaction_id: 10, message: Reaction recorded, conversation_id: 475, userInfo: {id: 461, firstname: Kathirtest06, lastname: , username: @kathirtest06, profile_image: null}}
        // message_reaction : {status: warning, message_id: 2898, reaction_id: null, message: reaction not found}
        // socket message_reaction : {status: success, message_id: 2898, reaction_id: 14, message: reaction updated}

        // print("socket message_reaction : " + data.toString());
        if (messages.isNotEmpty && data["userInfo"] != null) {
          if (chatName != null &&
              chatName.conversationId.toString() ==
                  data["conversation_id"].toString()) {
            messages.forEach((element) {
              if (element.id == data["message_id"]) {
                Map<String, dynamic> reactionInfoMap = {
                  "message_id": data["message_id"],
                  "type": data["type"],
                  "id": data["userInfo"]["id"],
                  "firstname": data["userInfo"]["firstname"],
                  "lastname": data["userInfo"]["lastname"],
                  "username": data["userInfo"]["username"],
                  "profile_image": data["userInfo"]["profile_image"]
                };
                int index = -1;
                if (element.reactionInfo != null) {
                  index = element.reactionInfo
                      .indexWhere((item) => item.id == userProfile.userId);
                }
                if (index < 0) {
                  if (element.reactionInfo == null) {
                    element.reactionInfo = List.generate(
                        1, (index) => Member.fromJson(reactionInfoMap));
                  } else {
                    element.reactionInfo
                        .insert(0, Member.fromJson(reactionInfoMap));
                  }
                } else {
                  if (data["type"] == "dislike") {
                    element.reactionInfo.removeAt(index);
                  } else {
                    element.reactionInfo[index] =
                        Member.fromJson(reactionInfoMap);
                  }
                }
                update();
              }
            });
          }
        }
      });
      socket.on('delivered_to', (data) {
        // if(data["u"] != storage.read("id")) {
        messages.forEach((element) {
          if (element.conversationId.toString() == data["c"].toString()) {
            // print("conversation");
            if (element.id.toString() == data["m"].toString()) {
              sendStatus(data["m"], data["u"], data["c"], data["s"]);
              element.deliverByAll = true;
              update();
            }
          }
        });

        // }
      });

      socket.on('message_seen_get', (data) {
        messages.forEach((element) {
          if (element.conversationId.toString() ==
              data["conversation_id"].toString()) if (element.id
                  .toString() ==
              data["message_id"].toString()) {
            element.seenByAll = true;
            element.deliverByAll = true;
            update();
          }
        });

        // sendStatus(data["c"], data["m"]);
      });

      socket.on('block_user', (data) {
        // isBlocked = true;
      });

      socket.on('hot_trends', (data) {
        // print("hottrends");

        // print('hot trends${data.toString()}');
        // print("hottrends");
        List<Trend> listtt = [];

        TrendsModel tren = TrendsModel();
        tren.region = data["region"];
        data["trends"].forEach((elee) {
          listtt.add(Trend.fromJson(elee));
          // .add(Trend.fromJson(elee));
        });
        tren.trends = listtt;
        // tren.trends = List<Trend>.from(data["trends"]);
        // listtt.forEach((ele){
        //
        // });

        trendingList = tren;
        update();
      });
      socket.on('new_post', (data) {
        //print("NEW POST SOCKET EVENT");
        //print(data);
        if (data["user_id"] != userId) {
          newPosts = newPosts + 1;
          socket.emit("unread_count_posts",{'user_id': userId, "count": newPosts});
          isNewPost = true;
          update();
         /* try {
            var postData = data['slug'];
            Post post = Post.fromJson(postData[0]);
            //print(post.postId);
            //print(post.postedTimeAgo);
            postList.insert(0, post);
            postList.forEach((element) {
              element.saved = false;
              // print('first screen2');
              threadNumber = element.thread_no;
              element.rebuzz.value = element.isRetweeted;
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;

              // element.comments.forEach((element) {
              //   element.reactionType.value = element.isLiked;
              //   element.commentCount.value = element.simpleLikeCount;
              // });

              element.reactionType.refresh();
            });

            update();
          }catch(e){
            print(e);
          }
*/
          // print('Oth index' + postList[0].body);
        }
      });

      socket.on(
        'like_unlike_post',
        (data) {
          // print("sockety");
          // print("like_unlike_post listener data: $data");

          //     print("data" + data.toString());
          //     try {
          //       if (Get.find<ProfileController>().userPosts.isNotEmpty &&
          //           Get.find<ProfileController>().userPosts.length > 0) {
          //         Get.find<ProfileController>().userPosts.forEach((ele) {
          //           // for(int i = 0; i <= postList.length ; i++){
          //
          //           if (ele.postId == data["post_id"]
          //               // postList[postIndex].postId
          //               ) {
          //             Get.find<ProfileController>().userPosts.forEach((element) {
          //               if (element.postId == data["post_id"]) {
          //                 if (data["type"] == "like") {
          //                   element.likeCount.value++;
          //                   // element.like.value = true;
          //                   // element.likeCount.refresh();
          //
          //                 } else if (data["type"] == "unlike") {
          //                   if (element.likeCount.value != 0) {
          //                     element.likeCount.value--;
          //                     element.like.value = false;
          //                     element.likeCount.refresh();
          //                   } else {
          //                     element.like.value = false;
          //                     // element.likeCount.value = 0;
          //                     // element.likeCount.refresh();
          //                   }
          //                 }
          //               }
          //               element.likeCount.refresh();
          //             });
          //           }
          //         });
          //       }
          //     } catch (_) {}

          try {
            if (Get.find<SavedPostController>().savedPostList.isNotEmpty &&
                Get.find<SavedPostController>().savedPostList.length > 0) {
              Get.find<SavedPostController>().savedPostList.forEach((ele) {
                if (ele.postId == data["post_id"]) {
                  Get.find<SavedPostController>()
                      .savedPostList
                      .forEach((element) {
                    if (element.postId == data["post_id"]) {
                      if (data["type"] == "like_simple_like" ||
                          data["type"] == "love" ||
                          data["type"] == "thanks" ||
                          data["type"] == "lough" ||
                          data["type"] == "smile" ||
                          data["type"] == "excited" ||
                          data["type"] == "cry") {
                        element.simpleLikeCount = element.likeCount.value - 1;
                        element.isLiked = data["type"];
                        element.likeCount.value = element.likeCount.value - 1;
                        element.likeCount.value++;
                      } else if (data["type"] == "unlike") {
                        if (element.likeCount.value != 0) {
                          element.likeCount.value = element.likeCount.value + 1;
                          element.likeCount.value--;
                        } else {
                          element.likeCount.value = 0;
                        }
                      }
                    }
                    element.likeCount.refresh();
                  });
                }
              });
            }
          } catch (_) {}
          try {
            if (Get.find<ProfileController>().userPosts.isNotEmpty &&
                Get.find<ProfileController>().userPosts.length > 0) {
              Get.find<ProfileController>().userPosts.forEach((ele) {
                if (ele.postId == data["post_id"]
                    // postList[postIndex].postId
                    ) {
                  Get.find<ProfileController>().userPosts.forEach((element) {
                    if (element.postId == data["post_id"]) {
                      if (data["type"] == "like_simple_like" ||
                          data["type"] == "love" ||
                          data["type"] == "thanks" ||
                          data["type"] == "lough" ||
                          data["type"] == "smile" ||
                          data["type"] == "excited" ||
                          data["type"] == "cry") {
                        element.simpleLikeCount = element.simpleLikeCount + 1;
                        element.isLiked = data["type"];
                        element.likeCount.value = element.likeCount.value - 1;
                        element.likeCount.value++;
                        // print(
                        //     "element.likeCount.value++ ${element.likeCount.value} ");
                      } else if (data["type"] == "unlike") {
                        if (element.simpleLikeCount != 0) {
                          element.simpleLikeCount = element.simpleLikeCount - 1;
                          element.isLiked = "dislike_simple_dislike";
                          element.likeCount.value = element.likeCount.value + 1;
                          element.likeCount.value--;
                        } else {
                          element.isLiked = "dislike_simple_dislike";
                          element.simpleLikeCount = 0;
                          element.likeCount.value = 0;
                        }
                      }
                    }
                    element.likeCount.refresh();
                  });
                  Get.find<ProfileController>().update();
                }
              });
            }
          } catch (_) {}
          try {
            if (Get.find<OtherUserController>().userPosts.isNotEmpty &&
                Get.find<OtherUserController>().userPosts.length > 0) {
              Get.find<OtherUserController>().userPosts.forEach((ele) {
                if (ele.postId == data["post_id"]
                    // postList[postIndex].postId
                    ) {
                  Get.find<OtherUserController>().userPosts.forEach((element) {
                    if (element.postId == data["post_id"]) {
                      if (data["type"] == "like_simple_like" ||
                          data["type"] == "love" ||
                          data["type"] == "thanks" ||
                          data["type"] == "lough" ||
                          data["type"] == "smile" ||
                          data["type"] == "excited" ||
                          data["type"] == "cry") {
                        element.simpleLikeCount = element.likeCount.value - 1;
                        element.isLiked = data["type"];
                        element.likeCount.value = element.likeCount.value - 1;
                        element.likeCount.value++;
                      } else if (data["type"] == "unlike") {
                        if (element.likeCount.value != 0) {
                          element.likeCount.value = element.likeCount.value + 1;
                          element.likeCount.value--;
                        } else {
                          element.isLiked = "dislike_simple_dislike";
                          element.simpleLikeCount = 0;
                          element.likeCount.value = 0;
                        }
                      }
                    }
                    element.likeCount.refresh();
                  });
                  Get.find<OtherUserController>().update();
                }
              });
            }
          } catch (_) {}

          try {
            if (Get.find<BrowseController>().browsePostList.isNotEmpty &&
                Get.find<BrowseController>().browsePostList.length > 0) {
              Get.find<BrowseController>().browsePostList.forEach((ele) {
                if (ele.postId == data["post_id"]
                    // postList[postIndex].postId
                    ) {
                  Get.find<BrowseController>()
                      .browsePostList
                      .forEach((element) {
                    if (element.postId == data["post_id"]) {
                      if (data["type"] == "like_simple_like" ||
                          data["type"] == "love" ||
                          data["type"] == "thanks" ||
                          data["type"] == "lough" ||
                          data["type"] == "smile" ||
                          data["type"] == "excited" ||
                          data["type"] == "cry") {
                        element.likeCount.value = element.likeCount.value - 1;
                        element.likeCount.value++;
                      } else if (data["type"] == "unlike") {
                        if (element.likeCount.value != 0) {
                          element.likeCount.value = element.likeCount.value + 1;
                          element.likeCount.value--;
                        } else {
                          element.likeCount.value = 0;
                        }
                      }
                    }
                    element.likeCount.refresh();
                  });
                }
              });
            }
          } catch (_) {}

          postList.forEach((ele) {
            if (ele.postId == data["post_id"])
            // postList[postIndex].postId
            {
              postList.forEach((element) {
                if (element.postId == data["post_id"]) {
                  // print("reactjjj  ${data["type"]}");

                  if (data["type"] == "like_simple_like" ||
                      data["type"] == "love" ||
                      data["type"] == "thanks" ||
                      data["type"] == "lough" ||
                      data["type"] == "smile" ||
                      data["type"] == "excited" ||
                      data["type"] == "cry" ||
                      data["type"] == "dislike_simple_dislike" ||
                      data["type"] == null) {
                    element.likeCount.value = element.likeCount.value - 1;
                    element.likeCount.value++;
                    // print(
                    //     "element.likeCount.value++ ${element.likeCount.value} ");
                    update();
                  } else if (data["type"] == "unlike") {
                    // print("dsfsdfsdf");

                    if (element.likeCount.value != 0) {
                      element.likeCount.value--;
                      update();
                    } else {
                      element.likeCount.value = 0;
                      update();
                    }
                  }
                }
                element.likeCount.refresh();
              });
            }
          });
          // }
        },
      );

      socket.on(
        'like_unlike_comment',
        (data) {
          if (Get.find<BrowseController>().browsePostList.isNotEmpty &&
              Get.find<BrowseController>().browsePostList.length > 0) {
            for (int i = 0;
                i <= Get.find<BrowseController>().browsePostList.length;
                i++) {
              if (Get.find<BrowseController>().browsePostList[i].postId ==
                  Get.find<BrowseController>()
                      .browsePostList[postIndex]
                      .postId) {
                Get.find<BrowseController>().browsePostList.forEach((element) {
                  if (data["type"] == "like") {
                    element.likeCount.value++;
                    element.likeCount.refresh();
                  } else if (data["type"] == "unlike") {
                    element.likeCount.value--;
                    element.likeCount.refresh();
                  }
                });
              }
            }
          }

          for (int i = 0; i <= postList.length; i++) {
            if (postList[i].postId == postList[postIndex].postId) {
              postList.forEach((element) {
                if (data["type"] == "like") {
                  element.likeCount.value++;
                  element.likeCount.refresh();
                } else if (data["type"] == "unlike") {
                  element.likeCount.value--;
                  element.likeCount.refresh();
                }
              });
            }
          }

          // update();
        },
      );

      socket.on('deleted_a_message', (data) {
        messages.removeWhere((element) =>
            element.id.toString() == data['message_id'].toString());
        update();
      });
      socket.on('comment_post', (data) {
        isSocketSuccess = false;
        // print(' INSIDE ON COMMENT SOCKET');

        postList.forEach((element) {
          // print('INSIDE FOR LOOP');
          if (element.postId.toString() == data["post_id"].toString()) {
            if (data["type"] == "create") {
              // print("reply kam ker rhy hain ");
              // print('REACHED HERRE');

              element.commentCount.value++;
              // print('DID NOT REACH HERE');
              element.isComment.value = false;
              element.commentCount.refresh();

              if (isPostDetails) {
                // print("reply kam ker rhy hain PPP ");

                // isPostDetails = false;

                // print("dataslug ${data["slug"]}");

                var comment = Comment.fromJson(data["slug"]);

                // print("comment hhh ${comment}");

                // print("datadfsfs ${data["in_reply_to_id"]}");

                if (data["in_reply_to_id"] == null ||
                    data["in_reply_to_id"] == "") {
                  // print('eeee');
                  selectedPost2[commentindex].commentCount.value++;
                  selectedPost2[commentindex].isComment.value = false;
                  selectedPost2[commentindex].commentCount.refresh();
                  //  selectedPost2[commentindex].comments.insert(0, comment);
                  Get.find<MobileCommentsController>().update();
                } else {
                  // selectedPost2[commentindex].comments.forEach((ele) {
                  //   if (ele.inReplyToId == data["in_reply_to_id"]) {
                  //
                  //     print("sdfsdfsdsfsdfsdfsdfs");
                  //     ele.replies.insert(0, comment);
                  //   }
                  // });
                }
              }
              // update();
              // element.comments.insert(0, Comment.fromJson(data["slug"]));
            }
          } else if (data["type"] == "delete") {
            if (selectedPost.commentCount.value != 0) {
              selectedPost.commentCount.value--;
              selectedPost.isComment.value = false;
              selectedPost.commentCount.refresh();
            } else {
              selectedPost.commentCount.value = 0;
              selectedPost.commentCount.refresh();
            }
          }
          // }
        });
        // }
        // });

        try {
          if (Get.find<ProfileController>().userPosts.isNotEmpty &&
              Get.find<ProfileController>().userPosts.length > 0) {
            Get.find<ProfileController>().userPosts.forEach((ele) {
              // for(int i = 0; i <= postList.length ; i++){
              // print("forloop iddd out " + data["post_id"].toString());
              // print("index id out" + ele.postId.toString());

              if (ele.postId.toString() == data["post_id"].toString()
                  // postList[postIndex].postId
                  ) {
                Get.find<ProfileController>().userPosts.forEach((element) {
                  if (element.postId.toString() == data["post_id"].toString()) {
                    if (data["type"] == "create") {
                      element.commentCount.value++;
                      element.isComment.value = false;
                      element.commentCount.refresh();
                      // element.comments.insert(0, Comment.fromJson(data["slug"]));
                    } else if (data["type"] == "delete") {
                      if (element.commentCount.value != 0) {
                        element.commentCount.value--;
                        element.isComment.value = false;
                        element.commentCount.refresh();
                      } else {
                        element.commentCount.value = 0;
                        element.commentCount.refresh();
                      }
                    }
                  }
                });
              }
            });
          }
        } catch (_) {}

        try {
          if (Get.find<SavedPostController>().savedPostList.isNotEmpty &&
              Get.find<SavedPostController>().savedPostList.length > 0) {
            Get.find<SavedPostController>().savedPostList.forEach((ele) {
              if (ele.postId.toString() == data["post_id"].toString()
                  // postList[postIndex].postId
                  ) {
                Get.find<SavedPostController>()
                    .savedPostList
                    .forEach((element) {
                  if (element.postId.toString() == data["post_id"].toString()) {
                    if (data["type"] == "create") {
                      element.commentCount.value++;
                      element.isComment.value = false;
                      element.commentCount.refresh();
                      // element.comments.insert(0, Comment.fromJson(data["slug"]));
                    } else if (data["type"] == "delete") {
                      if (element.commentCount.value != 0) {
                        element.commentCount.value--;
                        element.isComment.value = false;
                        element.commentCount.refresh();
                      } else {
                        element.commentCount.value = 0;
                        element.commentCount.refresh();
                      }
                    }
                  }
                });
              }
            });
          }
        } catch (_) {}
        try {
          if (Get.find<BrowseController>().browsePostList.isNotEmpty &&
              Get.find<BrowseController>().browsePostList.length > 0) {
            Get.find<BrowseController>().browsePostList.forEach((ele) {
              if (ele.postId.toString() == data["post_id"].toString()
                  // postList[postIndex].postId
                  ) {
                Get.find<BrowseController>().browsePostList.forEach((element) {
                  if (element.postId.toString() == data["post_id"].toString()) {
                    if (data["type"] == "create") {
                      element.commentCount.value++;
                      element.isComment.value = false;
                      element.commentCount.refresh();
                      // element.comments.insert(0, Comment.fromJson(data["slug"]));
                    } else if (data["type"] == "delete") {
                      if (element.commentCount.value != 0) {
                        element.commentCount.value--;
                        element.isComment.value = false;
                        element.commentCount.refresh();
                      } else {
                        element.commentCount.value = 0;
                        element.commentCount.refresh();
                      }
                    }
                  }
                });
              }
            });
          }
        } catch (_) {
          // ignore: unused_local_variable
          var slugData = data['slug'];
          if (data != null) {
            isSocketSuccess = true;
          }
          isCommentField.value = false;
          isCommentField.refresh();
        }
      });

      socket.on(
        'rebuzz_post',
        (data) {
          postList.forEach((ele) {
            if (ele.postId.toString() == data["post_id"].toString()
                // postList[postIndex].postId
                ) {
              postList.forEach((element) {
                if (element.postId.toString() == data["post_id"].toString()) {
                  if (data["slug"]["type"].toString() == "retweet") {
                    element.rebuzzCount.value++;
                    element.rebuzzCount.refresh();
                  } else if (data["slug"]["type"].toString() ==
                      "undo_retweet") {
                    if (element.rebuzzCount.value != 0) {
                      element.rebuzzCount.value--;
                      element.rebuzzCount.refresh();
                    } else {
                      element.rebuzzCount.value = 0;
                      element.rebuzzCount.refresh();
                    }
                  }
                }
              });
              update();
            }
          });
          try {
            if (Get.find<ProfileController>().userPosts.isNotEmpty &&
                Get.find<ProfileController>().userPosts.length > 0) {
              // print("profile py rebuzz pr aya hai");

              Get.find<ProfileController>().userPosts.forEach((ele) {
                if (ele.postId.toString() == data["post_id"].toString()
                    // postList[postIndex].postId
                    ) {
                  Get.find<ProfileController>().userPosts.forEach((element) {
                    if (element.postId.toString() ==
                        data["post_id"].toString()) {
                      if (data["slug"]["type"].toString() == "retweet") {
                        element.rebuzzCount.value++;
                        element.rebuzzCount.refresh();
                      } else if (data["slug"]["type"].toString() ==
                          "undo_retweet") {
                        if (element.rebuzzCount.value != 0) {
                          element.rebuzzCount.value--;
                          element.rebuzzCount.refresh();
                        } else {
                          element.rebuzzCount.value = 0;
                          element.rebuzzCount.refresh();
                        }
                      }
                    }
                  });
                  Get.find<ProfileController>().update();
                }
              });
            }
          } catch (_) {}

          try {
            if (Get.find<BrowseController>().browsePostList.isNotEmpty &&
                Get.find<BrowseController>().browsePostList.length > 0) {
              Get.find<BrowseController>().browsePostList.forEach((ele) {
                if (ele.postId.toString() == data["post_id"].toString()
                    // postList[postIndex].postId
                    ) {
                  Get.find<BrowseController>()
                      .browsePostList
                      .forEach((element) {
                    if (element.postId.toString() ==
                        data["post_id"].toString()) {
                      if (data["slug"]["type"].toString() == "retweet") {
                        element.rebuzzCount.value++;
                        element.rebuzzCount.refresh();
                      } else if (data["slug"]["type"].toString() ==
                          "undo_retweet") {
                        if (element.rebuzzCount.value != 0) {
                          element.rebuzzCount.value--;
                          element.rebuzzCount.refresh();
                        } else {
                          element.rebuzzCount.value = 0;
                          element.rebuzzCount.refresh();
                        }
                      }
                    }
                  });
                  Get.find<BrowseController>().update();
                  // update();
                }
              });
            }
          } catch (_) {}

          try {
            if (Get.find<SavedPostController>().savedPostList.isNotEmpty &&
                Get.find<SavedPostController>().savedPostList.length > 0) {
              Get.find<SavedPostController>().savedPostList.forEach((ele) {
                if (ele.postId.toString() == data["post_id"].toString()
                    // postList[postIndex].postId
                    ) {
                  Get.find<SavedPostController>()
                      .savedPostList
                      .forEach((element) {
                    if (element.postId.toString() ==
                        data["post_id"].toString()) {
                      if (data["slug"]["type"].toString() == "retweet") {
                        element.rebuzzCount.value++;
                        element.rebuzzCount.refresh();
                      } else if (data["slug"]["type"].toString() ==
                          "undo_retweet") {
                        if (element.rebuzzCount.value != 0) {
                          element.rebuzzCount.value--;
                          element.rebuzzCount.refresh();
                        } else {
                          element.rebuzzCount.value = 0;
                          element.rebuzzCount.refresh();
                        }
                      }
                    }
                  });
                  Get.find<SavedPostController>().update();
                }
              });
            }
          } catch (_) {}

          try {
            if (Get.find<ListController>().selectedList.newsfeed.isNotEmpty &&
                Get.find<ListController>().selectedList.newsfeed.length > 0) {
              Get.find<ListController>().selectedList.newsfeed.forEach((ele) {
                if (ele.postId.toString() == data["post_id"].toString()
                    // postList[postIndex].postId
                    ) {
                  Get.find<ListController>()
                      .selectedList
                      .newsfeed
                      .forEach((element) {
                    if (element.postId.toString() ==
                        data["post_id"].toString()) {
                      if (data["slug"]["type"].toString() == "retweet") {
                        element.rebuzzCount.value++;
                        element.rebuzzCount.refresh();
                      } else if (data["slug"]["type"].toString() ==
                          "undo_retweet") {
                        if (element.rebuzzCount.value != 0) {
                          element.rebuzzCount.value--;
                          element.rebuzzCount.refresh();
                        } else {
                          element.rebuzzCount.value = 0;
                          element.rebuzzCount.refresh();
                        }
                      }
                    }
                  });
                  Get.find<ListController>().update();
                }
              });
            }
          } catch (_) {}
          try {
            if (Get.find<OtherUserController>().userPosts.isNotEmpty &&
                Get.find<OtherUserController>().userPosts.length > 0) {
              // print("profile py rebuzz pr aya hai");

              Get.find<OtherUserController>().userPosts.forEach((ele) {
                if (ele.postId.toString() == data["post_id"].toString()
                    // postList[postIndex].postId
                    ) {
                  Get.find<OtherUserController>().userPosts.forEach((element) {
                    if (element.postId.toString() ==
                        data["post_id"].toString()) {
                      if (data["slug"]["type"].toString() == "retweet") {
                        element.rebuzzCount.value++;
                        element.rebuzzCount.refresh();
                      } else if (data["slug"]["type"].toString() ==
                          "undo_retweet") {
                        if (element.rebuzzCount.value != 0) {
                          element.rebuzzCount.value--;
                          element.rebuzzCount.refresh();
                        } else {
                          element.rebuzzCount.value = 0;
                          element.rebuzzCount.refresh();
                        }
                      }
                    }
                  });
                  Get.find<OtherUserController>().update();
                }
              });
            }
          } catch (_) {}
        },
      );

      // socket.on('new_message', (data) => print(data));
      socket.onDisconnect((_) {
        // print('disconnect');
      });
      // socket.on('fromServer', (_) => print(_));
    } catch (e) {
      print("Socket Error: $e");
    }
  }

  // Convert Map to List of Images
  mapToList(post) {
    imagesListForCarousel.clear();
    for (int i = 0; i < post.postFiles.length; i++) {
      imagesListForCarousel.add(post.postFiles[i]['file_path']);
    }
  }

// Convert Map to List of Videos
  maptoListForVideos(post) {
    videoListForCarousel.clear();
    for (int i = 0; i < post.postFiles.length; i++) {
      videoListForCarousel.add(post.postFiles[i]['file_path']);
    }
  }

  //send message
  Future<void> sendMessage(
      {ChatUserModel chatData,
      MessageModel messageData,
      Map<String, String> FileData,
      String thumbnailUrl,
      int conversationId,
      int messageId,
      ChatScrappingData scrappingData,
      String fileEx = '.png',
      String textMessage}) {
    // print(FileData);
    // print(conversationId);

    // print("thumbnail");
    // print(thumbnailUrl == null ? [].toString() : [thumbnailUrl].toString());
    // print("thumbnail");
    // String time = DateTime.now().timeZoneOffset.toString();

    // if (!time.contains('-')) {
    //   time = time[0];
    //   time = '+' + time;
    // } else {
    //   time = time[1];
    // }
    // print("emit called of Send Message" + messageId.toString());

    socket.emit('new_message', {
      "body": messageData != null
          ? messageData.body.trim()
          : messageController.text != ''
              ? "${messageController.text.trim()}"
              : textMessage,
      "conversation_id":
          messageData != null ? conversationId : chatData.conversationId,
      "post_type": 'post',
      "starting_point_id": 1,
      "mode": messageId == null ? 'new' : 'edit',
      "message_to_be_edited": messageId != null ? messageId : null,
      "link": scrappingData != null ? scrappingData.link : null,
      "link_title": scrappingData != null ? scrappingData.title : null,
      "link_meta": scrappingData?.meta,
      "link_image": scrappingData != null ? scrappingData.images[0] : null,
      "replied_to_message_id": replyToMsgModel?.id,
      // "GMT": time + ':00',
      "uploads": FileData.isNotEmpty ? [FileData] : [],

      // 'uploads': messageData != null
      //     ? messageData.messageFiles
      //     : fileUrl == null
      //         ? null
      //         : [
      //             {'path': fileUrl, 'name': 'fileName$fileEx'}
      //           ],
      // 'thumbnail_url': thumbnailUrl == null ? [] : [thumbnailUrl,]
    });
    videoBytesChat = null;
    imageBytesChat = null;
    isVideoPickedChat = false;
    isImagePickedChat = false;
    documentBytesChat = null;
    isDocumentPickedChat = false;
    replyToMsgModel = null;

    update();

    return null;
  }

  Future<void> chatReactionsEmit(
      {String reactionType, int conversationId, int messageId}) {
    // print(" Reactions emit called -  ${storage.read('token')}");
    // print("reactionType : " + reactionType.toString());
    // print("conversationId : " + conversationId.toString());
    // print("messageId : " + messageId.toString());

    socket.emit('message_recation', {
      "reactionType": reactionType,
      "messageID": messageId,
      "conversationID": conversationId,
    });
    messages.forEach((element) {
      if (element.id == messageId) {
        Map<String, dynamic> reactionInfoMap = {
          "message_id": messageId,
          "type": reactionType,
          "id": userProfile.userId,
          "firstname": userProfile.firstname,
          "lastname": userProfile.lastname,
          "username": userProfile.username,
          "profile_image": userProfile.profileImage
        };
        int index = -1;
        if (element.reactionInfo != null) {
          index = element.reactionInfo
              .indexWhere((item) => item.id == userProfile.userId);
        }

        // var oldReact = element.reactionInfo.where((element) => element.id == userProfile.userId);
        if (index < 0) {
          if (element.reactionInfo == null) {
            element.reactionInfo =
                List.generate(1, (index) => Member.fromJson(reactionInfoMap));
          } else {
            element.reactionInfo.insert(0, Member.fromJson(reactionInfoMap));
          }
        } else {
          if (reactionType == "dislike") {
            element.reactionInfo.removeAt(index);
          } else {
            element.reactionInfo[index] = Member.fromJson(reactionInfoMap);
          }
        }

        update();
      }
    });

    update();

    return null;
    // socket.emitWithAck('message_reaction', {
    // "reactionType": reactionType,
    // "conversationID": conversationId,
    // "messageID": messageId,
    // }, ack: (data) {
    //   print('ack $data') ;
    //   // if (data != null) {
    //   //   print('from server $data');
    //   // } else {
    //   //   print("Null") ;
    //   // }
    // });
  }

  // ignore: missing_return
  Future<void> sendStatus(messageId, memberId, conversationId, serderId) {
    if (messages[0].userId.toString() == memberId) if (serderId !=
        storage.read("id")) {
      socket.emit("message_seen_send", {
        "message_id": messageId,
        "member_id": memberId,
        "conversation_id": conversationId,
      });
    }
  }

  //Message Status

  Future<void> messageStatus(conversationId, messageId) async {
    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      // "Access-Control-Allow-Origin": "*",
    };
    try {
      var request = http.MultipartRequest(
          'POST', Uri.parse(Url.chatBaseUrl + 'message_status'));
      request.headers.addAll(headers);

      request.fields['conversation_id'] = conversationId.toString();
      request.fields['message_id'] = messageId.toString();
      var response = await request.send();
      if (response.statusCode == 200) {}
      response.stream.bytesToString().asStream().listen((event) {
        var parsedJson = json.decode(event);

        return parsedJson['meta']['code'];
      });
    } catch (_) {
      update();
    }
  }

  // LIKE UNLIKE SOCKETS
  Future<void> likeUnlike(
      String reactionType, var postId, Map<String, dynamic> data) async {
    // print(" LIKE emit called");

    if (!kIsWeb) {
      // print("reactionsas");
      // if (await UtilsMethods.checkInternet()) {
      socket.emit('like_unlike_post', {
        'user_id': storage.read('id'),
        'post_id': postId,
        'type': reactionType,
        'slug': data,
      });
      //log('data>>> $data');
      // } else {
      //   if (!kIsWeb) {
      //     Get.snackbar('Alert: ', 'Internet not connected!',
      //         snackPosition: SnackPosition.BOTTOM);
      //   }
      // }
      // return null;
    } else {
      // print("reactionType    $reactionType");

      socket.emit('like_unlike_post', {
        'user_id': storage.read('id'),
        'post_id': postId,
        'type': reactionType,
        'slug': data,
      });

      //log('data>>> $data');
    }
  }

  Future<void> deleteMsg(int msgId, bool delMultiple, {List<int> multipleIds}) {
    socket.emit('delete_message', {
      'message_id': msgId,
      'delete_multiple': delMultiple,
      'multiple_delete_message_ids': multipleIds,
    });
    messages.removeWhere((element) => element.id == msgId);
    update();
    print(" Delete emit called");

    return null;
  }

  Future<void> deleteMessageForYou(int msgId) async {
    // debugPrint("deleteMessageForYou API called");
    try {
      var data = {
        "message_id": msgId,
      };
      _dio.Dio dio = _dio.Dio();

      _dio.Response response = await dio.post(
        Url.deleteMessageForMe,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
          "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        data: data,
      );
      // print("deleteMessageForMe body : " + response.toString());
      if (response.statusCode == 200) {
        messages.removeWhere((element) => element.id == msgId);
        update();
      }
    } catch (e) {
      // print(e.toString());
    }
  }

  // LIKE UNLIKE COMMENTS SOCKETS
  Future<void> likeUnlikeComment() {
    // print(" LIKE COMMENTS called");
    socket.emit('like_unlike_comment', {
      'user_id': storage.read('id'),
      'post_id': 567,
      'comment_id': 184,
      'type': 'like',
      'slug': 'place_holder',
    });

    return null;
  }

  int commentindex = 0;

  //CREATE DELETE COMMENTS SOCKETS
  Future<void> createDeleteComment(int postId, String profileImage,
      String comment, String type, dynamic commentData) {
    // replyMentionTag.insert(0, false);
    socket.emit('comment_post', {
      'user_id': storage.read('id'),
      'username': userName,
      'profile_image': profileImage,
      'post_id': postId.toString(),
      'comment': comment,
      'type': type,
      'slug': commentData,
    });

    return null;
  }

  // CREATE DELETE BUZZ SOCKETS
  Future<void> createDeleteBuzz(String type, Post post) {
    // print(" REBUZZ called");
    socket.emit('rebuzz_post', {
      'user_id': storage.read('id'),
      'username': 'data.username',
      'post_id': post.postId.toString(),
      'slug': {"type": type},
    });

    return null;
  }

  // Convert Map to List of Images
//   mapToList(post) {
//     imagesListForCarousel.clear();
//     for (int i = 0; i < post.postFiles.length; i++) {
//       imagesListForCarousel.add(post.postFiles[i]['file_path']);
//     }
//   }
//
// // Convert Map to List of Videos
//   maptoListForVideos(post) {
//     videoListForCarousel.clear();
//     for (int i = 0; i < post.postFiles.length; i++) {
//       videoListForCarousel.add(post.postFiles[i]['file_path']);
//     }
//     print(videoListForCarousel);
//   }

  //get message
  Future<void> getMessages() {
    // print("callsed");
    // socket.on('new_message', (data) => streamSocket.addResponse);
    return null;
  }

  Future<List<Post>> fetchPosts() async {
    _posts = await getNewsFeed();
    postList = await getNewsFeed();

    update();

    // _posts.addAll(posts);
    return _posts;
  }

  Future<List<BlockedUser>> fetchBlockedUsers() async {
    isBlockedUsersLoading = true;
    update();

    blockedUser = await getBlockedUsersList();
    if (blockedUser != null) {
      if (blockedUser.isNotEmpty) {
        blockedUser.sort((a, b) => a.username.compareTo(b.username));
      }
    }

    isBlockedUsersLoading = false;
    update();
    return blockedUser;
  }

  // toggleComment() {
  //   isCommentField = !isCommentField;
  //   update();
  //   print(isCommentField);
  // }
  Future<List<Post>> getNewsFeed(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false}) async {
    try {
      if (reload) {
        if (!isNewsfeedLoading) isNewsfeedLoading = true;

        if (isPullToRefresh) {
          isNewsfeedLoading = false;
        }
        postList = [];
        update();
      }
      String url = Url.newsfeedRedisUrl;
      if (isLoading) {
        LoggingUtils.printValue("URL AFTER APPEND", url);


        var uri = Uri.parse(url);
        var response = await api.post(uri, token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        /*print("<============= NEWS FEED RESPONSE ISLOADING ===========>");
        print(response);*/
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;
          // print('first screen call it');
          List<Post> post = [];
          postList = [];
          postList = postData.map((e) => Post.fromJson(e)).toList();

          postList.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            //
            //
            // });

            element.reactionType.refresh();
            // if (element.isLiked == nul) {
            //   element.like.value = true;
            //
            // }
          });

          // print('IDHAR BHI');
          update();
        }else{
          isNewsfeedLoading = false;
          return null;
        }
      }

      var response = await api.post(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });

      /*print("<============= NEWS FEED HEADERS ===========>");
      print(storage.read('token'));*/

      /*print("<============= NEWS FEED RESPONSE NOT LOADING ===========>");
      print(response);*/
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isNewsfeedLoading = false;

        var postData = posts['data'] as List;

        /*print("<========= POST LENGTH =========>");
        print(postData.length);*/
        List<Post> post = [];

        if (shouldUpdate) {
          postList = [];
          update();
          shouldUpdate = false;

          postList = postData.map((e) => Post.fromJson(e)).toList();

          postList.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;


            element.reactionType.refresh();

          });
          update();
        } else if (newsFeedMobile) {

          update();
          newsFeedMobile = false;

          postList = postData.map((e) => Post.fromJson(e)).toList();

          postList.forEach((element) {
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;


            element.reactionType.refresh();
          });
          update();
        }

        try {
          postData.forEach((element) {
            /*print("<========= POST DATA =========>");
            print(postData.length);
            print(element);*/
            var data = Post.fromJson(element);


            post.add(data);
          });
        }catch(e){
          print("<====== EXCEPTION LOOP ========>");
          print(e);
          isNewsfeedLoading = false;
          return null;
        }

        post.forEach((element) {
          // print('first screen1');
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();

          // element.reactionCheck.value = false;
          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
        // shared.setString("post", post.toString());


        return post;
      } else {

        isNewsfeedLoading = false;
        return null;
      }
    } catch (e) {
      print("<========== EXCEPTION NEWS FEEDS=======>");
       print(e);
      isNewsfeedLoading = false;
       return null;
    }
  }

  Future<List<Post>> getNewsFeedFollowing(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false}) async {
    try {
      if (reload) {
        if (!isNewsFeedFollowingLoading) isNewsFeedFollowingLoading = true;

        if (isPullToRefresh) {
          isNewsFeedFollowingLoading = false;
        }
        postListFollowing = [];
        update();
      }
      //String url = Url.newsfeedUrl + "?page_no=1&tab=following";
      String url = Url.newsfeedRedisUrl;
      if (isLoading) {
        var response = await api.post(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },queryParameters: {"tab":"following","page_no":"1"});
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;
          // print('first screen call it');
          List<Post> post = [];
          postListFollowing = [];
          postListFollowing = postData.map((e) => Post.fromJson(e)).toList();

          postListFollowing.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }else{
          isNewsFeedFollowingLoading = false;
          return null;
        }
      }

      var response = await api.post(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },queryParameters: {"tab":"following","page_no":"1"});
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isNewsFeedFollowingLoading = false;

        var postData = posts['data'] as List;
        // print('first screen call it');
        List<Post> post = [];

        if (shouldUpdate) {
          postListFollowing = [];
          // print('list Update into ');
          update();
          // print('INSIDE SHOULD UPDATE');
          shouldUpdate = false;

          postListFollowing = postData.map((e) => Post.fromJson(e)).toList();

          postListFollowing.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListFollowing = postData.map((e) => Post.fromJson(e)).toList();

          postListFollowing.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          // print('first screen1');
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });

        return post;
      } else {
        isNewsFeedFollowingLoading = false;
        return null;
      }
    } catch (e) {
      isNewsFeedFollowingLoading = false;
      print(e);
      return null;

    }
  }

  Future<List<Post>> getPostListOne(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false,
      int postListID}) async {
    try {
      if (reload) {
        if (!isPostListOneLoading) isPostListOneLoading = true;

        if (isPullToRefresh) {
          isPostListOneLoading = false;
        }
        postListOne = [];
        update();
      }
      String url = Url.newsfeedUrl + "?page_no=1&tab=list&list_id=$postListID";
      if (isLoading) {
        var response = await api.get(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;
          List<Post> post = [];
          postListOne = [];
          postListOne = postData.map((e) => Post.fromJson(e)).toList();

          postListOne.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else {
          isPostListOneLoading = false;
        }
      }

      var response = await api.get(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isPostListOneLoading = false;

        var postData = posts['data'] as List;
        // print('first screen call it');
        List<Post> post = [];

        if (shouldUpdate) {
          postListOne = [];
          // print('list Update into ');
          update();
          // print('INSIDE SHOULD UPDATE');
          shouldUpdate = false;

          postListOne = postData.map((e) => Post.fromJson(e)).toList();

          postListOne.forEach((element) {
            // /'first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListOne = postData.map((e) => Post.fromJson(e)).toList();

          postListOne.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          // print('first screen1');
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });
        postListOne = post;
        update();
        return post;
      } else {
        isPostListOneLoading = false;
        update();
        return postListOne;
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION POST LIST ONE", e);
      // print(e);
    }
  }

  Future<List<Post>> getPostListTwo(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false,
      int postListID}) async {
    try {
      if (reload) {
        if (!isPostListTwoLoading) isPostListTwoLoading = true;

        if (isPullToRefresh) {
          isPostListTwoLoading = false;
        }
        postListTwo = [];
        update();
      }
      String url = Url.newsfeedUrl + "?page_no=1&tab=list&list_id=$postListID";
      if (isLoading) {
        var response = await api.get(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;
          // print('first screen call it');
          List<Post> post = [];
          postListTwo = [];
          postListTwo = postData.map((e) => Post.fromJson(e)).toList();

          postListTwo.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          isPostListTwoLoading = false;

          update();
        } else {
          isPostListTwoLoading = false;
          update();
          return postListTwo;
        }
      }

      var response = await api.get(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isPostListTwoLoading = false;

        var postData = posts['data'] as List;
        // print('first screen call it');
        List<Post> post = [];

        if (shouldUpdate) {
          postListTwo = [];
          // print('list Update into ');
          update();
          // print('INSIDE SHOULD UPDATE');
          shouldUpdate = false;

          postListTwo = postData.map((e) => Post.fromJson(e)).toList();

          postListTwo.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListTwo = postData.map((e) => Post.fromJson(e)).toList();

          postListTwo.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          // print('first screen1');
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });
        postListTwo = post;

        update();
        return post;
      } else {
        isPostListTwoLoading = false;
        update();
        return postListTwo;
      }
    } catch (e) {
      isPostListTwoLoading = false;
      update();
      return postListTwo;
      // print(e);
    }
  }

  Future<List<Post>> getPostListThree(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false,
      int postListID}) async {
    try {
      if (reload) {
        if (!isPostListThreeLoading) isPostListThreeLoading = true;

        if (isPullToRefresh) {
          isPostListThreeLoading = false;
        }
        postListThree = [];
        update();
      }
      String url = Url.newsfeedUrl + "?page_no=1&tab=list&list_id=$postListID";
      if (isLoading) {
        var response = await api.get(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;
          // print('first screen call it');
          List<Post> post = [];
          postListThree = [];
          postListThree = postData.map((e) => Post.fromJson(e)).toList();

          postListThree.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }
      }

      var response = await api.get(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isPostListThreeLoading = false;

        var postData = posts['data'] as List;
        // print('first screen call it');
        List<Post> post = [];

        if (shouldUpdate) {
          postListThree = [];
          // print('list Update into ');
          update();
          // print('INSIDE SHOULD UPDATE');
          shouldUpdate = false;

          postListThree = postData.map((e) => Post.fromJson(e)).toList();

          postListThree.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListThree = postData.map((e) => Post.fromJson(e)).toList();

          postListThree.forEach((element) {
            // print('first screen2');
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          // print('first screen1');
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });
        postListThree = post;
        update();
        return post;
      } else {
        isPostListThreeLoading = false;
        update();
        return postListThree;
      }
    } catch (e) {
      // print(e);
      isPostListThreeLoading = false;
      update();
      return postListThree;
    }
  }

  Future<List<Post>> getPostListFour(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false,
      int postListID}) async {
    try {
      if (reload) {
        if (!isPostListFourLoading) isPostListFourLoading = true;

        if (isPullToRefresh) {
          isPostListFourLoading = false;
        }
        postListFour = [];
        update();
      }
      String url = Url.newsfeedUrl + "?page_no=1&tab=list&list_id=$postListID";
      if (isLoading) {
        var response = await api.get(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;

          postListFour = [];
          postListFour = postData.map((e) => Post.fromJson(e)).toList();

          postListFour.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }
      }

      var response = await api.get(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isPostListFourLoading = false;

        var postData = posts['data'] as List;
        List<Post> post = [];

        if (shouldUpdate) {
          postListFour = [];
          update();
          shouldUpdate = false;

          postListFour = postData.map((e) => Post.fromJson(e)).toList();

          postListFour.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListFour = postData.map((e) => Post.fromJson(e)).toList();

          postListFour.forEach((element) {
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });
        postListFour = post;
        return post;
      } else {
        isPostListFourLoading = false;
        update();
        return postListFour;
      }
    } catch (e) {
      // print(e);
      isPostListFourLoading = false;
      update();
      return postListFour;
    }
  }

  Future<List<Post>> getPostListFive(
      {bool reload = true,
      shouldUpdate = false,
      newsFeedMobile = false,
      isPullToRefresh = false,
      isLoading = false,
      int postListID}) async {
    try {
      if (reload) {
        if (!isPostListFiveLoading) isPostListFiveLoading = true;

        if (isPullToRefresh) {
          isPostListFiveLoading = false;
        }
        postListFive = [];
        update();
      }
      String url = Url.newsfeedUrl + "?page_no=1&tab=list&list_id=$postListID";
      if (isLoading) {
        var response = await api.get(Uri.parse(url), token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });
        var posts = json.decode(response);
        if (posts["meta"]["code"] == 200) {
          var postData = posts['data'] as List;

          postListFive = [];
          postListFive = postData.map((e) => Post.fromJson(e)).toList();

          postListFive.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }
      }

      var response = await api.get(Uri.parse(url), token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      });
      var posts = json.decode(response);
      if (posts["meta"]["code"] == 200) {
        isPostListFiveLoading = false;

        var postData = posts['data'] as List;
        List<Post> post = [];

        if (shouldUpdate) {
          postListFive = [];
          update();
          shouldUpdate = false;

          postListFive = postData.map((e) => Post.fromJson(e)).toList();

          postListFive.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        } else if (newsFeedMobile) {
          update();
          newsFeedMobile = false;

          postListFive = postData.map((e) => Post.fromJson(e)).toList();

          postListFive.forEach((element) {
            threadNumber = element.thread_no;
            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            element.reactionType.refresh();
          });
          update();
        }

        postData.forEach((element) {
          var data = Post.fromJson(element);

          post.add(data);
        });

        post.forEach((element) {
          threadNumber = element.thread_no;
          // print('thread number:${threadNumber}');
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;

          element.reactionType.value = element.isLiked;

          element.reactionCheck.refresh();
        });
        postListFive = post;
        update();
        return post;
      } else {
        isPostListFiveLoading = false;
        update();
        return postListFive;
      }
    } catch (e) {
      // print(e);
      isPostListFiveLoading = false;
      update();
      return postListFive;
    }
  }

  Future verificationAccount() async {
    verificationCheck = false;
    update();
    var response = await api.get(Uri.parse(Url.verificationAccount), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });
    var data = json.decode(response);
    // print("response data  $data");
    if (data["meta"]["code"] == 200) {
      verification = data['data']["account_verified"];
    }
  }

  Future<dynamic> getPostHistory({int postId}) async {
    // isNewsfeedLoading = true;

    // isViewEditHistoryLoading = true;
    update();
    // print(postId);

    if (kIsWeb) {
      try {
        var response = await http.post(
          Uri.parse(Url.viewEditHistory),
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': userToken.toString(),
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: jsonEncode(
            {
              'post_id': postId,
            },
          ),
        );

        // print("view history response : ${response.body}");
        var viewEditHistory_ = json.decode(response.body);

        if (viewEditHistory_["meta"]["code"] == 200) {
          var viewEditHistory = viewEditHistoryFromJson(response.body);
          ViewEditHistory _viewEditHistory;
          _viewEditHistory = viewEditHistory;
          isNewsfeedLoading = false;
          update();
          return _viewEditHistory;
        }

        if (viewEditHistory_["meta"]["code"] == 400) {
          // print("agiya hai idhar");
          noEditHistoryMessage = viewEditHistory_["meta"]["message"];
          // print(noEditHistoryMessage);

          // print(" guzr giya hai idhar");

          // ViewEditHistory _viewEditHistory ;

          //  _viewEditHistory= viewEditHistory;
          isNewsfeedLoading = false;
          update();
          return null;

          // Get.snackbar(
          //   "",null,
          //   messageText: Text(
          //     "${viewEditHistory_["meta"]["message"]}",
          //     style: TextStyle(
          //       fontSize: 20,
          //       fontWeight: FontWeight.bold,
          //     ),
          //   ),
          //   colorText: Colors.black,
          //   duration: const Duration(milliseconds: 4000),
          // );

          // isViewEditHistoryLoading = false;
          // update();

          isNewsfeedLoading = false;
          update();
          return null;
        }
      } catch (e) {
        // print(e.toString());
      }
    } else {
      bool checkInternet = false;
      checkInternet = await UtilsMethods.checkInternet();
      if (checkInternet == true) {
        try {
          var response = await http.post(
            Uri.parse(Url.viewEditHistory),
            headers: <String, String>{
              'Content-Type': 'application/json',
              'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
              'Token': userToken.toString(),
              'X-Requested-With': 'XMLHttpRequest',
            },
            body: jsonEncode(
              {
                'post_id': postId,
              },
            ),
          );

          // print("view history response : ${response.body}");
          var viewEditHistory_ = json.decode(response.body);
          if (viewEditHistory_["meta"]["code"] == 200) {
            var viewEditHistory = viewEditHistoryFromJson(response.body);
            ViewEditHistory _viewEditHistory;
            _viewEditHistory = viewEditHistory;
            isNewsfeedLoading = false;
            update();
            return _viewEditHistory;
          }

          if (viewEditHistory_["meta"]["code"] == 400) {
            // print("andr nhi aya");
            Get.snackbar(
              "",
              null,
              messageText: Text(
                "${viewEditHistory_["meta"]["message"]}",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              colorText: Colors.black,
              duration: const Duration(milliseconds: 4000),
            );

            // isViewEditHistoryLoading = false;
            // update();
            isNewsfeedLoading = false;
            update();
            return null;
          }
        } catch (e) {
          // print(e.toString());
        }
      } else {
        // isViewEditHistoryLoading = false;
        // update();
        isNewsfeedLoading = false;
        update();
        return null;
      }
    }
  }

  // Fetch Server Languages
  Future<LanguageModel> getLanguages({bool isUpdate = true}) async {
    if (!kIsWeb) {
      var myLanguageObj =
          await DatabaseHelper.instance.queryAllRows(DatabaseHelper.myLang);
      //log('myLanguageObj 1::: $myLanguageObj');
      if (!await UtilsMethods.checkInternet()) {
        myLanguageObj.forEach((element) {
          //log('myLanguageObj 2::: $element');
          //log('myLanguageObj 2::: ${element['pivot'].runtimeType}');
          Lang myLang = Lang.fromLocalDbJson(element);
          languageData = LanguageModel();
          languageData.myLang = myLang;
          //log('myLanguageObj 3::: $myLang');
        });
        update();
      }
    }
    // if (reload) {
    //   if (!isNewsfeedLoading) isNewsfeedLoading = true;
    //   postList = [];
    //   update();
    // }
    // print("newsfeed getting");
    // print("languagesssssssssssssss");
    isLang = true;
    // update();
    var response = await api.get(Uri.parse(Url.getLanguageUrl), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    //debugPrint("lang response : $response");
    var languages = json.decode(response);
    // var languagesData = languages['data'] as List;

    if (languages["meta"]["code"].toString() == "200") {
      // print("LanguageModel:::: ${languages["data"]}");
      //debugPrint("Lang: ${languages['data']}");
      isLang = false;
      languageData = LanguageModel.fromJson(languages['data']);
      languageData.pinnedLists = languageData.pinnedLists.take(5).toList();
      //log('mylang::: ${languageData.appLang.toJson()}');
      if (!kIsWeb)
        DatabaseHelper.instance
            .insert(DatabaseHelper.myLang, languageData.myLang.toLocalDBMap());
      // update();
      update();
    } else {
      languageData = null;
      languageData.allLangs = [];
      isLang = false;
      update();
    }
    update();
    return languageData;
  }

  bool languageLoader = false;

  Future<TranslationData> newsFeedTranslation(
      int postId, String langCode) async {
    // languageLoader = true;
    // update();
    // print(postId.toString());

    var response = await api.get(
        Uri.parse(
            Url.baseUrl + "translate-post/${postId.toString()}/$langCode"),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        });

    var translation = json.decode(response);
    // var languagesData = languages['data'] as List;

    if (translation["meta"]["code"].toString() == "200") {
      translationData = TranslationData.fromJson(translation);

      // update();
      // languageLoader = false;
      // update();
      return translationData;
    } else {
      // print("sdfsdsfdfsdfsdfsdfsfd");
      return null;
    }
  }

  // Push Server Languages Request
  Future<void> languagesRequest(
      {languageId,
      autoTranslate = 0,
      appLanguageId,
      appLanguage,
      appLanguageCode}) async {
    // print("userToken.toString()");
    // print(userToken.toString());
    // print("userToken.toString()");
    List appLanguageList = [];
    appLanguageList.add(appLanguage);
    appLanguageList.add(appLanguageCode);
    appLanguageList.add(appLanguageId.toString());
    // print("kjlkjkljlkjlkjlk" + appLanguageList.toString());
    var response =
        await api.post(Uri.parse(Url.languageRequestUrl), queryParameters: {
      'language_id': languageId.toString(),
      'auto_translate': autoTranslate.toString(),
      // if(appLanguageId != null){
      "app_language_id": appLanguageId == null
          ? languageData.appLang.id.toString()
          : appLanguageId.toString(),
      'app_language_info[0]': appLanguageList[0] == null
          ? languageData.appLang.name
          : appLanguageList[0],
      // appLanguageId == null
      //     ? languageData.appLanguageSettings.id.toString()
      //     : appLanguageList.toString(),
      "app_language_info[1]": appLanguageList[1] == null
          ? languageData.appLang.code
          : appLanguageList[1],
      "app_language_info[2]": appLanguageList[2] == null
          ? languageData.appLang.id.toString()
          : appLanguageList[2].toString(),
      // }
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    // print("languagejsonResponse");
    print("lang res: " + jsonResponse.toString());
    // print("languagejsonResponse");
    if (jsonResponse["meta"]["code"] == 200) {}
  }

  // bool isPagedLoad = false;

  int pgCount = 0;

  Future<List<Post>> getNewsFeedPagged({int page}) async {
    // print("length ${postList.length}");
    // print("page  $page");
    // NativeAd _ad;
    // AdHelper _adHelper = AdHelper();
    // DateTime timeBeforeApiCalling = DateTime.now();
    // String formattedDate =
    //     DateFormat('kk:mm:ss \n EEE d MMM').format(timeBeforeApiCalling);
    // print('TIME BEFORE API CALLING     ' + formattedDate);

    // postList =[];
    String url = Url.newsfeedRedisUrl;

    var response = await api.post(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    },queryParameters: {"page_no":page.toString()});
    // DateTime timeAfterApiCalling = DateTime.now();
    // String formattedDated =
    //     DateFormat('kk:mm:ss \n EEE d MMM').format(timeAfterApiCalling);
    // print('TIME After API CALLING     ' + formattedDated);

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        // posts['data'].forEach((element) {
        //   var postData = posts['data'] as List;
        //   List<Post> notiList = postData.map((e) => Post.fromJson(e)).toList();
        //   postList.addAll(notiList);
        // });
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postList.addAll(postList2);

          postList.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;

            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value = element.simpleLikeCount;
            // });
          });
          // for (int i = 0; i < postList.length; i++)
          //   postList.forEach((element) {
          //     ads.add(
          //       BannerAd(
          //         size: AdSize.banner,
          //         adUnitId: AdHelper.bannerAdUnitId,
          //         // factoryId: 'listTile',
          //         request: AdRequest(),
          //         listener: _adHelper.adListener,
          //       )..load(),
          //     );
          //   });
        }
      }
    }

    try {
      if (postList.length > 0) {
        // print('newsfeedApi hit1 ');
        postList.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          // });
          element.reactionType.refresh();

          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
      }
    } catch (_) {}
    // isAdLoaded = false;
    // AdHelper _adHelper = AdHelper();
    // ads.insert(
    //   0,
    //   NativeAd(
    //     adUnitId: AdHelper.bannerAdUnitId,
    //     factoryId: 'listTile',
    //     request: AdRequest(),
    //     listener: _adHelper.adListener,
    //   )..load(),
    // );
    update();
    return postList;
  }

  Future<List<Post>> getNewsFeedPagedFollowing({int page}) async {
    // String url = Url.newsfeedUrl + "?page_no=${page.toString()}&tab=following";
    String url = Url.newsfeedRedisUrl;

    var response = await api.post(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    },queryParameters: {"tab":"following","page_no":page.toString()});

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListFollowing.addAll(postList2);

          postListFollowing.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListFollowing.length > 0) {
        postListFollowing.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListFollowing;
  }

  Future<List<Post>> getNewsFeedPagedListOne({int page, int listID}) async {
    String url = Url.newsfeedUrl +
        "?page_no=${page.toString()}&tab=list&list_id=$listID";

    var response = await api.get(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListOne.addAll(postList2);

          postListOne.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListOne.length > 0) {
        postListOne.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListOne;
  }

  Future<List<Post>> getNewsFeedPagedListTwo({int page, int listID}) async {
    String url = Url.newsfeedUrl +
        "?page_no=${page.toString()}&tab=list&list_id=$listID";

    var response = await api.get(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListTwo.addAll(postList2);

          postListTwo.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListTwo.length > 0) {
        postListTwo.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListTwo;
  }

  Future<List<Post>> getNewsFeedPagedListThree({int page, int listID}) async {
    String url = Url.newsfeedUrl +
        "?page_no=${page.toString()}&tab=list&list_id=$listID";

    var response = await api.get(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListThree.addAll(postList2);

          postListThree.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListThree.length > 0) {
        postListThree.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListThree;
  }

  Future<List<Post>> getNewsFeedPagedListFour({int page, int listID}) async {
    String url = Url.newsfeedUrl +
        "?page_no=${page.toString()}&tab=list&list_id=$listID";

    var response = await api.get(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListFour.addAll(postList2);

          postListFour.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListFour.length > 0) {
        postListFour.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListFour;
  }

  Future<List<Post>> getNewsFeedPagedListFive({int page, int listID}) async {
    String url = Url.newsfeedUrl +
        "?page_no=${page.toString()}&tab=list&list_id=$listID";

    var response = await api.get(Uri.parse(url), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    });

    var posts = json.decode(response);
    if (posts['meta']["code"] == 200) {
      if (posts['data'] != null) {
        var postData = posts['data'] as List;
        if (page != 1) {
          List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();

          postListFive.addAll(postList2);

          postListFive.forEach((element) {
            threadNumber = element.thread_no;

            element.rebuzz.value = element.isRetweeted;
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
          });
        }
      }
    }

    try {
      if (postListFive.length > 0) {
        postListFive.forEach((element) {
          threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();
        });
      }
    } catch (_) {}
    update();
    return postListFive;
  }

  Future<List<Post>> getSingleNewsFeedItemThread(threadNumber,
      {bool isReload = true}) async {
    if (isReload) {
      isLoading = true;

      update();
    }

    getDataSingleNews = [];
    var response = await api.get(
      Uri.parse("${Url.getSingleNewsFeedItemUrl + "?thread_no=$threadNumber"}"),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );

    var posts = json.decode(response);

    var singlePostData = posts['data'] as List;
    isLoading = false;
    update();
    // print('get data ');
    // print(singlePostData);

    //  List <Post> postData = [];
    getDataSingleNews.clear();

    singlePostData.forEach((element) {
      var data2 = Post.fromJson(element);
      getDataSingleNews.add(data2);
    });

    getDataSingleNews.forEach((element) {
      element.rebuzz.value = element.isRetweeted;
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      // element.comments.forEach((element) {
      //   // replyMentionTag.add(false);
      //   element.reactionType.value = element.isLiked;
      //   element.commentCount.value  = element.simpleLikeCount;
      // });

      element.reactionType.refresh();
    });

    return getDataSingleNews;

    //
    // });
    // return Post.fromJson(singlePostData);
  }

  bool isReload = true;

  Future<List<Post>> getSingleNewsFeedItem(postId,
      {bool isReload = true,
      int threadNumber,
      bool commentCheck,
      int index}) async {
    if (isReload && commentCheck != false) {
      // print("aya hai reload pr");
      isLoading = true;
      update();
    }
    getDataSingleNews = [];
    var response;
    if (threadNumber == null) {
      // print("ye wali chali");
      response = await api.get(
        Uri.parse("${Url.getSingleNewsFeedItemUrl + "?post_id=$postId"}"),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
    } else {
      response = await api.get(
        Uri.parse(
            "${Url.getSingleNewsFeedItemUrl + "?thread_no=$threadNumber"}"),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
    }

    // print("response post detail ${response}");

    var posts = json.decode(response);

    var singlePostData = posts['data'] as List;
    isLoading = false;
    update();
    // print('get data ');
    // print(singlePostData);
    getDataSingleNews.clear();
    singlePostData.forEach((element) {
      var data2 = Post.fromJson(element);
      getDataSingleNews.add(data2);
    });

    // print("single ");
    getDataSingleNews.forEach((element) {
      element.rebuzz.value = element.isRetweeted;
      element.likeCount.value = element.simpleLikeCount;
      element.rebuzzCount.value = element.retweetCount;
      element.commentCount.value = element.commentsCount;
      element.reactionType.value = element.isLiked;
      element.reactionType.refresh();
    });
    update();

    commentCheck = true;

    return getDataSingleNews;
  }

  //user Profile
  Future<UserProfile> getUserProfile({bool isFromRoute = false}) async {
    isLoading = true;
    if (!isFromRoute) {
      update();
    }
    // print('user profile api hit on newfeed controller');
    var response = await api.get(
        Uri.parse(Url.getProfileUrl + "?user_id=${storage.read("id")}"),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': userToken.toString(),
        });
    var jsonResponse = jsonDecode(response);
    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");

    if (jsonResponse["meta"]["code"] == 200) {
      // print(' response user profile api hit on newfeed controller');
      userProfile = UserProfile.fromJson(jsonResponse["data"]);
      storage.write("user_profile", jsonEncode(userProfile));
      storage.write("user_name", userProfile.username);
      storage.write("dob", userProfile.dob);
      storage.write("region", userProfile.region);
      storage.write('user_profile_Image', userProfile.profileImage);
      storage.write("notificationAllowed", userProfile.notificationAllowed);
      if (userProfile.notificationAllowed == 1) {
        notificationStatus = true;
      } else {
        notificationStatus = false;
      }

      String userData = storage.read("user_profile");

      userProfile = UserProfile.fromJson(jsonDecode(userData));
      userProfile.username = storage.read("user_name");
      userProfile.dob = storage.read("dob");
      userProfile.region = storage.read("region");
      userProfile.notificationAllowed = storage.read("notificationAllowed");
      // print("object");

      // print(userProfile.toJson());
      // print("object");
      if (!isFromRoute) {
        update();
      } // });
      isLoading = false;
      if (!isFromRoute) {
        update();
      }
    }
    return userProfile;
  }

  ///   multi Media Selected api  call
  Future<String> uploadMedia(Uint8List mediaBytes, int id,
      {String type = 'media', fileName = 'media',String fileType,String memeType, int index}) async{
    int currentIndex = currentIndexText;
    if (index != null) currentIndex = index;

    if (!kIsWeb) {
      // Get.dialog(
      //     Center(
      //         child: CircularProgressIndicator(
      //       color: MyColors.BlueColor,
      //     )),
      //     barrierDismissible: false);
    } else {
      mediaApiCheck = true;
    }

    /*
    //OLD API TO UPLOAD VIDEO AND FILES TO BACKEND

    _dio.Dio dio = _dio.Dio();
    // var parsedJson;
    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      'Content-Type': 'application/json',
      "Access-Control-Allow-Origin": "*",
    };

    var request = http.MultipartRequest('POST', Uri.parse(Url.uploadMedia));
    request.headers.addAll(headers);

    // request.files.add(http.MultipartFile.fromBytes(
    //   'files[]',
    //   mediaBytes[0],
    //   filename: "fileName",
    // ));
    var formData = FormData.fromMap({
      'files[]': await MultipartFile.fromBytes(mediaBytes, filename: fileName),
    });
    // print('Before hittig api');
    var response = await dio.post(Url.uploadMedia,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
              "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        data: formData);*/

    // var response = await request.send();
    // print('');
    // print(response);
    // print('After hittig api');

    var response = await HelperUploadMediaToS3().getS3UrlForVideosAndAndReturnJson(mediaBytes,fileType,memeType,fileName);
    var parsedJson = jsonDecode(response.toString());

    if (parsedJson['meta']['code'] == 200) {
      ModelClass model = ModelClass();
      model.mediaData2 ??= [];
      if (id == 1) {
        modelList2[currentIndex].mediaData2 =
            []; //   model.mediaData2.add(Files.fromJson(parsedJson['data'][0]));
        modelList2[currentIndex].mediaData2.add(Files.fromJson({
              'url': parsedJson['data'][0]['url'],
              'thumbnail_url': parsedJson['data'][0]['thumbnail_url'] ?? '',
              'name': parsedJson['data'][0]['name'],
              'size': parsedJson['data'][0]['size'],
              // 'mention_user_ids':""
            }));
      } else if (id == 2) {
        replayModelList[currentIndex].mediaData2 =
            []; //   model.mediaData2.add(Files.fromJson(parsedJson['data'][0]));
        replayModelList[currentIndex].mediaData2.add(Files.fromJson({
              'url': parsedJson['data'][0]['url'],
              'thumbnail_url': parsedJson['data'][0]['thumbnail_url'] ?? '',
              'name': parsedJson['data'][0]['name'],
              'size': parsedJson['data'][0]['size'],
              // 'mention_user_ids':""
            }));
      } else if (id == 3) {
        // modelList3[0].mediaData2 =
        //     []; //   model.mediaData2.add(Files.fromJson(parsedJson['data'][0]));
        // modelList3[0].mediaData2.clear();
        modelList3[currentIndex].mediaData2.add(Files.fromJson({
              'url': parsedJson['data'][0]['url'],
              'thumbnail_url': parsedJson['data'][0]['thumbnail_url'] ?? '',
              'name': parsedJson['data'][0]['name'],
              'size': parsedJson['data'][0]['size'],
              // 'mention_user_ids':""
            }));
      }
      mediaApiCheck = false;
      update();
      if (type == 'file') {
        return parsedJson['data'][0]['name'];
      }
      if (parsedJson['data'][0]['thumbnail_url'] == null) {
        return parsedJson['data'][0]['url'];
      } else {
        return parsedJson['data'][0]['thumbnail_url'];
      }

    }else{
      mediaApiCheck = false;
      update();
    }
  }

  ///   multi image selected   api  call
  Future<List<String>> multiImageSeleted(
      Map<String, dynamic> parameters, int id, List<PlatformFile> listPlatformFiles,{List<FileBytesModel> listBytes, int index}) async {
    int currentIndex = currentIndexText;
    if (index != null) currentIndex = index;
    debugPrint("currentIndex while upload: $currentIndex");
    if (!kIsWeb) {
      // Get.dialog(
      //     Center(
      //         child: CircularProgressIndicator(
      //       color: MyColors.BlueColor,
      //     )),
      //     barrierDismissible: false);
    } else {
      mediaApiCheck = true;
    }

    var tempData = [];
    if (kIsWeb) {
      if ( id==1){
        tempData = List.from(modelList2[currentIndex].mediaData2);
      } else if( id==3) {
        tempData = List.from(modelList3[currentIndex].mediaData2);
      }

    } else {
      if (id==2){

      } else {
        tempData = List.from(modelList2[currentIndex].mediaData2);
      }

    }

    /*
    //OLD API TO UPLOAD IAMGES TO BACKEND

//var formData = FormData.fromMap(parameters);
    _dio.Dio dio = _dio.Dio();
    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      'Content-Type': 'application/json',
      "Access-Control-Allow-Origin": "*",
    };
   var response = await dio.post(Url.uploadMedia,
        options: _dio.Options(headers: headers), data: formData);*/
    var response = await HelperUploadMediaToS3().getS3UrlForImagesAndReturnJson(listPlatformFiles,listBytes);

    if (kIsWeb && id==3 && modelList3[currentIndex].mediaData2.isEmpty && tempData.length != modelList3[currentIndex].mediaData2.length){
      // In some cases, when video already uploaded in this list, somehow we lose the data from the list here.
      // So, checking and adding the old data again in the media2 list
      modelList3[currentIndex].mediaData2 = List.from(tempData);
    } else if ((!kIsWeb || id == 1) && id != 2 && modelList2[currentIndex].mediaData2.isEmpty && tempData.length != modelList2[currentIndex].mediaData2.length){
      // Mobile
      modelList2[currentIndex].mediaData2 = List.from(tempData);
    }
    //print(response);

    var parsedJson = jsonDecode(response.toString());

    if (parsedJson['meta']['code'] == 200) {
      debugPrint("currentIndex while upload: Response 200");
      List<dynamic> responseModel = parsedJson['data'] as List<dynamic>;
      ModelClass model = ModelClass();
      model.mediaData2 ??= [];
      if (id == 1) {
        for (int i = 0; i < responseModel.length; i++) {
          modelList2[currentIndex].mediaData2.add(Files.fromJson({
                'url': parsedJson['data'][i]['url'],
                'thumbnail_url': parsedJson['data'][i]['thumbnail_url'] ?? '',
                'name': parsedJson['data'][i]['name'],
                'size': parsedJson['data'][i]['size'],

                // 'mention_user_ids':""
              }));
        }
      } else if (id == 2) {
        for (int i = 0; i < responseModel.length; i++) {
          replayModelList[currentIndex].mediaData2.add(Files.fromJson({
                'url': parsedJson['data'][i]['url'],
                'thumbnail_url': parsedJson['data'][i]['thumbnail_url'] ?? '',
                'name': parsedJson['data'][i]['name'],
                'size': parsedJson['data'][i]['size'],

                // 'mention_user_ids':""
              }));
        }
      } else if (id == 3) {
        for (int i = 0; i < responseModel.length; i++) {
          modelList3[currentIndex].mediaData2.add(Files.fromJson({
                'url': parsedJson['data'][i]['url'],
                'thumbnail_url': parsedJson['data'][i]['thumbnail_url'] ?? '',
                'name': parsedJson['data'][i]['name'],
                'size': parsedJson['data'][i]['size'],

                // 'mention_user_ids':""
              }));
        }
      }

      update();
    }else{
      mediaApiCheck = false;
      update();
    }
  }

  TextEditingController tagSearch = TextEditingController();
  List<MentionUserList> tagList = [];
  List<MentionUserList> peopleList = [];
  String mentionUserIds = "";

  void showCustomDialog(
      BuildContext context, height, width, Function() onCallBack, int index) {
    showGeneralDialog(
      context: context,

      barrierLabel: "Barrier",
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.5),
      // transitionDuration: Duration(milliseconds: 700),
      pageBuilder: (_, __, ___) {
        return StatefulBuilder(
            builder: (BuildContext contex, StateSetter setState) {
          return Center(
            child: Container(
              height: kIsWeb ? height / 1.1 : Get.height,
              width: kIsWeb ? width / 2.5 : Get.width,
              child: SafeArea(
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(kIsWeb ? 15 : 0)),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: kIsWeb ? width / 50 : 0,
                        vertical: kIsWeb ? 10 : 0),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.close),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    "Tap People",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16),
                                  ),
                                ],
                              ),
                              MaterialButton(
                                color: tagList.isEmpty
                                    ? MyColors.grey
                                    : MyColors.yellow,
                                child: Text(
                                  Strings.done,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                                onPressed: () {
                                  // print("currentIndexText ${currentIndexText}");

                                  for (int i = 0; i < modelList2[currentIndexText].mediaData2[0].mentionUserList.length; i++) {
                                    if (i == 0 || i == modelList2[currentIndexText].mediaData2[0].mentionUserList.length) {
                                      mentionUserIds = mentionUserIds + modelList2[currentIndexText].mediaData2[0].mentionUserList[i].id.toString();
                                      modelList2[currentIndexText].mediaData2[0].mentionUserId = mentionUserIds.toString();
                                    } else {
                                      mentionUserIds = mentionUserIds + "," + modelList2[currentIndexText].mediaData2[0].mentionUserList[i].id.toString();
                                      modelList2[currentIndexText].mediaData2[0].mentionUserId = mentionUserIds.toString();
                                    }
                                  }

                                  // modelList2[currentIndexText].mediaData2.add(Files.fromJson({
                                  //   "mention_users":tagList,
                                  //   "mention_user_ids":mentionUserIds,
                                  // }));
                                  onCallBack();
                                  Navigator.pop(context);
                                },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: kIsWeb ? 0 : 10, right: kIsWeb ? 0 : 10),
                            child: TextField(
                              controller: tagSearch,
                              style:
                                  LightStyles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                // fontSize: 14,
                                // fontWeight: FontWeight.bold,
                              ),
                              cursorColor: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              decoration: InputDecoration(
                                fillColor: Colors.grey[250],
                                border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.grey, width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                hintStyle: LightStyles.baseTextTheme.headline3,
                                hintText: "Search User",
                              ),
                              onChanged: (val) async {
                                if (val.isEmpty) {
                                  peopleList.clear();
                                  setState(() {});
                                } else {
                                  // print("val ${val}");
                                  peopleList = await onSearchTagPeople(val);

                                  // print("peopleList ${peopleList}");

                                  setState(() {});
                                }
                              },
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: kIsWeb ? 0 : 10),
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: List.generate(
                                    modelList2[currentIndexText]
                                        .mediaData2[0]
                                        .mentionUserList
                                        .length, (index) {
                                  return Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 5, vertical: 3),
                                    margin: EdgeInsets.only(
                                        left: kIsWeb ? width / 100 : 0),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        border:
                                            Border.all(color: Colors.black54)),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 12,
                                          backgroundImage: NetworkImage(modelList2[
                                                          currentIndexText]
                                                      .mediaData2[0]
                                                      .mentionUserList[index]
                                                      .profileImage !=
                                                  null
                                              ? modelList2[currentIndexText]
                                                  .mediaData2[0]
                                                  .mentionUserList[index]
                                                  .profileImage
                                              : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                        ),
                                        SizedBox(
                                          width: 3,
                                        ),
                                        Text(
                                          "${modelList2[currentIndexText].mediaData2[0].mentionUserList[index].firstname}",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(
                                          width: 20,
                                        ),
                                        InkWell(
                                          child: Icon(Icons.close),
                                          onTap: () {
                                            // print("index $index");

                                            // if(tagList.isNotEmpty)
                                            // {
                                            //   tagList.remove(tagList[index]);
                                            // }
                                            modelList2[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList
                                                .remove(modelList2[
                                                        currentIndexText]
                                                    .mediaData2[0]
                                                    .mentionUserList[index]);
                                            setState(() {});
                                          },
                                        )
                                      ],
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          peopleList.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(child: Text("No Results")),
                                )
                              : Padding(
                                  padding: const EdgeInsets.only(
                                      left: kIsWeb ? 0 : 10),
                                  child: Column(
                                    children: List.generate(
                                      peopleList.length,
                                      (index) => InkWell(
                                        onTap: () {
                                          // print(peopleList.length);
                                          // print(index);
                                          tagList.add(peopleList[index]);

                                          if (!modelList2[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList
                                              .contains(peopleList[index])) {
                                            modelList2[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList
                                                .add(peopleList[index]);
                                          }

                                          setState(() {});
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 10.0),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CircleAvatar(
                                                radius:
                                                    kIsWeb ? width / 55 : 17,
                                                backgroundImage: NetworkImage(
                                                    peopleList[index]
                                                                .profileImage !=
                                                            null
                                                        ? peopleList[index]
                                                            .profileImage
                                                        : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "${peopleList[index].firstname}",
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Text(
                                                    "${peopleList[index].username}",
                                                    style: TextStyle(
                                                        color: MyColors.grey),
                                                  ),
                                                ],
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // margin: EdgeInsets.symmetric(horizontal: 20),
              // decoration: BoxDecoration(
              //     color: Colors.white, borderRadius: BorderRadius.circular(40)),
            ),
          );
        });
      },
      transitionBuilder: (_, anim, __, child) {
        Tween<Offset> tween;
        if (anim.status == AnimationStatus.reverse) {
          tween = Tween(begin: Offset(-1, 0), end: Offset.zero);
        } else {
          tween = Tween(begin: Offset(1, 0), end: Offset.zero);
        }

        return SlideTransition(
          position: tween.animate(anim),
          child: FadeTransition(
            opacity: anim,
            child: child,
          ),
        );
      },
    );
  }

  void showCustomDialogReply(
      BuildContext context, height, width, Function() onCallBack) {
    showGeneralDialog(
      context: context,

      barrierLabel: "Barrier",
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.5),
      // transitionDuration: Duration(milliseconds: 700),
      pageBuilder: (_, __, ___) {
        return StatefulBuilder(
            builder: (BuildContext contex, StateSetter setState) {
          return Center(
            child: Container(
              height: kIsWeb ? height / 1.1 : Get.height,
              width: kIsWeb ? width / 2.5 : Get.width,
              child: SafeArea(
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(kIsWeb ? 15 : 0)),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: kIsWeb ? width / 50 : 0,
                        vertical: kIsWeb ? 10 : 0),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.close),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    "Tap People",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16),
                                  ),
                                ],
                              ),
                              MaterialButton(
                                color: tagList.isEmpty
                                    ? MyColors.grey
                                    : MyColors.yellow,
                                child: Text(
                                  Strings.done,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.white),
                                ),
                                onPressed: () {
                                  for (int i = 0;
                                      i <
                                          replayModelList[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList
                                              .length;
                                      i++) {
                                    if (i == 0 ||
                                        i ==
                                            replayModelList[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList
                                                .length) {
                                      mentionUserIds = mentionUserIds +
                                          replayModelList[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList[i]
                                              .id
                                              .toString();
                                      replayModelList[currentIndexText]
                                              .mediaData2[currentIndexText]
                                              .mentionUserId =
                                          mentionUserIds.toString();
                                    } else {
                                      mentionUserIds = mentionUserIds +
                                          "," +
                                          replayModelList[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList[i]
                                              .id
                                              .toString();
                                      replayModelList[currentIndexText]
                                              .mediaData2[currentIndexText]
                                              .mentionUserId =
                                          mentionUserIds.toString();
                                    }
                                  }
                                  // modelList2[currentIndexText].mediaData2.add(Files.fromJson({
                                  //   "mention_users":tagList,
                                  //   "mention_user_ids":mentionUserIds,
                                  // }));
                                  onCallBack();
                                  Navigator.pop(context);
                                },
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                left: kIsWeb ? 0 : 10, right: kIsWeb ? 0 : 10),
                            child: TextField(
                              controller: tagSearch,
                              style:
                                  LightStyles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                // fontSize: 14,
                                // fontWeight: FontWeight.bold,
                              ),
                              cursorColor: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              decoration: InputDecoration(
                                fillColor: Colors.grey[250],
                                border: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Colors.grey, width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                                hintStyle: LightStyles.baseTextTheme.headline3,
                                hintText: "Search User",
                              ),
                              onChanged: (val) async {
                                if (val.isEmpty) {
                                  peopleList.clear();
                                  setState(() {});
                                } else {
                                  // print("val ${val}");
                                  peopleList = await onSearchTagPeople(val);

                                  // print("peopleList ${peopleList}");

                                  setState(() {});
                                }
                              },
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Padding(
                            padding:
                                const EdgeInsets.only(left: kIsWeb ? 0 : 10),
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: List.generate(
                                    replayModelList[currentIndexText]
                                        .mediaData2[0]
                                        .mentionUserList
                                        .length, (index) {
                                  return Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 5, vertical: 3),
                                    margin: EdgeInsets.only(
                                        left: kIsWeb ? width / 100 : 0),
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(20),
                                        border:
                                            Border.all(color: Colors.black54)),
                                    child: Row(
                                      children: [
                                        CircleAvatar(
                                          radius: 12,
                                          backgroundImage: NetworkImage(
                                              replayModelList[currentIndexText]
                                                          .mediaData2[0]
                                                          .mentionUserList[
                                                              index]
                                                          .profileImage !=
                                                      null
                                                  ? replayModelList[
                                                          currentIndexText]
                                                      .mediaData2[0]
                                                      .mentionUserList[index]
                                                      .profileImage
                                                  : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                        ),
                                        SizedBox(
                                          width: 3,
                                        ),
                                        Text(
                                          "${replayModelList[currentIndexText].mediaData2[0].mentionUserList[index].firstname}",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        SizedBox(
                                          width: 20,
                                        ),
                                        InkWell(
                                          child: Icon(Icons.close),
                                          onTap: () {
                                            // print("index $index");

                                            // if(tagList.isNotEmpty)
                                            // {
                                            //   tagList.remove(tagList[index]);
                                            // }
                                            replayModelList[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList
                                                .remove(replayModelList[
                                                        currentIndexText]
                                                    .mediaData2[0]
                                                    .mentionUserList[index]);
                                            setState(() {});
                                          },
                                        )
                                      ],
                                    ),
                                  );
                                }),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          peopleList.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(child: Text("No Results")),
                                )
                              : Padding(
                                  padding: const EdgeInsets.only(
                                      left: kIsWeb ? 0 : 10),
                                  child: Column(
                                    children: List.generate(
                                      peopleList.length,
                                      (index) => InkWell(
                                        onTap: () {
                                          // print(peopleList.length);
                                          // print(index);
                                          tagList.add(peopleList[index]);

                                          if (!replayModelList[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList
                                              .contains(peopleList[index])) {
                                            replayModelList[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList
                                                .add(peopleList[index]);
                                          }

                                          setState(() {});
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 10.0),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: [
                                              CircleAvatar(
                                                radius:
                                                    kIsWeb ? width / 55 : 17,
                                                backgroundImage: NetworkImage(
                                                    peopleList[index]
                                                                .profileImage !=
                                                            null
                                                        ? peopleList[index]
                                                            .profileImage
                                                        : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "${peopleList[index].firstname}",
                                                    style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  Text(
                                                    "${peopleList[index].username}",
                                                    style: TextStyle(
                                                        color: MyColors.grey),
                                                  ),
                                                ],
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // margin: EdgeInsets.symmetric(horizontal: 20),
              // decoration: BoxDecoration(
              //     color: Colors.white, borderRadius: BorderRadius.circular(40)),
            ),
          );
        });
      },
      transitionBuilder: (_, anim, __, child) {
        Tween<Offset> tween;
        if (anim.status == AnimationStatus.reverse) {
          tween = Tween(begin: Offset(-1, 0), end: Offset.zero);
        } else {
          tween = Tween(begin: Offset(1, 0), end: Offset.zero);
        }

        return SlideTransition(
          position: tween.animate(anim),
          child: FadeTransition(
            opacity: anim,
            child: child,
          ),
        );
      },
    );
  }

  void showCustomDialogForHome(
      BuildContext context, height, width, Function() onCallBack) {
    showGeneralDialog(
      context: context,

      barrierLabel: "Barrier",
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.5),
      // transitionDuration: Duration(milliseconds: 700),
      pageBuilder: (_, __, ___) {
        return StatefulBuilder(
            builder: (BuildContext contex, StateSetter setState) {
          return Center(
            child: Container(
              height: height / 1.1,
              width: width / 2.5,
              child: Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: width / 50, vertical: 10),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                IconButton(
                                  icon: Icon(Icons.close),
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                Text(
                                  "Tap People",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16),
                                ),
                              ],
                            ),
                            MaterialButton(
                              color: tagList.isEmpty
                                  ? MyColors.grey
                                  : MyColors.yellow,
                              child: Text(
                                Strings.done,
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.white),
                              ),
                              onPressed: () {
                                for (int i = 0;
                                    i <
                                        modelList3[currentIndexText]
                                            .mediaData2[0]
                                            .mentionUserList
                                            .length;
                                    i++) {
                                  if (i == 0 ||
                                      i ==
                                          modelList3[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList
                                              .length) {
                                    mentionUserIds = mentionUserIds +
                                        modelList3[currentIndexText]
                                            .mediaData2[0]
                                            .mentionUserList[i]
                                            .id
                                            .toString();
                                    modelList3[currentIndexText]
                                            .mediaData2[currentIndexText]
                                            .mentionUserId =
                                        mentionUserIds.toString();
                                  } else {
                                    mentionUserIds = mentionUserIds +
                                        "," +
                                        modelList3[currentIndexText]
                                            .mediaData2[0]
                                            .mentionUserList[i]
                                            .id
                                            .toString();
                                    modelList3[currentIndexText]
                                            .mediaData2[currentIndexText]
                                            .mentionUserId =
                                        mentionUserIds.toString();
                                  }
                                }
                                // modelList2[currentIndexText].mediaData2.add(Files.fromJson({
                                //   "mention_users":tagList,
                                //   "mention_user_ids":mentionUserIds,
                                // }));
                                onCallBack();
                                Navigator.pop(context);
                              },
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                          ],
                        ),
                        TextField(
                          controller: tagSearch,
                          style: LightStyles.baseTextTheme.headline2.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            // fontSize: 14,
                            // fontWeight: FontWeight.bold,
                          ),
                          cursorColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                          decoration: InputDecoration(
                            fillColor: Colors.grey[250],
                            border: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1),
                              borderRadius: BorderRadius.circular(30),
                            ),
                            hintStyle: LightStyles.baseTextTheme.headline3,
                            hintText: "Search User",
                          ),
                          onChanged: (val) async {
                            if (val.isEmpty) {
                              peopleList.clear();
                              setState(() {});
                            } else {
                              // print("val ${val}");
                              peopleList = await onSearchTagPeople(val);

                              // print("peopleList ${peopleList}");

                              setState(() {});
                            }
                          },
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          width: width / 2.6,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: List.generate(
                                  modelList3[currentIndexText]
                                      .mediaData2[0]
                                      .mentionUserList
                                      .length, (index) {
                                return Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 3),
                                  margin: EdgeInsets.only(left: width / 100),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border:
                                          Border.all(color: Colors.black54)),
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 12,
                                        backgroundImage: NetworkImage(modelList3[
                                                        currentIndexText]
                                                    .mediaData2[0]
                                                    .mentionUserList[index]
                                                    .profileImage !=
                                                null
                                            ? modelList3[currentIndexText]
                                                .mediaData2[0]
                                                .mentionUserList[index]
                                                .profileImage
                                            : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                      ),
                                      SizedBox(
                                        width: 3,
                                      ),
                                      Text(
                                        "${modelList3[currentIndexText].mediaData2[0].mentionUserList[index].firstname}",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        width: 20,
                                      ),
                                      InkWell(
                                        child: Icon(Icons.close),
                                        onTap: () {
                                          // print("index $index");
                                          //
                                          //
                                          if (tagList.isNotEmpty) {
                                            tagList.remove(tagList[index]);
                                          }

                                          modelList3[currentIndexText]
                                              .mediaData2[0]
                                              .mentionUserList
                                              .remove(
                                                  modelList3[currentIndexText]
                                                      .mediaData2[0]
                                                      .mentionUserList[index]);
                                          setState(() {});
                                        },
                                      )
                                    ],
                                  ),
                                );
                              }),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        peopleList.isEmpty
                            ? Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Center(child: Text("No Results")),
                              )
                            : Column(
                                children: List.generate(
                                  peopleList.length,
                                  (index) => InkWell(
                                    onTap: () {
                                      // print(peopleList.length);
                                      // print(index);
                                      tagList.add(peopleList[index]);

                                      if (!modelList3[currentIndexText]
                                          .mediaData2[0]
                                          .mentionUserList
                                          .contains(peopleList[index])) {
                                        modelList3[currentIndexText]
                                            .mediaData2[0]
                                            .mentionUserList
                                            .add(peopleList[index]);
                                      }

                                      setState(() {});
                                    },
                                    child: Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10.0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          CircleAvatar(
                                            radius: width / 55,
                                            backgroundImage: NetworkImage(
                                                peopleList[index]
                                                            .profileImage !=
                                                        null
                                                    ? peopleList[index]
                                                        .profileImage
                                                    : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "${peopleList[index].firstname}",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              Text(
                                                "${peopleList[index].username}",
                                                style: TextStyle(
                                                    color: MyColors.grey),
                                              ),
                                            ],
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              )
                      ],
                    ),
                  ),
                ),
              ),
              // margin: EdgeInsets.symmetric(horizontal: 20),
              // decoration: BoxDecoration(
              //     color: Colors.white, borderRadius: BorderRadius.circular(40)),
            ),
          );
        });
      },
      transitionBuilder: (_, anim, __, child) {
        Tween<Offset> tween;
        if (anim.status == AnimationStatus.reverse) {
          tween = Tween(begin: Offset(-1, 0), end: Offset.zero);
        } else {
          tween = Tween(begin: Offset(1, 0), end: Offset.zero);
        }

        return SlideTransition(
          position: tween.animate(anim),
          child: FadeTransition(
            opacity: anim,
            child: child,
          ),
        );
      },
    );
  }

  void showTagUserDialog(BuildContext context, height, width, List mentionUser,
      Function() onCallBack) {
    showGeneralDialog(
      context: context,
      barrierLabel: "Barrier",
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.5),
      pageBuilder: (_, __, ___) {
        return StatefulBuilder(
            builder: (BuildContext contex, StateSetter setState) {
          return Center(
            child: SizedBox(
              height: kIsWeb ? height / 1.3 : Get.height,
              width: kIsWeb ? width / 2.5 : Get.width,
              child: SafeArea(
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(kIsWeb ? 15 : 0)),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                        horizontal: kIsWeb ? width / 50 : 15,
                        vertical: kIsWeb ? 10 : 0),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.close),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  SizedBox(
                                    width: 20,
                                  ),
                                  Text(
                                    "Tap People",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          mentionUser.isEmpty
                              ? Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Center(child: Text("No Results")),
                                )
                              : SingleChildScrollView(
                                  child: Column(
                                    children: List.generate(
                                      mentionUser.length,
                                      (index) => InkWell(
                                        onTap: () {
                                          // tagList.add(peopleList[index]);
                                          // setState((){});
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              bottom: 10.0),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              CircleAvatar(
                                                radius:
                                                    kIsWeb ? width / 50 : 18,
                                                backgroundImage: NetworkImage(
                                                    mentionUser[index][
                                                                "profile_image"] !=
                                                            null
                                                        ? mentionUser[index]
                                                            ["profile_image"]
                                                        : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqrrxsxZSpsfebkw8VLXe6R5j7mryT6PK7Pg&usqp=CAU"),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "${mentionUser[index]["firstname"]}",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 16),
                                                  ),
                                                  Text(
                                                    "${mentionUser[index]["username"]}",
                                                    style: TextStyle(
                                                        color: MyColors.grey,
                                                        fontSize: 16),
                                                  ),
                                                ],
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              // margin: EdgeInsets.symmetric(horizontal: 20),
              // decoration: BoxDecoration(
              //     color: Colors.white, borderRadius: BorderRadius.circular(40)),
            ),
          );
        });
      },
      transitionBuilder: (_, anim, __, child) {
        Tween<Offset> tween;
        if (anim.status == AnimationStatus.reverse) {
          tween = Tween(begin: Offset(0, 0), end: Offset.zero);
        } else {
          tween = Tween(begin: Offset(0, 0), end: Offset.zero);
        }

        return SlideTransition(
          position: tween.animate(anim),
          child: FadeTransition(
            opacity: anim,
            child: child,
          ),
        );
      },
    );
  }

  Future<List<MentionUserList>> onSearchTagPeople(String text) async {
    searchResult.clear();
    List<MentionUserList> resultList = [];
    if (text.isEmpty) {
      return resultList;
    }

    var response = await api.post(Uri.parse(Url.searchUsers), queryParameters: {
      'search_text': text.toString(),
      "type": "mention_users"
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    wait = false;
    update();
    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");

    if (jsonResponse["meta"]["code"].toString() == "200") {
      jsonResponse["data"].forEach((ele) {
        resultList.add(MentionUserList.fromJson(ele));
      });
      update();
      return resultList;
    } else {
      return resultList;
    }

    // return jsonResponse['data']['post_counts']['simple_like_count'];
  }

  int othersUserid = 0;

  Future<UserProfile> getOtherUserProfile(int userIddd,
      {postId,
      final UserProfile userInfod,
      bool isFromRoute = false,
      bool otherProfileScreenCheck}) async {
    userInfo = userInfod;

    // print("userInfo.userId ${userInfo.userId}");

    // print("idhr......");

    if (userIddd != null) {
      othersUserid = userIddd;
    }

    // print("userIddd $userIddd");
    // print("userIddd $othersUserid ");

    isLoading = true;
    if (!isFromRoute) {
      update();
    }
    var response;
    // print('USERNAME' + otherUserName + 'USername');
    // print(otherUserName.trim() + 'test');
    otherUserName = otherUserName.trim();
    String idPath = postId != null
        ? Url.getProfileUrl + '?user_id=$userIddd' + '&post_id=$postId'
        : Url.getProfileUrl + '?user_id=$userIddd';
    String namePath = postId != null
        ? Url.getProfileUrl + '?username=$otherUserName' + '&post_id=$postId'
        : Url.getProfileUrl + '?username=$otherUserName';

    // print("Yeh Wali API hit hoi");

    if (otherProfileScreenCheck != false) {
      otherProfileScreen = true;
    }

    // print("posid  $postId");

    if (!isFromRoute) {
      update();
    }
    // if (otherUserName.isNotEmpty && otherUserName != '' && postId == null) {
    //   print('INSIDE USERNAME SCOPE');
    //   print('PATH' + namePath);
    //   response = await api.get(Uri.parse(namePath),
    //       // queryParameters: {
    //       //   'post_id': postId.toString(),
    //       //   'username': otherUserName,
    //       // },
    //       token: {
    //         'X-Requested-With': 'XMLHttpRequest',
    //         'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
    //         'Token': userToken.toString(),
    //       });
    //
    //
    // }
    //  else {
    // print('INSIDE ID SCOPE' + idPath);
    response = await api.get(Uri.parse(idPath), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });

    //   }

    // print(" other user profile response   $response");
    var jsonResponse = jsonDecode(response);
    print("Other Users Profile Response: $jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");

    if (jsonResponse["meta"]["code"] == 200) {
      // jsonResponse["data"].forEach((ele) {
      otherUserProfile = UserProfile.fromJson(jsonResponse["data"]);
      userInfo = UserProfile.fromJson(jsonResponse["data"]);

      userInfo = otherUserProfile;

      // print('Success');
      // print(otherUserProfile.muted);
      // print(otherUserProfile.email);

      otherProfileScreen = false;
      otherUserName = otherUserProfile.username;
      otherUserId = otherUserProfile.userId;

      if (!isFromRoute) {
        update();
      }
      // if (!kIsWeb)
      //   DatabaseHelper.instance
      //       .insert(DatabaseHelper.profileTable, otherUserProfile.toJson());
      // userPosts = await filterUsersPost('posts');
      // });

      isLoading = false;
      if (!isFromRoute) {
        update();
      }
    }
    return otherUserProfile;
  }

  // ignore: missing_return
  Future<List<Post>> filterUsersPost(
    tab,
  ) async {
    try {


      isFilter = true;
      // update();

      LoginController signupController = LoginController();
      var resBody;
      // debugPrint("other User Id ---->>> ${otherUserId} ");

      resBody = await signupController.filterUserPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        "user_id": otherUserId.toString(),
        "tab": tab.toString(),
      });

     //  print("response aya hai post ka ");
      // print(resBody);
      if (resBody["meta"]["code"] == 200) {
        if (resBody['data'] != null) {
          var postData = resBody['data'] as List;

          // List<Post> postList2 = postData.map((e) => Post.fromJson(e)).toList();
          // userPosts.addAll(postList2);
          // update();
          List<Post> postList2=  postData.map((e) => Post.fromJson(e)).toList();
          Get.find<OtherUserController>().userPosts.addAll(postList2);
          if (Get.find<OtherUserController>().userPosts != null) {
            for (var element in Get.find<OtherUserController>().userPosts) {
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;
              element.reactionType.refresh();
            }
          }

          isFilter = false;
          update();
          return postData.map((e) => Post.fromJson(e)).toList();
        } else {
          isFilter = false;
          update();
          return [];
        }
      } else {
        isFilter = false;
        update();
        return [];
      }
    } catch (e) {
      // print(e.toString());
    }
  }

  Future<void> schedulePost(
    context, {
    String bodyText,
    List<String> fileName,
    List<Uint8List> imageWebBytes,
    List<PlatformFile> imageWebByte,
    List<ModelClass> payload,
    String fileUrls,
    String filesInfo,
    String link,
    String linkTitle,
    String linkMeta,
    String linkImage,
    String postingTime,
        bool isComment = false
  }) async {
    final String currentTimeZone =
        await FlutterNativeTimezone.getLocalTimezone();
    // print("currentTimeZone  ${currentTimeZone}");


    print("postingTime  ${postingTime}");
    postingTime = postingTime.substring(0,postingTime.indexOf(":00"));
     print("postingTime  ${postingTime}");

    try {
      var response = await http.post(Uri.parse(Url.schedulePost),
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': userToken.toString(),
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: jsonEncode({
            'payload': payload,
            'type': isComment ? "comment" :'schedule',
            'body': bodyText,
            'link': link,
            'link_title': linkTitle,
            'link_meta': linkMeta,
            'posting_time': postingTime,
            'link_image': linkImage,
            "privacy_type": "public",
            "timezone": currentTimeZone,
            "reply_id":payload.first.replyId

          }));

      // print("response.body ${(response.body)}");

      //    var parsedJson;
      //    var request = http.MultipartRequest('POST', Uri.parse(Url.schedulePost));
      //    request.headers.addAll(headers);
      //
      //    for (int i = 0; i < imageWebByte.length; i++) {
      //      request.files.add(http.MultipartFile.fromBytes(
      //          'files[]', imageWebByte[i].bytes,
      //          filename: fileName != null ? fileName[i] : 'file'));
      //    }
      //    request.fields['type'] = 'schedule';
      //    request.fields['body'] = bodyText;
      //    request.fields['link'] = link;
      // //  request.fields['payload'] = payload;
      //
      //    request.fields['link_title'] = linkTitle;
      //
      //    request.fields['link_meta'] = linkMeta;
      //    request.fields['link_image'] = linkImage;
      //    request.fields['posting_time'] = postingTime;
      //
      //    // print(request.files);
      //    // print(request.fields);
      //    // print("SELECTION TYPE" + selectType);
      //    request.fields['privacy_type'] = 'public';

      // var response = await request.send().then((response) {

      // print(response.statusCode);
      if (response.statusCode == 200) {
        UtilsMethods.toastMessageShow(
          displayColor,
          displayColor,
          displayColor,
          message: 'Your werf is scheduled successfully',
        );
        // print("bodyText bodyText${bodyText}");
        // print("postingTime postingTime ${postingTime}");
        Get.find<NewsfeedController>().modelList3[0].mediaData2.clear();
        Get.find<NewsfeedController>().writeSomethingHere[0].clear();
        Get.find<NewsfeedController>().isPostScheduled = false;
      } else {
        UtilsMethods.toastMessageShow(
          displayColor,
          displayColor,
          displayColor,
          message: 'There was an error in scheduling your werf',
        );
      }
      // });

      //  print("response schedule ${response.body}");
    } catch (ex) {
       print("<======== EXCEPTION NEWS FEED CONTROLLER ==========> schedulePost()");
       UtilsMethods.toastMessageShow(
         displayColor,
         displayColor,
         displayColor,
         message: 'There was an error in scheduling your werf. Please try again',
       );
      // print(ex);
      // print("exception");
    }
  }

  // ignore: missing_return
  Future<int> createPost(
      {List<ModelClass> payload,
      int postId,
        bool isEdit,
      int replyId,
      int getClickId,
      int incrementPostId,
      bool isUserProfile}) async {
    if (postId == -1) {
      postList.forEach((element) {
        if (element.postId == payload[0].replyId) {
          element.commentCount.value = element.commentCount.value + 1;
          update();
        }
      });
      try {
        if (Get.find<SavedPostController>().savedPostList.isNotEmpty &&
            Get.find<SavedPostController>().savedPostList.length > 0) {
          Get.find<SavedPostController>().savedPostList.forEach((element) {
            if (element.postId == payload[0].replyId) {
              element.commentCount.value = element.commentCount.value + 1;
              Get.find<SavedPostController>().update();
            }
          });
        }
      } catch (_) {}
      try {
        if (Get.find<ProfileController>().userPosts.isNotEmpty &&
            Get.find<ProfileController>().userPosts.length > 0) {
          Get.find<ProfileController>().userPosts.forEach((element) {
            if (element.postId == payload[0].replyId) {
              element.commentCount.value = element.commentCount.value + 1;
              Get.find<ProfileController>().update();
            }
          });
        }


      } catch (_) {}
      try {
        if (Get.find<OtherUserController>().userPosts.isNotEmpty &&
            Get.find<OtherUserController>().userPosts.length > 0) {
          Get.find<OtherUserController>().userPosts.forEach((element) {
            if (element.postId == payload[0].replyId) {
              element.commentCount.value = element.commentCount.value + 1;
              Get.find<OtherUserController>().update();
            }
          });
        }
      } catch (_) {}

      try {
        if (Get.find<BrowseController>().browsePostList.isNotEmpty &&
            Get.find<BrowseController>().browsePostList.length > 0) {
          Get.find<BrowseController>().browsePostList.forEach((element) {
            if (element.postId == payload[0].replyId) {
              element.commentCount.value = element.commentCount.value + 1;
              Get.find<BrowseController>().update();
            }
          });
        }
      } catch (_) {}
      try {
        if (Get.find<ListController>().selectedList.newsfeed.isNotEmpty &&
            Get.find<ListController>().selectedList.newsfeed.length > 0) {
          Get.find<ListController>().selectedList.newsfeed.forEach((element) {
            if (element.postId == payload[0].replyId) {
              Get.find<ListController>().update();
            }
          });
        }
      } catch (_) {}
    }
    else {
      if (!isNewsfeedLoading) isNewsfeedLoading = true;
    }

    // print('data send to api ');

    // print('user id send to data ${payload[0].toJson()}');

    var response = await http.post(Uri.parse(Url.baseUrl + 'post/create'),
        headers: <String, String>{
          'Content-Type': 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': userToken.toString(),
          'X-Requested-With': 'XMLHttpRequest',
        },
        body: jsonEncode({'payload': payload}));
     //print("response aya hai ");
    var parsedJson = jsonDecode(response.body);

    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson['data'] as List;
      // modelList2=[];
      List<Post> postData = [];

      data.forEach((element) {
        var data2 = Post.fromJson(element);
        postData.add(data2);
      });
      postData.forEach((element) {
        trendingList = element.trending;
      });

      if (trendingList != null) {
        socket.emit('hot_trends', {
          'trends': trendingList.trends,
          'region': trendingList.region,
        });
      }

      // print("sdfsdfddsqwerq  $postId");
      if (postId == 0) {
        socket.emit('new_post', {'user_id': userId, "slug": data});
        // print(postData);

        postData.forEach((element) {
          element.reactionType.refresh();
          if (kIsWeb == false && (element.postType == "image" || element.postType == "video")){
            UtilsMethods.toastMessageShow(
              displayColor,
              displayColor,
              displayColor,
              message: 'Your image/video will be available in a moment.',
              toastDuration: 5,
            );
          }
          postList.insert(0, element);
        });
        //
        postList.forEach((element) {
          //  threadNumber = element.thread_no;
          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          // });
        });
      }
      else if (postId == -1) {
        // print("idhr aya hai ");
      }
      else {

        if(isEdit==true)
          {
            UtilsMethods.toastMessageShow(
                displayColor,
                displayColor,
                displayColor,
                toastDuration: 3,
                message: Strings.yourImageVideoWillBeAvailableInAMoment);

          }
        if(isEdit==false)
          {
            int ind = postData.indexWhere((element) {
              return element.postId == postId;
            });

            postData.forEach((element) {
              postList[ind] = element;
            });
            postList.forEach((element) {
              //  threadNumber = element.thread_no;
              element.rebuzz.value = element.isRetweeted;
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;
            });


          }


      }

      // print("replyId ${replyId}");

      if (replyId == 2) {
        if (kIsWeb) {
          if (getClickId == 1) {
            // MobileCommentsController mobileController;
            int index = selectedPost2.indexWhere((element) {
              return element.postId == incrementPostId;
            });
            if (index >= 0) selectedPost2[index].commentCount.value++;
            // mobileController = Get.find<MobileCommentsController>();
            // mobileController.update();
          } else {
            int index = getCommentsList.indexWhere((element) {
              return element.postId == incrementPostId;
            });
            getCommentsList[index].commentCount.value++;
          }
          postData.forEach((element) {
            element.reactionType.refresh();
            getCommentsList.insert(0, element);
          });
        } else {
          if (getClickId == 1) {
            MobileCommentsController mobileController;
            int index = selectedPost2.indexWhere((element) {
              return element.postId == incrementPostId;
            });
            selectedPost2[index].commentCount.value++;
          }
          else {
            int index = getCommentsList.indexWhere((element) {
              return element.postId == incrementPostId;
            });
            getCommentsList[index].commentCount.value++;
          }
          postData.forEach((element) {
            element.reactionType.refresh();
            getCommentsList.insert(0, element);
          });

          MobileCommentsController mobileController;
          if (Get.isRegistered<MobileCommentsController>()) {
            mobileController = Get.find<MobileCommentsController>();
          }
          mobileController.update();
        }
      }

      isNewsfeedAdded = true;

      if (replyId == null) {
      }
      else {
        // print("commeasdadsadadasdt py aya haiu");
        postList = await getNewsFeed(reload: true, newsFeedMobile: true);
      }

      update(["post", "postt"]);

      if (isUserProfile == true) {
        // print("idhar aya hai profile pr");
        if (Get.isRegistered<ProfileController>()) {
          ///
          Get.find<ProfileController>().isHiddenPost = false;
          Get.find<ProfileController>().isTweets = true;
          Get.find<ProfileController>().isTweetsReply = false;
          Get.find<ProfileController>().isMedia = false;
          Get.find<ProfileController>().isLikes = false;
          Get.find<ProfileController>().userProfile = await getUserProfile();
          await Get.find<ProfileController>().filterUsersPost("posts");
          Get.find<ProfileController>().userPosts.forEach((element) {
            element.likeCount.value = element.simpleLikeCount;
            element.rebuzzCount.value = element.retweetCount;
            element.commentCount.value = element.commentsCount;
            element.reactionType.value = element.isLiked;
            // element.comments.forEach((element) {
            //   element.reactionType.value = element.isLiked;
            //   element.commentCount.value  = element.simpleLikeCount;
            // });
            element.reactionType.refresh();
          });
          Get.find<ProfileController>().update();
        }
      }

      return parsedJson['meta']['code'];
    }
    else if (parsedJson['meta'] != null && parsedJson['meta']['code'] != null && parsedJson['meta']['code'] == 400)
      {

        UtilsMethods.toastMessageShow(
            displayColor,
            displayColor,
            displayColor,
            message: Strings.postOnlyCanUpdateIn60minutes);

      }



  }

  void pinUnPinPost({int postId, int pinUnPinPost}) async {
    if (!isNewsfeedLoading) isNewsfeedLoading = false;
    // print(mediaData);
    // print('data' +
    //     jsonEncode(
    //       {
    //         'post_id': postId,
    //         'pin_unpin_post': pinUnPinPost,
    //       },
    //     ).toString());
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'post/pin_unpin_post'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
          'pin_unpin_post': pinUnPinPost,
        },
      ),
    );
    // print(userToken.toString());
    // print("pinpost post by asad");

    // print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson['data'];
    }
  }

  Future<dynamic> HideUnHideReplay({int commentId}) async {
    // print("commentId ${commentId}");

    var response = await http.post(
      Uri.parse(Url.hideUnHideReply),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'comment_id': commentId,
        },
      ),
    );

    // print(userToken.toString());

    // print("response hide unhide replay  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      var data = parsedJson['data'];
      return data;
    }
  }

  List<Comment> commentList = [];

  bool allCommentLoading = false;

  Future<dynamic> allHiddenComment({int postId}) async {
    allCommentLoading = true;
    update();

    // print("commentId ${postId}");
    var response = await http.post(
      Uri.parse(Url.allHiddenComment),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
        },
      ),
    );
    // print(userToken.toString());

    // print("response all hidden Comment  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      commentList = [];

      var data = parsedJson['data'] as List;
      data.forEach((element) {
        var data2 = Comment.fromJson(element);
        commentList.add(data2);
      });

      commentList.forEach((element) {
        // print(element.body);
      });

      // print("xxxxx");
      allCommentLoading = false;
      update();

      return commentList;
    } else if (response.statusCode == 200 &&
        parsedJson['meta']['code'] == 400) {
      commentList = [];
      // print(commentList.length);
      allCommentLoading = false;

      update();
      return commentList;
    } else {
      // print("sdfsdfsdf");
      commentList = [];
      // print(commentList.length);
      allCommentLoading = false;
      update();
      return commentList;
    }

    // return
  }

  Future<int> deactivateProfile({String Password}) async {
    // print("idhr aya hai ");
    // print('data' +
    //     jsonEncode(
    //       {
    //         'password': Password,
    //       },
    //     ).toString());
    var response = await http.post(
      Uri.parse(Url.deleteProfile),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'password': Password,
        },
      ),
    );
    // print(userToken.toString());
    // print("delete profile");
    // print("response  ${response.body.toString()}");
    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      int data = parsedJson['meta']["code"];

      // Navigator.pop(context);
      // Navigator.pop(context);

      // print("datacode  $data");
      return data;
    } else if (response.statusCode == 422) {
      List<dynamic> data = parsedJson['errors']["password"];

      Fluttertoast.showToast(
          msg: "Incorrect Password",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.blue,
          textColor: Colors.white,
          fontSize: 16.0);

      // print("datacode  $data");

      return null;
    } else {
      return null;
    }
  }

  Future<int> deletedProfile({String Password}) async {
    // print("idhr aya hai ");
    // print('data' +
    //     jsonEncode(
    //       {
    //         'password': Password,
    //       },
    //     ).toString());
    var response = await http.post(
      Uri.parse(Url.permanentDeleteProfile),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'password': Password,
        },
      ),
    );
    // print(userToken.toString());
    // print("delete profile");
    // print("response  ${response.body.toString()}");
    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      int data = parsedJson['meta']["code"];
      // print("datacode  $data");
      return data;
    } else if (response.statusCode == 422) {
      List<dynamic> data = parsedJson['errors']["password"];

      Fluttertoast.showToast(
          msg: "Incorrect Password",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.blue,
          textColor: Colors.white,
          fontSize: 16.0);

      // print("datacode  $data");

      return null;
    } else {
      return null;
    }
  }

  Future<String> muteUnMute({String postType, int userID}) async {
    // print("idhr aya hai ");
    // print('data' +
    //     jsonEncode(
    //       {'postType': postType, 'userID': userID},
    //     ).toString());

    var response = await http.post(
      Uri.parse(Url.muteUnMute),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'muted_user_id': userID, "type": postType},
      ),
    );

    // print("mute unmute");
    // print("response  ${response.body.toString()}");

    var parsedJson = jsonDecode(response.body);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      String data = parsedJson['meta']["message"];
      // print("data message  $data");
      return data;
    } else {
      return null;
    }
  }

  Future<int> createQuoteWerf(
      {String bodyText,
      // File files,
      List<String> fileName,
      List<Uint8List> imageWebBytes,
      String fileUrls,
      String filesInfo,
      String privacyType,
      String selectType,
      int postId,
      String link,
      String linkTitle,
      String linkMeta,
      String linkImage,
      String quoteId,
      List mediaData}) async {
    if (!isNewsfeedLoading) isNewsfeedLoading = true;
    List<Map<String, String>> payload = [
      {
        'body': bodyText,
        'link': link,
        'link_title': linkTitle,
        'link_meta': linkMeta,
        'link_image': linkImage,
        'type': 'quote',
        'quote_id': quoteId,
        'files': null,
      }
    ];
    var response = await http.post(
      Uri.parse(Url.baseUrl + 'post/create'),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode({'payload': payload}),
    );

    var parsedJson = jsonDecode(response.body);
    // print(parsedJson);
    if (response.statusCode == 200 && parsedJson['meta']['code'] == 200) {
      // print('quete werf:${parsedJson['data']}');
      var data = parsedJson['data'];
      List<Post> postData = [];

      data.forEach((element) {
        var data2 = Post.fromJson(element);
        postData.add(data2);
      });

      postData.forEach((element) {
        trendingList = element.trending;
      });

      if (trendingList != null) {
        socket.emit('hot_trends', {
          'trends': trendingList.trends,
          'region': trendingList.region,
        });
      }
      socket.emit('new_post', {'user_id': userId, "slug": data});

      // print(postData);
      postData.forEach((element) {
        postList.insert(0, element);
      });
      postList.forEach((element) {
        //  threadNumber = element.thread_no;
        element.rebuzz.value = element.isRetweeted;
        element.likeCount.value = element.simpleLikeCount;
        element.rebuzzCount.value = element.retweetCount;
        element.commentCount.value = element.commentsCount;
        element.reactionType.value = element.isLiked;
      });

      update(["post", "postt"]);

      return parsedJson['meta']['code'];
    }
  }

  Future<void> scheduleQuotePost(
    context, {
    String bodyText,
    List<String> fileName,
    List<Uint8List> imageWebBytes,
    String fileUrls,
    String filesInfo,
    String link,
    String linkTitle,
    String linkMeta,
    String linkImage,
    String postingTime,
    String quoteId,
  }) async {
    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
      // "Access-Control-Allow-Origin": "*",
    };
    try {
      var parsedJson;
      var request = http.MultipartRequest('POST', Uri.parse(Url.schedulePost));
      request.headers.addAll(headers);

      for (int i = 0; i < imageWebBytes.length; i++) {
        request.files.add(http.MultipartFile.fromBytes(
            'files[]', imageWebBytes[i],
            filename: fileName != null ? fileName[i] : 'file'));
      }
      request.fields['type'] = 'schedule';
      request.fields['body'] = bodyText;
      request.fields['link'] = link;
      request.fields['link_title'] = linkTitle;

      request.fields['link_meta'] = linkMeta;
      request.fields['link_image'] = linkImage;
      request.fields['posting_time'] = postingTime;
      request.fields['quote_id'] = quoteId;
      request.fields['privacy_type'] = 'public';

      var response = await request.send().then((response) {
        // print(response);
        // print(response.statusCode);
        if (response.statusCode == 200) {
          UtilsMethods.toastMessageShow(
            displayColor,
            displayColor,
            displayColor,
            message: 'Your werf is scheduled successfully',
          );
        } else {
          UtilsMethods.toastMessageShow(
            displayColor,
            displayColor,
            displayColor,
            message: 'There was an error in scheduling your werf',
          );
        }
      });
    } catch (ex) {
      // print("exception");
      // print(ex);
      // print("exception");
    }
  }

  bool counter = false;

  Future<int> likePost(int postId, String reactionType, {Post post}) async {
    // print("like post reaction");
    // print(postId.toString());

    // print("reactionType  $reactionType");

    // print("reactionType  $reactionType");
    // print("postid  $postId");

    // print('INSIDE LIKE POST FUNCTION');
    var response = await api.post(Uri.parse(Url.likePostUrl), queryParameters: {
      'type': reactionType,
      'post_id': postId.toString(),
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });

    // debugPrint('reaction response  $response');
    var jsonResponse = jsonDecode(response);

    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");
    if (jsonResponse["meta"]["code"] == 200)
      log('');

    Post postDetails = post;

    int value = jsonResponse['data']['count'];

    postDetails.likeCount.value = value;

/*    if (reactionType == "dislike_simple_dislike") {
      if (postDetails.likeCount.value != 0) {
        postDetails.likeCount.value--;
      } else {
        postDetails.likeCount.value = 0;
      }
    }*/
    postList.forEach((element) {
      if (element.postId == postId) {
        element.simpleLikeCount = value;
        element.isLiked = reactionType;
        element.likeCount.value = value;
        element.reactionType.value = reactionType;
        update();
      }
    });

    try {
      if (Get.find<ProfileController>().userPosts.isNotEmpty &&
          Get.find<ProfileController>().userPosts.length > 0) {
        Get.find<ProfileController>().userPosts.forEach((ele) {
          if (ele.postId == postId
          // postList[postIndex].postId
          ) {
            debugPrint("inside condition 001");
            Get.find<ProfileController>().userPosts.forEach((element) {
              if (element.postId == postId) {
                element.simpleLikeCount = value;
                element.isLiked = reactionType;
                element.likeCount.value = value;
                element.reactionType.value = reactionType;
                element.likeCount.refresh();
                Get.find<ProfileController>().update();
              }

            });

          }
        });
      }
    } catch (_) {}

    // print("counter  $counter");
    update();

    if (!kIsWeb) {
      var dbRes = await DatabaseHelper.instance.update(
          DatabaseHelper.savedPostTable,
          postDetails.toLocalDBMap(),
          postDetails.postId,
          'post_id');
      log('${postDetails.postId}  done updating ..... $dbRes');
    }

    return jsonResponse['data']
        ['count'] /*jsonResponse['data']['post_counts']['simple_like_count']*/;
  }

  Future<bool> snoozeNotification(int snoozeStatus) async {
    // print(postId.toString());
    // print('INSIDE LIKE POST FUNCTION');
    var response =
        await api.post(Uri.parse(Url.snoozeNotification), queryParameters: {
      'notification_status': snoozeStatus.toString(),
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");
    if (jsonResponse["meta"]["code"] == 200) {
      if (jsonResponse["meta"]["message"] ==
          "Notification enabled successfully") {
        return true;
      } else {
        return false;
      }
    }
  }

  // ignore: missing_return
  Future<Map<String, dynamic>> createComment(String commentText, Post post,
      {int commentId}) async {
    // replyMentionTag[index]=false;

    // replyMentionTag.insert(0, false);

    var response = await api.post(
      Uri.parse(Url.createCommentUrl),
      queryParameters: {
        'post_id': post.postId.toString(),
        'body': commentText,
        'in_reply_to_id': commentId != null ? commentId.toString() : '',
      },
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    var jsonData = json.decode(response);
    // print("$jsonData");
    if (jsonData['meta']['code'] == 200)
      return jsonData;
    else
      return jsonData;
  }

  // ignore: missing_return
  Future<bool> likeComment(int commentId, String reactionType) async {
    // print(commentId.toString());
    // print(reactionType.toString());
    // print('INSIDE LIKE POST FUNCTION');
    var response =
        await api.post(Uri.parse(Url.likeDislikeCommentUrl), queryParameters: {
      'type': reactionType,
      'comment_id': commentId.toString(),
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);

    // print("comment reponse ${response}");

    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");
    if (jsonResponse["meta"]["code"] == 200) {
      return true;
    }
  }

  deleteComment(commentId) async {
    // print("$userToken");

    // ignore: unused_local_variable
    var response = await api.delete(
      Uri.parse(Url.deleteCommentUrl),
      queryParameters: {'comment_id': commentId.toString()},
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read("token"),
      },
    );
    await getSavedPost();

    postList = await getNewsFeed();

    update();
    // print(response.toString());
  }

  bool bookMarkLoading = false;

  Future<bool> unSavePost(int postId) async {
    // print("postId ${postId} ");

    var response = await http.post(
      Uri.parse(Url.unSavePostUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'saved_item_id': postId,
        },
      ),
    );

    // postList =

    // await getNewsFeed();

    // postList.forEach((element) {
    //   print('first screen2');
    //   threadNumber = element.thread_no;
    //   element.likeCount.value = element.simpleLikeCount;
    //   element.rebuzzCount.value = element.retweetCount;
    //   element.commentCount.value = element.commentsCount;
    //   element.reactionType.value = element.isLiked;
    //
    //   element.comments.forEach((element) {
    //     element.reactionType.value = element.isLiked;
    //     element.commentCount.value = element.simpleLikeCount;
    //   });
    //
    //   element.reactionType.refresh();
    //   // if (element.isLiked == nul) {
    //   //   element.like.value = true;
    //   //
    //   // }
    // });

    // print("response.body  ${response.body}");

    var jsonResponse = jsonDecode(response.body);

    Get.put(SavedPostController());
    Get.find<SavedPostController>().savedPostList = await getSavedPost();
    Get.find<SavedPostController>().update();

    if (jsonResponse["meta"]["code"] == 200) {
      // postList=   await  getNewsFeed(reload: true,shouldUpdate : true);
      //
      //
      //   postList.forEach((element) {
      //    print('first screen1');
      //    threadNumber = element.thread_no;
      //    print('thread number:${threadNumber}');
      //    element.likeCount.value = element.simpleLikeCount;
      //    element.rebuzzCount.value = element.retweetCount;
      //    element.commentCount.value = element.commentsCount;
      //
      //    element.reactionType.value = element.isLiked;
      //
      //    element.comments.forEach((element) {
      //      element.reactionType.value = element.isLiked;
      //      element.commentCount.value = element.simpleLikeCount;
      //    });
      //
      //    element.reactionCheck.refresh();
      //
      //    update();
      //
      //    // element.reactionCheck.value = false;
      //    // if (element.isLiked == true) {
      //    //   element.like.value = true;
      //    //   element.like.refresh();
      //    // }
      //  });

      update();
      return true;
    } else {
      return false;
    }
  }

  Future<bool> savePost(postId) async {
    var response = await api.post(
      Uri.parse(Url.savePostUrl),
      queryParameters: {'post_id': '$postId'},
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );

    //postList =

    // await getNewsFeed();

    // postList.forEach((element) {
    //   print('first screen2');
    //   threadNumber = element.thread_no;
    //   element.likeCount.value = element.simpleLikeCount;
    //   element.rebuzzCount.value = element.retweetCount;
    //   element.commentCount.value = element.commentsCount;
    //   element.reactionType.value = element.isLiked;
    //
    //   element.comments.forEach((element) {
    //     element.reactionType.value = element.isLiked;
    //     element.commentCount.value = element.simpleLikeCount;
    //   });
    //
    //   element.reactionType.refresh();
    //   // if (element.isLiked == nul) {
    //   //   element.like.value = true;
    //   //
    //   // }
    // });

    Get.put(SavedPostController());
    Get.find<SavedPostController>().savedPostList = await getSavedPost();
    Get.find<SavedPostController>().update();

    var jsonResponse = jsonDecode(response);
    // print(jsonResponse);

    if (jsonResponse["meta"]["code"] == 200) {
      // postList=   await  getNewsFeed(reload: true,shouldUpdate : true);
      //
      //
      // postList.forEach((element) {
      //   print('first screen1');
      //   threadNumber = element.thread_no;
      //   print('thread number:${threadNumber}');
      //   element.likeCount.value = element.simpleLikeCount;
      //   element.rebuzzCount.value = element.retweetCount;
      //   element.commentCount.value = element.commentsCount;
      //
      //   element.reactionType.value = element.isLiked;
      //
      //   element.comments.forEach((element) {
      //     element.reactionType.value = element.isLiked;
      //     element.commentCount.value = element.simpleLikeCount;
      //   });
      //
      //   element.reactionCheck.refresh();
      //
      //   update();
      //
      //   // element.reactionCheck.value = false;
      //   // if (element.isLiked == true) {
      //   //   element.like.value = true;
      //   //   element.like.refresh();
      //   // }
      // });
      update();
      return true;
    } else {
      return false;
    }
  }

  Future<int> saveUsername(String username) async {
    var response = await http.post(
      Uri.parse(Url.saveUsernameUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'username': username},
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200) {
      storage.write("userName", username.toString());
      userName = username.toString();
      return 1;
    }
    if (response.statusCode == 422) {
      // print("already taken");
      return 2;
    } else {
      return 3;
    }
  }

  Future<int> sendCodeResetEmail(int verificationCode, String email) async {
    var response = await http.post(
      Uri.parse(Url.sendCodeResetEmail),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          "verification_code": verificationCode,
          'new_email': email,
        },
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 && jsonResponse["meta"]["code"] == 200) {
      return 1;
    } else {
      return 2;
    }
  }

  Future<int> sendEmailVerification(String email) async {
    var response = await http.post(
      Uri.parse(Url.sendEmailVerification),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'new_email': email,
        },
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 && jsonResponse["meta"]["code"] == 200) {
      return 1;
    } else {
      return 2;
    }
  }

  Future<int> emailTakenOrNot(String email) async {
    var response = await http.post(
      Uri.parse(Url.emailTakenOrNot),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'email': email,
        },
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 && jsonResponse["meta"]["code"] == 200) {
      emailValidator = false;
      update();
      return 1;
    } else {
      if (email.isEmpty) {
        emailValidator = false;
        update();
      } else {
        emailValidator = true;
        update();
      }

      return 2;
    }
  }

  Future<int> verifyPassword(int userId, String password) async {
    // print("country user id ${userId}");

    var response = await http.post(
      Uri.parse(Url.verifyPassword),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'user_id': userId,
          'current_password': password,
        },
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 && jsonResponse["meta"]["code"] == 200) {
      return 1;
    } else {
      return 2;
    }
  }

  Future<int> changeCountry(int userId, int countryId) async {
    // print("country user id ${userId}");
    // print("country user id ${countryId}");

    var response = await http.post(
      Uri.parse(Url.changeCountryUrl),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {'country_id': countryId, 'user_id': userId},
      ),
    );

    var jsonResponse = jsonDecode(response.body);
    // print("jsonResponse  ${jsonResponse}");

    if (response.statusCode == 200 || jsonResponse["meta"]["code"] == 200) {
      return 1;
    } else {
      return 2;
    }
  }

  Future<List<Post>> getSavedPost() async {
    List<Post> list = [];
    String getResponse = await api.get(
      Uri.parse(Url.getSavedPostUrl + '?page_no=1'),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    final response = jsonDecode(getResponse);
    if (response['meta']['code'] == 200) {
      if (response["data"] != null) {
        response["data"].forEach((element) {
          var data = Post.fromJson(element);
          list.add(data);
          // if (!kIsWeb)
          //   DatabaseHelper.instance.insert(DatabaseHelper.savedPostTable, data.toLocalDBMap());
        });

        list.forEach((element) {
          // print('first screen2');
          threadNumber = element.thread_no;

          element.rebuzz.value = element.isRetweeted;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value = element.simpleLikeCount;
          //
          //
          // });

          element.reactionType.refresh();
          // if (element.isLiked == nul) {
          //   element.like.value = true;
          //
          // }
        });

        // if (!kIsWeb) {
        //   var savedPostData = await DatabaseHelper.instance
        //       .queryAllRows(DatabaseHelper.savedPostTable);
        //   // print('Saved post Data >>>. $savedPostData');
        //   print('Saved post Data >>>. ${savedPostData.length}');
        //   savedPostData.forEach((element) {
        //     print('postFiles >>> ${element}');
        //     var data = Post.fromLocalDbJson(element);
        //     list.add(data);
        //   });
        //   list = new List.from(list.reversed);
        // }

        return list;
      } else
        return list = [];
    } else
      return list = [];
  }

  List<Post> savedlist = [];

  Future<List<Post>> getSavedPostPaged({int page}) async {
    try {
      if (page == 1 || page == null) {
        return savedlist = [];
      }
      var getResponse = await api.get(
        Uri.parse(Url.getSavedPostUrl + '?page_no=' + page.toString()),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      final response = jsonDecode(getResponse);

      if (response['meta']["code"] == 200) {
        if (response['data'] != null) {
          var postData = response['data'] as List;
          List<Post> postList3 = postData.map((e) => Post.fromJson(e)).toList();
          savedlist.addAll(postList3);
          Get.find<SavedPostController>().savedPostList.addAll(postList3);
          return postData.map((e) => Post.fromJson(e)).toList();
        } else {
          return [];
        }
      } else {
        return [];
      }
      // List<Post> postList3 = postData.map((e) => Post.fromJson(e)).toList();
      // savedlist.addAll(postList3);
      // if (response["data"] != null) {
      //   response["data"].forEach((element) {
      //     list.add(Post.fromJson(element));
      //   });
      // }
    } catch (_) {
      return [];
    }
  }

  sharePost(String sharedPostId) {
    api.post(
      Uri.parse(Url.sharePostUrl),
      queryParameters: {
        'shared_post_id': sharedPostId,
        'privacy_option': 'follow_followers',
      },
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
  }

  getSharedPost(String postId) {
    api.get(
      Uri.parse(Url.getSharedPostUrl),
      queryParameters: {'post_id': postId},
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
  }

  Future<List<GetFollowerModel>> followSuggestions() async {
    isWhoToFollow = true;
    followSuggestionsList = [];
    // update();
    // ignore: unused_local_variable
    String value;
    LoginController authController = LoginController();
    var resBody = await authController.followSuggestions(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    });

    if (resBody["meta"]["code"] == 200) {
      for (var element in resBody['data']) {

        followSuggestionsList.add(GetFollowerModel.fromJson(element));

      }
    }
    isWhoToFollow = false;
    update();
    return followSuggestionsList;
  }

  getWerfAnalytics(var postId) async {
    isAnalyticsLoading = true;
    // update();
    var responseBody = await api.post(
      Uri.parse(Url.werfAnalytics),
      queryParameters: {'post_id': postId.toString()},
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );
    var analytics = json.decode(responseBody);
    if (analytics['meta']['code'] == 200) {
      werfAnalytics = WerfAnalytics.fromJson(analytics['data']);
      // print(werfAnalytics.detailExpands);
    }
    isAnalyticsLoading = false;
    // update();
  }

  Future<TrendsModel> getTrendings() async {
    isTrendingLoading = true;
    trendingList = null;
    // update();
    LoginController authController = LoginController();
    SignupController signupController = Get.find<SignupController>();
    var resBody = await authController.getTrendings(
        token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    },
        queryParameters:
        {
          "country_code":signupController.isoCountryCode
        }
        );
    isTrendingLoading = false;
    // print("resBody[data].runtimeType.toString()");
    // print(resBody["data"]);
    // print("resBody[data].runtimeType.toString()");
    if (resBody["meta"]["code"] == 200) {

      trendingList = TrendsModel.fromJson(resBody["data"]);
    }
    update();
    return trendingList;
  }

  Future getCategories() async {
    isLoading = true;
    categoryList = [];
    // update();
    LoginController authController = LoginController();
    var resBody = await authController.getCategory(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    });
    isLoading = false;
    if (resBody["data"].runtimeType.toString() != "_JsonMap") {
      resBody["data"].forEach((element) {
        categoryList.add(CategoryModel.fromJson(element));
      });
      // update(['main_screen']);

      // print("Category length");
      // print(categoryList.length.toString());
    }
    // update();
  }

  // Follow Unfollow User
  Future<List<dynamic>> addFollowing(followedId, text, {postId}) async {
    isLoading = true;
    trendingList.trends = [];
    update();

    // print("followedId $followedId");

    // print("postId $postId");

    // print("postId $text");

    LoginController authController = LoginController();
    var resBody;
    resBody = await authController.followUser(
        token: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "X-Requested-With": "XMLHttpRequest"
        },
        queryParameters: postId != null
            ? {
                "followed_user_id": followedId.toString(),
                'post_id': postId.toString()
              }
            : {
                "followed_user_id": followedId.toString(),
              },
        text: text);
    // print(''';;;;;;;;;
    // ;;;;;;;;;;;;;;;;;
    // ;;;;;;;;;;;;;;;
    // ;;;;;;;''');

    // print('FOLLOWED API ' + resBody.toString());

    isLoading = false;
    if (resBody["data"].runtimeType.toString() != "_JsonMap") {}
    update();
    return trendingList.trends;
  }

  // onSearchTextChanged(String text) async {
  //   searchResult.clear();
  //   if (text.isEmpty) {
  //     return;
  //   }
  //
  //   postList.forEach((userDetail) {
  //     if (userDetail.username.contains(text) ||
  //         userDetail.authorName.contains(text)) searchResult.add(userDetail);
  //     update();
  //   });
  // }

  onSearchTextChanged(String text,
      {bool isSearchBar, bool isFromRoute = false}) async {
    searchResult.clear();
    if (text.isEmpty) {
      isSearch = false;
    } else {
      isSearch = true;
    }

    if (isSearchBar == false) {
      isSearch = false;
      if (!isFromRoute) {
        update();
      }
    }

    var response =
        await api.post(Uri.parse(Url.searchSuggestions), queryParameters: {
      'search_text': text.toString(),
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    wait = false;
    if (!isFromRoute) {
      update();
    } // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");

    if (jsonResponse["meta"]["code"] == 200) {
      searchResult.clear();
      jsonResponse["data"].forEach((ele) {
        searchResult.add(SearchSuggestion.fromJson(ele));
      });
      LoggingUtils.printValue("search resulttt", searchResult.length);

      if (!isFromRoute) {
        update();
      }
    }
    // return jsonResponse['data']['post_counts']['simple_like_count'];
  }

  onSearchTextChangedForDM(String text,
      {bool isSearchBar, bool isFromRoute = false}) async {
    searchResultForDM.clear();

    if (!isFromRoute) {
      update();
    }

    var response =
        await api.post(Uri.parse(Url.searchSuggestions), queryParameters: {
      'search_text': text.toString(),
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    wait = false;
    if (!isFromRoute) {
      update();
    } // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");

    if (jsonResponse["meta"]["code"] == 200) {
      jsonResponse["data"].forEach((ele) {
        searchResultForDM.add(SearchSuggestion.fromJson(ele));
      });
      if (!isFromRoute) {
        update();
      }
    }
    // return jsonResponse['data']['post_counts']['simple_like_count'];
  }

  emitImpressionsSocket(postId) {
    // print('User Id is ' + userId.toString());

    if (socket != null) {
      socket.emit('post_impression', {
        'post_id': postId.toString(),
        'user_id': userId,
      });
    }
  }

  Future<dynamic> filterUsers(
      {id,
      String type,
      filterPeople,
      filterLocation,
      int pageNo = 1,
      tag,
      bool isFromRoute = false}) async {
    // print("idhr aya hai browser");

    try {
      // print("filterUsers api");
      // print("$type");
      // print("$id");
      // print("$tag");
      // print("$otherUserName");
      // print("search");
      filteredPeople = [];
      // if(pageNo>1){
      filteredPost = [];
// }
      isFilter = true;
      if (!isFromRoute) {
        isFilter = true;
        update();
      }
      if (people == 1) {
        filterPeople = "anyone";
      } else if (people == 2) {
        filterPeople = "follow";
      }
      if (place == 1) {
        filterLocation = "anywhere";
      } else if (place == 2) {
        filterLocation = "near_you";
      }

      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        'page_no': pageNo.toString(),
        "id": id.toString(),
        "type": type.toString(),
        "hash_cash_tag": tag ?? otherUserName,
        "tab": seletedTab ?? "top",
        "filter_people": filterPeople ?? "anyone",
        "filter_location": filterLocation ?? "anywhere",
      });

      if (!isFromRoute) {
        isFilter = false;
        update();
      } // print("rep");
      // print(resBody.toString());
      // print("rep");
      SingleTone.instance.searchTag = null;
      SingleTone.instance.searchType = null;
      SingleTone.instance.searchId = null;
      if (resBody["meta"]["code"] == 200) {
        // print("entry");
        filteredPost = [];
        filteredPeople = [];
        resBody["data"].forEach((element) {
          if (seletedTab == "people") {

            filteredPeople.add(FilteredPeople.fromJson(element));


          } else {
            filteredPost.add(Post.fromJson(element));

          }
        });

        debugPrint('filter people length:${filteredPeople.length}');
        debugPrint('filter post  length:${filteredPost.length}');
        filteredPost.forEach((element) {
          // print('first screen2');
          threadNumber = element.thread_no;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          // });

          element.reactionType.refresh();
          // if (element.isLiked == nul) {
          //   element.like.value = true;
          //
          // }
        });
        isFilter = false;
        if (!isFromRoute) {
          update();
        }
      } else {
        isFilter = false;
        filteredPost = [];
        if (!isFromRoute) {
          update();
        }
      }
      // return seletedTab == "people"?filteredPeople:filteredPost;
    } catch (e) {
      // print(e.toString());
    }
  }
  Future<dynamic> hashTagWerfs(
      {
        int pageNo = 1,
        tag,
        bool isFromRoute = false}) async {

    try {

      hashTagList = [];


      if (!isFromRoute) {
        update();
      }


      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        'page_no': pageNo.toString(),
        "id": "0",
        "type": "tag",
        "hash_cash_tag":  tag,
        "tab": "top",
        "filter_people":"anyone",
        "filter_location":"anywhere" ,
      });

      if (!isFromRoute) {
        update();
      } // print("rep");

      //HashTagPost hashTagPost = HashTagPost.fromJson(resBody);
      LoggingUtils.printValue("FILTER POST HASHTAG", resBody.toString());
      if (resBody["meta"]["code"] == 200) {
        hashTagList = [];
        resBody["data"].forEach((element) {





            hashTagList.add(Post.fromJson(element));
            //hashTagPostList.add(HashTagPost.fromJson(element) as HashTagPost);

        });

        hashTagList.forEach((element) {
          //print('first screen2');
          threadNumber = element.thread_no;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          // });

          element.reactionType.refresh();
          // if (element.isLiked == nul) {
          //   element.like.value = true;
          //
          // }
        });

        if (!isFromRoute) {
          update();
        }
        update();
      } else {
        hashTagList = [];
        if (!isFromRoute) {
          update();
        }
      }
      // return seletedTab == "people"?filteredPeople:filteredPost;
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION FILTER POST HASHTAG", e);

      // print(e.toString());
    }
  }
  Future<List<Post>> hashTagWerfsPagged(
      {
        int pageNo = 1,
        tag}) async {
    try {

      if (pageNo == 1) {
        hashTagList = [];
      }


      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        'page_no': pageNo.toString(),
        "id": "0",
        "type": "tag",
        "hash_cash_tag": tag ,
        "tab":  "top" ,
        "filter_people": "anyone" ,
        "filter_location": "anywhere" ,
      });

      if (resBody["meta"]["code"] == 200) {
        if (pageNo == 1) {
          hashTagList = [];
        }
        resBody["data"].forEach((element) {


          hashTagList.add(Post.fromJson(element));


        });

        hashTagList.forEach((element) {
          threadNumber = element.thread_no;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;

          element.reactionType.refresh();

        });
        return hashTagList;
        // update();
      } else {
        return [];
      }
    } catch (e) {
      // print(e.toString());
    }
  }
  Future<List<Post>> filterUsersPagged(
      {id,
      String type,
      filterPeople,
      filterLocation,
      int pageNo = 1,
      tag}) async {
    try {
      // print("search");
      // print("$type");
      // print("$id");
      // print("search");
      filteredPeople = [];
      if (pageNo == 1) {
        filteredPost = [];
      }
      isFilter = true;
      // update();
      if (people == 1) {
        filterPeople = "anyone";
      } else if (people == 2) {
        filterPeople = "follow";
      }
      if (place == 1) {
        filterLocation = "anywhere";
      } else if (place == 2) {
        filterLocation = "near_you";
      }

      LoginController signupController = LoginController();
      var resBody;
      resBody = await signupController.filterPost(token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      }, queryParameters: {
        'page_no': pageNo.toString(),
        "id": id.toString(),
        "type": type.toString(),
        "hash_cash_tag": tag == null ? otherUserName : tag,
        "tab": seletedTab == null ? "top" : seletedTab,
        "filter_people": filterPeople == null ? "anyone" : filterPeople,
        "filter_location": filterLocation == null ? "anywhere" : filterLocation,
      });

      // isFilter = false;
      // update();
      // print("rep");
      debugPrint('Filter result ---->>> ${resBody.toString()}');
      // print("rep");
      if (resBody["meta"]["code"] == 200) {
        // print("entry");
        if (pageNo == 1) {
          filteredPost = [];
        }
        filteredPeople = [];
        resBody["data"].forEach((element) {
          // print("element");
          // print(element);
          // print("element");
          if (seletedTab == "people") {
            // print("people");
            filteredPeople.add(FilteredPeople.fromJson(element));
          } else {
            // print("other");
            //
            filteredPost.add(Post.fromJson(element));

            // print("length");
            // print(filteredPost.length.toString());
            // print("length");
          }
        });

        filteredPost.forEach((element) {
          threadNumber = element.thread_no;
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          // });

          element.reactionType.refresh();
          // if (element.isLiked == nul) {
          //   element.like.value = true;
          //
          // }
        });
        return filteredPost;
        // update();
      } else {
        return [];
      }
      // return seletedTab == "people"?filteredPeople:filteredPost;
    } catch (e) {
      // /e.toString());
    }
  }

  Future<int> reportPost(reportPostId, postId, text) async {
    LoginController signupController = LoginController();
    var resBody;
    resBody = await signupController.reportPost(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "report_post_id": postId.toString(),
      "report_id": reportPostId.toString(),
      "body": text.toString(),
    });

    // print(resBody);
    if (resBody['meta']['code'] == 200) {
      return 200;
    }
    if (resBody['meta']['code'] == 400) {
      return 400;
    }
  }

  Future<int> reportUser(reportProfileId, categoryReportId) async {
    LoginController signupController = LoginController();
    var resBody;
    resBody = await signupController.reportUser(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "reported_profile_id": reportProfileId.toString(),
      "report_id": categoryReportId.toString(),
      // "body": text.toString(),
    });

    // print(resBody);
    if (resBody['meta']['code'] == 200) {
      return 200;
    }
    if (resBody['meta']['code'] == 400) {
      return 400;
    }
  }

  void updateControllers(int checkScreen) {
    if (checkScreen == 1) {
      Get.find<NewsfeedController>().update();
    } else if (checkScreen == 2) {
      Get.find<ProfileController>().update();
    } else if (checkScreen == 3) {
      Get.find<BrowseController>().update();
    } else if (checkScreen == 4) {
      Get.find<SavedPostController>().update();
    } else if (checkScreen == 5) {
      Get.find<NewsfeedController>().update();
    } else if (checkScreen == 6) {
      Get.find<TopicController>().update();
    } else if (checkScreen == 7) {
      Get.find<OtherTopicController>().update();
    } else if (checkScreen == 9) {
      Get.find<OtherUserController>().update();
    }
  }

  Future<bool> hidePost(postId, {int checkScreen, int topicId}) async {
    isLoading = true;
    update();

    // print("postid1231231231313 ${postId.toString()}");

    LoginController authController = LoginController();
    var resBody;
    resBody = await authController.hidePost(token: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    }, queryParameters: {
      "post_id": postId.toString(),
    });

    isLoading = false;
    if (resBody["meta"]["code"] == 200) {
      if (checkScreen == 1) {
        // print("Post Hidden");
        // if (Get.isRegistered<NewsfeedController>()) {
        //   Get.find<NewsfeedController>().postList;
        //   Get.find<NewsfeedController>().update();
        postList = await getNewsFeed(reload: true, shouldUpdate: true);
        // }
        //
      } else if (checkScreen == 2) {
        Get.find<ProfileController>().userProfile = await getUserProfile();

        await Get.find<ProfileController>().filterUsersPost("posts");
        Get.find<ProfileController>().userPosts.forEach((element) {
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value  = element.simpleLikeCount;
          // });
          element.reactionType.refresh();

          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
        Get.find<ProfileController>().update();
      } else if (checkScreen == 3) {
        Get.find<BrowseController>().isLoading = true;

        Get.find<BrowseController>().browsePostList = [];
        Get.find<BrowseController>().update();
        Get.find<BrowseController>().browsePostList =
            await Get.find<BrowseController>().getBrowsePost();
        // Get.find<BrowseController>().update();
      } else if (checkScreen == 4) {
        Get.find<SavedPostController>().savedPostList = [];
        Get.find<SavedPostController>().isLoading = true;
        Get.find<SavedPostController>().update();
        Get.find<SavedPostController>().savedPostList =
            await Get.find<SavedPostController>()
                .newsFeedControloler
                .getSavedPost();
        Get.find<SavedPostController>().isLoading = false;
        Get.find<SavedPostController>().update();
      } else if (checkScreen == 5) {
        // print("1231231231");
        await filterUsers(
          id: 0.toString(),
          type: "tag",
          tag: searchText.text,
          // id: id,
          // type: controller.searchResult[0].type,
        );

        update();
      } else if (checkScreen == 6) {
        // print(topicId);
        Get.find<TopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<TopicController>().update();
      } else if (checkScreen == 7) {
        // print(topicId);
        Get.find<OtherTopicController>().othertopicid = topicId;
        Get.find<OtherTopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<OtherTopicController>().update();
      } else if (checkScreen == 8) {
        getCommentsList.removeWhere((element) => element.postId == postId);
        update();

        // if(kIsWeb)
        //   {
        //     SingleTone.instance.commentId = commentId;
        //     if (commentId == 1) {
        //       MobileCommentsController mobileController;
        //       if (Get.isRegistered<MobileCommentsController>()) {
        //         mobileController =
        //         await Get.find<MobileCommentsController>();
        //         selectedPost2 =
        //         await mobileController.getSingleNewsFeedItem(
        //             postId, isReload: true);
        //         getCommentsList =
        //         await mobileController.getCommentsPostLists(
        //             postId: postId);
        //       } else {
        //         mobileController =
        //         await Get.put(MobileCommentsController());
        //       }
        //     }
        //     postId = postId;
        //     SingleTone.instance.post_Id = postId;
        //     // controller.threadNumber = null;
        //     // controller.selectedPost = post;
        //     navRoute = "isPostDetail";
        //     detailPageCounter++;
        //     /"postcard");
        //
        //     if (navRoute == "isPostDetail") {
        //       Get.toNamed(FluroRouters.mainScreen + "/postDetail/" + postId.toString());
        //     } else {
        //       Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
        //           postId.toString());
        //     }
        //     // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());
        //
        //     // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));
        //
        //
        //     print('post id:${postId}');
        //     print('singtone post id:${SingleTone.instance.post_Id}');
        //     selectedPost2 = await getSingleNewsFeedItem(
        //         postId, isReload: true);
        //       update();
        //
        //
        //   }
        // else{
        //
        //   if (commentId == 1) {
        //     if (Get.isRegistered<
        //         MobileCommentsController>()) {
        //       Get.delete<
        //           MobileCommentsController>();
        //     }
        //
        //     Route route = MaterialPageRoute(builder: (context) =>
        //         CommentsScreen(
        //           postId: postId, thread_no: null,));
        //     Navigator.pushReplacement(context, route);
        //   }
        //   else {
        //     selectedPost = post;
        //     commentController.clear();
        //     selectedPost = post;
        //     Navigator.push(context, MaterialPageRoute(
        //         builder: (BuildContext context) =>
        //             CommentsScreen(
        //               postId: post.postId, thread_no: null,)));
        //     postId = post.postId;
        //
        //     //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
        //     // controller.isPostDetails = true;
        //     // controller.postDetail =
        //     //     await controller.getSingleNewsFeedItem(post.postId);
        //   }
        // }
      } else if (checkScreen == 9) {
        Get.find<OtherUserController>().filterUsersPostPagged("posts", page: 1);
        // Get.find<OtherUserController>().userPosts = await filterUsersPost('posts');
        Get.find<OtherUserController>().update();
      }

      // print("hide post${resBody}");
      // postList = await getNewsFeed(reload: true);
      update();
      return true;
    }

    return false;
  }




  Future<bool> hideUnHideComment(postId) async {


    // print("postid1231231231313 ${postId.toString()}");

    // print("getCommentsList ${getCommentsList.length}}");


    var resBody;

    resBody = await http.post(
      Uri.parse(Url.hideUnhideComments),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'comment_id': postId,
        },
      ),

    );


    //
    // print("resBody ${resBody.body.toString()}");
    var parsedJson = jsonDecode(resBody.body);

    if (parsedJson["meta"]["code"] == 200) {


      // print("getCommentsList ${getCommentsList.length}}");

      getCommentsList.removeWhere((element) => element.postId == postId);

      if(Get.isRegistered<MobileCommentsController>())
        {
          Get.find<MobileCommentsController>().update();
        }

      update();

      return true;
    }

    return false;
  }


  Future<bool> UnHidePost(int postId, int checkScreen) async {


    // print("postid1231231231313 ${postId.toString()}");

    // print("getCommentsList ${getCommentsList.length}}");


    var resBody;

    resBody = await http.post(
      Uri.parse(Url.UnhidePost),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: jsonEncode(
        {
          'post_id': postId,
        },
      ),

    );


    //
    // print("resBody ${resBody.body.toString()}");
    var parsedJson = jsonDecode(resBody.body);

    if (parsedJson["meta"]["code"] == 200) {


       if (checkScreen == 2) {
         Get.find<ProfileController>().userPosts=  await Get.find<ProfileController>().filterUsersPostForHiddenReplies(page: 1);
        Get.find<ProfileController>().userPosts.forEach((element) {
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value  = element.simpleLikeCount;
          // });
          element.reactionType.refresh();

          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
        Get.find<ProfileController>().update();
      }

      update();

      return true;
    }

    return false;
  }



  Future<void> deletePost(int postId,
      {List<Post> postList, int id, int topicId, int idForComments}) async {
    /*  int ind = postList.indexWhere((element) {
      return element.postId == postId;
    });

    print("post id   $postId");

    print("idex   $ind");

    postList.removeAt(ind);
    update();*/
    var resBody;
    // print("sdfsdfsdfsdfsdf");

    resBody = await api.delete(
      Uri.parse(Url.deletePost + '?post_id=$postId'),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    var response = jsonDecode(resBody);

    if (response["meta"]["code"] == 200) {
      if (id == 1) {
        // print("hello thread");
        // if (Get.isRegistered<NewsfeedController>()) {
        //   Get.find<NewsfeedController>().postList;
        //   Get.find<NewsfeedController>().update();
        postList = await getNewsFeed(reload: true, shouldUpdate: true);
        this.postList.removeWhere((element) => element.postId == postId);
        // }
        //
      } else if (id == 2) {
        // if (Get.isRegistered<ProfileController>()) {
        //   Get.find<ProfileController>().userPosts;
        //   Get.find<ProfileController>().update();
        //
        // }
        Get.find<ProfileController>().userProfile = await getUserProfile();

        await Get.find<ProfileController>().filterUsersPost("posts");
        Get.find<ProfileController>().userPosts.forEach((element) {
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          // element.comments.forEach((element) {
          //   element.reactionType.value = element.isLiked;
          //   element.commentCount.value  = element.simpleLikeCount;
          // });
          element.reactionType.refresh();

          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
        Get.find<ProfileController>().update();
      } else if (id == 3) {
        // if (Get.isRegistered<ProfileController>()) {
        //   Get.find<ProfileController>().userPosts;
        //   Get.find<ProfileController>().update();
        //
        // }

        Get.find<BrowseController>().isLoading = true;

        Get.find<BrowseController>().browsePostList = [];
        Get.find<BrowseController>().update();
        Get.find<BrowseController>().browsePostList =
            await Get.find<BrowseController>().getBrowsePost();
        // Get.find<BrowseController>().update();
      } else if (id == 4) {
        Get.find<SavedPostController>().savedPostList = [];
        Get.find<SavedPostController>().isLoading = true;
        Get.find<SavedPostController>().update();
        Get.find<SavedPostController>().savedPostList =
            await Get.find<SavedPostController>()
                .newsFeedControloler
                .getSavedPost();
        Get.find<SavedPostController>().isLoading = false;
        Get.find<SavedPostController>().update();
      } else if (id == 5) {
        // print("1231231231");
        await filterUsers(
          id: 0.toString(),
          type: "tag",
          tag: searchText.text,
          // id: id,
          // type: controller.searchResult[0].type,
        );

        update();
      } else if (id == 6) {
        // print(topicId);
        Get.find<TopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<TopicController>().update();
      } else if (id == 7) {
        // print(topicId);
        Get.find<OtherTopicController>().othertopicid = topicId;
        Get.find<OtherTopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<OtherTopicController>().update();
      } else if (id == 8) {
        // print('comment remove');
        int index = selectedPost2.indexWhere((element) {
          return element.postId == idForComments;
        });
        selectedPost2[index].commentCount.value--;
        //  Get.find<MobileCommentsController>().getSingleNewsFeedItem(idForComments,);
        Get.find<MobileCommentsController>()
            .getCommentsPostLists(postId: idForComments);

        Get.find<MobileCommentsController>().update();
      }

      update();
    }
  }

  Future<bool> blockUser(userId, {int checkScreen, int topicId}) async {
    isLoading = true;
    update();

    var response = await api.post(
      Uri.parse(Url.blockUserUrl),
      queryParameters: {
        'blocked_id': userId.toString(),
      },
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    // print("MY RESP BODY $response");

    // ignore: unused_local_variable
    var json = jsonDecode(response);
    if (json["meta"]["code"] == 200) {
      socket.emit('block_user', {
        'user_id': GetStorage().read('id'),
        'blocked_user': userId,
        'slug': ''
      });

      if (checkScreen == 9) {
        isOtherUserProfileScreen = false;
        isNewsFeedScreen = true;
        update();
      }

      getNewsFeed(reload: true, shouldUpdate: true);

      if (checkScreen == 3) {
        // if (Get.isRegistered<ProfileController>()) {
        //   Get.find<ProfileController>().userPosts;
        //   Get.find<ProfileController>().update();
        //
        // }

        Get.find<BrowseController>().isLoading = true;

        Get.find<BrowseController>().browsePostList = [];
        Get.find<BrowseController>().update();
        Get.find<BrowseController>().browsePostList =
            await Get.find<BrowseController>().getBrowsePost();
        // Get.find<BrowseController>().update();
      } else if (checkScreen == 2) {
        // if (Get.isRegistered<ProfileController>()) {
        //   Get.find<ProfileController>().userPosts;
        //   Get.find<ProfileController>().update();
        //
        // }
        Get.find<ProfileController>().userProfile = await getUserProfile();

        await Get.find<ProfileController>().filterUsersPost("posts");
        Get.find<ProfileController>().userPosts.forEach((element) {
          element.likeCount.value = element.simpleLikeCount;
          element.rebuzzCount.value = element.retweetCount;
          element.commentCount.value = element.commentsCount;
          element.reactionType.value = element.isLiked;
          element.reactionType.refresh();

          // if (element.isLiked == true) {
          //   element.like.value = true;
          //   element.like.refresh();
          // }
        });
        Get.find<ProfileController>().update();
      } else if (checkScreen == 4) {
        Get.find<SavedPostController>().savedPostList = [];
        Get.find<SavedPostController>().isLoading = true;
        Get.find<SavedPostController>().update();
        Get.find<SavedPostController>().savedPostList =
            await Get.find<SavedPostController>()
                .newsFeedControloler
                .getSavedPost();
        Get.find<SavedPostController>().isLoading = false;
        Get.find<SavedPostController>().update();
      } else if (checkScreen == 5) {
        // print("1231231231");
        await filterUsers(
          id: 0.toString(),
          type: "tag",
          tag: searchText.text,
          // id: id,
          // type: controller.searchResult[0].type,
        );

        update();
      } else if (checkScreen == 6) {
        // print(topicId);
        Get.find<TopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<TopicController>().update();
      } else if (checkScreen == 7) {
        // print(topicId);
        Get.find<OtherTopicController>().othertopicid = topicId;
        Get.find<OtherTopicController>().topicPost(topicId: topicId, pageNO: 1);
        Get.find<OtherTopicController>().update();
      }

      return true;
    }

    await fetchPosts();

    update();
    return false;
    // print(response);
  }

  Future<bool> blockUserFromChat(userId) async {

    var response = await api.post(
      Uri.parse(Url.blockUserUrl),
      queryParameters: {
        'blocked_id': userId.toString(),
      },
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    debugPrint("Block user from chat Response: $response");

    var json = jsonDecode(response);
    if (json["meta"]["code"] == 200) {
     return true;
    } else {
      return false;
    }
  }

  Future<List<BlockedUser>> getBlockedUsersList() async {
    var response = await api.get(
      Uri.parse(Url.blockedUsersList),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    var blockedUsersData = json.decode(response);
    if (blockedUsersData['meta']['code'] != 200) {
      // print('INSIDE MESSAGE');
      return null;
    } else {
      var blockedUsers = blockedUsersData['data'] as List;

      return blockedUsers.map((e) => BlockedUser.fromJson(e)).toList();
    }
  }

  // ignore: missing_return

  bool rLoading = false;

  Reactions allReaction;

  Future<Reactions> getWhoReacted(int postId,
      {String reactionType, int allLikes}) async {
    // print("allLikes $allLikes");
    if (reactionType != "love" &&
        reactionType != "like_simple_like" &&
        reactionType != "lough" &&
        reactionType != "excited" &&
        reactionType != "thanks" &&
        reactionType != "cry" &&
        reactionType != "smile" &&
        allLikes == 0) {
      reactionLoading = true;
      update();
    }

    rLoading = true;
    update();

    var responseBody = await api.post(
      Uri.parse(Url.whoReactedUrl),
      queryParameters: {
        'post_id': postId.toString(),
        "type": reactionType,
      },
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );

    // print("responseBody $responseBody");
    var reactions = json.decode(responseBody);
    if (reactions['meta']["code"] == 200) {
      var reactionsData = Reactions.fromJson(reactions);

      if (reactionType != "love" &&
          reactionType != "like_simple_like" &&
          reactionType != "lough" &&
          reactionType != "excited" &&
          reactionType != "thanks" &&
          reactionType != "cry" &&
          reactionType != "smile") {
        reaction = reactionsData;
      } else {
        reaction.data.reactedUser = null;
        allReaction = reactionsData;
      }

      rLoading = false;
      update();
      if (reactionType != "love" &&
          reactionType != "like_simple_like" &&
          reactionType != "lough" &&
          reactionType != "excited" &&
          reactionType != "thanks" &&
          reactionType != "cry" &&
          reactionType != "smile" &&
          allLikes == 0) {
        reactionLoading = false;
        update();
      }

      // print("reactionLoading $reactionLoading");
      update();
      return reactionsData;
    }
  }

  CommentReaction commentReaction;
  CommentReaction allCommentReaction;

  bool commentLoading = false;

  Future<CommentReaction> getWhoReactedForCommment(int commentId,
      {String reactionType, int allLikes}) async {
    // print("allLikes $allLikes");
    if (reactionType != "love" &&
        reactionType != "simple_like" &&
        reactionType != "lough" &&
        reactionType != "excited" &&
        reactionType != "thanks" &&
        reactionType != "cry" &&
        reactionType != "smile" &&
        allLikes == 0) {
      reactionLoading = true;
      update();
    }

    rLoading = true;
    update();

    var responseBody = await api.post(
      Uri.parse(Url.whoReactedForCommentUrl),
      queryParameters: {
        'comment_id': commentId.toString(),
        "type": reactionType,
      },
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );

    // print("responseBody $responseBody");
    var reactions = json.decode(responseBody);
    if (reactions['meta']["code"] == 200) {
      var reactionsData = CommentReaction.fromJson(reactions);

      if (reactionType != "love" &&
          reactionType != "simple_like" &&
          reactionType != "lough" &&
          reactionType != "excited" &&
          reactionType != "thanks" &&
          reactionType != "cry" &&
          reactionType != "smile") {
        commentReaction = reactionsData;
      } else {
        commentReaction.data.reactedUser = null;
        allCommentReaction = reactionsData;
      }

      rLoading = false;
      update();
      if (reactionType != "love" &&
          reactionType != "simple_like" &&
          reactionType != "lough" &&
          reactionType != "excited" &&
          reactionType != "thanks" &&
          reactionType != "cry" &&
          reactionType != "smile" &&
          allLikes == 0) {
        reactionLoading = false;
        update();
      }

      // print("reactionLoading $reactionLoading");
      update();
      return reactionsData;
    }
  }

  // ignore: missing_return
  Future<List<Retweet>> getWhoRetweeted(int postId) async {
    var responseBody = await api.post(
      Uri.parse(Url.whoRetweetedUrl),
      queryParameters: {'post_id': postId.toString()},
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );
    var retweets = json.decode(responseBody);
    if (retweets['meta']['code'] == 200) {
      var retweetsData = retweets['data'] as List;

      return retweetsData.map((e) => Retweet.fromJson(e)).toList();
    }
  }

  Future<String> addRetweet(int postId, {Post post}) async {
    // print("post id  $postId");
    var responseBody = await api.post(
      Uri.parse(Url.addRetweetUrl),
      queryParameters: {'post_id': postId.toString()},
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );
    var decodedResponse = json.decode(responseBody);
    var retweetResponse = decodedResponse['meta']['message'];

    // post.undoRewerf = false;

    UtilsMethods.toastMessageShow(displayColor, displayColor, displayColor,
        message: Strings.rewerfSuccessfully);

    // post.rebuzzCount.value   =  decodedResponse['data']['retweet_count'];
    //  update();

    return retweetResponse;
  }

  Future<String> undoRetweet(int postId, {Post post}) async {
    var responseBody = await api.post(
      Uri.parse(Url.undoRetweetUrl),
      queryParameters: {'post_id': postId.toString()},
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );

    var decodedResponse = json.decode(responseBody);
    var retweetResponse = decodedResponse['meta']['message'];

    //post.undoRewerf = true;

    // print("count   ${decodedResponse['data']['retweet_count'].toString()}");
    // post.rebuzzCount.value   =  decodedResponse['data']['retweet_count'];
    // update();
    UtilsMethods.toastMessageShow(
      displayColor,
      displayColor,
      displayColor,
      message: 'Undo ReWerf successfully.',
    );
    //  update();
    return retweetResponse;
  }

  // Chat Privacy Setting
  Future<void> privacyRequest({String privacy}) async {
    var response =
        await api.post(Uri.parse(Url.chatPrivacyUrl), queryParameters: {
      'privacy': privacy,
    }, token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': userToken.toString(),
    });
    var jsonResponse = jsonDecode(response);
    // print("jsonResponse");
    // print(jsonResponse);
    // print("jsonResponse");
    if (jsonResponse["meta"]["code"] == 200) {
      if (!kIsWeb) {
        UtilsMethods.toastMessageShow(displayColor, displayColor, displayColor,
            message: Strings.privacyUpdated);
        // Get.snackbar("Success", "Privacy updated",
        //     backgroundColor: Color(0xFFedab30), colorText: Colors.white);
      }
      userPrivacy = await getUserCahtPrivacy();
      update();
    }
  }

  //Add New Members to Group Chat
  addMembersToGroupChat(conversationId, memberId) async {
    var response = await api.post(
      Uri.parse(Url.addMemberChat),
      queryParameters: {
        'conversation_id': conversationId.toString(),
        'member_id': memberId.toString(),
      },
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': userToken.toString(),
      },
    );

    // print('RESPONSE  ' + response);
  }

  //Get user chat Privacy
  Future<String> getUserCahtPrivacy() async {
    var response = await api.get(
      Uri.parse(Url.getChatPrivacyUrl),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );
    var privacyData = json.decode(response);
    if (privacyData['meta']['code'] != 200) {
      return null;
    } else {
      // var blockedUsers = blockedUsersData['data'] as List;
      //
      return privacyData['data']['setting_value'];
    }
  }

  Future<List<dynamic>> searchChatUser(String value, {type}) async {
    value = value.replaceAll('@', '');
    // print("API VALUE   $value");
    // print("API VALUE   $type");
    // print(type == null ? null : type);
    isChatUsersLoad = true;
    //   update();
    // LoginController signupController = LoginController();
    var resBody = await searchUsers(queryParameters: {
      "search_text": value,
      "type": type == null ? '' : type,
    }, token: {
      "Authorization": " Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    });

    isChatUsersLoad = false;
    // update();

    return resBody;
  }

  Future<List<dynamic>> searchUsers(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    // print("sdadasd");
    // print(queryParameters["search_text"]);
    // print(queryParameters["type"]);

    Api api = Api();
    var response = await api.post(Uri.parse(Url.searchUsers),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    if (json["meta"]["code"] == 200) {
      // print("sdfdfs");
      return json['data'];
    } else if (json["meta"]["code"] == 400) {
      return json['data'];
    }
    // print(response);
    // return ;
  }

  Future<List<dynamic>> searchUsersForPost(
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    Api api = Api();
    var response = await api.post(Uri.parse(Url.searchUsers),
        queryParameters: queryParameters, token: token);
    var json = jsonDecode(response);
    if (json["meta"]["code"] == 200) {
      return json['data'];
    } else if (json["meta"]["code"] == 400) {
      return [false];
    }
    // print(response);
    // return ;
  }

  Future<List<dynamic>> searchTags(value) async {
    // print(value);
    LoginController signupController = LoginController();

    var resBody = await api.post(Uri.parse(Url.searchTags), queryParameters: {
      "search_text": value,
    }, token: {
      "Authorization": " Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "X-Requested-With": "XMLHttpRequest"
    });
    var json = jsonDecode(resBody);

    if (json['meta']['code'] == 200) {
      // print('response of search tags:${resBody}');
      return json['data'];
    } else {
      return [];
    }
  }

  // ignore: missing_return
  Future<String> uploadFileChat(
      Uint8List fileBytes, int conversationId, String fileName,
      {String textMessage}) async {
      isVideoThumbnail = false;

      if (isVideoPickedChat) {
        isVideoPickedChat = false;
        isVideoUpload = true;
      }
      if (isDocumentPickedChat) {
        isDocumentPickedChat = false;
        isDocUpload = true;
      }
      if (isImagePickedChat) {
        isImagePickedChat = false;
        isImageUpload = true;
      }
      update();
      Map<String, String> headers = {
        "Token": storage.read('token'),
        "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "*",
      };
      var request =
      http.MultipartRequest('POST', Uri.parse(Url.createMessageImage));
      request.headers.addAll(headers);

      request.files.add(
          http.MultipartFile.fromBytes('file', fileBytes, filename: fileName));
      request.fields['conversation_id'] = conversationId.toString();
      var response = await request.send();
      final responseStr = await response.stream.bytesToString();

      // response.stream.bytesToString().asStream().listen((event) {
      //   var parsedJson = json.decode(event);
      var parsedJson = json.decode(responseStr);

      // print("file data ${parsedJson}");
      // print("event");
      // print(event);
      // print("event");
      // print('IMAGE RRRRRRREEEEEEESSSSSSPPPPPPOOOONNNNNNNSSSSEE' +
      //     parsedJson.toString());
      if (parsedJson['data']['file']['url'] != null) {
        // print('hello asadd');
        String url = parsedJson['data']['file']['url'];

        // print('Breake String' + parsedJson['data']['file']['thumbnail_url']);
        sendMessage(
            chatData: chatName,
            FileData: {
              "name": parsedJson['data']['file']['filename'],
              "path": parsedJson['data']['file']['url'],
              "thumbnail_url": parsedJson['data']['file']['thumbnail_url'] ?? '',
              "size": parsedJson['data']['file']['size']
            },
            fileEx: url.substring(url.lastIndexOf('.'), url.length),
            textMessage: textMessage);
        isVideoUpload = false;
        isDocUpload = false;
        isImageUpload = false;
        update();
        return parsedJson['data']['file']['url'];
      } else {
        isVideoUpload = false;
        isDocUpload = false;
        isImageUpload = false;
        update();
      }
    // });
  }

  //Chat
  // ignore: missing_return
  Future<List<ChatUserModel>> getMessageRequest(
      {bool isFromRoute = false}) async {
    try {
      // isChatLoad = true;
      if (!isFromRoute) {
        update();
      }
      // print("chat request api call");
      var response = await api.get(
        Uri.parse(Url.getChatRequestUrl),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          // 'Content-type' : 'application/json',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      // print('CHAAAAAAAAAAAAAT    ' + response.toString());
      // print("gettt chat");
      var jsonData = json.decode(response);
      var postData = jsonData['data'] as List;
      if (jsonData['meta']['code'] == 200) {
        // isChatLoad = false;
        if (!isFromRoute) {
          update();
        }
        chatRequestUserList =
            postData.map((e) => ChatUserModel.fromJson(e)).toList();

        /*  chatUserList.forEach((element) {

          print("get element.name   ${element.name}");
        });*/

        // chatUserList2.clear();
        // update();
        // chatUserList.forEach((element) {
        //   chatUserList2.add(element);
        // });

        // print("Messgae Request " + chatRequestUserList.length.toString());

        // print('SSSSUUUCCCCEEEESSSS');
        if (!isFromRoute) {
          update();
        }
      }
      // isChatLoad = false;
      return chatRequestUserList;
    } catch (e) {
      // isChatLoad = false;
      LoggingUtils.printValue("mesg request errot", e);
      if (!isFromRoute) {
        update();
      }
      // print("errror$e");
    }
  }

  Future<List<ChatUserModel>> getChat({bool isFromRoute = false}) async {
    try {
      isChatLoad = true;
      if (!isFromRoute) {
        update();
      }
      // print("chat api call");
      var response = await api.post(
        Uri.parse(Url.getChatUrl),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      // print('CHAAAAAAAAAAAAAT    ' + response.toString());
      // print("gettt chat");
      var jsonData = json.decode(response);
      var postData = jsonData['data'] as List;
      // print("no error");
      if (jsonData['meta']['code'] == 200) {
        isChatLoad = false;
        if (!isFromRoute) {
          update();
        }
        chatUserList = postData.map((e) => ChatUserModel.fromJson(e)).toList();

        /*  chatUserList.forEach((element) {

          print("get element.name   ${element.name}");
        });*/

        // chatUserList2.clear();
        // update();
        // chatUserList.forEach((element) {
        //   chatUserList2.add(element);
        // });

        // print(chatUserList);

        // print('SSSSUUUCCCCEEEESSSS');
        if (!isFromRoute) {
          update();
        }
      }
      return chatUserList;
    } catch (e) {
      isChatLoad = false;
      if (!isFromRoute) {
        update();
      }
      return [];
      // print("errror$e");
    }
  }

  Future<List<ChatUserModel>> getChatForMessageScreen() async {
    try {
      // print("chat api call");
      var response = await api.post(
        Uri.parse(Url.getChatUrl),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      // print('CHAAAAAAAAAAAAAT    ' + response.toString());
      // print("gettt chat");
      String myToken = storage.read('token');
      // print("MyToken : ${myToken}");
      var jsonData = json.decode(response);
      var postData = jsonData['data'] as List;
      if (jsonData['meta']['code'] == 200) {
        chatUserList.clear();
        chatUserList = postData.map((e) => ChatUserModel.fromJson(e)).toList();

        chatUserList.forEach((element) {
          // print("element.name  ${element.name}");
        });

        // chatUserList2.clear();
        // update();
        //
        // chatUserList.forEach((element) {
        //   chatUserList2.add(element);
        // });

        update();
      }
      return chatUserList;
    } catch (e) {
      update();
      // print("errror$e");
    }
  }

  Future<void> searchChat(String searchText) async {
    // print('Search Chat API Init');
    String myToken = storage.read('token');
    // print("MyToken : ${myToken}");
    try {
      var response = await api.get(
          Uri.parse("${Url.chatSearchUrl}?toSearch=$searchText"),
          token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      // print('Search Chat Response : $searchText : $response');
      // Expected a value of type 'String', but got one of type 'int'
      var jsonData = json.decode(response);
      // print('001 Search Chat Response : $searchText : $jsonData');
      if (jsonData['meta']['code'] == 200) {
        chatSearchMessageList.clear();
        // chatSearchMessageList = messageData.map((e) => ChatUserModel.fromJson(e)).toList();
        // print("002 Messages : ${jsonData['data']['messages']}");
        chatSearchMessageList = (jsonData['data']['messages'] as List).map((e) => MessageModel.fromJson(e)).toList();
        // print("003 People : ${jsonData['data']['people']}");
        chatSearchPeopleList = (jsonData['data']['people'] as List).map((e) => MessageModel.fromJson(e)).toList();
        // print("004 Groups : ${jsonData['data']['groups']}");
        chatSearchGroupList = (jsonData['data']['groups'] as List).map((e) => ChatUserModel.fromJson(e)).toList();
        // print("Message Length : ${chatSearchMessageList.length}");
        // print("Message Length : ${chatSearchPeopleList.length}");
        // print("Group Length : ${chatSearchGroupList.length}");
        update();

      }
    } catch (e) {
      // print("searchChat error : $e");
    }
  }

  int chatIndex = 0;

  Future<void> createChat(idList, chatType,
      {String groupName, String groupImage, String groupMemberName}) async {
    debugPrint("Create Chat 001");
    try {
      // print("idList");
      // print(idList.toString());
      // print("idList");
      var params = chatType == "group"
          ? {
              "conversation_type": "group",
              "member_ids": idList,
              // "conversation_name": groupName == null ? groupMemberName : groupName,
              "group_chat_image": groupImage != null ? groupImage : null
            }
          : {
              "conversation_type": "single",
              "member_ids": idList,
            };
      _dio.Dio dio = _dio.Dio();

      // ignore: unused_local_variable
      _dio.Response response = await dio.post(
        Url.createChatUrl,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
              "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        data: jsonEncode(params),
      );
      debugPrint("chat create response " + response.toString());
    } catch (e) {
      // print(e.toString());
    }
  }

  leaveConversation(int conversationId) async {
    var response = await api.post(Uri.parse(Url.leaveConversation), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    }, queryParameters: {
      "conversation_id": conversationId.toString(),
    });
    var parsedJson = json.decode(response);
    // print(response);
    if (parsedJson['meta']['code'] == 200) {
      infoChatInfo = false;
      update();
    }
  }

  AcceptRejectMessageRequest(int conversationId, String accpetReject) async {
    try {
      var params = {
        "conversation_id": conversationId,
        "message_request_accepted": accpetReject,
      };
      _dio.Dio dio = _dio.Dio();
      chatAcceptLoading = true;

      _dio.Response response = await dio.post(
        Url.deleteConversation,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
              "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        queryParameters: params,
      );
      // print("deleteConversation body : " + response.toString());
      if (response.statusCode == 200) {
        chatAcceptLoading = false;
        if (kIsWeb == true) {
          isRequestScreen = false;
          chatUserList = await getChat();
          chatRequestUserList = await getMessageRequest();
          update();
        } else {
          isRequestScreen = false;
          // chatUserList = await getChat();
          chatUserList = await getChat();
          chatRequestUserList = await getMessageRequest();
          update();
        }
      }
    } catch (e) {
      // print(e.toString());
    }
  }

  deleteConversation(int conversationId) async {
    try {
      var params = {
        "conversation_id": conversationId,
      };
      _dio.Dio dio = _dio.Dio();

      _dio.Response response = await dio.post(
        Url.deleteConversation,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
              "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        queryParameters: params,
      );
      // print("deleteConversation body : " + response.toString());
      if (response.statusCode == 200) {
        infoChatInfo = false;
        update();
      }
    } catch (e) {
      // print(e.toString());
    }
  }

  getSnoozeNotification(String snoozeType) async {
    //int conversationId, int memberId, String snoozeType
    // print("getSnoozeNotification function Initiated");

    isChatSnoozeNotification = false;
    isChatSnoozeMention = false;

    var params = <String, Object>{};
    params["conversation_id"] = chatName.conversationId.toString();
    if (chatName.conversationType == "single")
      params["member_id"] = chatName.memberId.toString();
    params["snooze_type"] = snoozeType;

    var response = await api.post(Uri.parse(Url.getSnoozeNotificationUrl),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
        queryParameters: params);
    var parsedJson = json.decode(response);
    // print("getSnoozeNotificationUrl :: " + response);
    if (parsedJson['meta']['code'] == 200) {
      // Single : {"action":"/conversation/get_snooze_notification","meta":{"code":200,"message":"Snooze got successfully."},
      // "data":[{"id":1,"conversation_id":475,"snooze_by":461,"snooze_to":459,"snooze_type":"message","created_at":"2023-08-30T16:45:57.000Z","updated_at":"2023-08-30T16:45:57.000Z"}]}
      var postData = parsedJson['data'] as List;
      if (postData.length > 0) {
        if (parsedJson['data'][0]['snooze_type'] == "message") {
          isChatSnoozeNotification = true;
        } else if (parsedJson['data'][0]['snooze_type'] == "mention") {
          isChatSnoozeMention = true;
        }
      } else if (postData.length > 1) {
        if (parsedJson['data'][1]['snooze_type'] == "message") {
          isChatSnoozeNotification = true;
        } else if (parsedJson['data'][1]['snooze_type'] == "mention") {
          isChatSnoozeMention = true;
        }
      }
      update();
    }
  }

  setSnoozeNotification(String snoozeType, int snoozeValue) async {//int conversationId, int memberId, String snoozeType
    // print("Set SnoozeNotification function Initiated");

    var params = <String, Object>{};
    params["conversation_id"] = chatName.conversationId.toString();
    if (chatName.conversationType == "single")
      params["member_id"] = chatName.memberId.toString();
    params["snooze_type"] = snoozeType;
    params["snooze"] = snoozeValue.toString();

    var response = await api.post(Uri.parse(Url.snoozeNotificationUrl),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
        queryParameters: params);
    // {
    //   "conversation_id": chatName.conversationId.toString(),
    // "member_id": chatName.conversationType == "single" ? chatName.memberId.toString() : null,
    // "snooze": snoozeValue.toString(),
    // "snooze_type": snoozeType,
    // }
    var parsedJson = json.decode(response);
    // print("Set SnoozeNotificationUrl :: " + response);
    if (parsedJson['meta']['code'] == 200) {
      // {"action":"/conversation/snooze_notification","meta":{"code":200,"message":"Snooze added successfully."},
      // "data":{"fieldCount":0,"affectedRows":1,"insertId":1,"info":"","serverStatus":2,"warningStatus":0}}
      if (snoozeType == "message") {
        isChatSnoozeNotification = snoozeValue == 1 ? true : false;
      } else if (snoozeType == "mention") {
        isChatSnoozeMention = snoozeValue == 1 ? true : false;
      }

      update();
    }
  }

  Future<void> updateGroupName(BuildContext context,
      {String groupName, conversationId}) async {
    try {
      var params = {
        "conversation_id": conversationId,
        "new_group_chat_name": groupName,
      };
      _dio.Dio dio = _dio.Dio();

      _dio.Response response = await dio.post(
        Url.updateGroupNameUrl,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
              "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        data: jsonEncode(params),
      );
      if (response.statusCode == 200) {
        await getChat();
        if (!kIsWeb) {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
        } else {
          Navigator.of(context).pop();
        }

        // Get.showSnackbar(GetBar(
        //   animationDuration: Duration(milliseconds: 1000),
        //   backgroundColor: Color(0xFFedab30),
        //   dismissDirection: SnackDismissDirection.HORIZONTAL,
        //   message: 'Updated Succesfully',
        //   isDismissible: true,
        //   duration: Duration(seconds: 2),
        // ));
        update();
      }
      // print("create response");
      // print(response.data);
      // print("create response");
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> updateGroupImage(
      {Uint8List groupProfileImage, conversationId}) async {
    Map<String, String> headers = {
      "Token": storage.read('token'),
      "Authorization": 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'X-Requested-With': 'XMLHttpRequest',
    };
    var request =
        http.MultipartRequest('POST', Uri.parse(Url.updateGroupImageUrl));
    request.headers.addAll(headers);

    request.files.add(http.MultipartFile.fromBytes('file', groupProfileImage,
        filename: 'group name'));

    request.fields['conversation_id'] = conversationId.toString();
    var response = await request.send();
    response.stream.bytesToString().asStream().listen((event) async {
      var parsedJson = json.decode(event);
      await getChat();
      // print("image");
      // print(parsedJson.toString());
      // print("image");
      return parsedJson['meta']['code'];
    });
  }

  Future<Uint8List> callGetImage() async {
    Uint8List image;
    var img = await dataController.getImage();
    image = await img.readAsBytes();
    return image;
  }

  Future<void> getMessagesOfAConversation(int conversationId) async {
    // print("getMessagesOfAConversation method : $conversationId");
    String time = DateTime.now().timeZoneOffset.toString();

    if (!time.contains('-')) {
      time = time[0];
      time = '+' + time;
    } else {
      time = time[1];
    }
    // try {
    messageLoader = true;
    update();
    // messages = [];
    // update();
    try{
      var params = {
        "conversation_id": conversationId.toString(),
        "page_no": "1", //1.toString(),
        "GMT": time + ":00",
      };
      _dio.Dio dio = _dio.Dio();

      _dio.Response response = await dio.post(
        Url.messageUrl,
        options: _dio.Options(headers: {
          HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
          HttpHeaders.authorizationHeader:
          "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
          'Token': storage.read('token'),
        }),
        data: jsonEncode(params),
      );
      // print("messsss//////////////////////${response.data["data"]}");
      if (response.statusCode == 200) {
        // update();
        // print("message is success : Url.createMessageUrl time: $response");
        // var tok = storage.read('token');
        // print("Token : $tok");
        messages = [];
        response.data["data"].forEach((element) {
          // print("element " + element.toString());
          messages.add(MessageModel.fromJson(element));
        });
        // Future.delayed(Duration(seconds: 2), () {
        messageLoader = false;
        update();
        // });

        // messages = postData.map((e) => MessageModel.fromJson(e)).toList();
      } else {
        // } catch (e) {
        messages = [];
        messageLoader = false;
        update();
      }
    } catch (e){
      messages = [];
      messageLoader = false;
      update();
    }

  }

  List<MessageModel> messagesPage = [];

  Future<List<MessageModel>> createMessagePaged(int page) async {
    // try {
    // messageLoader = true;
    // update();
    messagesPage = [];
    // update();
    var params = {
      "conversation_id": chatName.conversationId.toString(),
      "page_no": page.toString()
    };
    _dio.Dio dio = _dio.Dio();

    _dio.Response response = await dio.post(
      Url.messageUrl,
      options: _dio.Options(headers: {
        HttpHeaders.contentTypeHeader: "application/json; charset=UTF-8",
        HttpHeaders.authorizationHeader:
            "Bearer e06b4395-4411-4c2c-9585-952900e5ba25",
        'Token': storage.read('token'),
      }),
      data: jsonEncode(params),
    );
    // print("messsss//////////////////////${response.data["data"]}");
    if (response.statusCode == 200) {
      messageLoader = false;
      update();
      response.data["data"].forEach((element) {
        messagesPage.add(MessageModel.fromJson(element));
      });
      return messagesPage;
      // messages = postData.map((e) => MessageModel.fromJson(e)).toList();
      // update();
    } else {
      return messagesPage;
      // } catch (e) {
      // messageLoader = false;
      // update();
    }
  }

  String localeCode = 'en';

  Future<void> upDateLocale(String language) async {
//    if (language == 'English') {
//      localeCode = 'en';
//      Get.updateLocale(Locale('en'));
//    } else if (language == 'عربي') {
//   if(language == "es"){
//     language = "sp";
//   }
//   if(language == "de"){
//     language = "du";
//   }
    localeCode = '$language';

    // print("localecode  $localeCode  ");

    Get.updateLocale(Locale('$language'));
//    } else if (language == 'Français') {
//      localeCode = '$language';
//      Get.updateLocale(Locale('fr'));
//    } else if (language == 'Deutsche') {
//      localeCode = '$language';
//      Get.updateLocale(Locale('du'));
//    } else if (language == 'Española') {
//      localeCode = 'sp';
//      Get.updateLocale(Locale('sp'));
//    } else if (language == 'हिंदी') {
//      localeCode = 'hi';
//      Get.updateLocale(Locale('hi'));
//    } else if (language == 'Bahasa_Indonesia') {
//      localeCode = 'indo';
//      Get.updateLocale(Locale('indo'));
//    } else if (language == 'Português') {
//      localeCode = 'po';
//      Get.updateLocale(Locale('po'));
//    } else if (language == 'Turca') {
//      localeCode = 'tu';
//      Get.updateLocale(Locale('tu'));
//    } else if (language == 'Shoomaali') {
//      localeCode = 'so';
//      Get.updateLocale(Locale('so'));
//    } else if (language == 'فارسی') {
//      localeCode = 'fa';
//      Get.updateLocale(Locale('fa'));
//    } else {
//      localeCode = 'en';
//      Get.updateLocale(Locale('en'));
//    }

    update();
  }

  String imageFileName;

  Future<void> uploadImage(conversationId) async {
    List<Uint8List> bytes = [];
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    // ignore: unused_local_variable
    List<int> byt = [];

    if (pickedFile != null) {
      isImagePickedChat = true;
      isImagePickedChat = true;
      ImageThumbnail = await pickedFile.readAsBytes();
      isSendMsg = false;

      bytes.add(await pickedFile.readAsBytes());
      imageBytesChat = await pickedFile.readAsBytes();
      update();
      // print("paaaaaaaaaaaaath${pickedFile.path}");
      // print("paaaaaaaaaaaaath");
      // ignore: unused_local_variable
      final tii = File(pickedFile.path);
      // print(tii.);
      // ignore: unused_local_variable
      String fileName = pickedFile.path.split('/').last;
      // ignore: unused_local_variable
      String ext = pickedFile.path.split('.').last;
      imageFileName = fileName + "." + ext;
    }
  }

  String videoFileName;
  VideoPlayerChat videoController;

  Future<void> uploadVideo(conversationId) async {
    List<Uint8List> bytes = [];
    final picker = ImagePicker();
    final pickedFile = await picker.getVideo(source: ImageSource.gallery);
    // ignore: unused_local_variable
    List<int> byt = [];

    if (pickedFile != null) {
      isVideoPickedChat = true;
      isSendMsg = false;
      update();

      bytes.add(await pickedFile.readAsBytes());
      videoBytesChat = await pickedFile.readAsBytes();
      update();
      // print("paaaaaaaaaaaaath${pickedFile.path}");
      // print("paaaaaaaaaaaaath");
      // ignore: unused_local_variable
      final tii = File(pickedFile.path);
      Get.find<NewsfeedController>().isVideoThumbnail = true;
      if (kIsWeb) {
        videoController = VideoPlayerChat(videoUrl: pickedFile.path);
      } else {
        Get.find<NewsfeedController>().videoThumbnail =
            await VideoThumbnail.thumbnailData(
          video: File(pickedFile.path).path,
          imageFormat: ImageFormat.JPEG,
          maxWidth: 128,
          // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
          quality: 25,
        );
      }

      Get.find<NewsfeedController>().update();
      // print(tii.);
      // ignore: unused_local_variable
      String fileName = pickedFile.path.split('/').last;
      // ignore: unused_local_variable
      String ext = pickedFile.path.split('.').last;
      videoFileName = fileName + "." + ext;

      // ignore: unused_local_variable
      _dio.Dio dio = _dio.Dio();
    }
  }

  String pdfFileName;

  Future<void> uploadDocument(conversationId) async {
    FilePickerResult result = await FilePicker.platform.pickFiles(
        withData: true,
        type: FileType.custom,
        allowedExtensions: ['pdf', 'xlsx', 'docx']);
    if (result != null) {
      documentBytesChat = result.files.first.bytes;
      isDocumentPickedChat = true;
      isSendMsg = false;
      // update();
      update();
      pdfFileName = result.files.first.name;
      // print(result.names);
      // /"HERE IS PDF FILE NAME  " + pdfFileName);
    }
  }

  addVoteToPoll(int postId, String vote) async {
    var response = await api.post(Uri.parse(Url.pollRespond), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    }, queryParameters: {
      'post_id': postId.toString(),
      'vote': vote,
    });
    // var res = jsonDecode(response);
    // postList.forEach((element) {
    //   if (element.postId == postId) {
    //     element.pollInfo = {
    //       if (element.pollQuestionOne.isNotEmpty &&
    //           element.pollQuestionOne != null)
    //         '${element.pollInfo[element.pollQuestionOne]}': res['data']
    //             ['${element.pollQuestionOne}'],
    //       if (element.pollQuestionTwo.isNotEmpty &&
    //           element.pollQuestionTwo != null)
    //         '${element.pollInfo[element.pollQuestionTwo]}': res['data']
    //             ['${element.pollQuestionTwo}'],
    //       if (element.pollQuestionThree.isNotEmpty &&
    //           element.pollQuestionThree != null)
    //         '${element.pollInfo[element.pollQuestionThree]}': res['data']
    //             ['${element.pollQuestionThree}'],
    //       if (element.pollQuestionFour.isNotEmpty &&
    //           element.pollQuestionFour != null)
    //         '${element.pollInfo[element.pollQuestionFour]}': res['data']
    //             ['${element.pollQuestionFour}'],
    //     };
    //   }
    // });

    // print(jsonDecode(response.toString()));
  }

  Future<List<ScheduledPost>> getScheduledPosts() async {
    noScheduledPost = false;
    update();
    // scheduledPosts.clear();
    // update();
    var response = await api.get(
      Uri.parse(Url.getScheduledPosts),
      token: {
        'X-Requested-With': 'XMLHttpRequest',
        'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
        'Token': storage.read('token'),
      },
    );

    if (jsonDecode(response)['meta']['code'] == 200) {
      var scheduledPost = jsonDecode(response);
      var scheduledPostData = scheduledPost['data'] as List;


      scheduledPosts = scheduledPostData.map((e) => ScheduledPost.fromJson(e)).toList();
      // print('schehdh' + scheduledPost.toString());
      noScheduledPost = false;
      update();
      return scheduledPosts;
    } else if (jsonDecode(response)['meta']['code'] == 400) {
      noScheduledPost = true;
      update();
      return [];
    }

    // print(response);
  }

  Future deleteScheduledPosts(List ids, context) async {



    for (int i = 0; i < ids.length; i++) {
      scheduledPosts.removeAt(
          scheduledPosts.indexWhere((element) => element.id == ids[i]));
    }
    update();


    // print("list ids   $ids}");


    var seprateIds = ids.join(',');

    // print('IDS TO SEND ' + seprateIds);
    // print('id string' + ids.toString());
    var response = await api.post(Uri.parse(Url.deleteScheduledPosts), token: {
      'X-Requested-With': 'XMLHttpRequest',
      'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
      'Token': storage.read('token'),
    }, queryParameters: {
      'ids': seprateIds
    });

    Navigator.of(context).pop();
    UtilsMethods.toastMessageShow(
      displayColor,
      displayColor,
      displayColor,
      message: 'Post Deleted',
    );
    // Get.showSnackbar(GetSnackBar(
    //   animationDuration: Duration(milliseconds: 1000),
    //   backgroundColor: Color(0xFFedab30),
    //   // dismissDirection: SnackDismissDirection.HORIZONTAL,
    //   message: 'Post Deleted',
    //   isDismissible: true,
    //   duration: Duration(seconds: 2),
    // ));

    // print('response deleted' + response.toString());
  }

  String getWhoLikedPost(List likeList, List retweetList) {
    if (likeList.length > 0) {
      if (likeList.length == 1) {
        return '🖤 ${likeList[0]['username']} liked';
      } else if (likeList.length == 2) {
        return '🖤 ${likeList[0]['username']} and ${likeList[1]['username']} liked';
      } else {
        return '🖤 ${likeList[0]['username']} and ${likeList.length - 1} others liked';
      }
    } else if (retweetList.length > 0) {
      if (retweetList.length == 1) {
        return '${retweetList[0]['username']} rewerf';
      } else if (retweetList.length == 2) {
        return '${retweetList[0]['username']} and ${retweetList[1]['username']} rewerf';
      } else {
        return '${retweetList[0]['username']} and ${retweetList.length - 1} others rewerf';
      }
    } else {
      return '';
    }
  }
}

class DeletionIDs {
  var ids;

  DeletionIDs(this.ids);
}
