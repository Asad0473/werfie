import 'dart:convert';

import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/utils/logging_utils.dart';

import '../../utils/urls.dart';

class UpdateDailyDigestAPI {
  Future<bool> update(String dailyWeeklyBiweeklyOff) async {
    final storage = GetStorage();

    var postBody = {
      "digest": dailyWeeklyBiweeklyOff == 'off' ? 0 : 1,
      "type":
          dailyWeeklyBiweeklyOff == 'off' ? "daily " : dailyWeeklyBiweeklyOff
    };

    LoggingUtils.printValue("POST BODY DIGEST SETTINGS", postBody);

    var response = await http.post(Uri.parse(Url.digestSettings),
        body: jsonEncode(postBody),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          // Specify content-type as JSON to prevent empty response body
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        });
    LoggingUtils.printValue(
        "UPDATE DAILY DIGEST API RESPONSE ", jsonDecode(response.body));

    try {
      if (response.statusCode == 200) {
        LoggingUtils.printValue(
            "UPDATE DAILY DIGEST API RESPONSE ", response.statusCode);
        return true;
      } else {
        return false;
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION UPDATE DAILY DIGEST API", e);
      return false;
    }
  }
}
