import 'dart:convert';

import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/notifications.dart';
import 'package:werfieapp/network/api.dart';
import 'package:werfieapp/utils/urls.dart';

class NotificationController extends GetxController {
  var api = Api();
  final storage = GetStorage();
  var isLoadingNotifications = true;
  var isLoadingMentionedNotifications = true;
  var isLoadingVerifiedNotifications = true;
  bool isSingleNewsfeedCalled = false;
  List<Notifications> notificationList = [];
  List<Notifications> mentionedNotificationList = [];
  List<Notifications> verifiedNotificationList = [];

  List<Notifications> notificationslist = [];

  @override
  void onInit() async {
    await getNotifications();
    await getMentionedNotifications();
    await getVerifiedNotifications();

    super.onInit();
  }

  Future<List<Notifications>> getNotifications() async {
    final String currentTimeZone =
        await FlutterNativeTimezone.getLocalTimezone();
    isLoadingNotifications = true;
    notificationList.clear();
    update();
    // if(!kIsWeb) DatabaseHelper.instance.dropTable(DatabaseHelper.notificationsTable);
    var responseBody = await api.get(
      Uri.parse(Url.getNotificationsUrl +
          '?page_no=1' +
          '&timezone=$currentTimeZone'),
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );
    // print("This is response of NOTIFICATION");
    // print(responseBody);

    var notifications = json.decode(responseBody);
    // print('NOTIFICATION ' + notifications.toString());
    if (notifications['meta']["code"] == 200) {
      if (notifications['data'] != null) {
        var data = notifications['data'] as List;
        data.forEach((element) {
          var data2 = Notifications.fromJson(element);
          notificationList.add(data2);
        });
        // var postData = notifications['data'] as List;
        // List<Notifications> notiList =
        // postData.map((e) => Notifications.fromJson(e)).toList();
        // notificationslist.addAll(notiList);
        // print(notificationList.length);
        // update();
        /*  notifications['data'].forEach((element) {
          var data = Notifications.fromJson(element);
          if (kIsWeb) notificationList.add(data); //for web
          if (!kIsWeb)
            DatabaseHelper.instance
                .insert(DatabaseHelper.notificationsTable, data.toJson());
        });*/
        // if (!kIsWeb) {
        //   //get all data from local db and add into list
        //   var notificationTableData = await DatabaseHelper.instance
        //       .queryAllRows(DatabaseHelper.notificationsTable);
        //   // print(
        //   //     '>>>. ${DatabaseHelper.instance.queryAllRows(DatabaseHelper.notificationsTable)}');
        //    notificationTableData.forEach((element) {
        //     var data = Notifications.fromJson(element);
        //     notificationList.add(data);
        //   });
        //   notificationList = new List.from(notificationList.reversed);
        //
        // }
        isLoadingNotifications = false;
        update();
        return notificationList;
      }
    }

    isLoadingNotifications = false;
    update();
    return notificationList;
  }
  Future<List<Notifications>> getMentionedNotifications() async {
    final String currentTimeZone =
    await FlutterNativeTimezone.getLocalTimezone();
    isLoadingMentionedNotifications = true;
    mentionedNotificationList.clear();
    update();
    // if(!kIsWeb) DatabaseHelper.instance.dropTable(DatabaseHelper.notificationsTable);
    var responseBody = await api.get(
      Uri.parse(Url.getMentionedNotificationsUrl +
          '?page_no=1' +
          '&timezone=$currentTimeZone'),
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );

    var notifications = json.decode(responseBody);
    // print('NOTIFICATION ' + notifications.toString());
    if (notifications['meta']["code"] == 200) {
      if (notifications['data'] != null) {
        var data = notifications['data'] as List;
        data.forEach((element) {
          var data2 = Notifications.fromJson(element);
          mentionedNotificationList.add(data2);
        });
        // var postData = notifications['data'] as List;
        // List<Notifications> notiList =
        // postData.map((e) => Notifications.fromJson(e)).toList();
        // notificationslist.addAll(notiList);
        // print(mentionedNotificationList.length);
        // update();
        /*  notifications['data'].forEach((element) {
          var data = Notifications.fromJson(element);
          if (kIsWeb) notificationList.add(data); //for web
          if (!kIsWeb)
            DatabaseHelper.instance
                .insert(DatabaseHelper.notificationsTable, data.toJson());
        });*/
        // if (!kIsWeb) {
        //   //get all data from local db and add into list
        //   var notificationTableData = await DatabaseHelper.instance
        //       .queryAllRows(DatabaseHelper.notificationsTable);
        //   // print(
        //   //     '>>>. ${DatabaseHelper.instance.queryAllRows(DatabaseHelper.notificationsTable)}');
        //    notificationTableData.forEach((element) {
        //     var data = Notifications.fromJson(element);
        //     notificationList.add(data);
        //   });
        //   notificationList = new List.from(notificationList.reversed);
        //
        // }
        isLoadingMentionedNotifications = false;
        update();
        return mentionedNotificationList;
      }
    }

    isLoadingMentionedNotifications = false;
    update();
    return mentionedNotificationList;
  }
  Future<List<Notifications>> getVerifiedNotifications() async {
    final String currentTimeZone =
    await FlutterNativeTimezone.getLocalTimezone();
    isLoadingVerifiedNotifications = true;
    verifiedNotificationList.clear();
    update();
    // if(!kIsWeb) DatabaseHelper.instance.dropTable(DatabaseHelper.notificationsTable);
    var responseBody = await api.get(
      Uri.parse(Url.getVerifiedNotificationsUrl +
          '?page_no=1' +
          '&timezone=$currentTimeZone'),
      token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "Token": storage.read('token'),
        "X-Requested-With": "XMLHttpRequest"
      },
    );

    var notifications = json.decode(responseBody);
    // print('NOTIFICATION ' + notifications.toString());
    if (notifications['meta']["code"] == 200) {
      if (notifications['data'] != null) {
        var data = notifications['data'] as List;
        data.forEach((element) {
          var data2 = Notifications.fromJson(element);
          verifiedNotificationList.add(data2);
        });
        // var postData = notifications['data'] as List;
        // List<Notifications> notiList =
        // postData.map((e) => Notifications.fromJson(e)).toList();
        // notificationslist.addAll(notiList);
        // print(verifiedNotificationList.length);
        // update();
        /*  notifications['data'].forEach((element) {
          var data = Notifications.fromJson(element);
          if (kIsWeb) notificationList.add(data); //for web
          if (!kIsWeb)
            DatabaseHelper.instance
                .insert(DatabaseHelper.notificationsTable, data.toJson());
        });*/
        // if (!kIsWeb) {
        //   //get all data from local db and add into list
        //   var notificationTableData = await DatabaseHelper.instance
        //       .queryAllRows(DatabaseHelper.notificationsTable);
        //   // print(
        //   //     '>>>. ${DatabaseHelper.instance.queryAllRows(DatabaseHelper.notificationsTable)}');
        //    notificationTableData.forEach((element) {
        //     var data = Notifications.fromJson(element);
        //     notificationList.add(data);
        //   });
        //   notificationList = new List.from(notificationList.reversed);
        //
        // }
        isLoadingVerifiedNotifications = false;
        update();
        return verifiedNotificationList;
      }
    }

    isLoadingVerifiedNotifications = false;
    update();
    return verifiedNotificationList;
  }


  // ignore: missing_return
  Future<List<Notifications>> getNotificationsPaged({int page}) async {
    final String currentTimeZone =
        await FlutterNativeTimezone.getLocalTimezone();

    try {
      if (page == 1 || page == null) {
        notificationslist = [];
      }
      var responseBody = await api.get(
        Uri.parse(Url.getNotificationsUrl +
            '?page_no=' +
            page.toString() +
            '&timezone=$currentTimeZone'),
        token: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "X-Requested-With": "XMLHttpRequest"
        },
      );

      var notifications = json.decode(responseBody);
      if (notifications['meta']["code"] == 200) {
        if (notifications['data'] != null) {
          var data = notifications['data'] as List;
          data.forEach((element) {
            var data2 = Notifications.fromJson(element);
            notificationList.add(data2);
          });
          // var postData = notifications['data'] as List;
          // List<Notifications> notiList =
          //     postData.map((e) => Notifications.fromJson(e)).toList();
          // notificationslist.addAll(notiList);

          isLoadingNotifications = false;
          update();

          return notificationList;
        } else {
          isLoadingNotifications = false;
          update();

          return notificationslist = [];
        }
      } else {
        isLoadingNotifications = false;
        update();
        return notificationslist = [];
      }
    } catch (_) {
      notificationslist = [];
    }
  }
  Future<List<Notifications>> getMentionedNotificationsPaged({int page}) async {
    final String currentTimeZone =
        await FlutterNativeTimezone.getLocalTimezone();

    try {
      if (page == 1 || page == null) {
        mentionedNotificationList = [];
      }
      var responseBody = await api.get(
        Uri.parse(Url.getMentionedNotificationsUrl +
            '?page_no=' +
            page.toString() +
            '&timezone=$currentTimeZone'),
        token: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "X-Requested-With": "XMLHttpRequest"
        },
      );

      var notifications = json.decode(responseBody);
      if (notifications['meta']["code"] == 200) {
        if (notifications['data'] != null) {
          var data = notifications['data'] as List;
          data.forEach((element) {
            var data2 = Notifications.fromJson(element);
            mentionedNotificationList.add(data2);
          });
          // var postData = notifications['data'] as List;
          // List<Notifications> notiList =
          //     postData.map((e) => Notifications.fromJson(e)).toList();
          // notificationslist.addAll(notiList);

          isLoadingMentionedNotifications = false;
          update();

          return mentionedNotificationList;
        } else {
          isLoadingMentionedNotifications = false;
          update();

          return mentionedNotificationList = [];
        }
      } else {
        isLoadingMentionedNotifications = false;
        update();
        return mentionedNotificationList = [];
      }
    } catch (_) {
      mentionedNotificationList = [];
    }
  }
  Future<List<Notifications>> getVerifiedNotificationsPaged({int page}) async {
    final String currentTimeZone =
        await FlutterNativeTimezone.getLocalTimezone();

    try {
      if (page == 1 || page == null) {
        verifiedNotificationList = [];
      }
      var responseBody = await api.get(
        Uri.parse(Url.getVerifiedNotificationsUrl +
            '?page_no=' +
            page.toString() +
            '&timezone=$currentTimeZone'),
        token: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "X-Requested-With": "XMLHttpRequest"
        },
      );

      var notifications = json.decode(responseBody);
      if (notifications['meta']["code"] == 200) {
        if (notifications['data'] != null) {
          var data = notifications['data'] as List;
          data.forEach((element) {
            var data2 = Notifications.fromJson(element);
            verifiedNotificationList.add(data2);
          });
          // var postData = notifications['data'] as List;
          // List<Notifications> notiList =
          //     postData.map((e) => Notifications.fromJson(e)).toList();
          // notificationslist.addAll(notiList);

          isLoadingVerifiedNotifications = false;
          update();

          return verifiedNotificationList;
        } else {
          isLoadingVerifiedNotifications = false;
          update();

          return verifiedNotificationList = [];
        }
      } else {
        isLoadingVerifiedNotifications = false;
        update();
        return verifiedNotificationList = [];
      }
    } catch (_) {
      verifiedNotificationList = [];
    }
  }
}
