import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';

import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';

class PushNotificationsSettingsAPIRes {
  bool success;
  PushNotificationsSettingsResponse pushNotificationsSettingsResponse;

  PushNotificationsSettingsAPIRes(this.success,
      {this.pushNotificationsSettingsResponse});
}

class PushNotificationsSettingsAPI {
  Future<PushNotificationsSettingsAPIRes> pushNotificationsSettings(
    String action, {
    int werfsNotifications = 0,
    String topWerfs = "off",
    String reWerfs = "off",
    String likes = "off",
    int photoTags = 0,
    int newFollowers = 0,
    int directMessages = 0,
    String messageReactions = "off",
    int topics = 0,
    int newsAndSports = 0,
    int recommendations = 0,
    int moments = 0,
  }) async {
    final storage = GetStorage();

    var postBody;
    if (action == "update") {
      {
        postBody = {
          "action": "update",
          "werfs_notification": werfsNotifications,
          "top_werfs": topWerfs,
          "re_werfs": reWerfs,
          "likes": likes,
          "photo_tags": photoTags,
          "new_followers": newFollowers,
          "direct_mesages": directMessages,
          "message_reactions": messageReactions,
          "topics": topics,
          "news_or_sports": newsAndSports,
          "recommendations": recommendations,
          "moments": moments,
        };
      }
    } else {
      postBody = {"action": "read"};
    }

    LoggingUtils.printValue("POST BODY PUSH NOTIFICATIONS SETTINGS", postBody);

    var response = await http.post(Uri.parse(Url.pushNotifications),
        body: jsonEncode(postBody),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        });

    try {
      if (response.statusCode == 200) {
        LoggingUtils.printValue("GET PUSH NOTIFICATIONS SETTINGS RESPONSE ",
            response.body);

        PushNotificationsSettingsResponse pushNotificationsSettingsResponse =
            PushNotificationsSettingsResponse.fromJson(
                jsonDecode(response.body));

        final controller = Get.find<NotificationSettingsController>();
        controller.pushNotificationsSettingsResponse =
            pushNotificationsSettingsResponse;

        return PushNotificationsSettingsAPIRes(true,
            pushNotificationsSettingsResponse:
                pushNotificationsSettingsResponse);
      } else {
        LoggingUtils.printValue("GET PUSH NOTIFICATIONS SETTINGS RESPONSE ",
            jsonEncode(response.body));
        return PushNotificationsSettingsAPIRes(false);
      }
    } catch (e) {
      LoggingUtils.printValue(
          "EXCEPTION GET PUSH NOTIFICATIONS SETTINGS API", e);
      return PushNotificationsSettingsAPIRes(false);
    }
  }
}
