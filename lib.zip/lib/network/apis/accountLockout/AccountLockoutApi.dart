import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/utils/strings.dart';

import '../../../models/login/PoshLoginResponse.dart' as pl;
import '../../../utils/urls.dart';

class AccountLockoutAPIRes {
  bool success;
  String message;

  AccountLockoutAPIRes(this.success, {this.message,});
}

class AccountLockoutApi {
  Future<AccountLockoutAPIRes> lockAccount(String email) async {

    var body = jsonEncode({
      "email": email,
    });

    //print("==============> Account lockout POST BODY");
    //print(body);
    var response = await http.post(Uri.parse(Url.accountLockoutUrl),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: body);

    try {
      //print("=========> Account lockout response");
      //print(response.body);

      if (response.statusCode == 200) {
          return AccountLockoutAPIRes(
            false,
            message: "You\'r account is locked due to multiple incorrect attempts try again in 30 minutes",
          );
      } else {
        return AccountLockoutAPIRes(false, message: Strings.someThingWentWrong);
      }

    } catch (e) {
      print(e);
      return AccountLockoutAPIRes(false, message: Strings.someThingWentWrong);
    }
  }

}
