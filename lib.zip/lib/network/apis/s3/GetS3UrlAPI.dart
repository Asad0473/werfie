import 'dart:convert';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/sendVerificationEmailResponse/GetS3UrlResponse.dart'
    as S3Model;
import 'package:werfieapp/utils/strings.dart';
import '../../../utils/urls.dart';

class GetS3UrlAPIRes {
  bool success;
  String message;
  S3Model.Data data;

  GetS3UrlAPIRes(this.success, {this.message, this.data});
}

class GetS3UrlAPI {
  Future<GetS3UrlAPIRes> getUrl({
      String fileName, String mimeType, String fileType}) async {
    /*print("<======== PRE ASSIGNED URL =======>");
    print(fileName);
    print(mimeType);
    print(fileType);*/

    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.awsSignedUrl),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({
          "file_name": fileName,
          "mime_type": mimeType,
          "file_type": fileType,
        }));

    try {
      if (response.statusCode == 200) {
        //print("<======== PRE ASSIGNED URL RESPONSE =======>");
        //print(response.body);

        S3Model.GetS3UrlResponse verify2FACodeResponse =
            S3Model.GetS3UrlResponse.fromJson(jsonDecode(response.body));

        if (verify2FACodeResponse.meta.code == 200) {
          return GetS3UrlAPIRes(true,
              message: verify2FACodeResponse.meta.message,
              data: verify2FACodeResponse.data);
        } else {
          return GetS3UrlAPIRes(false,
              message: verify2FACodeResponse.meta.message);
        }
      } else {
        print("<======== ERROR PRE ASSIGNED URL RESPONSE =======>");
        print(response.body);

        return GetS3UrlAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print("<======== EXCEPTION PRE ASSIGNED URL RESPONSE =======>");
      print(e);

      return GetS3UrlAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
