import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/sendVerificationEmailResponse/GetS3UrlResponse.dart'
    as S3Model;
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';
import '../../../utils/urls.dart';

class UploadMediaToS3APIRes {
  bool success;
  String message;

  UploadMediaToS3APIRes(
    this.success, {
    this.message,
  });
}

class UploadMediaToS3API {
  Future<UploadMediaToS3APIRes> upload(
      PlatformFile file, Uint8List bytes, String url, String memeType) async {
    try {
      Dio dio = Dio();

      dio.options.connectTimeout = const Duration(seconds: 180); // 5 seconds
      dio.options.receiveTimeout = const Duration(seconds: 180);

      Response response = await dio.put(
        url,
        data: file != null
            ? file.bytes ?? await File(file.path).readAsBytes()
            : bytes,
        options: Options(contentType: memeType ?? 'image/png'),
      );

      //print(response);

      if (response.statusCode == 200) {
        print('Media uploaded successfully');
        return UploadMediaToS3APIRes(true);
      } else {
        print('Failed to upload media. Status code: ${response.statusCode}');
        return UploadMediaToS3APIRes(false);
      }
    } catch (e) {
      print(e);
      LoggingUtils.printValue("EXCEPTION VERIFY 2FA RESPONSE API", e);
      return UploadMediaToS3APIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
