import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';

import '../../models/notifications/EmailNotificationsSettingsResponse.dart';
import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';

class EmailNotificationsSettingsAPIRes {
  bool success;
  EmailNotificationsSettingsResponse emailNotificationsSettingsResponse;

  EmailNotificationsSettingsAPIRes(this.success,
      {this.emailNotificationsSettingsResponse});
}

class EmailNotificationsSettingsAPI {
  Future<EmailNotificationsSettingsAPIRes> emailNotificationsSettings(
    String action, {
      int emailNotificationSwitch = 0,
    int newNotifications = 0,
    int directMessages = 0,
    int werfsEmailedToYou = 0,
    int newABoutWerfie = 0,
    int tipsOnWerfie = 0,
    int thingsYouMissed = 0,
    int participationInResearch = 0,
    int suggestionsOnAccounts = 0,
    int suggestionBasedRecentFollowers = 0,
  }) async {
    final storage = GetStorage();

    var postBody;
    if (action == "update") {
      {
        postBody = {
          "action": "update",
          "email_notification_switch": emailNotificationSwitch,
          "new_notifications": newNotifications,
          "direct_messages": directMessages,
          "werfs_emailed_to_you": werfsEmailedToYou,
          "new_about_werfie": newABoutWerfie,
          "tips_on_werfie": tipsOnWerfie,
          "things_you_missed": thingsYouMissed,
          "participation_in_research": participationInResearch,
          "suggestion_on_accounts": suggestionsOnAccounts,
          "suggestion_based_recent_followers": suggestionBasedRecentFollowers
        };
      }
    } else {
      postBody = {"action": "read"};
    }

    LoggingUtils.printValue("POST BODY EMAIL NOTIFICATIONS SETTINGS", postBody);

    var response = await http.post(Uri.parse(Url.emailNotifications),
        body: jsonEncode(postBody),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        });

    try {
      if (response.statusCode == 200) {
        LoggingUtils.printValue(
            "GET EMAIL NOTIFICATIONS SETTINGS RESPONSE ", response.body);

        EmailNotificationsSettingsResponse emailNotificationsSettingsResponse =
        EmailNotificationsSettingsResponse.fromJson(
                jsonDecode(response.body));

        final controller = Get.find<NotificationSettingsController>();
        controller.emailNotificationsSettingsResponse =
            emailNotificationsSettingsResponse;

        return EmailNotificationsSettingsAPIRes(true,
            emailNotificationsSettingsResponse:
                emailNotificationsSettingsResponse);
      } else {
        LoggingUtils.printValue("GET EMAIL NOTIFICATIONS SETTINGS RESPONSE ",
            jsonEncode(response.body));
        return EmailNotificationsSettingsAPIRes(false);
      }
    } catch (e) {
      LoggingUtils.printValue(
          "EXCEPTION GET EMAIL NOTIFICATIONS SETTINGS API", e);
      return EmailNotificationsSettingsAPIRes(false);
    }
  }
}
