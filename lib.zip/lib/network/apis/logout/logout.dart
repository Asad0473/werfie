import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:werfieapp/utils/strings.dart';

import '../../../models/sendVerificationEmailResponse/SendVerificationEmailResponse.dart';
import '../../../utils/urls.dart';

class LogoutAPIRes {
  bool success;
  String message;

  LogoutAPIRes(
    this.success, {
    this.message,
  });
}

class LogoutAPI {
  Future<LogoutAPIRes> logout(String token, String fcmToken) async {
    var response = await http.post(Uri.parse(Url.logout),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": token,
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({
          "token": token,
          "fcm_token": fcmToken,
        }));

    try {
      //print("<======= LOGOUT RESPONSE =========>");
      //print(response.body);
      if (response.statusCode == 200) {
        SendVerificationEmailResponse logoutResponse =
            SendVerificationEmailResponse.fromJson(jsonDecode(response.body));
        if (logoutResponse.meta.code == 200) {
          return LogoutAPIRes(
            true,
            message: logoutResponse.meta.message,
          );
        } else {
          return LogoutAPIRes(
            false,
            message: logoutResponse.meta.message,
          );
        }
      } else {
        return LogoutAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      //print("<======= EXCEPTION LOGOUT=======>");
      print(e);
      return LogoutAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
