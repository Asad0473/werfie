import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../models/2fa/Send2FAResponse.dart';
import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';

class Verify2FACodeAPIRes {
  bool success;
  String message;

  Verify2FACodeAPIRes(this.success, {this.message});
}

class Verify2FACodeAPI {
  Future<Verify2FACodeAPIRes> verify2FaCode(String code,
      {bool enable = true}) async {
    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.verify2FACode), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    }, body: jsonEncode({
      "code": code
    }));

    try {
      if (response.statusCode == 200) {
        LoggingUtils.printValue("VERIFY 2FA RESPONSE ", response.body);

        Send2FAResponse verify2FACodeResponse =
            Send2FAResponse.fromJson(jsonDecode(response.body));

        if (verify2FACodeResponse.meta.code == 200) {
          return Verify2FACodeAPIRes(true,
              message: verify2FACodeResponse.meta.message);
        } else {
          return Verify2FACodeAPIRes(false, message: verify2FACodeResponse.meta.message);
        }
      } else {
        LoggingUtils.printValue(
            "VERIFY 2FA RESPONSE RESPONSE ", jsonEncode(response.body));
        return Verify2FACodeAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION VERIFY 2FA RESPONSE API", e);
      return Verify2FACodeAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
