import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:werfieapp/utils/strings.dart';

import '../../../models/sendVerificationEmailResponse/SendVerificationEmailResponse.dart';
import '../../../utils/urls.dart';

class SendVerificationEmailAPIRes {
  bool success;
  String message;

  SendVerificationEmailAPIRes(
    this.success, {
    this.message,
  });
}

class SendVerificationEmailAPI {
  Future<SendVerificationEmailAPIRes> sendVerificationEmail(String email,
      {bool isResetPasswordFromPhone = false}) async {
    var body = jsonEncode(isResetPasswordFromPhone
        ? {"email": email, "reset_password": "1"}
        : {"email": email, "reset_password": "0", "type": "register"});

    var response = await http.post(Uri.parse(Url.forgotPassword),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: body);

    try {
      //print(body);
      //print(response.body);
      if (response.statusCode == 200) {
        SendVerificationEmailResponse werfieHandleSuggestionsResponse =
            SendVerificationEmailResponse.fromJson(jsonDecode(response.body));

        if (werfieHandleSuggestionsResponse.meta.code == 200) {
          return SendVerificationEmailAPIRes(
            true,
            message: werfieHandleSuggestionsResponse.meta.message,
          );
        } else {
          return SendVerificationEmailAPIRes(
            false,
            message: werfieHandleSuggestionsResponse.meta.message,
          );
        }
      } else {
        return SendVerificationEmailAPIRes(false,
            message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print(e);
      return SendVerificationEmailAPIRes(false,
          message: Strings.someThingWentWrong);
    }
  }
}
