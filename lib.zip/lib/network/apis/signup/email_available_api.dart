import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/verifyEmailResponse/VerifyEmailResponse.dart';
import 'package:werfieapp/utils/strings.dart';
import '../../../utils/urls.dart';

class IsEmailAvailableAPIRes {
  bool success;
  String message;

  IsEmailAvailableAPIRes(this.success, {this.message});
}

class EmailAvailableAPI {
  Future<IsEmailAvailableAPIRes> isEmailAvailable(String email) async {
    var response = await http.post(Uri.parse(Url.checkEmail),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({"email": email}));
    //print(response.body);

    try {
      if (response.statusCode == 200) {
        EmailAvailableResponse werfieHandleSuggestionsResponse =
            EmailAvailableResponse.fromJson(jsonDecode(response.body));

        if (werfieHandleSuggestionsResponse.meta.code == 200) {
          return IsEmailAvailableAPIRes(true,
              message: werfieHandleSuggestionsResponse.meta.message);
        } else {
          return IsEmailAvailableAPIRes(
            false,
            message: werfieHandleSuggestionsResponse.meta.message,
          );
        }
      } else {
        return IsEmailAvailableAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print(e);
      return IsEmailAvailableAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
