import 'dart:convert';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/werfieHandleSuggestions/WerfieHandleSuggestionsResponse.dart'
    as WHR;
import 'package:werfieapp/utils/strings.dart';

import '../../../utils/urls.dart';

class WerfieHandleSuggestionsAPIRes {
  bool success;
  String message;
  WHR.Data data;

  WerfieHandleSuggestionsAPIRes(this.success, {this.message, this.data});
}

class WerfieHandleSuggestionsAPI {
  Future<WerfieHandleSuggestionsAPIRes> verifyHandleAndGetSuggestions(
      String userName) async {
    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.getWerfieHandleSuggestions),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          //"Token": storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({"username": userName}));

    try {
      print(response.body);
      if (response.statusCode == 200) {
        WHR.WerfieHandleSuggestionsResponse werfieHandleSuggestionsResponse =
            WHR.WerfieHandleSuggestionsResponse.fromJson(
                jsonDecode(response.body));

        if (werfieHandleSuggestionsResponse.meta.code == 200) {
          return WerfieHandleSuggestionsAPIRes(true,
              message: werfieHandleSuggestionsResponse.meta.message,
              data: werfieHandleSuggestionsResponse.data);
        } else if (werfieHandleSuggestionsResponse.meta.code == 202) {
          return WerfieHandleSuggestionsAPIRes(false,
              message: werfieHandleSuggestionsResponse.meta.message,
              data: werfieHandleSuggestionsResponse.data);
        }else{
          return WerfieHandleSuggestionsAPIRes(false,
              message: werfieHandleSuggestionsResponse.meta.message,
          );
        }
      } else {
        return WerfieHandleSuggestionsAPIRes(false,
            message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print(e);
      return WerfieHandleSuggestionsAPIRes(false,
          message: Strings.someThingWentWrong);
    }
  }
}
