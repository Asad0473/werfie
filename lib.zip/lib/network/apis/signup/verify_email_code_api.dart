import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:werfieapp/utils/strings.dart';

import '../../../models/sendVerificationEmailResponse/SendVerificationEmailResponse.dart';
import '../../../models/verifyEmailCode/VerifyEmailCodeResponse.dart';
import '../../../utils/urls.dart';

class VerifyEmailCodeAPIRes {
  bool success;
  String message;

  VerifyEmailCodeAPIRes(this.success, {this.message,});
}

class VerifyEmailCodeAPI {
  Future<VerifyEmailCodeAPIRes> verifyCode(
      String verificationCode,String email) async {

    var response = await http.post(Uri.parse(Url.loginVerify),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({"verification_code": verificationCode,"email":email}));

    try {
      //print({"verification_code": verificationCode,"email":email});
      //print(response.body);
      if (response.statusCode == 200) {
        VerifyEmailCodeResponse verifyEmailCodeResponse =
        VerifyEmailCodeResponse.fromJson(
                jsonDecode(response.body));

        if (verifyEmailCodeResponse.meta.code == 200) {
          return VerifyEmailCodeAPIRes(true,
              message: verifyEmailCodeResponse.meta.message,);
        } else{
          return VerifyEmailCodeAPIRes(false,
              message: verifyEmailCodeResponse.meta.message,
          );
        }
      } else {
        return VerifyEmailCodeAPIRes(false,
            message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print(e);
      return VerifyEmailCodeAPIRes(false,
          message: Strings.someThingWentWrong);
    }
  }
}
