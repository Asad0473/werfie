import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../models/signUp/SignUpResponse.dart' as SR;
import '../../../utils/fluro_router.dart';
import '../../../utils/urls.dart';

class SignUpAPIRes {
  bool success;
  String message;
  SR.Data data;

  SignUpAPIRes(this.success, {this.message, this.data});
}

class SignUpAPI {
  Future<SignUpAPIRes> signUp(BuildContext context) async {
    final controller = Get.find<SignupController>();

    var body = jsonEncode(controller.isSignupUsingEmail
        ? {
            "firstname": controller.name,
            "username": controller.handle,
            "email": controller.email,
            "password": controller.password,
            "password_confirmation": controller.password,
            "country_code": controller.isoCountryCode,
            "dob": controller.dob,
            "email_verified": true,
            "phone_no_fcm_token": controller.fcmToken
          }
        : {
            "firstname": controller.name,
            "username": controller.handle,
            "phone_no": controller.phone,
            "password": controller.password,
            "password_confirmation": controller.password,
            "country_code": controller.isoCountryCode,
            "dob": controller.dob,
            "phone_no_fcm_token": controller.fcmToken
          });

    print("SIGNUP POST BODY");
    print(body);
    var response = await http.post(Uri.parse(Url.registerationUrl),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: body);

    try {
      print(response.body);
      var checkEmailError = jsonDecode(response.body);

      if (checkEmailError['errors'] != null &&
          checkEmailError['errors']['email'][0] ==
              "The email has already been taken.") {
        return SignUpAPIRes(
          false,
          message: "The email has already been taken.",
        );
      } else {
        if (response.statusCode == 200) {
          SR.SignUpResponse signUpResponse =
              SR.SignUpResponse.fromJson(jsonDecode(response.body));

          if (signUpResponse.meta.code == 200) {
            await saveDataLocally(signUpResponse.data, controller);
            await initControllers(controller, context, controller.handle);

            return SignUpAPIRes(true,
                message: signUpResponse.meta.message,
                data: signUpResponse.data);
          } else {
            return SignUpAPIRes(
              false,
              message: signUpResponse.meta.message,
            );
          }
        } else {
          return SignUpAPIRes(false, message: Strings.someThingWentWrong);
        }
      }
    } catch (e) {
      print(e);
      return SignUpAPIRes(false, message: Strings.someThingWentWrong);
    }
  }

  saveDataLocally(
    SR.Data data,
    SignupController controller,
  ) async {
    final getStorage = GetStorage();
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    sharedPreferences.setString("token", data.token);
    sharedPreferences.setString("userName", data.username);

    if (data.email != null && data.email.isNotEmpty) {
      sharedPreferences.setString("email", data.email);
      getStorage.write("email", data.email);
      getStorage.write("CurrentEmail", controller.email);
    } else {
      sharedPreferences.setString("email", data.phoneNo);
      getStorage.write("email", data.phoneNo);
      getStorage.write("CurrentEmail", data.phoneNo);
    }

    sharedPreferences.setBool('guestUser', true);
    sharedPreferences.setBool('socialLogin', false);

    getStorage.write('id', data.id);
    getStorage.write("token", data.token);


    getStorage.write("userName", data.username);

    getStorage.write("remember", true);
  }

  initControllers(SignupController controller, BuildContext context,
      String userName) async {
    LoginController loginController = Get.find<LoginController>();
    loginController.generateFCMToken(context);
    loginController.updateInitialWelcomeMsg(true);

    Get.put(NewsfeedController());

    Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>().getLanguages();
    int index =
        Get.find<NewsfeedController>().languagesList.indexWhere((element) {
      return Get.find<NewsfeedController>().languageData.appLang.id ==
          element.id;
    });

    int index2 = Get.find<NewsfeedController>()
        .translationLanguage
        .indexWhere((element) {
      return Get.find<NewsfeedController>().languageData.myLang.id ==
          element.id;
    });

    Get.find<NewsfeedController>().dropdownValue =
        Get.find<NewsfeedController>().languagesList[index];

    Get.find<NewsfeedController>().dropdownValue1 =
        Get.find<NewsfeedController>().translationLanguage[index2];

    Get.find<NewsfeedController>().selectedAppLanguageInfoId =
        Get.find<NewsfeedController>().languageData.appLang.id;

    Get.find<NewsfeedController>()
        .upDateLocale(Get.find<NewsfeedController>().languageData.appLang.code);
    Get.find<NewsfeedController>().update();

    if (kIsWeb) {
      SingleTone.instance.socialLogin = false;
      loginController.showRegistrationSuccessful = true;
      loginController.showSignUpForm = false;
      loginController.update();
      Navigator.pop(context);
      Get.offNamed(FluroRouters.mainScreen);
    } else {
      SingleTone.instance.socialLogin = false;
      Get.offAll(MainScreen(), arguments: {
        "userName": userName,
      });
    }
  }
}
