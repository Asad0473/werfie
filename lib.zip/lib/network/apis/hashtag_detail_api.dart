import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../models/2fa/Send2FAResponse.dart';
import '../../models/hashtag/hashtag_details_response_model.dart';
import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';

class HashtagDetailAPIRes {
  bool success;
  String message;
  dynamic data;

  HashtagDetailAPIRes(this.success, {this.message,this.data});
}

class HashtagDetailAPI {
  Future<HashtagDetailAPIRes> hashtagDetail(String hashTag,
      {bool enable = true}) async {
    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.hashtagDetail), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    }, body: jsonEncode({
      "hash_tag": hashTag
    }));

    try {
      if (response.statusCode == 200) {

        HashtagDetailsResponseModel hashtagDetailsResponseModel =
        HashtagDetailsResponseModel.fromJson(jsonDecode(response.body));

        if (hashtagDetailsResponseModel.meta.code == 200) {
          return HashtagDetailAPIRes(true,
              message: hashtagDetailsResponseModel.meta.message,data: hashtagDetailsResponseModel.data);
        } else {
          return HashtagDetailAPIRes(false, message: hashtagDetailsResponseModel.meta.message);
        }
      } else {
        return HashtagDetailAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      return HashtagDetailAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
