import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../models/2fa/Send2FAResponse.dart';
import '../../../models/spaces/create_space_response_model.dart';
import '../../../utils/loading_dialog_builder.dart';
import '../../../utils/urls.dart';



class CreateSpaceAPIRes {
  bool success;
  String message;
  CreateSpaceResponseModel data;

  CreateSpaceAPIRes(this.success, {this.message,this.data});
}

class CreateSpaceAPI {
  Future<CreateSpaceAPIRes> createSpace({String name,String type,String startTime,String topicIds,
      }) async {
    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.createSpace), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    }, body: jsonEncode({
      "name": name,
      "type": type,
      "start_time": startTime,
      "topic_ids": topicIds,
    }));
    LoggingUtils.printValue("Create space RESPONSE ", jsonDecode(response.body));

    try {
      if (response.statusCode == 200) {

        CreateSpaceResponseModel verify2FACodeResponse =
        CreateSpaceResponseModel.fromJson(jsonDecode(response.body));

        if (verify2FACodeResponse.meta.code == 200) {
          return CreateSpaceAPIRes(true,
              message: verify2FACodeResponse.meta.message,data: verify2FACodeResponse);
        } else {
          return CreateSpaceAPIRes(false, message: verify2FACodeResponse.meta.message);
        }
      } else {
        LoggingUtils.printValue(
            "Create space RESPONSE RESPONSE ", jsonEncode(response.body));
        return CreateSpaceAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION Create space RESPONSE API", e);
      return CreateSpaceAPIRes(false, message: Strings.someThingWentWrong);
    }
  }



}
