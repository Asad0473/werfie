import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../models/spaces/get_spaces_response_model.dart' as spacesResponse;
import '../../../utils/loading_dialog_builder.dart';
import '../../../utils/urls.dart';



class GetSpacesAPIRes {
  bool success;
  String message;
  List<spacesResponse.Data> data;
  GetSpacesAPIRes(this.success, {this.message,this.data});
}

class GetSpacesAPI {
  Future<GetSpacesAPIRes> getSpaces(int currentUserId) async {
    final storage = GetStorage();

    var response = await http.get(Uri.parse(Url.getSpaces), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    });
    LoggingUtils.printValue("Create space RESPONSE ", jsonDecode(response.body));

    try {
      if (response.statusCode == 200) {

        spacesResponse.GetSpacesResponseModel getSpacesResponse =
        spacesResponse.GetSpacesResponseModel.fromJson(jsonDecode(response.body));

        if (getSpacesResponse.meta.code == 200) {
          LoggingUtils.printValue(
              "Create space RESPONSE RESPONSE ", jsonEncode(response.body));
          // await getSpacesResponse.data.sort((a, b) => a.endTime == null ? 0 :1);





          await getSpacesResponse.data.sort((a, b) {
            if (a.userId.toString() == currentUserId.toString()) {
              return -1; // Place the desired item at the beginning
            } else if (b.userId.toString() == currentUserId.toString()) {
              return 1; // Place the desired item at the beginning
            } else {
              return a.userId.compareTo(b.userId); // Sort other items by name
            }
          });
          return GetSpacesAPIRes(true,
              message: getSpacesResponse.meta.message,data: getSpacesResponse.data);
        } else {
          LoggingUtils.printValue(
              "Create space RESPONSE RESPONSE ", jsonEncode(response.body));
          return GetSpacesAPIRes(false, message: getSpacesResponse.meta.message);
        }
      } else {
        LoggingUtils.printValue(
            "Create space RESPONSE RESPONSE ", jsonEncode(response.body));
        return GetSpacesAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION Create space RESPONSE API", e);
      return GetSpacesAPIRes(false, message: Strings.someThingWentWrong);
    }
  }


}
