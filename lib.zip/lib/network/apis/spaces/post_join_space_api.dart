import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../models/2fa/Send2FAResponse.dart';
import '../../../models/spaces/SpaceJoinResponseModel.dart';
import '../../../models/spaces/create_space_response_model.dart';
import '../../../utils/loading_dialog_builder.dart';
import '../../../utils/urls.dart';



class PostJoinSpaceAPIRes {
  bool success;
  String message;
  SpaceJoinResponseModel data;

  PostJoinSpaceAPIRes(this.success, {this.message,this.data});
}

class PostJoinSpaceAPI {
  Future<PostJoinSpaceAPIRes> postJoinSpace({String spaceId}) async {
    final storage = GetStorage();

    var response = await http.post(Uri.parse(Url.joinSpace), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    }, body: jsonEncode({
      "space_id": spaceId,
    }));
    LoggingUtils.printValue("Create space RESPONSE ", jsonDecode(response.body));

    try {
      if (response.statusCode == 200) {

        SpaceJoinResponseModel spaceJoinResponseModel =
        SpaceJoinResponseModel.fromJson(jsonDecode(response.body));

        if (spaceJoinResponseModel.meta.code == 200) {
          print('post join api called');
          return PostJoinSpaceAPIRes(true,
              message: spaceJoinResponseModel.meta.message,data: spaceJoinResponseModel);
        } else {
          return PostJoinSpaceAPIRes(false, message: spaceJoinResponseModel.meta.message);
        }
      } else {
        LoggingUtils.printValue(
            "Create space RESPONSE RESPONSE ", jsonEncode(response.body));
        return PostJoinSpaceAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION Create space RESPONSE API", e);
      return PostJoinSpaceAPIRes(false, message: Strings.someThingWentWrong);
    }
  }


  spaceJoinApiCall(
      BuildContext context,{String spaceId}) async {
    try {
      DialogBuilder(context).showLoadingIndicator();

      PostJoinSpaceAPIRes response = await PostJoinSpaceAPI()
          .postJoinSpace(spaceId: spaceId);

      if (response.success) {
        DialogBuilder(context).hideOpenDialog();
        Fluttertoast.showToast(
            msg: Strings.createSpaceSuccessfully,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);


      } else {
        DialogBuilder(context).hideOpenDialog();


        Fluttertoast.showToast(
            msg: response.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        return;
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
      Fluttertoast.showToast(
          msg: e.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return;

      // TODO
    }
  }
}
