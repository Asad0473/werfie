import 'dart:convert';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/models/verifyEmailResponse/VerifyEmailResponse.dart';
import 'package:werfieapp/utils/strings.dart';
import '../../../models/reportUserAndWerf/ReportUserAndWerfApiResponse.dart';
import '../../../utils/urls.dart';

enum ReportType { werf, user, message }

class ReportUserAndWerfAPIRes {
  bool success;
  String message;

  ReportUserAndWerfAPIRes(this.success, {this.message});
}

class ReportUserAndWerfApi {
  final storage = GetStorage();

  Future<ReportUserAndWerfAPIRes> report(
      String category, String subCategory, int id, ReportType type,int messageId) async {
    var response = await http.post(Uri.parse(Url.reportUserAndWerf),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          'Token': storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: jsonEncode({
          "category": category,
          "sub_category": subCategory,
          "description": "N/A",
          "type": type == ReportType.werf
              ? "post"
              : type == ReportType.user
                  ? "user"
                  : 'chat',
          "reported_id": type == ReportType.werf || type == ReportType.user ? id : messageId
        }));
      print("<======= REPORT USER AND WERF API RESPONSE ==========>");
      print(response.body);
    try {
      if (response.statusCode == 200) {
        ReportUserAndWerfApiResponse reportUserAndWerfApiResponse =
            ReportUserAndWerfApiResponse.fromJson(jsonDecode(response.body));

        if (reportUserAndWerfApiResponse.meta.code == 200) {
          return ReportUserAndWerfAPIRes(true,
              message: reportUserAndWerfApiResponse.meta.message);
        } else {
          return ReportUserAndWerfAPIRes(
            false,
            message: reportUserAndWerfApiResponse.meta.message,
          );
        }
      } else {
        return ReportUserAndWerfAPIRes(false,
            message: Strings.someThingWentWrong);
      }
    } catch (e) {
      print(e);
      return ReportUserAndWerfAPIRes(false,
          message: Strings.someThingWentWrong);
    }
  }
}
