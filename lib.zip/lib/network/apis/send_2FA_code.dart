import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../models/2fa/Send2FAResponse.dart';
import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../models/notifications/PushNotificationsSettingsResponse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';

class Send2FACodeAPIRes {
  bool success;
  String message;

  Send2FACodeAPIRes(this.success, {this.message});
}

class Send2FACodeAPI {
  Future<Send2FACodeAPIRes> send2FaCode() async {
    final storage = GetStorage();

    var response = await http.get(Uri.parse(Url.send2FA), headers: {
      "Authorization": "Bearer ${Url.webAPIKey}",
      "Token": storage.read('token'),
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "X-Requested-With": "XMLHttpRequest"
    });

    try {
      if (response.statusCode == 200) {
        LoggingUtils.printValue("GET SEND 2FA RESPONSE ", response.body);

        Send2FAResponse send2FAResponse =
            Send2FAResponse.fromJson(jsonDecode(response.body));

        if (send2FAResponse.meta.code == 200) {
          return Send2FACodeAPIRes(true, message: send2FAResponse.meta.message);
        } else {
          return Send2FACodeAPIRes(false, message: send2FAResponse.meta.message);
        }
      } else {
        LoggingUtils.printValue(
            "GET SEND 2FA RESPONSE RESPONSE ", jsonEncode(response.body));
        return Send2FACodeAPIRes(false, message: Strings.someThingWentWrong);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION GET SEND 2FA RESPONSE API", e);
      return Send2FACodeAPIRes(false, message: Strings.someThingWentWrong);
    }
  }
}
