import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../models/login/PoshLoginResponse.dart' as pl;
import '../../../utils/fluro_router.dart';
import '../../../utils/urls.dart';

class PoshLoginAPIRes {
  bool success;
  String message;
  pl.Data data;

  PoshLoginAPIRes(this.success, {this.message, this.data});
}

class PoshLoginApi {
  Future<PoshLoginAPIRes> login(BuildContext context,String email,String password) async {

    var body = jsonEncode({
            "email": email,
            "password": password,
          });

    //print("SIGNUP POST BODY");
    //print(body);
    var response = await http.post(Uri.parse(Url.poshLogin),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: body);

    try {
      //print(response.body);

        if (response.statusCode == 200) {
          pl.PoshLoginResponse poshLoginResponse = pl.PoshLoginResponse.fromJson(jsonDecode(response.body));

          if (poshLoginResponse.meta.code == 200) {
            await saveDataLocally(poshLoginResponse.data, email);
            await initControllers( context,poshLoginResponse.data.username);

            return PoshLoginAPIRes(true,
                message: poshLoginResponse.meta.message,
                data: poshLoginResponse.data);
          } else {
            return PoshLoginAPIRes(
              false,
              message: poshLoginResponse.meta.message,
            );
          }
        } else {
          return PoshLoginAPIRes(false, message: Strings.someThingWentWrong);
        }

    } catch (e) {
      print(e);
      return PoshLoginAPIRes(false, message: Strings.someThingWentWrong);
    }
  }

  saveDataLocally(
      pl.Data data,
    String currentEmail,
  ) async {
    final getStorage = GetStorage();
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    sharedPreferences.setString("token", data.token);
    sharedPreferences.setString("userName", data.username);

    if (data.email != null && data.email.isNotEmpty) {
      sharedPreferences.setString("email", data.email);
      getStorage.write("email", data.email);
      getStorage.write("CurrentEmail", currentEmail);
    } else {
      sharedPreferences.setString("email", data.phone);
      getStorage.write("email", data.phone);
      getStorage.write("CurrentEmail", data.phone);
    }

    sharedPreferences.setBool('guestUser', true);
    sharedPreferences.setBool('socialLogin', false);

    getStorage.write('id', data.id);
    getStorage.write("token", data.token);


    getStorage.write("userName", data.username);

    getStorage.write("remember", true);
  }

  initControllers(BuildContext context,String name) async {
    LoginController loginController = Get.find<LoginController>();
    loginController.generateFCMToken(context);
    loginController.updateInitialWelcomeMsg(true);

    Get.put(NewsfeedController());

    Get.find<NewsfeedController>().languageData =
        await Get.find<NewsfeedController>().getLanguages();
    int index =
        Get.find<NewsfeedController>().languagesList.indexWhere((element) {
      return Get.find<NewsfeedController>().languageData.appLang.id ==
          element.id;
    });

    int index2 = Get.find<NewsfeedController>()
        .translationLanguage
        .indexWhere((element) {
      return Get.find<NewsfeedController>().languageData.myLang.id ==
          element.id;
    });

    Get.find<NewsfeedController>().dropdownValue =
        Get.find<NewsfeedController>().languagesList[index];

    Get.find<NewsfeedController>().dropdownValue1 =
        Get.find<NewsfeedController>().translationLanguage[index2];

    Get.find<NewsfeedController>().selectedAppLanguageInfoId =
        Get.find<NewsfeedController>().languageData.appLang.id;

    Get.find<NewsfeedController>()
        .upDateLocale(Get.find<NewsfeedController>().languageData.appLang.code);
    Get.find<NewsfeedController>().update();

    if (kIsWeb) {
      SingleTone.instance.socialLogin = false;
      loginController.showRegistrationSuccessful = true;
      loginController.showSignUpForm = false;
      loginController.update();
      Navigator.pop(context);
      Get.offNamed(FluroRouters.mainScreen);
    } else {
      SingleTone.instance.socialLogin = false;
      Get.offAll(MainScreen(), arguments: {
        "userName": name,
        "postId": loginController.postId,
        "profileId": loginController.profileId
      });
    }
  }
}
