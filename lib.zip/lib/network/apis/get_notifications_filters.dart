import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:http/http.dart' as http;
import 'package:werfieapp/network/controller/notification_controller.dart';
import 'package:werfieapp/utils/logging_utils.dart';

import '../../models/notifications/NotificationsFilterRespnse.dart';
import '../../utils/urls.dart';
import '../controller/NotificationsSettingsController.dart';


class NotificationFiltersAPIRes{

  bool success;
  NotificationsFilterResponse notificationsFilterResponse;

  NotificationFiltersAPIRes(this.success,{this.notificationsFilterResponse});

}

class NotificationsFiltersAPI {



  Future<NotificationFiltersAPIRes> Filters(String action,
      {int qualityFilter = 0,
      int youDontFollow = 0,
      int whoDontFollowYou = 0,
      int withNewAccount = 0,
      int defaultPhotoUsers = 0,
      int emailNotConfirmedUsers = 0,
      int phoneNotConfirmedUsers = 0,bool isQualityFilter = false}) async {
    final storage = GetStorage();

    var postBody;
    if (action == "update") {

      if(isQualityFilter){
        postBody = {
          "action": "update",
          "quality_filter": qualityFilter,
        };
      }else {
        postBody = {
          "action": "update",
          "you_dont_follow": youDontFollow,
          "who_dont_follow_you": whoDontFollowYou,
          "with_new_account": withNewAccount,
          "default_photo_users": defaultPhotoUsers,
          "email_not_confirmed_users": emailNotConfirmedUsers,
          "phone_not_confirmed_users": phoneNotConfirmedUsers
        };
      }
    }else{
      postBody = {
        "action":"read"
      };
    }

    LoggingUtils.printValue("POST BODY DIGEST SETTINGS", postBody);

    var response = await http.post(Uri.parse(Url.mutedNotifications),
        body: jsonEncode(postBody),
        headers: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "Token": storage.read('token'),
          "content-type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "X-Requested-With": "XMLHttpRequest"
        });

    try {
      if (response.statusCode == 200) {

        LoggingUtils.printValue(
            "GET NOTIFICATIONS FILTERS RESPONSE ", response.body);

        NotificationsFilterResponse notificationsFilterResponse = NotificationsFilterResponse.fromJson(jsonDecode(response.body));

        final controller = Get.find<NotificationSettingsController>();
        controller.notificationsFilterResponse = notificationsFilterResponse;

        return NotificationFiltersAPIRes(true,notificationsFilterResponse: notificationsFilterResponse);

      } else {
        return NotificationFiltersAPIRes(false);
      }
    } catch (e) {
      LoggingUtils.printValue("EXCEPTION GET NOTIFICATIONS FILTERS API", e);
      return NotificationFiltersAPIRes(false);
    }
  }
}
