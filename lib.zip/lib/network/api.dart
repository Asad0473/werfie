import 'package:http/http.dart' as http;

class Api {
  // ignore: missing_return
  Future<String> get(url,
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    var response = await http.get(
      url,
      headers: token,
    );
    // print("get api request " + url.toString());

    // print(response.statusCode);
    // print(response.body);

    if (response.statusCode >= 200 && response.statusCode <= 209) {
      // print("sdfsdfsdfsdf ${response.body}");

      return response.body;
    } else {
      //print(response.body);
    }
  }

  Future<String> post(url, {queryParameters, Map<String, String> token}) async {
    var response = await http.post(url, body: queryParameters, headers: token);
    // print('YAHAN');
    // print('HERE IS THE RECIEVED RESPONSE CODE ${response.statusCode}');
    // print("post api request " + url.toString());
    // print(response.body);

    if (response.statusCode >= 200 && response.statusCode <= 209) {
      // print(response.body);
      return response.body;
    } else {
      // print('HERE IN ELSE CONDITION');
      return response.body;
    }
  }

  // ignore: missing_return
  Future<dynamic> delete(url,
      {Map<String, String> queryParameters, Map<String, String> token}) async {
    // print(token);
    var response =
        await http.delete(url, body: queryParameters, headers: token);
    // print('RESPONSE' + response.body);
    if (response.statusCode >= 200 && response.statusCode <= 209) {
      // print('D E L E T E D S U C C E S S F U L L Y  ${response.body}');
      return response.body;
    } else {
      // print(response.body);
    }
  }
}
