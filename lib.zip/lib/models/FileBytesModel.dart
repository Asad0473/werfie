import 'dart:typed_data';

class FileBytesModel {
  Uint8List bytes;
  String name;

  FileBytesModel(Uint8List bytes, String name) {
    this.bytes = bytes;
    this.name = name;
  }
}