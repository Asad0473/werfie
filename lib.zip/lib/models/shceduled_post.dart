class ScheduledPost {
  int id;
  String body;
  int userId;
  int postTypeId;
  String privacyType;
  int languageId;
  String link;
  String linkTitle;
  String linkMeta;
  String linkImage;
  String shortenUrl;
  String fileType;
  String filePath;
  String originalName;
  String size;
  String thumbnailPath;
  String schedulerStatus;
  String postingTime;
  String createdAt;
  String updatedAt;
  bool isScheduledPostSelectedForDeletion = false;

  ScheduledPost(
      {this.id,
      this.body,
      this.userId,
      this.postTypeId,
      this.privacyType,
      this.languageId,
      this.link,
      this.linkTitle,
      this.linkMeta,
      this.linkImage,
      this.shortenUrl,
      this.fileType,
      this.filePath,
      this.originalName,
      this.size,
      this.thumbnailPath,
      this.schedulerStatus,
      this.postingTime,
      this.createdAt,
      this.updatedAt});

  ScheduledPost.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    body = json['body'];
    userId = json['user_id'];
    postTypeId = json['post_type_id'];
    privacyType = json['privacy_type'];
    languageId = json['language_id'];
    link = json['link'];
    linkTitle = json['link_title'];
    linkMeta = json['link_meta'];
    linkImage = json['link_image'];
    shortenUrl = json['shorten_url'];
    fileType = json['file_type'];
    filePath = json['file_path'];
    originalName = json['original_name'];
    size = json['size'];
    thumbnailPath = json['thumbnail_path'];
    schedulerStatus = json['scheduler_status'];
    postingTime = json['posting_time'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['body'] = this.body;
    data['user_id'] = this.userId;
    data['post_type_id'] = this.postTypeId;
    data['privacy_type'] = this.privacyType;
    data['language_id'] = this.languageId;
    data['link'] = this.link;
    data['link_title'] = this.linkTitle;
    data['link_meta'] = this.linkMeta;
    data['link_image'] = this.linkImage;
    data['shorten_url'] = this.shortenUrl;
    data['file_type'] = this.fileType;
    data['file_path'] = this.filePath;
    data['original_name'] = this.originalName;
    data['size'] = this.size;
    data['thumbnail_path'] = this.thumbnailPath;
    data['scheduler_status'] = this.schedulerStatus;
    data['posting_time'] = this.postingTime;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
