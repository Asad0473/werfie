import 'package:werfieapp/models/ReportUserModel/ReportUserSubCategory.dart';

class ReportUserCategories {
  String name;
  String description;
  List<ReportUserSubCategory> listSubCategory;

  ReportUserCategories(this.name, this.description, this.listSubCategory);

  static getReportCategoriesList() {
    List<ReportUserCategories> listReportUserCategories = [
      ReportUserCategories(
          'Hate',
          'Slurs, Racist or sexist stereotypes, Dehumanization, Incitement of fear or discrimination, Hateful references, Hateful symbols & logos',
          [
            ReportUserSubCategory('Hate', 'Slurs & Tropes',
                'We prohibit targeting others with repeated slurs, tropes or other content that intends to degrade or reinforce negative or harmful stereotypes about a protected category'),
            ReportUserSubCategory('Hate', 'Hateful References',
                'We prohibit targeting individuals or groups with content that references forms of violence or violent events where a protected category was the primary target or victims, where the intent is to harass'),
            ReportUserSubCategory('Hate', 'Dehumanization',
                'We prohibit the dehumanization of a group of people based on their religion, caste, age, disability, serious disease, national origin, race, ethnicity, gender, gender identity, or sexual orientation'),
            ReportUserSubCategory('Hate', 'Hateful Imagery',
                'We prohibit the use of logos, symbols, or images whose purpose is to promote hostility and malice against others based on their race, religion, disability, sexual orientation, gender identity or ethnicity/national origin'),
            ReportUserSubCategory('Hate', 'Incitement',
                'Encouraging others to deny support to a business or service, or spreading fear against me or a group of people, because of their identity'),
          ]),
      ReportUserCategories(
          'Abuse & Harassment',
          'Insults, Unwanted Sexual Content & Graphic Objectification, Unwanted NSFW & Graphic Content, Violent Event Denial, Targeted Harassment and Inciting Harassment',
          [
            ReportUserSubCategory('Abuse & Harassment', 'Unwanted NSFW & Graphic Content',
                'We prohibit targeting others with unwanted adult and graphic content'),
            ReportUserSubCategory('Abuse & Harassment', 'Targeted Harassment',
                'We consider targeted behavior as malicious, unreciprocated, and intended to humiliate or degrade an individual(s)'),
            ReportUserSubCategory('Abuse & Harassment', 'Insults',
                'We take action against the use of insults or profanity to target others'),
            ReportUserSubCategory(
                'Abuse & Harassment',
                'Unwanted Sexual Content & Graphic Objectification',
                'We prohibit unwanted sexual conduct and graphic objectification that sexually objectifies an individual without their consent'),
            ReportUserSubCategory('Abuse & Harassment', 'Violent Event Denial',
                'We prohibit content that denies that mass murder or other mass casualty events took place, where we can verify that the event occurred, and when the content is shared with abusive context.'),
            ReportUserSubCategory('Abuse & Harassment', 'Inciting Harassment',
                'We prohibit behavior that encourages others to harass or target specific individuals or groups of people with abuse'),
          ]),
      ReportUserCategories(
          'Violent Speech',
          'Violent Threats, Wish of Harm, Glorification of Violence, Incitement of Violence, Coded Incitement of Violence',
          [
            ReportUserSubCategory('Violent speech', 'Violent Threats',
                'You may not threaten to inflict physical harm on others, which includes (but is not limited to) threatening to kill, torture, sexually assault, or otherwise hurt someone'),
            ReportUserSubCategory('Violent speech', 'Glorification of Violence',
                'You may not glorify, praise, or celebrate acts of violence where harm occurred, which includes (but is not limited to) expressing gratitude that someone experienced physical harm or praising Violent entities and Perpetrators of Violent Attacks. This also includes glorifying animal abuse or cruelty.'),
            ReportUserSubCategory('Violent speech', 'Incitement of Violence',
                'You may not incite, promote, or encourage others to commit acts of violence or harm, which includes (but is not limited to) encouraging others to hurt themselves or inciting others to commit atrocity crimes including crimes against humanity, war crimes or genocide.'),
            ReportUserSubCategory('Violent speech', 'Wish of Harm',
                'You may not wish, hope, or express desire for harm. This includes (but is not limited to) hoping for others to die, suffer illnesses, tragic incidents, or experience other physically harmful consequences.'),
            ReportUserSubCategory('Violent speech', 'Coded Incitement of Violence',
                'You may not use coded language (often referred to as "dog whistles") to indirectly incite violence.'),
          ]),
      ReportUserCategories(
          'Child Safety',
          'Child sexual exploitation, grooming, physical child abuse, underage user',
          [
            ReportUserSubCategory(
                'Child safety',
                'Selling or distributing sexually explicit content involving a minor',
                ''),
            ReportUserSubCategory('Child safety', 'Sexualization of minors', ''),
            ReportUserSubCategory(
                'Child safety', 'Grooming or online enticement of minors', ''),
            ReportUserSubCategory('Child safety', 'Child sex trafficking', ''),
            ReportUserSubCategory('Child safety', 'Physical child abuse',
                'Including media of children in physical altercations, victims of bullying or abuse'),
            ReportUserSubCategory(
                'Child safety',
                'Minor at risk (e.g, adult with access to minor expressing desire to engage in sexual act)',
                ''),
            ReportUserSubCategory(
                'Child safety',
                'Illustrated, cartoon, computer generated media depicting a minor engaging in a sexual act or child-like sex doll',
                ''),
            ReportUserSubCategory('Child safety', 'Underage user', ''),
            ReportUserSubCategory(
                'Child safety',
                'Normalizing or glorifying acts of child sexual exploitation',
                ''),
          ]),
      ReportUserCategories(
          'Privacy',
          'Sharing private information, threatening to share/expose private information, sharing non-consensual intimate images, sharing images of me that I don’t want on the platform',
          [
            ReportUserSubCategory(
                'Exposing private info',
                'Threatening to share or sharing private personal information without permission',
                ''),
            ReportUserSubCategory(
                'Exposing private info',
                'Threatening to share or sharing a sexual, nude, or intimate photo/video of me or someone without permission',
                ''),
            ReportUserSubCategory(
                'Exposing private info',
                'Sharing a photo/video of me that I do not want on the platform',
                ''),
          ]),
      ReportUserCategories(
          'Spam',
          'Fake accounts, financial scams, posting malicious links, misusing hashtags, fake engagement, repetitive replies, Reposts, or Direct Messages',
          [
            ReportUserSubCategory(
                'Spam',
                'Fake News or Misinformation',
                ''),
            ReportUserSubCategory(
                'Spam',
                'Keyword Stuffing or Content Spam',
                ''),
            ReportUserSubCategory(
                'Spam',
                'Malware or Virus',
                ''),
          ]),
      ReportUserCategories(
          'Suicide or self-harm',
          'Encouraging, promoting, providing instructions or sharing strategies for self-harm.',
          [
            ReportUserSubCategory(
                'Suicide or self-harm',
                'Asking others for encouragement to engage in self-harm or suicide',
                ''),
            ReportUserSubCategory(
                'Suicide or self-harm',
                'Sharing info, strategies, or methods that would help people self-harm',
                ''),
            ReportUserSubCategory(
                'Suicide or self-harm',
                'Expressing tendencies or intention to engage in self-harm or suicide',
                ''),
          ]),
      ReportUserCategories(
          'Sensitive or disturbing media',
          'Graphic Content, Gratutitous Gore, Adult Nudity & Sexual Behavior, Violent Sexual Conduct, Bestiality & Necrophilia, Media depicting a deceased individual',
          [
            ReportUserSubCategory('Sensitive media', 'Graphic Content',
                'Graphic content is any media that depicts death, violence, medical procedures, or serious physical injury in graphic detail of humans or animals'),
            ReportUserSubCategory('Sensitive media', 'Gratuitious Gore',
                'Gratuitous gore is any media that depicts excessively graphic or gruesome content related to death, violence or severe physical harm, or graphic content that is shared for sadistic purposes. This includes animal abuse & cruelty.'),
            ReportUserSubCategory(
                'Sensitive media',
                'I am a family member or authorized reporter and I am reporting media depicting a deceased individual',
                ''),
            ReportUserSubCategory('Sensitive media', 'Violent sexual conduct',
                'Violent sexual conduct is any media that depicts violence, whether real or simulated, in association with sexual acts.'),
            ReportUserSubCategory(
                'Sensitive media',
                'Besitiality & Necrophilia',
                'Bestiality is any media that depicts sexual acts between a human and an animal. Necrophilia is any media that depicts sexual acts between a living human and a human corpse.'),
            ReportUserSubCategory(
                'Sensitive media',
                'Adult Nudity & Sexual Behavior',
                'Adult Nudity & Sexual Behavior'),
          ]),
      ReportUserCategories('Deceptive identities',
          'Impersonation, non-compliant parody/fan accounts', [
        ReportUserSubCategory('Impersonation',
            'Pretending to be me, my brand or a user that I represent', ''),
        ReportUserSubCategory(
            'Impersonation', 'Someone else on X is being impersonated', ''),
      ]),
      ReportUserCategories('Violent & hateful entities',
          'Violent extremism and terrorism, hate groups & networks', [
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone',
            'What’s happening now',
            'We received your report. We’ll hide the reported post from your timeline in the meantime.'),
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone',
            'What’s next',
            'We’ll use an automated process to review this post for spam. Automation allows us to better manage the hundreds of millions of reports we receive every year. We’ll also use this info to improve our platform and show you less content like this.'),
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone',
            'Additional things you can do in the meantime',
            'Remove ⁦@RjeyTech⁩’s posts from your timeline without unfollowing or blocking them.'),
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone',
            '',
            'Block ⁦@RjeyTech⁩ from following you, viewing your posts, or messaging you. By blocking them, you also won’t see any posts or notifications from them.'),
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone', '', ''),
        ReportUserSubCategory(
            'Thanks for helping make X better for everyone', '', ''),
      ]),
    ];
    return listReportUserCategories;
  }
}
