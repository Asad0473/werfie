class ReportUserSubCategory{

  String title;
  String name;
  String description;

  ReportUserSubCategory(this.title,this.name, this.description);
}