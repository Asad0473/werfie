// To parse this JSON data, do
//
//     final removeUnfollowModel = removeUnfollowModelFromJson(jsonString);

import 'dart:convert';

RemoveUnfollowModel removeUnfollowModelFromJson(String str) =>
    RemoveUnfollowModel.fromJson(json.decode(str));

String removeUnfollowModelToJson(RemoveUnfollowModel data) =>
    json.encode(data.toJson());

class RemoveUnfollowModel {
  RemoveUnfollowModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  Data data;

  factory RemoveUnfollowModel.fromJson(Map<String, dynamic> json) =>
      RemoveUnfollowModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.followerId,
  });

  int followerId;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        followerId: json["follower_id"],
      );

  Map<String, dynamic> toJson() => {
        "follower_id": followerId,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
