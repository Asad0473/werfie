class UserProfile {
  UserProfile({
    this.firstname,
    this.lastname,
    this.email,
    this.phone,
    this.profileImage,
    this.coverImage,
    this.followers,
    this.followings,
    this.bio,
    this.languageId,
    this.autoTranslate,
    this.username,
    this.is_follow,
    this.region,
    this.userId,
    this.notificationAllowed,
    this.dob,
    this.accountVerified,
    this.muted,
    this.totalPosts,
    this.gender,
    this.age,
    this.digestType,
    this.createdAt,
    this.delete_cover_picture,
    this.delete_profile_picture, this.is2FAEnable,
    this.followedBy
  });

  String firstname;
  String lastname;
  String email;
  String phone;
  String profileImage;
  dynamic coverImage;
  int followers;
  int followings;
  dynamic bio;
  int languageId;
  String username;
  int autoTranslate;
  bool is_follow;
  String region;
  int notificationAllowed;
  String dob;
  int userId;
  String accountVerified;
  bool muted;
  int totalPosts;
  String gender;
  String createdAt;
  String digestType;
  int age;
  bool delete_cover_picture;
  bool delete_profile_picture;
  int is2FAEnable = 0;
  String followedBy;

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        firstname: json["firstname"],
        lastname: json["lastname"],
        username: json['username'],
        email: json["email"],
        phone: json["phone_no"],
        profileImage: json["profile_image"],
        coverImage: json["cover_image"],
        followers: json["followers"],
        followings: json["followings"],
        bio: json["bio"],
        region: json["region"] == null ? null : json["region"],
        languageId: json["language_id"],
        autoTranslate: json["auto_translate"],
        is_follow: json['is_follow'] ?? false,
        userId: json['user_id'] == null ? json['id'] : json['user_id'],
        notificationAllowed: json['notification_allowed'],
        dob: json['dob'],
        accountVerified:
            json['account_verified'] == null ? null : json['account_verified'],
        muted: json['muted'] ?? false,
        totalPosts: json['total_posts'],
        gender: json['gender'],
        createdAt: json["created_at"],
        age: json['age'],
        digestType: json['digest'],
        delete_cover_picture: json['delete_cover_picture'],
        delete_profile_picture: json['delete_profile_picture'],
        is2FAEnable: json['is_two_fa_enabled'],
        followedBy: json['followed_by'] ?? ""
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "firstname": firstname,
        "lastname": lastname,
        "email": email,
        "phone_no": phone,
        "profile_image": profileImage,
        "cover_image": coverImage,
        "followers": followers,
        "followings": followings,
        "bio": bio,
        "language_id": languageId,
        "auto_translate": autoTranslate,
        "dob": dob,
        "account_verified": accountVerified == null ? null : accountVerified,
        'muted': muted,
        "total_posts": totalPosts,
        "gender": gender,
        "created_at": createdAt,
        'age': age,
        'digest': digestType,
        'delete_cover_picture': delete_cover_picture,
        'delete_profile_picture': delete_profile_picture,
        'is_two_fa_enabled': is2FAEnable,
        'followed_by': followedBy
      };
}
