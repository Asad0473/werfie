class FilteredPeople {
  FilteredPeople({
    this.userId,
    this.authorName,
    this.profileImage,
    this.username,
    this.following,
    this.accountVerified,
  });

  int userId;
  String authorName;
  String profileImage;
  String username;
  bool following;
  String accountVerified;

  factory FilteredPeople.fromJson(Map<String, dynamic> json) => FilteredPeople(
        userId: json["user_id"],
        authorName: json["author_name"],
        profileImage: json["profile_image"],
        username: json["username"],
        following: json["following"],
        accountVerified:
            json['account_verified'] == null ? null : json['account_verified'],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "author_name": authorName,
        "profile_image": profileImage,
        "username": username,
        "following": following,
        "account_verified": accountVerified == null ? null : accountVerified,
      };
}
