// To parse this JSON data, do
//
//     final reaction = reactionFromJson(jsonString);

import 'dart:convert';
import 'dart:core';
import 'dart:core';

class Reactions {
  String action;
  Meta meta;
  Data data;

  Reactions({this.action, this.meta, this.data});

  Reactions.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  List<ReactionCounts> reactionCounts;
  List<ReactedUser> reactedUser;

  Data({this.reactionCounts, this.reactedUser});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['reaction_counts'] != null) {
      reactionCounts = <ReactionCounts>[];
      json['reaction_counts'].forEach((v) {
        reactionCounts.add(new ReactionCounts.fromJson(v));
      });
    }
    if (json['reacted_user'] != null) {
      reactedUser = <ReactedUser>[];
      json['reacted_user'].forEach((v) {
        reactedUser.add(new ReactedUser.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.reactionCounts != null) {
      data['reaction_counts'] =
          this.reactionCounts.map((v) => v.toJson()).toList();
    }
    if (this.reactedUser != null) {
      data['reacted_user'] = this.reactedUser.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ReactionCounts {
  int likes;
  int loves;
  int loughs;
  int smiles;
  int thanks;
  int exciteds;
  int crys;

  ReactionCounts(
      {this.likes,
      this.loves,
      this.loughs,
      this.smiles,
      this.thanks,
      this.exciteds,
      this.crys});

  ReactionCounts.fromJson(Map<String, dynamic> json) {
    likes = json['likes'];
    loves = json['loves'];
    loughs = json['loughs'];
    smiles = json['smiles'];
    thanks = json['thanks'];
    exciteds = json['exciteds'];
    crys = json['crys'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['likes'] = this.likes;
    data['loves'] = this.loves;
    data['loughs'] = this.loughs;
    data['smiles'] = this.smiles;
    data['thanks'] = this.thanks;
    data['exciteds'] = this.exciteds;
    data['crys'] = this.crys;
    return data;
  }
}

class ReactedUser {
  int postId;
  int userId;
  String username;
  String profileImage;
  String type;
  String accountVerified;

  ReactedUser(
      {this.postId,
      this.userId,
      this.username,
      this.profileImage,
      this.type,
      this.accountVerified});

  ReactedUser.fromJson(Map<String, dynamic> json) {
    postId = json['post_id'];
    userId = json['user_id'];
    username = json['username'];
    profileImage = json['profile_image'];
    type = json['type'];
    accountVerified = json['account_verified'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['post_id'] = this.postId;
    data['user_id'] = this.userId;
    data['username'] = this.username;
    data['profile_image'] = this.profileImage;
    data['type'] = this.type;
    data['account_verified'] = this.accountVerified;
    return data;
  }
}

Reaction1 reactionFromJson(String str) => Reaction1.fromJson(json.decode(str));

String reactionToJson(Reaction1 data) => json.encode(data.toJson());

class Reaction1 {
  Reaction1({
    this.postId,
    this.userId,
    this.username,
    this.profileImage,
    this.accountVerified,
    this.type,
  });

  int postId;
  int userId;
  String username;
  dynamic profileImage;
  String type;
  String accountVerified;

  factory Reaction1.fromJson(Map<String, dynamic> json) => Reaction1(
        postId: json["post_id"],
        userId: json["user_id"],
        username: json["username"],
        profileImage: json["profile_image"],
        type: json["type"],
        accountVerified: json["verified"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
        "user_id": userId,
        "username": username,
        "profile_image": profileImage,
        "type": type,
        "verified": accountVerified
      };
}
