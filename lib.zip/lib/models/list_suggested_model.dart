// To parse this JSON data, do
//
//     final suggestedUserPostModel = suggestedUserPostModelFromJson(jsonString);

import 'dart:convert';

SuggestedUserPostModel suggestedUserPostModelFromJson(String str) =>
    SuggestedUserPostModel.fromJson(json.decode(str));

String suggestedUserPostModelToJson(SuggestedUserPostModel data) =>
    json.encode(data.toJson());

class SuggestedUserPostModel {
  SuggestedUserPostModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  List<Datum> data;

  factory SuggestedUserPostModel.fromJson(Map<String, dynamic> json) =>
      SuggestedUserPostModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.id,
    this.authorName,
    this.authorProfileImage,
    this.username,
    this.bio,
  });

  int id;
  String authorName;
  dynamic authorProfileImage;
  String username;
  bool isFollow = false;
  dynamic bio;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        authorName: json["author_name"],
        authorProfileImage: json["author_profile_image"],
        username: json["username"],
        bio: json["bio"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "author_name": authorName,
        "author_profile_image": authorProfileImage,
        "username": username,
        "bio": bio,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
