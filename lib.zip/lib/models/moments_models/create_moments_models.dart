class MomentData {
  MomentData({
    this.title,
    this.userId,
    this.description,
    this.privacyType,
    this.id,
    this.coverImage,
  });

  String title;
  int userId;
  String description;
  String privacyType;
  String coverImage;
  int id;

  factory MomentData.fromJson(Map<String, dynamic> json) => MomentData(
        title: json["title"],
        userId: json["user_id"],
        coverImage: json['cover_image'] == null ? null : json['cover_image'],
        description: json["description"],
        privacyType: json["privacy_type"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "user_id": userId,
        "description": description,
        "privacy_type": privacyType,
        'cover_image': coverImage == null ? null : coverImage,
        "id": id,
      };
}
