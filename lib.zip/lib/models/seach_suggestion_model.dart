class SearchSuggestion {
  SearchSuggestion({
    this.id,
    this.title,
    this.type,
    this.username,
    this.profileImage,
    this.firstname,
    this.accountVerified,
  });

  int id;
  String title;
  String type;
  String username;
  String firstname;
  String profileImage;
  String accountVerified;

  factory SearchSuggestion.fromJson(Map<String, dynamic> json) =>
      SearchSuggestion(
        id: json["id"],
        title: json["title"] == null ? null : json["title"],
        type: json["type"] == null ? null : json["type"],
        username: json["username"] == null ? null : json["username"],
        firstname: json["firstname"] == null ? null : json["firstname"],
        profileImage:
            json["profile_image"] == null ? null : json["profile_image"],
        accountVerified:
            json['account_verified'] == null ? null : json['account_verified'],
      );
}
