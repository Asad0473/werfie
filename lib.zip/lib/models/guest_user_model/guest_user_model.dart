// To parse this JSON data, do
//
//     final guestUserModel = guestUserModelFromJson(jsonString);

import 'dart:convert';

import 'package:werfieapp/models/post.dart';

GuestUserModelTopicData guestUserModelFromJson(String str) =>
    GuestUserModelTopicData.fromJson(json.decode(str));

String guestUserModelToJson(GuestUserModelTopicData data) =>
    json.encode(data.toJson());

class GuestUserModelTopicData {
  GuestUserModelTopicData({
    this.topic,
    this.items,
  });

  Topic topic;
  List<Post> items;

  factory GuestUserModelTopicData.fromJson(Map<String, dynamic> json) =>
      GuestUserModelTopicData(
        topic: Topic.fromJson(json["topic"]),
        items: json["items"] == null
            ? []
            : List<Post>.from(json["items"].map((x) => Post.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "topic": topic.toJson(),
        "items":
            items == null ? [] : List<Post>.from(items.map((x) => x.toJson())),
      };
}

class Topic {
  Topic({
    this.id,
    this.topic,
  });

  int id;
  String topic;

  factory Topic.fromJson(Map<String, dynamic> json) => Topic(
        id: json["id"],
        topic: json["topic"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "topic": topic,
      };
}
