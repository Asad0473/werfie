import 'dart:convert';

import '../post.dart';


GuestUserSearchResultModel guestUserSearchResultModelFromJson(String str) =>
    GuestUserSearchResultModel.fromJson(json.decode(str));

String guestUserSearchResultModelToJson(GuestUserSearchResultModel data) =>
    json.encode(data.toJson());

class GuestUserSearchResultModel {
  GuestUserSearchResultModel({
    // this.user,
    this.posts,
  });

  // User user;
  List<Post> posts;

  factory GuestUserSearchResultModel.fromJson(Map<String, dynamic> json) =>
      GuestUserSearchResultModel(
        // user: User.fromJson(json["user"]),
        posts: List<Post>.from(json["posts"].map((x) => Post.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        //  "user": user.toJson(),
        "posts": List<dynamic>.from(posts.map((x) => x.toJson())),
      };
}
