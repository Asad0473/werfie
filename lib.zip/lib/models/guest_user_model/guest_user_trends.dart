import 'dart:convert';

GuestUserTrends guestUserTrendsFromJson(String str) =>
    GuestUserTrends.fromJson(json.decode(str));

String guestUserTrendsToJson(GuestUserTrends data) =>
    json.encode(data.toJson());

class GuestUserTrends {
  GuestUserTrends({
    this.id,
    this.title,
    this.usedCount,
    this.image,
  });

  int id;
  String title;
  int usedCount;
  dynamic image;

  factory GuestUserTrends.fromJson(Map<String, dynamic> json) =>
      GuestUserTrends(
        id: json["id"],
        title: json["title"],
        usedCount: json["used_count"],
        image: json["image"] == null ? null : json["image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "used_count": usedCount,
        "image": image,
      };
}
