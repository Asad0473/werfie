// To parse this JSON data, do
//
//     final guestUserSearchQueryModel = guestUserSearchQueryModelFromJson(jsonString);

import 'dart:convert';

GuestUserSearchQueryModel guestUserSearchQueryModelFromJson(String str) =>
    GuestUserSearchQueryModel.fromJson(json.decode(str));

String guestUserSearchQueryModelToJson(GuestUserSearchQueryModel data) =>
    json.encode(data.toJson());

class GuestUserSearchQueryModel {
  GuestUserSearchQueryModel({
    this.tags,
    this.users,
  });

  List<Tag> tags;
  List<User> users;

  factory GuestUserSearchQueryModel.fromJson(Map<String, dynamic> json) =>
      GuestUserSearchQueryModel(
        tags: List<Tag>.from(json["tags"].map((x) => Tag.fromJson(x))),
        users: List<User>.from(json["users"].map((x) => User.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "tags": List<dynamic>.from(tags.map((x) => x.toJson())),
        "users": List<dynamic>.from(users.map((x) => x.toJson())),
      };
}

class Tag {
  Tag({
    this.id,
    this.title,
    this.usedCount,
    this.createdAt,
    this.updatedAt,
    this.countryId,
    this.regionName,
    this.cityName,
    this.zipCode,
  });

  int id;
  String title;
  int usedCount;
  DateTime createdAt;
  DateTime updatedAt;
  int countryId;
  dynamic regionName;
  dynamic cityName;
  dynamic zipCode;

  factory Tag.fromJson(Map<String, dynamic> json) => Tag(
        id: json["id"],
        title: json["title"],
        usedCount: json["used_count"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        countryId: json["country_id"],
        regionName: json["region_name"] == null ? null : json["region_name"],
        cityName: json["city_name"] == null ? null : json["city_name"],
        zipCode: json["zip_code"] == null ? null : json["zip_code"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "used_count": usedCount,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "country_id": countryId,
        "region_name": regionName,
        "city_name": cityName,
        "zip_code": zipCode,
      };
}

class User {
  User({
    this.id,
    this.emailVerifiedAt,
    this.isBlock,
    this.profileImage,
    this.coverImage,
    this.dob,
    this.city,
    this.aboutMe,
    this.gender,
    this.createdAt,
    this.updatedAt,
    this.firstname,
    this.lastname,
    this.email,
    this.isOnline,
    this.lastLogin,
    this.username,
  });

  int id;
  dynamic emailVerifiedAt;
  int isBlock;
  String profileImage;
  String coverImage;
  dynamic dob;
  dynamic city;
  String aboutMe;
  dynamic gender;
  DateTime createdAt;
  DateTime updatedAt;
  String firstname;
  String lastname;
  String email;
  int isOnline;
  DateTime lastLogin;
  String username;

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        emailVerifiedAt: json["email_verified_at"] == null
            ? null
            : json["email_verified_at"],
        isBlock: json["is_block"],
        profileImage:
            json["profile_image"] == null ? null : json["profile_image"],
        coverImage: json["cover_image"] == null ? null : json["cover_image"],
        dob: json["dob"] == null ? null : json["dob"],
        city: json["city"] == null ? null : json["city"],
        aboutMe: json["about_me"] == null ? null : json["about_me"],
        gender: json["gender"] == null ? null : json["gender"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        firstname: json["firstname"],
        lastname: json["lastname"],
        email: json["email"],
        isOnline: json["is_online"],
        username: json["username"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email_verified_at": emailVerifiedAt,
        "is_block": isBlock,
        "profile_image": profileImage,
        "cover_image": coverImage,
        "dob": dob,
        "city": city,
        "about_me": aboutMe,
        "gender": gender,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "firstname": firstname,
        "lastname": lastname,
        "email": email,
        "is_online": isOnline,
        "last_login": lastLogin?.toIso8601String(),
        "username": username,
      };
}
