

class GetFollowerModel {
  GetFollowerModel(
      {this.name,
      this.profileImage,
      this.username,
      this.authorGender,
      this.followerId,
      this.follow,
      this.id,
      this.accountVerified,
      this.bio,
      });

  String name;
  int id;
  String profileImage;
  String username;
  String authorGender;
  int followerId;
  bool follow;
  bool isFollow = false;
  String accountVerified;
  String bio;

  factory GetFollowerModel.fromJson(Map<String, dynamic> json) =>
      GetFollowerModel(
        name: json["name"],
        id: json["id"],
        follow: json["follow"],
        authorGender: json["author_gender"],
        profileImage: json["profile_image"],
        username: json["username"],
        followerId: json["follower_id"],
        accountVerified:
            json['account_verified'] == null ? null : json['account_verified'],
        bio: json["bio"]
      );
}

class GetFollowingModel {
  GetFollowingModel({
    this.name,
    this.profileImage,
    this.username,
    this.authorGender,
    this.followerId,
    this.accountVerified,
    this.isFollow = false,
    this.bio,
  });

  String name;
  String profileImage;
  String username;
  String authorGender;
  int followerId;
  bool isFollow;
  String bio;
  String accountVerified;

  factory GetFollowingModel.fromJson(Map<String, dynamic> json) =>
      GetFollowingModel(
        // isFollow:json["follow"],
        name: json["name"],
        authorGender: json["author_gender"],
        profileImage: json["profile_image"],
        username: json["username"],
        followerId: json["follower_id"],
        accountVerified:
            json['account_verified'] == null ? null : json['account_verified'],
          bio: json["bio"]
      );
}
