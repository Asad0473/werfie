import 'package:flutter_tts/flutter_tts.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/chatUserModel.dart';

class MessageModel {
  MessageModel({
    this.id,
    this.body,
    this.userId,
    this.conversationId,
    this.audioFile,
    this.speechToText,
    this.postTypeId,
    this.languageId,
    this.thumbnail,
    this.speechLanguageId,
    this.processingStatus,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.repliedToMessageId,
    this.deletedAt,
    this.seenBy,
    this.deliveredTo,
    this.createdAt,
    this.updatedAt,
    this.authorId,
    this.audioMsgUrl,
    this.profileImage,
    this.fullName,
    this.firstname,
    this.lastname,
    this.username,
    this.postTypes,
    this.isDeliveredToMe,
    this.isSeenByMe,
    this.post,
    this.messageFiles,
    this.seenByAll = false,
    this.deliverByAll = false,
    this.isMessageSelected = false,
    this.reactionInfo,
    this.replyMsgModel,
  });

  int id;
  String body;
  int userId;
  int conversationId;
  dynamic audioFile;
  dynamic speechToText;
  int postTypeId;
  int languageId;
  dynamic speechLanguageId;
  String processingStatus;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  dynamic repliedToMessageId;
  dynamic deletedAt;
  String seenBy;
  String thumbnail;
  String deliveredTo;
  DateTime createdAt;
  DateTime updatedAt;
  int authorId;
  dynamic audioMsgUrl;
  String profileImage;
  String fullName;
  String firstname;
  String lastname;
  String postTypes;
  int isDeliveredToMe;
  int isSeenByMe;
  bool seenByAll;
  bool deliverByAll;
  List<dynamic> messageFiles;
  bool isMessageSelected;
  String messageStatus = "send";
  FlutterTts tts;
  MessagePost post;
  RxBool onHover = false.obs;
  bool isTTSPlaying = false;
  bool isPlay = false;
  List<Member> reactionInfo;
  String username;
  MessageModel replyMsgModel;

  factory MessageModel.fromJson(Map<String, dynamic> json) => MessageModel(
      id: json["id"],
      body: json["body"],
      thumbnail: json["thumbnail_url"],
      conversationId: json["conversation_id"],
      userId: json["user_id"],
      seenByAll: json["seen_by_all"] == null ? false : json["seen_by_all"],
      deliverByAll:
          json["deliver_by_all"] == null ? false : json["deliver_by_all"],
      audioFile: json["audio_file"],
      speechToText: json["speech_to_text"],
      postTypeId: json["post_type_id"],
      languageId: json["language_id"],
      speechLanguageId: json["speech_language_id"],
      processingStatus: json["processing_status"],
      link: json["link"],
      linkTitle: json["link_title"],
      linkMeta: json["link_meta"],
      linkImage: json["link_image"],
      repliedToMessageId: json["replied_to_message_id"],
      deletedAt: json["deleted_at"],
      seenBy: json["seen_by"],
      deliveredTo: json["delivered_to"],
      createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
      updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
      authorId: json["author_id"],
      audioMsgUrl: json["audio_msg_url"],
      profileImage: json["profile_image"],
      fullName: json["full_name"],
      firstname: json["firstname"],
      lastname: json["lastname"],
      username: json["username"],
      postTypes: json["post_types"],
      isDeliveredToMe: json["is_delivered_to_me"],
      isSeenByMe: json["is_seen_by_me"],
      messageFiles: json["message_files"] == null ? [] : json["message_files"],
      reactionInfo: json["reactionInfo"] == null ? null : List<Member>.from(json["reactionInfo"].map((x) => Member.fromJson(x))),
      //json["reactionInfo"] == null ? [] : json["reactionInfo"],
      post: json['post'] != null ? new MessagePost.fromJson(json['post']) : null,
      replyMsgModel: json['replied_to'] != null ? MessageModel.fromJson(json['replied_to']) : null);
}

class MessagePost {
  int id;
  String body;
  dynamic location;
  dynamic lat;
  dynamic lng;
  int userId;
  int blocked;
  int commentsCount;
  int postTypeId;
  int simpleLikeCount;
  int simpleDislikeCount;
  int sharesCount;
  dynamic postedOnTimelineId;
  dynamic sharedPostId;
  int statusId;
  dynamic statusReason;
  String privacyType;
  int languageId;
  String publishStatus;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  dynamic shortenUrl;
  dynamic deletedAt;
  String createdAt;
  String updatedAt;
  int processablesCount;
  dynamic rePostId;
  String type;
  dynamic pollQuesFirst;
  dynamic pollQuesSecond;
  dynamic pollQuesThird;
  dynamic pollQuesFourth;
  dynamic pollExpires;
  dynamic quoteId;
  dynamic replyId;
  int pinPost;
  int threadNo;
  List<MessageFiles> files;

  MessagePost(
      {this.id,
      this.body,
      this.location,
      this.lat,
      this.lng,
      this.userId,
      this.blocked,
      this.commentsCount,
      this.postTypeId,
      this.simpleLikeCount,
      this.simpleDislikeCount,
      this.sharesCount,
      this.postedOnTimelineId,
      this.sharedPostId,
      this.statusId,
      this.statusReason,
      this.privacyType,
      this.languageId,
      this.publishStatus,
      this.link,
      this.linkTitle,
      this.linkMeta,
      this.linkImage,
      this.shortenUrl,
      this.deletedAt,
      this.createdAt,
      this.updatedAt,
      this.processablesCount,
      this.rePostId,
      this.type,
      this.pollQuesFirst,
      this.pollQuesSecond,
      this.pollQuesThird,
      this.pollQuesFourth,
      this.pollExpires,
      this.quoteId,
      this.replyId,
      this.pinPost,
      this.threadNo,
      this.files});

  MessagePost.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    body = json['body'];
    location = json['location'];
    lat = json['lat'];
    lng = json['lng'];
    userId = json['user_id'];
    blocked = json['blocked'];
    commentsCount = json['comments_count'];
    postTypeId = json['post_type_id'];
    simpleLikeCount = json['simple_like_count'];
    simpleDislikeCount = json['simple_dislike_count'];
    sharesCount = json['shares_count'];
    postedOnTimelineId = json['posted_on_timeline_id'];
    sharedPostId = json['shared_post_id'];
    statusId = json['status_id'];
    statusReason = json['status_reason'];
    privacyType = json['privacy_type'];
    languageId = json['language_id'];
    publishStatus = json['publish_status'];
    link = json['link'];
    linkTitle = json['link_title'];
    linkMeta = json['link_meta'];
    linkImage = json['link_image'];
    shortenUrl = json['shorten_url'];
    deletedAt = json['deleted_at'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    processablesCount = json['processables_count'];
    rePostId = json['re_post_id'];
    type = json['type'];
    pollQuesFirst = json['poll_ques_first'];
    pollQuesSecond = json['poll_ques_second'];
    pollQuesThird = json['poll_ques_third'];
    pollQuesFourth = json['poll_ques_fourth'];
    pollExpires = json['poll_expires'];
    quoteId = json['quote_id'];
    replyId = json['reply_id'];
    pinPost = json['pin_post'];
    threadNo = json['thread_no'];
    if (json['files'] != null) {
      files = new List<MessageFiles>();
      json['files'].forEach((v) {
        files.add(new MessageFiles.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['body'] = this.body;
    data['location'] = this.location;
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    data['user_id'] = this.userId;
    data['blocked'] = this.blocked;
    data['comments_count'] = this.commentsCount;
    data['post_type_id'] = this.postTypeId;
    data['simple_like_count'] = this.simpleLikeCount;
    data['simple_dislike_count'] = this.simpleDislikeCount;
    data['shares_count'] = this.sharesCount;
    data['posted_on_timeline_id'] = this.postedOnTimelineId;
    data['shared_post_id'] = this.sharedPostId;
    data['status_id'] = this.statusId;
    data['status_reason'] = this.statusReason;
    data['privacy_type'] = this.privacyType;
    data['language_id'] = this.languageId;
    data['publish_status'] = this.publishStatus;
    data['link'] = this.link;
    data['link_title'] = this.linkTitle;
    data['link_meta'] = this.linkMeta;
    data['link_image'] = this.linkImage;
    data['shorten_url'] = this.shortenUrl;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['processables_count'] = this.processablesCount;
    data['re_post_id'] = this.rePostId;
    data['type'] = this.type;
    data['poll_ques_first'] = this.pollQuesFirst;
    data['poll_ques_second'] = this.pollQuesSecond;
    data['poll_ques_third'] = this.pollQuesThird;
    data['poll_ques_fourth'] = this.pollQuesFourth;
    data['poll_expires'] = this.pollExpires;
    data['quote_id'] = this.quoteId;
    data['reply_id'] = this.replyId;
    data['pin_post'] = this.pinPost;
    data['thread_no'] = this.threadNo;
    if (this.files != null) {
      data['files'] = this.files.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class MessageFiles {
  int id;
  String fileType;
  int postId;
  String filePath;
  dynamic speechToText;
  dynamic speechToTextWords;
  String originalName;
  int size;
  String thumbnailPath;
  int viewsCount;
  String narratorGender;
  int languageId;
  int hasCorrectFilePath;
  String processingStatus;
  dynamic deletedAt;
  String createdAt;
  String updatedAt;
  dynamic mentionUserIds;
  dynamic description;

  MessageFiles(
      {this.id,
      this.fileType,
      this.postId,
      this.filePath,
      this.speechToText,
      this.speechToTextWords,
      this.originalName,
      this.size,
      this.thumbnailPath,
      this.viewsCount,
      this.narratorGender,
      this.languageId,
      this.hasCorrectFilePath,
      this.processingStatus,
      this.deletedAt,
      this.createdAt,
      this.updatedAt,
      this.mentionUserIds,
      this.description});

  MessageFiles.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fileType = json['file_type'];
    postId = json['post_id'];
    filePath = json['file_path'];
    speechToText = json['speech_to_text'];
    speechToTextWords = json['speech_to_text_words'];
    originalName = json['original_name'];
    size = json['size'];
    thumbnailPath = json['thumbnail_path'];
    viewsCount = json['views_count'];
    narratorGender = json['narrator_gender'];
    languageId = json['language_id'];
    hasCorrectFilePath = json['has_correct_file_path'];
    processingStatus = json['processing_status'];
    deletedAt = json['deleted_at'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    mentionUserIds = json['mention_user_ids'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['file_type'] = this.fileType;
    data['post_id'] = this.postId;
    data['file_path'] = this.filePath;
    data['speech_to_text'] = this.speechToText;
    data['speech_to_text_words'] = this.speechToTextWords;
    data['original_name'] = this.originalName;
    data['size'] = this.size;
    data['thumbnail_path'] = this.thumbnailPath;
    data['views_count'] = this.viewsCount;
    data['narrator_gender'] = this.narratorGender;
    data['language_id'] = this.languageId;
    data['has_correct_file_path'] = this.hasCorrectFilePath;
    data['processing_status'] = this.processingStatus;
    data['deleted_at'] = this.deletedAt;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['mention_user_ids'] = this.mentionUserIds;
    data['description'] = this.description;
    return data;
  }
}
