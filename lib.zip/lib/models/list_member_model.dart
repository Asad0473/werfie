// To parse this JSON data, do
//
//     final addMemberListModel = addMemberListModelFromJson(jsonString);

import 'dart:convert';

AddMemberListModel addMemberListModelFromJson(String str) =>
    AddMemberListModel.fromJson(json.decode(str));

String addMemberListModelToJson(AddMemberListModel data) =>
    json.encode(data.toJson());

class AddMemberListModel {
  AddMemberListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  Data data;

  factory AddMemberListModel.fromJson(Map<String, dynamic> json) =>
      AddMemberListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.memberFollowerId,
    this.listId,
    this.type,
    this.updatedAt,
    this.createdAt,
    this.id,
  });

  String memberFollowerId;
  String listId;
  String type;
  DateTime updatedAt;
  DateTime createdAt;
  int id;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        memberFollowerId: json["member_follower_id"],
        listId: json["list_id"],
        type: json["type"],
        updatedAt: DateTime.parse(json["updated_at"]),
        createdAt: DateTime.parse(json["created_at"]),
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "member_follower_id": memberFollowerId,
        "list_id": listId,
        "type": type,
        "updated_at": updatedAt.toIso8601String(),
        "created_at": createdAt.toIso8601String(),
        "id": id,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
