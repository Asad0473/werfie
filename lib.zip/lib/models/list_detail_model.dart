// To parse this JSON data, do
//
//     final listDetailModel = listDetailModelFromJson(jsonString);

import 'dart:convert';

import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';

ListDetailModel listDetailModelFromJson(String str) =>
    ListDetailModel.fromJson(json.decode(str));

String listDetailModelToJson(ListDetailModel data) =>
    json.encode(data.toJson());

class ListDetailModel {
  ListDetailModel({
    this.listDetail,
    this.newsfeed,
  });

  ListDetail listDetail;
  List<Post> newsfeed;

  factory ListDetailModel.fromJson(Map<String, dynamic> json) =>
      ListDetailModel(
        listDetail: ListDetail.fromJson(json["list_detail"]),
        newsfeed:
            List<Post>.from(json["newsfeed"].map((x) => Post.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "list_detail": listDetail.toJson(),
        "newsfeed": List<dynamic>.from(newsfeed.map((x) => x.toJson())),
      };
}

class ListDetail {
  ListDetail({
    this.id,
    this.userId,
    this.name,
    this.description,
    this.coverImage,
    this.makePrivate,
    this.createdAt,
    this.updatedAt,
    this.membersCount,
    this.followersCount,
  });

  int id;
  int userId;
  String name;
  dynamic description;
  dynamic coverImage;
  String makePrivate;
  DateTime createdAt;
  DateTime updatedAt;
  int membersCount;
  int followersCount;

  factory ListDetail.fromJson(Map<String, dynamic> json) => ListDetail(
        id: json["id"],
        userId: json["user_id"],
        name: json["name"],
        description: json["description"],
        coverImage: json["cover_image"],
        makePrivate: json["make_private"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        membersCount: json["members_count"],
        followersCount: json["followers_count"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "name": name,
        "description": description,
        "cover_image": coverImage,
        "make_private": makePrivate,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "members_count": membersCount,
        "followers_count": followersCount,
      };
}

class Newsfeed {
  Newsfeed({
    this.id,
    this.postId,
    this.authorName,
    this.profileImage,
    this.username,
    this.authorId,
    this.postedOn,
    this.postType,
    this.body,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.shortenUrl,
    this.type,
    this.pollQuesFirst,
    this.pollQuesSecond,
    this.pollQuesThird,
    this.pollQuesFourth,
    this.pollExpires,
    this.location,
    this.lat,
    this.lng,
    this.simpleLikeCount,
    this.commentsCount,
    this.languageId,
    this.quoteId,
    this.threadNo,
    this.retweetCount,
    this.youRetweet,
    this.postFiles,
    this.canEdit,
    this.userProfile,
    this.followed,
    this.followingLikes,
    this.followingRetweets,
    this.trending,
    this.saved,
    this.postedTimeAgo,
    this.comments,
    this.isLiked,
  });

  int id;
  int postId;
  Name authorName;
  dynamic profileImage;
  Username username;
  int authorId;
  DateTime postedOn;
  Type postType;
  String body;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  dynamic shortenUrl;
  TypeEnum type;
  dynamic pollQuesFirst;
  dynamic pollQuesSecond;
  dynamic pollQuesThird;
  dynamic pollQuesFourth;
  dynamic pollExpires;
  dynamic location;
  dynamic lat;
  dynamic lng;
  int simpleLikeCount;
  int commentsCount;
  int languageId;
  dynamic quoteId;
  int threadNo;
  int retweetCount;
  bool youRetweet;
  List<PostFile> postFiles;
  bool canEdit;
  UserProfile userProfile;
  bool followed;
  List<dynamic> followingLikes;
  List<dynamic> followingRetweets;
  dynamic trending;
  bool saved;
  String postedTimeAgo;
  List<dynamic> comments;
  bool isLiked;

  factory Newsfeed.fromJson(Map<String, dynamic> json) => Newsfeed(
        id: json["id"],
        postId: json["post_id"],
        authorName: nameValues.map[json["author_name"]],
        profileImage: json["profile_image"],
        username: usernameValues.map[json["username"]],
        authorId: json["author_id"],
        postedOn: DateTime.parse(json["posted_on"]),
        postType: typeValues.map[json["post_type"]],
        body: json["body"],
        link: json["link"],
        linkTitle: json["link_title"],
        linkMeta: json["link_meta"],
        linkImage: json["link_image"],
        shortenUrl: json["shorten_url"],
        type: typeEnumValues.map[json["type"]],
        pollQuesFirst: json["poll_ques_first"],
        pollQuesSecond: json["poll_ques_second"],
        pollQuesThird: json["poll_ques_third"],
        pollQuesFourth: json["poll_ques_fourth"],
        pollExpires: json["poll_expires"],
        location: json["location"],
        lat: json["lat"],
        lng: json["lng"],
        simpleLikeCount: json["simple_like_count"],
        commentsCount: json["comments_count"],
        languageId: json["language_id"],
        quoteId: json["quote_id"],
        threadNo: json["thread_no"],
        retweetCount: json["retweet_count"],
        youRetweet: json["you_retweet"],
        postFiles: List<PostFile>.from(
            json["post_files"].map((x) => PostFile.fromJson(x))),
        canEdit: json["can_edit"],
        userProfile: UserProfile.fromJson(json["author_basic_info"]),
        followed: json["followed"],
        followingLikes:
            List<dynamic>.from(json["following_likes"].map((x) => x)),
        followingRetweets:
            List<dynamic>.from(json["following_retweets"].map((x) => x)),
        trending: json["trending"],
        saved: json["saved"],
        postedTimeAgo: json["posted_time_ago"],
        comments: List<dynamic>.from(json["comments"].map((x) => x)),
        isLiked: json["isLiked"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "post_id": postId,
        "author_name": nameValues.reverse[authorName],
        "profile_image": profileImage,
        "username": usernameValues.reverse[username],
        "author_id": authorId,
        "posted_on": postedOn.toIso8601String(),
        "post_type": typeValues.reverse[postType],
        "body": body,
        "link": link,
        "link_title": linkTitle,
        "link_meta": linkMeta,
        "link_image": linkImage,
        "shorten_url": shortenUrl,
        "type": typeEnumValues.reverse[type],
        "poll_ques_first": pollQuesFirst,
        "poll_ques_second": pollQuesSecond,
        "poll_ques_third": pollQuesThird,
        "poll_ques_fourth": pollQuesFourth,
        "poll_expires": pollExpires,
        "location": location,
        "lat": lat,
        "lng": lng,
        "simple_like_count": simpleLikeCount,
        "comments_count": commentsCount,
        "language_id": languageId,
        "quote_id": quoteId,
        "thread_no": threadNo,
        "retweet_count": retweetCount,
        "you_retweet": youRetweet,
        "post_files": List<dynamic>.from(postFiles.map((x) => x.toJson())),
        "can_edit": canEdit,
        "author_basic_info": userProfile.toJson(),
        "followed": followed,
        "following_likes": List<dynamic>.from(followingLikes.map((x) => x)),
        "following_retweets":
            List<dynamic>.from(followingRetweets.map((x) => x)),
        "trending": trending,
        "saved": saved,
        "posted_time_ago": postedTimeAgo,
        "comments": List<dynamic>.from(comments.map((x) => x)),
        "isLiked": isLiked,
      };
}

class AuthorBasicInfo {
  AuthorBasicInfo({
    this.id,
    this.emailVerifiedAt,
    this.isBlock,
    this.profileImage,
    this.coverImage,
    this.dob,
    this.city,
    this.aboutMe,
    this.gender,
    this.createdAt,
    this.updatedAt,
    this.firstname,
    this.lastname,
    this.email,
    this.languageId,
    this.website,
    this.isOnline,
    this.lastLogin,
    this.username,
    this.accountVerified,
    this.apiToken,
    this.notificationAllowed,
    this.deletedAt,
    this.followers,
    this.followings,
    this.isFollow,
    this.bio,
    this.region,
  });

  int id;
  dynamic emailVerifiedAt;
  int isBlock;
  dynamic profileImage;
  dynamic coverImage;
  dynamic dob;
  dynamic city;
  dynamic aboutMe;
  dynamic gender;
  DateTime createdAt;
  DateTime updatedAt;
  Name firstname;
  String lastname;
  Email email;
  dynamic languageId;
  dynamic website;
  int isOnline;
  DateTime lastLogin;
  Username username;
  AccountVerified accountVerified;
  dynamic apiToken;
  int notificationAllowed;
  dynamic deletedAt;
  int followers;
  int followings;
  bool isFollow;
  dynamic bio;
  dynamic region;

  factory AuthorBasicInfo.fromJson(Map<String, dynamic> json) =>
      AuthorBasicInfo(
        id: json["id"],
        emailVerifiedAt: json["email_verified_at"],
        isBlock: json["is_block"],
        profileImage: json["profile_image"],
        coverImage: json["cover_image"],
        dob: json["dob"],
        city: json["city"],
        aboutMe: json["about_me"],
        gender: json["gender"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        firstname: nameValues.map[json["firstname"]],
        lastname: json["lastname"],
        email: emailValues.map[json["email"]],
        languageId: json["language_id"],
        website: json["website"],
        isOnline: json["is_online"],
        lastLogin: DateTime.parse(json["last_login"]),
        username: usernameValues.map[json["username"]],
        accountVerified: accountVerifiedValues.map[json["account_verified"]],
        apiToken: json["api_token"],
        notificationAllowed: json["notification_allowed"],
        deletedAt: json["deleted_at"],
        followers: json["followers"],
        followings: json["followings"],
        isFollow: json["is_follow"],
        bio: json["bio"],
        region: json["region"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email_verified_at": emailVerifiedAt,
        "is_block": isBlock,
        "profile_image": profileImage,
        "cover_image": coverImage,
        "dob": dob,
        "city": city,
        "about_me": aboutMe,
        "gender": gender,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "firstname": nameValues.reverse[firstname],
        "lastname": lastname,
        "email": emailValues.reverse[email],
        "language_id": languageId,
        "website": website,
        "is_online": isOnline,
        "last_login": lastLogin.toIso8601String(),
        "username": usernameValues.reverse[username],
        "account_verified": accountVerifiedValues.reverse[accountVerified],
        "api_token": apiToken,
        "notification_allowed": notificationAllowed,
        "deleted_at": deletedAt,
        "followers": followers,
        "followings": followings,
        "is_follow": isFollow,
        "bio": bio,
        "region": region,
      };
}

enum AccountVerified { VERIFIED }

final accountVerifiedValues =
    EnumValues({"verified": AccountVerified.VERIFIED});

enum Email { ASIF_IMDAD_SOFTECH_COM_PK }

final emailValues =
    EnumValues({"asif.imdad@softech.com.pk": Email.ASIF_IMDAD_SOFTECH_COM_PK});

enum Name { ASIF_ALI }

final nameValues = EnumValues({"Asif ali": Name.ASIF_ALI});

enum Username { ASIFALI }

final usernameValues = EnumValues({"asifali": Username.ASIFALI});

class PostFile {
  PostFile({
    this.id,
    this.fileType,
    this.postId,
    this.filePath,
    this.thumbnailPath,
    this.originalName,
    this.size,
    this.viewsCount,
  });

  int id;
  Type fileType;
  int postId;
  String filePath;
  String thumbnailPath;
  String originalName;
  int size;
  int viewsCount;

  factory PostFile.fromJson(Map<String, dynamic> json) => PostFile(
        id: json["id"],
        fileType: typeValues.map[json["file_type"]],
        postId: json["post_id"],
        filePath: json["file_path"],
        thumbnailPath:
            json["thumbnail_path"] == null ? null : json["thumbnail_path"],
        originalName: json["original_name"],
        size: json["size"],
        viewsCount: json["views_count"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "file_type": typeValues.reverse[fileType],
        "post_id": postId,
        "file_path": filePath,
        "thumbnail_path": thumbnailPath == null ? null : thumbnailPath,
        "original_name": originalName,
        "size": size,
        "views_count": viewsCount,
      };
}

enum Type { POST, VIDEO, IMAGE }

final typeValues =
    EnumValues({"image": Type.IMAGE, "post": Type.POST, "video": Type.VIDEO});

enum TypeEnum { POST, THREAD }

final typeEnumValues =
    EnumValues({"post": TypeEnum.POST, "thread": TypeEnum.THREAD});

class EnumValues<T> {
  Map<String, T> map;
  Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap;
  }
}
