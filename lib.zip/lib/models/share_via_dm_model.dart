class ShareViaDMModel {
  List<int> _conversationIds;
  int _postId;
  String _comment;

  ShareViaDMModel({List<int> conversationIds, int postId, String comment}) {
    if (conversationIds != null) {
      this._conversationIds = conversationIds;
    }
    if (postId != null) {
      this._postId = postId;
    }
    if (comment != null) {
      this._comment = comment;
    }
  }

  List<int> get conversationIds => _conversationIds;

  set conversationIds(List<int> conversationIds) =>
      _conversationIds = conversationIds;

  int get postId => _postId;

  set postId(int postId) => _postId = postId;

  String get comment => _comment;

  set comment(String comment) => _comment = comment;

  ShareViaDMModel.fromJson(Map<String, dynamic> json) {
    _conversationIds = json['conversation_ids'].cast<int>();
    _postId = json['post_id'];
    _comment = json['comment'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['conversation_ids'] = this._conversationIds;
    data['post_id'] = this._postId;
    data['comment'] = this._comment;
    return data;
  }
}
