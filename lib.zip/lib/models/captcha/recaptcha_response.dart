class RecaptchaResponse {
  String action;
  Meta meta;
  Data data;

  RecaptchaResponse({this.action, this.meta, this.data});

  RecaptchaResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  bool success;
  String challengeTs;
  String hostname;
  double score;
  String action;

  Data(
      {this.success, this.challengeTs, this.hostname, this.score, this.action});

  Data.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    challengeTs = json['challenge_ts'];
    hostname = json['hostname'];
    score = json['score'];
    action = json['action'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['challenge_ts'] = this.challengeTs;
    data['hostname'] = this.hostname;
    data['score'] = this.score;
    data['action'] = this.action;
    return data;
  }
}
