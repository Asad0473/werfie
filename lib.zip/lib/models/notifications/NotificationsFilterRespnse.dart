class NotificationsFilterResponse {
  String action;
  Meta meta;
  Data data;

  NotificationsFilterResponse({this.action, this.meta, this.data});

  NotificationsFilterResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int userId;
  int youDontFollow;
  int whoDontFollowYou;
  int withNewAccount;
  int defaultPhotoUsers;
  int emailNotConfirmedUsers;
  int phoneNotConfirmedUsers;
  int qualityFilter;

  Data(
      {this.userId,
        this.youDontFollow,
        this.whoDontFollowYou,
        this.withNewAccount,
        this.defaultPhotoUsers,
        this.emailNotConfirmedUsers,
        this.phoneNotConfirmedUsers,
        this.qualityFilter});

  Data.fromJson(Map<String, dynamic> json) {
    userId = json['user_id'];
    youDontFollow = json['you_dont_follow'];
    whoDontFollowYou = json['who_dont_follow_you'];
    withNewAccount = json['with_new_account'];
    defaultPhotoUsers = json['default_photo_users'];
    emailNotConfirmedUsers = json['email_not_confirmed_users'];
    phoneNotConfirmedUsers = json['phone_not_confirmed_users'];
    qualityFilter = json['quality_filter'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_id'] = this.userId;
    data['you_dont_follow'] = this.youDontFollow;
    data['who_dont_follow_you'] = this.whoDontFollowYou;
    data['with_new_account'] = this.withNewAccount;
    data['default_photo_users'] = this.defaultPhotoUsers;
    data['email_not_confirmed_users'] = this.emailNotConfirmedUsers;
    data['phone_not_confirmed_users'] = this.phoneNotConfirmedUsers;
    data['quality_filter'] = this.qualityFilter;
    return data;
  }
}
