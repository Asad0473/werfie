class EmailNotificationsSettingsResponse {
  String action;
  Meta meta;
  Data data;

  EmailNotificationsSettingsResponse({this.action, this.meta, this.data});

  EmailNotificationsSettingsResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int emailNotificationSwitch;
  int newNotifications;
  int directMessages;
  int werfsEmailedToYou;
  String topWerfsAndStories;
  int newAboutWerfie;
  int tipsOnWerfie;
  int thingsYouMissed;
  int participationInResearch;
  int suggestionOnAccounts;
  int suggestionBasedRecentFollowers;

  Data(
      {this.emailNotificationSwitch,
        this.newNotifications,
        this.directMessages,
        this.werfsEmailedToYou,
        this.topWerfsAndStories,
        this.newAboutWerfie,
        this.tipsOnWerfie,
        this.thingsYouMissed,
        this.participationInResearch,
        this.suggestionOnAccounts,
        this.suggestionBasedRecentFollowers});

  Data.fromJson(Map<String, dynamic> json) {
    emailNotificationSwitch = json['email_notification_switch'];
    newNotifications = json['new_notifications'];
    directMessages = json['direct_messages'];
    werfsEmailedToYou = json['werfs_emailed_to_you'];
    topWerfsAndStories = json['top_werfs_and_stories'];
    newAboutWerfie = json['new_about_werfie'];
    tipsOnWerfie = json['tips_on_werfie'];
    thingsYouMissed = json['things_you_missed'];
    participationInResearch = json['participation_in_research'];
    suggestionOnAccounts = json['suggestion_on_accounts'];
    suggestionBasedRecentFollowers = json['suggestion_based_recent_followers'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email_notification_switch'] = this.emailNotificationSwitch;
    data['new_notifications'] = this.newNotifications;
    data['direct_messages'] = this.directMessages;
    data['werfs_emailed_to_you'] = this.werfsEmailedToYou;
    data['top_werfs_and_stories'] = this.topWerfsAndStories;
    data['new_about_werfie'] = this.newAboutWerfie;
    data['tips_on_werfie'] = this.tipsOnWerfie;
    data['things_you_missed'] = this.thingsYouMissed;
    data['participation_in_research'] = this.participationInResearch;
    data['suggestion_on_accounts'] = this.suggestionOnAccounts;
    data['suggestion_based_recent_followers'] =
        this.suggestionBasedRecentFollowers;
    return data;
  }
}
