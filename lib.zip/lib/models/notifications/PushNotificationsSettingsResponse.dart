class PushNotificationsSettingsResponse {
  String action;
  Meta meta;
  Data data;

  PushNotificationsSettingsResponse({this.action, this.meta, this.data});

  PushNotificationsSettingsResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int werfsNotification;
  String topWerfs;
  String reWerfs;
  String likes;
  int photoTags;
  int newFollowers;
  int directMesages;
  String messageReactions;
  int topics;
  int newsOrSports;
  int recommendations;
  int moments;

  Data(
      {this.werfsNotification,
        this.topWerfs,
        this.reWerfs,
        this.likes,
        this.photoTags,
        this.newFollowers,
        this.directMesages,
        this.messageReactions,
        this.topics,
        this.newsOrSports,
        this.recommendations,
        this.moments});

  Data.fromJson(Map<String, dynamic> json) {
    werfsNotification = json['werfs_notification'];
    topWerfs = json['top_werfs'];
    reWerfs = json['re_werfs'];
    likes = json['likes'];
    photoTags = json['photo_tags'];
    newFollowers = json['new_followers'];
    directMesages = json['direct_mesages'];
    messageReactions = json['message_reactions'];
    topics = json['topics'];
    newsOrSports = json['news_or_sports'];
    recommendations = json['recommendations'];
    moments = json['moments'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['werfs_notification'] = this.werfsNotification;
    data['top_werfs'] = this.topWerfs;
    data['re_werfs'] = this.reWerfs;
    data['likes'] = this.likes;
    data['photo_tags'] = this.photoTags;
    data['new_followers'] = this.newFollowers;
    data['direct_mesages'] = this.directMesages;
    data['message_reactions'] = this.messageReactions;
    data['topics'] = this.topics;
    data['news_or_sports'] = this.newsOrSports;
    data['recommendations'] = this.recommendations;
    data['moments'] = this.moments;
    return data;
  }
}
