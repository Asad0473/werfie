import 'package:intl/intl.dart';

class TranslationData {
  String action;
  Meta meta;
  List<Data> data;

  TranslationData({this.action, this.meta, this.data});

  TranslationData.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  int postId;
  String authorName;
  String profileImage;
  String username;
  int authorId;
  String postedOn;
  String postType;
  String body;
  var link;
  var linkTitle;
  var linkMeta;
  var linkImage;
  var shortenUrl;
  String type;
  var pollQuesFirst;
  var pollQuesSecond;
  var pollQuesThird;
  var pollQuesFourth;
  var pollExpires;
  var location;
  var lat;
  var lng;
  int simpleLikeCount;
  int commentsCount;
  int languageId;
  var quoteId;
  int threadNo;
  String originalBody;
  String languageDirection;

  Data({
    this.id,
    this.postId,
    this.authorName,
    this.profileImage,
    this.username,
    this.authorId,
    this.postedOn,
    this.postType,
    this.body,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.shortenUrl,
    this.type,
    this.pollQuesFirst,
    this.pollQuesSecond,
    this.pollQuesThird,
    this.pollQuesFourth,
    this.pollExpires,
    this.location,
    this.lat,
    this.lng,
    this.simpleLikeCount,
    this.commentsCount,
    this.languageId,
    this.quoteId,
    this.threadNo,
    this.originalBody,
    this.languageDirection,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    postId = json['post_id'];
    authorName = json['author_name'];
    profileImage = json['profile_image'];
    username = json['username'];
    authorId = json['author_id'];
    postedOn = json['posted_on'];
    postType = json['post_type'];
    body = Bidi.stripHtmlIfNeeded(json['body']);
    link = json['link'];
    linkTitle = json['link_title'];
    linkMeta = json['link_meta'];
    linkImage = json['link_image'];
    shortenUrl = json['shorten_url'];
    type = json['type'];
    pollQuesFirst = json['poll_ques_first'];
    pollQuesSecond = json['poll_ques_second'];
    pollQuesThird = json['poll_ques_third'];
    pollQuesFourth = json['poll_ques_fourth'];
    pollExpires = json['poll_expires'];
    location = json['location'];
    lat = json['lat'];
    lng = json['lng'];
    simpleLikeCount = json['simple_like_count'];
    commentsCount = json['comments_count'];
    languageId = json['language_id'];
    quoteId = json['quote_id'];
    threadNo = json['thread_no'];
    originalBody = json['original_body'];
    languageDirection = json["language_direction"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['post_id'] = this.postId;
    data['author_name'] = this.authorName;
    data['profile_image'] = this.profileImage;
    data['username'] = this.username;
    data['author_id'] = this.authorId;
    data['posted_on'] = this.postedOn;
    data['post_type'] = this.postType;
    data['body'] = this.body;
    data['link'] = this.link;
    data['link_title'] = this.linkTitle;
    data['link_meta'] = this.linkMeta;
    data['link_image'] = this.linkImage;
    data['shorten_url'] = this.shortenUrl;
    data['type'] = this.type;
    data['poll_ques_first'] = this.pollQuesFirst;
    data['poll_ques_second'] = this.pollQuesSecond;
    data['poll_ques_third'] = this.pollQuesThird;
    data['poll_ques_fourth'] = this.pollQuesFourth;
    data['poll_expires'] = this.pollExpires;
    data['location'] = this.location;
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    data['simple_like_count'] = this.simpleLikeCount;
    data['comments_count'] = this.commentsCount;
    data['language_id'] = this.languageId;
    data['quote_id'] = this.quoteId;
    data['thread_no'] = this.threadNo;
    data['original_body'] = this.originalBody;
    data["language_direction"] = this.languageDirection;
    return data;
  }
}
