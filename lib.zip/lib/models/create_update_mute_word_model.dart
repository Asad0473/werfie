class CreateMuteWord {
  String action;
  Meta meta;
  Data data;

  CreateMuteWord({this.action, this.meta, this.data});

  CreateMuteWord.fromJson(Map json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map toJson() {
    final Map data = new Map();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}
class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map json) {
    code = json['code'];
    message = json['message'];
  }

  Map toJson() {
    final Map data = new Map();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  int userId;
  String word;
  String muteFromHome;
  String notificationSwitch;
  String notificationValue;
  String muteDuration;
  String createdAt;
  String updatedAt;

  Data(
      {this.id,
        this.userId,
        this.word,
        this.muteFromHome,
        this.notificationSwitch,
        this.notificationValue,
        this.muteDuration,
        this.createdAt,
        this.updatedAt});

  Data.fromJson(Map json) {
    id = json['id'];
    userId = json['user_id'];
    word = json['word'];
    muteFromHome = json['mute_from_home'];
    notificationSwitch = json['notification_switch'];
    notificationValue = json['notification_value'];
    muteDuration = json['mute_duration'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map toJson() {
    final Map data = new Map();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['word'] = this.word;
    data['mute_from_home'] = this.muteFromHome;
    data['notification_switch'] = this.notificationSwitch;
    data['notification_value'] = this.notificationValue;
    data['mute_duration'] = this.muteDuration;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}