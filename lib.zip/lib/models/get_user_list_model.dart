import 'dart:convert';

UserListModel userListModelFromJson(String str) =>
    UserListModel.fromJson(json.decode(str));

String userListModelToJson(UserListModel data) => json.encode(data.toJson());

class UserListModel {
  UserListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  List<Datum> data;

  factory UserListModel.fromJson(Map<String, dynamic> json) => UserListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    this.id,
    this.title,
    this.type,
    this.firstname,
    this.username,
    this.profileImage,
  });

  int id;
  String title;
  String type;
  String firstname;
  String username;
  String profileImage;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        title: json["title"] == null ? null : json["title"],
        type: json["type"],
        firstname: json["firstname"] == null ? null : json["firstname"],
        username: json["username"] == null ? null : json["username"],
        profileImage:
            json["profile_image"] == null ? null : json["profile_image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title == null ? null : title,
        "type": type,
        "firstname": firstname == null ? null : firstname,
        "username": username == null ? null : username,
        "profile_image": profileImage == null ? null : profileImage,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
