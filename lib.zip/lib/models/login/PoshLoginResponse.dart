class PoshLoginResponse {
  String action;
  Meta meta;
  Data data;

  PoshLoginResponse({this.action, this.meta, this.data});

  PoshLoginResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  String token;
  String phone;
  String email;
  String username;
  int id;

  Data({this.token, this.phone, this.email, this.username, this.id});

  Data.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    phone = json['phone'];
    email = json['email'];
    username = json['username'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['token'] = this.token;
    data['phone'] = this.phone;
    data['email'] = this.email;
    data['username'] = this.username;
    data['id'] = this.id;
    return data;
  }
}
