class Send2FAResponse {
  String action;
  Meta meta;
  Data data;

  Send2FAResponse({this.action, this.meta, this.data});

  Send2FAResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  Null emailVerifiedAt;
  int isBlock;
  String profileImage;
  String coverImage;
  String dob;
  String city;
  String aboutMe;
  String createdAt;
  String updatedAt;
  String firstname;
  String lastname;
  String email;

  Data(
      {this.id,
        this.emailVerifiedAt,
        this.isBlock,
        this.profileImage,
        this.coverImage,
        this.dob,
        this.city,
        this.aboutMe,
        this.createdAt,
        this.updatedAt,
        this.firstname,
        this.lastname,
        this.email,});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    emailVerifiedAt = json['email_verified_at'];
    isBlock = json['is_block'];
    profileImage = json['profile_image'];
    coverImage = json['cover_image'];
    dob = json['dob'];
    city = json['city'];
    aboutMe = json['about_me'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['email_verified_at'] = this.emailVerifiedAt;
    data['is_block'] = this.isBlock;
    data['profile_image'] = this.profileImage;
    data['cover_image'] = this.coverImage;
    data['dob'] = this.dob;
    data['city'] = this.city;
    data['about_me'] = this.aboutMe;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;
    return data;
  }
}