class SavedPostModel {
  SavedPostModel({
    this.postId,
    this.authorName,
    this.profileImage,
    this.username,
    this.authorGender,
    this.authorId,
    this.postedOn,
    this.postType,
    this.postTypeColorCode,
    this.body,
    this.location,
    this.simpleLikeCount,
    this.simpleDislikeCount,
    this.sharesCount,
    this.sharedPostId,
    this.privacyType,
    this.commentsCount,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.languageId,
    this.publishStatus,
    this.savedItemType,
    this.savedItemId,
    this.postFiles,
    this.comments,
    this.postedTimeAgo,
    this.language,
    this.isLiked,
    this.isDisliked,
    this.languageDirection,
    this.autoTranslate,
    this.taggedUsers,
    this.youAreTagged,
  });

  int postId;
  String authorName;
  dynamic profileImage;
  String username;
  dynamic authorGender;
  int authorId;
  DateTime postedOn;
  String postType;
  String postTypeColorCode;
  String body;
  String location;
  int simpleLikeCount;
  int simpleDislikeCount;
  int sharesCount;
  dynamic sharedPostId;
  String privacyType;
  int commentsCount;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  int languageId;
  String publishStatus;
  String savedItemType;
  int savedItemId;
  List<PostFile> postFiles;
  List<Comment> comments;
  String postedTimeAgo;
  Language language;
  bool isLiked;
  bool isDisliked;
  String languageDirection;
  bool autoTranslate;
  List<dynamic> taggedUsers;
  bool youAreTagged;

  factory SavedPostModel.fromJson(Map<String, dynamic> json) => SavedPostModel(
        postId: json["post_id"],
        authorName: json["author_name"],
        profileImage: json["profile_image"],
        username: json["username"],
        authorGender: json["author_gender"],
        authorId: json["author_id"],
        postedOn: DateTime.parse(json["posted_on"]),
        postType: json["post_type"],
        postTypeColorCode: json["post_type_color_code"],
        body: json["body"],
        location: json["location"],
        simpleLikeCount: json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"],
        sharesCount: json["shares_count"],
        sharedPostId: json["shared_post_id"],
        privacyType: json["privacy_type"],
        commentsCount: json["comments_count"],
        link: json["link"],
        linkTitle: json["link_title"],
        linkMeta: json["link_meta"],
        linkImage: json["link_image"],
        languageId: json["language_id"] == null ? null : json["language_id"],
        publishStatus: json["publish_status"],
        savedItemType: json["saved_item_type"],
        savedItemId: json["saved_item_id"],
        postFiles: List<PostFile>.from(
            json["post_files"].map((x) => PostFile.fromJson(x))),
        comments: List<Comment>.from(
            json["comments"].map((x) => Comment.fromJson(x))),
        postedTimeAgo: json["posted_time_ago"],
        language: Language.fromJson(json["language"]),
        isLiked: json["isLiked"],
        isDisliked: json["isDisliked"],
        languageDirection: json["language_direction"],
        autoTranslate: json["auto_translate"],
        taggedUsers: List<dynamic>.from(json["tagged_users"].map((x) => x)),
        youAreTagged: json["you_are_tagged"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
        "author_name": authorName,
        "profile_image": profileImage,
        "username": username,
        "author_gender": authorGender,
        "author_id": authorId,
        "posted_on": postedOn.toIso8601String(),
        "post_type": postType,
        "post_type_color_code": postTypeColorCode,
        "body": body,
        "location": location,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "shares_count": sharesCount,
        "shared_post_id": sharedPostId,
        "privacy_type": privacyType,
        "comments_count": commentsCount,
        "link": link,
        "link_title": linkTitle,
        "link_meta": linkMeta,
        "link_image": linkImage,
        "language_id": languageId == null ? null : languageId,
        "publish_status": publishStatus,
        "saved_item_type": savedItemType,
        "saved_item_id": savedItemId,
        "post_files": List<dynamic>.from(postFiles.map((x) => x.toJson())),
        "comments": List<dynamic>.from(comments.map((x) => x.toJson())),
        "posted_time_ago": postedTimeAgo,
        "language": language.toJson(),
        "isLiked": isLiked,
        "isDisliked": isDisliked,
        "language_direction": languageDirection,
        "auto_translate": autoTranslate,
        "tagged_users": List<dynamic>.from(taggedUsers.map((x) => x)),
        "you_are_tagged": youAreTagged,
      };
}

class Comment {
  Comment({
    this.id,
    this.body,
    this.userId,
    this.postTypeId,
    this.postId,
    this.status,
    this.processingStatus,
    this.simpleLikeCount,
    this.simpleDislikeCount,
    this.inReplyToId,
    this.repliesCount,
    this.audioFileUrl,
    this.audioPath,
    this.speechToText,
    this.languageId,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.createdAt,
    this.updatedAt,
    this.commentedTimeAgo,
    this.showOriginalBody,
    this.listenCommentUrl,
    this.author,
    this.commentLanguage,
  });

  int id;
  String body;
  int userId;
  int postTypeId;
  int postId;
  String status;
  String processingStatus;
  int simpleLikeCount;
  int simpleDislikeCount;
  dynamic inReplyToId;
  int repliesCount;
  dynamic audioFileUrl;
  dynamic audioPath;
  dynamic speechToText;
  int languageId;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  DateTime createdAt;
  DateTime updatedAt;
  String commentedTimeAgo;
  bool showOriginalBody;
  String listenCommentUrl;
  Author author;
  Language commentLanguage;

  factory Comment.fromJson(Map<String, dynamic> json) => Comment(
        id: json["id"],
        body: json["body"],
        userId: json["user_id"],
        postTypeId: json["post_type_id"],
        postId: json["post_id"],
        status: json["status"],
        processingStatus: json["processing_status"],
        simpleLikeCount: json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"],
        inReplyToId: json["in_reply_to_id"],
        repliesCount: json["replies_count"],
        audioFileUrl: json["audio_file_url"],
        audioPath: json["audio_path"],
        speechToText: json["speech_to_text"],
        languageId: json["language_id"],
        link: json["link"],
        linkTitle: json["link_title"],
        linkMeta: json["link_meta"],
        linkImage: json["link_image"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        commentedTimeAgo: json["commented_time_ago"],
        showOriginalBody: json["show_original_body"],
        listenCommentUrl: json["listen_comment_url"],
        author: Author.fromJson(json["author"]),
        commentLanguage: Language.fromJson(json["comment_language"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "body": body,
        "user_id": userId,
        "post_type_id": postTypeId,
        "post_id": postId,
        "status": status,
        "processing_status": processingStatus,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "in_reply_to_id": inReplyToId,
        "replies_count": repliesCount,
        "audio_file_url": audioFileUrl,
        "audio_path": audioPath,
        "speech_to_text": speechToText,
        "language_id": languageId,
        "link": link,
        "link_title": linkTitle,
        "link_meta": linkMeta,
        "link_image": linkImage,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "commented_time_ago": commentedTimeAgo,
        "show_original_body": showOriginalBody,
        "listen_comment_url": listenCommentUrl,
        "author": author.toJson(),
        "comment_language": commentLanguage.toJson(),
      };
}

class Author {
  Author({
    this.id,
    this.profileImage,
    this.firstname,
    this.lastname,
    this.username,
  });

  int id;
  dynamic profileImage;
  String firstname;
  String lastname;
  String username;

  factory Author.fromJson(Map<String, dynamic> json) => Author(
        id: json["id"],
        profileImage: json["profile_image"],
        firstname: json["firstname"],
        lastname: json["lastname"],
        username: json["username"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "profile_image": profileImage,
        "firstname": firstname,
        "lastname": lastname,
        "username": username,
      };
}

class Language {
  Language({
    this.id,
    this.name,
    this.code,
    this.direction,
    this.createdAt,
    this.updatedAt,
    this.code2,
    this.flagPath,
    this.isTranslationSupported,
    this.isTopLanguage,
  });

  int id;
  String name;
  String code;
  String direction;
  DateTime createdAt;
  DateTime updatedAt;
  String code2;
  String flagPath;
  String isTranslationSupported;
  String isTopLanguage;

  factory Language.fromJson(Map<String, dynamic> json) => Language(
        id: json["id"] == null ? null : json["id"],
        name: json["name"] == null ? null : json["name"],
        code: json["code"] == null ? null : json["code"],
        direction: json["direction"] == null ? null : json["direction"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        code2: json["code2"] == null ? null : json["code2"],
        flagPath: json["flag_path"] == null ? null : json["flag_path"],
        isTranslationSupported: json["is_translation_supported"] == null
            ? null
            : json["is_translation_supported"],
        isTopLanguage:
            json["is_top_language"] == null ? null : json["is_top_language"],
      );

  Map<String, dynamic> toJson() => {
        "id": id == null ? null : id,
        "name": name == null ? null : name,
        "code": code == null ? null : code,
        "direction": direction == null ? null : direction,
        "created_at": createdAt == null ? null : createdAt.toIso8601String(),
        "updated_at": updatedAt == null ? null : updatedAt.toIso8601String(),
        "code2": code2 == null ? null : code2,
        "flag_path": flagPath == null ? null : flagPath,
        "is_translation_supported":
            isTranslationSupported == null ? null : isTranslationSupported,
        "is_top_language": isTopLanguage == null ? null : isTopLanguage,
      };
}

class PostFile {
  PostFile({
    this.id,
    this.fileType,
    this.postId,
    this.filePath,
    this.speechToText,
    this.speechToTextWords,
    this.originalName,
    this.size,
    this.thumbnailPath,
    this.viewsCount,
    this.narratorGender,
    this.languageId,
    this.hasCorrectFilePath,
    this.processingStatus,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
    this.languageNameReadable,
    this.hasSpeechToText,
  });

  int id;
  String fileType;
  int postId;
  String filePath;
  dynamic speechToText;
  dynamic speechToTextWords;
  String originalName;
  dynamic size;
  dynamic thumbnailPath;
  int viewsCount;
  String narratorGender;
  int languageId;
  int hasCorrectFilePath;
  String processingStatus;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  String languageNameReadable;
  int hasSpeechToText;

  factory PostFile.fromJson(Map<String, dynamic> json) => PostFile(
        id: json["id"],
        fileType: json["file_type"],
        postId: json["post_id"],
        filePath: json["file_path"],
        speechToText: json["speech_to_text"],
        speechToTextWords: json["speech_to_text_words"],
        originalName: json["original_name"],
        size: json["size"],
        thumbnailPath: json["thumbnail_path"],
        viewsCount: json["views_count"],
        narratorGender: json["narrator_gender"],
        languageId: json["language_id"] == null ? null : json["language_id"],
        hasCorrectFilePath: json["has_correct_file_path"],
        processingStatus: json["processing_status"],
        deletedAt: json["deleted_at"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        languageNameReadable: json["language_name_readable"] == null
            ? null
            : json["language_name_readable"],
        hasSpeechToText: json["has_speech_to_text"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "file_type": fileType,
        "post_id": postId,
        "file_path": filePath,
        "speech_to_text": speechToText,
        "speech_to_text_words": speechToTextWords,
        "original_name": originalName,
        "size": size,
        "thumbnail_path": thumbnailPath,
        "views_count": viewsCount,
        "narrator_gender": narratorGender,
        "language_id": languageId == null ? null : languageId,
        "has_correct_file_path": hasCorrectFilePath,
        "processing_status": processingStatus,
        "deleted_at": deletedAt,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "language_name_readable":
            languageNameReadable == null ? null : languageNameReadable,
        "has_speech_to_text": hasSpeechToText,
      };
}
