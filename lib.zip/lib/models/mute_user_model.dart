class MuteUser {
  String action;
  Meta meta;
  List<Data> data;

  MuteUser({this.action, this.meta, this.data});

  MuteUser.fromJson(Map json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = [];
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
  }

  Map toJson() {
    final Map data = new Map();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }



}
class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map json) {
    code = json['code'];
    message = json['message'];
  }

  Map toJson() {
    final Map data = new Map();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}
class Data {
  int id;
  String username;
  String profileImage;

  Data({this.id, this.username, this.profileImage});

  Data.fromJson(Map json) {
    id = json['id'];
    username = json['username'];
    profileImage = json['profile_image'];
  }

  Map toJson() {
    final Map data = new Map();
    data['id'] = this.id;
    data['username'] = this.username;
    data['profile_image'] = this.profileImage;
    return data;
  }
}