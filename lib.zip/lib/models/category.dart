class CategoryModel {
  CategoryModel({this.name, this.id});

  String name;
  int id;

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
        name: json["name"],
        id: json["id"],
      );
}
