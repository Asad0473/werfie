class TopicData {
  String mainCateName;

  List<SubCategory> subCategory;

  TopicData({this.mainCateName, this.subCategory});
}

class SubCategory {
  String subCategoryName;

  List<SubSubCategory> subSubCategory;

  SubCategory({this.subCategoryName, this.subSubCategory});
}

class SubSubCategory {
  String subSubCateName;

  SubSubCategory({
    this.subSubCateName,
  });
}
