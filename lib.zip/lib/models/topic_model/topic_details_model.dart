import 'package:get/get_rx/src/rx_types/rx_types.dart';

import '../post.dart';

class Topic {
  String action;
  Meta meta;
  Data data;

  Topic({this.action, this.meta, this.data});

  Topic.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  TopicDetail topicDetail;
  List<TrendingUsers> trendingUsers;
  List<Post> newsfeed;

  Data({this.topicDetail, this.trendingUsers, this.newsfeed});

  Data.fromJson(Map<String, dynamic> json) {
    topicDetail = json['topic_detail'] != null
        ? new TopicDetail.fromJson(json['topic_detail'])
        : null;
    if (json['trending_users'] != null) {
      trendingUsers = <TrendingUsers>[];
      json['trending_users'].forEach((v) {
        trendingUsers.add(new TrendingUsers.fromJson(v));
      });
    }
    if (json['newsfeed'] != null) {
      newsfeed = <Post>[];
      json['newsfeed'].forEach((v) {
        newsfeed.add(new Post.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.topicDetail != null) {
      data['topic_detail'] = this.topicDetail.toJson();
    }
    if (this.trendingUsers != null) {
      data['trending_users'] =
          this.trendingUsers.map((v) => v.toJson()).toList();
    }
    if (this.newsfeed != null) {
      data['newsfeed'] = this.newsfeed.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class TopicDetail {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  RxString type = "".obs;

  TopicDetail({this.id, this.topic, this.createdAt, this.updatedAt, this.type});

  TopicDetail.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    type.value = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['type'] = this.type.value;
    return data;
  }
}

class TrendingUsers {
  int id;
  String username;
  String firstname;
  String profileImage;
  String accountVerified;
  RxInt isFollower = 0.obs;

  TrendingUsers(
      {this.id,
      this.username,
      this.firstname,
      this.profileImage,
      this.accountVerified,
      this.isFollower});

  TrendingUsers.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    username = json['username'];
    firstname = json['firstname'];
    profileImage = json['profile_image'];
    accountVerified = json['account_verified'];
    isFollower.value = json['is_follower'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['username'] = this.username;
    data['firstname'] = this.firstname;
    data['profile_image'] = this.profileImage;
    data['account_verified'] = this.accountVerified;
    data['is_follower'] = this.isFollower.value;
    return data;
  }
}
