import 'package:get/get_rx/src/rx_types/rx_types.dart';

class SuggestedFollowingTopicForOtherProfile {
  String action;
  Meta meta;
  Data data;

  SuggestedFollowingTopicForOtherProfile({this.action, this.meta, this.data});

  SuggestedFollowingTopicForOtherProfile.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  List<Topics> topics;
  List<SuggestedTopics> suggestedTopics;

  Data({this.topics, this.suggestedTopics});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['topics'] != null) {
      topics = <Topics>[];
      json['topics'].forEach((v) {
        topics.add(new Topics.fromJson(v));
      });
    }
    if (json['suggested_topics'] != null) {
      suggestedTopics = <SuggestedTopics>[];
      json['suggested_topics'].forEach((v) {
        suggestedTopics.add(new SuggestedTopics.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.topics != null) {
      data['topics'] = this.topics.map((v) => v.toJson()).toList();
    }
    if (this.suggestedTopics != null) {
      data['suggested_topics'] =
          this.suggestedTopics.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Topics {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  RxInt isFollowed = 0.obs;

  Topics(
      {this.id, this.topic, this.createdAt, this.updatedAt, this.isFollowed});

  Topics.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isFollowed.value = json['is_followed'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_followed'] = this.isFollowed.value;
    return data;
  }
}

class SuggestedTopics {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  RxInt type = 0.obs;

  SuggestedTopics({this.id, this.topic, this.createdAt, this.updatedAt});

  SuggestedTopics.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
