import 'package:get/get.dart';

class FollowingAndSuggestedTopics {
  String action;
  Meta meta;
  Data data;

  FollowingAndSuggestedTopics({this.action, this.meta, this.data});

  FollowingAndSuggestedTopics.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  List<SuggestedTopics> suggestedTopics;
  List<FollowingTopics> followingTopics;

  Data({this.suggestedTopics, this.followingTopics});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['suggested_topics'] != null) {
      suggestedTopics = <SuggestedTopics>[];
      json['suggested_topics'].forEach((v) {
        suggestedTopics.add(new SuggestedTopics.fromJson(v));
      });
    }
    if (json['following_topics'] != null) {
      followingTopics = <FollowingTopics>[];
      json['following_topics'].forEach((v) {
        followingTopics.add(new FollowingTopics.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.suggestedTopics != null) {
      data['suggested_topics'] =
          this.suggestedTopics.map((v) => v.toJson()).toList();
    }
    if (this.followingTopics != null) {
      data['following_topics'] =
          this.followingTopics.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SuggestedTopics {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  RxInt type = 0.obs;

  SuggestedTopics({this.id, this.topic, this.createdAt, this.updatedAt});

  SuggestedTopics.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}

class FollowingTopics {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  RxBool isFollow = false.obs;
  RxBool isHoverFollow = false.obs;

  FollowingTopics({this.id, this.topic, this.createdAt, this.updatedAt});

  FollowingTopics.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
