import 'package:get/get_rx/src/rx_types/rx_types.dart';

class NotInterestedTopic {
  String action;
  Meta meta;
  List<Data> data;

  NotInterestedTopic({this.action, this.meta, this.data});

  NotInterestedTopic.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  String topic;
  String createdAt;
  String updatedAt;
  int isFollowed;
  RxBool isFollow = true.obs;

  Data({this.id, this.topic, this.createdAt, this.updatedAt, this.isFollowed});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    topic = json['topic'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    isFollowed = json['is_followed'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['topic'] = this.topic;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['is_followed'] = this.isFollowed;
    return data;
  }
}
