// To parse this JSON data, do
//
//     final memberGetModel = memberGetModelFromJson(jsonString);

import 'dart:convert';

MemberGetModel memberGetModelFromJson(String str) =>
    MemberGetModel.fromJson(json.decode(str));

String memberGetModelToJson(MemberGetModel data) => json.encode(data.toJson());

class MemberGetModel {
  MemberGetModel({
    this.id,
    this.listId,
    this.memberFollowerId,
    this.type,
    this.firstname,
    this.profileImage,
    this.accountVerified,
    this.aboutMe,
    this.username,
  });

  int id;
  int listId;
  int memberFollowerId;
  String type;
  String firstname;
  dynamic profileImage;
  dynamic accountVerified;
  dynamic aboutMe;
  String username;
  bool isFollow = false;

  factory MemberGetModel.fromJson(Map<String, dynamic> json) => MemberGetModel(
        id: json["id"],
        listId: json["list_id"],
        memberFollowerId: json["member_follower_id"],
        type: json["type"],
        firstname: json["firstname"],
        profileImage: json["profile_image"],
        accountVerified: json["account_verified"],
        aboutMe: json["about_me"],
        username: json["username"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "list_id": listId,
        "member_follower_id": memberFollowerId,
        "type": type,
        "firstname": firstname,
        "profile_image": profileImage,
        "account_verified": accountVerified,
        "about_me": aboutMe,
        "username": username,
      };
}
