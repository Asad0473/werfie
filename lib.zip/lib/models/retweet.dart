// To parse this JSON data, do
//
//     final retweet = retweetFromJson(jsonString);

import 'dart:convert';

Retweet retweetFromJson(String str) => Retweet.fromJson(json.decode(str));

String retweetToJson(Retweet data) => json.encode(data.toJson());

class Retweet {
  Retweet({
    this.postId,
    this.userId,
    this.username,
    this.profileImage,
  });

  int postId;
  int userId;
  String username;
  dynamic profileImage;

  factory Retweet.fromJson(Map<String, dynamic> json) => Retweet(
        postId: json["post_id"],
        userId: json["user_id"],
        username: json["username"],
        profileImage: json["profile_image"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
        "user_id": userId,
        "username": username,
        "profile_image": profileImage,
      };
}
