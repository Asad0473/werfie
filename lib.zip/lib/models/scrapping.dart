class ScrappingData {
  String title;
  String meta;
  List<String> images;
  String link;

  ScrappingData({this.title, this.meta, this.images, this.link});

  ScrappingData.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    meta = json['meta'];
    images = json['images'].cast<String>();
    link = json['link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> scrappingData = new Map<String, dynamic>();
    scrappingData['title'] = this.title;
    scrappingData['meta'] = this.meta;
    scrappingData['images'] = this.images;
    scrappingData['link'] = this.link;
    return scrappingData;
  }
}

class ChatScrappingData {
  String title;
  String meta;
  List<String> images;
  String link;

  ChatScrappingData({this.title, this.meta, this.images, this.link});

  ChatScrappingData.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    meta = json['meta'];
    images = json['images'];
    link = json['link'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> ChatScrappingData = new Map<String, dynamic>();
    ChatScrappingData['title'] = this.title;
    ChatScrappingData['meta'] = this.meta;
    ChatScrappingData['images'] = this.images;
    ChatScrappingData['link'] = this.link;
    return ChatScrappingData;
  }
}
