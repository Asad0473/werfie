class ChatUserModel {
  ChatUserModel({
    this.conversationId,
    this.conversationType,
    this.name,
    this.groupImage,
    this.isMute,
    this.lastUpdated,
    this.unreadMessagesCount,
    this.latestMessage,
    this.latestMessageTime,
    this.latestMessageLanguageId,
    this.authorId,
    this.adminIds,
    this.members,
    this.user,
    this.messages,
    this.memberId,
    this.profileImage,
    this.dob,
    this.city,
    this.isBlocked,
    this.username,
    this.isOnline,
    this.singlePersonFollow,
    this.accountVerified,
    this.messageAllowed,
    this.participant_bio,
    this.participant_followers,
    this.latest_message_type,
    this.user_id,
  });

  int conversationId;
  String conversationType;
  String name;
  String groupImage;
  int isMute;
  DateTime lastUpdated;
  int unreadMessagesCount;
  String latestMessage;
  dynamic latestMessageTime;
  dynamic latestMessageLanguageId;
  dynamic messageAllowed;
  dynamic authorId;
  List<int> adminIds;
  List<Member> members;
  User user;
  bool isBlocked;
  List<dynamic> messages;
  int memberId;
  String profileImage;
  dynamic dob;
  dynamic city;
  String username;
  bool isOnline;
  bool singlePersonFollow;
  String accountVerified;
  String participant_bio;
  int participant_followers;
  int latest_message_type;
  int user_id;

  factory ChatUserModel.fromJson(Map<String, dynamic> json) => ChatUserModel(
    conversationId: json["conversation_id"],
    conversationType: json["conversation_type"],
    name: json["name"],
    isBlocked:
    json["message_allowed"] == null ? true : json["message_allowed"],
    groupImage: json["group_image"] == null ? null : json["group_image"],
    isMute: json["is_mute"],
    lastUpdated: json["last_updated"] == null ? null : DateTime.parse(json["last_updated"]),
    unreadMessagesCount: json["unread_messages_count"],
    latestMessage: json["orignal_latest_message"],
    latestMessageTime: json["latest_message_time"],
    latestMessageLanguageId: json["latest_message_language_id"],
    messageAllowed: json["message_allowed"],
    authorId: json["author_id"],
    adminIds: json["admin_ids"] == null
        ? null
        : List<int>.from(json["admin_ids"].map((x) => x)),
    members: json["members"] == null
        ? null
        : List<Member>.from(json["members"].map((x) => Member.fromJson(x))),
    user: json["user"] == null ? null : User.fromJson(json["user"]),
    messages: json["messages"] == null ? null : List<dynamic>.from(json["messages"].map((x) => x)),
    memberId: json["member_id"] == null ? null : json["member_id"],
    profileImage:
    json["profile_image"] == null ? null : json["profile_image"],
    dob: json["dob"],
    city: json["city"],
    username: json["username"] == null ? null : json["username"],
    isOnline: json["is_online"] == null ? null : json["is_online"],
    singlePersonFollow: json['follow'],
    accountVerified:
    json['account_verified'] == null ? null : json['account_verified'],
    participant_bio:
    json['participant_bio'] == null ? null : json['participant_bio'],
    participant_followers: json['participant_followers'] == null
        ? null
        : json['participant_followers'],
    latest_message_type: json['latest_message_type'] == null
        ? null
        : json['latest_message_type'],
    user_id: json['user_id'] == null ? null : json['user_id'],
  );

  Map<String, dynamic> toJson() => {
    "conversation_id": conversationId,
    "conversation_type": conversationType,
    "name": name,
    "group_image": groupImage == null ? null : groupImage,
    "is_mute": isMute,
    "last_updated": lastUpdated.toIso8601String(),
    "unread_messages_count": unreadMessagesCount,
    "latest_message": latestMessage,
    "latest_message_time": latestMessageTime,
    "latest_message_language_id": latestMessageLanguageId,
    "author_id": authorId,
    "message_allowed":messageAllowed,
    "admin_ids": adminIds == null
        ? null
        : List<dynamic>.from(adminIds.map((x) => x)),
    "members": members == null
        ? null
        : List<dynamic>.from(members.map((x) => x.toJson())),
    "user": user == null ? null : user.toJson(),
    "messages": List<dynamic>.from(messages.map((x) => x)),
    "member_id": memberId == null ? null : memberId,
    "profile_image": profileImage == null ? null : profileImage,
    "dob": dob,
    "city": city,
    "username": username == null ? null : username,
    "is_online": isOnline == null ? null : isOnline,
    "account_verified": accountVerified == null ? null : accountVerified,
    "follow": singlePersonFollow,
    "participant_bio": participant_bio,
    "participant_followers": participant_followers,
    "latest_message_type": latest_message_type,
    "user_id": user_id,
  };
}

class Member {
  Member({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.profileImage,
    this.isOnline,
    this.isAdmin,
    this.follow,
    this.reactionType,
  });

  int id;
  String firstname;
  String lastname;
  String username;
  String profileImage;
  bool isOnline;
  bool follow;
  bool isAdmin;
  String reactionType;

  factory Member.fromJson(Map<String, dynamic> json) => Member(
    id: json["id"],
    firstname: json["firstname"],
    lastname: json["lastname"],
    username: json["username"],
    profileImage:
    json["profile_image"] == null ? null : json["profile_image"],
    isOnline: json["is_online"],
    isAdmin: json["is_admin"],
    follow: json["follow"] == null ? null : json["follow"],
    reactionType: json["type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "firstname": firstname,
    "lastname": lastname,
    "username": username,
    "profile_image": profileImage == null ? null : profileImage,
    "is_online": isOnline,
    "is_admin": isAdmin,
  };
}

class User {
  User({
    this.firstname,
    this.lastname,
  });

  String firstname;
  String lastname;

  factory User.fromJson(Map<String, dynamic> json) => User(
    firstname: json["firstname"],
    lastname: json["lastname"],
  );

  Map<String, dynamic> toJson() => {
    "firstname": firstname,
    "lastname": lastname,
  };
}

