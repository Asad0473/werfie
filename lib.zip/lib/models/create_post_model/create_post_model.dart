import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../FileBytesModel.dart';

class ModelClass {
  String bodyText;

  // File files,
  List<String> fileName;
  List<Uint8List> imageWebBytes;
  String fileUrls;
  String filesInfo;
  String privacyType;
  String selectType = "Everyone";
  int postId;
  String link;
  String linkTitle;
  String linkMeta;
  String linkImage;
  String poll_ques_first = "";
  String poll_ques_second = "";
  String poll_ques_third = "";
  String poll_ques_fourth = "";
  String days;
  String hours;
  String minutes;
  bool isPoll;
  bool poolThread = false;
  String postType;
  List<Files> mediaData2;
  String location;
  String lat;
  String lng;
  bool isMediaAttached = false;
  bool isImageAttached = false;
  FocusNode focusNode;

  int postBodyLength = 0;

  FocusNode focusNode2;

  int replyId;
  String quoteId;
  String selectedType = "";
  int imageCounter = 0;
  List<TextEditingController> imageDescriptionController = List.generate(4, (i) => TextEditingController());

  // bool imageSave =
  int descriptionCounter = 0;
  int imagePickCount = 0;

  // int counter =0;
  List<FileBytesModel> listFiles = [];
  List<PlatformFile> listFilesMob = [];
  List<Uint8List> pickedVideos = [];
  Uint8List videoThumbnail;

  ModelClass({
    this.bodyText,
    // File files,
    this.fileName,
    this.imageWebBytes,
    this.fileUrls,
    this.filesInfo,
    this.privacyType,
    this.selectType,
    this.postId,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.poll_ques_first,
    this.poll_ques_second,
    this.poll_ques_third,
    this.poll_ques_fourth,
    this.days,
    this.hours,
    this.minutes,
    this.isPoll,
    this.postType,
    this.mediaData2,
    this.location,
    this.lat,
    this.lng,
    this.poolThread,
    this.focusNode,
    this.focusNode2,
    this.replyId,
    this.quoteId,
    this.selectedType,
    this.imageCounter,
    this.descriptionCounter,
    this.imageDescriptionController,
    this.imagePickCount = 0,
    //  this.listOfSchedulerPost
  });

  factory ModelClass.fromJson(Map<String, dynamic> json) => ModelClass(
        bodyText: json['body'],
        link: json['link'],
        linkTitle: json['link_title'],
        linkMeta: json['link_meta'],
        linkImage: json['link_image'],
        postType: json['type'],
        poll_ques_first: json['poll_ques_first'],
        poll_ques_second: json['poll_ques_second'],
        poll_ques_third: json['poll_ques_third'],
        poll_ques_fourth: json['poll_ques_fourth'],
        days: json['days'].toString(),
        minutes: json['minutes'].toString(),
        hours: json['hours'].toString(),
        mediaData2:
            List<Files>.from(json['files'].map((x) => Files.fromJson(x))),
        location: json['location'],
        lat: json['lat'],
        lng: json['lng'],
        postId: json['post_id'],
        poolThread: json['poll_thread'],
        replyId: json['reply_id'],
        quoteId: json["quote_id"],
        //  selectedType: json["public"]==null? json["mention_users"]==null?json["follow_followers"]==null?json["public"],
      );

  Map<String, dynamic> toJson() => {
        'post_id': postId,
        'body': bodyText,
        'link': link,
        'link_title': linkTitle,
        'link_meta': linkMeta,
        'link_image': linkImage,
        'type': postType,
        'poll_ques_first': poll_ques_first ?? '',
        'poll_ques_second': poll_ques_second ?? '',
        'poll_ques_third': poll_ques_third ?? '',
        'poll_ques_fourth': poll_ques_fourth ?? '',
        'days': days,
        'minutes': minutes,
        'hours': hours,
        'files': List<dynamic>.from(mediaData2.map((x) => x.toJson())),
        'location': location ?? '',
        'lat': lat.toString() ?? '',
        'lng': lng.toString() ?? '',
        'poll_thread': poolThread,
        'reply_id': replyId,
        "quote_id": quoteId,
        "privacy_type": selectedType,

        //  "list_of_scheduler_post":List<dynamic>.from(listOfSchedulerPost.map((x) => x))
      };
}

class Files {
  String url;
  String thumbnailUrl;
  String name;
  String mentionUserId;
  int size;
  List<MentionUserList> mentionUserList;
  String description;
  String fileType;

  Files({
    this.url,
    this.thumbnailUrl,
    this.name,
    this.mentionUserId,
    this.mentionUserList,
    this.size,
    this.description,
    this.fileType,
  });

  factory Files.fromJson(Map<String, dynamic> json) => Files(
        url: json['url'],
        thumbnailUrl: json['thumbnail_url'],
        name: json['name'],
        mentionUserId:
            json['mention_user_ids'] == null ? "" : json['mention_user_ids'],
        size: json['size'],
        mentionUserList: json['mention_users'] == null
            ? []
            : List<MentionUserList>.from(
                json['mention_users'].map((x) => Files.fromJson(x))),
        description: json['description'] == null ? "" : json['description'],
        fileType: json['video'] == null ? "" : json['video'],
      );

  Map<String, dynamic> toJson() => {
        'url': url,
        'thumbnail_url': thumbnailUrl,
        'name': name,
        'mention_user_ids': mentionUserId,
        'mention_users':
            List<dynamic>.from(mentionUserList.map((x) => x.toJson())),
        'size': size,
        "description": description,
        "file_type": fileType
      };
}

class MentionUserList {
  MentionUserList({
    this.id,
    this.username,
    this.firstname,
    this.profileImage,
    this.accountVerified,
  });

  int id;
  String username;
  String firstname;
  String profileImage;
  dynamic accountVerified;

  factory MentionUserList.fromJson(Map<String, dynamic> json) =>
      MentionUserList(
        id: json["id"],
        username: json["username"],
        firstname: json["firstname"],
        profileImage: json["profile_image"],
        accountVerified: json["account_verified"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "username": username,
        "firstname": firstname,
        "profile_image": profileImage,
        "account_verified": accountVerified,
      };
}
