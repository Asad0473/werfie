// class LanguageModel {
//   LanguageModel({
//     this.data,
//   });
//
//   Data data;
//
//   factory LanguageModel.fromJson(Map<String, dynamic> json) => LanguageModel(
//     data: Data.fromJson(json["data"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "data": data.toJson(),
//   };
// }



class LanguageModel {
  LanguageModel({
    this.myLang,
    this.appLang,
    // this.appLanguageInfo,
    this.autoTranslateSettings,
    this.allLangs, this.pinnedLists,
  });

  Lang myLang;
  Lang appLang;

  // AppLanguageInfo appLanguageInfo;
  AutoTranslateSettings autoTranslateSettings;
  List<Lang> allLangs;
  List<PinnedLists> pinnedLists;

  factory LanguageModel.fromJson(Map<String, dynamic> json) => LanguageModel(
        myLang: Lang.fromJson(json["my_lang"]),
        appLang: Lang.fromJson(json["app_lang"]),
        // appLanguageInfo: AppLanguageInfo.fromJson(json["app_language_info"]),
        autoTranslateSettings:
            AutoTranslateSettings.fromJson(json["auto_translate_settings"]),
        allLangs:
            List<Lang>.from(json["all_langs"].map((x) => Lang.fromJson(x))),
      pinnedLists:List<PinnedLists>.from(json["pinned_lists"].map((x) => PinnedLists.fromJson(x)))
      );

  Map<String, dynamic> toJson() => {
        "my_lang": myLang.toJson(),
        "app_lang": appLang.toJson(),
        // "app_language_info": appLanguageInfo.toJson(),
        "auto_translate_settings": autoTranslateSettings.toJson(),
        "all_langs": List<dynamic>.from(allLangs.map((x) => x.toJson())),
      };
}


class PinnedLists {
  int id;
  int userId;
  String name;
  String description;
  String coverImage;
  String makePrivate;
  String authorName;
  String authorProfileImage;
  String accountVerified;
  String username;
  int isPinned;

  PinnedLists(
      {this.id,
        this.userId,
        this.name,
        this.description,
        this.coverImage,
        this.makePrivate,
        this.authorName,
        this.authorProfileImage,
        this.accountVerified,
        this.username,
        this.isPinned});

  PinnedLists.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    name = json['name'] ?? "Name";
    description = json['description'] ?? "";
    coverImage = json['cover_image'] ?? "";
    makePrivate = json['make_private'];
    authorName = json['author_name'] ?? "";
    authorProfileImage = json['author_profile_image'] ?? "";
    accountVerified = json['account_verified'];
    username = json['username'] ?? "";
    isPinned = json['is_pinned'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['description'] = this.description;
    data['cover_image'] = this.coverImage;
    data['make_private'] = this.makePrivate;
    data['author_name'] = this.authorName;
    data['author_profile_image'] = this.authorProfileImage;
    data['account_verified'] = this.accountVerified;
    data['username'] = this.username;
    data['is_pinned'] = this.isPinned;
    return data;
  }
}

class Lang {
  Lang({
    this.id,
    this.name,
    // this.flagPath,
    this.code,
    this.pivot,
  });

  int id;
  String name;

  // FlagPath flagPath;
  String code;
  Pivot pivot;

  factory Lang.fromJson(Map<String, dynamic> json) => Lang(
        id: json["id"],
        name: json["name"],
        // flagPath: flagPathValues.map[json["flag_path"]],
        code: json["code"],
        pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
      );

  factory Lang.fromLocalDbJson(Map<String, dynamic> json) => Lang(
        id: json["id"],
        name: json["name"],
        // flagPath: flagPathValues.map[json["flag_path"]],
        code: json["code"],
        // pivot: json["pivot"] == null ? null : Pivot.fromJson(jsonDecode(json["pivot"])),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        // "flag_path": flagPathValues.reverse[flagPath],
        "code": code,
        "pivot": pivot == null ? null : pivot.toJson(),
      };

  Map<String, dynamic> toLocalDBMap() => {
        "id": id,
        "name": name,
        // "flag_path": flagPathValues.reverse[flagPath],
        "code": code,
        "pivot": pivot == null ? null : pivot.toJson().toString(),
      };
}

// enum FlagPath { IMAGES_UK_SVG }

// final flagPathValues = EnumValues({
//   "/images/uk.svg": FlagPath.IMAGES_UK_SVG
// });

class Pivot {
  Pivot({
    this.userId,
    this.appLanguageId,
    this.languageId,
  });

  int userId;
  int appLanguageId;
  int languageId;

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
        userId: json["user_id"],
        appLanguageId:
            json["app_language_id"] == null ? null : json["app_language_id"],
        languageId: json["language_id"] == null ? null : json["language_id"],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "app_language_id": appLanguageId == null ? null : appLanguageId,
        "language_id": languageId == null ? null : languageId,
      };
}

class AppLanguageInfo {
  AppLanguageInfo({
    this.language,
    this.languageCode,
    this.id,
  });

  String language;
  String languageCode;
  String id;

  factory AppLanguageInfo.fromJson(Map<String, dynamic> json) =>
      AppLanguageInfo(
        language: json["language"],
        languageCode: json["languageCode"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "language": language,
        "languageCode": languageCode,
        "id": id,
      };
}

class AutoTranslateSettings {
  AutoTranslateSettings({
    this.id,
    this.userId,
    this.autoTranslate,
    this.dobPrivacy,
    this.createdAt,
    this.updatedAt,
  });

  int id;
  int userId;
  int autoTranslate;
  String dobPrivacy;
  DateTime createdAt;
  DateTime updatedAt;

  factory AutoTranslateSettings.fromJson(Map<String, dynamic> json) =>
      AutoTranslateSettings(
        id: json["id"],
        userId: json["user_id"],
        autoTranslate: json["auto_translate"],
        dobPrivacy: json["dob_privacy"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "auto_translate": autoTranslate,
        "dob_privacy": dobPrivacy,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };
}

// class EnumValues<T> {
//   Map<String, T> map;
//   Map<T, String> reverseMap;
//
//   EnumValues(this.map);
//
//   Map<T, String> get reverse {
//     if (reverseMap == null) {
//       reverseMap = map.map((k, v) => new MapEntry(v, k));
//     }
//     return reverseMap;
//   }
// }

// class LanguageModel {
//   LanguageModel({
//     this.myLang,
//     this.allLangs,
//     this.autoTranslateSettings,
//     // this.appLanguageSettings,
//     this.appLanguageInfo
//   });
//
//   Lang myLang;
//   List<Lang> allLangs;
//   AutoTranslateSettings autoTranslateSettings;
//   // Lang appLanguageSettings;
//   AppLanguageInfo appLanguageInfo;
//
//   factory LanguageModel.fromJson(Map<String, dynamic> json) => LanguageModel(
//     myLang: Lang.fromJson(json["my_lang"]),
//     allLangs: List<Lang>.from(json["all_langs"].map((x) => Lang.fromJson(x))),
//     autoTranslateSettings: AutoTranslateSettings.fromJson(json["auto_translate_settings"]),
//     // appLanguageSettings: Lang.fromJson(json["app_lang"]),
//     appLanguageInfo: AppLanguageInfo.fromJson(json["app_language_info"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "my_lang": myLang.toJson(),
//     "all_langs": List<dynamic>.from(allLangs.map((x) => x.toJson())),
//     "auto_translate_settings": autoTranslateSettings.toJson(),
//   };
// }
//
// class Lang {
//   Lang({
//     this.id,
//     this.name,
//     this.flagPath,
//     this.code,
//     this.pivot,
//   });
//
//   int id;
//   String name;
//   String flagPath;
//   String code;
//   Pivot pivot;
//
//   factory Lang.fromJson(Map<String, dynamic> json) => Lang(
//     id: json["id"],
//     name: json["name"],
//     flagPath: json["flag_path"],
//     code: json["code"],
//     pivot: json["pivot"] == null ? null : Pivot.fromJson(json["pivot"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "name": name,
//     "flag_path": flagPath,
//     "code": code,
//     "pivot": pivot == null ? null : pivot.toJson(),
//   };
// }
//
// enum FlagPath { IMAGES_UK_SVG }
//
// // final flagPathValues = EnumValues({
// //   "/images/uk.svg": FlagPath.IMAGES_UK_SVG
// // });
//
// class Pivot {
//   Pivot({
//     this.userId,
//     this.languageId,
//   });
//
//   int userId;
//   int languageId;
//
//   factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
//     userId: json["user_id"],
//     languageId: json["language_id"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "user_id": userId,
//     "language_id": languageId,
//   };
// }
//
// class AutoTranslateSettings {
//   AutoTranslateSettings({
//     this.id,
//     this.userId,
//     this.autoTranslate,
//     this.dobPrivacy,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   int id;
//   int userId;
//   int autoTranslate;
//   String dobPrivacy;
//   DateTime createdAt;
//   DateTime updatedAt;
//
//   factory AutoTranslateSettings.fromJson(Map<String, dynamic> json) => AutoTranslateSettings(
//     id: json["id"],
//     userId: json["user_id"],
//     autoTranslate: json["auto_translate"],
//     dobPrivacy: json["dob_privacy"],
//     createdAt: DateTime.parse(json["created_at"]),
//     updatedAt: DateTime.parse(json["updated_at"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "user_id": userId,
//     "auto_translate": autoTranslate,
//     "dob_privacy": dobPrivacy,
//     "created_at": createdAt.toIso8601String(),
//     "updated_at": updatedAt.toIso8601String(),
//   };
// }
// class AppLanguageInfo {
//   AppLanguageInfo({
//     this.id,this.language,this.languageCode
//   });
//
//   String id;
//   String language;
//   String languageCode;
//
//   factory AppLanguageInfo.fromJson(Map<String, dynamic> json) => AppLanguageInfo(
//     id: json["id"],
//     language: json["language"],
//     languageCode: json["languageCode"],
//   );
//
//   // Map<String, dynamic> toJson() => {
//   //   "id": id,
//   //   "user_id": userId,
//   //   "auto_translate": autoTranslate,
//   //   "dob_privacy": dobPrivacy,
//   //   "created_at": createdAt.toIso8601String(),
//   //   "updated_at": updatedAt.toIso8601String(),
//   // };
// }
//
//
// // class EnumValues<T> {
// //   Map<String, T> map;
// //   Map<T, String> reverseMap;
// //
// //   EnumValues(this.map);
// //
// //   Map<T, String> get reverse {
// //     if (reverseMap == null) {
// //       reverseMap = map.map((k, v) => new MapEntry(v, k));
// //     }
// //     return reverseMap;
// //   }
// // }
