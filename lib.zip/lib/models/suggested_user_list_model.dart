// To parse this JSON data, do
//
//     final suggesteduserListModel = suggesteduserListModelFromJson(jsonString);

import 'dart:convert';

SuggesteduserListModel suggesteduserListModelFromJson(String str) =>
    SuggesteduserListModel.fromJson(json.decode(str));

String suggesteduserListModelToJson(SuggesteduserListModel data) =>
    json.encode(data.toJson());

class SuggesteduserListModel {
  SuggesteduserListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  List<SuggestUser> data;

  factory SuggesteduserListModel.fromJson(Map<String, dynamic> json) =>
      SuggesteduserListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: json["data"] == null || json["data"] == {}
            ? []
            : List<SuggestUser>.from(
                json["data"].map((x) => SuggestUser.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class SuggestUser {
  SuggestUser({
    this.id,
    this.authorName,
    this.authorProfileImage,
    this.username,
    this.bio,
  });

  int id;
  String authorName;
  String authorProfileImage;
  String username;
  String bio;
  bool isFollow = false;

  factory SuggestUser.fromJson(Map<String, dynamic> json) => SuggestUser(
        id: json["id"],
        authorName: json["author_name"],
        authorProfileImage: json["author_profile_image"] == null
            ? null
            : json["author_profile_image"],
        username: json["username"],
        bio: json["bio"] == null ? null : json["bio"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "author_name": authorName,
        "author_profile_image":
            authorProfileImage == null ? null : authorProfileImage,
        "username": username,
        "bio": bio == null ? null : bio,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
