class TrendsModel {
  TrendsModel({
    this.trends,
    this.region,
  });

  List<Trend> trends = [];
  String region;

  factory TrendsModel.fromJson(Map<String, dynamic> json) => TrendsModel(
        trends: json["hot_trends"] == null
            ? []
            : List<Trend>.from(
                json["hot_trends"].map((x) => Trend.fromJson(x))),
        region: json["region"] == null ? null : json["region"],
      );

  Map<String, dynamic> toJson() => {
        "trends": List<dynamic>.from(trends.map((x) => x.toJson())),
        "region": region,
      };
}

class Trend {
  Trend({
    this.postId,
    this.tagId,
    this.title,
    this.region,
    this.createdAt,
    this.trendingCount,
  });

  int postId;
  int tagId;
  String title;
  String region;
  DateTime createdAt;
  int trendingCount;

  factory Trend.fromJson(Map<String, dynamic> json) => Trend(
        postId: json["post_id"],
        tagId: json["tag_id"],
        title: json["title"],
        region: json["region"],
        createdAt: DateTime.parse(json["created_at"]),
        trendingCount: json["trending_count"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
        "tag_id": tagId,
        "title": title,
        "region": region,
        "created_at": createdAt.toIso8601String(),
        "trending_count": trendingCount,
      };
}
