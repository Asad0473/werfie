// // To parse this JSON data, do
// //
// //     final Notifications = NotificationsFromJson(jsonString);
//
import 'dart:convert';

Notifications notificationsFromJson(String str) =>
    Notifications.fromJson(json.decode(str));

String notificationsToJson(Notifications data) => json.encode(data.toJson());

class Notifications {
  Notifications({
    this.id,
    this.senderName,
    this.userId,
    this.onUser,
    this.text,
    this.type,
    this.isRead,
    this.postId,
    this.commentId,
    this.rePostId,
    this.createdAt,
    this.updatedAt,
    this.profileImage,
  });

  int id;
  String senderName;
  int userId;
  int onUser;
  String text;
  String type;
  int isRead;
  int postId;
  dynamic commentId;
  dynamic rePostId;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic profileImage;

  factory Notifications.fromJson(Map<String, dynamic> json) => Notifications(
        id: json["id"],
        senderName: json["sender_name"],
        userId: json["user_id"],
        onUser: json["on_user"],
        text: json["text"],
        type: json["type"],
        isRead: json["is_read"],
        postId: json["post_id"],
        commentId: json["comment_id"],
        rePostId: json["re_post_id"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        profileImage: json["profile_image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "sender_name": senderName,
        "user_id": userId,
        "on_user": onUser,
        "text": text,
        "type": type,
        "is_read": isRead,
        "post_id": postId,
        "comment_id": commentId,
        "re_post_id": rePostId,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "profile_image": profileImage,
      };
}
