class HashtagDetailsResponseModel {
  String action;
  Meta meta;
  Data data;

  HashtagDetailsResponseModel({this.action, this.meta, this.data});

  HashtagDetailsResponseModel.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  String title;
  int usedCount;
  String createdAt;
  String updatedAt;
  int countryId;
  String regionName;
  String cityName;
  String zipCode;
  int postCount;
  String country;
  int contributers;

  Data(
      {this.id,
        this.title,
        this.usedCount,
        this.countryId,
        this.regionName,
        this.cityName,
        this.zipCode,
        this.postCount,
        this.createdAt,
        this.updatedAt,
        this.country,
        this.contributers,});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    usedCount = json['used_count'];
    countryId = json['country_id'];
    regionName = json['region_name'];
    cityName = json['city_name'];
    zipCode = json['zip_code'];
    postCount = json['post_count'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    country = json['country'];
    contributers = json['contributers'];

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['title'] = this.title;
    data['used_count'] = this.usedCount;
    data['country_id'] = this.countryId;
    data['region_name'] = this.regionName;
    data['city_name'] = this.cityName;
    data['zip_code'] = this.zipCode;
    data['post_count'] = this.postCount;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    data['country'] = this.country;
    data['contributers'] = this.contributers;
    return data;
  }
}