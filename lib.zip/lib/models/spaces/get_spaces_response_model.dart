class GetSpacesResponseModel {
  String action;
  Meta meta;
  List<Data> data;

  GetSpacesResponseModel({this.action, this.meta, this.data});

  GetSpacesResponseModel.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null?  new Meta.fromJson(json['meta']) : null;
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data.add(new Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  int userId;
  String name;
  String type;
  String startTime;
  String endTime;
  String topicIds;
  String createdAt;
  String updatedAt;

  Data(
      {this.id,
        this.userId,
        this.name,
        this.type,
        this.startTime,
        this.endTime,
        this.topicIds,
        this.createdAt,
        this.updatedAt});

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    userId = json['user_id'];
    name = json['name'];
    type = json['type'];
    startTime = json['start_time'];
    endTime = json['end_time']??null;
    topicIds = json['topic_ids'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['name'] = this.name;
    data['type'] = this.type;
    data['start_time'] = this.startTime;
    data['end_time'] = this.endTime;
    data['topic_ids'] = this.topicIds;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}
