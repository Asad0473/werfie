// To parse this JSON data, do
//
//     final viewEditHistory = viewEditHistoryFromJson(jsonString);

import 'dart:convert';

import 'package:meta/meta.dart';

ViewEditHistory viewEditHistoryFromJson(String str) =>
    ViewEditHistory.fromJson(json.decode(str));

String viewEditHistoryToJson(ViewEditHistory data) =>
    json.encode(data.toJson());

class ViewEditHistory {
  ViewEditHistory({
    @required this.action,
    @required this.meta,
    @required this.data,
  });

  String action;
  Meta meta;
  List<Datum> data;

  factory ViewEditHistory.fromJson(Map<String, dynamic> json) =>
      ViewEditHistory(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": List<dynamic>.from(data.map((x) => x.toJson())),
      };
}

class Datum {
  Datum({
    @required this.id,
    @required this.postId,
    @required this.description,
    @required this.createdAt,
    @required this.updatedAt,
  });

  int id;
  int postId;
  String description;
  DateTime createdAt;
  DateTime updatedAt;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        id: json["id"],
        postId: json["post_id"],
        description: json["description"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "post_id": postId,
        "description": description,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
      };
}

class Meta {
  Meta({
    @required this.code,
    @required this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
