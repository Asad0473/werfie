// To parse this JSON data, do
//
//     final socketLike = socketLikeFromJson(jsonString);

import 'dart:convert';

SocketLike socketLikeFromJson(String str) =>
    SocketLike.fromJson(json.decode(str));

String socketLikeToJson(SocketLike data) => json.encode(data.toJson());

class SocketLike {
  SocketLike({
    this.userId,
    this.postId,
    this.type,
    this.slug,
  });

  int userId;
  int postId;
  String type;
  Slug slug;

  factory SocketLike.fromJson(Map<String, dynamic> json) => SocketLike(
        userId: json["user_id"],
        postId: json["post_id"],
        type: json["type"],
        slug: Slug.fromJson(json["slug"]),
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "post_id": postId,
        "type": type,
        "slug": slug.toJson(),
      };
}

class Slug {
  Slug({
    this.isLikedSocket,
    this.totalLikes,
  });

  bool isLikedSocket;
  int totalLikes;

  factory Slug.fromJson(Map<String, dynamic> json) => Slug(
        isLikedSocket: json["isLikedSocket"],
        totalLikes: json["totalLikes"],
      );

  Map<String, dynamic> toJson() => {
        "isLikedSocket": isLikedSocket,
        "totalLikes": totalLikes,
      };
}
