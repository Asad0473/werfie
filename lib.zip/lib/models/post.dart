// class // To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

import 'package:flutter_tts/flutter_tts.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/models/translationData_model.dart';
import 'package:werfieapp/models/trends_model.dart';

Post welcomeFromJson(String str) => Post.fromJson(json.decode(str));

// String welcomeToJson(Post data) => json.encode(data.toJson());

class Post {
  Post({
    this.postId,
    this.authorName,
    this.profileImage,
    this.username,
    this.authorId,
    this.postedOn,
    this.postType,
    this.postTypeColorCode,
    this.body,
    this.location,
    this.simpleLikeCount,
    this.simpleDislikeCount,
    this.commentsCount,
    this.sharesCount,
    this.postFiles,
    this.postedTimeAgo,
    //  this.comments,
    this.isLiked,
    this.isDisliked,
    this.savedItemId,
    this.isRetweeted,
    this.languageId,
    this.retweetCount,
    this.link,
    this.linkTitle,
    this.linkImage,
    this.linkMeta,
    this.pollQuestionOne,
    this.pollQuestionTwo,
    this.pollQuestionFour,
    this.pollQuestionThree,
    this.pollExpires,
    this.pollInfo,
    this.trending,
    this.type,
    this.saved,
    this.quoteId,
    this.quoteInfo,
    this.followingLikes,
    this.followingRetweets,
    this.userInfo,
    this.lng,
    this.lat,
    this.pinPost,
    this.canEdit,
    this.thread_no,
    this.mute,
    this.saveCreateAt,
    this.postViews,
    this.languageDirection,
    this.numLines,
  });

  int postId;
  bool undoRewerf = false;
  String authorName;
  String profileImage;
  int savedItemId;
  String username;
  int authorId;
  DateTime postedOn;
  DateTime saveCreateAt;
  String postType;
  String postTypeColorCode;
  String body;
  int languageId;
  String location;
  int simpleLikeCount;
  int simpleDislikeCount;
  int commentsCount;
  RxInt commentCount = 0.obs;
  int retweetCount;
  int sharesCount;
  List<dynamic> postFiles = [];
  String postedTimeAgo;

//  List<Comment> comments;
  String isLiked;
  bool isDisliked;
  bool isRetweeted;
  RxBool like = false.obs;
  RxBool checkValue = false.obs;
  RxBool rebuzz = false.obs;
  RxInt likeCount = 0.obs;
  RxInt rebuzzCount = 0.obs;
  RxInt threadNumber = 0.obs;
  RxBool isComment = false.obs;
  FlutterTts tts;
  bool isPlay = false;
  bool saved = false;
  UserProfile userInfo;
  String lng;
  String lat;
  int pinPost;
  bool canEdit;
  int thread_no;
  String link;
  String linkTitle;
  String linkMeta;
  String linkImage;
  String pollQuestionOne;
  String pollQuestionTwo;
  String pollQuestionThree;
  String pollQuestionFour;
  String pollExpires;
  String type;
  int quoteId;
  TrendsModel trending;
  QuoteWerf quoteInfo;
  List<dynamic> followingLikes = [];
  List<dynamic> followingRetweets = [];
  bool mute;
  var pollInfo;
  RxBool reactionCheck = false.obs;
  RxBool showDialouge=false.obs;
  RxBool showDialougeUnderPic=false.obs;
  RxBool showDialougeUnderName=false.obs;
  RxBool showDialougeUnderUserName=false.obs;
  RxString reactionType = "".obs;

  RxBool translation = false.obs;
  TranslationData translationData;
  bool translationLoader = false;

  RxBool translationLoadere = false.obs;

  String languageDirection;

  int numLines = 0;
  int postViews;

  // SocketLike socketLike;

/*
  Post.fromJson(Map<String, dynamic> json) {
    authorName = json['author_name'];
    authorId = json['author_id'];
    retweetCount = json['retweet_count'];
    link = json['link'];
    pollQuestionOne = json['poll_ques_first'];
    //quoteInfo = json['quote_info'];
    pollQuestionFour = json['poll_ques_fourth'];
    postType = json['post_type'];
    languageId = json['language_id'];
    pollInfo = json['poll_info'];
    pollQuestionThree = json['poll_ques_third'];
    postId = json['post_id'];
    thread_no = json['thread_no'];
    languageDirection = json['language_direction'];
    quoteId = json['quote_id'];
    type = json['type'];
    linkMeta = json['link_meta'];
    linkImage = json['link_image'];
    lat = json['lat'];
    body = json['body'];
    username = json['username'];
    pollExpires = json['poll_expires'];
    pollQuestionTwo = json['poll_ques_second'];
    body = json['original_body'];
    location = json['location'];
    lng = json['lng'];
    saved = json['saved'] == "true" ? true : false ;
    postedOn = DateTime.parse('2024-01-01 11:03:31');
    simpleLikeCount = json['simple_like_count'];
    profileImage = json['profile_image'];
    postViews = json['post_views'] ?? 0;
    linkTitle = json['link_title'];
    canEdit = json['can_edit'];
    isLiked = json['isLiked'].toString();
    //trending = json['trending'];
    commentsCount = json['comments_count'];

  }
*/

  factory Post.fromJson(Map<String, dynamic> json) => Post(
        userInfo: UserProfile.fromJson(json['author_basic_info']),
        postId: json["post_id"],
        authorName: json["author_name"],
        savedItemId:
            json["saved_item_id"] == null ? null : json["saved_item_id"],
        profileImage:
            json["profile_image"] == null ? null : json["profile_image"],
        username: json["username"],
        authorId: json["author_id"],
        postedOn: DateTime.parse(json["posted_on"]),
        postType: json["post_type"],
        postTypeColorCode: json["post_type_color_code"],
        // location: json["location"],
        body: json["body"] ?? "",
        languageId: json["language_id"],

        simpleLikeCount: json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"],
        commentsCount: json["comments_count"],
        sharesCount: json["shares_count"],
        postFiles: List<dynamic>.from(json["post_files"].map((x) => x)),
        postedTimeAgo: json["posted_time_ago"],
        //  comments: (json["comments"] as List)?.map((e) => Comment.fromJson(e))?.toList(),
        isLiked: json["isLiked"],
        isDisliked: json["isDisliked"],
        isRetweeted: json['you_retweet'],
        retweetCount: json['retweet_count'],
        link: json['link'],
        linkTitle: json['link_title'],
        linkMeta: json['link_meta'],
        linkImage: json['link_image'],
        pollQuestionOne: json['poll_ques_first'] ?? "",
        pollQuestionTwo: json['poll_ques_second'] ?? "",
        pollQuestionThree: json['poll_ques_third'] ?? "",
        pollQuestionFour: json['poll_ques_fourth'] ?? "",
        pollExpires: json['poll_expires'],
        pollInfo: json['poll_info'],
        type: json['type'],
        quoteId: json['quote_id'],
        quoteInfo: json["quote_info"] == null
            ? null
            : QuoteWerf.fromJson(json["quote_info"]),
        trending: json["trending"] == null
            ? null
            : TrendsModel.fromJson(json["trending"]),
        saved: json['saved'],
        saveCreateAt: json["saved_created_at"] == null
            ? null
            : DateTime.parse(json["saved_created_at"]),
        followingLikes: json['following_likes'] ?? [],
        followingRetweets: json['following_retweets'] ?? [],
        location: json["location"],
        lat: json["lat"],
        lng: json["lng"],
        pinPost: json["pin_post"],
        canEdit: json["can_edit"],
        thread_no: json["thread_no"] == null ? null : json["thread_no"],

        mute: json['is_muted'] ?? false,
        postViews: json['post_views'] ?? 0,
        languageDirection: json["language_direction"],
      );

  factory Post.fromLocalDbJson(Map<String, dynamic> json) => Post(
        postId: json["post_id"],
        authorName: json["author_name"],
        savedItemId:
            json["saved_item_id"] == null ? null : json["saved_item_id"],
        profileImage: json["profile_image"],
        username: json["username"],
        authorId: json["author_id"],
        postedOn: DateTime.parse(json["posted_on"]),
        postType: json["post_type"],
        postTypeColorCode: json["post_type_color_code"],
        // location: json["location"],
        body: json["body"],
        languageId: json["language_id"],
        simpleLikeCount: json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"],
        //     commentsCount: json["comments_count"],
        sharesCount: json["shares_count"],
        postFiles: json["post_files"] == null
            ? []
            : List<dynamic>.from(jsonDecode(json["post_files"]).map((x) => x)),
        postedTimeAgo: json["posted_time_ago"],
        // comments:
        //     (jsonDecode(json["comments"]) as List)?.map((e) => Comment.fromJson(e))?.toList(),
        isLiked: json["isLiked"],
        isDisliked: json["isDisliked"] == 0 ? false : true,
        isRetweeted: json['you_retweet'] == 0 ? false : true,
        retweetCount: json['retweet_count'],
        link: json['link'],
        linkTitle: json['link_title'],
        linkMeta: json['link_meta'],
        linkImage: json['link_image'],
        pollQuestionOne: json['poll_ques_first'],
        pollQuestionTwo: json['poll_ques_second'],
        pollQuestionThree: json['poll_ques_third'],
        pollQuestionFour: json['poll_ques_fourth'],
        pollExpires: json['poll_expires'],
        pollInfo: json['poll_info'],
        type: json['type'],
        trending: json["trending"] == null
            ? null
            : TrendsModel.fromJson(json["trending"]),
        saved: json['saved'],
        followingLikes: jsonDecode(json['following_likes']) ?? [],
        followingRetweets: jsonDecode(json['following_retweets']) ?? [],
        quoteInfo: jsonDecode(json["quote_info"]) == null
            ? null
            : QuoteWerf.fromJson(jsonDecode(json["quote_info"])),

        location: json["location"] == null ? null : json["location"],
        // languageDirection: json["language_direction"],
        // lat: json["lat"]== null ? null : json["lat"],
        // lng: json["lng"]== null ? null : json["lng"],
        // pinPost: json["pin_post"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
    'author_basic_info':userInfo,
        "author_name": authorName,
        "profile_image": profileImage,
        "username": username,
        "author_id": authorId,
        "posted_on": postedOn,
        "post_type": postType,
        "post_type_color_code": postTypeColorCode,
        "body": body,
        // "location": location,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "comments_count": commentsCount,
        "shares_count": sharesCount,
        if (postFiles != null)
          "post_files": List<dynamic>.from(postFiles.map((x) => x)),
        "posted_time_ago": postedTimeAgo,
        // if (comments != null)
        //   "comments": List<dynamic>.from(comments.map((x) => x)),
        "isLiked": isLiked,
        'saved': saved,
        "isDisliked": isDisliked,
        'you_retweet': isRetweeted,
        'retweet_count': retweetCount,
        "saved_created_at": saveCreateAt,
        "location": location,
        "lat": lat,
        "lng": lng,
        "pin_post": pinPost,
        "can_edit": canEdit,
        "thread_no": thread_no,
        'is_muted': mute,
        'post_views': postViews,
        "language_direction": languageDirection
      };

  Map<String, dynamic> toLocalDBMap() => {
        "post_id": postId,
        "author_name": authorName,
        "profile_image": profileImage,
        "username": username,
        "author_id": authorId,
        "posted_on": postedOn.toString(),
        "post_type": postType,
        "post_type_color_code": postTypeColorCode,
        "body": body,
        // "location": location,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "comments_count": commentsCount,
        "shares_count": sharesCount,
        if (postFiles != null)
          "post_files": List<dynamic>.from(postFiles.map((x) => jsonEncode(x)))
              .toString(),
        "posted_time_ago": postedTimeAgo,
        // if (comments != null)
        //   "comments":
        //       List<dynamic>.from(comments.map((x) => jsonEncode(x))).toString(),
        "isLiked": isLiked,
        //1 true , 0 false
        "isDisliked": isDisliked == null
            ? 0
            : isDisliked
                ? 1
                : 0,
        'you_retweet': isRetweeted == null
            ? 0
            : isRetweeted
                ? 1
                : 0,
        'retweet_count': retweetCount,
        'following_likes': followingLikes.toString(),
        'following_retweets': followingRetweets.toString(),
        'quote_info': jsonEncode(quoteInfo).toString(),
        "location": location,
        // "language_direction":languageDirection
        // "lat" :lat,
        // "lng":lng,
        // "pin_post": pinPost,
      };

  RxList<Comment> setCommentsList(List<dynamic> list) {
    RxList<Comment> _list = <Comment>[].obs;
    list.forEach((element) {
      _list.add(element);
      _list.refresh();
    });
    return _list;
  }
}

class Comment {
  Comment({
    this.id,
    this.body,
    this.userId,
    this.postTypeId,
    this.postId,
    this.status,
    this.processingStatus,
    this.simpleLikeCount,
    this.simpleDislikeCount,
    this.inReplyToId,
    this.repliesCount,
    this.audioFileUrl,
    this.audioPath,
    this.speechToText,
    this.languageId,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.createdAt,
    this.updatedAt,
    this.replies,
    this.isLiked,
    // this.listenCommentUrl,
    this.commentedTimeAgo,
    this.author,
  });

  int id;
  String body;
  String userId;
  dynamic postTypeId;
  dynamic postId;
  String status;
  String processingStatus;
  int simpleLikeCount;
  int simpleDislikeCount;
  int inReplyToId;
  int repliesCount;
  dynamic audioFileUrl;
  dynamic audioPath;
  dynamic speechToText;
  int languageId;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  String createdAt;
  String updatedAt;
  List<Comment> replies;
  RxBool replyMentionTag = false.obs;

  // String listenCommentUrl;
  String commentedTimeAgo;
  Author author;
  String isLiked;
  RxBool isReply = false.obs;
  bool isTTSPlayingComments = false;
  FlutterTts tts;
  RxString reactionType = "".obs;
  RxBool reactionCheck = false.obs;
  RxInt commentCount = 0.obs;

  factory Comment.fromJson(Map<String, dynamic> json) => Comment(
        id: json["id"] == null ? null : json["id"],
        body: json["body"] == null ? "" : json["body"].toString(),
        userId: json["user_id"] == null ? "" : json["user_id"].toString(),
        postTypeId: json["post_type_id"] == null ? null : json["post_type_id"],
        postId: json["post_id"] == null ? null : json["post_id"],
        status: json["status"] == null ? "" : json["status"].toString(),
        processingStatus: json["processing_status"] == null
            ? ""
            : json["processing_status"].toString(),
        simpleLikeCount: json["simple_like_count"] == null
            ? null
            : json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"] == null
            ? null
            : json["simple_dislike_count"],
        inReplyToId:
            json["in_reply_to_id"] == null ? null : json["in_reply_to_id"],
        repliesCount:
            json["replies_count"] == null ? null : json["replies_count"],
        audioFileUrl: json["audio_file_url"],
        audioPath: json["audio_path"],
        speechToText: json["speech_to_text"],
        languageId: json["language_id"] == null ? null : json["language_id"],
        link: json["link"],
        linkTitle: json["link_title"],
        linkMeta: json["link_meta"],
        linkImage: json["link_image"],
        createdAt: json["created_at"],
        updatedAt: json["updated_at"],
        isLiked: json["isLiked"],
        replies: json["replies"] == null
            ? null
            : List<Comment>.from(
                json["replies"].map((x) => Comment.fromJson(x))),
        // listenCommentUrl: json["listen_comment_url"] == null
        //     ? null
        //     : json["listen_comment_url"],
        commentedTimeAgo: json["commented_time_ago"] == null
            ? null
            : json["commented_time_ago"],
        author: Author.fromJson(json["author"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "body": body,
        "user_id": userId,
        "post_type_id": postTypeId,
        "post_id": postId,
        "status": status,
        "processing_status": processingStatus,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "in_reply_to_id": inReplyToId == null ? null : inReplyToId,
        "replies_count": repliesCount,
        "audio_file_url": audioFileUrl,
        "audio_path": audioPath,
        "speech_to_text": speechToText,
        "language_id": languageId,
        "link": link,
        "link_title": linkTitle,
        "link_meta": linkMeta,
        "link_image": linkImage,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "replies": replies == null
            ? null
            : List<dynamic>.from(replies.map((x) => x.toJson())),
        // "listen_comment_url":
        //     listenCommentUrl == null ? null : listenCommentUrl,
        "commented_time_ago":
            commentedTimeAgo == null ? null : commentedTimeAgo,
        "author": author.toJson(),
      };
}

class Author {
  Author({
    this.id,
    this.profileImage,
    this.firstname,
    this.lastname,
    this.username,
    this.accountVerified,
  });

  int id;
  dynamic profileImage;
  String firstname;
  String lastname;
  String username;
  String accountVerified;

  factory Author.fromJson(Map<String, dynamic> json) => Author(
        id: json["id"] == null ? GetStorage().read("id") : json["id"],
        profileImage: json["profile_image"],
        firstname: json["firstname"],
        lastname: json["lastname"],
        username: json["username"],
        accountVerified: json["verified"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "profile_image": profileImage,
        "firstname": firstname,
        "lastname": lastname,
        "username": username,
        "verified": accountVerified,
      };
}

class Trending {
  Trending({
    this.region,
    this.hotTrends,
  });

  String region;
  List<HotTrend> hotTrends;

  factory Trending.fromJson(Map<String, dynamic> json) => Trending(
        region: json["region"] == null ? null : json["region"],
        hotTrends: List<HotTrend>.from(
            json["hot_trends"].map((x) => HotTrend.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "region": region,
        "hot_trends": List<dynamic>.from(hotTrends.map((x) => x.toJson())),
      };
}

class HotTrend {
  HotTrend({
    this.postId,
    this.tagId,
    this.title,
    this.region,
    this.createdAt,
    this.trendingCount,
  });

  int postId;
  int tagId;
  String title;
  String region;
  DateTime createdAt;
  int trendingCount;

  factory HotTrend.fromJson(Map<String, dynamic> json) => HotTrend(
        postId: json["post_id"],
        tagId: json["tag_id"],
        title: json["title"],
        region: json["region"],
        createdAt: DateTime.parse(json["created_at"]),
        trendingCount: json["trending_count"],
      );

  Map<String, dynamic> toJson() => {
        "post_id": postId,
        "tag_id": tagId,
        "title": title,
        "region": region,
        "created_at": createdAt.toIso8601String(),
        "trending_count": trendingCount,
      };
}
// To parse this JSON data, do
//
//     final quoteWerf = quoteWerfFromJson(jsonString);

QuoteWerf quoteWerfFromJson(String str) => QuoteWerf.fromJson(json.decode(str));

String quoteWerfToJson(QuoteWerf data) => json.encode(data.toJson());

class QuoteWerf {
  QuoteWerf({
    this.id,
    this.postId,
    this.authorName,
    this.profileImage,
    this.username,
    this.authorGender,
    this.authorId,
    this.postedOn,
    this.postType,
    this.postTypeColorCode,
    this.body,
    this.location,
    this.simpleLikeCount,
    this.simpleDislikeCount,
    this.sharesCount,
    this.sharedPostId,
    this.commentsCount,
    this.privacyType,
    this.link,
    this.linkTitle,
    this.linkMeta,
    this.linkImage,
    this.shortenUrl,
    this.type,
    this.pollQuesFirst,
    this.pollQuesSecond,
    this.pollQuesThird,
    this.pollQuesFourth,
    this.pollExpires,
    this.publishStatus,
    this.languageId,
    this.statusId,
    this.quoteId,
    this.postFiles,
  });

  int id;
  int postId;
  String authorName;
  String profileImage;
  String username;
  dynamic authorGender;
  int authorId;
  DateTime postedOn;
  String postType;
  String postTypeColorCode;
  String body;
  String location;
  int simpleLikeCount;
  int simpleDislikeCount;
  int sharesCount;
  dynamic sharedPostId;
  int commentsCount;
  String privacyType;
  dynamic link;
  dynamic linkTitle;
  dynamic linkMeta;
  dynamic linkImage;
  dynamic shortenUrl;
  String type;
  dynamic pollQuesFirst;
  dynamic pollQuesSecond;
  dynamic pollQuesThird;
  dynamic pollQuesFourth;
  dynamic pollExpires;
  String publishStatus;
  int languageId;
  int statusId;
  dynamic quoteId;
  List<dynamic> postFiles;

  factory QuoteWerf.fromJson(Map<String, dynamic> json) => QuoteWerf(
        id: json["id"],
        postId: json["post_id"],
        authorName: json["author_name"],
        profileImage: json["profile_image"],
        username: json["username"],
        authorGender: json["author_gender"],
        authorId: json["author_id"],
        postedOn: DateTime.parse(json["posted_on"]),
        postType: json["post_type"],
        postTypeColorCode: json["post_type_color_code"],
        body: json["body"],
        location: json["location"],
        simpleLikeCount: json["simple_like_count"],
        simpleDislikeCount: json["simple_dislike_count"],
        sharesCount: json["shares_count"],
        sharedPostId: json["shared_post_id"],
        commentsCount: json["comments_count"],
        privacyType: json["privacy_type"],
        link: json["link"],
        linkTitle: json["link_title"],
        linkMeta: json["link_meta"],
        linkImage: json["link_image"],
        shortenUrl: json["shorten_url"],
        type: json["type"],
        pollQuesFirst: json["poll_ques_first"],
        pollQuesSecond: json["poll_ques_second"],
        pollQuesThird: json["poll_ques_third"],
        pollQuesFourth: json["poll_ques_fourth"],
        pollExpires: json["poll_expires"],
        publishStatus: json["publish_status"],
        languageId: json["language_id"],
        statusId: json["status_id"],
        quoteId: json["quote_id"],
        postFiles: List<dynamic>.from(json["post_files"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "post_id": postId,
        "author_name": authorName,
        "profile_image": profileImage,
        "username": username,
        "author_gender": authorGender,
        "author_id": authorId,
        "posted_on": postedOn.toIso8601String(),
        "post_type": postType,
        "post_type_color_code": postTypeColorCode,
        "body": body,
        "location": location,
        "simple_like_count": simpleLikeCount,
        "simple_dislike_count": simpleDislikeCount,
        "shares_count": sharesCount,
        "shared_post_id": sharedPostId,
        "comments_count": commentsCount,
        "privacy_type": privacyType,
        "link": link,
        "link_title": linkTitle,
        "link_meta": linkMeta,
        "link_image": linkImage,
        "shorten_url": shortenUrl,
        "type": type,
        "poll_ques_first": pollQuesFirst,
        "poll_ques_second": pollQuesSecond,
        "poll_ques_third": pollQuesThird,
        "poll_ques_fourth": pollQuesFourth,
        "poll_expires": pollExpires,
        "publish_status": publishStatus,
        "language_id": languageId,
        "status_id": statusId,
        "quote_id": quoteId,
        "post_files": List<dynamic>.from(postFiles.map((x) => x)),
      };
}
