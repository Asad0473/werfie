class WerfieHandleSuggestionsResponse {
  String action;
  Meta meta;
  Data data;

  WerfieHandleSuggestionsResponse({this.action, this.meta, this.data});

  WerfieHandleSuggestionsResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  List<String> usernameSuggestion;

  Data({this.usernameSuggestion});

  Data.fromJson(Map<String, dynamic> json) {
    if(json["username_suggestion"] != null && json["username_suggestion"].isNotEmpty )
    usernameSuggestion = json['username_suggestion'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['username_suggestion'] = this.usernameSuggestion;
    return data;
  }
}

