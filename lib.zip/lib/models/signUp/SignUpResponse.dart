class SignUpResponse {
  String action;
  Meta meta;
  Data data;

  SignUpResponse({this.action, this.meta, this.data});

  SignUpResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  String token;
  String phoneNo;
  String email;
  String username;
  int id;

  Data({this.token, this.phoneNo, this.email, this.username, this.id});

  Data.fromJson(Map<String, dynamic> json) {
    token = json['token'];
    phoneNo = json['phone_no'];
    email = json['email'];
    username = json['username'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['token'] = this.token;
    data['phone_no'] = this.phoneNo;
    data['email'] = this.email;
    data['username'] = this.username;
    data['id'] = this.id;
    return data;
  }
}