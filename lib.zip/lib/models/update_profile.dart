// To parse this JSON data, do
//
//     final updateProfile = updateProfileFromJson(jsonString);

import 'dart:convert';

UpdateProfile updateProfileFromJson(String str) =>
    UpdateProfile.fromJson(json.decode(str));

String updateProfileToJson(UpdateProfile data) => json.encode(data.toJson());

class UpdateProfile {
  UpdateProfile({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  Data data;

  factory UpdateProfile.fromJson(Map<String, dynamic> json) => UpdateProfile(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.id,
    this.emailVerifiedAt,
    this.isBlock,
    this.profileImage,
    this.coverImage,
    this.dob,
    this.city,
    this.aboutMe,
    this.gender,
    this.createdAt,
    this.updatedAt,
    this.firstname,
    this.lastname,
    this.email,
    this.languageId,
    this.website,
    this.isOnline,
    this.lastLogin,
    this.username,
    this.accountVerified,
    this.apiToken,
    this.notificationAllowed,
    this.deletedAt,
    this.language,
  });

  int id;
  dynamic emailVerifiedAt;
  int isBlock;
  dynamic profileImage;
  dynamic coverImage;
  String dob;
  dynamic city;
  String aboutMe;
  dynamic gender;
  DateTime createdAt;
  DateTime updatedAt;
  String firstname;
  String lastname;
  String email;
  int languageId;
  dynamic website;
  int isOnline;
  DateTime lastLogin;
  String username;
  dynamic accountVerified;
  dynamic apiToken;
  int notificationAllowed;
  dynamic deletedAt;
  Language language;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        id: json["id"],
        emailVerifiedAt: json["email_verified_at"],
        isBlock: json["is_block"],
        profileImage: json["profile_image"],
        coverImage: json["cover_image"],
        dob: json["dob"],
        city: json["city"],
        aboutMe: json["about_me"],
        gender: json["gender"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        firstname: json["firstname"],
        lastname: json["lastname"],
        email: json["email"],
        languageId: json["language_id"],
        website: json["website"],
        isOnline: json["is_online"],
        lastLogin: DateTime.parse(json["last_login"]),
        username: json["username"],
        accountVerified: json["account_verified"],
        apiToken: json["api_token"],
        notificationAllowed: json["notification_allowed"],
        deletedAt: json["deleted_at"],
        language: Language.fromJson(json["language"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "email_verified_at": emailVerifiedAt,
        "is_block": isBlock,
        "profile_image": profileImage,
        "cover_image": coverImage,
        "dob": dob,
        "city": city,
        "about_me": aboutMe,
        "gender": gender,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "firstname": firstname,
        "lastname": lastname,
        "email": email,
        "language_id": languageId,
        "website": website,
        "is_online": isOnline,
        "last_login": lastLogin.toIso8601String(),
        "username": username,
        "account_verified": accountVerified,
        "api_token": apiToken,
        "notification_allowed": notificationAllowed,
        "deleted_at": deletedAt,
        "language": language.toJson(),
      };
}

class Language {
  Language({
    this.id,
    this.name,
    this.code,
    this.direction,
    this.createdAt,
    this.updatedAt,
    this.code2,
    this.flagPath,
    this.isTranslationSupported,
    this.isTopLanguage,
    this.pivot,
  });

  int id;
  String name;
  String code;
  String direction;
  DateTime createdAt;
  DateTime updatedAt;
  String code2;
  String flagPath;
  String isTranslationSupported;
  String isTopLanguage;
  Pivot pivot;

  factory Language.fromJson(Map<String, dynamic> json) => Language(
        id: json["id"],
        name: json["name"],
        code: json["code"],
        direction: json["direction"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        code2: json["code2"],
        flagPath: json["flag_path"],
        isTranslationSupported: json["is_translation_supported"],
        isTopLanguage: json["is_top_language"],
        pivot: Pivot.fromJson(json["pivot"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "code": code,
        "direction": direction,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "code2": code2,
        "flag_path": flagPath,
        "is_translation_supported": isTranslationSupported,
        "is_top_language": isTopLanguage,
        "pivot": pivot.toJson(),
      };
}

class Pivot {
  Pivot({
    this.userId,
    this.languageId,
  });

  int userId;
  int languageId;

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
        userId: json["user_id"],
        languageId: json["language_id"],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "language_id": languageId,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
