// To parse this JSON data, do
//
//     final listModel = listModelFromJson(jsonString);



// ListModel listModelFromJson(String str) => ListModel.fromJson(json.decode(str));
//
// String listModelToJson(ListModel data) => json.encode(data.toJson());

import 'package:get/get.dart';

class ListModel {
  ListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  DataList data;

  factory ListModel.fromJson(Map<String, dynamic> json) => ListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: DataList.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class DataList {
  DataList({
    this.lists,
    this.pinnedLists,
    this.discoverLists,
  });

  List<DiscoverListElement> lists;
  List<DiscoverListElement> pinnedLists;
  List<DiscoverListElement> discoverLists;

  factory DataList.fromJson(Map<String, dynamic> json) => DataList(
        lists: List<DiscoverListElement>.from(
            json["lists"].map((x) => DiscoverListElement.fromJson(x))),
        pinnedLists: List<DiscoverListElement>.from(
            json["pinnedLists"].map((x) => DiscoverListElement.fromJson(x))),
        discoverLists: json["discoverLists"] == null
            ? []
            : List<DiscoverListElement>.from(json["discoverLists"]
                .map((x) => DiscoverListElement.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "lists": List<dynamic>.from(lists.map((x) => x.toJson())),
        "pinnedLists": List<dynamic>.from(pinnedLists.map((x) => x.toJson())),
        "discoverLists":
            List<dynamic>.from(discoverLists.map((x) => x.toJson())),
      };
}

class DiscoverListElement {
  DiscoverListElement({
    this.id,
    this.userId,
    this.name,
    this.description,
    this.coverImage,
    this.makePrivate,
    this.authorName,
    this.authorProfileImage,
    this.username,
    this.isPinValue
  });

  int id;
  int userId;
  String name;
  String description;
  String coverImage;
  String makePrivate;
  String authorName;
  dynamic authorProfileImage;
  String username;
  bool isFollow = false;
  bool isPin = false;
  int isPinValue;
  RxInt isPinRX=0.obs;

  factory DiscoverListElement.fromJson(Map<String, dynamic> json) =>
      DiscoverListElement(
        id: json["id"],
        userId: json["user_id"],
        name: json["name"],
        description: json["description"],
        coverImage: json["cover_image"] == null ? null : json["cover_image"],
        makePrivate: json["make_private"],
        authorName: json["author_name"],
        authorProfileImage: json["author_profile_image"],
        username: json["username"],
        isPinValue:json["is_pinned"]
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "name": name,
        "description": description,
        "cover_image": coverImage == null ? null : coverImage,
        "make_private": makePrivate,
        "author_name": authorName,
        "author_profile_image": authorProfileImage,
        "username": username,
    "is_pinned": isPinValue,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
