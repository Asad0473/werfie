class CommentReaction {
  String action;
  Meta meta;
  Data data;

  CommentReaction({this.action, this.meta, this.data});

  CommentReaction.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  ReactionCounts reactionCounts;
  List<ReactedUser> reactedUser;

  Data({this.reactionCounts, this.reactedUser});

  Data.fromJson(Map<String, dynamic> json) {
    reactionCounts = json['reaction_counts'] != null
        ? new ReactionCounts.fromJson(json['reaction_counts'])
        : null;
    if (json['reacted_user'] != null) {
      reactedUser = <ReactedUser>[];
      json['reacted_user'].forEach((v) {
        reactedUser.add(new ReactedUser.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.reactionCounts != null) {
      data['reaction_counts'] = this.reactionCounts.toJson();
    }
    if (this.reactedUser != null) {
      data['reacted_user'] = this.reactedUser.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ReactionCounts {
  int likes;
  int loves;
  int loughs;
  int smiles;
  int thanks;
  int exciteds;
  int crys;

  ReactionCounts(
      {this.likes,
      this.loves,
      this.loughs,
      this.smiles,
      this.thanks,
      this.exciteds,
      this.crys});

  ReactionCounts.fromJson(Map<String, dynamic> json) {
    likes = json['likes'];
    loves = json['loves'];
    loughs = json['loughs'];
    smiles = json['smiles'];
    thanks = json['thanks'];
    exciteds = json['exciteds'];
    crys = json['crys'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['likes'] = this.likes;
    data['loves'] = this.loves;
    data['loughs'] = this.loughs;
    data['smiles'] = this.smiles;
    data['thanks'] = this.thanks;
    data['exciteds'] = this.exciteds;
    data['crys'] = this.crys;
    return data;
  }
}

class ReactedUser {
  int id;
  int commentId;
  int userId;
  String type;
  String createdAt;
  String updatedAt;
  User user;

  ReactedUser(
      {this.id,
      this.commentId,
      this.userId,
      this.type,
      this.createdAt,
      this.updatedAt,
      this.user});

  ReactedUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    commentId = json['comment_id'];
    userId = json['user_id'];
    type = json['type'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    user = json['user'] != null ? new User.fromJson(json['user']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['comment_id'] = this.commentId;
    data['user_id'] = this.userId;
    data['type'] = this.type;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    if (this.user != null) {
      data['user'] = this.user.toJson();
    }
    return data;
  }
}

class User {
  int id;

  int isBlock;
  String profileImage;
  String coverImage;

  String username;
  String firstname;
  String lastname;
  String email;

  String accountVerified;

  User({
    this.id,
    this.isBlock,
    this.profileImage,
    this.coverImage,
    this.firstname,
    this.lastname,
    this.email,
    this.accountVerified,
  });

  User.fromJson(Map<String, dynamic> json) {
    id = json['id'];

    isBlock = json['is_block'];
    profileImage = json['profile_image'];
    coverImage = json['cover_image'];

    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];

    username = json['username'];
    accountVerified = json['account_verified'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;

    data['is_block'] = this.isBlock;
    data['profile_image'] = this.profileImage;
    data['cover_image'] = this.coverImage;

    data['firstname'] = this.firstname;
    data['lastname'] = this.lastname;
    data['email'] = this.email;

    data['username'] = this.username;
    data['account_verified'] = this.accountVerified;

    return data;
  }
}
