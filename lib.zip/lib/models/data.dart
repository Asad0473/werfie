class Data {
  String thumbnailUrl;
  String name;
  String size;
  String url;

  Data({this.thumbnailUrl, this.name, this.size, this.url});

  Data.fromJson(Map<String, dynamic> json) {
    thumbnailUrl = json['thumbnail_url'];
    name = json['name'];
    size = json['size'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['thumbnail_url'] = this.thumbnailUrl;
    data['name'] = this.name;
    data['size'] = this.size;
    data['url'] = this.url;
    return data;
  }
}
