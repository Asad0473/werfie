class PrivacyAndSafetyModel {
  String action;
  Meta meta;
  Data data;

  PrivacyAndSafetyModel({this.action, this.meta, this.data});

  PrivacyAndSafetyModel.fromJson(Map json) {
    action = json['action'];
    meta = json['meta'] != null ? new Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map toJson() {
    final Map data = new Map();
    data['action'] = this.action;
    if (this.meta != null) {
      data['meta'] = this.meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map json) {
    code = json['code'];
    message = json['message'];
  }

  Map toJson() {
    final Map data = new Map();
    data['code'] = this.code;
    data['message'] = this.message;
    return data;
  }
}

class Data {
  int id;
  int userId;
  int protectWerfs;
  int allowPhotoTagging;
  String whoCanPhotoTagYou;
  int markMediaSensitive;
  int addLocationToWerfs;
  int displaySensitiveContentMedia;
  int exploreSettingsLocation;
  int exploreSettingsPersonalization;
  int searchSettingsHideSensitiveContent;
  int searchSettingsRemoveBlockedAccounts;
  String directMessages;
  int filterLowQualityMessages;
  int showReadReceipts;
  int spacesSettingAllowFollowers;
  int discoverSettingsEmail;
  int discoverSettingsPhone;
  int personalizedAdsSwitch;
  int inferredIdentitySwitch;
  int shareDataWithBusinessPartners;
  int locationInfoYouHaveBeen;
  String createdAt;
  String updatedAt;

  Data(
  {this.id,
  this.userId,
  this.protectWerfs,
  this.allowPhotoTagging,
  this.whoCanPhotoTagYou,
  this.markMediaSensitive,
  this.addLocationToWerfs,
    this.displaySensitiveContentMedia,
    this.exploreSettingsLocation,
    this.exploreSettingsPersonalization,
    this.searchSettingsHideSensitiveContent,
    this.searchSettingsRemoveBlockedAccounts,
    this.directMessages,
    this.filterLowQualityMessages,
    this.showReadReceipts,
    this.spacesSettingAllowFollowers,
    this.discoverSettingsEmail,
    this.discoverSettingsPhone,
    this.personalizedAdsSwitch,
    this.inferredIdentitySwitch,
    this.shareDataWithBusinessPartners,
    this.locationInfoYouHaveBeen,
    this.createdAt,
    this.updatedAt,

  });

  Data.fromJson(Map json) {
  id = json['id'];
  userId = json['user_id'];
  protectWerfs = json['protect_werfs'];
  allowPhotoTagging = json['allow_photo_tagging'];
  whoCanPhotoTagYou = json['who_can_photo_tag_you'];
  markMediaSensitive = json['mark_media_sensitive'];
  addLocationToWerfs = json['add_location_to_werfs'];
  displaySensitiveContentMedia = json['display_sensitive_content_media'];
  exploreSettingsLocation = json['explore_settings_location'];
  exploreSettingsPersonalization = json['explore_settings_personalization'];
  searchSettingsHideSensitiveContent =
  json['search_settings_hide_sensitive_content'];
  searchSettingsRemoveBlockedAccounts =
  json['search_settings_remove_blocked_accounts'];
  directMessages = json['direct_messages'];
  filterLowQualityMessages = json['filter_low_quality_messages'];
  showReadReceipts = json['show_read_receipts'];
  spacesSettingAllowFollowers = json['spaces_setting_allow_followers'];
  discoverSettingsEmail = json['discover_settings_email'];
  discoverSettingsPhone = json['discover_settings_phone'];
  personalizedAdsSwitch = json['personalized_ads_switch'];
  inferredIdentitySwitch = json['inferred_identity_switch'];
  shareDataWithBusinessPartners = json['share_data_with_business_partners'];
  locationInfoYouHaveBeen = json['location_info_you_have_been'];
  createdAt = json['created_at'];
  updatedAt = json['updated_at'];
  }
  Map toJson() {
    final Map data = new Map();
    data['id'] = this.id;
    data['user_id'] = this.userId;
    data['protect_werfs'] = this.protectWerfs;
    data['allow_photo_tagging'] = this.allowPhotoTagging;
    data['who_can_photo_tag_you'] = this.whoCanPhotoTagYou;
    data['mark_media_sensitive'] = this.markMediaSensitive;
    data['add_location_to_werfs'] = this.addLocationToWerfs;
    data['display_sensitive_content_media'] = this.displaySensitiveContentMedia;
    data['explore_settings_location'] = this.exploreSettingsLocation;
    data['explore_settings_personalization'] =
        this.exploreSettingsPersonalization;
    data['search_settings_hide_sensitive_content'] =
        this.searchSettingsHideSensitiveContent;
    data['search_settings_remove_blocked_accounts'] =
        this.searchSettingsRemoveBlockedAccounts;
    data['direct_messages'] = this.directMessages;
    data['filter_low_quality_messages'] = this.filterLowQualityMessages;
    data['show_read_receipts'] = this.showReadReceipts;
    data['spaces_setting_allow_followers'] = this.spacesSettingAllowFollowers;
    data['discover_settings_email'] = this.discoverSettingsEmail;
    data['discover_settings_phone'] = this.discoverSettingsPhone;
    data['personalized_ads_switch'] = this.personalizedAdsSwitch;
    data['inferred_identity_switch'] = this.inferredIdentitySwitch;
    data['share_data_with_business_partners'] =
        this.shareDataWithBusinessPartners;
    data['location_info_you_have_been'] = this.locationInfoYouHaveBeen;
    data['created_at'] = this.createdAt;
    data['updated_at'] = this.updatedAt;
    return data;
  }
}