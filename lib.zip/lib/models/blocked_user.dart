// To parse this JSON data, do
//
//     final blockedUser = blockedUserFromJson(jsonString);

import 'dart:convert';

BlockedUser blockedUserFromJson(String str) =>
    BlockedUser.fromJson(json.decode(str));

String blockedUserToJson(BlockedUser data) => json.encode(data.toJson());

class BlockedUser {
  BlockedUser({
    this.id,
    this.username,
    this.profileImage,
  });

  int id;
  String username;
  dynamic profileImage;

  factory BlockedUser.fromJson(Map<String, dynamic> json) => BlockedUser(
        id: json["id"],
        username: json["username"],
        profileImage: json["profile_image"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "username": username,
        "profile_image": profileImage,
      };
}
