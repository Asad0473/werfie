// To parse this JSON data, do
//
//     final followerListModel = followerListModelFromJson(jsonString);

import 'dart:convert';

FollowerListModel followerListModelFromJson(String str) =>
    FollowerListModel.fromJson(json.decode(str));

String followerListModelToJson(FollowerListModel data) =>
    json.encode(data.toJson());

class FollowerListModel {
  FollowerListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  Data data;

  factory FollowerListModel.fromJson(Map<String, dynamic> json) =>
      FollowerListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.memberId,
  });

  String memberId;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        memberId: json["member_id"],
      );

  Map<String, dynamic> toJson() => {
        "member_id": memberId,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
