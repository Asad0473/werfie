// To parse this JSON data, do
//
//     final deleteListModel = deleteListModelFromJson(jsonString);

import 'dart:convert';

DeleteListModel deleteListModelFromJson(String str) =>
    DeleteListModel.fromJson(json.decode(str));

String deleteListModelToJson(DeleteListModel data) =>
    json.encode(data.toJson());

class DeleteListModel {
  DeleteListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  Data data;

  factory DeleteListModel.fromJson(Map<String, dynamic> json) =>
      DeleteListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class Data {
  Data({
    this.listId,
  });

  String listId;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        listId: json["list_id"],
      );

  Map<String, dynamic> toJson() => {
        "list_id": listId,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
