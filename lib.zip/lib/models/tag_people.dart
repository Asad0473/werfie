// class TagPeople {
//   TagPeople({
//     this.id,
//     this.username,
//     this.firstname,
//     this.profileImage,
//     this.accountVerified,
//   });
//
//   int id;
//   String username;
//   String firstname;
//   String profileImage;
//   dynamic accountVerified;
//
//   factory TagPeople.fromJson(Map<String, dynamic> json) => TagPeople(
//     id: json["id"],
//     username: json["username"],
//     firstname: json["firstname"],
//     profileImage: json["profile_image"],
//     accountVerified: json["account_verified"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "username": username,
//     "firstname": firstname,
//     "profile_image": profileImage,
//     "account_verified": accountVerified,
//   };
// }
