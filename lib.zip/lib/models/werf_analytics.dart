// To parse this JSON data, do
//
//     final werfAnalytics = werfAnalyticsFromJson(jsonString);

import 'dart:convert';

import 'package:meta/meta.dart';

WerfAnalytics werfAnalyticsFromJson(String str) =>
    WerfAnalytics.fromJson(json.decode(str));

String werfAnalyticsToJson(WerfAnalytics data) => json.encode(data.toJson());

class WerfAnalytics {
  WerfAnalytics({
    @required this.impressions,
    @required this.profileVisits,
    @required this.newFollowers,
    @required this.detailExpands,
  });

  int impressions;
  int profileVisits;
  int newFollowers;
  int detailExpands;

  factory WerfAnalytics.fromJson(Map<String, dynamic> json) => WerfAnalytics(
        impressions: json["impressions"],
        profileVisits: json["profile_visits"],
        newFollowers: json["new_followers"],
        detailExpands: json["detail_expands"],
      );

  Map<String, dynamic> toJson() => {
        "impressions": impressions,
        "profile_visits": profileVisits,
        "new_followers": newFollowers,
        "detail_expands": detailExpands,
      };
}
