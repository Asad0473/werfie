import 'dart:convert';

GetListMembers getListMenbersFromJson(String str) => GetListMembers.fromJson(json.decode(str));

String getListMenbersToJson(GetListMembers data) => json.encode(data.toJson());

class GetListMembers {
  String action;
  Meta meta;
  List<GetMemberListData> data;

  GetListMembers({
    this.action,
     this.meta,
     this.data,
  });

  factory GetListMembers.fromJson(Map json) => GetListMembers(
    action: json["action"],
    meta: Meta.fromJson(json["meta"]),
    data: List.from(json["data"].map((x) => GetMemberListData.fromJson(x))),
  );

  Map toJson() => {
    "action": action,
    "meta": meta.toJson(),
    "data": List.from(data.map((x) => x.toJson())),
  };
}



class GetMemberListData {
  int id;
  int userId;
  String name;
  String description;
  String coverImage;
  String makePrivate;
  String authorName;
  dynamic authorProfileImage;
  dynamic accountVerified;
  String username;

  GetMemberListData({
     this.id,
    this.userId,
   this.name,
     this.description,
     this.coverImage,
   this.makePrivate,
    this.authorName,
     this.authorProfileImage,
    this.accountVerified,
    this.username,
  });

  factory GetMemberListData.fromJson(Map json) => GetMemberListData(
    id: json["id"],
    userId: json["user_id"],
    name: json["name"],
    description: json["description"],
    coverImage: json["cover_image"],
    makePrivate: json["make_private"],
    authorName: json["author_name"],
    authorProfileImage: json["author_profile_image"],
    accountVerified: json["account_verified"],
    username: json["username"],
  );

  Map toJson() => {
    "id": id,
    "user_id": userId,
    "name": name,
    "description": description,
    "cover_image": coverImage,
    "make_private": makePrivate,
    "author_name": authorName,
    "author_profile_image": authorProfileImage,
    "account_verified": accountVerified,
    "username": username,
  };
}

class Meta {
  int code;
  String message;

  Meta({
     this.code,
     this.message,
  });

  factory Meta.fromJson(Map json) => Meta(
    code: json["code"],
    message: json["message"],
  );

  Map toJson() => {
    "code": code,
    "message": message,
  };
}