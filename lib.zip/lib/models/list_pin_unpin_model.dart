// To parse this JSON data, do
//
//     final pinUnPinListModel = pinUnPinListModelFromJson(jsonString);

import 'dart:convert';

PinUnPinListModel pinUnPinListModelFromJson(String str) =>
    PinUnPinListModel.fromJson(json.decode(str));

String pinUnPinListModelToJson(PinUnPinListModel data) =>
    json.encode(data.toJson());

class PinUnPinListModel {
  PinUnPinListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  PinListData data;

  factory PinUnPinListModel.fromJson(Map<String, dynamic> json) =>
      PinUnPinListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: PinListData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class PinListData {
  PinListData({
    this.userId,
    this.listId,
    this.updatedAt,
    this.createdAt,
    this.id,
  });

  int userId;
  String listId;
  DateTime updatedAt;
  DateTime createdAt;
  int id;

  factory PinListData.fromJson(Map<String, dynamic> json) => PinListData(
        userId: json["user_id"],
        listId: json["list_id"],
        updatedAt: DateTime.parse(json["updated_at"]),
        createdAt: DateTime.parse(json["created_at"]),
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "list_id": listId,
        "updated_at": updatedAt.toIso8601String(),
        "created_at": createdAt.toIso8601String(),
        "id": id,
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
