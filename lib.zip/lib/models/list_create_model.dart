// To parse this JSON data, do
//
//     final createListModel = createListModelFromJson(jsonString);

import 'dart:convert';

CreateListModel createListModelFromJson(String str) =>
    CreateListModel.fromJson(json.decode(str));

String createListModelToJson(CreateListModel data) =>
    json.encode(data.toJson());

class CreateListModel {
  CreateListModel({
    this.action,
    this.meta,
    this.data,
  });

  String action;
  Meta meta;
  DataListCreated data;

  factory CreateListModel.fromJson(Map<String, dynamic> json) =>
      CreateListModel(
        action: json["action"],
        meta: Meta.fromJson(json["meta"]),
        data: DataListCreated.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "action": action,
        "meta": meta.toJson(),
        "data": data.toJson(),
      };
}

class DataListCreated {
  DataListCreated({
    this.coverImage,
    this.name,
    this.userId,
    this.description,
    this.makePrivate,
    this.updatedAt,
    this.createdAt,
    this.id,
    this.authorName,
    this.username,
    this.authorProfileImage,
    this.isPin
  });

  String coverImage;
  String name;
  int userId;
  String description;
  String makePrivate;
  DateTime updatedAt;
  DateTime createdAt;
  int id;
  String authorName;
  String username;
  dynamic authorProfileImage;
  int isPin;

  factory DataListCreated.fromJson(Map<String, dynamic> json) =>
      DataListCreated(
        coverImage: json["cover_image"],
        name: json["name"],
        userId: json["user_id"],
        description: json["description"],
        makePrivate: json["make_private"],
        updatedAt: DateTime.parse(json["updated_at"]),
        createdAt: DateTime.parse(json["created_at"]),
        id: json["id"],
        authorName: json["author_name"],
        username: json["username"],
        authorProfileImage: json["author_profile_image"],
        isPin: json ["is_pinned"],
      );

  Map<String, dynamic> toJson() => {
        "cover_image": coverImage,
        "name": name,
        "user_id": userId,
        "description": description,
        "make_private": makePrivate,
        "updated_at": updatedAt.toIso8601String(),
        "created_at": createdAt.toIso8601String(),
        "id": id,
        "author_name": authorName,
        "username": username,
        "author_profile_image": authorProfileImage,
    "is_pinned":isPin
      };
}

class Meta {
  Meta({
    this.code,
    this.message,
  });

  int code;
  String message;

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        code: json["code"],
        message: json["message"],
      );

  Map<String, dynamic> toJson() => {
        "code": code,
        "message": message,
      };
}
