class GetS3UrlResponse {
  String action;
  Meta meta;
  Data data;

  GetS3UrlResponse({this.action, this.meta, this.data});

  GetS3UrlResponse.fromJson(Map<String, dynamic> json) {
    action = json['action'];
    meta = json['meta'] != null ? Meta.fromJson(json['meta']) : null;
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['action'] = action;
    if (meta != null) {
      data['meta'] = meta.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data.toJson();
    }
    return data;
  }
}

class Meta {
  int code;
  String message;

  Meta({this.code, this.message});

  Meta.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['code'] = code;
    data['message'] = message;
    return data;
  }
}

class Data {
  String preSignedUrl;
  String fileUrl;
  String fileName;
  String fileType;
  String mimeType;

  Data(
      {this.preSignedUrl,
        this.fileUrl,
        this.fileName,
        this.fileType,
        this.mimeType});

  Data.fromJson(Map<String, dynamic> json) {
    preSignedUrl = json['preSignedUrl'];
    fileUrl = json['fileUrl'];
    fileName = json['fileName'];
    fileType = json['fileType'];
    mimeType = json['mimeType'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['preSignedUrl'] = preSignedUrl;
    data['fileUrl'] = fileUrl;
    data['fileName'] = fileName;
    data['fileType'] = fileType;
    data['mimeType'] = mimeType;
    return data;
  }
}