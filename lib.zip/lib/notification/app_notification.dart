import 'dart:convert';
import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../main.dart';
import '../models/post.dart';
import '../network/controller/news_feed_controller.dart';
import '../video_call/video_call_home.dart';
import '../video_call/utilities/video_call_utilities.dart';

class FirebaseNotifications {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static String deviceToken;
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

  static FirebaseNotifications get instance => FirebaseNotifications();

  final firebaseCloudvapidKey =
      "AAAAJUemdpI:APA91bEA7xjcabvKHGbJ54WMKKj7WA19gmBlLqGyH8RHRfhQXabhJBjaCE0S7iKugcWJFRVtDJAQbxChj6vwXRVKegN8EJ0H78kmbfvfP_8g0IBpe-B88XJI2JKSG7c5HJc5KzhcuwAS";
final firebasePublicvapidKey =
"BNG1ZQDff2Kkygun-sMgncG0UDl84FiyCxmELo0WlMWKVLNL5EqYSDJalek1pm4GbEfylyjv-q47HtAv4cYXPNM";
  Future<String> getToken() async {
    try {
      return await _firebaseMessaging.getToken(
        vapidKey: firebasePublicvapidKey,
      );
    }catch(e){
      print(e);
    }
  }
  Future initLocalNotification() async {
    await Firebase.initializeApp();
    try {
      String token = await _firebaseMessaging.getToken(
        vapidKey: firebasePublicvapidKey,
      );
      deviceToken = token;
      // print("fcm token: " + token);
      // print("fcm token: " + token);
      GetStorage().write('fcm_token', token);
      // debugPrint('fcm token init : ${GetStorage().read('fcm_token')}');
    } catch (e) {
      // print("fcm token: " + e.toString());
    }
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage message) {
      //print('.getInitialMessage(): notification Recieved : $message}');
      // Fluttertoast.showToast(msg: "Initial Message: $message");
      if (message != null) {

        Future.delayed(const Duration(seconds: 3), () {
          // Here you can write your code for open new view
          VideoCallUtilities().checkVideoCall(message);
        });

        message.toString();
        print(message.toString());
      }
    });

    // VideoCallUtilities.listenCallKitEvent();

    // await _firebaseMessaging
    //     .getToken(vapidKey: firebasePublicApiIdKey)
    //     .then((val) async {
    //   deviceToken = val;
    //
    //   print('FCMTOKEN ${val.toString()}');
    // });
    if (!kIsWeb) {
      if (Platform.isIOS) {
        // set iOS Local notification.
        var initializationSettingsAndroid =
            AndroidInitializationSettings('@mipmap/ic_launcher');
        var initializationSettingsIOS = DarwinInitializationSettings(
          requestSoundPermission: true,
          requestBadgePermission: true,
          requestAlertPermission: true,
          onDidReceiveLocalNotification: _onDidReceiveLocalNotification,
        );
        var initializationSettings = InitializationSettings(
            android: initializationSettingsAndroid,
            iOS: initializationSettingsIOS);
        await _flutterLocalNotificationsPlugin.initialize(
            initializationSettings,
            onDidReceiveNotificationResponse: onDidReceiveNotificationResponse);
      } else {
        var initializationSettingsAndroid =
            AndroidInitializationSettings('@mipmap/ic_launcher');
        var initializationSettingsIOS = DarwinInitializationSettings(
            onDidReceiveLocalNotification: _onDidReceiveLocalNotification);
        var initializationSettings = InitializationSettings(
            android: initializationSettingsAndroid,
            iOS: initializationSettingsIOS);
        await _flutterLocalNotificationsPlugin.initialize(
            initializationSettings,
            onDidReceiveNotificationResponse: onDidReceiveNotificationResponse);
      }
    }
  }

  void onDidReceiveNotificationResponse(
      NotificationResponse notificationResponse) async {
    debugPrint("payload triggered");

    final String payload = notificationResponse.payload;
    if (notificationResponse.payload != null) {
      // print('notification data here');
      if (Get.isRegistered<NewsfeedController>()) {
        Get.find<NewsfeedController>()
            .getNewsFeed(reload: true, shouldUpdate: true);
      }
      print(payload);
    }
    if (notificationResponse.actionId == 'id_answer') {
      debugPrint("notificationResponse: $notificationResponse");
      debugPrint("notificationResponse payload: ${notificationResponse.payload}");
      // Action 2 tapped
      print('Action 2 tapped');
      Map<String, dynamic> payloadMap = jsonDecode(notificationResponse.payload);
      actionAnswer(payloadMap);
      // Perform action for Action 2
    }
  }

  Future _selectNotification(String payload) async {}

  Future _onDidReceiveLocalNotification(
      int id, String title, String body, String payload) async {
    print('_onDidReceiveLocalNotification: notification Recieved : $payload}');
    // print('Handling a background message $body');
  }

  Future takeFCMTokenWhenAppLaunch() async {
    try {
      NotificationSettings settings =
          await _firebaseMessaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );

      if (settings.authorizationStatus == AuthorizationStatus.authorized) {
        // print('User granted permission');
      } else if (settings.authorizationStatus ==
          AuthorizationStatus.provisional) {
        // print('User granted provisional permission');
      } else {
        // print('User declined or has not accepted permission');
      }

      FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
        // print('Got a message whilst in the foreground!');
        // print('Message data: ${message.data}');

        // print('Notification Data here' + message.data.toString());
        //
        print('onMessage.listen: notification Recieved : ${message.toMap().toString()}');
        print('onMessage.listen: notification Recieved : ${message.data}');
        // onMessage.listen: notification Recieved : {senderId: null, category: null, collapseKey: null, contentAvailable: false, data: {notification_type: audio_video_call, title: Werfie, body: kathirtest07 is calling, caller_name: kathirtest07, caller_id: 503, conversation_id: 504, caller_image_url: String, text: kathirtest07 is calling}, from: 160115881618, messageId: 62c0c608-344c-41b8-8633-56a826d299cb, messageType: null, mutableContent: false, notification: {title: Kathirtest08 is calling you, titleLocArgs: [], titleLocKey: null, body: Kathirtest08, bodyLocArgs: [], bodyLocKey: null, android: null, apple: null, web: {analyticsLabel: null, image: null, link: null}}, sentTime: null, threadId: null, ttl: null}
        // onMessage.listen: notification Recieved : {notification_type: audio_video_call, title: Werfie, body: kathirtest07 is calling, caller_name: kathirtest07, caller_id: 503, conversation_id: 504, caller_image_url: String, text: kathirtest07 is calling}

        // notification Recieved : {notification_type: Call, title: Werfie, body: kathirtest08 is calling, caller_name: kathirtest08, caller_id: 504, conversation_id: 504, caller_image_url: String, text: kathirtest08 is calling}

        VideoCallUtilities().checkVideoCall(message);

        if (message.data["notification_type"] == "audio_video_call"){
          return;
        }
        var jsonDataEncode = jsonEncode(message.data.toString());
        // print('jason data response$jsonDataEncode');
        var jasonDecodeData = json.decode(jsonDataEncode);
        // print('jason Decode data $jasonDecodeData');

        var type = message.data['type'];

        if (type == 'new_message') {
          /// We handle messageCount only in background notification in main.dart file.
          /// When user is in foreground, we use socket to get get the message count.

          // final sharedPrefs = await SharedPreferences.getInstance();
          // if (sharedPrefs.containsKey('messageCount')) {
          //   messageNotifications.value =
          //       await sharedPrefs.getInt('messageCount');
          //   messageNotifications.value++;
          //   sharedPrefs.setInt('messageCount', messageNotifications.value);
          //   messageNotifications.refresh();
          // } else {
          //   messageNotifications.value++;
          //   sharedPrefs.setInt('messageCount', messageNotifications.value);
          //   messageNotifications.refresh();
          // }
        } else {
          notifi.value++;
          notifi.refresh();
        }
        // var jsonResponse = jsonDecode(message.data.toString());
        // print('Notification jason response :$jsonResponse');
        // if(jsonResponse['tittle']=="Liked Buzz"){
        //   print('jasondata Notification');
        // }

        if (message.notification != null &&
            message.notification.title == 'Liked Buzz') {
          // print(' with out data jasondata Notification');
          if (Get.isRegistered<NewsfeedController>()) {
            List<Post> notificationList =
                Get.find<NewsfeedController>().postList;
            // print('data list length: ${notificationList.length}');
            // print('inside if ');
          }
        }

        RemoteNotification notification = message.notification;
        //   AndroidNotification android = message.notification.android;

        final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
            FlutterLocalNotificationsPlugin();

        const AndroidNotificationChannel channel = AndroidNotificationChannel(
          'high_importance_channel', // id
          'High Importance Notifications', // title
          // description
          importance: Importance.max,
        );
        await flutterLocalNotificationsPlugin
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>()
            ?.createNotificationChannel(channel);
        if (notification != null) {
          List<AndroidNotificationAction> actions = [];
          if (message.data["notification_type"] == "audio_video_call"){
            actions = [
              AndroidNotificationAction('id_decline', 'Decline', showsUserInterface: true),
              AndroidNotificationAction('id_answer', 'Answer', showsUserInterface: true)
            ];
          }
          flutterLocalNotificationsPlugin.show(
            notification.hashCode,
            notification.title,
            notification.body,
            NotificationDetails(
                android: AndroidNotificationDetails(
                  channel.id,
                  channel.name,
                  // TODO add a proper drawable resource to android, for now using
                  //      one that already exists in example app.
                  icon: 'werfielogo',
                  actions: actions
                ),
                iOS: DarwinNotificationDetails(
                  presentSound: true,
                  presentAlert: true,
                )),
            payload: jsonEncode(message.data)
          );
        }
        void pushShowNotification(int code, String title, String message) {
          _flutterLocalNotificationsPlugin.show(
            code,
            title,
            message,
            NotificationDetails(
                android: AndroidNotificationDetails(
                  channel.id,
                  channel.name,

                  // TODO add a proper drawable resource to android, for now using
                  //      one that already exists in example app.
                  icon: 'werfielogo',
                ),
                iOS: DarwinNotificationDetails(
                  presentSound: true,
                  presentAlert: true,
                )),
          );
        }
      });

      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        debugPrint("onMessageOpenedApp: ${message.data}");
        // VideoCallUtilities().checkVideoCall(message);
      });
    } catch (e) {
      // print(e.toString());
    }
  }
}

actionAnswer(var actionButtonData){
  // var controller = Get.find<NewsfeedController>();

  if (!kIsWeb){
  //   // onVideoCallChange = true;
  //   controller.navRoute = "isVideoCallScreen";
  //
  //   Get.toNamed(FluroRouters.mainScreen + '/videocall', arguments: widget.conversationID);
  // } else {
    Navigator.push(navigatorKey.currentContext, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome(conversationId: actionButtonData["conversation_id"])));
  }
}

