import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:werfieapp/network/apis/s3/UploadMediaToS3API.dart';
import 'package:werfieapp/utils/strings.dart';

import '../models/FileBytesModel.dart';
import '../network/apis/s3/GetS3UrlAPI.dart';
import '../widgets/web_createpostModule/create_PostWeb.dart';

class HelperUploadMediaToS3 {
  getS3UrlForVideosAndAndReturnJson(Uint8List mediaBytes, String fileType,
      String memeType, String fileName) async {
    List<MediaItem> mediaList = [];

    try {
      GetS3UrlAPIRes getS3UrlAPIRes = await GetS3UrlAPI().getUrl(
          fileName: fileName.contains('.') ? fileName : "filename.$fileType",
          mimeType: fileType == 'mp3'
              ? 'application/octet-stream'
              : fileType == 'pdf'
                  ? 'application/pdf'
                  : fileType == 'mp4' ? memeType ??  'application/octet-stream'
                  : 'application/octet-stream',
          fileType: fileType == 'pdf' || fileType == 'mp3'
              ? 'file'
              : fileType == 'mp4'
                  ? 'video'
                  : fileType);
      if (getS3UrlAPIRes.success) {
        mediaList.add(
          MediaItem(
            url: getS3UrlAPIRes.data.fileUrl,
            thumbnailUrl: getS3UrlAPIRes.data.fileUrl,
            name: getS3UrlAPIRes.data.fileName,
          ),
        );
        await UploadMediaToS3API().upload(null, mediaBytes,
            getS3UrlAPIRes.data.preSignedUrl, 'application/octet-stream');
        return generateResponse(mediaList);
      } else {
        return generateResponse(mediaList,
            responseCode: 300, responseMessage: getS3UrlAPIRes.message);
      }
    } catch (e) {
      print(e);
      return generateResponse(mediaList,
          responseCode: 400, responseMessage: Strings.someThingWentWrong);
    }
  }

  getS3UrlForImagesAndReturnJson(
      List<PlatformFile> listFiles, List<FileBytesModel> listBytes) async {
    List<MediaItem> mediaList = [];
    try {
      if (listFiles != null && listFiles.isNotEmpty) {
        for (PlatformFile file in listFiles) {
          GetS3UrlAPIRes getS3UrlAPIRes = await GetS3UrlAPI().getUrl(
              fileName: "filename.${file.extension}",
              mimeType: getMimeType(
                  file.bytes ?? await File(file.path).readAsBytes()),
              fileType: 'image');
          if (getS3UrlAPIRes.success) {
            mediaList.add(
              MediaItem(
                url: getS3UrlAPIRes.data.fileUrl,
                thumbnailUrl: getS3UrlAPIRes.data.fileUrl,
                name: getS3UrlAPIRes.data.fileName,
              ),
            );
            await UploadMediaToS3API().upload(
                file,
                null,
                getS3UrlAPIRes.data.preSignedUrl,
                getMimeType(file.bytes ?? await File(file.path).readAsBytes()));
          } else {
            return generateResponse(mediaList,
                responseMessage: getS3UrlAPIRes.message, responseCode: 300);
          }
        }
      } else {
        for (FileBytesModel file in listBytes) {
          GetS3UrlAPIRes getS3UrlAPIRes = await GetS3UrlAPI().getUrl(
              fileName: file.name,
              mimeType: getMimeType(file.bytes),
              fileType: 'image');
          if (getS3UrlAPIRes.success) {
            mediaList.add(
              MediaItem(
                url: getS3UrlAPIRes.data.fileUrl,
                thumbnailUrl: getS3UrlAPIRes.data.fileUrl,
                name: getS3UrlAPIRes.data.fileName,
              ),
            );
            await UploadMediaToS3API().upload(null, file.bytes,
                getS3UrlAPIRes.data.preSignedUrl, getMimeType(file.bytes));
          } else {
            return generateResponse(mediaList,
                responseMessage: getS3UrlAPIRes.message, responseCode: 300);
          }
        }
      }

      return generateResponse(mediaList);
    } catch (e) {
      print(e);
      return generateResponse(mediaList,
          responseCode: 400, responseMessage: Strings.someThingWentWrong);
    }
  }

  String getMimeType(Uint8List bytes) {
    // JPEG
    if (bytes.length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xD8) {
      return 'image/jpeg';
    }
    // PNG
    else if (bytes.length >= 8 &&
        bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4E &&
        bytes[3] == 0x47 &&
        bytes[4] == 0x0D &&
        bytes[5] == 0x0A &&
        bytes[6] == 0x1A &&
        bytes[7] == 0x0A) {
      return 'image/png';
    } else {
      return 'application/octet-stream'; // Default to binary/octet-stream if MIME type is unknown
    }
  }

  String generateResponse(List<MediaItem> mediaList,
      {int responseCode = 200,
      String responseMessage = 'Media uploaded successfully'}) {
    // Create the response map
    Map<String, dynamic> response = {
      'action': 'post/upload',
      'meta': {'code': responseCode, 'message': responseMessage},
      'data': mediaList.map((mediaItem) => mediaItem.toJson()).toList(),
    };

    // Convert the map to JSON string and return

    //print("<=========== CONVERT MAP TO JSON UPLOAD GCS =================>");
    //print(json.encode(response));
    return json.encode(response);
  }
}

class MediaItem {
  String url;
  String thumbnailUrl;
  String name;
  int size;

  MediaItem({this.url, this.thumbnailUrl, this.name, this.size});

  // Method to convert MediaItem to JSON
  Map<String, dynamic> toJson() {
    return {
      'url': url,
      'thumbnail_url': thumbnailUrl,
      'name': name,
      'size': size,
    };
  }
}
