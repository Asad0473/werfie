import 'dart:async';
import 'dart:io';

import 'package:bottom_picker/bottom_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/main.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/create_post_mobile.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/screens/spaces/spaces_webview_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/widgets/custom_adwidget.dart';
import 'package:werfieapp/widgets/loading_widgets/list_view_loading_shimmer.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/thread_post_card.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_PostWeb.dart';

import '../components/input_field.dart';
import '../components/rounded_button.dart';
import '../models/chatUserModel.dart';
import '../models/create_post_model/create_post_model.dart';
import '../models/topic_model/suggested_following_topic_model.dart';
import '../network/apis/spaces/create_space_api.dart';
import '../network/apis/spaces/get_spaces_api.dart';
import '../network/controller/share_via_direct_message_controller.dart';
import '../network/controller/topic_controller.dart';
import '../utils/font.dart';
import '../utils/loading_dialog_builder.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../utils/strings.dart';
import '../utils/urls.dart';
import '../utils/utils_methods.dart';
import '../web_views/dialogbox_web.dart';
import '../widgets/choice_chip_widget.dart';
import '../widgets/custom_adwidget_web.dart';
import '../widgets/main_drawer.dart';
import '../widgets/new_message_dialog.dart';
import '../widgets/text/NoResponseFromServerTextWidget.dart';

// ignore: must_be_immutable
class NewsFeed extends StatefulWidget {
  int adIndex = 0;
  NewsfeedController controller;
  String postId;
  String profileId;
  bool isPullToRefresh = false;
  Post post;

  bool newsFeedCheck = false;

  NewsFeed({this.controller, this.postId, this.profileId, this.post});

  static const routeName = '\NewsFeedMobile';
  int num = 0;

  @override
  State<NewsFeed> createState() => _NewsFeedState();
}

class _NewsFeedState extends State<NewsFeed> with TickerProviderStateMixin {
  final DummyData dataController = Get.put(DummyData());

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  String link, linkTitle, linkMeta, linkImage;

  //List<Widget> data ;
  List<Tab> listTabViewTitles = [
    Tab(text: Strings.forYou),
    Tab(text: Strings.following),
  ];
  int initPosition = 0;
  TabController tabController;

  bool isTabsLoaded = false;
  TopicController topicController = Get.put(TopicController());
  Future<FollowingAndSuggestedTopics> suggestedTopics;
  String url="";
  String profilePicUrl='https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png';

  @override
  void initState() {
    //data = [tabForYou(),tabFollowing()];
    //data.add(tabForYou());
    //data.add(tabForYou());
    addNewsFeedMetaTags();

     suggestedTopics= topicController.suggestedTopic();
    tabController = TabController(length: 2, vsync: this);
    super.initState();
  }

  addNewsFeedMetaTags(){
    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleHome,
        metaTagDescription: MetaTagValues.newsFeedMetaDescription,
        metaTagKeywords: MetaTagValues.newsFeedMetaKeywords,
        ogTitle: MetaTagValues.newsFeedOGTitle,
        ogDescription: MetaTagValues.newsFeedOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }
  _handleTabSelection() {
    if (tabController.indexIsChanging) {
      LoggingUtils.printValue("TAB BAR INDEX", tabController.index);

      if (tabController.index == 2) {
        if (widget.controller.postListOne.isEmpty) {
          widget.controller.getPostListOne(
              postListID: widget.controller.languageData.pinnedLists.first.id);
        }
      } else if (tabController.index == 3) {
        if (widget.controller.postListTwo.isEmpty) {
          widget.controller.getPostListTwo(
              postListID: widget.controller.languageData.pinnedLists[1].id);
        }
      } else if (tabController.index == 4) {
        if (widget.controller.postListThree.isEmpty) {
          widget.controller.getPostListThree(
              postListID: widget.controller.languageData.pinnedLists[2].id);
        }
      } else if (tabController.index == 5) {
        if (widget.controller.postListFour.isEmpty) {
          widget.controller.getPostListFour(
              postListID: widget.controller.languageData.pinnedLists[3].id);
        }
      } else if (tabController.index == 6) {
        if (widget.controller.postListFive.isEmpty) {
          widget.controller.getPostListTwo(
              postListID: widget.controller.languageData.pinnedLists[4].id);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!isTabsLoaded) {
      if (widget.controller.languageData != null) {
        if (widget.controller.languageData.pinnedLists != null &&
            widget.controller.languageData.pinnedLists.isNotEmpty) {
          widget.controller.languageData.pinnedLists.forEach((element) {
            listTabViewTitles.add(Tab(
              text: element.name,
            ));
          });
        }
        isTabsLoaded = true;

        LoggingUtils. printValue(
            "TAB VIEW LIST COUNT", listTabViewTitles.length);
        tabController = TabController(
          length: widget.controller.languageData != null &&
                  widget.controller.languageData.pinnedLists != null &&
                  widget.controller.languageData.pinnedLists.isNotEmpty
              ? widget.controller.languageData.pinnedLists.length + 2
              : 2,
          vsync: this,
          initialIndex: 0,
        );
        tabController.addListener(_handleTabSelection);
      }
    }

    if (widget.controller.languageData != null) {}
    if (widget.postId != null) {
    } else if (widget.profileId != null) {
    } else {}
    return Scaffold(
        key: _scaffoldKey,
        appBar: kIsWeb
            ? MediaQuery.of(context).size.width >= 500
                ? PreferredSize(
                    preferredSize: Size(0.0, 0.0),
                    child: Container(),
                  )
                : AppBar(
                    leading: widget.controller.userProfile == null
                        ? SizedBox(
                            width: 24,
                            child: Center(
                              child: SpinKitCircle(
                                color: Colors.grey,
                                size: 40,
                              ),
                            ),
                          )
                        : GestureDetector(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(40),
                                child: FadeInImage(
                                  fit: BoxFit.cover,
                                  width: 30,
                                  height: 30,
                                  placeholder: const AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  image: NetworkImage(widget
                                          .controller.userProfile.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                ),
                              ),
                            ),
                          ),
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    iconTheme: const IconThemeData(
                      color: Color(0xFF4f515b),
                    ),
                    centerTitle: true,
                    title: SizedBox(
                      height: 40,
                      width: 100,
                      child: Image.asset(
                        Theme.of(context).brightness == Brightness.dark?
                        AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,

                        // color: Color((0xFF47b867)),
                      ),
                    ),
                    actions: [
                      MediaQuery.of(context).size.width > 500
                          ? const SizedBox()
                          : InkWell(
                              onTap: () {
                                notifi.value = 0;
                                notifi.refresh();
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        SearchScreen(),
                                  ),
                                );
                              },
                              child: const Padding(
                                padding: EdgeInsets.only(right: 12.0),
                                child: Icon(Icons.search),
                              )),
                    ],
                    automaticallyImplyLeading:
                        !Responsive.isDesktop(context) ? true : false,
                  )
            : AppBar(
                leading: GestureDetector(
                  onTap: () {
                    Scaffold.of(context).openDrawer();
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 10),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(40),
                      child: FadeInImage(
                        fit: BoxFit.cover,
                        width: 30,
                        height: 30,
                        placeholder: const AssetImage(
                            'assets/images/person_placeholder.png'),
                        image: NetworkImage(widget.controller.userProfile !=
                            null && widget.controller.userProfile
                            .profileImage !=
                            null
                            ? widget.controller.userProfile.profileImage
                            : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                      ),
                    ),
                  ),
                ),
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                iconTheme: const IconThemeData(
                  color: Color(0xFF4f515b),
                ),
                centerTitle: true,
                title: SizedBox(
                  height: 40,
                  width: 100,
                  child: Image.asset(
                    Theme.of(context).brightness == Brightness.dark?
                    AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,
                  ),
                ),
                actions: [
                  // MediaQuery.of(context).size.width >500?SizedBox() :
                  // GestureDetector(
                  //   onTap: (){
                  //
                  //     return showDialog<void>(
                  //       context: context,
                  //       barrierDismissible: true, // user must tap button!
                  //       builder: (BuildContext context) {
                  //         return AlertDialog(
                  //           contentPadding: EdgeInsets.zero,
                  //           titlePadding:EdgeInsets.zero ,
                  //
                  //           content: GetBuilder<NewsfeedController>(builder: (controller) {
                  //             return Padding(
                  //               padding: const EdgeInsets.all(8.0),
                  //               child: Container(
                  //                 decoration: BoxDecoration(
                  //                   borderRadius: BorderRadius.circular(15),
                  //                   color: Colors.white,
                  //                 ),
                  //
                  //                 height: 250,
                  //                 width: 350,
                  //
                  //                 child: Padding(
                  //                   padding: const EdgeInsets.all(8.0),
                  //                   child: Column(
                  //                     crossAxisAlignment: CrossAxisAlignment.start,
                  //                     children: [
                  //                       Align(
                  //
                  //                         // alignment:
                  //                         child: GestureDetector(
                  //                           onTap:(){
                  //                   Navigator.pop(context);
                  //                 },
                  //                           child: Icon(
                  //                             Icons.cancel,
                  //                           ),
                  //                         ),
                  //                           alignment:Alignment.topRight,
                  //                       ),
                  //                       Text(
                  //                         "App Language",
                  //
                  //                         style: TextStyle(
                  //                           color: controller.displayColor,
                  //                           fontSize: 15,
                  //
                  //                         ),
                  //                       ),
                  //                       SizedBox(
                  //                         height: 5,
                  //                       ),
                  //                       SizedBox(
                  //                         height: 40,
                  //                         child: FormField<String>(
                  //
                  //                           builder: (FormFieldState<String> state) {
                  //                             return InputDecorator(
                  //                               decoration: InputDecoration(
                  //                                 fillColor: Colors.transparent,
                  //                                 focusColor: Colors.transparent,
                  //                                 contentPadding: EdgeInsets.only(
                  //                                     bottom: 5,
                  //                                     top: 2,
                  //                                     left: 15,
                  //                                     right: 2),
                  //                                 // labelText: "hi",
                  //                                 // labelStyle: textStyle,
                  //                                 // labelText: _dropdownValue == null
                  //                                 //     ? 'Where are you from'
                  //                                 //     : 'From',
                  //                                 hintText: "Community Name",
                  //
                  //                                 enabledBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1, color: Colors.grey
                  //
                  //                                   ),
                  //                                   borderRadius: BorderRadius.circular(60),
                  //
                  //                                 ),
                  //
                  //                                 focusedBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1,
                  //                                       color: Colors.blue
                  //                                   ), //<-- SEE HERE
                  //                                 ),
                  //
                  //                               ),
                  //                               child: DropdownButtonHideUnderline(
                  //
                  //                                 child: DropdownButton<AppLanguage>(
                  //
                  //                                   // borderRadius: BorderRadius.circular(20),
                  //                                   focusColor: Colors.transparent,
                  //
                  //                                   iconEnabledColor: controller.displayColor,
                  //                                   menuMaxHeight: 200,
                  //
                  //                                   value: controller.dropdownValue,
                  //                                   style: TextStyle(
                  //                                     color: Colors.black,
                  //                                   ),
                  //                                   // hint: Text(
                  //                                   //   "Select Bank",
                  //                                   //   style: TextStyle(
                  //                                   //     color: Colors.grey,
                  //                                   //     fontSize: 16,
                  //                                   //     fontFamily: "verdana_regular",
                  //                                   //   ),
                  //                                   // ),
                  //                                   onChanged: (AppLanguage value) {
                  //
                  //
                  //
                  //                                     print("controller.languageData ${controller.languageData.myLang.name}");
                  //
                  //
                  //
                  //
                  //
                  //                                     Navigator.pop(context);
                  //                                     controller.dropdownValue = value;
                  //
                  //
                  //
                  //
                  //                                     controller.languagesRequest(languageId: controller.selectedLanguage != null ? controller.selectedLanguage.id.toString() : 1.toString(), autoTranslate: 1.toString(),
                  //                                         appLanguageId: controller.dropdownValue.id,
                  //                                         appLanguage: controller.dropdownValue.name,
                  //                                         appLanguageCode: controller.dropdownValue.code);
                  //
                  //
                  //
                  //
                  //
                  //                                   print('heheheheheheeh');
                  //                                   Get.delete<
                  //                                       NewsfeedController>();
                  //                                   if (kIsWeb) {
                  //                                     Get.offNamed(FluroRouters.mainScreen);
                  //
                  //                                   } else {
                  //                                     Get.offUntil(
                  //                                         MaterialPageRoute(
                  //                                           builder: (context) =>
                  //                                               Session(),
                  //                                         ),
                  //                                             (route) => false);
                  //                                   }
                  //
                  //                                     print( controller.dropdownValue.name);
                  //                                     controller.update();
                  //                                   },
                  //                                   items:controller.languagesList.map((AppLanguage language) {
                  //                                     return new DropdownMenuItem<AppLanguage>(
                  //                                       value: language,
                  //                                       child: Row(
                  //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //                                         children: [
                  //                                           new Text(
                  //                                             language.name,
                  //                                             style: new TextStyle(color: Colors.black),
                  //                                           ),
                  //
                  //                                         ],
                  //                                       ),
                  //                                     );
                  //                                   }).toList(),
                  //                                   isExpanded: false,
                  //                                   isDense: true,
                  //
                  //
                  //                                 ),
                  //                               ),
                  //                             );
                  //                           },
                  //                         ),
                  //                       ),
                  //                       Padding(
                  //                         padding: const EdgeInsets.all(8.0),
                  //                         child: Divider(),
                  //                       ),
                  //                       Text(
                  //                         "Translation Language",
                  //
                  //                         style: TextStyle(
                  //                           color: controller.displayColor,
                  //                           fontSize: 15,
                  //
                  //                         ),
                  //                       ),
                  //                       SizedBox(
                  //                         height: 5,
                  //                       ),
                  //                       SizedBox(
                  //                         height: 40,
                  //                         child: FormField<String>(
                  //
                  //                           builder: (FormFieldState<String> state) {
                  //                             return InputDecorator(
                  //                               decoration: InputDecoration(
                  //                                 fillColor: Colors.transparent,
                  //                                 focusColor: Colors.transparent,
                  //                                 contentPadding: EdgeInsets.only(
                  //                                     bottom: 5,
                  //                                     top: 2,
                  //                                     left: 15,
                  //                                     right: 2),
                  //                                 // labelText: "hi",
                  //                                 // labelStyle: textStyle,
                  //                                 // labelText: _dropdownValue == null
                  //                                 //     ? 'Where are you from'
                  //                                 //     : 'From',
                  //                                 hintText: "Community Name",
                  //
                  //                                 enabledBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1, color: Colors.grey
                  //
                  //                                   ),
                  //                                   borderRadius: BorderRadius.circular(60),
                  //
                  //                                 ),
                  //
                  //                                 focusedBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1,
                  //                                       color: Colors.blue
                  //                                   ), //<-- SEE HERE
                  //                                 ),
                  //
                  //                               ),
                  //                               child: DropdownButtonHideUnderline(
                  //
                  //                                 child: DropdownButton<AppLanguage>(
                  //
                  //
                  //                                   // borderRadius: BorderRadius.circular(20),
                  //                                   focusColor: Colors.transparent,
                  //
                  //                                   iconEnabledColor: controller.displayColor,
                  //                                   menuMaxHeight: 200,
                  //
                  //                                   value: controller.dropdownValue1,
                  //                                   style: TextStyle(
                  //                                     color: Colors.black,
                  //                                   ),
                  //                                   // hint: Text(
                  //                                   //   "Select Bank",
                  //                                   //   style: TextStyle(
                  //                                   //     color: Colors.grey,
                  //                                   //     fontSize: 16,
                  //                                   //     fontFamily: "verdana_regular",
                  //                                   //   ),
                  //                                   // ),
                  //                                   onChanged: (AppLanguage value) {
                  //                                     Navigator.pop(context);
                  //                                     controller.dropdownValue1 = value;
                  //
                  //                                     // controller.selectedLanguage =  controller.dropdownValue1.id;
                  //                                     if (controller.isAutoTranslate) {
                  //                                       controller.languagesRequest(languageId:    controller.dropdownValue1 != null ?    controller.dropdownValue1.id.toString() : 1.toString(), autoTranslate: 1.toString());
                  //                                       // controller.postList =await controller.getNewsFeed(reload: true);
                  //                                       // controller.languageData =await controller.getLanguages();
                  //                                       // // await controller.get
                  //                                       // controller.isLanguageSettings =false;
                  //                                       //     controller.isProfileLanguagetype = false;
                  //                                       //     controller.isNewsFeedScreen =true;
                  //                                       //     controller.isSettingsScreen =false;
                  //
                  //                                       // MyApp.rebirth(context);
                  //                                       // controller.update();
                  //
                  //                                       // Future.delayed(
                  //                                       //     Duration(seconds: 2), () {
                  //
                  //
                  //                                     Get.delete<
                  //                                         NewsfeedController>();
                  //                                     if (kIsWeb) {
                  //                                       Get.offNamed(FluroRouters.mainScreen);
                  //
                  //                                     } else {
                  //                                       Get.offUntil(
                  //                                           MaterialPageRoute(
                  //                                             builder: (context) => Session(),
                  //                                           ),
                  //                                               (route) => false);
                  //                                     }
                  //                                     // Navigator.of(context)
                  //                                     //     .pushAndRemoveUntil(
                  //                                     //         MaterialPageRoute(
                  //                                     //             builder:
                  //                                     //                 (context) =>
                  //                                     //                     Session()),
                  //                                     //         (Route<dynamic>
                  //                                     //                 route) =>
                  //                                     //             false);
                  //                                     // });
                  //                                     // Phoenix.rebirth(context);
                  //
                  //                                     }
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //                                     print( controller.dropdownValue1.name);
                  //                                     controller.update();
                  //                                   },
                  //                                   items:controller.translationLanguage.map((AppLanguage language) {
                  //                                     return new DropdownMenuItem<AppLanguage>(
                  //
                  //                                       value: language,
                  //                                       child: Row(
                  //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //                                         children: [
                  //                                           new Text(
                  //                                             language.name,
                  //                                             style: new TextStyle(color: Colors.black),
                  //                                           ),
                  //                                           // controller.languageData.myLang.name == language.name?
                  //                                           // Icon(
                  //                                           //     Icons.check
                  //                                           // ):SizedBox(),
                  //                                         ],
                  //                                       ),
                  //                                     );
                  //                                   }).toList(),
                  //                                   isExpanded: false,
                  //                                   isDense: true,
                  //
                  //
                  //                                 ),
                  //                               ),
                  //                             );
                  //                           },
                  //                         ),
                  //                       ),
                  //
                  //                     ],
                  //                   ),
                  //                 ),
                  //               ),
                  //             );
                  //           }),
                  //
                  //
                  //
                  //           // actions: <Widget>[
                  //           //   TextButton(
                  //           //     child: const Text('Approve'),
                  //           //     onPressed: () {
                  //           //       Navigator.of(context).pop();
                  //           //     },
                  //           //   ),
                  //           // ],
                  //         );
                  //       },
                  //     );
                  //
                  //   },
                  //   child: SvgPicture.asset(
                  //     AppImages.languageIcon,
                  //     height: 30,
                  //     width: 30,
                  //     color: widget.controller.displayColor,
                  //
                  //   ),
                  // ),
                  // SizedBox(width: 5,),

                  MediaQuery.of(context).size.width > 500
                      ? const SizedBox()
                      : InkWell(
                          onTap: () {
                            notifi.value = 0;
                            notifi.refresh();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    SearchScreen(),
                              ),
                            );
                          },
                          child: const Padding(
                            padding: EdgeInsets.only(right: 12.0),
                            child: Icon(Icons.search),
                          )),
                ],
                automaticallyImplyLeading:
                    !Responsive.isDesktop(context) ? true : false,
                bottom: TabBar(
                  controller: tabController,
                  isScrollable: true,
                  indicatorColor:
                      Get.isDarkMode ? MyColors.werfieBlue : Colors.white,
                  labelColor:
                      Get.isDarkMode ? Colors.white : MyColors.werfieBlue,
                  unselectedLabelColor:
                      Get.isDarkMode ? Colors.white : Colors.black26,
                  labelStyle:
                      const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  unselectedLabelStyle:
                      const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                  indicatorWeight: 2,
                  labelPadding: const EdgeInsets.symmetric(horizontal: 8),
                  indicator:  RoundedTabIndicator(
                    indicatorWidth: 50, // Adjust this value for indicator width
                    indicatorHeight: 5, // Adjust this value for indicator height
                    cornerRadius: 5, // Adjust this value for desired rounded corners
                    color:widget.controller.displayColor , // Adjust this value for desired color
                  ),
                  dividerColor:
                      Get.isDarkMode ? MyColors.werfieBlue : Colors.white,
                  tabs: listTabViewTitles,
                ),
              ),
        drawer: Responsive.isDesktop(context)
            ? MainDrawer(widget.controller)
            : Container(),
        drawerEnableOpenDragGesture:
            !Responsive.isDesktop(context) ? false : true,
        floatingActionButton: kIsWeb
            ? MediaQuery.of(context).size.width >= 500
                ? SizedBox()
                : getFAB()
            : getFAB(),
        body: body());
  }

  Widget getFAB() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FloatingActionButton(
          backgroundColor: MyColors.werfieBlue,
          heroTag: UniqueKey(),
          onPressed: _toggleExpand,
          child: Icon(
            widget.controller.isFABExpanded ? Icons.close : Icons.add,
            color: Colors.white,
          ),
        ),
        SizedBox(
          height: 16,
        ),
        if (widget.controller.isFABExpanded) ...[
          FloatingActionButton(
            heroTag: UniqueKey(),
            onPressed: () {
              widget.controller.modelList2 = [];

              widget.controller.modelList2.add(ModelClass.fromJson({
                'body': '',
                'poll_ques_first': null,
                'poll_ques_first': null,
                'poll_ques_third': null,
                'poll_ques_fourth': null,
                //  selectType: "Public",
                'files': [],
                'link_meta': '',
                'link': '',
                'link_image': '',
                'link_title': '',
                'days': '',
                'minutes': '',
                'hours': '',
                'location': '',
                'lat': '',
                'lng': '',
                'poll_thread': false,
                'type':
                    widget.controller.modelList2.length < 2 ? 'post' : 'thread'
              }));

              //   widget.controller. indexOfText();
              // print('list of ');
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (BuildContext context) =>
                      CreatePostMobile(widget.controller),
                ),
              );
            },
            backgroundColor: widget.controller.displayColor,
            child: Icon(
              Icons.add,
              color: Colors.white,
            ),
          ),
          SizedBox(
            height: 16,
          ),
          FloatingActionButton(
            heroTag: UniqueKey(),
            onPressed: () => _showBottomSheet(context),
            backgroundColor: widget.controller.displayColor,
            child: Icon(
              Icons.star,
              color: Colors.white,
            ),
          /*  child:SvgPicture.asset(
              'assets/svg_drawer_icons/spaces.svg',
              color:  Colors.black,
            ),*/
          )
        ]
      ],
    );
  }

  void _showBottomSheetCreate(BuildContext context) {
    TextEditingController spaceNameController = TextEditingController();
    String selectedateTime = DateTime.now().toString();
    String selectedOption = 'instant';
    int selectedChipIndex = 0; // Index of the selected chip
    String selectedTopics = '';

    FollowingAndSuggestedTopics model;
    showModalBottomSheet(
        context: context,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
        ),
        builder: (BuildContext context) {
          return StatefulBuilder(
            builder: (context, setState) {
              return Container(
                padding: EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            'Create your space',
                            style: TextStyle(
                              fontSize: 20.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.help_outline),
                            color: Colors.blue,
                            onPressed: () {
                              // Handle the question mark icon tap
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 20.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            child: RadioListTile<String>(
                              title: Text(
                                'Instant',
                                style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              value: 'instant',
                              groupValue: selectedOption,
                              onChanged: (value) {
                                setState(() {
                                  selectedOption = value;
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: RadioListTile<String>(
                              title: Text(
                                'Schedule',
                                style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              value: 'schedule',
                              groupValue: selectedOption,
                              onChanged: (value) {
                                setState(() {
                                  selectedOption = value;
                                  selectedateTime = DateTime.now().toString();
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      Text(
                        'Name your space',
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      TextField(
                        controller: spaceNameController,
                        decoration: InputDecoration(
                            hintText: 'What do you want to talk about?',
                            hintStyle: TextStyle(fontSize: 14)),
                      ),
                      SizedBox(height: 16.0),

                      selectedOption == "schedule"
                          ? InkWell(
                        onTap: (){
                          BottomPicker.dateTime(
                            title: "Schedule your space",
                            description: "Watch party, let go",
                            titleAlignment:
                            CrossAxisAlignment.start,

                            titleStyle: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                                color: Colors.black),
                            onSubmit: (date) {
                              print(date);
                              selectedateTime = date.toString();
                            },
                            onClose: () {
                              print("Picker closed");
                            },
                            buttonText: 'Confirm',
                            buttonTextStyle: const TextStyle(
                                color: Colors.white),
                            buttonSingleColor: Colors.blue,
                            minDateTime: DateTime.now(),

                            // minDateTime:  DateTime(2021, 5, 1),
                            // maxDateTime:  DateTime(2021, 8, 2),
                          ).show(context);

                        },
                        child: Row(children: [
                          Expanded(
                            child: Text(
                              // 'Select up to 3 topics',
                              UtilsMethods.dateTimeFormat(selectedateTime.toString(),"MMMM dd, yyyy hh:mm a") ,
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.calendar_month),
                            color: Colors.blue,
                            onPressed: () {
                              // Handle the question mark icon tap
                            },
                          )

                        ],),
                      ):SizedBox.shrink(),

                      SizedBox(height: 16.0),
                      Text(
                        // 'Select up to 3 topics',
                        'Select Topic',
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      FutureBuilder(
                          future: suggestedTopics,
                          builder: (context, dataSnapshot) {
                            if (dataSnapshot.connectionState ==
                                ConnectionState.waiting) {
                              return Center(
                                child: CircularProgressIndicator(),
                              );
                            } else {
                              if (dataSnapshot.error != null) {
                                print(dataSnapshot.error);
                                return Center(
                                  child: Text(
                                      'Oops…Something went wrong! Please try again'),
                                );
                              } else {
                                model = dataSnapshot.data;

                                return Wrap(
                                  spacing: 10.0,
                                  children: List.generate(
                                    model.data.suggestedTopics.length,
                                    // You can change this to the number of topics available
                                        (index) {

                                      return Padding(
                                        padding: const EdgeInsets.all(0.0),
                                        child: ChoiceChip(
                                          label: Text('${model.data.suggestedTopics[index].topic}'),
                                          selected: selectedChipIndex == index,
                                          //// Set selected status accordingly
                                          selectedColor: Colors.blue,
                                          onSelected: (selected) {
                                            // Handle chip selection here
                                            if (selected) {
                                              setState(() {
                                                selectedChipIndex = index;
                                                selectedTopics = model.data.suggestedTopics[selectedChipIndex].topic;
                                              });
                                            }
                                          },
                                        ),
                                      );
                                    },
                                  ),
                                );
                              }
                            }
                          }),
                      SizedBox(height: 16.0),
                      Row(
                        children: [
                          Expanded(
                            child: Container(
                              height: 30,
                              margin: EdgeInsets.all(16.0),
                              child: ElevatedButton(
                                onPressed: () {
                                  // Add functionality for the round shape button here
                                  if (spaceNameController.text.isEmpty) {
                                    Fluttertoast.showToast(
                                        msg: Strings.pleaseEnterTheSpaceName,
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 1,
                                        backgroundColor: Colors.red,
                                        textColor: Colors.white,
                                        fontSize: 16.0);
                                    return;
                                  } else {
                                  createSpaceApiCall(context,
                                        name: spaceNameController.text,
                                        type: selectedOption,
                                        controller: widget.controller,
                                        startTime: selectedateTime,
                                        topicIds: model.data.suggestedTopics[selectedChipIndex].id.toString());
                                  }
                                },
                                child: Text('Create Space'),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30.0),
                                  ),
                                ),
                              ),
                            ),
                          ),

                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        });
  }

  void _showCustomDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return CustomDialog(
          title: 'Custom Dialog Title',
          content: 'This is the content of the custom dialog.',
          onClose: () {
            Navigator.of(context).pop(); // Close the dialog
          },
        );
      },
    );
  }

  void _showBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Set to true for a full-screen bottom sheet
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      builder: (BuildContext context) {
        return FutureBuilder(
            future: GetSpacesAPI().getSpaces(widget.controller.userProfile.userId),
            builder: (context, dataSnapshot) {
              if (dataSnapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: CircularProgressIndicator(),
                );
              } else {
                if (dataSnapshot.error != null) {
                  return Center(
                    child: Text('Oops…Something went wrong! Please try again'),
                  );
                } else {
                  GetSpacesAPIRes model = dataSnapshot.data;

                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0,vertical: 60),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            IconButton(
                              icon: Icon(Icons.close),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            SizedBox(width: kIsWeb?MediaQuery.of(context).size.width * 0.10:MediaQuery.of(context).size.width *0.35,height: MediaQuery.of(context).size.height * 0.05,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(

                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        25.0), // Adjust as needed
                                  ),
                                  primary: MyColors.werfieBlue,
                                ),
                                onPressed: () {
                                  // Action when the button is pressed
                                  // print('Button pressed for ${items[index]}');
                                  _showBottomSheetCreate(context);

                                },
                                child: Text(
                                  'Create Space',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          'Watch party, let go',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 20),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Expanded(
                            child: ListView.builder(
                          itemCount: model.data.length,
                          itemBuilder: (context, index) {
                            return  Card(
                              margin: EdgeInsets.all(16.0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              elevation: 4.0,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15.0),
                                child: Container(
                                  padding: EdgeInsets.symmetric(vertical: 30,horizontal: 10),
                                  decoration: BoxDecoration(
                                    gradient: index % 2 == 0
                                        ?  LinearGradient(
                                      colors: [MyColors.werfieBlue.withOpacity(0.3), Colors.blue.shade100], // Replace with your desired colors
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ) : LinearGradient(
                                      colors: [Colors.red.withOpacity(0.3), Colors.orange.shade100], // Gradient for odd indexed items
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                  ),
                                  child: ListTile(
                                    contentPadding: EdgeInsets.all(10),
                                    leading: Container(
                            width: 50.0, // Set your desired width
                            height: 50.0, // Set your desired height
                            child: Visibility(
                                      visible:  !(widget.controller.userProfile.userId.toString() == model.data[index].userId.toString()
                                          && model.data[index].endTime == null
                                          && model.data[index].type == "schedule"),
                                      child: Image.asset(
                                        "assets/images/live.gif",

                                      ),
                                    ),),
                                    title: Text(
                                      model.data[index].name,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,fontSize: 16,color: Colors.white),
                                    ),
                                    subtitle: Text(
                                      model.data[index].type,style: TextStyle(
                                        fontWeight: FontWeight.w400,fontSize: 14,color: Colors.white),),
                                    trailing:model.data[index].endTime==null? SizedBox(width:  kIsWeb?MediaQuery.of(context).size.width *0.05:MediaQuery.of(context).size.width *0.25,height: MediaQuery.of(context).size.height * 0.05,
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(
                                                25.0), // Adjust as needed
                                          ),
                                          primary: Colors.black.withOpacity(0.7),
                                        ),
                                        onPressed: () async {
                                          // Action when the button is pressed

                                           profilePicUrl = widget
                                              .controller.userProfile
                                              .profileImage != null
                                              ? widget.controller.userProfile
                                              .profileImage
                                              : 'https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png';
                                           url = '${Url
                                              .spaceStagingUrl}join?space_id=${model
                                              .data[index]
                                              .id}&user_id=${widget.controller
                                              .userProfile
                                              .userId}&first_name=${widget
                                              .controller.userProfile
                                              .firstname}&last_name=${widget
                                              .controller.userProfile
                                              .lastname}&profile_picture_url=${profilePicUrl}?hmac=2qrt5LEJcx2B__YaKzZG3LV4EOpUqlanRy-CxdifXjE';

                                          if(Platform.isIOS) {


                                            final Uri uri = Uri.parse(url);

                                            if (await canLaunchUrl(uri)) {
                                              await launchUrl(uri,
                                                  webOnlyWindowName: '_blank');
                                            } else {
                                              throw 'Could not launch $url';
                                            }
                                          }else {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (BuildContext context) => SpacesWebviewScreen(url: url,),
                                              ),
                                            );
                                          }
                                        },
                                        child: Text( widget.controller.userProfile.userId.toString() == model.data[index].userId.toString()
                                            && model.data[index].endTime == null
                                            && model.data[index].type == "schedule" ? 'Start' : 'Join'),
                                      ),
                                    ):SizedBox.shrink(),
                                  ),
                                ),
                              ),
                            );

                          },
                        )),
                      ],
                    ),
                  );
                }
              }
            });
      },
    );
  }
  createSpaceApiCall(
      BuildContext context,{String name,String type,String startTime,String topicIds,NewsfeedController controller,
      }) async {
    try {
      DialogBuilder(context).showLoadingIndicator();

      CreateSpaceAPIRes response = await CreateSpaceAPI()
          .createSpace(name: name,type: type,startTime: startTime,topicIds: topicIds);

      if (response.success) {
        DialogBuilder(context).hideOpenDialog();
        Fluttertoast.showToast(
            msg: Strings.createSpaceSuccessfully,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);

        Navigator.pop(context);
        String profilePicUrl = controller
            .userProfile.profileImage !=
            null
            ? controller.userProfile
            .profileImage
            : 'https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png';
         url = '${Url
            .spaceStagingUrl}join?space_id=${response.data.data.first
            .id}&user_id=${controller
            .userProfile
            .userId}&first_name=${controller
            .userProfile
            .firstname}&last_name=${controller
            .userProfile
            .lastname}&profile_picture_url=${profilePicUrl}?hmac=2qrt5LEJcx2B__YaKzZG3LV4EOpUqlanRy-CxdifXjE';

        _startMeetingDialog(context,url,controller,response.data.data[0].id);




      } else {
        DialogBuilder(context).hideOpenDialog();


        Fluttertoast.showToast(
            msg: response.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        return;
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
      Fluttertoast.showToast(
          msg: e.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return;

      // TODO
    }
  }
  void _startMeetingDialog(BuildContext context,String url, NewsfeedController controller,int spaceId) {
    TextEditingController urlController = TextEditingController();
    urlController.text=url;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 500.0, // Set the desired maximum width here
              maxHeight: 500.0, // Set the desired maximum width here
              minHeight: 250.0, // Set the desired maximum width here
            ),
            child: Container(
              width: 300.0, // Set your desired width here
              height: 200.0, // Set your desired height here
              padding: EdgeInsets.all(16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Your space is ready",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                        ),
                      ),
                      IconButton(
                        icon: Icon(Icons.close),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ],
                  ),
                  SizedBox(height: 16.0),
                  TextField(
                    // enabled: true,
                    readOnly: true,
                    controller: urlController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      suffixIcon:  InkWell(
                          child: PopupMenuButton(
                              tooltip: "Share",
                              position: PopupMenuPosition.under,
                              padding: EdgeInsets.zero,

                              icon: Icon(Icons.share_outlined, size: 20, color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.grey,),


                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark ? Colors.black : Colors
                                  .white,
                              // Callback that sets the selected popup menu item.
                              onSelected: (value) async {
                                if (value == 2) {
                                  showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(10.0))),
                                            insetPadding: EdgeInsets.symmetric(
                                                horizontal: 0, vertical: 0),
                                            contentPadding: EdgeInsets.symmetric(
                                                horizontal: 12),
                                            content: DialogboxWeb(
                                              controller,
                                              controller.userProfile.profileImage,
                                              true,
                                              spaceURL:url,

                                              ShowPolls: false,
                                            ));
                                      });

                                  // Clipboard.setData(ClipboardData(text: url)).then((_) {
                                  //   Fluttertoast.showToast(
                                  //       msg: 'Space link copied successfully',
                                  //       toastLength:
                                  //       Toast.LENGTH_SHORT,
                                  //       gravity: ToastGravity.TOP,
                                  //       timeInSecForIosWeb:
                                  //       1,
                                  //       backgroundColor: controller.displayColor,
                                  //
                                  //       textColor: Colors.white,
                                  //       webPosition: "center",
                                  //       webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                  //       fontSize: 16.0);
                                  // });


                                }
                                else if (value == 3) {

                                  Clipboard.setData(ClipboardData(text: url)).then((_) {
                                    Fluttertoast.showToast(
                                        msg: 'Space link copied successfully',
                                        toastLength:
                                        Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.TOP,
                                        timeInSecForIosWeb:
                                        1,
                                        backgroundColor: controller.displayColor,

                                        textColor: Colors.white,
                                        webPosition: "center",
                                        webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                        fontSize: 16.0);
                                  });


                                }
                                else if (value == 4) {

                                  Share.share(url, subject: 'Join space');

                                }
                                else if (value == 5) {


                                  showDialog(
                                    context: context,
                                    builder:
                                        (BuildContext context) {
                                      List<ChatUserModel> filterListChatUserList = [];
                                      List<ChatUserModel> selectedUserList = [];
                                      TextEditingController messageController = TextEditingController();
                                      messageController.text=url;

                                      return StatefulBuilder(
                                        builder: (context, setState) {
                                          return Padding(
                                            padding: const EdgeInsets.symmetric(vertical: 40),
                                            child: AlertDialog(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                    BorderRadius.all(
                                                        Radius.circular(
                                                            10.0))),
                                                insetPadding:
                                                EdgeInsets.symmetric(
                                                    horizontal: 0,
                                                    vertical: 0),
                                                contentPadding:
                                                EdgeInsets.symmetric(
                                                    horizontal: 12),
                                                content: AspectRatio(
                                                  aspectRatio: 4 / 6,
                                                  child: SingleChildScrollView(
                                                    child: Column(
                                                        mainAxisSize: MainAxisSize.min,
                                                        children: <Widget>[
                                                          MouseRegion(
                                                            cursor: SystemMouseCursors.click,
                                                            child: GestureDetector(
                                                              onTap: () {
                                                                Navigator.pop(context);
                                                              },
                                                              child: Padding(
                                                                padding: const EdgeInsets
                                                                    .only(top: 20,

                                                                    left: 10),
                                                                child: Align(
                                                                  alignment: Alignment
                                                                      .topRight,
                                                                  child: Icon(
                                                                    Icons.close,
                                                                    size: 25,
                                                                    color: Theme.of(context).brightness == Brightness.dark
                                                                        ? Colors.white : Colors.black,

                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(height: 20,),
                                                          TextField(
                                                            style: LightStyles.baseTextTheme
                                                                .headline4.copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark ? Colors
                                                                  .white : Colors
                                                                  .black,
                                                              //fontWeight: FontWeight.w500,
                                                              // fontSize: 14,
                                                            ),
                                                            cursorColor: Theme
                                                                .of(context)
                                                                .brightness == Brightness.dark
                                                                ? Colors.white
                                                                : Colors
                                                                .black,
                                                            onTap: () {
                                                              // print("search tap called");
                                                            },
                                                            controller: controller
                                                                .searchTextForDM,
                                                            onChanged: (val) async {
                                                              if (val != null &&
                                                                  val.isNotEmpty) {
                                                                filterListChatUserList =
                                                                    controller.chatUserList
                                                                        .where((element) =>
                                                                    element.name != null &&
                                                                        element.name
                                                                            .toLowerCase()
                                                                            .contains(val
                                                                            .toLowerCase()))
                                                                        .toList();

                                                              } else {
                                                                filterListChatUserList = [];
                                                              }
                                                              setState(() {});
                                                            },
                                                            textAlignVertical: TextAlignVertical
                                                                .center,

                                                            decoration: InputDecoration(
                                                              filled: true,
                                                              hintText: Strings.search,
                                                              // border: InputBorder.none,
                                                              contentPadding: EdgeInsets.only(
                                                                  left: 0,
                                                                  bottom: 13,
                                                                  top: 0,
                                                                  right: 0),
                                                              hintStyle: LightStyles
                                                                  .baseTextTheme.headline3.copyWith(
                                                                color:Theme
                                                                    .of(context)
                                                                    .brightness ==
                                                                    Brightness.dark ? Colors
                                                                    .white60 : Colors
                                                                    .black45,
                                                              ),
                                                              prefixIcon: Icon(
                                                                Icons.search,
                                                                size: 20,
                                                                color: Theme
                                                                    .of(context)
                                                                    .brightness ==
                                                                    Brightness.dark
                                                                    ? Colors.white
                                                                    : Colors.black,
                                                              ),
                                                              border: OutlineInputBorder(
                                                                borderRadius: BorderRadius
                                                                    .circular(40),
                                                                borderSide: BorderSide(
                                                                    color: Colors.grey,
                                                                    width: 1),
                                                              ),

                                                              fillColor: Theme.of(context).brightness == Brightness.dark
                                                                  ? Colors.black54 : Color(0XFFeff3f4), //
                                                            ),
                                                          ),
                                                          SizedBox(height: 20,),
                                                          selectedUserList.isNotEmpty ?
                                                          SizedBox(
                                                            height: 40,
                                                            width: 800,
                                                            child: ListView.builder(
                                                                shrinkWrap: true,
                                                                scrollDirection: Axis
                                                                    .horizontal,
                                                                itemCount: selectedUserList
                                                                    .length,
                                                                itemBuilder: (context,
                                                                    index) {
                                                                  return Row(
                                                                    children: [
                                                                      ChoiceChipWidget(
                                                                          imageUrl: selectedUserList[index]
                                                                              .profileImage,
                                                                          name: selectedUserList[index]
                                                                              .name,
                                                                          onDelete: () {
                                                                            selectedUserList
                                                                                .removeAt(
                                                                                index);
                                                                            setState(() {});
                                                                          }),
                                                                      SizedBox(width: 5,)
                                                                    ],
                                                                  );
                                                                }),
                                                          ) :
                                                          SizedBox.shrink(),
                                                          SizedBox(height: 20,),
                                                          controller.isChatLoad
                                                              ? Center(
                                                            child: Padding(
                                                              padding: const EdgeInsets.only(
                                                                  top: 10.0),
                                                              child: CircularProgressIndicator(
                                                                color: MyColors.BlueColor,),
                                                            ),
                                                          )
                                                              : filterListChatUserList !=
                                                              null || filterListChatUserList
                                                              .isNotEmpty
                                                              ? Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment.start,
                                                            children: [

                                                              ///1st list
                                                              Column(
                                                                children: List.generate(
                                                                    filterListChatUserList
                                                                        .length, (index) {
                                                                  return Padding(
                                                                    padding: const EdgeInsets
                                                                        .only(
                                                                        top: 0.0,
                                                                        left: 0,
                                                                        right: 0),
                                                                    child: InkWell(
                                                                      onTap: () {
                                                                        if (!selectedUserList
                                                                            .contains(
                                                                            filterListChatUserList[index])) {
                                                                          selectedUserList
                                                                              .add(
                                                                              filterListChatUserList[index]);
                                                                          setState(() {});
                                                                        }
                                                                      },
                                                                      child: Card(
                                                                        elevation: 0.0,
                                                                        color: controller
                                                                            .highlighteTheChat ==
                                                                            index
                                                                            ? Theme
                                                                            .of(context)
                                                                            .brightness ==
                                                                            Brightness.dark
                                                                            ? Color(
                                                                            0xff202327)
                                                                            : Color(
                                                                            0xffeff3f4)
                                                                            : Colors
                                                                            .transparent,
                                                                        child: Padding(
                                                                            padding:
                                                                            const EdgeInsets
                                                                                .all(8.0),
                                                                            child:


                                                                            Row(
                                                                              crossAxisAlignment:
                                                                              CrossAxisAlignment
                                                                                  .start,
                                                                              children: [
                                                                                filterListChatUserList[index]
                                                                                    .conversationType !=
                                                                                    "group"
                                                                                    ?


                                                                                CircleAvatar(
                                                                                  backgroundImage:

                                                                                  filterListChatUserList[index]
                                                                                      .profileImage !=
                                                                                      null
                                                                                      ? NetworkImage(
                                                                                      filterListChatUserList[index]
                                                                                          .profileImage)
                                                                                      : AssetImage(
                                                                                      'assets/images/person_placeholder.png'),
                                                                                  radius: 22,
                                                                                )
                                                                                    : CircleAvatar(
                                                                                  backgroundImage: filterListChatUserList[index]
                                                                                      .groupImage !=
                                                                                      null
                                                                                      ? NetworkImage(
                                                                                      filterListChatUserList[index]
                                                                                          .groupImage)
                                                                                      : AssetImage(
                                                                                      'assets/images/person_placeholder.png'),
                                                                                  radius: 22,
                                                                                ),
                                                                                SizedBox(
                                                                                  width: 20,
                                                                                ),
                                                                                Expanded(
                                                                                  child: Column(
                                                                                    crossAxisAlignment:
                                                                                    CrossAxisAlignment
                                                                                        .start,
                                                                                    mainAxisAlignment:
                                                                                    MainAxisAlignment
                                                                                        .spaceEvenly,
                                                                                    children: [
                                                                                      FittedBox(
                                                                                        child: Row(


                                                                                          children: [
                                                                                            filterListChatUserList[index]
                                                                                                .conversationType ==
                                                                                                "group"
                                                                                                ?
                                                                                            filterListChatUserList[index]
                                                                                                .name !=
                                                                                                null
                                                                                                ? Text(
                                                                                              "${filterListChatUserList[index]
                                                                                                  .name}",
                                                                                              style: Styles
                                                                                                  .baseTextTheme
                                                                                                  .headline4
                                                                                                  .copyWith(
                                                                                                color: Theme
                                                                                                    .of(
                                                                                                    context)
                                                                                                    .brightness ==
                                                                                                    Brightness
                                                                                                        .dark
                                                                                                    ? Colors
                                                                                                    .white
                                                                                                    : Colors
                                                                                                    .black,
                                                                                                fontSize: 15,
                                                                                                fontWeight: FontWeight
                                                                                                    .bold,
                                                                                              ),
                                                                                            )
                                                                                                : filterListChatUserList[index]
                                                                                                .members
                                                                                                .length ==
                                                                                                1
                                                                                                ? FittedBox(
                                                                                                child: Row(
                                                                                                  children: [
                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members[0]
                                                                                                          .firstname}",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),


                                                                                                  ],
                                                                                                )
                                                                                            )
                                                                                                : filterListChatUserList[index]
                                                                                                .members
                                                                                                .length ==
                                                                                                2
                                                                                                ? FittedBox(
                                                                                                child: Row(
                                                                                                  children: [
                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members[0]
                                                                                                          .firstname}, ",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),
                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members[1]
                                                                                                          .firstname}",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),

                                                                                                  ],
                                                                                                )
                                                                                            )
                                                                                                : filterListChatUserList[index]
                                                                                                .members
                                                                                                .length ==
                                                                                                3
                                                                                                ? FittedBox(
                                                                                              child: Row(
                                                                                                children: [
                                                                                                  Text(
                                                                                                    "${filterListChatUserList[index]
                                                                                                        .members[0]
                                                                                                        .firstname}, ",
                                                                                                    style: Styles
                                                                                                        .baseTextTheme
                                                                                                        .headline4
                                                                                                        .copyWith(
                                                                                                      color: Theme
                                                                                                          .of(
                                                                                                          context)
                                                                                                          .brightness ==
                                                                                                          Brightness
                                                                                                              .dark
                                                                                                          ? Colors
                                                                                                          .white
                                                                                                          : Colors
                                                                                                          .black,
                                                                                                      fontSize: 15,
                                                                                                      fontWeight: FontWeight
                                                                                                          .bold,
                                                                                                    ),
                                                                                                  ),
                                                                                                  Text(
                                                                                                    "${filterListChatUserList[index]
                                                                                                        .members
                                                                                                        .length -
                                                                                                        1} other...",
                                                                                                    style: Styles
                                                                                                        .baseTextTheme
                                                                                                        .headline4
                                                                                                        .copyWith(
                                                                                                      color: Theme
                                                                                                          .of(
                                                                                                          context)
                                                                                                          .brightness ==
                                                                                                          Brightness
                                                                                                              .dark
                                                                                                          ? Colors
                                                                                                          .white
                                                                                                          : Colors
                                                                                                          .black,
                                                                                                      fontSize: 15,
                                                                                                      fontWeight: FontWeight
                                                                                                          .bold,
                                                                                                    ),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            )
                                                                                                : filterListChatUserList[index]
                                                                                                .members
                                                                                                .length >=
                                                                                                4
                                                                                                ? FittedBox(
                                                                                                child: Row(
                                                                                                  children: [

                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members[0]
                                                                                                          .firstname}, ",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),
                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members[1]
                                                                                                          .firstname}, ",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),

                                                                                                    Text(
                                                                                                      "${filterListChatUserList[index]
                                                                                                          .members
                                                                                                          .length -
                                                                                                          2} other...",
                                                                                                      style: Styles
                                                                                                          .baseTextTheme
                                                                                                          .headline4
                                                                                                          .copyWith(
                                                                                                        color: Theme
                                                                                                            .of(
                                                                                                            context)
                                                                                                            .brightness ==
                                                                                                            Brightness
                                                                                                                .dark
                                                                                                            ? Colors
                                                                                                            .white
                                                                                                            : Colors
                                                                                                            .black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight
                                                                                                            .bold,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                )
                                                                                            )


                                                                                                : SizedBox()
                                                                                                : SizedBox(),


                                                                                            filterListChatUserList[index]
                                                                                                .conversationType ==
                                                                                                "single"
                                                                                                ?


                                                                                            Text(
                                                                                              "${filterListChatUserList[index]
                                                                                                  .name}",
                                                                                              style: Styles
                                                                                                  .baseTextTheme
                                                                                                  .headline4
                                                                                                  .copyWith(
                                                                                                color: Theme
                                                                                                    .of(
                                                                                                    context)
                                                                                                    .brightness ==
                                                                                                    Brightness
                                                                                                        .dark
                                                                                                    ? Colors
                                                                                                    .white
                                                                                                    : Colors
                                                                                                    .black,
                                                                                                fontSize: 15,
                                                                                                fontWeight: FontWeight
                                                                                                    .bold,
                                                                                              ),
                                                                                            )
                                                                                                : SizedBox()


                                                                                          ],
                                                                                        ),
                                                                                      ),

                                                                                      SizedBox(
                                                                                        width: 150,
                                                                                        child: Text(
                                                                                          filterListChatUserList[index]
                                                                                              .latestMessage ==
                                                                                              null
                                                                                              ? ""
                                                                                              : filterListChatUserList[index]
                                                                                              .latestMessage,
                                                                                          overflow: TextOverflow
                                                                                              .ellipsis,
                                                                                          maxLines: 1,
                                                                                          style: Styles
                                                                                              .baseTextTheme
                                                                                              .headline2
                                                                                              .copyWith(
                                                                                            color: Theme
                                                                                                .of(
                                                                                                context)
                                                                                                .brightness ==
                                                                                                Brightness
                                                                                                    .dark
                                                                                                ? Colors
                                                                                                .white
                                                                                                : Colors
                                                                                                .black,
                                                                                            fontSize: kIsWeb
                                                                                                ? 14
                                                                                                : 12,
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                ),
                                                                                // Column(
                                                                                //   children: [
                                                                                //     Text(
                                                                                //         "jkbdjsbfjbfjksbdfjbsdf")
                                                                                //   ],
                                                                                // )
                                                                              ],
                                                                            )
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  );
                                                                }),
                                                              ),
                                                            ],
                                                          )
                                                              : Column(
                                                            children: [
                                                              Text(
                                                                Strings
                                                                    .sendAMessageGetAMessage,
                                                                // style: TextStyle(
                                                                //     fontSize: 18,
                                                                //     color: Colors.black,
                                                                //     fontWeight: FontWeight.w900),

                                                                style: Styles.baseTextTheme
                                                                    .headline4.copyWith(
                                                                  color: Theme
                                                                      .of(context)
                                                                      .brightness ==
                                                                      Brightness.dark ? Colors
                                                                      .white : Colors.black,
                                                                  fontSize: kIsWeb ? 14 : 12,
                                                                ),
                                                              ),
                                                              SizedBox(height: 10),
                                                              Text(
                                                                Strings
                                                                    .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                                                                textAlign: TextAlign.center,
                                                                // style: TextStyle(color: Colors.black),

                                                                style: Styles.baseTextTheme
                                                                    .headline4.copyWith(
                                                                  color: Theme
                                                                      .of(context)
                                                                      .brightness ==
                                                                      Brightness.dark ? Colors
                                                                      .white : Colors.black,
                                                                  fontSize: kIsWeb ? 14 : 12,
                                                                ),

                                                              ),
                                                              SizedBox(height: 14),
                                                              RoundedButton(

                                                                Strings.startAConversation,
                                                                    () {
                                                                  showDialog(
                                                                    context: context,
                                                                    builder: (
                                                                        BuildContext context) {
                                                                      return AlertDialog(
                                                                        contentPadding: EdgeInsets
                                                                            .zero,
                                                                        insetPadding: EdgeInsets
                                                                            .zero,
                                                                        shape: RoundedRectangleBorder(
                                                                          borderRadius:
                                                                          BorderRadius
                                                                              .circular(20),
                                                                        ),
                                                                        content: NewMessageDialogBox(),
                                                                      );
                                                                    },
                                                                  );
                                                                },
                                                                horizontalPadding: 40,
                                                                roundedButtonColor: controller
                                                                    .displayColor,
                                                              ),
                                                            ],
                                                          ),
                                                          Visibility(
                                                            visible: selectedUserList
                                                                .isNotEmpty,
                                                            child: Padding(
                                                              padding: EdgeInsets.only(
                                                                  bottom: kIsWeb
                                                                      ? 0
                                                                      : MediaQuery
                                                                      .of(context)
                                                                      .viewInsets
                                                                      .bottom),
                                                              child: Row(
                                                                children: [
                                                                  SizedBox(
                                                                    width: 10,
                                                                  ),

                                                                  SizedBox(width: 5),
                                                                  Expanded(
                                                                    child: Builder(
                                                                        builder: (context) {
                                                                          return


                                                                            InputField(
                                                                              contextPadding: EdgeInsets
                                                                                  .only(
                                                                                  left: kIsWeb
                                                                                      ? 20
                                                                                      : 20,
                                                                                  top: kIsWeb
                                                                                      ? 30
                                                                                      : 20,
                                                                                  bottom: kIsWeb
                                                                                      ? 20
                                                                                      : 15),


                                                                              suffixIconColor: controller
                                                                                  .displayColor,
                                                                              controller: messageController,


                                                                              maxLine: 7,
                                                                              minLine: 1,
                                                                              // hint: 'Enter your message',
                                                                              hint: Strings
                                                                                  .enterYourComment,
                                                                              // suffixIcon: Icons.emoji_emotions_outlined,
                                                                            );
                                                                        }),
                                                                  ),

                                                                  IconButton(
                                                                    onPressed:

                                                                        () async {
                                                                      final String messageText =
                                                                      messageController
                                                                          .text.trim();
                                                                      if (selectedUserList
                                                                          .isNotEmpty) {
                                                                        var params = {
                                                                          "conversation_ids": selectedUserList
                                                                              .map((e) =>
                                                                          e.conversationId)
                                                                              .toList(),
                                                                          // "post_id": post.postId,
                                                                          "space_id": spaceId.toString(),
                                                                          "comment": messageController.text
                                                                        };

                                                                        LoggingUtils
                                                                            .printValue(
                                                                            "Params", params);
                                                                        DialogBuilder(context)
                                                                            .showLoadingIndicator();

                                                                        await ShareViaDirectMessage()
                                                                            .sharePostApi(
                                                                            params);
                                                                        controller.getChat();
                                                                        DialogBuilder(context)
                                                                            .hideOpenDialog();

                                                                        Navigator.pop(
                                                                            context);
                                                                      } else {


                                                                      }
                                                                    },
                                                                    icon: Icon(
                                                                      Icons.send_outlined,
                                                                      color: controller
                                                                          .displayColor,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),

                                                        ]
                                                    ),
                                                  ),)
                                              // :

                                              // DialogboxMobile(
                                              //     _scaffoldKey, controller),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                    barrierDismissible: true,
                                  );
                                }


                              },
                              itemBuilder: (BuildContext context) =>
                              [
                                PopupMenuItem(
                                  value: 2,
                                  child: Row(
                                      children: [
                                        Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              AppImages.createWerf,
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            )
                                        ),
                                        SizedBox(width: 5),
                                        Text(
                                          Strings.creatAsWerf,
                                          style:
                                          TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors
                                                  .black,
                                              fontSize: 14
                                          ),),
                                      ]),),

                                PopupMenuItem(
                                  value: 3,
                                  child: Row(
                                      children: [
                                        Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              AppImages.copylink,
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            )
                                        ),
                                        SizedBox(width: 5),
                                        Text(
                                          Strings.copylinkToWerf,
                                          style:
                                          TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors
                                                  .black,
                                              fontSize: 14
                                          ),),
                                      ]),),
                                // if(!kIsWeb)
                                PopupMenuItem(
                                  value: 4,
                                  child: Row(
                                      children: [
                                        Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              AppImages.share,
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            )
                                        ),
                                        SizedBox(width: 5),
                                        Text(
                                          Strings.shareWerf,
                                          style:
                                          TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors
                                                  .black,
                                              fontSize: 14
                                          ),),
                                      ]),),
                                PopupMenuItem(
                                  value: 5,
                                  child: Row(
                                      children: [
                                        Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                              AppImages.copylink,
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            )
                                        ),
                                        SizedBox(width: 5),
                                        Text(
                                          Strings.sendViaDirectMessage,
                                          style:
                                          TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors
                                                  .black,
                                              fontSize: 14
                                          ),),
                                      ]),),

                              ]
                          )
                      ),


                    ),
                  ),
                  SizedBox(height: 16.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      /*              ElevatedButton(
                      onPressed: () {
                        // Action when Share button is pressed

                        // Share.share(url, subject: 'Space url');

                      },
                      child: Text('Share'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                      ),
                    ),*/
                      ElevatedButton(
                        onPressed: () async {
                          // Action when Start Now button is pressed
                          if(Platform.isIOS) {

                            final Uri uri = Uri.parse(url);

                            if (await canLaunchUrl(uri)) {
                              await launchUrl(uri,
                                  webOnlyWindowName: '_blank');
                            } else {
                              throw 'Could not launch $url';
                            }
                          }else{
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) => SpacesWebviewScreen(url: url,),
                              ),
                            );
                          }
                        },
                        child: Text('Start Now'),
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),),
        );
      },
    );
  }

  void _toggleExpand() {
    widget.controller.isFABExpanded = !widget.controller.isFABExpanded;
    widget.controller.update();
  }

  tabForYou() {
    return widget.controller.isNewsfeedLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return _.postList == null || _.postList.isEmpty ? const NoResponseFromServerTextWidget() :
                             Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                        backgroundColor: Colors.black,
                                        scrollbarTheme: ScrollbarThemeData(
                                          radius: const Radius.circular(10.0),
                                          thumbColor: MaterialStateProperty.all(
                                              Colors.black26),
                                          trackColor: MaterialStateProperty.all(
                                              const Color(0xFFf7f9f9)),
                                          trackBorderColor:
                                              MaterialStateProperty.all(
                                                  const Color(0xFFf7f9f9)),
                                          trackVisibility:
                                              MaterialStateProperty.all(false),
                                          thickness:
                                              MaterialStateProperty.all(4),
                                          minThumbLength: 150,
                                          thumbVisibility: MaterialStateProperty.all(true),
                                        ),
                                      ),
                                child: PagedL(
                                  emptyStateWidget: ListViewLoadingShimmer(),
                                  // Text(Strings.noPosts),
                                  itemBuilder: _itemRow,
                                  padding: EdgeInsets.only(
                                      top: 16.00, left: 0.00, right: 0.00),
                                  loadingIndicator: Padding(
                                    padding: EdgeInsets.all(10.00),
                                    child: ListViewLoadingShimmer(),
                                  ),
                                  itemDataProvider: _fetchData,
                                  list: _.postList,
                                  listSize: _checkPage(_.postList.length),

                                  // + 1
                                  // : _checkPage(_.postList.length),
                                  newsFeedCheck: true,
                                  isForYou: true,
                                ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postList =
                                      await widget.controller.getNewsFeed(
                                    shouldUpdate: false,
                                    reload: true,
                                    newsFeedMobile: true,
                                  );
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postList == null || _.postList.isEmpty
                                    ? const NoResponseFromServerTextWidget()
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postList,
                                        listSize: _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabFollowing() {
    return widget.controller.isNewsFeedFollowingLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return _.postListFollowing == null ||  _.postListFollowing.isEmpty
                                ? const NoResponseFromServerTextWidget()
                            : Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListFollowing.isEmpty
                                    ? Column(
                                        children: [
                                          Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              CreatePostWeb(
                                                widget.controller,
                                                widget.controller.userProfile,
                                                post: widget.post,
                                              ),
                                              Divider(
                                                thickness: 2,
                                                color: Colors.grey[200],
                                              ),
                                            ],
                                          ),
                                          Center(
                                            child: Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 100.0),
                                              child: Text(
                                                "No posts found ",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 18),
                                              ),
                                            ),
                                          ),
                                        ],
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFollowing,
                                        listSize: _checkPageFollowing(
                                            _.postListFollowing.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postList = await widget
                                      .controller
                                      .getNewsFeedFollowing(
                                    shouldUpdate: false,
                                    reload: true,
                                    newsFeedMobile: true,
                                  );
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListFollowing == null ||  _.postListFollowing.isEmpty
                                    ? const NoResponseFromServerTextWidget()
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFollowing,
                                        listSize: _checkPage(
                                            _.postListFollowing.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabListOne() {
    return widget.controller.isPostListOneLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListOne.isEmpty
                                    ? const Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListOne,
                                        listSize: _checkPageListOne(
                                            _.postListOne.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postListOne =
                                      await widget.controller.getPostListOne(
                                          shouldUpdate: false,
                                          reload: true,
                                          newsFeedMobile: true,
                                          postListID: widget
                                              .controller
                                              .languageData
                                              .pinnedLists
                                              .first
                                              .id);
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListOne.isEmpty
                                    ? Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListOne,
                                        listSize: _checkPageListOne(
                                            _.postListOne.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabListTwo() {
    return widget.controller.isPostListTwoLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListTwo.isEmpty
                                    ? const Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListTwo,
                                        listSize: _checkPageListTwo(
                                            _.postListTwo.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postListTwo =
                                      await widget.controller.getPostListTwo(
                                          shouldUpdate: false,
                                          reload: true,
                                          newsFeedMobile: true,
                                          postListID: widget.controller
                                              .languageData.pinnedLists[1].id);
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListTwo.isEmpty
                                    ? Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListTwo,
                                        listSize: _checkPageListTwo(
                                            _.postListTwo.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabListThree() {
    return widget.controller.isPostListThreeLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListThree.isEmpty
                                    ? const Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListThree,
                                        listSize: _checkPageListThree(
                                            _.postListThree.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postListThree =
                                      await widget.controller.getPostListThree(
                                          shouldUpdate: false,
                                          reload: true,
                                          newsFeedMobile: true,
                                          postListID: widget.controller
                                              .languageData.pinnedLists[2].id);
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListThree.isEmpty
                                    ? Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListThree,
                                        listSize: _checkPageListThree(
                                            _.postListThree.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabListFour() {
    return widget.controller.isPostListFourLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListFour.isEmpty
                                    ? const Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFour,
                                        listSize: _checkPageListFour(
                                            _.postListFour.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postListFour =
                                      await widget.controller.getPostListFour(
                                          shouldUpdate: false,
                                          reload: true,
                                          newsFeedMobile: true,
                                          postListID: widget.controller
                                              .languageData.pinnedLists[3].id);
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListFour.isEmpty
                                    ? Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFour,
                                        listSize: _checkPageListFour(
                                            _.postListFour.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  tabListFive() {
    return widget.controller.isPostListFiveLoading == true ||
            widget.controller.languageData == null
        ? const Center(
            child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(
              MyColors.BlueColor,
            ),
          ))
        : Stack(
            alignment: Alignment.topCenter,
            children: [
              Column(
                children: [
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: const Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.black26),
                                    trackColor: MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        const Color(0xFFf7f9f9)),
                                    trackVisibility:
                                    MaterialStateProperty.all(false),
                                    thickness:
                                    MaterialStateProperty.all(4),
                                    minThumbLength: 150,
                                    thumbVisibility: MaterialStateProperty.all(true),
                                  ),
                                ),
                                child: _.postListFive.isEmpty
                                    ? const Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 0.00,
                                            right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFive,
                                        listSize: _checkPageListFive(
                                            _.postListFive.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          })
                      : GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            //return SizedBox();
                            // print("second builder" + _.postList[0].body);
                            return Expanded(
                              child: RefreshIndicator(
                                triggerMode:
                                    RefreshIndicatorTriggerMode.anywhere,
                                onRefresh: () async {
                                  widget.isPullToRefresh = true;
                                  // widget.controller.postList = await widget.controller.getNewsFeed(
                                  //     shouldUpdate: true, reload: true);
                                  // widget.controller.update();
                                  widget.controller.postListFive =
                                      await widget.controller.getPostListFive(
                                          shouldUpdate: false,
                                          reload: true,
                                          newsFeedMobile: true,
                                          postListID: widget.controller
                                              .languageData.pinnedLists[4].id);
                                  widget.controller.update();

                                  widget.isPullToRefresh = false;
                                  /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                },
                                child: _.postListFive.isEmpty
                                    ? Center(
                                        child: Text(
                                          "No posts found ",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 18),
                                        ),
                                      )
                                    : PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),
                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 0.00, left: 4.00, right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: Center(
                                              child: ListViewLoadingShimmer()
                                              // Container(
                                              //     color: Colors.grey[200],
                                              //     // margin: EdgeInsets.all(10),
                                              //     height: 320,
                                              //     child: buildPostShimmer(
                                              //         context)),
                                              ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.postListFive,
                                        listSize: _checkPageListFive(
                                            _.postListFive.length),
                                        newsFeedCheck: true,
                                      ),
                              ),
                            );
                          }),
                ],
              ),
            ],
          );
  }

  body() {
    return kIsWeb
        ? Column(
            children: [
              SizedBox(
                height: 5,
              ),
              TabBar(
                controller: tabController,
                indicatorColor:
                    Get.isDarkMode ? MyColors.werfieBlue : Colors.blue,
                labelColor: Get.isDarkMode ? Colors.white : MyColors.werfieBlue,
                unselectedLabelColor:
                    Get.isDarkMode ? Colors.white : Colors.black26,
                labelStyle:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                unselectedLabelStyle:
                    TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                indicatorWeight: 4,
                indicatorSize: TabBarIndicatorSize.label,
                splashBorderRadius: BorderRadius.circular(10),
                indicator: RoundedTabIndicator(
                  indicatorWidth: 50, // Adjust this value for indicator width
                  indicatorHeight: 5, // Adjust this value for indicator height
                  cornerRadius: 10, // Adjust this value for desired rounded corners
                  color: Color(0xFF2769d9), // Adjust this value for desired color
                ),
                isScrollable: true,
                dividerColor:
                    Get.isDarkMode ? MyColors.werfieBlue : Colors.white,
                tabs: listTabViewTitles,
              ),
              //SizedBox(height: 5,),
              Divider(
                thickness: 0.5,
                color: Colors.black12,
              ),
              // CreatePostWeb(
              //   widget.controller,
              //   widget.controller.userProfile,
              //   post: widget.post,
              // ),
              // Divider(
              //   thickness: 2,
              //   color: Colors.grey[200],
              // ),

              Flexible(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  children: getTabsLists(),
                  controller: tabController,
                ),
              ),
            ],
          )
        : Flex(
            direction: Axis.vertical,
            children: [
              Flexible(
                child: TabBarView(
                  physics: NeverScrollableScrollPhysics(),
                  children: getTabsLists(),
                  controller: tabController,
                ),
              ),
            ],
          );
  }

  List<Widget> getTabsLists() {
    List<Widget> list = [tabForYou(), tabFollowing()];
    if (widget.controller.languageData != null &&
        widget.controller.languageData.pinnedLists != null &&
        widget.controller.languageData.pinnedLists.isNotEmpty) {
      switch (widget.controller.languageData.pinnedLists.length) {
        case 1:
          list.add(tabListOne());
          break;
        case 2:
          list.add(tabListOne());
          list.add(tabListTwo());
          break;
        case 3:
          list.add(tabListOne());
          list.add(tabListTwo());
          list.add(tabListThree());
          break;
        case 4:
          list.add(tabListOne());
          list.add(tabListTwo());
          list.add(tabListThree());
          list.add(tabListFour());
          break;
        case 5:
          list.add(tabListOne());
          list.add(tabListTwo());
          list.add(tabListThree());
          list.add(tabListFour());
          list.add(tabListFive());
          break;
      }
    }
    return list;
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageFollowing(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageListOne(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageListTwo(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageListThree(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageListFour(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPageListFive(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

// get newsfeed
  Future<List<Post>> _fetchData(int page) async {
    if (tabController.index == 0) {
      return await widget.controller.getNewsFeedPagged(page: page);
    } else if (tabController.index == 1) {
      return await widget.controller.getNewsFeedPagedFollowing(page: page);
    } else if (tabController.index == 2) {
      return await widget.controller.getNewsFeedPagedListOne(
          page: page, listID: widget.controller.languageData.pinnedLists[0].id);
    } else if (tabController.index == 3) {
      return await widget.controller.getNewsFeedPagedListTwo(
          page: page, listID: widget.controller.languageData.pinnedLists[1].id);
    } else if (tabController.index == 4) {
      return await widget.controller.getNewsFeedPagedListThree(
          page: page, listID: widget.controller.languageData.pinnedLists[2].id);
    } else if (tabController.index == 5) {
      return await widget.controller.getNewsFeedPagedListFour(
          page: page, listID: widget.controller.languageData.pinnedLists[2].id);
    } else if (tabController.index == 6) {
      return await widget.controller.getNewsFeedPagedListFive(
          page: page, listID: widget.controller.languageData.pinnedLists[4].id);
    }
  }

// item rows
  Widget _itemRow(BuildContext context, Post post, {bool isListEmpty = false}) {
    List<Post> list;
    if (tabController.index == 0) {
      list = widget.controller.postList;
    } else if (tabController.index == 1) {
      list = widget.controller.postListFollowing;
    } else if (tabController.index == 2) {
      list = widget.controller.postListOne;
    } else if (tabController.index == 3) {
      list = widget.controller.postListTwo;
    } else if (tabController.index == 4) {
      list = widget.controller.postListThree;
    } else if (tabController.index == 5) {
      list = widget.controller.postListFour;
    } else if (tabController.index == 6) {
      list = widget.controller.postListFive;
    }
    int index = list.indexWhere((element) {
      return element.postId == post.postId;
    });

    if (index != 0 && index % 13 == 0 /*&& !kIsWeb*/) {
      return Column(
        children: [
          list[index].type == 'thread'
              ? index == 0
                  ? Column(
                      children: [
                        ThreadPostCard(
                            postList: list,
                            scaffoldKey: _scaffoldKey,
                            post: list[index],
                            index: index,
                            controller: widget.controller,
                            deletePostId: 1,
                            mute: 0),
                      ],
                    )
                  : ThreadPostCard(
                      postList: list,
                      scaffoldKey: _scaffoldKey,
                      post: list[index],
                      index: index,
                      controller: widget.controller,
                      deletePostId: 1,
                      mute: 0)
              : index == 0
                  ? Column(
                      children: [
                        GestureDetector(
                          child: PostCard(
                              postList: list,
                              post: list[index],
                              scaffoldKey: _scaffoldKey,
                              index: index,
                              controller: widget.controller,
                              deletePostId: widget.controller.deletePostId,
                              mute: 0),
                        ),
                      ],
                    )
                  : GestureDetector(
                      child: PostCard(
                          postList: list,
                          post: list[index],
                          scaffoldKey: _scaffoldKey,
                          index: index,
                          controller: widget.controller,
                          deletePostId: widget.controller.deletePostId,
                          mute: 0),
                    ),
          SizedBox(height: 4),

          kIsWeb?CustomAdWidgetWeb():
          CustomAdWidget(
              // ad: widget.controller.ads[widget.adIndex++],
              ),
        ],
      );
    } else {
      return Column(
        children: [
          if (index == 0 && kIsWeb)
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CreatePostWeb(
                  widget.controller,
                  widget.controller.userProfile,
                  post: widget.post,
                ),
              ],
            ),
          VisibilityDetector(
            key: Key('postCard-widget-key'),
            onVisibilityChanged: (visibilityInfo) {
              double visiblePercentage = visibilityInfo.visibleFraction * 100;
              // debugPrint(
              //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
              if (visiblePercentage > 20 &&
                  post.authorId != widget.controller.userId) {
                widget.controller.emitImpressionsSocket(post.postId);
              }
            },
            child: list[index].type == 'thread'
                ? index == 0
                    ? Column(
                        children: [
                          ThreadPostCard(
                              postList: list,
                              scaffoldKey: _scaffoldKey,
                              post: list[index],
                              index: index,
                              controller: widget.controller,
                              deletePostId: 1,
                              mute: 0),
                        ],
                      )
                    : ThreadPostCard(
                        postList: list,
                        scaffoldKey: _scaffoldKey,
                        post: list[index],
                        index: index,
                        controller: widget.controller,
                        deletePostId: 1,
                        mute: 0)
                : index == 0
                    ? Column(
                        children: [
                          PostCard(
                              postList: list,
                              post: list[index],
                              scaffoldKey: _scaffoldKey,
                              index: index,
                              controller: widget.controller,
                              deletePostId: 1,
                              mute: 0),
                        ],
                      )
                    : PostCard(
                        postList: list,
                        post: list[index],
                        scaffoldKey: _scaffoldKey,
                        index: index,
                        controller: widget.controller,
                        deletePostId: 1,
                        mute: 0),
          ),
        ],
      );
    }
  }

// Widget buildPostShimmer(BuildContext context) => ListTile(
//       //Shimmer for Profile Photo
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           //Shimmer for username
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 20),
//           //Shimmer for post text
//           CustomShimmerWidget.rectangular(
//             height: 210,
//           ),
//           SizedBox(height: 20),
//           //Shimmer for reaction row
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               //  SizedBox(width: 16),
//             ],
//           ),
//           SizedBox(height: 16),
//         ],
//       ),
//       // trailing: SizedBox(),
//       // subtitle: CustomShimmerWidget.rectangular(
//       //     height: 14, width: MediaQuery.of(context).size.width * 0.3),
//     );
}

class CustomDialog extends StatelessWidget {
  final String title;
  final String content;
  final VoidCallback onClose;

  CustomDialog({
    this.title,
    this.content,
    this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 18.0,
              ),
            ),
            SizedBox(height: 12.0),
            Text(content),
            SizedBox(height: 12.0),
            ElevatedButton(
              onPressed: onClose,
              child: Text('Close'),
            ),
          ],
        ),
      ),
    );
  }
}
class RoundedTabIndicator extends Decoration {
  final double indicatorWidth;
  final double indicatorHeight;
  final double cornerRadius;
  final Color color;

  const RoundedTabIndicator({
     this.indicatorWidth,
     this.indicatorHeight,
     this.cornerRadius,
     this.color,
  });

  @override
  BoxPainter createBoxPainter([VoidCallback onChanged]) {
    return _RoundedIndicatorPainter(
      this,
      onChanged,
    );
  }
}

class _RoundedIndicatorPainter extends BoxPainter {
  final RoundedTabIndicator decoration;

  _RoundedIndicatorPainter(this.decoration, VoidCallback onChanged)
      : super(onChanged);

  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration configuration) {
    final Rect rect = Offset(
      offset.dx + (configuration.size.width - decoration.indicatorWidth) / 2,
      offset.dy + (configuration.size.height - decoration.indicatorHeight),
    ) &
    Size(
      decoration.indicatorWidth,
      decoration.indicatorHeight,
    );

    final Paint paint = Paint()
      ..color = decoration.color
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, Radius.circular(decoration.cornerRadius)),
      paint,
    );
  }
}
