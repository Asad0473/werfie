import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:get/get.dart' as GET;
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:werfieapp/video_call/utilities/video_call_utilities.dart';
import 'package:werfieapp/video_call/widgets/add_user_to_call.dart';
import 'package:werfieapp/video_call/widgets/participants_list.dart';
import 'package:werfieapp/video_call/widgets/square_button.dart';
import 'package:werfieapp/video_call/widgets/user_card.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/fluro_router.dart';
import 'controller/video_call_controller.dart';
import 'models/participant_model.dart';

class VideoCallHome extends StatefulWidget {
  final String conversationId;
  const VideoCallHome({Key key, this.conversationId}) : super(key: key);

  @override
  State<VideoCallHome> createState() => _VideoCallHomeState();
}

class _VideoCallHomeState extends State<VideoCallHome> {



  // Create a device.

  // RTCVideoRenderer _localRenderer = new RTCVideoRenderer();

  VideoCallController videoCallController;
  String conversationID = "";

  @override
  void initState() {

    if (Get.isRegistered<VideoCallController>()) {
      videoCallController = Get.find<VideoCallController>();
    } else {
      videoCallController = Get.put(VideoCallController());
    }


    if(kIsWeb){
      String data = Get.arguments.toString(); // Retrieve the passed argument
      conversationID = data;
    } else {
      conversationID = widget.conversationId;
    }

    if (videoCallController.conversationID.isEmpty){
      if (conversationID != null && conversationID.isNotEmpty){
        SchedulerBinding.instance.addPostFrameCallback((_) {
          videoCallController.initialize(conversationId: conversationID);
        });
      }
    }


    // _localRenderer.initialize();
    super.initState();
  }
  @override
  deactivate() {
    // _localRenderer.dispose();
    super.deactivate();
  }

  @override
  void dispose() async{
    debugPrint("Dispose called");
    // await disconnectCallAndExit();
    super.dispose();
  }



  goBack(){
    if (kIsWeb){
      GET.Get.find<NewsfeedController>().navRoute = "isChatScreen";
      GET.Get.toNamed(FluroRouters.mainScreen + '/chats');
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {

    return GetBuilder<VideoCallController>(builder: (controller) {
      return Material(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 20.0,),
     /*     Row(
            children: [
              SquareButton(icon: Icons.arrow_back_outlined,
                onTap: () async{
                  await disconnectCallAndExit();
                  goBack();
                },),
              Spacer(),
              // Icon(Icons.fullscreen, size: 30.0,),
            ],
          ),*/
          Expanded(
            child: videoCallController.participantsList.length > 2
                ? groupCall()
                : oneToOne(),),
          const SizedBox(height: 15.0,),
          bottomIcons(),
          const SizedBox(height: 15.0,),
        ],
      ),
    ); });
  }

  Widget bottomIcons(){
    return Row(
      children: [
        const Spacer(),
        SquareButton(icon: Icons.add,
          iconColor: Colors.black87,
          onTap: (){
            addAUser();
          },),
/*        SquareButton(icon: Icons.people,
          iconColor: !showParticipantsList ? Colors.black87 : Colors.red,
          onTap: (){
          setState(() {
            showParticipantsList = !showParticipantsList;
          });
          },),*/
        !kIsWeb ? SquareButton(icon: Icons.volume_up_rounded,
          iconColor: videoCallController.isSpeakerEnabled ? Colors.green : Colors.black87,
          onTap: (){
            videoCallController.isSpeakerEnabled = !videoCallController.isSpeakerEnabled;
            videoCallController.enableOrDisableSpeakerPhone();
          },) : const SizedBox(),
        SquareButton(icon: videoCallController.isAudioOn ? Icons.mic_none_outlined : Icons.mic_off_outlined,
          iconColor: videoCallController.isAudioOn ? Colors.black87 : Colors.red,
          onTap: (){
            videoCallController.isAudioOn = !videoCallController.isAudioOn;
            videoCallController.update();
            videoCallController.micOnOff();
          },),
        SquareButton(icon: videoCallController.isVideoOn ? Icons.videocam_rounded : Icons.videocam_off, //videocam_off_rounded
          iconColor: videoCallController.isVideoOn ? Colors.black87 : Colors.red,
          onTap: (){
            videoCallController.isVideoOn = !videoCallController.isVideoOn;
            videoCallController.update();
            videoCallController.cameraOnOff();
            // sendJoinRequest();
          },),
/*        !kIsWeb ? SquareButton(icon: Icons.cameraswitch, //videocam_off_rounded
          iconColor: Colors.black87,
          onTap: () async{
          videoCallController.switchCamera();
          },) : SizedBox(),*/
        SquareButton(icon: Icons.call_end,
          bgColor: Colors.red,
          iconColor: Colors.white ,
          onTap: () async{
            await videoCallController.disconnectCallAndExit();
            goBack();
          },),
        const Spacer(),
      ],
    );
  }

  Widget bottomIconsTodo(){
    return Row(
      children: [
        const Spacer(),
        SquareButton(icon: Icons.file_copy,
          onTap: (){
            // enableWebCam();
            // consumeMethod();
          },),
        SquareButton(icon: Icons.chat,
          onTap: (){
          },),
        SquareButton(icon: Icons.screen_share_rounded,
          onTap: (){
          },),
        SquareButton(icon: Icons.emoji_emotions,
          onTap: (){
          },),
        SquareButton(icon: Icons.front_hand,
          onTap: (){
          },),
        SquareButton(icon: Icons.menu,
          onTap: (){
          },),
        SquareButton(icon: Icons.monitor,
          onTap: (){
          },),
        InkWell(
          onTap: (){

          },
          child: Container(
              margin: EdgeInsets.symmetric(horizontal: 5.0),
              padding: EdgeInsets.symmetric(horizontal: 10.0),
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(10.0)
              ),
              // width: 190.0,
              height: 50.0,
              child: Row(
                children: const [
                  Icon(Icons.monitor, size: 15.0,),
                  Text("   Speaker View"),
                  Icon(Icons.arrow_drop_down),
                ],
              )
          ),
        ),
        SquareButton(icon: Icons.fullscreen,
          onTap: (){
          },),
        const Spacer(),
        SquareButton(icon: Icons.more_vert,
          onTap: (){
          },),
      ],
    );
  }

  oneToOne(){

    ParticipantModel localParticipantModel, remoteParticipantModel;

    debugPrint("videoCallController.participantsList length: ${videoCallController.participantsList.length}");
    for (ParticipantModel element in videoCallController.participantsList){
      if (element.user.id.toString() == videoCallController.userId.toString()){
        localParticipantModel = element;
      } else {
        remoteParticipantModel = element;
      }
    }

    return Stack(
      children: [
        UserCard(height: double.infinity, width: double.infinity, participantModel: remoteParticipantModel, showCallingText: !videoCallController.isOtherCallerJoined && videoCallController.isCaller,),
        localParticipantModel != null && localParticipantModel.renderer != null
            ? Positioned(bottom: kIsWeb ? 20 : 50, right: 20, child: UserCard(height: 200.0, width: 200.0, participantModel: localParticipantModel))
            : const SizedBox(),
      ],
    );
  }

  groupCall(){
    return Row(
      children: [
        Expanded(child: gridList()),
        videoCallController.showParticipantsList && kIsWeb ? ParticipantsList(participantsList: videoCallController.participantsList,) : SizedBox(),

      ],
    );
  }

  gridList(){
    int crossAxisCount = 2;
    if (kIsWeb && videoCallController.participantsList.length >= 3 && !videoCallController.showParticipantsList){
      crossAxisCount = 3;
    }
    return Center(
      child: GridView.builder(
        shrinkWrap: true,
        padding: EdgeInsets. zero,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount, // number of items in each row
          mainAxisSpacing: 1.0, // spacing between rows
          crossAxisSpacing: 1.0, // spacing between columns
          childAspectRatio: 1,
        ),
        // padding: EdgeInsets.all(0.0), // padding around the grid
        itemCount: videoCallController.participantsList.length, // total number of items
        itemBuilder: (context, index) {
          return Container(
            // color: Colors.blue, // color of grid items
            child: Center(
              child: UserCard(participantModel: videoCallController.participantsList[index],),
            ),
          );
        },
      ),
    );
  }

  addAUser(){
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          contentPadding: EdgeInsets.zero,
          insetPadding: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius:
            BorderRadius.circular(20),
          ),
          content: AddUserToCall(conversationId: videoCallController.conversationID, participantsList: videoCallController.participantsList,),
        );
      },
    ).then((value) {
    });
  }


}
