import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get_storage/get_storage.dart';
import 'package:mediasoup_client_flutter/mediasoup_client_flutter.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../../network/controller/news_feed_controller.dart';
import '../../utils/fluro_router.dart';
import '../models/available_producers_model.dart';
import '../models/participant_model.dart';
import '../utilities/video_call_utilities.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:get/get.dart' as GET;

class VideoCallController extends GetxController {
  IO.Socket socketVideo;

  String roomId = '';
  int userId;
  String roomType = 'mediasoup-sfu';
  Map<String, dynamic> basicSendData;

  MediaStream videoStream;
  MediaStream audioStream;
  Transport producerTransport;
  var mediaSoupDevice = Device();
  String conversationID = "";

  Transport _consumerTransport;
  String consumerID;
  bool isAudioOn = true;
  bool isVideoOn = true;
  List<AvailableProducersModel> producersList = [];
  List<ParticipantModel> participantsList = [];

  bool showParticipantsList = false;
  String preferredCamera = "front";
  bool isSpeakerEnabled = true;
  final player = AudioPlayer();
  bool isOtherCallerJoined = false;
  bool isCaller = false;

  initialize({String conversationId}) {
    userId = GetStorage().read('id');

    // if(kIsWeb){
    //   String data = Get.arguments.toString(); // Retrieve the passed argument
    //   debugPrint("argument data: $data");
    //   roomId = roomId + data;
    //   conversationID = data;
    // } else {
    roomId = 'room_id_' + conversationId;
    conversationID = conversationId;
    debugPrint("Conversation Id: ${conversationId}");
    debugPrint("Room Id: ${roomId}");
    // }

    basicSendData = {
      "room_id": roomId,
      "room_type": roomType,
      "user_id": userId,
    };

    update();

    initSockets();
  }

  @override
  void onClose() {
    // if (socket != null) {
    //   socket.close();
    // }
    player.dispose();
    super.onClose();
  }

  disconnectCallAndExit() async {
    try {
      player.stop();
      conversationID = "";
      await VideoCallUtilities().leaveCall(socketVideo, basicSendData);
      // stream.dispose();
      // audioStream.dispose();
      // await _localRenderer.dispose();
      if (socketVideo != null) {
        await socketVideo.close();
        await socketVideo.disconnect();
        await socketVideo.dispose();
      }
      await producerTransport.close();
      await _consumerTransport.close();

      mediaSoupDevice = Device();
      videoStream = null;
      audioStream = null;
      consumerID = null;
      isAudioOn = true;
      isVideoOn = true;
      producersList = [];
      participantsList = [];
      showParticipantsList = false;
      Get.delete<VideoCallController>();
    } catch (e) {
      debugPrint("disconnectCallAndExit 14 $e");
    }
  }

  initSockets() async {
    try {
      String url = "https://room-server.werfie.com?user_id=$userId";
      socketVideo = IO.io(url, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': false,
        'force new connection': true,
      });

      socketVideo.connect();
      socketVideo.onConnect((data) {});

      socketVideo.on('connect_error', (data) {
        debugPrint("Socket connection error: $data");
      });

      socketVideo.onDisconnect((_) {
        debugPrint('socket disconnect');
      });

      socketListeners();
      await sendJoinRequest();
    } catch (e) {
      debugPrint("06 initSockets : $e");
    }
  }

  socketListeners() async {
    socketVideo.on('room:can-make-connection', (data) async {
      debugPrint("Kathirva's Log 03: 'room:can-make-connection' receive event triggered: $data");
      Map<String, dynamic> routerRtpCapabilities = Map<String, dynamic>.from(data['router']['rtp_capabilities']);
      final rtpCapabilities = RtpCapabilities.fromMap(routerRtpCapabilities);
      rtpCapabilities.headerExtensions.removeWhere((he) => he.uri == 'urn:3gpp:video-orientation');
      try{
        await mediaSoupDevice.load(routerRtpCapabilities: rtpCapabilities);
      } catch (e){
        debugPrint("Kathirva's Log 03A: Device Load Error : $e");
      }

      canProduceVideo(routerRtpCapabilities);
      createConsumeTransport();
      debugPrint("routerRtpCapabilities: $routerRtpCapabilities");

      // final Map<String, dynamic> routerRtpCapabilities = data
      // Proceed further upon receiving acknowledgment to join the call
      // Start setting up WebRTC connections, enable video/audio, etc.
      // Access router, capabilities, etc., from data received
    });
    socketVideo.on('room:new-producer', (data) {
      debugPrint("New producer available :: $data");
      // Extract the producer data
      Map<String, dynamic> producer = data['producer'];
      AvailableProducersModel availableProducersModel = AvailableProducersModel.fromJson(producer);
      // String pUserId = data["user_id"];
      // String pRoomID = data["room_id"];
      producersList.add(availableProducersModel);
      consumeEachProducer();
      // New producer available :: {user_id: 504, producer: {id: 3f262910-a912-422b-a0cc-af7927d510de, name: 504_user_video_producer, track_type: user, track_kind: video, transport_id: 6075a7d4-ae80-44a4-b7ad-f5dab503e957, user_id: 504}, track_type: user, room_id: random_room_id_504}
    });
    socketVideo.on('room:joined', (data) async {
      // New user room:joined :: {user: {id: 504, name: Kathiravan}, socket_id: Giro7OtnA2-i627RAAG2, is_video_on: true, is_audio_on: false, available_producers: {503_user_video_producer: {id: d9a14daa-960d-4be6-b8fe-b37a9af67648, name: 503_user_video_producer, track_type: user, track_kind: video, transport_id: 96f9fd51-fddb-4fac-9ace-161691e442fb, user_id: 503}, 503_user_audio_producer: {id: c7f21a66-2bb0-4915-a38c-1791b3a2c171, name: 503_user_audio_producer, track_type: user, track_kind: audio, transport_id: 96f9fd51-fddb-4fac-9ace-161691e442fb, user_id: 503}, 504_user_video_producer: {id: d3226578-c065-4420-b475-a33ff5ecb492, name: 504_user_video_producer, track_type: user, track_kind: video, transport_id: 5168eeb2-b355-467c-81be-07b024836474, user_id: 504}}, participant: {id: 504, unique_id: 504_1703787884698, user: {id: 504, name: Kathiravan}, is_video_on: true, is_audio_on: false, is_sharing: false, is_recording: false, is_disconnected: false}, participants: {503: {id: 503, unique_id: 503_1703787870874, user: {id: 503, name: Kathiravan}, is_video_on: true, is_audio_on: false, is_sharing: false, is_recording: false, is_disconnected: false}, 504: {id: 504, unique_id: 504_1703787884698, user: {id: 504, name: Kathiravan}, is_video_on: true, is_audio_on: false, is_sharing: false, is_recording: false, is_disconnected: false}}, participants_ids: [503, 504], room_id: random_room_id_504}

      // Map<String, dynamic> participant = data['participants'];
      // ParticipantModel participantModel = ParticipantModel.fromJson(participant);
      // participantsList.add(participantModel);
      await processParticipantsList(data['participants']);

      debugPrint("New user room:joined :: $data");
    });
    socketVideo.on('room:video-switched', (data) {
      debugPrint("room:video-switched :: $data");
    });
    socketVideo.on('room:audio-switched', (data) {
      debugPrint("room:audio-switched :: $data");
    });
    socketVideo.on('room:left', (data) {
      debugPrint("room:left :: $data");
      // room:left :: {user_id: 503, participants_ids: [504], room_id: random_room_id_504}
      int leftUserID = data["user_id"];
      participantsList.removeWhere((element) => element.user.id == leftUserID);
      disconnectCallIfLastCaller();
      update();
    });
    socketVideo.on('room:producer-closed', (data) {
      debugPrint("Producer closed :: $data");
      // Producer closed :: {producer_id: 63beae15-2fb0-4f64-99cb-123e0689a7e8, producer_name: 503_user_video_producer, room_id: random_room_id_504}
    });
    socketVideo.on('room:consumer-closed', (data) {
      debugPrint("Consumer closed :: $data");
      // Consumer closed :: {consumer_id: 98d3b6b2-6073-4f31-b060-272e97edd565, room_id: random_room_id_504}
    });
    socketVideo.on('room:transport-closed', (data) {
      debugPrint("Transport closed :: $data");
    });
  }

  Future sendJoinRequest() async {
    debugPrint("Kathirva's Log 01: emit sendJoinRequest");
    Map<String, dynamic> data = {
      "room": {"id": roomId},
      ...basicSendData
    };
    debugPrint("Kathirva's Log 02: Send Event 'room:request-join': $data");
    // Send the join request to the server
    await socketVideo.emit('room:request-join', data);
  }

  canProduceVideo(Map<String, dynamic> routerRtpCapabilities) async {
    // Load the device with the router RTP capabilities.
    debugPrint("Kathirva's Log 04: loading mediaSoupDevice with RtpCapabilities: $routerRtpCapabilities");

    debugPrint("Kathirva's Log 05: loading mediaSoupDevice is done");

    // Check wheter we can produce video to the router.
    if (mediaSoupDevice.canProduce(RTCRtpMediaType.RTCRtpMediaTypeVideo)) {
      debugPrint("Kathirva's Log 06: mediaSoupDevice can be able to produce audio/video - true");
      createNewTransport();
    } else {
      debugPrint("Kathirva's Log 06A: Error: mediaSoupDevice not able to produce video");
    }
  }

  Future createNewTransport() async {
    // await joinCall();
    var params = {
      'sctpCapabilities': mediaSoupDevice.sctpCapabilities.toMap(),
      ...basicSendData,
    };

    debugPrint("Kathirva's Log 07: send event 'room:create-transport': $params");

    await socketVideo.emitWithAck('room:create-transport', params, ack: (data) {
      debugPrint("Kathirva's Log 08: send event 'room:create-transport' response: $data");

      if (data != null) {
        var createTransportInfo = data['transport'];
        producerConnectProduce(createTransportInfo);
      }
    });
    debugPrint("Kathirva's Log 08A: End of method");
  }

  void producerConnectProduce(var createTransportInfo) async {
    try {
      Map<dynamic, dynamic> transportInfo = {
        "id": createTransportInfo["id"],
        "iceParameters": createTransportInfo["ice_parameters"],
        "iceCandidates": createTransportInfo["ice_candidates"],
        "dtlsParameters": createTransportInfo["dtls_parameters"],
        'sctpParameters': mediaSoupDevice.sctpCapabilities.toMap(),
      };
      debugPrint("Kathirva's Log 09: createSendTransportFromMap: $transportInfo");

      producerTransport = await mediaSoupDevice.createSendTransportFromMap(
        transportInfo,
        producerCallback: _producerCallback,
      );
      debugPrint("Kathirva's Log 10: createSendTransportFromMap: Done");

      debugPrint("Kathirva's Log 11: producerTransport.on('connect') initiated");
      producerTransport.on('connect', (Map data) {
        debugPrint("Kathirva's Log 17: producerTransport.on('connect') triggered: $data");
        connectTransport(data);
      });

      debugPrint("Kathirva's Log 12: producerTransport.on('produce') initiated");
      producerTransport.on('produce', (Map data) async {
        debugPrint("Kathirva's Log 20: producerTransport.on('produce') triggered: $data");
        produceTransport(data);
      });

      producerTransport.on('connectionstatechange', (connectionState) {
        debugPrint("Kathirva's Log xx: connectionstatechange: $connectionState");
        if (connectionState == 'connected') {
          // enableChatDataProducer();
          // enableBotDataProducer();
        }
      });
      if (isVideoOn) enableCamera();
      enableMic();
    } catch (e) {
      debugPrint("Kathirva's Log xx: Error: $e");
    }
  }

  connectTransport(var data) async {
    var dtls = data['dtlsParameters'].toMap();
    // debugPrint("dtls 01: $dtls");
    // dtls['role'] = 'client';
    // debugPrint("dtls 02: $dtls");

    var connectParams = {
      'transport_id': producerTransport.id,
      'connect_parameters': {'dtls_parameters': dtls},
      ...basicSendData,
    };
    debugPrint("Kathirva's Log 18: Send event 'room:connect-transport': $connectParams");
    await socketVideo.emit('room:connect-transport', connectParams);
    var callback = data['callback'];
    callback();
    debugPrint("Kathirva's Log 19: onConnect callback done");
  }

  produceTransport(var produceData) async {
    final Map<String, dynamic> produceDataMap = {
      'transport_id': producerTransport.id,
      'producer_name': "${userId}_user_${produceData['kind']}_producer",
      'track_type': "user",
      'track_kind': produceData['kind'],
      'produce_parameters': {
        'kind': produceData['kind'],
        "rtp_parameters": produceData['rtpParameters'].toMap(),
      },
      ...basicSendData,
    };
    debugPrint("Kathirva's Log 21: Send event 'room:produce-transport': $produceDataMap");
    await socketVideo.emitWithAck('room:produce-transport', produceDataMap, ack: (data) {
      debugPrint("Kathirva's Log 22: Send event 'room:produce-transport' response: $data");
      if (data != null) {
        // Handle the response data
        var producerID = data["producer"]["id"];
        debugPrint("producerID: $producerID");
        var callback = produceData['callback'];
        callback(producerID);
      }
    });
    // 503_user_video_producer: {id: 3a35890e-bbb0-4aca-aa42-835c0c1020b6, name: 503_user_video_producer, track_type: user, track_kind: video, transport_id: 93e967e3-182e-437c-98df-fcf928b12cbc, user_id: 503},
    // 503_user_audio_producer: {id: 07920223-cc05-40a2-b561-f87192208ecd, name: 503_user_audio_producer, track_type: user, track_kind: audio, transport_id: 93e967e3-182e-437c-98df-fcf928b12cbc, user_id: 503}, 504_user_video_producer: {id: 977edeef-0aa9-4dd4-bb1d-24758aab68b6, name: 504_user_video_producer, track_type: user, track_kind: video, transport_id: d93c62fd-8e66-4026-96b1-ee8039a774a6, user_id: 504}, 504_user_audio_producer: {id: fec5890f-e1fe-4ee6-95bf-548058306225, name: 504_user_audio_producer, track_type: user, track_kind: audio, transport_id: d93c62fd-8e66-4026-96b1-ee8039a774a6, user_id: 504}}}
  }

  void _producerCallback(Producer producer) async {
    debugPrint("Kathirva's Log 23: Producer callback triggered: $producer");
    // producer.on('trackended', () {
    //   disableMic().catchError((data) {});
    // });
    await socketVideo.emitWithAck('room:resume-producer', {
      'producer_id': producer.id,
      'transport_id': producerTransport.id,
      ...basicSendData,
    }, ack: (data) {
      print('Consumer 7C: resume consume response : $data');
    });
    await VideoCallUtilities().joinCall(socketVideo, basicSendData);
    getRoomParticipants();
  }

  enableCamera() async {
/*    bool isHasPermission = false;
    if (!kIsWeb) {
      var status = await Permission.camera.request();
      isHasPermission = status.isGranted;
    }
    if (!kIsWeb && !isHasPermission) {
      debugPrint("Camera Permission Denied");
      return;
    }*/

    String facingMode = 'user';
    if (preferredCamera == 'front') {
      // Front Camera
      facingMode = 'user';
    } else {
      // Back Camera
      facingMode = 'environment';
    }
    Map<String, dynamic> mediaConstraints = <String, dynamic>{
      'audio': false,
      'video': {
        'facingMode': facingMode, // "facingMode": "environment"
        'mandatory': {
          'minWidth': '1280', // Provide your own width, height and frame rate here
          'minHeight': '720',
          'minFrameRate': '30',
        },
        // 'optional': [
        //   {
        //     'sourceId': "videoInputDeviceId",
        //   },
        // ],
      },
    };

    // NOTE: prefer using h264
    final videoVPVersion = 8; //kIsWeb ? 9 : 8;
    var temp = mediaSoupDevice.rtpCapabilities.codecs;
    debugPrint("Kathirva's Log 13: Available codecs");
    for (var codec in temp) {
      debugPrint("Kathirva's Log 13A: Codec Name: ${codec.mimeType}");
    }

    debugPrint("Kathirva's Log 14: Using 'video/VP8' codec");

    // Codec Name: audio/opus
    // Codec Name: video/VP8
    // Codec Name: video/rtx

    RtpCodecCapability codec =
        mediaSoupDevice.rtpCapabilities.codecs.firstWhere((RtpCodecCapability c) => c.mimeType.toLowerCase() == 'video/vp$videoVPVersion',
            // (RtpCodecCapability c) => c.mimeType.toLowerCase() == 'video/h264',

            orElse: () => throw 'desired vp$videoVPVersion codec+configuration is not supported');

    videoStream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
    MediaStreamTrack track = videoStream.getVideoTracks().first;

    // this.setState(() {
    //   _localRenderer.srcObject = stream;
    // });
    debugPrint("Kathirva's Log 15: Video stream created");

    debugPrint("Kathirva's Log 16: Initiating 'producerTransport.produce'");
    producerTransport.produce(
      track: track,
      codecOptions: ProducerCodecOptions(
        videoGoogleStartBitrate: 1000,
      ),
      // encodings: //kIsWeb ?
      // [
      //   // RtpEncodingParameters(
      //   //     rid: 'r0', scalabilityMode: 'S1T3', maxBitrate: 100000),
      //   // RtpEncodingParameters(scalabilityMode: 'S3T3_KEY', scaleResolutionDownBy: 1.0),
      // ],
      // OperationError: Failed to execute 'addTransceiver' on 'RTCPeerConnection': Attempted to set RtpParameters scalabilityMode to an unsupported value for the current codecs.
      // : [],
      stream: videoStream,
      appData: {
        'source': 'camera',
      },
      source: 'camera',
      codec: codec,
    );
    update();
  }

  void enableMic() async {
    if (mediaSoupDevice.canProduce(RTCRtpMediaType.RTCRtpMediaTypeAudio) == false) {
      return;
    }

    MediaStreamTrack track;
    try {
      audioStream = await createAudioStream();
      track = audioStream.getAudioTracks().first;
      debugPrint("audio Track: ${track.id}");
      producerTransport.produce(
        track: track,
        codecOptions: ProducerCodecOptions(opusStereo: 1, opusDtx: 1),
        stream: audioStream,
        appData: {
          'source': 'mic',
        },
        source: 'mic',
      );
    } catch (error) {
      if (audioStream != null) {
        await audioStream.dispose();
      }
    }
    update();
  }

  Future<MediaStream> createAudioStream() async {
    // audioInputDeviceId = mediaDevicesBloc.state.selectedAudioInput!.deviceId;
    Map<String, dynamic> mediaConstraints = {
      'audio': {
        // 'optional': [
        //   {
        //     'sourceId': "audioInputDeviceId",
        //   },
        // ],
      },
    };

    MediaStream stream = await navigator.mediaDevices.getUserMedia(mediaConstraints);

    return stream;
  }

  Future getRoomParticipants() async {
    await socketVideo.emitWithAck('room:get-post-join-data', basicSendData, ack: (data) async {
      print('Participants Response : $data');
      debugPrint("getRoomParticipants: 001");
      List<AvailableProducersModel> tempAvailableProducersList = (data['available_producers'] as Map<String, dynamic>)
          .entries
          .map((entry) => AvailableProducersModel.fromJson(entry.value))
          .toList();
      debugPrint("getRoomParticipants: 002");
      producersList = [...producersList, ...tempAvailableProducersList];
      debugPrint("getRoomParticipants: 003");
      // Extracting participants
      await processParticipantsList(data['participants']);
      debugPrint("getRoomParticipants: 004");
      // participantsList = [...participantsList, ...participants];
      // debugPrint("Total Participants length: ${participants.length}");
      // debugPrint("Total Participants: ${participants}");
      consumeEachProducer();
      debugPrint("getRoomParticipants: 005");
    });
  }

  createConsumeTransport() async {
    var params = {
      'sctpCapabilities': mediaSoupDevice.sctpCapabilities.toMap(),
      ...basicSendData,
    };
    print('Consumer 00: room:create-transport starts');
    await socketVideo.emitWithAck('room:create-transport', params, ack: (data) {
      print('Consumer 01: room:create-transport : $data');

      if (data != null) {
        var transportInfo = data['transport'];

        Map<dynamic, dynamic> transportInfoMap = {
          "id": transportInfo["id"],
          "iceParameters": transportInfo["ice_parameters"],
          "iceCandidates": transportInfo["ice_candidates"],
          "dtlsParameters": transportInfo["dtls_parameters"],
          'sctpParameters': mediaSoupDevice.sctpCapabilities.toMap(),
        };

        _consumerTransport = mediaSoupDevice.createRecvTransportFromMap(
          transportInfoMap,
          consumerCallback: _consumerCallback,
        );
        connectConsumerTransport();
      }
    });
  }

  connectConsumerTransport() {
    print('Consumer 02: connectConsumerTransport() method starts');

    _consumerTransport.on(
      'connect',
      (data) async {
        print('Consumer 06: on connect triggered : $data');

        var connectParams = {
          'transport_id': _consumerTransport.id,
          'connect_parameters': {'dtls_parameters': data['dtlsParameters'].toMap()},
          ...basicSendData,
        };

        await socketVideo.emit('room:connect-transport', connectParams);
        var callback = data['callback'];
        callback();
      },
    );
  }

  void _consumerCallback(Consumer consumer, [dynamic accept]) async {
    print('Consumer 07: consumer callback triggered : $consumer');
    print('Consumer 07A: consumer Peer ID : ${consumer.peerId}');

    ScalabilityMode scalabilityMode = ScalabilityMode.parse(consumer.rtpParameters.encodings.first.scalabilityMode);

    accept({});

    int index = participantsList.indexWhere((element) => element.user.id.toString() == consumer.peerId);
    if (index == -1) return;

    if (participantsList[index].renderer == null) {
      participantsList[index] = participantsList[index].copyWith(renderer: RTCVideoRenderer());
      await participantsList[index].renderer.initialize();
    }

    if (consumer.kind == "audio") {
      participantsList[index].copyWith(audio: consumer);
    } else if (consumer.kind == "video") {
      participantsList[index].copyWith(video: consumer);
    }

    participantsList[index].renderer.srcObject = consumer.stream;
    update();

    debugPrint("Consumer 07B::");
    await socketVideo.emitWithAck('room:resume-consumer', {
      'transport_id': _consumerTransport.id,
      'consumer_id': consumer.id, //consumerID,
      ...basicSendData,
    }, ack: (data) {
      print('Consumer 7C: resume consume response : $data');
    });

    // peersBloc.add(PeerAddConsumer(peerId: consumer.peerId, consumer: consumer));
  }

  consumeEachProducer() {
    debugPrint("availableProducersList Length 01: ${producersList.length}");
    producersList.removeWhere((element) {
      return element.userId == userId; // we do not consume our own stream
    });

    debugPrint("availableProducersList Length 02: ${producersList.length}");
    debugPrint("availableProducersList : ${producersList}");

    if (producersList.isEmpty) return;

    producersList.forEach((element) {
      consumeTransport(element);
    });
  }

  consumeTransport(AvailableProducersModel availableProducersModel) async {
    // print('Consumer 03: consume transport : $consumeData');
    // Consumer 03: consume transport : {participants: {503: {id: 503, unique_id: 503_1703660938928, user: {id: 503, name: Kathiravan}, is_video_on: true, is_audio_on: false, is_sharing: false, is_recording: false, is_disconnected: false}, 504: {id: 504, unique_id: 504_1703660874310, user: {id: 504, name: Kathiravan}, is_video_on: true, is_audio_on: false, is_sharing: false, is_recording: false, is_disconnected: false}}, participants_ids: [503, 504], available_producers: {504_user_video_producer: {id: 8d86a49f-9048-49ca-bb2c-00bfc08abfc0, name: 504_user_video_producer, track_type: user, track_kind: audio, transport_id: 298fdd04-0308-462b-af0b-960dce9cbf3c, user_id: 504}, 503_user_video_producer: {id: 9a641129-4f3a-4f38-b7b5-5804658ccd00, name: 503_user_video_producer, track_type: user, track_kind: video, transport_id: 2be79515-a723-423d-92fa-460d361f5227, user_id: 503}}}

    // Map<String, dynamic> jsonData = json.decode(consumeData.toString());

    // String producerID = "";
    // String producerTransportID = "";
    // Accessing available_producers keys dynamically
    // Extract 'transport_id' and 'id'
    // producerID = consumeData['available_producers']['503_user_video_producer']['id'];
    // producerTransportID = consumeData['available_producers']['503_user_video_producer']['transport_id'];

    // Converting data to List<AvailableProducers>

/*    int index = participantsList.indexWhere((element) => element.user.id.toString() == availableProducersModel.userId);
    if (index == -1) return;
    if (participantsList[index].audio != null && participantsList[index].video != null){
      return;
    } else if (participantsList[index].audio != null && availableProducersModel.trackKind == "audio"){
      return;
    } else if (participantsList[index].video != null && availableProducersModel.trackKind == "video"){
      return;
    }*/

    String producerID = availableProducersModel.id;
    String producerTransportID = availableProducersModel.transportId;

/*    jsonData['available_producers'].forEach((key, value) {
      producerID = value['transport_id'];
      producerTransportID = value['id'];

      // Use the extracted values
      // print("Key: $key");
      // print("Transport ID: $transportId");
      // print("ID: $id");
    });*/

    final Map<String, dynamic> produceDataMap = {
      'transport_id': _consumerTransport.id,
      'producer_id': producerID,
      'producer_transport_id': producerTransportID,
      'device_rtp_capabilities': mediaSoupDevice.rtpCapabilities.toMap(),
      ...basicSendData,
    };
    debugPrint("Consumer 04: produceDataMap: $produceDataMap");
    await socketVideo.emitWithAck('room:consume-transport', produceDataMap, ack: (data) {
      print('Consumer 05: consume transport response : $data');
      if (data != null) {
        var response = data['consumer'];
        consumerID = response['id'];
        _consumerTransport.consume(
            id: response['id'],
            producerId: response['producer_id'],
            peerId: availableProducersModel.userId.toString(),
            //response['producerId'],
            kind: RTCRtpMediaTypeExtension.fromString(response['kind']),
            rtpParameters: RtpParameters.fromMap(response['rtp_parameters']),
            accept: (param) {
              debugPrint("Consumer 5A: $param");
            });
      }
    });
  }

  processParticipantsList(var data) async {
    debugPrint("processParticipantsList 001");

    List<ParticipantModel> newDataList =
        (data as Map<String, dynamic>).entries.map((entry) => ParticipantModel.fromJson(entry.value)).toList();

    // Add new entries
    for (var newData in newDataList) {
      int index = participantsList.indexWhere((element) => element.user.id.toString() == newData.user.id.toString());

      if (index >= 0) {
        // Update existing entry if any thing need to update
      } else {
        // Add new entry
        participantsList.add(newData);
      }
    }
    debugPrint("processParticipantsList 002 : ${participantsList.length}");
    // Remove entries not available in the data
    participantsList.removeWhere((participant) {
      var newDataIds = newDataList.map((data) => data.user.id.toString()).toList();
      return !newDataIds.contains(participant.user.id.toString());
    });

    /// Assigning local video stream for self participant item
    int index = participantsList.indexWhere((element) => element.user.id.toString() == userId.toString());
    if (index >= 0) {
      if (participantsList[index].renderer == null && videoStream != null) {
        debugPrint("processParticipantsList 003 : ${participantsList.length}");
        participantsList[index] = participantsList[index].copyWith(renderer: RTCVideoRenderer());
        await participantsList[index].renderer.initialize();
        participantsList[index].renderer.srcObject = videoStream;
        update();
      }
    }
    enableOrDisableSpeakerPhone();
    debugPrint("processParticipantsList 004 : ${participantsList.length}");
    debugPrint("isCaller: $isCaller");
    if (isCaller && participantsList.length == 1 && !isOtherCallerJoined){
      playDialTone();
    } else {
      player.stop();
      if (participantsList.length > 1) isOtherCallerJoined = true;
    }
  }

  micOnOff() {
    audioStream.getAudioTracks().first.enabled = isAudioOn;
  }

  cameraOnOff() {
    if (videoStream == null) {
      enableCamera();
    } else {
      videoStream.getVideoTracks().first.enabled = isVideoOn;
    }
  }

  enableOrDisableSpeakerPhone() {
    // Loop through the participants and enable speakerphone for their audio
    try {
      for (var participant in participantsList) {
        participant?.audio?.stream?.getAudioTracks()?.first?.enableSpeakerphone(isSpeakerEnabled);
      }
    } catch (e) {
      debugPrint("Error: enableSpeakerphone: $e");
    }

    update();
  }

  switchCamera() async {
    enableBackCamera();
    update();
    // createNewTransport();
    return;
    await VideoCallUtilities().leaveCall(socketVideo, basicSendData);
    participantsList.removeWhere((element) => element.user.id == userId);
    if (preferredCamera == "front") {
      preferredCamera == "back";
    } else {
      preferredCamera == "front";
    }
    update();
    await producerTransport.close();
    createNewTransport();
    return;
    try {
      videoStream.getVideoTracks().first.switchCamera();
    } catch (e) {
      debugPrint("Error: switchCamera: $e");
    }
  }

  enableBackCamera() async{
    debugPrint("Switch Camera 001");

    Map<String, dynamic> mediaConstraints = <String, dynamic>{
      'audio': false,
      'video': {
        'facingMode': "environment", // "facingMode": "environment"
        'mandatory': {
          'minWidth': '1280', // Provide your own width, height and frame rate here
          'minHeight': '720',
          'minFrameRate': '30',
        },
      },
    };

    // NOTE: prefer using h264
    final videoVPVersion = 8; //kIsWeb ? 9 : 8;
    // var temp = mediaSoupDevice.rtpCapabilities.codecs;

    // Codec Name: audio/opus
    // Codec Name: video/VP8
    // Codec Name: video/rtx

    // RtpCodecCapability codec =
    // mediaSoupDevice.rtpCapabilities.codecs.firstWhere((RtpCodecCapability c) => c.mimeType.toLowerCase() == 'video/vp$videoVPVersion',
    //     orElse: () => throw 'desired vp$videoVPVersion codec+configuration is not supported');

    // await producerTransport.close();
    Future.delayed(const Duration(seconds: 3));
    videoStream.getVideoTracks()[0].stop();
    videoStream.dispose();
    videoStream = null;
    // VideoCallUtilities().leaveCall(socketVideo, basicSendData);

    /// Assigning local video stream for self participant item
    participantsList.removeWhere((element) => element.user.id.toString() == userId.toString());
    return;

    // videoStream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
    // MediaStreamTrack track = videoStream.getVideoTracks().first;

    /// Assigning local video stream for self participant item
    int index = participantsList.indexWhere((element) => element.user.id.toString() == userId.toString());
    participantsList[index] = participantsList[index].copyWith(renderer: null);
    if (index >= 0) {
      if (participantsList[index].renderer == null && videoStream != null) {
        participantsList[index] = participantsList[index].copyWith(renderer: RTCVideoRenderer());
        await participantsList[index].renderer.initialize();
        participantsList[index].renderer.srcObject = videoStream;
      }
    }
    debugPrint("Switch Camera 009");
  }

  playDialTone() async {
    try {
      debugPrint("Dial Tone Starts");
      String assetPath = "sounds/dial_tone.mp3";
      await player.play(AssetSource(assetPath));
      await player.resume();
      await player.setReleaseMode(ReleaseMode.loop);

      // If call is not answered, we disconnect the call after 40 seconds.
      Future.delayed(const Duration(seconds: 40)).then((value) async{
        player.stop();
        if (isCaller && !isOtherCallerJoined && conversationID != ""){
          await disconnectCallAndExit();
          Fluttertoast.showToast(
              msg: "No Answer",
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 5,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
              webPosition: "center",
              fontSize: kIsWeb ? 18 : 16.0);
          goBack();
        }
      });

      debugPrint("Dial Tone Ends");
    } catch (e) {
      debugPrint("Audio Error: $e");
    }
  }

  goBack(){
    if (kIsWeb){
      GET.Get.find<NewsfeedController>().navRoute = "isChatScreen";
      GET.Get.toNamed('${FluroRouters.mainScreen}/chats');
    } else {
      Navigator.pop(GET.Get.context);
    }
  }

  disconnectCallIfLastCaller(){
    // When there is more than one user in a call, and all the users leave the call, we disconnect the call of the last one.
    if(isOtherCallerJoined && participantsList.length == 1){
      disconnectCallAndExit();
      goBack();
    }
  }

}
