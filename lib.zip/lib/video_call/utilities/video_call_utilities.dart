

import 'dart:convert';
import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get_storage/get_storage.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/utils/urls.dart';

import '../../main.dart';
import '../../network/controller/news_feed_controller.dart';
import '../controller/video_call_controller.dart';
import '../video_call_home.dart';
import '../widgets/calling_screen.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';

class VideoCallUtilities {

  // Calls
  void joinCall(var socket, var basicSendData) async{
    debugPrint("Join call send event");
    String userName = GetStorage().read('userName');
    await socket.emit('room:joined', {
      'user': {'id': basicSendData['user_id'], 'name': userName},
      'is_video_on': true, // Set video status
      'is_audio_on': true, // Set audio status
      ...basicSendData
    });
  }
  void leaveCall(var socket, var basicSendData) {
    socket.emit('room:left', basicSendData);
  }

  void endCall(var socket, var basicSendData) {
    socket.emit('room:ended', basicSendData);
  }
  void turnOffOnVideo(var socket, var basicSendData) async{
    await socket.emit('room:video-switched', basicSendData);
  }
  void turnOffOnAudio(var socket, var basicSendData) async{
    await socket.emit('room:audio-switched', basicSendData);
  }

  // Producer

  void pauseProducer(var socket, var basicSendData, {String consumerID, String transportID}) {
    Map <String, dynamic> data = {
      "consumer_id": consumerID,
      "transport_id": transportID,
      ...basicSendData
    };
    socket.emit('room:pause-producer', data);
  }

  void resumeProducer(var socket, var basicSendData, {String consumerID, String transportID}) {
    Map <String, dynamic> data = {
      "consumer_id": consumerID,
      "transport_id": transportID,
      ...basicSendData
    };
    socket.emit('room:resume-producer', data);
  }

  void closeProducer(var socket, var basicSendData, {String consumerID, String transportID}) {
    Map <String, dynamic> data = {
      "consumer_id": consumerID,
      "transport_id": transportID,
      ...basicSendData
    };
    socket.emit('room:close-producer', data);
  }

  // Consumer

  void resumeConsumer(var socket, var basicSendData, {String consumerID, String transportID}) {
    Map <String, dynamic> data = {
      "consumer_id": consumerID,
      "transport_id": transportID,
      ...basicSendData
    };
    socket.emit('room:consume-transport', data);
  }

  void closeConsumer(var socket, var basicSendData, {String consumerID, String transportID}) {
    Map <String, dynamic> data = {
      "consumer_id": consumerID,
      "transport_id": transportID,
      ...basicSendData
    };
    socket.emit('room:close-consumer', data);
  }

  showCallingDialog({String callerName, String conversationID, bool isAudioCall = false}){
    VideoCallController videoCallController;
    if (Get.isRegistered<VideoCallController>()) {
      videoCallController = Get.find<VideoCallController>();
    } else {
      videoCallController = Get.put(VideoCallController());
    }
    videoCallController.isVideoOn = isAudioCall ? false : true;

    if (videoCallController.conversationID == null || videoCallController.conversationID.isEmpty){
      if (kIsWeb){
        showDialog(
          barrierDismissible: true,
          context: kIsWeb ? mainNavigatorKey.currentContext : navigatorKey.currentContext,
          builder: (BuildContext context) {
            return AlertDialog(
              contentPadding: EdgeInsets.zero,
              insetPadding: EdgeInsets.zero,
              shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(20),
              ),
              content: CallingScreen(callerName: callerName, conversationID: conversationID,),
            );
          },);
      } else {
        debugPrint("_firebaseMessagingBackgroundHandler: 09");
        showCallkitIncoming(callerName: callerName, conversationID: conversationID, isAudioCall: isAudioCall);
      }

    }
  }

  sendNotification({String conversationID, int newUserID}) async{
    String callerName = GetStorage().read('userName');
    int userId = GetStorage().read('id');
    int callReceiverID = newUserID == null ? Get.find<NewsfeedController>().chatName.memberId : newUserID;
    debugPrint("callReceiverID: $callReceiverID");
    if (callReceiverID == null || callReceiverID == 0) return;
    try {
      VideoCallController videoCallController;
      if (Get.isRegistered<VideoCallController>()) {
        videoCallController = Get.find<VideoCallController>();
      } else {
        videoCallController = Get.put(VideoCallController());
      }
      bool isAudioCall = videoCallController.isVideoOn ? false : true;

      String url = Url.callNotification;
      var response = await http.post(Uri.parse(url),
          headers: <String, String>{
            'Content-Type': 'application/json',
            'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
            'Token': Get.find<NewsfeedController>().userToken.toString(),
            'X-Requested-With': 'XMLHttpRequest',
          },
          body: jsonEncode({
            "user_id": callReceiverID,
            "payload": {
              "receiver_id": callReceiverID,
              "text": "$callerName is calling",
              "caller_id": userId,
              "caller_name": callerName,
              "caller_image_url": "String",
              "conversation_id": conversationID,
              "notification_type":"audio_video_call",
              "title":"Werfie",
              "body":"$callerName is calling",
              "is_audio_call": isAudioCall,
            }
          }));

      debugPrint("Response: ${response.statusCode}");
      debugPrint("Response: ${response.body}");
      if (response.statusCode == 200) {
      }
    } catch (e) {
      debugPrint("Error: $e");
    }
  }

  checkVideoCall(RemoteMessage message){
    String receiverID = message.data["receiver_id"].toString();
    String userId = GetStorage().read('id').toString();
    if (message.data["notification_type"] == "audio_video_call"){ //  && receiverID == userId
      bool isAudioCall = message.data["is_audio_call"] == "true" ? true : false ?? false;
      showCallingDialog(callerName: message.data["caller_name"], conversationID: message.data["conversation_id"], isAudioCall: isAudioCall);
    }
  }

  static Future<void> requestPermissions() async {
    if (kIsWeb) return; // Permission handler won't work on web
    try{
      // Request both camera and microphone permissions
      Map<Permission, PermissionStatus> statuses = await [
        Permission.camera,
        Permission.microphone,
      ].request();

      // Check if permissions were granted
      if (statuses[Permission.camera] == PermissionStatus.granted &&
          statuses[Permission.microphone] == PermissionStatus.granted) {
        // Both permissions granted, you can proceed with using camera and microphone
        debugPrint("Both camera and microphone permissions granted.");
      } else {
        // Handle if any of the permissions were denied
        debugPrint("Camera or microphone permissions denied.");
      }
    } catch (e){
      debugPrint("permission error: $e");
    }
  }

  static Future<void> showCallkitIncoming({String callerName, String conversationID, bool isAudioCall = false}) async {
    if (kIsWeb) return;
    cancelAllNotifications();
    VideoCallUtilities.listenCallKitEvent();
    var params = <String, dynamic>{
      'id': const Uuid().v4(),
      'nameCaller': callerName,
      'appName': 'Werfie',
      'avatar': '', //https://i.pravatar.cc/100
      'handle': '', // ''01234567'
      'type': 0,
      'duration': 30000,
      'textAccept': 'Accept',
      'textDecline': 'Decline',
      'textMissedCall': 'Missed call',
      'textCallback': 'Call back',
      'extra': <String, dynamic>{'conversationID': conversationID},
      'headers': <String, dynamic>{'apiKey': 'Abc@123!', 'platform': 'flutter'},
      'android': <String, dynamic>{
        'isCustomNotification': true,
        'isShowLogo': false,
        'isShowCallback': false,
        'ringtonePath': 'system_ringtone_default',
        'backgroundColor': '#0955fa',
        'backgroundUrl': '', // https://i.pravatar.cc/500
        'actionColor': '#4CAF50',
        'incomingCallNotificationChannelName': "Incoming Call",
      },
      'ios': <String, dynamic>{
        'iconName': 'CallKitLogo',
        'handleType': 'generic',
        'supportsVideo': true,
        'maximumCallGroups': 2,
        'maximumCallsPerCallGroup': 1,
        'audioSessionMode': 'default',
        'audioSessionActive': true,
        'audioSessionPreferredSampleRate': 44100.0,
        'audioSessionPreferredIOBufferDuration': 0.005,
        'supportsDTMF': true,
        'supportsHolding': true,
        'supportsGrouping': false,
        'supportsUngrouping': false,
        'ringtonePath': 'system_ringtone_default'
      }
    };
    await FlutterCallkitIncoming.showCallkitIncoming(params);
  }

  static Future<void> listenCallKitEvent() async {
    try {
      FlutterCallkitIncoming.onEvent.listen((event) async {
        print('FlutterCallkitIncoming 11: $event');
        switch (event.name) {
          case CallEvent.ACTION_CALL_INCOMING:
          // TODO: received an incoming call
            break;
          case CallEvent.ACTION_CALL_START:
          // TODO: started an outgoing call
          // TODO: show screen calling in Flutter
            break;
          case CallEvent.ACTION_CALL_ACCEPT:
            acceptCall(event.body["extra"]["conversationID"]);
            // accepted an incoming call
            // show screen calling in Flutter
            break;
          case CallEvent.ACTION_CALL_DECLINE:
          // TODO: declined an incoming call
            break;
          case CallEvent.ACTION_CALL_ENDED:
            cancelAllNotifications();
          // TODO: ended an incoming/outgoing call
            break;
          case CallEvent.ACTION_CALL_TIMEOUT:
          // TODO: missed an incoming call
            break;
          case CallEvent.ACTION_CALL_CALLBACK:
          // TODO: only Android - click action `Call back` from missed call notification
            break;
          case CallEvent.ACTION_CALL_TOGGLE_HOLD:
          // TODO: only iOS
            break;
          case CallEvent.ACTION_CALL_TOGGLE_MUTE:
          // TODO: only iOS
            break;
          case CallEvent.ACTION_CALL_TOGGLE_DMTF:
          // TODO: only iOS
            break;
          case CallEvent.ACTION_CALL_TOGGLE_GROUP:
          // TODO: only iOS
            break;
          case CallEvent.ACTION_CALL_TOGGLE_AUDIO_SESSION:
          // TODO: only iOS
            break;
          case CallEvent.ACTION_DID_UPDATE_DEVICE_PUSH_TOKEN_VOIP:
          // TODO: only iOS
            break;
        }
        debugPrint("Ends ::");
      });
    } on Exception {}
  }

  static acceptCall(String conversationID) async{

    cancelAllNotifications();
    final sharedPrefs = await SharedPreferences.getInstance();
    Map<dynamic, dynamic> data = {
      "conversationID": conversationID.toString(),
      "timestamp": DateTime.now().toString()
    };
    String jsonData = jsonEncode(data);
    await sharedPrefs.setString("background_call", jsonData);
    // VideoCallUtilities.requestPermissions();
    // Navigator.pop(Get.context);
    // var controller = Get.find<NewsfeedController>();

    // if (kIsWeb){
    //   // onVideoCallChange = true;
    //   controller.navRoute = "isVideoCallScreen";
    //
    //   Get.toNamed('${FluroRouters.mainScreen}/videocall', arguments: widget.conversationID);
    // } else {
    // await Future.delayed(const Duration(seconds: 3));
    gotoCall(conversationID);
    // }
    // cancelAllNotifications();
  }

  static checkBackgroundCall() async {
    await Future.delayed(const Duration(seconds: 3));
    VideoCallController videoCallController;
    if (Get.isRegistered<VideoCallController>()) {
      videoCallController = Get.find<VideoCallController>();
    } else {
      videoCallController = Get.put(VideoCallController());
    }
    if (videoCallController.conversationID != null && videoCallController.conversationID.isNotEmpty){
      // Fluttertoast.showToast(msg: "Check BgCall return");
      return;
    }

    // Fluttertoast.showToast(msg: "Checking BgCall: ");
    final sharedPrefs = await SharedPreferences.getInstance();
    String backgroundCallData = sharedPrefs.getString("background_call");
    if (backgroundCallData != null) {
      Map<dynamic, dynamic> decodedData = json.decode(backgroundCallData);
      if (decodedData.containsKey("conversationID") && isRecentCall(decodedData["timestamp"])) {
        String conversationID = decodedData["conversationID"];
        gotoCall(conversationID);
        // try{
        //   Navigator.push(navigatorKey.currentContext, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome(conversationId: conversationID)));
        // } catch (e){
        //   debugPrint("Error: $e");
        // }

      }
    }
  }

  static Future<String> getIosVoipToken() async{
    try{
      var devicePushTokenVoip = await FlutterCallkitIncoming.getDevicePushTokenVoIP();
      debugPrint("DevicePushTokenVoip: $devicePushTokenVoip");
      return devicePushTokenVoip.toString();
    } catch (e){
      debugPrint("Get iOS voip error");
      return "";
    }

  }

  static gotoCall(String conversationID) async{
    try{
      var context = navigatorKey.currentContext;
      context ??= Get.context;
      if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome(conversationId: conversationID)));
    /*  if (Platform.isIOS){
        // await FlutterCallkitIncoming.setCallConnected(this._currentUuid);
        var devicePushTokenVoip = await FlutterCallkitIncoming.getDevicePushTokenVoIP();
        debugPrint("DevicePushTokenVoip: $devicePushTokenVoip");
      }*/
    } catch (e){
      debugPrint("Error:: $e");
      // Fluttertoast.showToast(msg: "$e");
    }

  }

  static bool isRecentCall(String timestampString) {
    if (timestampString != null) {
      DateTime timestamp = DateTime.parse(timestampString);
      DateTime now = DateTime.now();
      Duration difference = now.difference(timestamp);
      return difference.inSeconds <= 20;
    }
    return false;
  }

  static cancelAllNotifications() async{
    debugPrint("cancelAllNotifications starts");
    // Initialize the plugin
    FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    // Call cancelAll to cancel all pending notifications
    await flutterLocalNotificationsPlugin.cancelAll();
    debugPrint("cancelAllNotifications end");
  }
}