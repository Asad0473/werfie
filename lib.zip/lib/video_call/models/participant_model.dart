import 'package:mediasoup_client_flutter/mediasoup_client_flutter.dart';

class ParticipantModel {
  final int id;
  final String uniqueId;
  final UserData user;
  final bool isVideoOn;
  final bool isAudioOn;
  final bool isSharing;
  final bool isRecording;
  final bool isDisconnected;
  final Consumer audio;
  final Consumer video;
  final RTCVideoRenderer renderer;

  ParticipantModel({
    this.id,
    this.uniqueId,
    this.user,
    this.isVideoOn,
    this.isAudioOn,
    this.isSharing,
    this.isRecording,
    this.isDisconnected,
    this.audio,
    this.video,
    this.renderer,
  });

  factory ParticipantModel.fromJson(Map<String, dynamic> json) {
    return ParticipantModel(
      id: json['id'],
      uniqueId: json['unique_id'],
      user: UserData.fromJson(json['user']),
      isVideoOn: json['is_video_on'] ??  false,
      isAudioOn: json['is_audio_on'] ?? false,
      isSharing: json['is_sharing'] ??  false,
      isRecording: json['is_recording'] ?? false,
      isDisconnected: json['is_disconnected'] ?? false,
    );
  }

  ParticipantModel copyWith({
    int id,
    String uniqueId,
    UserData user,
    bool isVideoOn,
    bool isAudioOn,
    bool isSharing,
    bool isRecording,
    bool isDisconnected,
    Consumer audio,
    Consumer video,
    RTCVideoRenderer renderer,
  }) {
    return ParticipantModel(
      id: id ?? this.id,
      uniqueId: uniqueId ?? this.uniqueId,
      user: user ?? this.user,
      isVideoOn: isVideoOn ?? this.isVideoOn,
      isAudioOn: isAudioOn ?? this.isAudioOn,
      isSharing: isSharing ?? this.isSharing,
      isRecording: isRecording ?? this.isRecording,
      isDisconnected: isDisconnected ?? this.isDisconnected,
      audio: audio ?? this.audio,
      video: video ?? this.video,
      renderer: renderer ?? this.renderer,
    );
  }
}

class UserData {
  final int id;
  final String name;

  UserData({this.id, this.name});

  factory UserData.fromJson(Map<String, dynamic> json) {
    return UserData(
      id: json['id'],
      name: json['name'],
    );
  }
}
