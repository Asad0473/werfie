class AvailableProducersModel {
  final String id;
  final String name;
  final String trackType;
  final String trackKind;
  final String transportId;
  final int userId;

  AvailableProducersModel({
    this.id,
    this.name,
    this.trackType,
    this.trackKind,
    this.transportId,
    this.userId,
  });

  factory AvailableProducersModel.fromJson(Map<String, dynamic> json) {
    return AvailableProducersModel(
      id: json['id'],
      name: json['name'],
      trackType: json['track_type'],
      trackKind: json['track_kind'],
      transportId: json['transport_id'],
      userId: json['user_id'],
    );
  }
}