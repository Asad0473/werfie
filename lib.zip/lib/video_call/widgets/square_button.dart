import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color iconColor;
  final Color bgColor;
  const SquareButton({Key key, @required this.icon, @required this.onTap, this.iconColor, this.bgColor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color bgColor = this.bgColor ?? Colors.grey.shade200;

    return InkWell(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 5.0),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(100.0)
        ),
        width: 50.0,
        height: 50.0,
        child: Icon(icon, color: iconColor,)
      ),
    );
  }
}
