import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:werfieapp/video_call/utilities/video_call_utilities.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../utils/fluro_router.dart';
import '../video_call_home.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class CallingScreen extends StatefulWidget {
  final String callerName, conversationID;
  const CallingScreen({Key key, this.callerName, this.conversationID}) : super(key: key);

  @override
  State<CallingScreen> createState() => _CallingScreenState();
}

class _CallingScreenState extends State<CallingScreen> {
  final player = AudioPlayer();
  @override
  void initState() {
    playSound();
    super.initState();
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height/2,
      child: Center(
        child: Container(
          // height: MediaQuery.of(context).size.height/2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                'Incoming Call from',
                style: TextStyle(fontSize: 20),
              ),
              const SizedBox(height: 10),
              Text(
                widget.callerName,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 50),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(20),
                      primary: Colors.red,
                    ),
                    onPressed: () {
                      VideoCallUtilities.cancelAllNotifications();
                      Navigator.pop(context);
                    },
                    child: const Icon(
                      Icons.call_end,
                      size: 30,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 50),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      shape: CircleBorder(),
                      padding: EdgeInsets.all(20),
                      primary: Colors.green,
                    ),
                    onPressed: () {
                      VideoCallUtilities.requestPermissions();
                      Navigator.pop(context);
                      var controller = Get.find<NewsfeedController>();

                      if (kIsWeb){
                        // onVideoCallChange = true;
                        controller.navRoute = "isVideoCallScreen";

                        Get.toNamed('${FluroRouters.mainScreen}/videocall', arguments: widget.conversationID);
                      } else {
                        Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome(conversationId: widget.conversationID)));
                      }
                      VideoCallUtilities.cancelAllNotifications();
                    },
                    child: const Icon(
                      Icons.phone,
                      size: 30,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  playSound() async {
    String assetPath = "sounds/ringing.mp3";
    await player.play(AssetSource(assetPath));
    await player.resume();
  }
}
