import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../models/participant_model.dart';

class ParticipantsList extends StatefulWidget {
  final List<ParticipantModel> participantsList;

  const ParticipantsList({Key key, this.participantsList}) : super(key: key);

  @override
  State<ParticipantsList> createState() => _ParticipantsListState();
}

class _ParticipantsListState extends State<ParticipantsList> {
  @override
  Widget build(BuildContext context) {
    return _body();
    return Scaffold(
      body: _body(),
    );
  }

  Widget _body() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20.0),
        color: Colors.grey[50],),
      width: 300,
      height: double.infinity,
      child: Column(
        children: [
          Container(
            child: Text("Participants", style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.w500),),
          ),
          Divider(),
          Expanded(
            child: ListView.builder(
                itemCount: widget.participantsList.length,
                itemBuilder: (context, index) {
                  return _listItem(widget.participantsList[index]);
                }),
          ),
        ],
      ),
    );
  }

  Widget _listItem(ParticipantModel participantModel){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2.0),
          child: Row(
            children: [
              Text(participantModel.user.name, style: TextStyle(color: Colors.black87, fontSize: 15.0),),
              Spacer(),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    participantModel.isAudioOn ? Icons.mic : Icons.mic_off,
                    color: Colors.black54,
                    size: 20.0,
                  )),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    participantModel.isAudioOn ? Icons.videocam : Icons.videocam_off,
                    color: Colors.black54,
                    size: 20.0,
                  ))
            ],
          ), //participantModel.user.name
        ),
        Divider(color: Colors.grey[100],)
      ],
    );
  }
}
