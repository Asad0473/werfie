import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../../network/controller/news_feed_controller.dart';
import '../../utils/fluro_router.dart';
import '../controller/video_call_controller.dart';
import '../utilities/video_call_utilities.dart';
import '../video_call_home.dart';

class CallButtons extends StatelessWidget {
  final BuildContext context;
  final String conversationId;
  const CallButtons({Key key, this.context, this.conversationId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(onPressed: () {
          VideoCallController videoCallController;
          if (Get.isRegistered<VideoCallController>()) {
            videoCallController = Get.find<VideoCallController>();
          } else {
            videoCallController = Get.put(VideoCallController());
          }
          videoCallController.isVideoOn = false;
          videoCallController.isCaller = true;

          gotoCall();
        },
          icon: Icon(Icons.call),
          iconSize: 20.0,
          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
        ),
        IconButton(onPressed: () {
          VideoCallController videoCallController;
          if (Get.isRegistered<VideoCallController>()) {
            videoCallController = Get.find<VideoCallController>();
          } else {
            videoCallController = Get.put(VideoCallController());
          }
          videoCallController.isCaller = true;

          gotoCall();
        },
          icon: Icon(Icons.videocam_rounded),
          iconSize: 25.0,
          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
        ),
      ],
    );;
  }

  gotoCall(){
    VideoCallUtilities.requestPermissions();
    if (kIsWeb){
      // onVideoCallChange = true;
      Get.find<NewsfeedController>().navRoute = "isVideoCallScreen";
      Get.toNamed(FluroRouters.mainScreen + '/videocall', arguments: conversationId);
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => VideoCallHome(conversationId: conversationId,)));
    }
    VideoCallUtilities().sendNotification(conversationID: conversationId);
  }
}
