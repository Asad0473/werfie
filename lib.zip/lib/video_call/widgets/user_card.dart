import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../models/participant_model.dart';

class UserCard extends StatelessWidget {
  final RTCVideoRenderer renderer;
  final ParticipantModel participantModel;
  final double width, height;
  final bool showCallingText;
  const UserCard({Key key, this.renderer, this.participantModel, this.width, this.height, this.showCallingText}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [

          Container(
            height: height ?? 250,
            width: width ?? 350,
            decoration: BoxDecoration(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black : Colors.grey[200],
                borderRadius: BorderRadius.circular(10.0)),
            margin: const EdgeInsets.all(5.0),
            child: participantModel == null || participantModel.renderer == null ? avatar(context) : videoView(),
          ),
          /*Positioned(
            top: 20.0,
            right: 20.0,
              child: Icon(participantModel.isAudioOn ? Icons.mic : Icons.mic_off, color: Colors.black54,)),*/
          participantModel != null && participantModel.renderer != null ? Positioned(
              bottom: 20.0,
              right: 0.0,
              left: 0.0,
              child: Center(child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0),
                child: Text(participantModel.user.name,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18.0, color: Colors.white, height: 1.0),),
              ))) : const SizedBox(),
        ],
      ),
    );
  }

  Widget videoView(){
    return Container(
      height: 200,
      width: 200,
      key: const Key('local'),
      margin: const EdgeInsets.fromLTRB(5.0, 5.0, 5.0, 5.0),
      decoration: const BoxDecoration(color: Colors.grey),
      child: RTCVideoView(
        participantModel.renderer,
        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
      ),
    );
  }

  Widget avatar(context){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 65,
          backgroundColor: Colors.white,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child:
            // controller.userProfile.profileImage != null
            //     ? Image.network(
            //   controller.userProfile.profileImage,
            //   fit: BoxFit.cover,
            //   width: 150,
            //   height: 150,
            // )
            //     :
            Image.asset(
              'assets/images/person_placeholder.png',
              fit: BoxFit.cover,
              width: 150,
              height: 150,
            ),
          ),
        ),
        const SizedBox(height: 5.0,),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8.0),
          child: Text(participantModel != null ? participantModel.user.name : "",
            textAlign: TextAlign.center,
            style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black),),
        ),
        const SizedBox(height: 5.0,),
        participantModel == null && showCallingText != null && showCallingText ? const Text("Calling...") : const SizedBox(),
      ],
    );
  }
}
