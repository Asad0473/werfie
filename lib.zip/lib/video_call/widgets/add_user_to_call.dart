import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/strings.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:werfieapp/widgets/chat_screen_mobile.dart';

import '../models/participant_model.dart';
import '../utilities/video_call_utilities.dart';

class AddUserToCall extends StatelessWidget {
  AddUserToCall({this.conversationId, this.participantsList});

  final controller = Get.find<NewsfeedController>();
  final conversationId;
  final List<ParticipantModel> participantsList;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return SingleChildScrollView(
        child: StatefulBuilder(
          builder: (context, setState) {
            return Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(.2),
                    spreadRadius: 0,
                    blurRadius: 0,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
              ),
              width: kIsWeb ? 500 : MediaQuery.of(context).size.width * 0.9,
              height: kIsWeb ? 500 : MediaQuery.of(context).size.height * 0.6,
              child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 12, right: 12, top: 12, bottom: 0),
                          child: Row(
                            //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconButton(
                                onPressed: () {
                                  Navigator.of(context).pop();

                                  controller.usersList.clear();
                                  controller.selectedPeople.clear();
                                  controller.idList.clear();

                                  controller.update();
                                },
                                icon: Icon(
                                  Icons.close,
                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                "Add user to call",
                                // style: TextStyle(
                                //     fontWeight: FontWeight.bold),
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                ),
                              ),
                              Spacer(),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: TextField(
                            style: LightStyles.baseTextTheme.headline2
                                .copyWith(color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black),
                            cursorColor: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                            autofocus: true,
                            controller: controller.chatSearchTEC,
                            focusNode: controller.chatSearchTextFocus,
                            onChanged: (value) async {
                              if (value.isEmpty) {
                                var result = await controller.searchChatUser("");
                                if (controller.chatSearchTEC.text == value) {
                                  controller.usersList = result;
                                  controller.isChatUsersLoad = false;
                                  controller.usersList = null;
                                  controller.update();
                                }
                              } else {
                                if (value[0] == '@') {
                                  var result = await controller.searchChatUser(value.substring(1));
                                  if (controller.chatSearchTEC.text == value) {
                                    controller.usersList = result;
                                    controller.update();
                                  }
                                } else {
                                  var result = await controller.searchChatUser(value);
                                  ;
                                  if (controller.chatSearchTEC.text == value) {
                                    controller.usersList = result;
                                    controller.update();
                                  }
                                }
                              }
                            },
                            textAlignVertical: TextAlignVertical.center,
                            decoration: InputDecoration(
                              hintText: Strings.searchPeople,
                              hintStyle: LightStyles.baseTextTheme.headline3,
                              prefixIcon: Icon(
                                Icons.search,
                                size: 20,
                                color: controller.displayColor,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 0,
                                  style: BorderStyle.none,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 0,
                                  style: BorderStyle.none,
                                ),
                              ),
                              fillColor: Colors.grey[250],
                            ),
                          ),
                        ),
                        controller.selectedPeople != null && controller.selectedPeople.isNotEmpty
                            ? Wrap(
                                children: List.generate(controller.selectedPeople.length, (index) {
                                  return Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: ActionChip(
                                      onPressed: () {
                                        print('pressed');
                                        controller.selectedPeople.removeAt(index);
                                        controller.usersList.removeAt(index);
                                        controller.idList.removeAt(index);
                                        controller.update();
                                        setState(() {});
                                      },
                                      elevation: 8.0,
                                      padding: EdgeInsets.symmetric(vertical: 6, horizontal: 2),
                                      avatar: CircleAvatar(
                                        radius: 16,
                                        backgroundColor: Colors.white,
                                        child: GestureDetector(
                                          onTap: () {
                                            print('pressed');
                                            controller.usersList.clear();
                                            controller.selectedPeople.clear();
                                            controller.idList.clear();

                                            controller.update();
                                            setState(() {});
                                          },
                                          child: Icon(
                                            Icons.close,
                                            color: controller.displayColor,
                                            size: 12,
                                          ),
                                        ),
                                      ),
                                      label: Text(
                                        controller.selectedPeople[index].toString(),
                                        style: Styles.baseTextTheme.headline4.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                      backgroundColor: controller.displayColor,
                                      shape: StadiumBorder(
                                          side: BorderSide(
                                        width: 1,
                                        color: controller.displayColor,
                                      )),
                                    ),
                                  );
                                }),
                              )
                            : Container(),
                        Divider(),

                        ///SearchList
                        Expanded(
                                child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: controller.usersList == null ? 0 : controller.usersList.length,
                                itemBuilder: (context, index) => Card(
                                  elevation: 2,
                                  margin: EdgeInsets.all(10),
                                  child: ListTile(
                                    onTap: () {
                                      int selectedUserID = controller.usersList[index]['id'];
                                      debugPrint("User tapped: $selectedUserID");
                                      int userIndex = participantsList.indexWhere((element) => element.user.id.toString() == selectedUserID.toString());
                                      if (userIndex == -1) {
                                        // Send notification when user is not in the call.
                                        VideoCallUtilities().sendNotification(conversationID: conversationId.toString(), newUserID: selectedUserID);
                                      }
                                      Navigator.pop(context);
                                    },
                                    leading: // controller.groupName != null ? controller.groupName :
                                        controller.usersList[index]['profile_image']
                                                // != null ? controller.chatName.profileImage
                                                ==
                                                null
                                            ? CircleAvatar(
                                                backgroundImage: AssetImage('assets/images/person_placeholder.png'),
                                              )
                                            : Padding(
                                                padding: const EdgeInsets.only(bottom: 4, left: 7),
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(30),
                                                  child: FadeInImage(
                                                      fit: BoxFit.cover,
                                                      width: 40,
                                                      height: 40,
                                                      placeholder: AssetImage('assets/images/person_placeholder.png'),
                                                      image: NetworkImage(controller.usersList[index]['profile_image'] != null
                                                          ? controller.usersList[index]['profile_image']
                                                          : "assets/images/person_placeholder.png")),
                                                ),
                                              ),
                                    title: Row(
                                      children: [
                                        Flexible(
                                          child: Text(
                                            controller.usersList[index]['firstname'],
                                            softWrap: true,
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ),
                                        controller.usersList[index]['account_verified'] == "verified"
                                            ? Row(
                                                children: [
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  BlueTick(
                                                    height: 15,
                                                    width: 15,
                                                    iconSize: 10,
                                                  ),
                                                ],
                                              )
                                            : SizedBox(),
                                      ],
                                    ),
                                    subtitle: Text(
                                      controller.usersList[index]['username'],
                                      style: Styles.baseTextTheme.headline4.copyWith(
                                        fontWeight: FontWeight.w400,
                                        fontSize: kIsWeb ? 14 : 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ))
                      ],
                    ),
            );
          },
        ),
      );
    });
  }
}
