import 'dart:core';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_compress/video_compress.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:werfieapp/widgets/web_createpostModule/video_playerchat.dart';

import 'network/controller/news_feed_controller.dart';

class DummyData extends GetxController {
  int likesCount = 4;

  incrementlikeCount(int index) {
    _posts[index]['likesCount']++;

    // print(_posts[index]['likesCount']);
  }

  final showAllComments = false.obs;

  var commentsCount = 3.obs;

  final isWeb = false.obs;
  // List<File> videoFiles = [];
  var singleVideo;

  togglePlatform() => isWeb.value = !isWeb.value;
  final isReplyComment = true.obs;

  toggleReplyComment(int postIndex, int commentIndex) {
    _posts[postIndex]['comments'][commentIndex]['isReplyOnWeb'].value =
        !_posts[postIndex]['comments'][commentIndex]['isReplyOnWeb'].value;
  }

  toggleComment(int index) {
    _posts[index]['isCommentOnWeb'].value =
        !_posts[index]['isCommentOnWeb'].value;
  }

  List _posts = [
    {
      'share': false.obs,
      'userName': 'Michael',
      'text':
          'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.',
      'imageUrl': [
        'assets/images/person1.jpeg',
        'assets/images/person6.jpeg',
        'assets/images/person2.jpeg',
        'assets/images/person3.jpeg',
        'assets/images/person4.jpeg',
        'assets/images/person5.jpeg',
        'assets/images/person6.jpeg',
        'assets/images/person1.jpeg',
      ],
      'likesCount': 3.obs,
      'isCommentOnWeb': false.obs,
      'comments': [
        {
          'commentText': 'Hey there.',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
        {
          'commentText': 'Nice',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
        {
          'commentText': 'Wow',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
        {
          'commentText': 'Great',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
        {
          'commentText': 'Exquisite',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
      ].obs,
    },
    {
      'share': false.obs,
      'userName': 'Jenny',
      'text':
          'A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.',
      'likesCount': 3.obs,
      'isCommentOnWeb': false.obs,
      'comments': [
        {
          'commentText': 'Hey there.',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
      ].obs,
    },
    {
      'share': false.obs,
      'userName': 'Liam',
      'videoUrl':
          'https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4',
      'likesCount': 3.obs,
      'isCommentOnWeb': false.obs,
      'comments': [
        {
          'commentText': 'Hey there.',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
      ].obs,
    },
    {
      'share': false.obs,
      'userName': 'Joana',
      'audioUrl':
          'https://file-examples-com.github.io/uploads/2017/11/file_example_MP3_700KB.mp3',
      'likesCount': 3.obs,
      'isCommentOnWeb': false.obs,
      'comments': [
        {
          'commentText': 'Hey there.',
          'replies': [].obs,
          'isReplyOnWeb': false.obs,
        },
      ].obs,
    }
  ].obs;

  List get posts {
    return [..._posts];
  }

  void addComment(int index, String comment) {
    _posts[index]['comments'].insert(0, {
      'commentText': comment,
      'replies': [],
      'isReplyOnWeb': false.obs,
    });
    // print(_posts[index]['comments'].length);
    toggleComment(index);
  }

  void addReply(int postIndex, int commentIndex, String comment) {
    _posts[postIndex]['comments'][commentIndex]['replies'].insert(0, comment);
    // print(_posts[postIndex]['comments'][commentIndex]['replies'].length);
    toggleReplyComment(postIndex, commentIndex);
  }

  void addReplyMobile(int postIndex, int commentIndex, String comment) {
    _posts[postIndex]['comments'][commentIndex]['replies'].insert(0, comment);
    // print(_posts[postIndex]['comments'][commentIndex]['replies'].length);
  }

  void deleteComment(int postIndex, int commentIndex) {
    _posts[postIndex]['comments'].removeAt(commentIndex);
  }

  void deleteReply(int postIndex, int commentIndex) {
    _posts[postIndex]['comments'][commentIndex]['replies'].removeAt(0);
  }

  Future<List<XFile>> multiImageSelected() async {
    try {
      final ImagePicker imagePicker = ImagePicker();
      List<XFile> imageFileList = [];

      final List<XFile> selectedImages = await imagePicker.pickMultiImage();
      if (selectedImages.isNotEmpty) {
        imageFileList.addAll(selectedImages);
        // print("Image List Length:" + imageFileList.length.toString());
      }

      if (imageFileList != null || imageFileList.isNotEmpty) {
        return imageFileList;
      } else {
        return null;
      }
    } catch (e) {
      // print("errrrrrrrrrrrrrrrrrrrr$e");
    }
  }

  Future<PickedFile> getImage() async {
    try {
      final picker = ImagePicker();

      final pickedFile = await picker.getImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        return pickedFile;
      } else {
        // print(pickedFile.path);
        return null;
      }
    } catch (e) {
      // print("errrrrrrrrrrrrrrrrrrrr$e");
    }
  }

  // ignore: missing_return
  Future<Map<String, dynamic>> getVideo() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickVideo(source: ImageSource.gallery);
    /*print("PICKED FILE PATH");
    print(pickedFile.mimeType);
    print(pickedFile.path);
    print(pickedFile.name);*/

    try {
      if (pickedFile != null) {
        if (kIsWeb) {
          // print("file catch in web");
          var bytes = pickedFile.readAsBytes();
          Get
              .find<NewsfeedController>()
              .videoController = VideoPlayerChat(videoUrl: pickedFile.path);
          // videoFiles.add();
          return {
            'bytes': bytes,
            'name': pickedFile.name,
            'memeType': pickedFile.mimeType
          };
        } else {
          // print("file catch in mobile");
          var bytes = pickedFile.readAsBytes();
          /*
        final compressedVideo = await VideoCompress.compressVideo(
          pickedFile.path,
          quality: VideoQuality.LowQuality,
          deleteOrigin: false, // It's false by default
        );
        File compressedFile = File(compressedVideo.path);
        // print("compressed video size " + compressedVideo.filesize.toString());
        var bytes = compressedFile.readAsBytes(); */
          // print("before");
          // print(pickedFile.path);
          // print (await File(pickedFile.path).length());
          // print("before");
          // await VideoCompress.setLogLevel(0);
          // final MediaInfo info = await VideoCompress.compressVideo(
          //   File(pickedFile.path).path,
          //   quality: VideoQuality.MediumQuality,
          //   deleteOrigin: false,
          //   includeAudio: true,
          // );
          // print("path");
          // print(info.file.path);
          // print (await info.file.length());
          // print("path");
          // videoFiles.add(compressedFile);
          var controller = Get.find<NewsfeedController>();
          controller.modelList2[controller.currentIndexText].videoThumbnail =
          await VideoThumbnail.thumbnailData(
            video: File(pickedFile.path).path,
            imageFormat: ImageFormat.JPEG,
            maxWidth: 128,
            // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
            quality: 100,
          );
          return {
            'bytes': bytes,
            'name': pickedFile.name,
            'memeType': pickedFile.mimeType
          };
        }
      } else {
        // print('No image selected');
      }
    }catch(e){
      print(e);
    }
  }



  Future<Map<String, dynamic>> getVideoFromCamera() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickVideo(source: ImageSource.camera);

    if (pickedFile != null) {
      if (kIsWeb) {
        // print("file catch in web");
        var bytes = pickedFile.readAsBytes();
        // videoFiles.add();
        return {
          'bytes': bytes,
          'name': pickedFile.name,
          'memeType': pickedFile.mimeType
        };
      } else {
        // print("file catch in mobile");
        final compressedVideo = await VideoCompress.compressVideo(
          pickedFile.path,
          quality: VideoQuality.LowQuality,
          deleteOrigin: false, // It's false by default
        );
        File compressedFile = File(compressedVideo.path);
        // print("compressed video size " + compressedVideo.filesize.toString());
        var bytes = compressedFile.readAsBytes();
        // print("before");
        // print(pickedFile.path);
        // print (await File(pickedFile.path).length());
        // print("before");
        // await VideoCompress.setLogLevel(0);
        // final MediaInfo info = await VideoCompress.compressVideo(
        //   File(pickedFile.path).path,
        //   quality: VideoQuality.MediumQuality,
        //   deleteOrigin: false,
        //   includeAudio: true,
        // );
        // print("path");
        // print(info.file.path);
        // print (await info.file.length());
        // print("path");
        // videoFiles.add(compressedFile);
        return {
          'bytes': bytes,
          'name': pickedFile.name,
          'memeType': pickedFile.mimeType
        };
      }
    } else {
      // print('No image selected');
    }
  }

  // Future<PickedFile> getVideoWithoutBytes() async {
  //   final picker = ImagePicker();
  //   final pickedFileWithoutBytes =
  //       await picker.getVideo(source: ImageSource.gallery);
  //   if (pickedFileWithoutBytes != null) {
  //     return pickedFileWithoutBytes;
  //   } else {
  //     print('No image selected');
  //   }
  // }

  // ignore: missing_return
  Future<Map<String, dynamic>> getFile() async {
    FilePickerResult result = await FilePicker.platform
        .pickFiles(withData: true, type: FileType.custom, allowedExtensions: [
      'pdf',
    ]);
    if (result != null) {
      Uint8List fileBytes = result.files.first.bytes;
      // print('File Bytes  ' + fileBytes.toString());
      String pdfFileName = result.files.first.name;
      String pdfFileExt = result.files.first.extension;
      // print("HERE IS PDF FILE NAME  " + pdfFileName);
      return {
        'fileBytes': fileBytes,
        'pdfFileName': pdfFileName,
        'pdfFileExt': pdfFileExt
      };
    }
  }

  void createPost({
    String text,
    List imageUrl,
    dynamic videoUrl,
    String audioUrl,
    String documentName,
    int documentSize,
    RxBool share,
  }) {
    _posts.insert(
      0,
      {
        'share': share,
        'text': text,
        'imageUrl': imageUrl,
        'videoUrl': videoUrl,
        'likesCount': 0.obs,
        'isCommentOnWeb': false.obs,
        'audioUrl': audioUrl,
        'documentName': documentName,
        'documentSize': documentSize,
        'comments': [
          {
            'commentText': 'Hey there.',
            'replies': [].obs,
            'isReplyOnWeb': false.obs,
          },
        ].obs,
      },
    );
    // print(_posts[0]);
  }

  void deletePost(int postIndex) {
    _posts.removeAt(postIndex);
  }

  // ignore: missing_return
  Future<PlatformFile> getAudioMobile() async {
    PlatformFile _audioFile;
    FilePickerResult result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.audio,
    );

    if (result != null) {
      _audioFile = result.files.first;
      // print(_audioFile.name);
      return _audioFile;
    } else {
      // User canceled the picker
    }
  }

  // ignore: missing_return
  Future<Uint8List> getAudio() async {
    Uint8List _audio;
    FilePickerResult result = await FilePicker.platform.pickFiles(
      allowMultiple: false,
      type: FileType.custom,
      withData: true,
      allowedExtensions: ['mp3'],
    );
    if (result != null) {
      _audio = result.files.first.bytes;
      // print('AUDIO BYTES DATA     ' + result.files.first.bytes.toString());
      return _audio;
    } else {
      // User canceled the picker
    }
  }
}
