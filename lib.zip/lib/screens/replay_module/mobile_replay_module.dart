import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:file_support/file_support.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/network/controller/google_search_location.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_post_icons.dart';
import '../../components/rounded_button.dart';
import '../../models/create_post_model/create_post_model.dart';
import '../../models/post.dart';
import '../../models/scrapping.dart';
import '../../network/controller/news_feed_controller.dart';
import 'package:dio/dio.dart' as _dio;
import '../../network/singleTone.dart';
import '../../utils/emojis.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../web_views/dialogbox_web.dart';
import '../../web_views/web_guest_user/components/guest_user_post_card.dart';
import '../../widgets/blue_tick.dart';
import '../../widgets/post_image_description.dart';
import '../../widgets/post_text_description.dart';
import '../google_search_screen.dart';

class ReplayMobile extends StatefulWidget {
  ReplayMobile({
    Key key,
    this.post,
    this.newsfeedController,
    this.profileImageUrl,
    this.replyPageId,
    this.getClickId,
  }) : super(key: key);
  bool isPostScheduled = false;
  DateTime dateTimeData;
  List postsForDeletions = [];
  bool mentionUser = false;
  bool mentionTag = false;
  Post post;

  final String profileImageUrl;
  List<dynamic> users = [];
  List<dynamic> tags = [];
  final NewsfeedController newsfeedController;
  var focusNode = FocusNode();
  int replyPageId;
  int getClickId;

  @override
  State<ReplayMobile> createState() => _ReplayMobileState();
}

class _ReplayMobileState extends State<ReplayMobile>
    with SingleTickerProviderStateMixin {
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;
  int postId = 0;
  List EditimageThumbnailsList = [];

  ScrollController scrollController = ScrollController();

  bool visibility = false;
  bool threadCreated = false;
  bool closeIcon = false;
  String selectedDateTime;

  var checkFocus = false.obs;
  bool editImageCheck = false;

  /// emojis variable
  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  int _selectedTab = 0;
  StreamSubscription<bool> keyboardSubscription;
  TabController _tabController;
  List<bool> showPolls = [];
  ScrollController _scrollController;

  bool isPortrait = false;
  double width = 0, height = 0;

  List<TextEditingController> _controller =
      List.generate(2, (i) => TextEditingController());

  // List<TextEditingController> _controller = [];

  // var controller = Get.find<NewsfeedController>();

  List<PlatformFile> listFiles = [];
  List<PlatformFile> compressedFiles = [];

  bool isTagSelected = false;

  List<FocusNode> fNode1 =
      List<FocusNode>.generate(1, (int index) => FocusNode());
  List<FocusNode> fNode2 =
      List<FocusNode>.generate(1, (int index) => FocusNode());
  FocusNode focusNodeText = FocusNode();
  FocusNode focusNode = FocusNode();

  GoogleSearchLocation locationController = Get.put(GoogleSearchLocation());

  final DummyData dataController = Get.find();
  bool isMediaUploading = false;

  var postTextController = TextEditingController();
  String link, linkTitle, linkMeta, linkImage;
  String scheduleMonthValue = DateTime.now().month.toString();
  String scheduleDayValue = DateTime.now().day.toString();
  String scheduleYearValue = DateTime.now().year.toString();
  String scheduleHourValue = DateTime.now().hour.toString();
  String selectedMonthValue = DateTime.now().month.toString();
  String selectedDayValue = DateTime.now().day.toString();
  String selectedYearValue = DateTime.now().year.toString();
  String selectedHourValue = DateTime.now().hour.toString();

  String scheduleMinutesValue = DateTime.now().minute.toString();
  String selectedMinutesValue = DateTime.now().minute.toString();
  bool monthValidatedSuccessfully = true;
  bool dayValidatedSuccessfully = true;
  bool hourValidatedSuccessfully = true;
  bool minutesValidatedSuccessfully = true;
  bool showScheduledWerfs = false;
  bool isEditable = false;
  bool isCheckBoxSelected = false;
  bool checkLocation = false;
  bool isMediaAttached = false;

  bool isImageAttached = false;

  File videoPicker;
  File pickedMedia;
  Uint8List pickedAudio;
  PickedFile pickedMediaFile;
  Uint8List imageBytes, videoBytes, pdfBytes;
  List<String> _pdfFilesName = [];
  Map<String, dynamic> _pdfs;
  PickedFile singleVideoFile;
  List<File> videoFiles = [];
  List<Uint8List> _pickedVideos = [];
  List<String> _pickedVideosName = [];
  List<String> _pickedVideosMemeType = [];
  List<Uint8List> _pickedAudios = [];

  // ignore: unused_field
  bool _validURL = false;

  // bool showPolls = false;
  int option = 2;
  bool onHover = false;
  bool isOptionThree = false;
  bool isOptionTwo = true;
  List<int> days = [0, 1, 2, 3, 4, 5, 6, 7];
  String pollDays = '0';
  String pollHours = '0';
  String pollMinutes = '0';
  String pollQuestionOne, pollQuestionTwo, pollQuestionThree, pollQuestionFour;
  String txtOption1 = '';
  String txtOption2 = '';
  String txtOption3 = '';
  String txtOption4 = '';
  bool apiCalled = false;
  String videoThumbnail = '';
  String imageThumbnail = '';
  String pdfName = '';
  String audioUrl = '';
  List imageThumbnailsList = [];
  String temp = '';
  String tempValue = '';
  String selectedHashTag = '';
  String tempUsername = '';
  final ScrollController scrollControllerBehaviour = ScrollController();
  List<int> years = [2022, 2023, 2024];
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List<int> minutes = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59
  ];
  List<PlatformFile> _paths;
  List<Uint8List> _pickedImage = [];
  List<Uint8List> _pickedPdfs = [];
  bool _loadingPath = false;
  final bool _multiPick = true;
  int imageWidgetKey = 0;
  int videoWidgetKey = 0;
  int pdfWidgetKey = 0;

  int postBodyLength = 0;

  int counter = 0;

  bool dragValue = false;
  bool translateLoading = false;

  @override
  void initState() {
    //
    // widget.newsfeedController.imageCounter=0;
    // widget.newsfeedController.descriptionCounter = 0;
    // if(widget.newsfeedController.imageDescriptionController.length>0){
    //
    //   widget. newsfeedController.imageDescriptionController.forEach((element) {
    //     element.clear();
    //   });
    // }

    focusNode.requestFocus();
    widget.newsfeedController.usersList = [];
    // for (int i = 0; i < 30; i++) _controller.add(TextEditingController());
    bool b = false;
    for (int i = 0; i < 2; i++) {
      showPolls.add(b);
    }
    widget.dateTimeData = DateTime.now();
    _tabController = TabController(vsync: this, length: emojis.length);
    _scrollController = ScrollController();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible && isEmojiVisible) {
        isEmojiVisible = false;
        if (this.mounted) {
          // check whether the state object is in tree
          setState(() {
            // make changes here
          });
        }
      } else {}
    });

    {
      widget.newsfeedController.replayModelList = [];
      widget.newsfeedController.replayModelList.add(ModelClass.fromJson({
        'body': '',
        'poll_ques_first': null,
        'poll_ques_first': null,
        'poll_ques_third': null,
        'poll_ques_fourth': null,
        //  selectType: "Public",
        'files': [],
        'link_meta': '',
        'link': '',
        'link_image': '',
        'link_title': '',
        'days': '',
        'minutes': '',
        'hours': '',
        'location': '',
        'lat': '',
        'lng': '',
        'poll_thread': false,
        'type': 'comment',
        'reply_id': widget.post.postId
      }));
      // print("hello");
      widget.newsfeedController.postText = false;
      //   isEditCheckForImage = -1;
      //  isEdit = false;
      // print("isCheckEdit: $isEditCheckForImage");
    }

    super.initState();
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        // print("hello");

        // print(checkFocus);

        checkFocus.value = true;

        widget.newsfeedController.postText = true;
        widget.newsfeedController.update();

        // print(checkFocus);
      } else {
        checkFocus.value = false;
        // print(checkFocus);
      }
    });

    selectedDateTime = DateTime.now().toString();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _controller[widget.newsfeedController.currentIndexText].addListener(() {
      if (_controller[widget.newsfeedController.currentIndexText]
          .text
          .isNotEmpty) {
        widget.newsfeedController.postText = true;
        widget.newsfeedController.update();
        // print(widget.newsfeedController.currentIndexText);
        // print(
        //     "TEXT EDIT CONTROLLLER on INITSTATE :${_controller[widget.newsfeedController.currentIndexText].text}");
        widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .bodyText =
            _controller[widget.newsfeedController.currentIndexText].text;
      } else {
        widget.newsfeedController.postText = false;
        widget.newsfeedController.update();
      }
    });
    widget.newsfeedController.peopleList = widget.newsfeedController.peopleList;

    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    isPortrait = height > width ? true : false;
    _tabController.addListener(() {
      _selectedTab = _tabController.index;
      if (!isPortrait) {
        _scrollController.jumpTo(_selectedTab * height * .075);
      }
      if (this.mounted) {
        // check whether the state object is in tree
        setState(() {
          // make changes here
        });
      }
      // setState(() {});
    });
  }

  callGetImage() async {
    widget.newsfeedController.postText = true;

    widget.newsfeedController.update();
    imageWidgetKey = 1;
    videoWidgetKey = 0;
    pdfWidgetKey = 0;
    // listFiles = [];

    if (listFiles.length > 4) {
      Fluttertoast.showToast(
          msg: Strings.pleaseChooseEither1VideoOr1Pdf,
          toastLength:
          Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb:
          5,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
          webPosition: "center",
          fontSize: kIsWeb?18:16.0);
      return;
    } else {

      setState(() => _loadingPath = true);
      try {
        _paths = (await FilePicker.platform.pickFiles(
          type: FileType.image,
          // allowedExtensions: ['jpg', 'jpeg', 'png','webp'],
          allowMultiple: _multiPick,
        ))?.files;

        await Future.forEach(_paths, (element) async {
          File compressedImage;
          if (element.extension == "jpg") {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 50);
          } else if (element.extension == "jpeg") {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 100);
          } else {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 50);
          }

          var size = await FileSupport().getFileSize(file: compressedImage);

          String filePath = compressedImage.path;
          String fileName = filePath.split('/').last;

          String splitSize = size.substring(0, 2).replaceAll(".", "").trim();
          int fileSize = int.parse(splitSize);

          PlatformFile convertedFile = await PlatformFile(
            name: fileName,
            path: filePath,
            size: fileSize,
          );
          compressedFiles.add(convertedFile);
        });

        if (_paths == null || _paths.isEmpty) {
          setState(() => _loadingPath = false);
          return;
        }
      } on PlatformException catch (e) {
        if (kDebugMode) {
          // print("Unsupported operation" + e.toString());
          setState(() => _loadingPath = false);
        }
      } catch (error) {
        if (kDebugMode) {
          // print(error);
        }
        setState(() => _loadingPath = false);
      }
      if (!mounted) return;
      setState(() {
        _loadingPath = false;

        listFiles.addAll(compressedFiles);
        compressedFiles.clear();

      });

      var controller = widget.newsfeedController;
      if (listFiles.length > 4) {
        Fluttertoast.showToast(
            msg: Strings.pleaseChooseEither1VideoOr1Pdf,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 5,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
            webPosition: "center",
            fontSize: kIsWeb ? 18 : 16.0);
        return;
      } else {
        // List<_dio.MultipartFile> files = [];
        // files = listFiles.map((path) => _dio.MultipartFile.fromFileSync(
        //           path.path,
        //           filename: path.name,
        //         ))
        //     .toList();
        // if (kDebugMode) {
        //   print(files.length);
        // }
        // Map<String, dynamic> userData = {};


        // print("filesx ${files[0].contentType}");
        // print("files ${files[0].filename}");
        // print("files ${files[0].headers}");
        // if (files.isNotEmpty) {
        //   userData.addAll({'files[]': files});
        // }
        // isMediaUploading = true;
        // await controller.multiImageSeleted(userData, 1);
        // controller.modelList2[controller.currentIndexText].imagePickCount =
        //     controller.modelList2[controller.currentIndexText].imagePickCount +
        //         listFiles.length;

        // Get.back();
        // print("pick image ${imageThumbnailsList}");
        visibility = true;
        // isMediaUploading = false;
        isMediaAttached = false;
        setState(() {});

      }

/*      List<_dio.MultipartFile> files = [];
      files = listFiles
          .map((path) => _dio.MultipartFile.fromFileSync(
                path.path,
                filename: path.name,
              ))
          .toList();

      Map<String, dynamic> userData = {};
      if (files.isNotEmpty) {
        userData.addAll({'files[]': files});
      }

      isMediaUploading = true;
      await widget.newsfeedController.multiImageSeleted(userData, 2,listFiles);
      Get.back();
      // print("pick image ${imageThumbnailsList}");
      visibility = true;
      isMediaUploading = false;
      isMediaAttached = false;
      setState(() {});*/
    }
  }

  callGetVideo() async {
    widget.newsfeedController.postText = true;
    widget.newsfeedController.update();

    videoWidgetKey = 1;
    imageWidgetKey = 0;
    pdfWidgetKey = 0;
    setState(() {});
    // File pickedMedia;
    Map<String,dynamic> map = await dataController.getVideo();
    videoBytes = await map['bytes'];

    // _pickedVideo = pickedMedia.path;
    // print(videoBytes.toString());

    // _pickedImage.add(videoBytes);
    // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
    if (videoBytes != null) {
      _pickedVideos.add(videoBytes);
      _pickedVideosName.add(map['name'] ?? 'fileName');
      _pickedVideosMemeType.add(map['memeType'] ?? 'mp4');

      isMediaUploading = true;

      // videoThumbnail =
      //     await widget.newsfeedController.uploadMedia(_pickedVideos[0], 2,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
      Get.back();
      videoWidgetKey = 1;
      setState(() {
        widget.newsfeedController.postText = true;
      });

      // print("video check $videoThumbnail");

      //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
      // if (videoThumbnail != null) {
        // print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          isMediaAttached = true;
          isMediaUploading = false;
        });
/*      } else {
        // print('IN ELSE BLOCK');
      }*/
    }
  }

  callGetFile() async {
    // print("pdf file");
    pdfWidgetKey = 1;
    videoWidgetKey = 0;
    imageWidgetKey = 0;

    _pdfs = await dataController.getFile();

    widget.newsfeedController.postText = true;
    widget.newsfeedController.update();
    // pickedMedia = await dataController.getImageWeb();

    // print('NAHI ATA IDHAR');
    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (ext!='pdf') {
        UtilsMethods.toastMessageShow(
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          message: Strings.fileTypeIsNotAllowed,
        );
      } else {
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        isMediaUploading = true;
        setState(() {});
        pdfName = await widget.newsfeedController.uploadMedia(_pickedPdfs[0], 2,
            type: 'file', fileName: _pdfFilesName[0],fileType: 'pdf');
        Get.back();
        // controller.modelList2[controller.currentIndexText].mediaData2.add();

        // pdfWidgetKey =0;
        // print(" pdfkey $pdfWidgetKey");
        isMediaAttached = true;
        // print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;
        setState(() {});
      }
    }
  }

  callGetAudio() async {
    pickedAudio = await dataController.getAudio();
    // print(pickedAudio.path);
    if (pickedAudio != null) {
      isMediaUploading = true;
      _pickedAudios.add(pickedAudio);
      setState(() {});
      audioUrl =
          await widget.newsfeedController.uploadMedia(_pickedAudios[0], 2,fileType: 'mp3');
      isMediaAttached = true;
      isMediaUploading = false;
      setState(() {});
    } else {
      // print('NANANANANA');
    }
  }

  buildPollOptions({
    @required int optionNumber,

    //  @required int indexOf
  }) {
    if (optionNumber == 1 || optionNumber == 4) {
      return Padding(
        padding: EdgeInsets.only(top: 6.0, bottom: 6.0, right: 34, left: 10),
        child: TextFormField(
          onChanged: (value) {
            if (optionNumber == 1) {
              //  txtOption1[controller.currentIndexText]=value;
              widget
                  .newsfeedController
                  .replayModelList[widget.newsfeedController.currentIndexText]
                  .poll_ques_first = value;
              //  print('value pool ${txtOption1[controller.currentIndexText]}');
              // print(
              //     'model values in pool 1: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_first}');
            } else {
              //  txtOption4[controller.currentIndexText]=value;
              widget
                  .newsfeedController
                  .replayModelList[widget.newsfeedController.currentIndexText]
                  .poll_ques_fourth = value;
              // print('value pool ${txtOption4[controller.currentIndexText]}');
              // print(
              //     'model values in pool 4: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_fourth}');
            }
          },
          // controller: optionNumber == 1 ? txtOption1 : txtOption4,
          inputFormatters: [
            LengthLimitingTextInputFormatter(25),
          ],
          style: Styles.baseTextTheme.headline4.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontSize: 14,
          ),
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            labelText: '${Strings.choice} $optionNumber',
            labelStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            hintText: optionNumber == 4
                ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                : '${Strings.choice} $optionNumber',
            hintStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: const BorderRadius.all(
                const Radius.circular(0.0),
              ),
              borderSide: BorderSide(
                width: 1,
                style: BorderStyle.none,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.grey,
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(
          top: 8.0,
          bottom: 8.0,
          left: 10,
          right: optionNumber == 2 && !isOptionTwo
              ? 34
              : option == 3 || option == 2 && isOptionTwo
                  ? 10
                  : option == 3 && !isOptionTwo
                      ? 34
                      : 34),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              onChanged: (value) {
                if (optionNumber == 2) {
                  // txtOption2[controller.currentIndexText]=value;
                  widget
                      .newsfeedController
                      .replayModelList[
                          widget.newsfeedController.currentIndexText]
                      .poll_ques_second = value;
                  // print(
                  //     'model values in pool 2: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_second}');
                } else {
                  // txtOption3[controller.currentIndexText]=value;
                  widget
                      .newsfeedController
                      .replayModelList[
                          widget.newsfeedController.currentIndexText]
                      .poll_ques_third = value;
                  // print(
                  //     'model values in pool 3: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_third}');
                }

                setState(() {});
              },
              // controller: optionNumber == 2 ? txtOption2 : txtOption3,
              inputFormatters: [
                LengthLimitingTextInputFormatter(25),
              ],
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: const BorderRadius.all(
                    const Radius.circular(0.0),
                  ),
                  borderSide: BorderSide(
                    width: 1,
                    style: BorderStyle.none,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.grey,
                  ),
                ),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                labelText: '${Strings.choice} $optionNumber',
                labelStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
                hintText: optionNumber == 3
                    ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                    : '${Strings.choice} $optionNumber',
                hintStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
              ),
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 14,
              ),
            ),
          ),
          optionNumber == 2 && option == 2 && isOptionTwo
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : SizedBox(),
          !isOptionTwo && option == 3 && optionNumber == 3
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : SizedBox(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var controller = widget.newsfeedController;
    var post = widget.post;
    final cross = (MediaQuery.of(context).size.width * .025).round();
    // print('CHECK BOOLEAN ' + widget.isPostScheduled.toString());
    // print("checkFocus${checkFocus}");
    String getDate;
    getDate = UtilsMethods.getDate(widget.post.postedOn);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? Colors.black
            : Colors.white,
        automaticallyImplyLeading: false,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
              highlightColor: Colors.transparent,
              splashColor: Colors.transparent,
              hoverColor: Colors.transparent,
              onPressed: () {
                imageThumbnailsList.clear();
                widget.newsfeedController.mediaData.clear();
                widget.newsfeedController.currentIndexText = 0;
                apiCalled = false;
                checkLocation = true;
                // print(checkLocation);
                SingleTone.instance.selectedLocation = null;
                setState(() {});

                Navigator.of(context).pop();
              },
              icon: Icon(
                Icons.close,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
              ),
            ),
            /* When Scheduling a Post*/
            widget.isPostScheduled
                ? ElevatedButton(
                    child: Text(
                      Strings.schedule,
                      style: TextStyle(fontSize: 14, color: Colors.white),
                    ),
                    style: ButtonStyle(
                      padding: MaterialStateProperty.all(
                        EdgeInsets.symmetric(horizontal: 30, vertical: 2),
                      ),
                      backgroundColor: MaterialStateProperty.all(
                          widget.newsfeedController.postText == false &&
                                  isMediaAttached == false
                              ? widget.newsfeedController.displayColor
                                  .withOpacity(0.5)
                              : widget.newsfeedController.postText == true &&
                                      isMediaUploading == true
                                  ? widget.newsfeedController.displayColor
                                      .withOpacity(0.5)
                                  : widget.newsfeedController.displayColor),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                      ),
                    ),
                    onPressed: widget.newsfeedController.postText == false &&
                            isMediaAttached == false
                        ? null
                        : widget.newsfeedController.postText == true &&
                                isMediaUploading == true
                            ? null
                            : () async {
                                if (widget.newsfeedController.replayModelList[0]
                                            .bodyText ==
                                        '' ||
                                    widget.newsfeedController.replayModelList[0]
                                        .bodyText.isEmpty) {
                                  UtilsMethods.toastMessageShow(
                                    widget.newsfeedController.displayColor,
                                    widget.newsfeedController.displayColor,
                                    widget.newsfeedController.displayColor,
                                    message: Strings.pleaseEnterValidText,
                                  );
                                  //  Get.snackbar('message', "please enter some Thing");
                                } else {
                                  // print('PRINT dksakdskodksodsa  ');
                                  // widget.controller.isLoading = true;
                                  apiCalled = true;
                                  setState(() {});
                                  widget.newsfeedController.schedulePost(
                                      context,
                                      bodyText: widget.newsfeedController
                                          .replayModelList[0].bodyText,
                                      fileName: _pdfFilesName.length > 0
                                          ? _pdfFilesName
                                          : null,
                                      // imageWebBytes: _pickedImage.isNotEmpty ? _pickedImage
                                      //     : _pickedVideos.isNotEmpty ? _pickedVideos
                                      //     : _pickedAudios != null
                                      //     ? _pickedAudios
                                      //     : _pickedPdfs,
                                      payload: widget
                                          .newsfeedController.replayModelList,
                                      link: link != null ? link : '',
                                      linkImage:
                                          linkImage != null ? linkImage : '',
                                      linkMeta:
                                          linkMeta != null ? linkMeta : '',
                                      linkTitle:
                                          linkTitle != null ? linkTitle : '',
                                      postingTime: selectedDateTime.toString(),
                                  isComment: true);
                                  Navigator.of(context).pop();
                                }

                                // Navigator.pop(context);
                              },
                  )
                : ElevatedButton(
                    child: threadCreated == false ||
                            widget.newsfeedController.replayModelList.length ==
                                1
                        ? Text(
                            Strings.reply,
                            style: TextStyle(fontSize: 14, color: Colors.white),
                          )
                        : Text(Strings.allReply),
                    style: ButtonStyle(
                      padding: MaterialStateProperty.all(
                        EdgeInsets.symmetric(horizontal: 30, vertical: 2),
                      ),
                      backgroundColor: MaterialStateProperty.all(widget
                                      .newsfeedController.postText ==
                                  false &&
                              isMediaAttached == false
                          ? widget.newsfeedController.displayColor
                              .withOpacity(0.5)
                          : widget.newsfeedController.postText == true &&
                                  isMediaUploading == true
                              ? widget.newsfeedController.displayColor
                                  .withOpacity(0.5)
                              : showPolls[widget.newsfeedController.currentIndexText] &&
                                      widget.newsfeedController.postText ==
                                          true &&
                                      txtOption1.isEmpty &&
                                      txtOption2.isEmpty &&
                                      widget
                                          .newsfeedController
                                          .replayModelList[widget
                                              .newsfeedController
                                              .currentIndexText]
                                          .bodyText
                                          .isEmpty &&
                                      widget
                                              .newsfeedController
                                              .replayModelList[widget.newsfeedController.currentIndexText]
                                              .poll_ques_first ==
                                          "" &&
                                      widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_second == ""
                                  ? widget.newsfeedController.displayColor.withOpacity(0.5)
                                  : widget.newsfeedController.displayColor),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                        RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                      ),
                    ),
                    onPressed: widget.newsfeedController.postText == false &&
                            isMediaAttached == false
                        ? null
                        : widget.newsfeedController.postText == true &&
                                isMediaUploading == true
                            ? null
                            : showPolls[widget
                                        .newsfeedController.currentIndexText] &&
                                    widget.newsfeedController.postText ==
                                        true &&
                                    widget
                                            .newsfeedController
                                            .replayModelList[widget
                                                .newsfeedController
                                                .currentIndexText]
                                            .bodyText ==
                                        null &&
                                    txtOption1.isEmpty &&
                                    txtOption2.isEmpty
                                ? () {}
                                : () async {
                                    if ((_pickedVideos.length + listFiles.length) > 4) {
                                      Fluttertoast.showToast(
                                          msg: Strings.pleaseChooseEither1VideoOr1Pdf,
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 5,
                                          backgroundColor: Colors.red,
                                          textColor: Colors.white,
                                          webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
                                          webPosition: "center",
                                          fontSize: kIsWeb ? 18 : 16.0);
                                      return;
                                    }
                                    apiCalled = true;
                                    setState(() {});

                                    if (_pickedVideos.isNotEmpty){
                                      videoThumbnail =
                                      await controller.uploadMedia(_pickedVideos[0], 2,fileName:_pickedVideosName[0],fileType: 'mp4',memeType: _pickedVideosMemeType[0]);
                                    }

                                    if (listFiles.isNotEmpty){
                                      await uploadImages();
                                    }

                                    List<ModelClass> showPoolList = [];

                                    /// show poll

                                    if (showPolls[0] == true &&
                                        threadCreated == false) {
                                      showPoolList.insert(
                                          0,
                                          ModelClass.fromJson({
                                            'body': widget.newsfeedController
                                                .replayModelList[0].bodyText,
                                            'poll_ques_first': widget
                                                .newsfeedController
                                                .replayModelList[0]
                                                .poll_ques_first,
                                            'poll_ques_second': widget
                                                .newsfeedController
                                                .replayModelList[0]
                                                .poll_ques_second,
                                            'poll_ques_third': widget
                                                        .newsfeedController
                                                        .replayModelList[0]
                                                        .poll_ques_third ==
                                                    null
                                                ? null
                                                : widget
                                                    .newsfeedController
                                                    .replayModelList[0]
                                                    .poll_ques_third,
                                            'poll_ques_fourth': widget
                                                        .newsfeedController
                                                        .replayModelList[0]
                                                        .poll_ques_fourth ==
                                                    null
                                                ? null
                                                : widget
                                                    .newsfeedController
                                                    .replayModelList[0]
                                                    .poll_ques_fourth,
                                            'files': [],
                                            'link_meta': '',
                                            'link': '',
                                            'link_image': '',
                                            'link_title': '',
                                            'days': '',
                                            'minutes': '',
                                            'hours': '',
                                            'location': '',
                                            'lat': '',
                                            'lng': '',
                                            'type': 'poll',
                                          }));
                                    }

                                    if (isEdit == false) {
                                      widget.newsfeedController.replayModelList
                                          .forEach((element) {
                                        // print(
                                        //     "before element.bodyText ${element.bodyText}");
                                        element.bodyText = element.bodyText
                                            .replaceAll("\n", " " + "\n");

                                        // print(
                                        //     "after element.bodyText ${element.bodyText}");
                                      });
                                    }

                                    var responseCode;

                                    {
                                      responseCode = await widget.newsfeedController.createPost(
                                        payload: showPolls[0] == true && threadCreated == false
                                            ? showPoolList
                                            : widget.newsfeedController.replayModelList,
                                        postId: -1,
                                        replyId: widget.replyPageId,
                                        getClickId: widget.getClickId,
                                        incrementPostId: widget.post.postId,
                                      );
                                    }
                                    // print(widget
                                    //     .newsfeedController.replayModelList);
                                    // print(
                                    //     'controller.modelList2.length ${widget.newsfeedController.replayModelList.length}');
                                    //SHOW TOAST HERE YOUR REPLY WILL BE AVAILABLE IN A MOMENT
                                 /*   Fluttertoast.showToast(
                                        msg:'Your reply is being reviewed.We will post it soon.',
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.CENTER,
                                        timeInSecForIosWeb: 5,
                                        backgroundColor: Colors.blue,
                                        textColor: Colors.white,
                                        webBgColor: "linear-gradient(to right, #2196F3FF, #2196F3FF)",
                                        webPosition: "center",
                                        fontSize: kIsWeb ? 18 : 16.0);*/

                                    apiCalled = false;
                                    listFiles.clear();
                                    _pickedVideos = [];
                                    _pickedVideosName = [];
                                    _pickedVideosMemeType = [];

                                    _pickedAudios = [];
                                    _pickedImage = [];
                                    widget.newsfeedController.mediaData = [];
                                    _pickedPdfs = [];
                                    widget.newsfeedController.currentIndexText = 0;

                                    setState(() {});
                                    Navigator.pop(context);
                                    widget.newsfeedController.isNewsfeedLoading = false;
                                    widget.newsfeedController.update();
                                    // print(
                                    //     'RESPONSEE' + responseCode.toString());
                                    // if (responseCode == 200) {
                                    // print('H E R E');
                                    widget.newsfeedController.postText = false;
                                  },
                  )
          ],
        ),
      ),
      body: Container(
        child: SafeArea(
          child: apiCalled
              ? Center(
                  child: CircularProgressIndicator(
                  color: MyColors.BlueColor,
                ))
              : CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child: Column(
                        children: [
                          SizedBox(
                            height: 20,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: CircleAvatar(
                                    backgroundImage: widget.post.profileImage !=
                                            null
                                        ? NetworkImage(widget.post.profileImage)
                                        : AssetImage(
                                            "assets/images/person_placeholder.png"),
                                    radius: 22,
                                  ),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      child: Text(
                                        "${widget.post.authorName}",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                                    widget.post.userInfo.accountVerified ==
                                            "verified"
                                        ? Padding(
                                            padding: const EdgeInsets.only(
                                                left: 2.0),
                                            child: BlueTick(
                                              height: 15,
                                              width: 15,
                                              iconSize: 10,
                                            ),
                                          )
                                        : SizedBox(),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      '@${widget.post.username}',
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(fontSize: 15),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          bottom: 10, left: 2, right: 2),
                                      child: Text(
                                        ".",
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '${getDate == null ? '' : getDate}',
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(fontSize: 15),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              children: [
                                IntrinsicHeight(
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 10),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: SizedBox(
                                        height: 50,
                                        child: VerticalDivider(
                                          color: Colors.grey,
                                          thickness: 2,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 30),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      /*widget.post != null
                                          ? SizedBox(
                                              width: Get.width * 0.8,
                                              child:
                                                  Text('${widget.post.body}'))
                                          : const Text(''),*/

                                      kIsWeb ? SizedBox()
                                          :
                                      // post.body.length > 0
                                      // ?
                                      SizedBox(
                                        width: Get.width * 0.8,
                                        child: GetBuilder<NewsfeedController>(
                                            id: 'translate',
                                            builder: (logic) {
                                              return PostTextDescription(
                                                post: post,
                                                controller: controller,
                                                translationCheck: post
                                                    .translation.value,
                                                translationData: post
                                                    .translationData,
                                                width: Get.width,
                                                commentId: null,

                                              );
                                            }),
                                      ),
                                      // )
                                      //     : SizedBox(),
                                      !kIsWeb ? post.body.length > 0 ?
                                      translateLoading == true ?
                                      SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                        ),
                                      ) :
                                      controller.languageData != null ?
                                      controller.languageData.myLang
                                          .id != post.languageId ?
                                      Obx(() {
                                        return GestureDetector(
                                          onTap: () async {
                                            // post.translationLoader = true;
                                            // controller.updateControllers(1);
                                            //
                                            // await Future.delayed(Duration(seconds: 2));

                                            setState(() {
                                              translateLoading = true;
                                            });

                                            bool success = false;

                                            post.translationData =
                                            await controller.newsFeedTranslation(
                                                post.postId,
                                                controller.languageData
                                                    .myLang.code);

                                            if (post.translationData != null) {
                                              setState(() {
                                                translateLoading = false;
                                              });
                                              // post.translationLoader = false;
                                              // controller.updateControllers(1);

                                              if (post.translation
                                                  .value == false) {
                                                print(
                                                    "controller.translationData.data[0].body ${controller
                                                        .translationData
                                                        .data[0].body}");
                                                post.translation.value =
                                                true;
                                                controller.update(['translate']);
                                              }
                                              else if (post.translation.value == true) {
                                                post.translation.value =
                                                false;
                                                controller.update(['translate']);
                                              }
                                            }
                                            else {
                                              // post.translationLoader = false;
                                              // controller.updateControllers(1);
                                              setState(() {
                                                translateLoading = false;
                                              });
                                              controller.update();
                                            }
                                          },

                                          child:

                                          post.translation.value == true ?
                                          Padding(
                                            padding: EdgeInsets.only(bottom: 10),
                                            child: Text(
                                                "View Original",

                                                style: TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                    color: controller
                                                        .displayColor

                                                )
                                            ),
                                          ) : Padding(
                                            padding: EdgeInsets.only(bottom: 10, top: 5),
                                            child:/*containHashTag? SizedBox() :*/  Text(
                                                /*controller.languageData.appLang.id == 2
                                                    ? "عرض الترجمة"
                                                    : */Strings.viewTranslated,
                                                style: TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                    color: controller
                                                        .displayColor

                                                )
                                            ),
                                          ),
                                        );
                                      }) : SizedBox() : SizedBox()
                                          : SizedBox() : SizedBox(),
                                      const SizedBox(height: 5,),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: RichText(
                                          text: TextSpan(
                                            text: Strings.replyToComment,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey),
                                            children: <TextSpan>[
                                              TextSpan(
                                                  text:
                                                      ' @${widget.post.username}',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.blue)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (_, int ind) {
                          return Container(
                            margin: EdgeInsets.all(5),
                            child: GestureDetector(
                              onTap: () {
                                widget.newsfeedController.currentIndexText =
                                    ind;
                              },
                              child: Column(
                                children: [
                                  ///  scdeudle  widget
                                  widget.isPostScheduled
                                      ? ListTile(
                                          minVerticalPadding: 0.0,
                                          horizontalTitleGap: 0.0,
                                          leading: Container(
                                            width: 20,
                                            height: 20,
                                            child: SvgPicture.asset(
                                              // _pickedPdfs.length > 0 ||
                                              //     _pickedAudios.length > 0 ||
                                              //     _pickedVideos.length > 0
                                              //     ?
                                              'assets/post_icons/calendar.svg',
                                              fit: BoxFit.cover,
                                              height: 200,
                                              width: 200,
                                              color: _pickedVideos.isNotEmpty ||
                                                      isMediaAttached ||
                                                      showPolls[widget
                                                          .newsfeedController
                                                          .currentIndexText]
                                                  ? Colors.grey[400]
                                                  : widget.newsfeedController
                                                      .displayColor,
                                              // : Colors.purple,
                                            ),
                                          ),
                                          title: Text(
                                            '${Strings.thisPostIsScheduledFor} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',

                                            // 'This post is scheduled for ${DateFormat("y-MMM-d hh:mm a")..parse(selectedDateTime)}',
                                          ),
                                          subtitle: GestureDetector(
                                            onTap: () {
                                              widget.isPostScheduled = false;
                                              setState(() {});
                                            },
                                            child: Text(
                                             Strings.clear,
                                              style: TextStyle(
                                                decoration:
                                                    TextDecoration.underline,
                                              ),

                                              // style: Theme.of(context).brightness == Brightness.dark ?
                                              // TextStyle(color: Colors.white, decoration: TextDecoration.underline)
                                              //     : TextStyle(color: Colors.black, decoration: TextDecoration.underline),
                                            ),
                                          ),
                                        )
                                      : SizedBox(),

                                  ///

                                  ListTile(
                                    contentPadding: EdgeInsets.only(left: 6),
                                    leading: widget.newsfeedController
                                                .userProfile ==
                                            null
                                        ? Container(
                                            width: 24,
                                            child: Center(
                                              child: SpinKitCircle(
                                                color: Colors.grey,
                                                size: 40,
                                              ),
                                            ))
                                        : widget.newsfeedController.userProfile
                                                    .profileImage ==
                                                null
                                            ? CircleAvatar(
                                                radius: 22,
                                                backgroundImage: AssetImage(
                                                    "assets/images/person_placeholder.png"))
                                            : ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(30),
                                                child: FadeInImage(
                                                    fit: BoxFit.cover,
                                                    width: 40,
                                                    height: 40,
                                                    placeholder: AssetImage(
                                                        'assets/images/person_placeholder.png'),
                                                    image: NetworkImage(widget
                                                                .newsfeedController
                                                                .userProfile
                                                                .profileImage !=
                                                            null
                                                        ? widget
                                                            .newsfeedController
                                                            .userProfile
                                                            .profileImage
                                                        : "assets/images/person_placeholder.png")),
                                              ),
                                    title: GestureDetector(
                                      onTap: () {
                                        widget.newsfeedController
                                            .currentIndexText = ind;
                                        isMediaAttached = false;
                                      },
                                      child: HashTagTextField(
                                        textInputAction:
                                            TextInputAction.newline,

                                        decorateAtSign: true,
                                        focusNode: focusNode,

                                        onTap: () {
                                          widget.newsfeedController
                                              .currentIndexText = ind;
                                          //   nodeFirst[controller.currentIndexText].hasFocus;
                                          // print(
                                          //     'on coursel changes the index:${widget.newsfeedController.currentIndexText}');
                                          if (isEmojiVisible) {
                                            // widget.controller.focusNode.requestFocus();
                                            isEmojiVisible = !isEmojiVisible;
                                          }
                                        },
                                        basicStyle: LightStyles
                                            .baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          // fontWeight: FontWeight.bold,
                                        ),
                                        cursorColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        maxLength: 800,
                                        buildCounter: (context,
                                                {currentLength,
                                                isFocused,
                                                maxLength}) =>
                                            null,
                                        maxLines:

                                            /// changing in mention tag
                                            showPolls[widget.newsfeedController
                                                    .currentIndexText]
                                                ? 3
                                                : widget.mentionUser ||
                                                        widget.mentionTag
                                                    ? 2
                                                    : null,
                                        keyboardType: TextInputType.multiline,
                                        maxLengthEnforcement:
                                            MaxLengthEnforcement.enforced,
                                        // focusNode: focusNodeText,
                                        // focusNode: nodeFirst[controller.currentIndexText],

                                        controller: _controller[
                                            ind] /*isEdit == true?postTextController:controller.modelList2[0].textEditingController*/,
                                        // decoratedStyle:
                                        // TextStyle(fontSize: 16, color: Colors.blue),
                                        decoratedStyle: LightStyles
                                            .baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.blue
                                              : Colors.blue,
                                          // fontWeight: FontWeight.bold,
                                        ),
                                        decoration: InputDecoration(
                                          contentPadding:
                                              EdgeInsets.only(top: 16),
                                          hintText: showPolls[widget
                                                  .newsfeedController
                                                  .currentIndexText]
                                              ? Strings.askAQuestion
                                              : Strings.werfYourReply,
                                          hintStyle: LightStyles
                                              .baseTextTheme.headline3,
                                          border: InputBorder.none,
                                        ),
                                        onChanged: (value) {
                                          if (value == "\n") {
                                            // print("endl");
                                          }

                                          if (value.contains("#") &&
                                              value.contains("@")) {
                                            setState(() {
                                              widget.mentionUser = false;
                                              widget.mentionTag = false;
                                            });
                                          }
                                          // print('change value $value');
                                          widget.newsfeedController
                                              .currentIndexText = ind;
                                          setState(() {
                                            postBodyLength = value.length;
                                          });

                                          // print(_controller[ind].text);

                                          widget
                                              .newsfeedController
                                              .replayModelList[ind]
                                              .bodyText = _controller[ind].text;

                                          // print('textttttttttt');
                                          // print("list of indexprint:$ind");
                                          // print(
                                          //     'current index value:${widget.newsfeedController.currentIndexText}');
                                          // print(
                                          //     'vlaue of controller:${widget.newsfeedController.replayModelList[ind].bodyText}');
                                          if (value.length > 0 &&
                                              _controller[ind]
                                                  .text
                                                  .trim()
                                                  .isNotEmpty)
                                            setState(() {
                                              widget.newsfeedController
                                                  .postText = true;
                                              if (widget.isPostScheduled) {
                                                visibility = false;
                                              } else {
                                                visibility = true;
                                              }
                                              closeIcon = false;
                                            });
                                          else
                                            setState(() {
                                              widget.newsfeedController
                                                  .postText = false;
                                              visibility = false;
                                              closeIcon = true;
                                            });
                                          if (value.length < 2) {
                                            /// user tag and mention tag
                                            widget.mentionUser = false;
                                            widget.mentionTag = false;
                                            temp = '';
                                            tempUsername = '';
                                            widget.tags.clear();

                                            /// end
                                            visibility = true;
                                            setState(() {});
                                          }
                                        },

                                        /// Called when detection (word starts with #, or # and @) is being typed
                                        onDetectionTyped: (text) async {

                                          if (!text.contains("#") ||
                                              !text.contains("@")) {
                                            setState(() {
                                              widget.mentionUser = false;
                                              widget.mentionTag = false;
                                            });
                                          }

                                          if (text.contains("#")) {
                                            tempValue = text;

                                            //print('start with #');
                                            widget.mentionUser = false;
                                            widget.tags = await widget
                                                .newsfeedController
                                                .searchTags(
                                                    tempValue.substring(1));
                                            if (widget.tags.length <= 0) {
                                              widget.tags.clear();
                                              widget.mentionTag = false;
                                              //  temp='';
                                              setState(() {});
                                            } else {
                                              widget.mentionUser = false;
                                              widget.mentionTag = true;

                                              setState(() {});
                                            }
                                          } else if (text.contains("@")) {
                                            tempValue = text;


                                            widget.mentionTag = false;
                                            widget.users = await widget
                                                .newsfeedController
                                                .searchChatUser(
                                              tempValue.substring(1),
                                              type: "mention_users",
                                            );
                                            if (widget.users.length <= 0) {
                                              widget.users.clear();
                                              widget.mentionUser = false;
                                              setState(() {});
                                            } else {
                                              widget.mentionUser = true;
                                              setState(() {});
                                            }
                                          }
                                        },

                                        /// Called when detection is fully typed
                                        onDetectionFinished: () {
                                          // tempValue="";

                                          setState(() {
                                            widget.mentionUser = false;
                                            widget.mentionTag = false;
                                          });

/*
                                                            setState(() {
                                                              widget.mentionTag=false;
                                                              widget.mentionUser=false;

                                                            });*/
                                        },
                                      ),
                                    ),
                                  ),

                                  /// mention tag  widget
                                  !widget.mentionTag
                                      ? SizedBox()
                                      : Align(
                                          alignment: Alignment.centerLeft,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.grey[300],
                                                width: 0.5,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                            ),
                                            height: 150,
                                            width: 300,
                                            child: widget.tags.length == 0
                                                ? SpinKitWave(
                                                    size: 30,
                                                    color: Color(0xFFedab30),
                                                  )
                                                : ListView.builder(
                                                    itemCount:
                                                        widget.tags.length,
                                                    itemBuilder:
                                                        (context, index) {
                                                      return ListTile(
                                                        onTap: () async {
                                                          //   temp='';
                                                          /*     _controller[controller.currentIndexText].text =
                                                        _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                       ' ' +
                                                            widget.tags[index]['title'];*/
                                                          _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text = _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text
                                                              .substring(
                                                                  0,
                                                                  _controller[widget
                                                                              .newsfeedController
                                                                              .currentIndexText]
                                                                          .text
                                                                          .length -
                                                                      tempValue
                                                                          .length);

                                                          tempValue =
                                                              widget.tags[index]
                                                                  ['title'];


                                                          _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text = _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .text +
                                                              " " +
                                                              tempValue +
                                                              " ";
                                                          // tempValue="";
                                                          _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .selection =
                                                              TextSelection.fromPosition(TextPosition(
                                                                  offset: _controller[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .text
                                                                      .length));
                                                          widget.tags.clear();
                                                          widget.mentionTag =
                                                              false;
                                                          //  widget.tags = [];
                                                          tempValue = "";
                                                          focusNodeText
                                                              .requestFocus();

                                                          setState(() {});
                                                          _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .selection =
                                                              TextSelection.fromPosition(TextPosition(
                                                                  offset: _controller[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .text
                                                                      .length));

                                                          // widget.focusNode
                                                          //     .requestFocus();

                                                        },
                                                        title: Text(
                                                          widget.tags.isNotEmpty
                                                              ? widget.tags[
                                                                      index]
                                                                  ['title']
                                                              : "",
                                                        ),
                                                      );
                                                    }),
                                          ),
                                        ),

                                  /// mention user  widget
                                  !widget.mentionUser
                                      ? SizedBox()
                                      : Align(
                                          alignment: Alignment.centerLeft,
                                          child: Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(
                                                color: Colors.grey[300],
                                                width: 0.5,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                            ),
                                            height: 150,
                                            width: 300,
                                            child: widget.users.length == 0
                                                ? SpinKitWave(
                                                    size: 30,
                                                    color: Color(0xFFedab30),
                                                  )
                                                : ListView.builder(
                                                    itemCount:
                                                        widget.users.length,
                                                    itemBuilder:
                                                        (context, index) {
                                                      return ListTile(
                                                        onTap: () async {
                                                          /*     _controller[controller.currentIndexText].text =
                                                        _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                       ' ' +
                                                            widget.tags[index]['title'];*/
                                                          _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text = _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text
                                                              .substring(
                                                                  0,
                                                                  _controller[widget
                                                                              .newsfeedController
                                                                              .currentIndexText]
                                                                          .text
                                                                          .length -
                                                                      tempValue
                                                                          .length);

                                                          tempValue = widget
                                                                  .users[index]
                                                              ['username'];


                                                          _controller[widget
                                                                  .newsfeedController
                                                                  .currentIndexText]
                                                              .text = _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .text +
                                                              " " +
                                                              tempValue +
                                                              " ";
                                                          // tempValue="";
                                                          _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .selection =
                                                              TextSelection.fromPosition(TextPosition(
                                                                  offset: _controller[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .text
                                                                      .length));
                                                          widget.users.clear();
                                                          widget.mentionUser =
                                                              false;
                                                          //  widget.tags = [];

                                                          tempValue = "";
                                                          focusNodeText
                                                              .requestFocus();
                                                          setState(() {});
                                                          // widget.focusNode
                                                          //     .requestFocus();

                                                          _controller[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .selection =
                                                              TextSelection.fromPosition(TextPosition(
                                                                  offset: _controller[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .text
                                                                      .length));
                                                        },
                                                        title: Text(
                                                            widget.users[index]
                                                                ['username']),
                                                      );
                                                    }),
                                          ),
                                        ),

                                  /// end mention user
                                  widget.newsfeedController.postText
                                      ? widget.newsfeedController.urlOrNot(
                                              _controller[widget.newsfeedController.currentIndexText].text)
                                          ?

                                  _controller[widget.newsfeedController.currentIndexText].text[1]!="@"?
                                  Container(
                                              child: urlFetch(),
                                            )
                                          : Container()
                                      : Container():Container(),

                                  ///show pools
                                  showPolls[ind]
                                      ? Align(
                                          alignment: Alignment.center,
                                          child: Container(
                                            width: 600,
                                            margin: EdgeInsets.only(
                                                bottom: 16, top: 16),
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                                border: Border.all(
                                                    color: Colors.grey,
                                                    width: 1)),
                                            child: Column(
                                              children: [
                                                SizedBox(height: 10),
                                                buildPollOptions(
                                                  optionNumber: 1,
                                                  //   indexOf: ind,
                                                ),
                                                buildPollOptions(
                                                  optionNumber: 2,
                                                  // indexOf: ind,
                                                ),
                                                option == 3 || option == 4
                                                    ? buildPollOptions(
                                                        optionNumber: 3,
                                                        //   indexOf: ind,
                                                      )
                                                    : SizedBox(),
                                                option == 4
                                                    ? buildPollOptions(
                                                        optionNumber: 4,
                                                        // indexOf: ind,
                                                      )
                                                    : SizedBox(),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Container(
                                                  height: 1,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.grey,
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      vertical: 6.0,
                                                      horizontal: 10),
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Text(
                                                      Strings.pollLength,
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline4
                                                          .copyWith(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontSize: 14,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Padding(
                                                  padding: EdgeInsets.symmetric(
                                                      vertical: 6.0,
                                                      horizontal: 10),
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                    children: [
                                                      /// pools days selected button
                                                      ButtonTheme(
                                                        materialTapTargetSize:
                                                            MaterialTapTargetSize
                                                                .padded,
                                                        child: Expanded(
                                                          child:
                                                              DropdownButtonFormField<
                                                                  String>(
                                                            icon: Icon(Icons
                                                                .keyboard_arrow_down),
                                                            isExpanded: true,
                                                            decoration:
                                                                InputDecoration(
                                                              border:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              disabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              enabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: widget
                                                                      .newsfeedController
                                                                      .displayColor,
                                                                ),
                                                              ),
                                                              labelText: Strings.day,
                                                              labelStyle: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : widget
                                                                        .newsfeedController
                                                                        .displayColor,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            value: 0.toString(),
                                                            hint: Text(
                                                             Strings.day,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            items: days.map(
                                                                (int value) {
                                                              return DropdownMenuItem<
                                                                  String>(
                                                                value: value
                                                                    .toString(),
                                                                child: Text(
                                                                  value
                                                                      .toString(),
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                              );
                                                            }).toList(),
                                                            onChanged: (days) {
                                                              pollDays = days;
                                                              widget
                                                                  .newsfeedController
                                                                  .replayModelList[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .days = days;
                                                              setState(() {});
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        width: 10,
                                                      ),

                                                      /// pools hour selected button
                                                      ButtonTheme(
                                                        materialTapTargetSize:
                                                            MaterialTapTargetSize
                                                                .padded,
                                                        child: Expanded(
                                                          child:
                                                              DropdownButtonFormField<
                                                                  String>(
                                                            icon: Icon(Icons
                                                                .keyboard_arrow_down),
                                                            isExpanded: true,
                                                            decoration:
                                                                InputDecoration(
                                                              border:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              disabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              enabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: widget
                                                                      .newsfeedController
                                                                      .displayColor,
                                                                ),
                                                              ),
                                                              labelText:
                                                                  Strings.hours,
                                                              labelStyle: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : widget
                                                                        .newsfeedController
                                                                        .displayColor,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            value: 0.toString(),
                                                            hint: Text(
                                                             Strings.hours,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            items: List.generate(
                                                                24,
                                                                (index) =>
                                                                    index).map(
                                                                (int value) {
                                                              return DropdownMenuItem<
                                                                  String>(
                                                                value: value
                                                                    .toString(),
                                                                child: Text(
                                                                  value
                                                                      .toString(),
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                              );
                                                            }).toList(),
                                                            onChanged: (hours) {
                                                              pollHours = hours;
                                                              widget
                                                                  .newsfeedController
                                                                  .replayModelList[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .hours = hours;
                                                              setState(() {});
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        width: 10,
                                                      ),

                                                      /// pools mint selected button
                                                      ButtonTheme(
                                                        materialTapTargetSize:
                                                            MaterialTapTargetSize
                                                                .padded,
                                                        child: Expanded(
                                                          child:
                                                              DropdownButtonFormField<
                                                                  String>(
                                                            icon: Icon(Icons
                                                                .keyboard_arrow_down),
                                                            isExpanded: true,
                                                            decoration:
                                                                InputDecoration(
                                                              border:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              disabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .grey,
                                                                ),
                                                              ),
                                                              enabledBorder:
                                                                  OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            10),
                                                                borderSide:
                                                                    BorderSide(
                                                                  color: widget
                                                                      .newsfeedController
                                                                      .displayColor,
                                                                ),
                                                              ),
                                                              labelText:
                                                                  Strings.minutes,
                                                              labelStyle: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : widget
                                                                        .newsfeedController
                                                                        .displayColor,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            value: pollHours ==
                                                                        '0' &&
                                                                    pollDays ==
                                                                        '0'
                                                                ? 5.toString()
                                                                : 0.toString(),
                                                            hint: Text(
                                                              Strings.minutes,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: 14,
                                                              ),
                                                            ),
                                                            alignment: Alignment
                                                                .bottomCenter,
                                                            items: pollHours ==
                                                                        '0' &&
                                                                    pollDays ==
                                                                        '0'
                                                                ? minutes.map(
                                                                    (int
                                                                        value) {
                                                                    return DropdownMenuItem<
                                                                        String>(
                                                                      value: value
                                                                          .toString(),
                                                                      child:
                                                                          Text(
                                                                        value
                                                                            .toString(),
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                          fontSize:
                                                                              14,
                                                                        ),
                                                                      ),
                                                                    );
                                                                  }).toList()

                                                                /// pool mint list generate
                                                                : List.generate(
                                                                    60,
                                                                    (index) =>
                                                                        index).map(
                                                                    (int
                                                                        value) {
                                                                    return DropdownMenuItem<
                                                                        String>(
                                                                      value: value
                                                                          .toString(),
                                                                      child: Text(
                                                                          value
                                                                              .toString()),
                                                                    );
                                                                  }).toList(),
                                                            onChanged:
                                                                (minutes) {
                                                              pollMinutes =
                                                                  minutes;
                                                              widget
                                                                  .newsfeedController
                                                                  .replayModelList[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .minutes = minutes;
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 6,
                                                ),
                                                Container(
                                                  height: 1,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.grey,
                                                ),

                                                /// remove pool button
                                                InkWell(
                                                  hoverColor: Colors.red[100],
                                                  onTap: () {
                                                    showPolls[widget
                                                            .newsfeedController
                                                            .currentIndexText] =
                                                        false;
                                                    option = 2;
                                                    isOptionTwo = true;
                                                    widget
                                                        .newsfeedController
                                                        .replayModelList[widget
                                                            .newsfeedController
                                                            .currentIndexText]
                                                        .poolThread = false;

                                                    setState(() {});
                                                  },
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    margin:
                                                        EdgeInsets.symmetric(
                                                            vertical: 6),
                                                    width: 600,
                                                    height: 40,
                                                    child: Text(
                                                     Strings.removePoll,
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .headline3
                                                          .copyWith(
                                                            fontSize: 18,
                                                            color: Colors
                                                                .redAccent,
                                                          ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        )
                                      : SizedBox(),

                                  /// reply images
                                  listFiles.length > 0
                                  /*widget.newsfeedController.replayModelList[ind]
                                                  .mediaData2.length >
                                              0 &&
                                          // && controller.modelList2[ind].mediaData2[0].name=="media"
                                          !widget
                                              .newsfeedController
                                              .replayModelList[ind]
                                              .mediaData2[0]
                                              .name
                                              .contains('.pdf') &&
                                          (widget.newsfeedController.replayModelList[ind].mediaData2[0].thumbnailUrl == null ||
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[ind]
                                                  .mediaData2[0]
                                                  .thumbnailUrl
                                                  .isEmpty)*/
                                      /*  imageWidgetKey ==1*/ ? Container(
                                          height: listFiles.length <
                                                  2
                                              ? 500
                                              : 200,
                                          // width: 180,
                                          child: ListView.separated(
                                              separatorBuilder: (_, __) {
                                                return SizedBox(width: 4);
                                              },
                                              scrollDirection: Axis.horizontal,
                                              itemCount: listFiles.length,
                                              itemBuilder: (context, index) {
                                                return
                                                 /* !widget
                                                        .newsfeedController
                                                        .replayModelList[ind]
                                                        .mediaData2
                                                        .asMap()
                                                        .containsKey(index)
                                                    ? Container(
                                                        height: 100,
                                                        alignment:
                                                            Alignment.center,
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          children: [
                                                            CircularProgressIndicator(
                                                              color: MyColors
                                                                  .BlueColor,
                                                            ),
                                                            SizedBox(height: 6),
                                                            Text(
                                                              'Uploading...',
                                                              style: TextStyle(
                                                                  color: MyColors
                                                                      .BlueColor,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700),
                                                            ),
                                                          ],
                                                        ),
                                                      )
                                                    : */
                                                Container(
                                                        height: listFiles
                                                                    .length <
                                                                2
                                                            ? 450
                                                            : 200,
                                                        width: listFiles
                                                                    .length <
                                                                2
                                                            ? MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width *
                                                                0.9
                                                            : 160,
                                                        child: Stack(
                                                          children: [
                                                            Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            15),
                                                              ),
                                                              height: _pickedImage
                                                                          .length <
                                                                      2
                                                                  ? 450
                                                                  : 200,
                                                              width: listFiles
                                                                          .length <
                                                                      2
                                                                  ? MediaQuery.of(
                                                                              context)
                                                                          .size
                                                                          .width *
                                                                      0.9
                                                                  : 160,
                                                              child: ClipRRect(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            15),
                                                                child: Image.file(File(listFiles[index].path), fit: BoxFit.cover,),
                                                                /*Image.network(
                                                                  widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          ind]
                                                                      .mediaData2[
                                                                          index]
                                                                      .url,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),*/
                                                              ),
                                                            ),
                                                            Positioned(
                                                              right: 6,
                                                              top: 10,
                                                              child:
                                                                  CircleAvatar(
                                                                radius: 14,
                                                                backgroundColor:
                                                                    Color(
                                                                        0xFF4b4f53),
                                                                child:
                                                                    IconButton(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  icon: Icon(
                                                                    Icons
                                                                        .close_rounded,
                                                                    size: 16,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                  onPressed:
                                                                      () {
                                                                    /*if (widget
                                                                            .newsfeedController
                                                                            .replayModelList[
                                                                                ind]
                                                                            .bodyText
                                                                            .isEmpty &&
                                                                        widget
                                                                            .post
                                                                            .quoteInfo
                                                                            .postFiles
                                                                            .isEmpty &&
                                                                        widget
                                                                            .newsfeedController
                                                                            .replayModelList[ind]
                                                                            .mediaData2
                                                                            .isEmpty)*/
                                                                        if (controller.replayModelList[ind]
                                                                            .bodyText
                                                                            .isEmpty)
                                                                        {
                                                                      widget.newsfeedController
                                                                              .postText =
                                                                          false;
                                                                      widget
                                                                          .newsfeedController
                                                                          .update();
                                                                    }


                                                                    widget
                                                                        .newsfeedController
                                                                        .mediaData
                                                                        .clear();
                                                                    //  widget.controller.update();
                                                                    if (listFiles.length ==
                                                                        1) {

                                                                      isMediaAttached =
                                                                          false;
                                                                      //  isEdit=false;

                                                                      setState(
                                                                          () {});
                                                                    }

                                                                    if (widget.newsfeedController.replayModelList[ind].imageCounter !=
                                                                            null &&
                                                                        widget.newsfeedController.replayModelList[ind].imageCounter >=
                                                                            0) {

                                                                      widget
                                                                          .newsfeedController
                                                                          .replayModelList[
                                                                              ind]
                                                                          .imageDescriptionController
                                                                          .remove(widget
                                                                              .newsfeedController
                                                                              .replayModelList[ind]
                                                                              .imageDescriptionController[index]);
                                                                      if (widget
                                                                              .newsfeedController
                                                                              .replayModelList[ind]
                                                                              .imageCounter >=
                                                                          1) {
                                                                        widget
                                                                            .newsfeedController
                                                                            .replayModelList[ind]
                                                                            .imageCounter--;
                                                                      }

                                                                      widget
                                                                          .newsfeedController
                                                                          .update();
                                                                    }
                                                                    if (widget.newsfeedController.replayModelList[ind].descriptionCounter !=
                                                                            null &&
                                                                        widget.newsfeedController.replayModelList[ind].descriptionCounter >
                                                                            1) {
                                                                      widget
                                                                          .newsfeedController
                                                                          .replayModelList[
                                                                              ind]
                                                                          .descriptionCounter--;
                                                                      widget
                                                                          .newsfeedController
                                                                          .update();
                                                                    }
                                                                    setState(
                                                                        () {});


                                                                    /*widget
                                                                        .newsfeedController
                                                                        .replayModelList[
                                                                            ind]
                                                                        .mediaData2
                                                                        .remove(widget
                                                                            .newsfeedController
                                                                            .replayModelList[ind]
                                                                            .mediaData2[index]);*/
                                                                    listFiles.removeAt(index);
                                                                    // imageThumbnailsList.removeAt(index);
                                                                    setState(
                                                                        () {});
                                                                  },
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                              }),
                                        )

                                      :SizedBox(),
                                  ///threadvideo
                                  ////// reply video
                                  _pickedVideos.isNotEmpty

                                      // : widget.newsfeedController.replayModelList[ind].mediaData2.length > 0 &&
                                      //         widget
                                      //                 .newsfeedController
                                      //                 .replayModelList[ind]
                                      //                 .mediaData2[0]
                                      //                 .name ==
                                      //             "media"
                                          /*videoWidgetKey ==1*/ ? Align(
                                              alignment: Alignment.center,
                                              child: SizedBox(
                                                height: _pickedVideos
                                                        .isEmpty
                                                    ? 100
                                                    : MediaQuery.of(context)
                                                            .size
                                                            .height /
                                                        4,
                                                width: _pickedVideos
                                                        .isEmpty
                                                    ? 100
                                                    : double.infinity,
                                                child: Container(
                                                  child: Stack(
                                                    children: [
                                                      Container(
                                                        height: _pickedVideos
                                                                .isEmpty
                                                            ? 100
                                                            : MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .height /
                                                                4,
                                                        width: _pickedVideos
                                                                .isEmpty
                                                            ? 100
                                                            : double.infinity,
                                                        child: _pickedVideos
                                                                .isEmpty
                                                            ? Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child: Container(
                                                                    // width: 62,
                                                                    // height: 72,
                                                                    child: Column(
                                                                  children: [
                                                                    CircularProgressIndicator(
                                                                        color: MyColors
                                                                            .BlueColor),
                                                                    SizedBox(
                                                                        height:
                                                                            6),
                                                                    Text(
                                                                      Strings.uploading,
                                                                      style: TextStyle(
                                                                          color: Color(
                                                                              0xFFedab30),
                                                                          fontWeight:
                                                                              FontWeight.w700),
                                                                    ),
                                                                  ],
                                                                )),
                                                              )
                                                            : controller.videoThumbnail != null ? Image.memory(
                                                          controller.videoThumbnail,
                                                          height: MediaQuery.of(context)
                                                              .size
                                                              .height /
                                                              3.8,
                                                          width: double
                                                              .infinity,
                                                          fit: BoxFit
                                                              .cover,
                                                        ) : Image.asset("assets/images/video_placeholder.png",height: MediaQuery.of(context)
                                                            .size
                                                            .height /
                                                            3.8,
                                                          width: double
                                                              .infinity,
                                                          fit: BoxFit
                                                              .cover,),
                                                          /*  : Image.network(
                                                                widget
                                                                        .newsfeedController
                                                                        .replayModelList[
                                                                            ind]
                                                                        .mediaData2[
                                                                            0]
                                                                        .thumbnailUrl ??
                                                                    'https://via.placeholder.com/150',
                                                                height: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .height /
                                                                    3.8,
                                                                width: double
                                                                    .infinity,
                                                                fit: BoxFit
                                                                    .cover,
                                                              ),*/
                                                      ),
                                                      Positioned(
                                                        right: 6,
                                                        top: 10,
                                                        child: _pickedVideos
                                                                .isEmpty
                                                            ? SizedBox()
                                                            : CircleAvatar(
                                                                radius: 14,
                                                                backgroundColor:
                                                                    Colors.grey,
                                                                child:
                                                                    IconButton(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  icon: Icon(
                                                                    Icons
                                                                        .close_rounded,
                                                                    size: 16,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                  onPressed:
                                                                      () {
                                                                widget.newsfeedController.postText = false;
                                                                widget.newsfeedController.update();


                                                                // controller.modelList2[ind].mediaData2.clear();

                                                                // if (controller.modelList2[ind].mediaData2.length == 1) {
                                                                //   isMediaAttached = false;
                                                                //   setState(
                                                                //           () {});
                                                                // }

                                                                widget.newsfeedController.replayModelList[ind].mediaData2.clear();
                                                                _pickedVideos.clear();

                                                                isMediaAttached = false;
                                                                widget.newsfeedController.postText = false;
                                                                widget.newsfeedController.update();
                                                                //   videoWidgetKey =0;
                                                                setState(() {});
                                                                widget.newsfeedController.update();
                                                              },
                                                                ),
                                                              ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            )
                                          // ///threadaudio
                                          //     : controller.modelList2[ind].mediaData2.length > 0 && controller.modelList2[ind].mediaData2!= null
                                          //     ? audioUrl.isEmpty
                                          //     ? Container(
                                          //     width: 100,
                                          //     height: 100,
                                          //     child: Column(
                                          //       children: [
                                          //         CircularProgressIndicator(),
                                          //         SizedBox(height: 6),
                                          //         Text(
                                          //           'Uploading...',
                                          //           style: TextStyle(
                                          //               color: Color(
                                          //                   0xFFedab30),
                                          //               fontWeight:
                                          //               FontWeight
                                          //                   .w700),
                                          //         ),
                                          //       ],
                                          //     ))
                                          //     : Stack(
                                          //   children: [
                                          //     Container(
                                          //       child:
                                          //       ChewieAudioPlayer(
                                          //         audioUrl: audioUrl,
                                          //       ),
                                          //     ),
                                          //     Positioned(
                                          //       right: 6,
                                          //       top: 10,
                                          //       child: CircleAvatar(
                                          //         radius: 14,
                                          //         backgroundColor:
                                          //         Colors.grey,
                                          //         child: IconButton(
                                          //           padding:
                                          //           EdgeInsets.zero,
                                          //           icon: Icon(
                                          //             Icons
                                          //                 .close_rounded,
                                          //             size: 16,
                                          //             color:
                                          //             Colors.white,
                                          //           ),
                                          //           onPressed: () {
                                          //             widget.controller
                                          //                 .mediaData
                                          //                 .clear();
                                          //             if (controller.modelList2[ind].mediaData2.length == 1) {
                                          //               isMediaAttached = false;
                                          //
                                          //               setState(() {});
                                          //             }
                                          //             print(controller.modelList2[ind].mediaData2.length);
                                          //             controller.modelList2[ind].mediaData2.remove(
                                          //                 controller.modelList2[ind].mediaData2[0]);
                                          //             audioUrl = '';
                                          //             setState(() {});
                                          //           },
                                          //         ),
                                          //       ),
                                          //     ),
                                          //   ],
                                          // )
                                          /// reply pdf
                                          : widget
                                                      .newsfeedController
                                                      .replayModelList[ind]
                                                      .mediaData2
                                                      .length >
                                                  0
                                              ? widget
                                                          .newsfeedController
                                                          .replayModelList[ind]
                                                          .mediaData2[0]
                                                          .name
                                                          .isNotEmpty &&
                                                      widget
                                                          .newsfeedController
                                                          .replayModelList[ind]
                                                          .mediaData2[0]
                                                          .name
                                                          .contains('.pdf')
                                                  ?
                                                  /*pdfWidgetKey ==1?*/
                                                  widget.newsfeedController.replayModelList[ind].mediaData2.length == 0
                                                      ? Container(
                                                          width: 100,
                                                          height: 100,
                                                          child: CircularProgressIndicator(
                                                            color: MyColors
                                                                .BlueColor,
                                                          ))
                                                      : Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child: SizedBox(
                                                            height: 100,
                                                            width: 320,
                                                            child: ListView
                                                                .separated(
                                                                    scrollDirection:
                                                                        Axis
                                                                            .horizontal,
                                                                    itemBuilder:
                                                                        (context,
                                                                            index) {
                                                                      return Container(
                                                                        height:
                                                                            100,
                                                                        width:
                                                                            320,
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            Container(
                                                                              height: 250,
                                                                              width: 320,
                                                                              child: ListTile(
                                                                                leading: Image.asset('assets/images/document.png'),
                                                                                title: Text(widget.newsfeedController.replayModelList[ind].mediaData2[0].name),
                                                                                trailing: CircleAvatar(
                                                                                  radius: 14,
                                                                                  backgroundColor: Colors.grey,
                                                                                  child: IconButton(
                                                                                    padding: EdgeInsets.zero,
                                                                                    icon: Icon(
                                                                                      Icons.close_rounded,
                                                                                      size: 16,
                                                                                      color: Colors.white,
                                                                                    ),
                                                                                    onPressed: () {
                                                                                      widget.newsfeedController.postText = false;
                                                                                      widget.newsfeedController.update();
                                                                                      widget.newsfeedController.replayModelList[ind].mediaData2.clear();
                                                                                      isMediaAttached = false;
                                                                                      setState(() {});
                                                                                      widget.newsfeedController.update();
                                                                                    },
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      );
                                                                    },
                                                                    separatorBuilder:
                                                                        (_, __) {
                                                                      return SizedBox(
                                                                          width:
                                                                              4);
                                                                    },
                                                                    itemCount: widget
                                                                        .newsfeedController
                                                                        .replayModelList[
                                                                            ind]
                                                                        .mediaData2
                                                                        .length),
                                                          ),
                                                        )
                                                  : Container()
                                              : Container(),

                                  ///thread tag people and add description
                                  widget.newsfeedController.replayModelList[0]
                                                  .mediaData2.length >
                                              0 &&
                                          // && controller.modelList2[ind].mediaData2[0].name=="media"
                                          !widget
                                              .newsfeedController
                                              .replayModelList[0]
                                              .mediaData2[0]
                                              .name
                                              .contains('.pdf') &&
                                          (widget
                                                      .newsfeedController
                                                      .replayModelList[0]
                                                      .mediaData2[0]
                                                      .thumbnailUrl ==
                                                  null ||
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[0]
                                                  .mediaData2[0]
                                                  .thumbnailUrl
                                                  .isEmpty)
                                      /*  imageWidgetKey ==1*/ ? Row(
                                          children: [
                                            InkWell(
                                                onTap: () {
                                                  widget.newsfeedController
                                                      .tagList
                                                      .clear();
                                                  widget.newsfeedController
                                                      .showCustomDialogReply(
                                                          context,
                                                          height,
                                                          width, () {
                                                    setState(() {
                                                      widget.newsfeedController
                                                              .tagList =
                                                          widget
                                                              .newsfeedController
                                                              .tagList;
                                                    });
                                                  });
                                                },
                                                child: Row(
                                                  children: [
                                                    Icon(
                                                      Icons.person,
                                                      size: 20,
                                                      color: widget
                                                          .newsfeedController
                                                          .displayColor,
                                                    ),
                                                    // Text(controller.tagList.isNotEmpty? "${controller.tagList.length >1?controller.tagList[0].firstname + " and ${controller.tagList.length-1} Others":"${controller.tagList[0].firstname}" } " :"Tag People",style:TextStyle(color: Colors.blue,fontSize: 12)),
                                                    Text(
                                                        widget
                                                                .newsfeedController
                                                                .replayModelList[
                                                                    ind]
                                                                .mediaData2[0]
                                                                .mentionUserList
                                                                .isNotEmpty
                                                            ? "${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList.length > 1 ? widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList[0].firstname + " and ${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList.length - 1} Others" : "${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList[0].firstname}"} "
                                                            : "Tag People",
                                                        style: TextStyle(
                                                            color: widget
                                                                .newsfeedController
                                                                .displayColor,
                                                            fontSize: 14)),
                                                  ],
                                                )),
                                            SizedBox(
                                              width: 20,
                                            ),
                                            widget
                                                            .newsfeedController
                                                            .replayModelList[0]
                                                            .mediaData2
                                                            .length ==
                                                        1 &&
                                                    widget
                                                            .newsfeedController
                                                            .replayModelList[0]
                                                            .descriptionCounter ==
                                                        1 &&
                                                    widget
                                                        .newsfeedController
                                                        .replayModelList[0]
                                                        .mediaData2[0]
                                                        .description
                                                        .isNotEmpty
                                                ? InkWell(
                                                    onTap: () {
                                                      if (kIsWeb) {
                                                        showDialog(
                                                            context: context,
                                                            builder:
                                                                (BuildContext
                                                                    con) {
                                                              return Shortcuts(
                                                                shortcuts: {
                                                                  LogicalKeySet(
                                                                          LogicalKeyboardKey
                                                                              .escape):
                                                                      EscIntent()
                                                                },
                                                                child:
                                                                    AlertDialog(
                                                                        backgroundColor: Theme.of(context).brightness == Brightness.dark
                                                                            ? MyColors
                                                                                .liteDark
                                                                            : Colors
                                                                                .white,
                                                                        insetPadding: EdgeInsets.symmetric(
                                                                            horizontal:
                                                                                0,
                                                                            vertical:
                                                                                0),
                                                                        contentPadding:
                                                                            EdgeInsets
                                                                                .zero,
                                                                        shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius.all(Radius.circular(
                                                                                10.0))),
                                                                        content:
                                                                            SingleChildScrollView(
                                                                          child:
                                                                              PostImageDescriptionForReply(
                                                                            ind:
                                                                                0,
                                                                            addDescriptionCheck:
                                                                                1,
                                                                          ),
                                                                        )

                                                                        //     Deactivation(
                                                                        //   context2: context,
                                                                        // ),
                                                                        ),
                                                              );
                                                            });
                                                      } else {
                                                        Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                              builder: (context) =>
                                                                  PostImageDescriptionForReply(
                                                                    ind: 0,
                                                                    addDescriptionCheck:
                                                                        1,
                                                                  )),
                                                        );
                                                      }
                                                    },
                                                    child: Row(
                                                      children: [
                                                        Icon(
                                                          Icons.note_add,
                                                          size: 20,
                                                          color: widget
                                                              .newsfeedController
                                                              .displayColor,
                                                        ),
                                                        SizedBox(
                                                          width: 2,
                                                        ),
                                                        Container(
                                                          width: 100,
                                                          child: Text(
                                                            widget
                                                                .newsfeedController
                                                                .replayModelList[
                                                                    0]
                                                                .mediaData2[0]
                                                                .description,
                                                            style: TextStyle(
                                                              color: widget
                                                                  .newsfeedController
                                                                  .displayColor,
                                                              fontSize: 14,
                                                            ),
                                                            overflow:
                                                                TextOverflow
                                                                    .ellipsis,
                                                          ),
                                                        ),
                                                      ],
                                                    ))
                                                : widget
                                                                .newsfeedController
                                                                .replayModelList[
                                                                    0]
                                                                .mediaData2
                                                                .length >
                                                            1 &&
                                                        widget
                                                                .newsfeedController
                                                                .replayModelList[
                                                                    0]
                                                                .descriptionCounter >=
                                                            1
                                                    ? InkWell(
                                                        onTap: () {
                                                          if (kIsWeb) {
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (BuildContext
                                                                        con) {
                                                                  return Shortcuts(
                                                                    shortcuts: {
                                                                      LogicalKeySet(
                                                                              LogicalKeyboardKey.escape):
                                                                          EscIntent()
                                                                    },
                                                                    child: AlertDialog(
                                                                        backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                        insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                        contentPadding: EdgeInsets.zero,
                                                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                        content: SingleChildScrollView(
                                                                          child:
                                                                              PostImageDescriptionForReply(
                                                                            ind:
                                                                                0,
                                                                            addDescriptionCheck:
                                                                                1,
                                                                          ),
                                                                        )

                                                                        //     Deactivation(
                                                                        //   context2: context,
                                                                        // ),
                                                                        ),
                                                                  );
                                                                });
                                                          } else {
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          PostImageDescriptionForReply(
                                                                            ind:
                                                                                0,
                                                                            addDescriptionCheck:
                                                                                1,
                                                                          )),
                                                            );
                                                          }
                                                        },
                                                        child: Row(
                                                          children: [
                                                            Icon(
                                                              Icons.note_add,
                                                              size: 20,
                                                              color: widget
                                                                  .newsfeedController
                                                                  .displayColor,
                                                            ),
                                                            SizedBox(
                                                              width: 2,
                                                            ),
                                                            Text(
                                                                "${widget.newsfeedController.replayModelList[0].descriptionCounter} image Description",
                                                                style: TextStyle(
                                                                    color: widget
                                                                        .newsfeedController
                                                                        .displayColor,
                                                                    fontSize:
                                                                        14)),
                                                          ],
                                                        ))
                                                    : InkWell(
                                                        onTap: () {
                                                          if (widget
                                                                  .newsfeedController
                                                                  .replayModelList[
                                                                      0]
                                                                  .imageDescriptionController
                                                                  .length >
                                                              0) {
                                                            widget
                                                                .newsfeedController
                                                                .replayModelList[
                                                                    0]
                                                                .imageDescriptionController
                                                                .forEach(
                                                                    (element) {
                                                              element.clear();
                                                            });
                                                          }
                                                          if (kIsWeb) {
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (BuildContext
                                                                        con) {
                                                                  return Shortcuts(
                                                                    shortcuts: {
                                                                      LogicalKeySet(
                                                                              LogicalKeyboardKey.escape):
                                                                          EscIntent()
                                                                    },
                                                                    child: AlertDialog(
                                                                        backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                        insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                        contentPadding: EdgeInsets.zero,
                                                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                        content: SingleChildScrollView(
                                                                          child:
                                                                              PostImageDescriptionForReply(
                                                                            ind:
                                                                                0,
                                                                            addDescriptionCheck:
                                                                                1,
                                                                          ),
                                                                        )

                                                                        //     Deactivation(
                                                                        //   context2: context,
                                                                        // ),
                                                                        ),
                                                                  );
                                                                });
                                                          } else {
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                  builder:
                                                                      (context) =>
                                                                          PostImageDescriptionForReply(
                                                                            ind:
                                                                                0,
                                                                            addDescriptionCheck:
                                                                                1,
                                                                          )),
                                                            );
                                                          }
                                                        },
                                                        child: Row(
                                                          children: [
                                                            Icon(
                                                              Icons.note_add,
                                                              size: 20,
                                                              color: widget
                                                                  .newsfeedController
                                                                  .displayColor,
                                                            ),
                                                            SizedBox(
                                                              width: 2,
                                                            ),
                                                            Text(
                                                                Strings.addDescription,
                                                                style: TextStyle(
                                                                    color: widget
                                                                        .newsfeedController
                                                                        .displayColor,
                                                                    fontSize:
                                                                        14)),
                                                          ],
                                                        )),
                                          ],
                                        )
                                      : SizedBox(),

                                  widget.newsfeedController.replayModelList[ind]
                                              .location !=
                                          ""
                                      ? Row(
                                          children: [
                                            Icon(Icons.location_on_outlined),
                                            Text(widget.newsfeedController
                                                .replayModelList[ind].location),
                                            SizedBox(
                                              width: 15,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                widget
                                                    .newsfeedController
                                                    .replayModelList[ind]
                                                    .location = "";
                                                // SingleTone.instance.selectedLocation = null;
                                                Get.find<NewsfeedController>()
                                                    .postText = false;
                                                Get.find<NewsfeedController>()
                                                    .update();
                                                setState(() {});
                                              },
                                              child: Icon(
                                                Icons.clear,
                                              ),
                                            )
                                          ],
                                        )
                                      : SizedBox()
                                ],
                              ),
                            ),
                          );
                        },
                        childCount:
                            widget.newsfeedController.replayModelList.length,
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: Container(
                        height: !isEmojiVisible ? 150 : 300,
                        child: Column(
                          children: [
                            SizedBox(),
                            widget.isPostScheduled
                                ? SizedBox()
                                : isMediaUploading
                                    ? SizedBox()
                                    : Divider(),
                            widget.isPostScheduled
                                ? SizedBox()
                                : isMediaUploading
                                    ? SizedBox()
                                    : SizedBox(),
                            isMediaUploading
                                ? SizedBox()
                                : Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      /// imagesicon

                                      CreatePostIcons(AppImages.uploadImage, widget
                                          .newsfeedController
                                          .replayModelList[widget
                                          .newsfeedController
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0 &&
                                          isMediaAttached == true ||
                                          showPolls[widget
                                              .newsfeedController
                                              .currentIndexText] ==
                                              true
                                          ? () {}
                                          : () {
                                        showModalBottomSheet<void>(
                                          backgroundColor:
                                          Colors.grey.shade200,
                                          context: context,
                                          builder:
                                              (BuildContext context) {
                                            return Column(
                                              mainAxisSize:
                                              MainAxisSize.min,
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .stretch,
                                              children: [
                                                ListTile(
                                                    leading: Icon(Icons
                                                        .camera_alt),
                                                    title: Text(
                                                        Strings.takeAPhoto),
                                                    onTap: () async {
                                                      Get.back();
                                                      widget
                                                          .newsfeedController
                                                          .postText = true;

                                                      widget
                                                          .newsfeedController
                                                          .update();
                                                      imageWidgetKey =
                                                      1;
                                                      videoWidgetKey =
                                                      0;
                                                      pdfWidgetKey = 0;
                                                      listFiles = [];

                                                      var image = await UtilsMethods.getImageFromCamera();




                                                      if (image !=
                                                          null) {
                                                        File
                                                        compressedImage =
                                                        await FileSupport().compressImage(
                                                            File(image
                                                                .path),
                                                            quality:
                                                            50);

                                                        var size = await FileSupport().getFileSize(
                                                            file:
                                                            compressedImage);

                                                        String
                                                        filePath =
                                                            compressedImage
                                                                .path;
                                                        String
                                                        fileName =
                                                            filePath
                                                                .split(
                                                                '/')
                                                                .last;

                                                        String
                                                        splitSize =
                                                        size.substring(
                                                            0, 2);
                                                        int fileSize =
                                                        int.parse(
                                                            splitSize);

                                                        PlatformFile
                                                        convertedFile =
                                                        await PlatformFile(
                                                          name:
                                                          fileName,
                                                          path:
                                                          filePath,
                                                          size:
                                                          fileSize,
                                                        );
                                                        List<PlatformFile>
                                                        compressedFiles =
                                                        [];
                                                        compressedFiles.add(
                                                            convertedFile);
                                                        List<PlatformFile>
                                                        listFiles =
                                                        [];
                                                        listFiles.addAll(
                                                            compressedFiles);
                                                        compressedFiles
                                                            .clear();
                                                        List<_dio.MultipartFile>
                                                        files = [];
                                                        files = listFiles
                                                            .map((path) => _dio.MultipartFile.fromFileSync(
                                                          path.path,
                                                          filename:
                                                          path.name,
                                                        ))
                                                            .toList();

                                                        Map<String,
                                                            dynamic>
                                                        userData =
                                                        {};
                                                        if (files
                                                            .isNotEmpty) {
                                                          userData
                                                              .addAll({
                                                            'files[]':
                                                            files
                                                          });
                                                        }

                                                        isMediaUploading =
                                                        true;
                                                        await widget
                                                            .newsfeedController
                                                            .multiImageSeleted(
                                                            userData,
                                                            2,listFiles);
                                                        // controller.modelList2[controller.currentIndexText].imagePickCount = controller.modelList2[controller.currentIndexText].imagePickCount + files.length;

                                                        visibility =
                                                        true;
                                                        isMediaUploading =
                                                        false;
                                                        isMediaAttached =
                                                        false;
                                                        setState(() {});

                                                        Get.back();
                                                      } else {
                                                        Get.back();
                                                      }
                                                    }),
                                                ListTile(
                                                    leading: Icon(
                                                        Icons.image),
                                                    title: Text(
                                                        Strings.chooseFromGallery),
                                                    onTap: () async {
                                                      Get.back();
                                                      callGetImage();
                                                    }),
                                              ],
                                            );
                                          },
                                        );
                                      },),

                                      /// videoicon
                                      ///
                                      CreatePostIcons(AppImages.uploadVideo, widget
                                          .newsfeedController
                                          .replayModelList[widget
                                          .newsfeedController
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0 ||
                                          showPolls[widget
                                              .newsfeedController
                                              .currentIndexText]
                                          ? () {}
                                          : (){
                                        showModalBottomSheet<void>(
                                          backgroundColor: Colors.grey.shade200,
                                          context: context,
                                          builder: (BuildContext context) {
                                            return Column(
                                              mainAxisSize: MainAxisSize.min,
                                              crossAxisAlignment: CrossAxisAlignment.stretch,
                                              children: [
                                                ListTile(
                                                    leading: Icon(Icons.camera_alt),
                                                    title: Text(Strings.makeVideoWithPhoneCamera),
                                                    onTap: () async {
                                                      Get.back();
                                                      widget.newsfeedController.postText = true;

                                                      widget.newsfeedController.update();

                                                      videoWidgetKey = 1;
                                                      imageWidgetKey = 0;
                                                      pdfWidgetKey = 0;
                                                      setState(() {});
                                                      // File pickedMedia;
                                                      Map<String,dynamic> map =await dataController.getVideoFromCamera();
                                                      videoBytes = map['bytes'];

                                                      // _pickedVideo = pickedMedia.path;

                                                      // _pickedImage.add(videoBytes);
                                                      // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
                                                      if (videoBytes != null) {
                                                        _pickedVideos.add(videoBytes);
                                                        _pickedVideosMemeType.add(map['memeType']);
                                                        _pickedVideosName.add(map['name'] ?? '');
                                                        isMediaUploading = true;

                                                        videoThumbnail = await  widget.newsfeedController.uploadMedia(_pickedVideos[0], 2,fileType: 'mp4',memeType: _pickedVideosMemeType[0],fileName: _pickedVideosName[0]);
                                                        Get.back();
                                                        videoWidgetKey = 1;
                                                        setState(() {
                                                          widget.newsfeedController.postText = true;
                                                        });


                                                        //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
                                                        if (videoThumbnail != null) {

                                                          setState(() {
                                                            visibility = true;
                                                            isMediaAttached = true;
                                                            isMediaUploading = false;
                                                          });
                                                        } else {
                                                          print('IN ELSE BLOCK');
                                                        }
                                                      }



                                                    }
                                                ),
                                                ListTile(
                                                    leading: Icon(Icons.image),
                                                    title: Text(Strings.chooseFromGallery),
                                                    onTap: () async {
                                                      Get.back();
                                                      callGetVideo();

                                                    }
                                                ),
                                              ],
                                            );
                                          },
                                        );
                                      },),

                                      /// audioicon
                                      // InkWell(
                                      //   onTap:
                                      //   //  isMediaUploading ? () {} : _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {} : _pickedPdfs.length > 0 || _pickedVideos.length > 0 || _pickedImage.length > 0
                                      //   controller.modelList2[widget.controller.currentIndexText].mediaData2.length>0 || showPolls[controller.currentIndexText]
                                      //       ? () {}
                                      //       : callGetAudio,
                                      //   child: Container(
                                      //       width: 20,
                                      //       height: 20,
                                      //       child: SvgPicture.asset(
                                      //         // _pickedPdfs.length > 0 ||
                                      //         //     _pickedAudios.length > 0 ||
                                      //         //     _pickedVideos.length > 0
                                      //         //     ?
                                      //         'assets/post_icons/mic.svg',
                                      //         color:
                                      //         controller.modelList2[widget.controller.currentIndexText].mediaData2.length>0 || showPolls[controller.currentIndexText]
                                      //             ? Colors.grey[400] :
                                      //         //   _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? Colors.grey[400] :
                                      //         Color(0xFFedc01c),
                                      //         // : 'assets/post_icons/image_color.png',
                                      //       )
                                      //     // Image.asset(_pickedPdfs.length > 0 ||
                                      //     //         _pickedVideos.length > 0 ||
                                      //     //         _pickedImage.length > 0
                                      //     //     ? 'assets/post_icons/mic.png'
                                      //     //     : 'assets/post_icons/mic_color.png'),
                                      //   ),
                                      // ),
                                      ///pdficon
                                      ///
                                      CreatePostIcons(AppImages.uploadFile, widget
                                          .newsfeedController
                                          .replayModelList[widget
                                          .newsfeedController
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0 ||
                                          showPolls[widget
                                              .newsfeedController
                                              .currentIndexText]
                                          ? () {} /*: _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {} : _pickedAudios.length > 0 || _pickedVideos.length > 0 || _pickedImage.length > 0 ? () {}*/
                                          : callGetFile,),

                                      ///poll icon
                                     /* InkWell(
                                        onTap:
                                            // isMediaUploading
                                            widget
                                                        .newsfeedController
                                                        .replayModelList[widget
                                                            .newsfeedController
                                                            .currentIndexText]
                                                        .mediaData2
                                                        .length >
                                                    0
                                                ? () {}
                                                :
                                                //_pickedVideos.isNotEmpty ||
                                                //   isMediaAttached ||
                                                showPolls[widget
                                                            .newsfeedController
                                                            .currentIndexText] ||
                                                        widget.isPostScheduled
                                                    ? () {}
                                                    : () {
                                                        showPolls[widget
                                                            .newsfeedController
                                                            .currentIndexText] = true;
                                                        widget
                                                            .newsfeedController
                                                            .replayModelList[widget
                                                                .newsfeedController
                                                                .currentIndexText]
                                                            .poolThread = true;
                                                        setState(() {});
                                                      },
                                        child: SvgPicture.asset(
                                          'assets/post_icons/polls.svg',
                                          // fit: BoxFit.fill,
                                          height: 20,
                                          width: 20,
                                          color:
                                              //  isMediaUploading
                                              widget
                                                          .newsfeedController
                                                          .replayModelList[widget
                                                              .newsfeedController
                                                              .currentIndexText]
                                                          .mediaData2
                                                          .length >
                                                      0
                                                  ? Colors.grey[400]
                                                  :
                                                  // _pickedVideos.isNotEmpty ||
                                                  //  isMediaAttached ||
                                                  widget.isPostScheduled ||
                                                          showPolls[widget
                                                              .newsfeedController
                                                              .currentIndexText]
                                                      ? Colors.grey[400]
                                                      : widget
                                                          .newsfeedController
                                                          .displayColor,
                                          // : Colors.green,
                                        ),
                                      ),*/

                                      ///scheduleposticon
                                      CreatePostIcons(AppImages.uploadSchedulePost, widget
                                          .newsfeedController
                                          .replayModelList[widget
                                          .newsfeedController
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0
                                      //  ||
                                      //   showPolls
                                          ? () {}
                                          : () async {
                                        bool val =
                                        await showModalBottomSheet(
                                          // isDismissible: false,

                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.only(
                                                    topLeft: Radius
                                                        .circular(
                                                        20),
                                                    topRight: Radius
                                                        .circular(
                                                        20))),
                                            context: context,
                                            isScrollControlled:
                                            true,
                                            constraints:
                                            BoxConstraints(
                                                maxHeight:
                                                520),
                                            builder: (context) {
                                              return StatefulBuilder(
                                                  builder: (context,
                                                      setState) {
                                                    return Container(
                                                      padding: EdgeInsets.symmetric(
                                                          horizontal:
                                                          16,
                                                          vertical:
                                                          16),
                                                      child: showScheduledWerfs
                                                          ?
                                                      // GetBuilder<
                                                      //         NewsfeedController>(
                                                      //         builder: (controller) {
                                                      //           return
                                                      Column(
                                                        children: [
                                                          ListTile(
                                                            leading: GestureDetector(
                                                                onTap: () {
                                                                  showScheduledWerfs = false;
                                                                  // visibility==false;
                                                                  setState(() {});
                                                                },
                                                                child: Icon(Icons.arrow_back)),
                                                            title: Text(Strings.unsentWerfs),
                                                            trailing: RoundedButton(
                                                              Strings.reply,
                                                                  () {
                                                                isEditable = true;
                                                                setState(() {});
                                                              },
                                                              horizontalPadding: 10.0,
                                                              verticalPadding: 4.0,
                                                              roundedButtonColor: widget.newsfeedController.displayColor,
                                                            ),
                                                          ),
                                                          SizedBox(height: 10),
                                                          Divider(height: 1),
                                                          widget.newsfeedController.noScheduledPost
                                                              ? CircularProgressIndicator(
                                                            color: MyColors.BlueColor,
                                                          )
                                                              : widget.newsfeedController.scheduledPosts.isEmpty
                                                              ? Center(
                                                            child: Text(Strings.youHaveNoScheduledWerfs),
                                                          )
                                                              : Expanded(
                                                            child: ListView.separated(
                                                                shrinkWrap: true,
                                                                itemBuilder: (context, index) {
                                                                  var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(widget.newsfeedController.scheduledPosts[index].postingTime, true);
                                                                  var postingTime = dateTime.toLocal();
                                                                  postingTime = DateFormat('yyyy-MM-dd HH:mm').parse(postingTime.toString());

                                                                  ///changes made in this section of code in edit schedule
                                                                  return GestureDetector(
                                                                    onTap: () {
                                                                      widget.isPostScheduled = true;
                                                                      monthValidatedSuccessfully = true;
                                                                      hourValidatedSuccessfully = true;
                                                                      postTextController.text = widget.newsfeedController.scheduledPosts[index].body;
                                                                      Navigator.of(context).pop();
                                                                      setState(() {});
                                                                    },
                                                                    child: ListTile(
                                                                      leading: isEditable
                                                                          ? Checkbox(
                                                                          value: widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion,
                                                                          onChanged: (value) {
                                                                            if (widget.postsForDeletions.contains(widget.newsfeedController.scheduledPosts[index].id)) {
                                                                              int ind = widget.postsForDeletions.indexWhere((element) => element == widget.newsfeedController.scheduledPosts[index].id);

                                                                              widget.postsForDeletions.removeAt(ind);
                                                                            } else {
                                                                              widget.postsForDeletions.add(widget.newsfeedController.scheduledPosts[index].id);
                                                                            }
                                                                            widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion = !widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion;
                                                                            widget.newsfeedController.update();
                                                                            setState(() {});
                                                                          })
                                                                          : SizedBox(),

                                                                      title: Text(
                                                                        '${Strings.willSendOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                        style: Styles.baseTextTheme.headline2.copyWith(
                                                                          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: kIsWeb ? 14 : 12,
                                                                          fontWeight: FontWeight.w400,
                                                                        ),
                                                                      ),
                                                                      // Text('Will Post on ${DateFormat.yMMMMd().add_jm().format(postingTime)}'),

                                                                      subtitle: Text(widget.newsfeedController.scheduledPosts[index].body),
                                                                    ),
                                                                  );
                                                                },

                                                                ///changes made in this section of code
                                                                separatorBuilder: (_, __) {
                                                                  return Divider(height: 1);
                                                                },
                                                                itemCount: widget.newsfeedController.scheduledPosts.length),
                                                          ),
                                                          isEditable
                                                              ? ListTile(
                                                            leading: Text(Strings.selectAll),
                                                            trailing: GestureDetector(
                                                              onTap: () {

                                                                widget.newsfeedController.deleteScheduledPosts(widget.postsForDeletions, context);
                                                                // widget
                                                                //     .postsForDeletions
                                                                //     .clear();
                                                              },
                                                              child: Text(Strings.delete),
                                                            ),
                                                          )
                                                              : SizedBox(),
                                                        ],
                                                      )
                                                      //     ;
                                                      //   },
                                                      // )
                                                          : Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment.start,
                                                        children: [
                                                          Row(
                                                            children: [
                                                              GestureDetector(
                                                                  onTap: () {
                                                                    Navigator.pop(context, false);
                                                                  },
                                                                  child: Icon(
                                                                    Icons.close,
                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  )),
                                                              SizedBox(width: 12),
                                                              Text(
                                                                Strings.schedule,
                                                                //  style: Theme.of(context).textTheme.headline4

                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontWeight: FontWeight.bold,
                                                                ),
                                                              ),
                                                              Spacer(),
                                                              RoundedButton(
                                                                Strings.confirm,

                                                                // hourValidatedSuccessfully &&
                                                                //         minutesValidatedSuccessfully &&
                                                                //         monthValidatedSuccessfully &&
                                                                //         dayValidatedSuccessfully
                                                                //     ? null
                                                                //     :
                                                                    () {
                                                                  if (monthValidatedSuccessfully) {
                                                                    widget.isPostScheduled = true;

                                                                    //  visibility=false;

                                                                    Navigator.pop(context, true);
                                                                  }
                                                                },
                                                                horizontalPadding: 20.0,
                                                                verticalPadding: 0.0,
                                                                roundedButtonColor: widget.newsfeedController.displayColor,
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 20,
                                                          ),
                                                          Row(
                                                            children: [
                                                              Icon(
                                                                Icons.calendar_today,
                                                                color: Color(0xFF586976),
                                                              ),
                                                              // SizedBox(width: 20,),
                                                              Padding(
                                                                padding: const EdgeInsets.only(left: 8),
                                                                child: Text(
                                                                  '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                  // 'Will Post on ${DateFormat("yyyy-MM-dd hh:mm").parse(selectedDateTime)}',
                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                    // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                    fontSize: kIsWeb ? 14 : 10,
                                                                    fontWeight: FontWeight.w400,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 10,
                                                          ),
                                                          Text(
                                                            Strings.date,
                                                            //  style: Theme.of(context).textTheme.headline6,

                                                            style: Styles.baseTextTheme.headline2.copyWith(
                                                              //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.w500,
                                                            ),
                                                          ),
                                                          SizedBox(height: 10),
                                                          /* Date DropDown Section */
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            children: [
                                                              // Drop Down Button for Month
                                                              ButtonTheme(
                                                                materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                child: Expanded(
                                                                  flex: 2,
                                                                  child: DropdownButtonFormField<String>(
                                                                    icon: Icon(Icons.keyboard_arrow_down),
                                                                    isExpanded: true,

                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                      border: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      disabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      enabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: widget.newsfeedController.displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText: Strings.month,
                                                                      labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.newsfeedController.displayColor,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint: Text(
                                                                      months[DateTime.now().month - 1],
                                                                      //,
                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),

                                                                    alignment: Alignment.bottomCenter,
                                                                    items: months.map((String value) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: value,
                                                                        child: Text(
                                                                          value.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (month) {
                                                                      /*        int selectedMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                month);
                                                            int currentMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                months[DateTime.now().month - 1]);
                                                            selectedMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            scheduleMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            print('SELECTED  $selectedMonthIndex' +
                                                                ' : ' +
                                                                'CURRENT $currentMonthIndex');*/

                                                                      selectedMonthValue = (months.indexWhere((element) => element == month) + 1).toString();

                                                                      selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(selectedDateTime)) {
                                                                        monthValidatedSuccessfully = true;
                                                                      } else {
                                                                        monthValidatedSuccessfully = false;
                                                                      }
                                                                      setState(() {});

                                                                      // setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(width: 12),
                                                              // Drop Down Button for Day
                                                              ButtonTheme(
                                                                materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                child: Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<String>(
                                                                    icon: Icon(Icons.keyboard_arrow_down),
                                                                    isExpanded: true,
                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                      border: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      disabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      enabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: widget.newsfeedController.displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText: Strings.day,
                                                                      labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.newsfeedController.displayColor,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint: Text(
                                                                      selectedDayValue,
                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment: Alignment.bottomCenter,
                                                                    items: List.generate(31, (index) => index + 1).map((int value) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: value.toString(),
                                                                        child: Text(
                                                                          value.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (day) {
                                                                      selectedDayValue = day;
                                                                      scheduleDayValue = day;
                                                                      int currentDay = DateTime.now().day;
                                                                      selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(selectedDateTime)) {
                                                                        monthValidatedSuccessfully = true;
                                                                      } else {
                                                                        monthValidatedSuccessfully = false;
                                                                      }
                                                                      setState(() {});
                                                                      // }
                                                                    },
                                                                  ),
                                                                ),
                                                              ),

                                                              SizedBox(width: 12),

                                                              // Drop Down Button for Year
                                                              ButtonTheme(
                                                                materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                child: Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<String>(
                                                                    icon: Icon(Icons.keyboard_arrow_down),
                                                                    isExpanded: true,
                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                                                      border: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      disabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      enabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: widget.newsfeedController.displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText: Strings.year,
                                                                      labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.newsfeedController.displayColor,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint: Text(
                                                                      DateTime.now().year.toString(),
                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment: Alignment.bottomCenter,
                                                                    items: years.map((int value) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: value.toString(),
                                                                        child: Text(
                                                                          value.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (year) {
                                                                      selectedYearValue = year;

                                                                      scheduleYearValue = year;

                                                                      selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(selectedDateTime)) {
                                                                        monthValidatedSuccessfully = true;
                                                                      } else {
                                                                        monthValidatedSuccessfully = false;
                                                                      }
                                                                      setState(() {});
                                                                      //


                                                                      // setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          !monthValidatedSuccessfully
                                                              ? Text(
                                                            Strings.youCannotScheduleAWerfInThePast,
                                                            style: TextStyle(color: Colors.red),
                                                          )
                                                              : SizedBox(),
                                                          SizedBox(height: 20),
                                                          /* Time DropDown Section */
                                                          Text(
                                                            Strings.time,
                                                            //  style: Theme.of(context).textTheme.headline6,
                                                            style: Styles.baseTextTheme.headline2.copyWith(
                                                              //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.w500,
                                                            ),
                                                          ),
                                                          SizedBox(height: 10),
                                                          Row(
                                                            children: [
                                                              /* DropDown Button For Hours */
                                                              ButtonTheme(
                                                                materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                child: Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<String>(
                                                                    icon: Icon(Icons.keyboard_arrow_down),
                                                                    isExpanded: true,
                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                      border: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      disabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      enabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: widget.newsfeedController.displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText: Strings.hours,
                                                                      labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.newsfeedController.displayColor,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint: Text(
                                                                      selectedHourValue,
                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment: Alignment.bottomCenter,
                                                                    items: List.generate(24, (index) => index).map((int value) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: value.toString(),
                                                                        child: Text(
                                                                          value.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (hour) {
                                                                      selectedHourValue = hour;
                                                                      scheduleHourValue = hour;

                                                                      selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(selectedDateTime)) {
                                                                        monthValidatedSuccessfully = true;
                                                                      } else {
                                                                        monthValidatedSuccessfully = false;
                                                                      }
                                                                      setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              /* DropDown Button For Minutes */
                                                              SizedBox(width: 12),
                                                              ButtonTheme(
                                                                materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                child: Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<String>(
                                                                    icon: Icon(Icons.keyboard_arrow_down),
                                                                    isExpanded: true,
                                                                    decoration: InputDecoration(
                                                                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                      border: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      disabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                        ),
                                                                      ),
                                                                      enabledBorder: OutlineInputBorder(
                                                                        borderRadius: BorderRadius.circular(10),
                                                                        borderSide: BorderSide(
                                                                          color: widget.newsfeedController.displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText: Strings.minutes,
                                                                      labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.newsfeedController.displayColor,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),

                                                                    // value: 0.toString(),
                                                                    hint: Text(
                                                                      selectedMinutesValue,
                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment: Alignment.bottomCenter,
                                                                    items: List.generate(60, (index) => index).map((int value) {
                                                                      return DropdownMenuItem<String>(
                                                                        value: value.toString(),
                                                                        child: Text(
                                                                          value.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged: (minute) {
                                                                      selectedMinutesValue = minute;
                                                                      scheduleMinutesValue = minute;

                                                                      selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(selectedDateTime)) {
                                                                        monthValidatedSuccessfully = true;
                                                                      } else {
                                                                        monthValidatedSuccessfully = false;
                                                                      }
                                                                      setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(width: 12),
                                                              Expanded(flex: 1, child: SizedBox()),
                                                            ],
                                                          ),
                                                          /* if (!monthValidatedSuccessfully)
                                                    Text(
                                                      'You cannot schedule a Werf in the past',
                                                      style: TextStyle(
                                                        color:
                                                        Colors.red,
                                                        fontSize: 12,
                                                      ),
                                                    )
                                                  else
                                                    SizedBox(),*/
                                                          SizedBox(height: 20),
                                                          Text(
                                                            Strings.timeZone,
                                                            //  style: Theme.of(context).textTheme.headline6,

                                                            style: Styles.baseTextTheme.headline2.copyWith(
                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.w500,
                                                            ),
                                                          ),
                                                          SizedBox(height: 10),
                                                          Text(
                                                            DateTime.now().timeZoneName,
                                                            // style: Theme.of(context).textTheme.headline4.copyWith(height: 1.2)

                                                            style: Styles.baseTextTheme.headline2.copyWith(
                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              //fontSize: kIsWeb ? 16 : 14,
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                          Divider(height: 1),
                                                          SizedBox(height: 10),
                                                          GestureDetector(
                                                              onTap: () async {
                                                                widget.newsfeedController.noScheduledPost = true;
                                                                showScheduledWerfs = true;
                                                                setState(() {});

                                                                widget.newsfeedController.scheduledPosts = await widget.newsfeedController.getScheduledPosts();
                                                                widget.newsfeedController.noScheduledPost = false;

                                                                setState(() {});
                                                              },
                                                              child: Text(
                                                                Strings.scheduledWerfs,
                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontSize: kIsWeb ? 16 : 14,
                                                                  fontWeight: FontWeight.w500,
                                                                ),
                                                              ))
                                                        ],
                                                      ),
                                                    );
                                                  });
                                            });

                                        if (val) {
                                          setState(() {});
                                        }
                                      },),

                                      /// locationicon
                                      CreatePostIcons( AppImages.uploadLocation, () {
                                        locationController
                                            .locationTextController
                                            .clear();
                                        Get.to(GoogleSearchSuggestion(
                                            index: widget.newsfeedController
                                                .currentIndexText, isReply: true)).then((value) {
                                          setState(() {});
                                        });
                                      }),


                                      ///smileicon
                                      CreatePostIcons(AppImages.uploadEmojis, () {

                                        if (isEmojiVisible) {

                                          widget.newsfeedController.focusNode
                                              .requestFocus();
                                        } else if (!isEmojiVisible) {
                                          // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                          // await Future.delayed(
                                          //     const Duration(milliseconds: 100));
                                          FocusScope.of(context).unfocus();

                                          // widget.controller.focusNode.unfocus();
                                        }
                                        isEmojiVisible = !isEmojiVisible;
                                        if (this.mounted) {
                                          // check whether the state object is in tree
                                          setState(() {
                                            // make changes here
                                          });
                                        }
                                      }),
                                    ],
                                  ),
                            Offstage(
                                offstage: !isEmojiVisible,
                                child: Container(
                                    height: 175,
                                    width: double.infinity,
                                    margin: const EdgeInsets.all(5),
                                    padding: const EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.black54, width: .5),
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: DefaultTabController(
                                        length: emojis.length,
                                        child: isPortrait
                                            ? Column(children: [
                                                Container(
                                                    margin: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: 2),
                                                    child: EmojiTabBar(
                                                        tabController:
                                                            _tabController)),
                                                const Divider(
                                                    color: Colors.black45,
                                                    height: 5,
                                                    thickness: .5),
                                                EmojisList(
                                                    cross: cross,
                                                    textController: _controller[
                                                        widget
                                                            .newsfeedController
                                                            .currentIndexText],
                                                    emojiSelected: () {

                                                      widget.newsfeedController
                                                          .postText = true;
                                                      widget.newsfeedController
                                                          .update();
                                                      setState(() {});
                                                    },
                                                    tabController:
                                                        _tabController)
                                              ])
                                            : Row(children: [
                                                emojiSideBar(),
                                                EmojisList(
                                                    cross: cross,
                                                    textController: _controller[
                                                        widget
                                                            .newsfeedController
                                                            .currentIndexText],
                                                    emojiSelected: () {

                                                      widget.newsfeedController
                                                          .postText = true;
                                                      widget.newsfeedController
                                                          .update();
                                                      setState(() {});
                                                    },
                                                    tabController:
                                                        _tabController)
                                              ])))),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
        ),
      ),
    );
  }

  uploadImages() async{
    var controller = widget.newsfeedController;
    List<_dio.MultipartFile> files = [];
    files = listFiles.map((path) => _dio.MultipartFile.fromFileSync(
      path.path,
      filename: path.name,
    ))
        .toList();

    Map<String, dynamic> userData = {};


    // print("filesx ${files[0].contentType}");
    // print("files ${files[0].filename}");
    // print("files ${files[0].headers}");
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }
    // isMediaUploading = true;
    await controller.multiImageSeleted(userData, 2,listFiles);
  }

  SizedBox emojiSideBar() {
    return SizedBox(
        width: 50,
        child: ListView.builder(
            controller: _scrollController,
            itemCount: emojis.length,
            itemBuilder: (context, index) {
              final x = emojis[index].split(' ');
              return GestureDetector(
                  onTap: () {
                    _selectedTab = index;
                    _tabController.animateTo(index);
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(2),
                      margin: const EdgeInsets.all(2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: _selectedTab == index
                              ? Colors.grey.shade300
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        x[0],
                        // style: const TextStyle(fontSize: 25),

                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(color: Colors.white, fontSize: 25)
                            : TextStyle(color: Colors.black, fontSize: 25),
                      )));
            }));
  }

  bool compareSelectedDatetime(String selectedDatetime) {
    DateTime parseDate =
        new DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDatetime);
    DateTime currentDatetime =
        new DateFormat("yyyy-MM-dd HH:mm:ss").parse(DateTime.now().toString());
    bool isValidDate = parseDate.isAfter(currentDatetime);

    return isValidDate;
  }

  Widget urlFetch() {
    if (widget.newsfeedController.scrapUrl.contains('.com')) {

      return FutureBuilder<ScrappingData>(
        future: widget.newsfeedController
            .urlScraping(widget.newsfeedController.scrapUrl),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            link = snapshot.data.link;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .link = snapshot.data.link;
            linkTitle = snapshot.data.title;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkTitle = snapshot.data.title;
            linkMeta = snapshot.data.meta;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkMeta = snapshot.data.meta;
            if (snapshot.data.images == null || snapshot.data.images.isEmpty) {
              linkImage =
                  "https://www.challengetires.com/assets/img/placeholder.jpg";
            } else {
              linkImage = snapshot.data.images[0];
            }

            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkImage = linkImage;

            return cardScrap(context, snapshot.data);
          } else if (snapshot.hasError) {
            return Container();
          }
          return Container(
            child: Center(
              child: CircularProgressIndicator(
                color: MyColors.BlueColor,
              ),
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }

  bool cardOpen = true;

  Widget cardScrap(BuildContext context, ScrappingData data) {
    // _validURL = true;
    if (data.title != '429 Too Many Requests') {
      return cardOpen
          ? Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: GestureDetector(
                onTap: () {
                  // Get.to(MenuListPage(
                  //   restaurantId: id,
                  // ));
                },
                child: Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(
                      Radius.circular(5.0),
                    ),
                    child: Container(
                      // height: 80,
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 0),
                            child: Container(
                              height: 80,
                              width: 80,
                              decoration: BoxDecoration(
                                  color: Colors.grey,
                                  borderRadius: BorderRadius.circular(0.0),
                                  image: DecorationImage(
                                      image: data.images[0] != null
                                          ? NetworkImage(
                                              data.images[0].toString())
                                          : AssetImage(
                                              "assets/images/person_placeholder.png"),
                                      fit: BoxFit.contain)),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        right: 8.0, top: 8.0),
                                    child: SizedBox(
                                      height: 4,
                                      child: Align(
                                          alignment: Alignment.topRight,
                                          child:
                                              // IconButton(
                                              //   icon: new Icon(Icons.cancel),
                                              //   highlightColor: Color(0xFFedab30),
                                              //   onPressed: (){
                                              //     setState(() {
                                              //     cardOpen = false;
                                              //   });
                                              //     },
                                              // ),
                                              GestureDetector(
                                                  onTap: () {
                                                    setState(() {

                                                      cardOpen = false;
                                                    });
                                                  },
                                                  child: Icon(Icons.cancel))),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8.00),
                                    child: SizedBox(
                                      // height: 20,
                                      child: data.title != null
                                          ? Text(
                                              data.title.toString(),
                                              overflow: TextOverflow.ellipsis,
                                              maxLines: 1,
                                              // style: TextStyle(
                                              //   color: Colors.black,
                                              //   fontFamily: 'Cairo',
                                              //   fontSize: 17,
                                              //   fontWeight: FontWeight.w500,
                                              // )

                                              style: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 17,
                                                      fontFamily: 'Cairo',
                                                      fontWeight:
                                                          FontWeight.w500)
                                                  : TextStyle(
                                                      color: Colors.black,
                                                      fontSize: 17,
                                                      fontFamily: 'Cairo',
                                                      fontWeight:
                                                          FontWeight.w500),
                                            )
                                          : SizedBox(),
                                    ),
                                  ),
                                  // Padding(
                                  //   padding: const EdgeInsets.only(right: 8.00),
                                  //   child: SizedBox(
                                  //     // height: 18,
                                  //     child:
                                  //     data.meta!=null?
                                  //     Text(
                                  //       data.meta.toString(),
                                  //       maxLines: 1,
                                  //       overflow: TextOverflow.ellipsis,
                                  //       // style: TextStyle(
                                  //       //   color: Colors.black,
                                  //       //   fontFamily: 'Cairo',
                                  //       //   fontSize: 16,
                                  //       //   fontWeight: FontWeight.w500,
                                  //       // ),
                                  //
                                  //       style: Theme.of(context).brightness == Brightness.dark ?
                                  //       TextStyle(color: Colors.white,  fontSize: 16,
                                  //           fontFamily: "Cairo",
                                  //           fontWeight: FontWeight.w500)
                                  //           : TextStyle(color: Colors.black,  fontSize: 16,
                                  //           fontFamily: "Cairo",
                                  //           fontWeight: FontWeight.w500),
                                  //
                                  //     ):SizedBox(),
                                  //   ),
                                  // ),
                                  Padding(
                                    padding: const EdgeInsets.only(right: 8.00),
                                    child: SizedBox(
                                      // height: 18,
                                      child: data.link != null
                                          ? Text(
                                              data.link.toString(),
                                              textAlign: TextAlign.left,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              // style: TextStyle(
                                              //   color: Colors.grey[700],
                                              //   fontFamily: 'Cairo',
                                              //   fontSize: 14,
                                              //   fontWeight: FontWeight.w400,
                                              // )

                                              style: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 14,
                                                      fontFamily: "Cairo",
                                                      fontWeight:
                                                          FontWeight.w400)
                                                  : TextStyle(
                                                      color: Colors.grey[700],
                                                      fontSize: 14,
                                                      fontFamily: "Cairo",
                                                      fontWeight:
                                                          FontWeight.w400),
                                            )
                                          : SizedBox(),
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          : SizedBox();
    } else {
      return Container();
    }
  }
}
