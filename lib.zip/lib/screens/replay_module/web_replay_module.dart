import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart' as _dio;
import 'package:dotted_border/dotted_border.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dropzone/flutter_dropzone.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/create_post_model/create_post_model.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_PostWeb.dart' as CPW;
import 'package:image/image.dart' as IMG;
import 'package:werfieapp/widgets/web_createpostModule/create_post_icons.dart';

import '../../components/rounded_button.dart';
import '../../models/FileBytesModel.dart';
import '../../models/map_autocomplete_model/map_auto_complete_model.dart';
import '../../models/post.dart';
import '../../models/scrapping.dart';
import '../../network/controller/google_search_location.dart';
import '../../network/singleTone.dart';
import '../../utils/colors.dart';
import '../../utils/emojis.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../web_views/dialogbox_web.dart';
import '../../web_views/web_guest_user/components/guest_user_post_card.dart';
import '../../widgets/blue_tick.dart';
import '../../widgets/post_image_description.dart';
import '../../widgets/post_text_description.dart';
import '../../widgets/single_comment.dart';
import '../../widgets/web_createpostModule/video_playerchat.dart';
// import '../../widgets/web_createpostModule/create_PostWeb.dart';

class WebReplayModule extends StatefulWidget {
  bool isPostScheduled = false;
  DateTime dateTimeData;
  List postsForDeletions = [];
  bool mentionUser = false;
  bool mentionTag = false;
  Post post;

  final String profileImageUrl;
  List<dynamic> users = [];
  List<dynamic> tags = [];
  final NewsfeedController newsfeedController;
  int replyPageId;
  int getClickId;
  var focusNode = FocusNode();

  WebReplayModule(
      {Key key,
      this.post,
      this.newsfeedController,
      this.profileImageUrl,
      this.replyPageId,
      this.getClickId
      })
      : super(key: key);

  @override
  State<WebReplayModule> createState() => _WebReplayModuleState();
}

class _WebReplayModuleState extends State<WebReplayModule>
    with SingleTickerProviderStateMixin {
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;
  int postId = 0;
  List EditimageThumbnailsList = [];

  ScrollController scrollController = ScrollController();

  bool visibility = false;
  bool threadCreated = false;
  bool closeIcon = false;
  String selectedDateTime;

  var checkFocus = false.obs;
  bool editImageCheck = false;

  /// emojis variable
  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  int _selectedTab = 0;
  StreamSubscription<bool> keyboardSubscription;
  TabController _tabController;
  List<bool> showPolls = [];
  ScrollController _scrollController;

  bool isPortrait = false;
  double width = 0, height = 0;

  List<TextEditingController> _controller =
      List.generate(2, (i) => TextEditingController());

  // List<TextEditingController> _controller = [];

  // var controller = Get.find<NewsfeedController>();

  List<FileBytesModel> listFiles = [];

  bool isTagSelected = false;

  List<FocusNode> fNode1 =
      List<FocusNode>.generate(1, (int index) => FocusNode());
  List<FocusNode> fNode2 =
      List<FocusNode>.generate(1, (int index) => FocusNode());
  FocusNode focusNodeText = FocusNode();
  FocusNode focusNode = FocusNode();

  GoogleSearchLocation locationController = Get.put(GoogleSearchLocation());

  final DummyData dataController = Get.find();
  bool isMediaUploading = false;

  var postTextController = TextEditingController();
  String link, linkTitle, linkMeta, linkImage;
  String scheduleMonthValue = DateTime.now().month.toString();
  String scheduleDayValue = DateTime.now().day.toString();
  String scheduleYearValue = DateTime.now().year.toString();
  String scheduleHourValue = DateTime.now().hour.toString();
  String selectedMonthValue = DateTime.now().month.toString();
  String selectedDayValue = DateTime.now().day.toString();
  String selectedYearValue = DateTime.now().year.toString();
  String selectedHourValue = DateTime.now().hour.toString();

  String scheduleMinutesValue = DateTime.now().minute.toString();
  String selectedMinutesValue = DateTime.now().minute.toString();
  bool monthValidatedSuccessfully = true;
  bool dayValidatedSuccessfully = true;
  bool hourValidatedSuccessfully = true;
  bool minutesValidatedSuccessfully = true;
  bool showScheduledWerfs = false;
  bool isEditable = false;
  bool isCheckBoxSelected = false;

  bool isMediaAttached = false;

  bool isImageAttached = false;

  File videoPicker;
  File pickedMedia;
  Uint8List pickedAudio;
  PickedFile pickedMediaFile;
  Uint8List imageBytes, videoBytes, pdfBytes;
  List<String> _pdfFilesName = [];
  Map<String, dynamic> _pdfs;
  PickedFile singleVideoFile;
  List<File> videoFiles = [];
  List<Uint8List> _pickedVideos = [];
  List<String> _pickedVideosName = [];
  List<String> _pickedVideosMemeType = [];

  List<Uint8List> _pickedAudios = [];

  // ignore: unused_field
  bool _validURL = false;

  // bool showPolls = false;
  int option = 2;
  bool onHover = false;
  bool isOptionThree = false;
  bool isOptionTwo = true;
  List<int> days = [0, 1, 2, 3, 4, 5, 6, 7];
  String pollDays = '0';
  String pollHours = '0';
  String pollMinutes = '0';
  String pollQuestionOne, pollQuestionTwo, pollQuestionThree, pollQuestionFour;
  String txtOption1 = '';
  String txtOption2 = '';
  String txtOption3 = '';
  String txtOption4 = '';
  bool apiCalled = false;
  String videoThumbnail = '';
  String imageThumbnail = '';
  String pdfName = '';
  String audioUrl = '';
  List imageThumbnailsList = [];
  String temp = '';
  String tempValue = '';
  String selectedHashTag = '';
  String tempUsername = '';
  final ScrollController scrollControllerBehaviour = ScrollController();
  List<int> years = [2022, 2023, 2024];
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List<int> minutes = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59
  ];
  List<PlatformFile> _paths;
  List<Uint8List> _pickedImage = [];
  List<Uint8List> _pickedPdfs = [];
  bool _loadingPath = false;
  final bool _multiPick = true;

  DropzoneViewController dropzoneViewController;

  int counter = 0;

  bool dragValue = false;

  bool selectedALL = false;

  @override
  void initState() {
    // widget.newsfeedController.imageCounter=0;
    // widget.newsfeedController.descriptionCounter = 0;
    // if(widget.newsfeedController.imageDescriptionController.length>0){
    //
    //   widget. newsfeedController.imageDescriptionController.forEach((element) {
    //     element.clear();
    //   });
    // }

    widget.newsfeedController.usersList = [];
    // for (int i = 0; i < 30; i++) _controller.add(TextEditingController());
    bool b = false;
    for (int i = 0; i < 2; i++) {
      showPolls.add(b);
    }
    widget.dateTimeData = DateTime.now();
    _tabController = TabController(vsync: this, length: emojis.length);
    _scrollController = ScrollController();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible && isEmojiVisible) {
        isEmojiVisible = false;
        if (this.mounted) {
          // check whether the state object is in tree
          setState(() {
            // make changes here
          });
        }
      } else {}
    });

    {
      widget.newsfeedController.replayModelList = [];
      widget.newsfeedController.replayModelList.add(ModelClass.fromJson({
        'body': '',
        'poll_ques_first': null,
        'poll_ques_first': null,
        'poll_ques_third': null,
        'poll_ques_fourth': null,
        //  selectType: "Public",
        'files': [],
        'link_meta': '',
        'link': '',
        'link_image': '',
        'link_title': '',
        'days': '',
        'minutes': '',
        'hours': '',
        'location': '',
        'lat': '',
        'lng': '',
        'poll_thread': false,
        'type': 'comment',
        'reply_id': widget.post.postId
      }));
      // print("hello");
      widget.newsfeedController.postText = false;
      //   isEditCheckForImage = -1;
      //  isEdit = false;
      // print("isCheckEdit: $isEditCheckForImage");
    }

    super.initState();
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        // print("hello");

        // print(checkFocus);

        checkFocus.value = true;

        widget.newsfeedController.postText = true;
        widget.newsfeedController.update();

        // print(checkFocus);
      } else {
        checkFocus.value = false;
        // print(checkFocus);
      }
    });

    selectedDateTime = DateTime.now().toString();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _controller[widget.newsfeedController.currentIndexText].addListener(() {
      if (_controller[widget.newsfeedController.currentIndexText]
          .text
          .isNotEmpty) {
        widget.newsfeedController.postText = true;
        widget.newsfeedController.update();
        // print(widget.newsfeedController.currentIndexText);
        // print(
        //     "TEXT EDIT CONTROLLLER on INITSTATE :${_controller[widget.newsfeedController.currentIndexText].text}");
        widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .bodyText =
            _controller[widget.newsfeedController.currentIndexText].text;
      } else {
        widget.newsfeedController.postText = false;
        widget.newsfeedController.update();
      }
    });
    widget.newsfeedController.peopleList = widget.newsfeedController.peopleList;

    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    isPortrait = height > width ? true : false;
    _tabController.addListener(() {
      _selectedTab = _tabController.index;
      if (!isPortrait) {
        _scrollController.jumpTo(_selectedTab * height * .075);
      }
      if (this.mounted) {
        // check whether the state object is in tree
        setState(() {
          // make changes here
        });
      }
      // setState(() {});
    });
  }

  acceptFile(dynamic event) async {
    if (dragValue == true) {
      dragValue = false;
      setState(() {});
    }

    // listFiles = [];
    widget.newsfeedController.mediaApiCheck = true;

    // print(event);

    final bytes = await dropzoneViewController.getFileData(event);
    final mime = await dropzoneViewController.getFileMIME(event);
    final name = await dropzoneViewController.getFilename(event);

    var fileType = mime.split('/');
    // print('file type ${fileType[0]}');

    List<_dio.MultipartFile> files = [];
    // List<FileBytesModel> listFiles =[];

    if (fileType[0] == "image"
      /*  &&
        widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .isMediaAttached ==
            false*/
    ) {
      files.add(_dio.MultipartFile.fromBytes(bytes, filename: name));
      listFiles.add(FileBytesModel(bytes, name));
      // print('file type ${mime}');
      // counter++;
      // print(counter);
      // print(
      //     "image sdfsdfsdf ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].mediaData2.length}");

      // print(files);
      dragGetImage(files,listFiles);
    } else if (fileType[0] == "video" &&
       /* widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .mediaData2
                .length ==
            0 &&
        widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .isImageAttached ==
            false &&*/
        isMediaUploading == false) {
      if (kIsWeb) {
        final path = await dropzoneViewController.createFileUrl(event);
        widget.newsfeedController.videoController = VideoPlayerChat(videoUrl: path);
      }
      // print("video pr aya hai");
      // print('file type ${fileType[0]}');
      dragGetVideo(bytes,mime,name);
    } else if (widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .mediaData2
                .length ==
            0 &&
        widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .isImageAttached ==
            false &&
        isMediaUploading == false) {
      // print(
      //     "bbbbb  ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].mediaData2.length}");

      _pdfs = {'fileBytes': bytes, 'pdfFileName': name, 'pdfFileExt': mime};
      dragGetFile(_pdfs);
    } else {
      widget.newsfeedController.update();

      UtilsMethods.toastMessageShow(
        widget.newsfeedController.displayColor,
        widget.newsfeedController.displayColor,
        widget.newsfeedController.displayColor,
        message:
            Strings.pleaseChooseEither1VideoOr1Pdf,
      );
    }
  }

  dragGetImage(List<_dio.MultipartFile> files,List<FileBytesModel> listFiles) async {
    // listFiles = [];

    widget
        .newsfeedController
        .replayModelList[widget.newsfeedController.currentIndexText]
        .isImageAttached = true;

    setState(() => _loadingPath = true);

    if (!mounted) return;
    setState(() {
      _loadingPath = false;
    });

    // files = listFiles.map((path) => _dio.MultipartFile.fromBytes(path.bytes, filename: path.name,))
    //     .toList();
/*    if (kDebugMode) {
      // print(files.length);
    }
    Map<String, dynamic> userData = {};
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }*/
    // setState(() {
    //
    // });

    // isMediaUploading = true;
    // await widget.newsfeedController.multiImageSeleted(userData, 2,null,listBytes: listFiles);

    widget.newsfeedController.postText = true;

    widget.newsfeedController.update();

    widget.newsfeedController.mediaApiCheck = false;
    // print('image from api url:${imageThumbnail}');
    // imageThumbnailsList.add(imageThumbnail);
    // print(imageThumbnailsList);
    // print('I D H A R A J A T A H A I');
    // isMediaAttached = true;
    visibility = true;
    // isMediaUploading = false;
    setState(() {});
  }

  dragGetVideo(var videoBytes,String memeType,String name) async {
    widget.newsfeedController.postText = true;
    widget.newsfeedController.update();

    if (videoBytes != null) {
      _pickedVideos.add(videoBytes);
      _pickedVideosName.add(name);
      _pickedVideosMemeType.add(memeType);
      isMediaUploading = true;
      setState(() {});
      // videoThumbnail = await Get.find<NewsfeedController>().uploadMedia(_pickedVideos[0], 2,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
      widget.newsfeedController.mediaApiCheck = false;

      // if (videoThumbnail != null) {
        // print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          widget
              .newsfeedController
              .replayModelList[widget.newsfeedController.currentIndexText]
              .isMediaAttached = true;
          isMediaUploading = false;
        });
      // } else {
      //   // print('IN ELSE BLOCK');
      // }
    }
  }

  dragGetFile(Map<String, dynamic> _pdfs) async {
    // _pdfs = await dataController.getFile();

    widget.newsfeedController.postText = true;
    widget.newsfeedController.update();

    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (!ext.contains('pdf')) {
        UtilsMethods.toastMessageShow(
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          message: Strings.fileTypeIsNotAllowed,
        );
      } else {
        isMediaUploading = true;
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        setState(() {});
        pdfName = await Get.find<NewsfeedController>().uploadMedia(
            _pickedPdfs[0], 2,
            type: 'file', fileName: _pdfFilesName[0],fileType: 'pdf');
        widget.newsfeedController.mediaApiCheck = false;

        widget
            .newsfeedController
            .replayModelList[widget.newsfeedController.currentIndexText]
            .isMediaAttached = true;
        // print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;

        setState(() {});
      }
    }
  }

  callGetImage() async {
    // isImageAttached = true;

    // listFiles = [];

    if (widget.newsfeedController.imagePickCount >= 4) {
      Fluttertoast.showToast(
          msg:
         Strings.pleaseChooseEither1VideoOr1Pdf,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 5,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
          webPosition: "center",
          fontSize: kIsWeb ? 18 : 16.0);
      return;
    }

    setState(() => _loadingPath = true);
    try {
      _paths = (await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'webp'],
        allowMultiple: _multiPick,
      ))
          ?.files;
      if (_paths == null || _paths.isEmpty) {
        setState(() => _loadingPath = false);

        return;
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        // print("Unsupported operation" + e.toString());
        setState(() => _loadingPath = false);

      }
    } catch (error) {
      if (kDebugMode) {
        // print(error);
      }
      setState(() => _loadingPath = false);
    }
    if (!mounted) return;
    setState(() {
      _loadingPath = false;

      for (var path in _paths) {
        if (listFiles.length < 4) {
          listFiles.add(FileBytesModel(path.bytes, path.name));
        } else {
          Fluttertoast.showToast(
              msg:
              Strings.pleaseChooseEither1VideoOr1Pdf,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 5,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
              webPosition: "center",
              fontSize: kIsWeb ? 18 : 16.0);
          break;
        }
      }
      if (kDebugMode) {
        // print(_paths.first.extension);
        // print(_paths.first.size);
      }
/*      if (_paths.first.size > 1999999) {
        // print("File size must not exceed 2 MB");
      } else {
        listFiles.addAll(_paths);
        // print(listFiles.length.toString() + "images length");
      }*/

    });

/*    List<_dio.MultipartFile> files = [];
    files = listFiles
        .map((path) => _dio.MultipartFile.fromBytes(
              path.bytes,
              filename: path.name,
            ))
        .toList();
    if (kDebugMode) {
      // print(files.length);
    }
    Map<String, dynamic> userData = {};
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }*/
    // setState(() {
    //
    // });

    // isMediaUploading = true;
    // await widget.newsfeedController.multiImageSeleted(userData, 2,listFiles);
    widget.newsfeedController.imagePickCount = widget.newsfeedController.imagePickCount + listFiles.length;
    widget.newsfeedController.postText = true;
    widget
        .newsfeedController
        .replayModelList[widget.newsfeedController.currentIndexText]
        .isImageAttached = true;
    widget.newsfeedController.update();

    widget.newsfeedController.mediaApiCheck = false;
    // print('image from api url:${imageThumbnail}');
    imageThumbnailsList.add(imageThumbnail);
    // print(imageThumbnailsList);
    // print('I D H A R A J A T A H A I');
    // isMediaAttached = true;
    visibility = true;
    // isMediaUploading = false;
    setState(() {});

  }

  callGetVideo() async {
    // File pickedMedia;
    Map<String,dynamic> map = await dataController.getVideo();
    videoBytes = await map['bytes'];

    widget.newsfeedController.postText = true;

    widget.newsfeedController.update();
    // _pickedVideo = pickedMedia.path;
    // print(videoBytes.toString());
    // _pickedImage.add(videoBytes);
    // _pickedVideos.add(videoBytes);
    // print(_pickedImage);
    if (videoBytes != null) {
      _pickedVideos.add(videoBytes);
      _pickedVideosName.add(map['name']);
      _pickedVideosMemeType.add(map['memeType']);

      isMediaUploading = true;

      setState(() {});
      // videoThumbnail = await Get.find<NewsfeedController>().uploadMedia(_pickedVideos[0], 2,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
      widget.newsfeedController.mediaApiCheck = false;

      // if (videoThumbnail != null) {
        // print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          widget
              .newsfeedController
              .replayModelList[widget.newsfeedController.currentIndexText]
              .isMediaAttached = true;
          // isMediaAttached = true;
          isMediaUploading = false;
        });
      // } else {
      //   // print('IN ELSE BLOCK');
      // }
    }
  }

  callGetFile() async {
    _pdfs = await dataController.getFile();

    widget.newsfeedController.postText = true;
    widget.newsfeedController.update();
    // pickedMedia = await dataController.getImageWeb();
    // _pickedPdfs.add(_pdfs['fileBytes']);
    // _pdfFilesName.add(_pdfs['pdfFileName']);
    // print('NAHI ATA IDHAR');
    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (ext!='pdf') {
        UtilsMethods.toastMessageShow(
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          widget.newsfeedController.displayColor,
          message: Strings.fileTypeIsNotAllowed,
        );
      } else {
        isMediaUploading = true;
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        setState(() {});
        pdfName = await Get.find<NewsfeedController>().uploadMedia(
            _pickedPdfs[0], 2,
            type: 'file', fileName: _pdfFilesName[0],fileType: 'pdf');
        widget.newsfeedController.mediaApiCheck = false;

        widget
            .newsfeedController
            .replayModelList[widget.newsfeedController.currentIndexText]
            .isMediaAttached = true;
        //isMediaAttached = true;
        // print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;

        setState(() {});
      }
    }
  }

  callGetAudio() async {
    pickedAudio = await dataController.getAudio();
    // print(pickedAudio.path);

    if (pickedAudio != null) {
      isMediaUploading = true;

      _pickedAudios.add(pickedAudio);
      setState(() {});
      audioUrl =
          await Get.find<NewsfeedController>().uploadMedia(_pickedAudios[0], 2,fileType: 'mp3');

      // isMediaAttached = true;
      isMediaUploading = false;

      setState(() {});
    } else {
      // print('NANANANANA');
    }
  }

  buildPollOptions({
    @required int optionNumber,

    //  @required int indexOf
  }) {
    if (optionNumber == 1 || optionNumber == 4) {
      return Padding(
        padding: EdgeInsets.only(top: 6.0, bottom: 6.0, right: 34, left: 10),
        child: TextFormField(
          onChanged: (value) {
            if (optionNumber == 1) {
              //  txtOption1[controller.currentIndexText]=value;
              widget
                  .newsfeedController
                  .replayModelList[widget.newsfeedController.currentIndexText]
                  .poll_ques_first = value;
              //  print('value pool ${txtOption1[controller.currentIndexText]}');
              // print(
              //     'model values in pool 1: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_first}');
            } else {
              //  txtOption4[controller.currentIndexText]=value;
              widget
                  .newsfeedController
                  .replayModelList[widget.newsfeedController.currentIndexText]
                  .poll_ques_fourth = value;
              // print('value pool ${txtOption4[controller.currentIndexText]}');
              // print(
              //     'model values in pool 4: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_fourth}');
            }
          },
          // controller: optionNumber == 1 ? txtOption1 : txtOption4,
          inputFormatters: [
            LengthLimitingTextInputFormatter(25),
          ],
          style: Styles.baseTextTheme.headline4.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontSize: 14,
          ),
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            labelText: '${Strings.choice} $optionNumber',
            labelStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            hintText: optionNumber == 4
                ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                : '${Strings.choice} $optionNumber',
            hintStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: const BorderRadius.all(
                const Radius.circular(0.0),
              ),
              borderSide: BorderSide(
                width: 1,
                style: BorderStyle.none,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.grey,
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(
          top: 8.0,
          bottom: 8.0,
          left: 10,
          right: optionNumber == 2 && !isOptionTwo
              ? 34
              : option == 3 || option == 2 && isOptionTwo
                  ? 10
                  : option == 3 && !isOptionTwo
                      ? 34
                      : 34),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              onChanged: (value) {
                if (optionNumber == 2) {
                  // txtOption2[controller.currentIndexText]=value;
                  widget
                      .newsfeedController
                      .replayModelList[
                          widget.newsfeedController.currentIndexText]
                      .poll_ques_second = value;
                  // print(
                  //     'model values in pool 2: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_second}');
                } else {
                  // txtOption3[controller.currentIndexText]=value;
                  widget
                      .newsfeedController
                      .replayModelList[
                          widget.newsfeedController.currentIndexText]
                      .poll_ques_third = value;
                  // print(
                  //     'model values in pool 3: ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_third}');
                }

                setState(() {});
              },
              // controller: optionNumber == 2 ? txtOption2 : txtOption3,
              inputFormatters: [
                LengthLimitingTextInputFormatter(25),
              ],
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: const BorderRadius.all(
                    const Radius.circular(0.0),
                  ),
                  borderSide: BorderSide(
                    width: 1,
                    style: BorderStyle.none,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.grey,
                  ),
                ),
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                labelText: '${Strings.choice} $optionNumber',
                labelStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
                hintText: optionNumber == 3
                    ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                    : '${Strings.choice} $optionNumber',
                hintStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
              ),
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 14,
              ),
            ),
          ),
          optionNumber == 2 && option == 2 && isOptionTwo
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : SizedBox(),
          !isOptionTwo && option == 3 && optionNumber == 3
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : SizedBox(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cross = (MediaQuery.of(context).size.width * .025).round();
    // print('CHECK BOOLEAN ' + widget.isPostScheduled.toString());
    // print("checkFocus${checkFocus}");
    String getDate;
    getDate = UtilsMethods.getDate(widget.post.postedOn);
    var controller = widget.newsfeedController;
    return SingleChildScrollView(
      child: Container(
        height: 500,
        width: 500,
        child: Container(
          child: Scaffold(
            backgroundColor: Colors.white,
            body: apiCalled
                ? Center(
                    child: Container(
                        height: 300,
                        width: 300,
                        padding:
                            EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                        alignment: Alignment.center,
                        child: SizedBox(
                          height: 40,
                          width: 40,
                          child: CircularProgressIndicator(
                            color: MyColors.BlueColor,
                            // value: 40,
                          ),
                        )),
                  )
                : CustomScrollView(
                    slivers: [
                      SliverToBoxAdapter(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            ///close icon
                            Align(
                              alignment: Alignment.topLeft,
                              child: MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.pop(context);
                                  },
                                  child: Icon(
                                    Icons.close,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    size: 25,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: CircleAvatar(
                                    backgroundImage: widget.post.profileImage !=
                                            null
                                        ? NetworkImage(widget.post.profileImage)
                                        : AssetImage(
                                            "assets/images/person_placeholder.png"),
                                    radius: 22,
                                  ),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      child: Text(
                                        "${widget.post.authorName}",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                                    widget.post.userInfo.accountVerified ==
                                            "verified"
                                        ? Padding(
                                            padding: const EdgeInsets.only(
                                                left: 2.0),
                                            child: BlueTick(
                                              height: 15,
                                              width: 15,
                                              iconSize: 10,
                                            ),
                                          )
                                        : SizedBox(),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      widget.newsfeedController.languageData
                                                  .appLang.id ==
                                              2
                                          ? '${widget.post.username}@'
                                          : '@${widget.post.username}',
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(fontSize: 14),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          bottom: 10, left: 2, right: 2),
                                      child: Text(
                                        ".",
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '${getDate == null ? '' : getDate}',
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(fontSize: 15),
                                    ),
                                  ],
                                )
                              ],
                            ),
                            Row(
                              children: [
                                const IntrinsicHeight(
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 10),
                                    child: Align(
                                      alignment: Alignment.topLeft,
                                      child: SizedBox(
                                        height: 50,
                                        child: VerticalDivider(
                                          color: Colors.grey,
                                          thickness: 2,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 30),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      GetBuilder<NewsfeedController>(
                                          id: 'translate',
                                          // global :false,

                                          builder: (_) {
                                            bool momentScreen = false;
                                            bool showMomentScreen = false;
                                            bool editMomentScreen = false;
                                            bool userProfileCheck = false;
                                            return PostTextDescription(

                                              post: widget.post,
                                              controller: widget.newsfeedController,
                                              showMomentScreen: showMomentScreen,
                                              editMomentScreen: editMomentScreen,
                                              translationCheck: widget.post.translation.value,
                                              translationData: widget.post.translationData,
                                              width: /*MediaQuery.of(context).size.width >= 720
                                                  ? editMomentScreen == true || showMomentScreen == true
                                                      ? 260
                                                      : momentScreen == true && SingleTone.instance.momentId == null ||
                                                              momentScreen == true && SingleTone.instance.momentId != null
                                                          ? 420
                                                          : 500
                                                  // : */420,
                                              commentId: null,

                                            );
                                          }),
                                      kIsWeb
                                          ? widget.post.body.isNotEmpty
                                              ? Obx(() {
                                                  return widget.post.translationLoadere.value == true
                                                      ? SizedBox(height: 20, width: 20, child: CircularProgressIndicator())
                                                      : widget.newsfeedController.languageData != null
                                                          ? widget.newsfeedController.languageData.myLang.id != widget.post.languageId
                                                              ? GestureDetector(
                                                                  onTap: () async {
                                                                    print("View translated hit");
                                                                    widget.post.translationLoadere.value = true;
                                                                    bool success = false;

                                                                    print("controller.languageData.myLang.id ${controller.languageData.myLang.code}");
                                                                    widget.post.translationData = await controller.newsFeedTranslation(
                                                                        widget.post.postId, controller.languageData.myLang.code);

                                                                    print("post.translationData ${widget.post.translationData.data[0].body}");

                                                                    if (widget.post.translationData != null) {
                                                                      widget.post.translationLoadere.value = false;

                                                                      if (widget.post.translation.value == false) {
                                                                        print("controller.translationData.data[0].body ${controller.translationData.data[0].body}");
                                                                        widget.post.translation.value = true;
                                                                        controller.update(['translate']);
                                                                      } else if (widget.post.translation.value == true) {
                                                                        widget.post.translation.value = false;
                                                                        controller.update(['translate']);
                                                                      }
                                                                    } else {
                                                                      widget.post.translationLoadere.value = false;
                                                                      controller.update();
                                                                    }
                                                                  },
                                                                  child: widget.post.translation.value == true
                                                                      ? Padding(
                                                                          padding: EdgeInsets.only(bottom: 10),
                                                                          child: Text("View Original",
                                                                              style: TextStyle(
                                                                                  decoration: TextDecoration.underline,
                                                                                  color: controller.displayColor)),
                                                                        )
                                                                      : Padding(
                                                                          padding: EdgeInsets.only(bottom: 10, top: 5),
                                                                          child:
                                                                          /*containHashTag
                                                                              ? SizedBox()
                                                                              : */Text(
                                                                                  /*controller.languageData.appLang.id == 2
                                                                                      ? "عرض الترجمة"
                                                                                      : */Strings.viewTranslated,
                                                                                  style: TextStyle(
                                                                                      decoration: TextDecoration.underline,
                                                                                      color: controller.displayColor)),
                                                                        ),
                                                                )
                                                              : SizedBox()
                                                          : SizedBox();
                                                })
                                              : SizedBox()
                                          : SizedBox(),
                                      // widget.post != null
                                      //     ? SizedBox(
                                      //         width: 400,
                                      //         child:
                                      //             Text(
                                      //                 '${widget.post.body}',
                                      //               style: TextStyle(
                                      //                 color:Theme.of(context).brightness == Brightness.dark?Colors.white:Colors.black
                                      //               ),
                                      //             )
                                      // )
                                      //     : Text(''),
                                      SizedBox(height: 5,),
                                      Align(
                                        alignment: Alignment.topLeft,
                                        child: RichText(
                                          text: TextSpan(
                                            text: Strings.replyToComment,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey),
                                            children: <TextSpan>[
                                              TextSpan(
                                                  text:
                                                      ' @${widget.post.username}',
                                                  style: TextStyle(
                                                      fontSize: 12,
                                                      color: Colors.blue)),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),

                            /// replay  module list

                            Column(
                              children: [
                                widget.newsfeedController.mediaApiCheck ==
                                        true
                                    ? Center(
                                        child: Container(
                                            height: 300,
                                            width: 300,
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 5, vertical: 5),
                                            alignment: Alignment.center,
                                            child: SizedBox(
                                              height: 40,
                                              width: 40,
                                              child:
                                                  CircularProgressIndicator(
                                                color: MyColors.BlueColor,
                                                // value: 40,
                                              ),
                                            )),
                                      )
                                    : Stack(
                                        children: [
                                          Container(
                                            height: 280,
                                            width: 500,
                                            padding: EdgeInsets.only(
                                                top: 10, bottom: 10),
                                            child: DottedBorder(
                                              color: dragValue == true
                                                  ? Colors.blue
                                                  : Colors.transparent,
                                              dashPattern: [8, 4],
                                              radius: Radius.circular(5),
                                              strokeWidth: 1,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(
                                                        8.0),
                                                child: Column(
                                                  children: [
                                                    Expanded(
                                                      child: kIsWeb
                                                          ? DropzoneView(
                                                              operation:
                                                                  DragOperation
                                                                      .copy,
                                                              cursor:
                                                                  CursorType
                                                                      .grab,
                                                              onHover: () {
                                                                // print(widget
                                                                //     .newsfeedController
                                                                //     .currentIndexText);

                                                                // print(
                                                                //     "asdasd");

                                                                if (dragValue ==
                                                                    false) {
                                                                  dragValue =
                                                                      true;
                                                                  setState(
                                                                      () {});
                                                                }
                                                              },
                                                              onLeave: () {
                                                                if (dragValue ==
                                                                    true) {
                                                                  dragValue =
                                                                      false;
                                                                  setState(
                                                                      () {});
                                                                }
                                                              },
                                                              onLoaded: () => print(" "),
                                                              onError: (err) =>
                                                                  print(
                                                                      ''),
                                                              // onDropMultiple: acceptFile ,
                                                              onDrop:
                                                                  acceptFile,
                                                              // onDropMultiple:acceptMultipleFile ,
                                                              onCreated: (controller) =>
                                                                  this.dropzoneViewController =
                                                                      controller,
                                                            )
                                                          : Container(),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          ConstrainedBox(
                                            constraints: BoxConstraints(
                                              minWidth: 500,
                                              minHeight: 200,
                                              maxWidth: 500,
                                              maxHeight: 280,
                                            ),
                                            child: ListView.builder(
                                              shrinkWrap: true,
                                              itemCount: widget
                                                  .newsfeedController
                                                  .replayModelList
                                                  .length,
                                              itemBuilder: (context, ind) {

                                                return InkWell(
                                                  focusColor:
                                                      Colors.transparent,
                                                  onTap: () {},
                                                  onHover: (value) {
                                                    widget
                                                        .newsfeedController
                                                        .currentIndexText = ind;


                                                    setState(() {});
                                                    widget
                                                        .newsfeedController
                                                        .update();
                                                  },
                                                  child: Container(
                                                    // margin: EdgeInsets.all(5),
                                                    color: Colors.white,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        widget
                                                            .newsfeedController
                                                            .currentIndexText = ind;
                                                        setState(() {});
                                                      },
                                                      child: Column(
                                                        children: [
                                                          ///  scdeudle  widget
                                                          widget.isPostScheduled
                                                              ? ListTile(
                                                                  minVerticalPadding:
                                                                      0.0,
                                                                  horizontalTitleGap:
                                                                      0.0,
                                                                  leading:
                                                                      Container(
                                                                    width:
                                                                        20,
                                                                    height:
                                                                        20,
                                                                    child: SvgPicture
                                                                        .asset(
                                                                      // _pickedPdfs.length > 0 ||
                                                                      //     _pickedAudios.length > 0 ||
                                                                      //     _pickedVideos.length > 0
                                                                      //     ?
                                                                      'assets/post_icons/calendar.svg',
                                                                      fit: BoxFit
                                                                          .cover,
                                                                      height:
                                                                          200,
                                                                      width:
                                                                          200,
                                                                      color: _pickedVideos.isNotEmpty || widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isMediaAttached || showPolls[widget.newsfeedController.currentIndexText]
                                                                          ? Colors.grey[400]
                                                                          : widget.newsfeedController.displayColor,
                                                                      // : Colors.purple,
                                                                    ),
                                                                  ),
                                                                  title:
                                                                      Text(
                                                                    '${Strings.thisPostIsScheduledFor} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                    // 'This post is scheduled for ${DateFormat.yMMMMd().add_jm().format(widget.dateTimeData)}',
                                                                  ),
                                                                  subtitle:
                                                                      GestureDetector(
                                                                    onTap:
                                                                        () {
                                                                      widget.isPostScheduled =
                                                                          false;
                                                                      setState(
                                                                          () {});
                                                                    },
                                                                    child:
                                                                        Text(
                                                                      Strings.clear,
                                                                      style:
                                                                          TextStyle(
                                                                        decoration:
                                                                            TextDecoration.underline,
                                                                      ),

                                                                      // style: Theme.of(context).brightness == Brightness.dark ?
                                                                      // TextStyle(color: Colors.white, decoration: TextDecoration.underline)
                                                                      //     : TextStyle(color: Colors.black, decoration: TextDecoration.underline),
                                                                    ),
                                                                  ),
                                                                )
                                                              : SizedBox(),

                                                          ///

                                                          ///
                                                          /// text  field
                                                          ListTile(
                                                            contentPadding:
                                                                EdgeInsets.only(
                                                                    left:
                                                                        6),
                                                            trailing:
                                                                SizedBox(),
                                                            leading: widget
                                                                        .newsfeedController
                                                                        .userProfile ==
                                                                    null
                                                                ? Container(
                                                                    width:
                                                                        24,
                                                                    child:
                                                                        Center(
                                                                      child:
                                                                          SpinKitCircle(
                                                                        color:
                                                                            Colors.grey,
                                                                        size:
                                                                            40,
                                                                      ),
                                                                    ))
                                                                : widget.newsfeedController.userProfile.profileImage ==
                                                                        null
                                                                    ? CircleAvatar(
                                                                        radius:
                                                                            22,
                                                                        backgroundImage:
                                                                            AssetImage("assets/images/person_placeholder.png"))
                                                                    : ClipRRect(
                                                                        borderRadius:
                                                                            BorderRadius.circular(30),
                                                                        child: FadeInImage(
                                                                            fit: BoxFit.cover,
                                                                            width: 40,
                                                                            height: 40,
                                                                            placeholder: AssetImage('assets/images/person_placeholder.png'),
                                                                            image: NetworkImage(widget.newsfeedController.userProfile.profileImage != null ? widget.newsfeedController.userProfile.profileImage : "assets/images/person_placeholder.png")),
                                                                      ),
                                                            title:
                                                                GestureDetector(
                                                              onTap: () {
                                                                widget
                                                                    .newsfeedController
                                                                    .currentIndexText = ind;
                                                                print(
                                                                    "check media length  ${widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].mediaData2.length}");
                                                                setState(
                                                                    () {});
                                                                widget
                                                                    .newsfeedController
                                                                    .replayModelList[widget
                                                                        .newsfeedController
                                                                        .currentIndexText]
                                                                    .isMediaAttached = false;
                                                              },
                                                                  child: HashTagTextField(
                                                                autofocus: true,
                                                                onChanged: (value) {
                                                                  if (value.contains("#") && value.contains("@")) {
                                                                    setState(() {
                                                                      widget.mentionUser = false;
                                                                      widget.mentionTag = false;
                                                                    });
                                                                  }

                                                                  widget.newsfeedController.currentIndexText = ind;
                                                                  setState(() {});

                                                                  print(_controller[ind].text);

                                                                  widget.newsfeedController.replayModelList[ind].bodyText =
                                                                      _controller[ind].text;

                                                                  if (value.length > 0 && _controller[ind].text.trim().isNotEmpty) {
                                                                    setState(() {
                                                                      widget.newsfeedController.postText = true;
                                                                      if (widget.isPostScheduled) {
                                                                        visibility = false;
                                                                      } else {
                                                                        visibility = true;
                                                                      }
                                                                      closeIcon = false;
                                                                    });
                                                                  } else {
                                                                    setState(() {
                                                                      widget.newsfeedController.postText = false;
                                                                      visibility = false;
                                                                      closeIcon = true;
                                                                    });
                                                                  }
                                                                  if (value.length < 2) {
                                                                    /// user tag and mention tag
                                                                    widget.mentionUser = false;
                                                                    widget.mentionTag = false;
                                                                    temp = '';
                                                                    tempUsername = '';
                                                                    widget.tags.clear();

                                                                    /// end
                                                                    visibility = true;
                                                                    setState(() {});
                                                                  }
                                                                  if (isEmojiVisible) {
                                                                    // widget.controller.focusNode.requestFocus();
                                                                    isEmojiVisible = !isEmojiVisible;
                                                                  }
                                                                },

                                                                /// Called when detection (word starts with #, or # and @) is being typed
                                                                onDetectionTyped: (text) async {
                                                                  if (!text.contains("#") || !text.contains("@")) {
                                                                    setState(() {
                                                                      widget.mentionUser = false;
                                                                      widget.mentionTag = false;
                                                                    });
                                                                  }

                                                                  if (text.contains("#")) {
                                                                    tempValue = text;

                                                                    print('start with #');
                                                                    widget.mentionUser = false;
                                                                    widget.tags =
                                                                        await widget.newsfeedController.searchTags(tempValue.substring(1));
                                                                    if (widget.tags.length <= 0) {
                                                                      widget.tags.clear();
                                                                      widget.mentionTag = false;
                                                                      //  temp='';
                                                                      setState(() {});
                                                                    } else {
                                                                      widget.mentionUser = false;
                                                                      widget.mentionTag = true;

                                                                      setState(() {});
                                                                    }
                                                                  } else if (text.contains("@")) {
                                                                    tempValue = text;

                                                                    print("start with @" + tempValue.substring(2));
                                                                    widget.mentionTag = false;
                                                                    widget.users = await widget.newsfeedController.searchChatUser(
                                                                      tempValue.substring(1),
                                                                      type: "mention_users",
                                                                    );
                                                                    if (widget.users.length <= 0) {
                                                                      widget.users.clear();
                                                                      widget.mentionUser = false;
                                                                      setState(() {});
                                                                    } else {
                                                                      widget.mentionUser = true;
                                                                      setState(() {});
                                                                    }
                                                                  }
                                                                },

                                                                /// Called when detection is fully typed
                                                                onDetectionFinished: () {
                                                                  print("detection finishedd");
                                                                  // tempValue="";

                                                                  setState(() {
                                                                    widget.mentionUser = false;
                                                                    widget.mentionTag = false;
                                                                  });

/*
                                                                        setState(() {
                                                                          widget.mentionTag=false;
                                                                          widget.mentionUser=false;

                                                                        });*/
                                                                },
                                                                // scrollController: scrollController,
                                                                // focusNode:
                                                                //     focusNodeText,
                                                                decorateAtSign: true,
                                                                focusNode: fNode2[ind],
                                                                // autofocus: true,
                                                                onTap: () {
                                                                  widget.newsfeedController.currentIndexText = ind;
                                                                  setState(() {});
                                                                },
                                                                basicStyle: LightStyles.baseTextTheme.headline2.copyWith(
                                                                  color: Theme.of(context).brightness == Brightness.dark
                                                                      ? Colors.white
                                                                      : Colors.black,
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 20,
                                                                ),
                                                                cursorColor: Theme.of(context).brightness == Brightness.dark
                                                                    ? Colors.white
                                                                    : Colors.black,
                                                                maxLength: 800,
                                                                maxLines: showPolls[widget.newsfeedController.currentIndexText]
                                                                    ? 3
                                                                    : widget.mentionUser || widget.mentionTag
                                                                        ? null
                                                                        : null,
                                                                keyboardType: TextInputType.multiline,

                                                                maxLengthEnforcement: MaxLengthEnforcement.enforced,
                                                                controller: _controller[
                                                                    ind] /*isEdit == true?postTextController:controller.modelList2[0].textEditingController*/,
                                                                decoratedStyle: LightStyles.baseTextTheme.headline2.copyWith(
                                                                  color: Colors.blue,
                                                                  fontWeight: FontWeight.w500,
                                                                  fontSize: 20,
                                                                ),
                                                                decoration: InputDecoration(
                                                                  counterStyle: const TextStyle(
                                                                    fontSize: 15,
                                                                  ),
                                                                  contentPadding: EdgeInsets.only(top: 16),
                                                                  hintText: showPolls[widget.newsfeedController.currentIndexText]
                                                                      ? Strings.askAQuestion
                                                                      : widget.newsfeedController.languageData.appLang.id == 2
                                                                          ? "ويرف ردك ..."
                                                                          : Strings.werfYourReply,
                                                                  border: InputBorder.none,
                                                                  hintStyle: LightStyles.baseTextTheme.headline3.copyWith(
                                                                    fontSize: 20,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            height: 20,
                                                          ),

                                                          /// mention tag  widget
                                                          !widget.mentionTag
                                                              ? SizedBox()
                                                              : Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .centerLeft,
                                                                  child:
                                                                      Container(
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      border:
                                                                          Border.all(
                                                                        color:
                                                                            Colors.grey[300],
                                                                        width:
                                                                            0.5,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(4),
                                                                    ),
                                                                    height:
                                                                        150,
                                                                    width:
                                                                        300,
                                                                    child: widget.tags.length ==
                                                                            0
                                                                        ? SpinKitWave(
                                                                            size: 30,
                                                                            color: Color(0xFFedab30),
                                                                          )
                                                                        : ListView.builder(
                                                                            itemCount: widget.tags.length,
                                                                            itemBuilder: (context, index) {
                                                                              return ListTile(
                                                                                onTap: () async {
                                                                                  //   temp='';
                                                                                  print("textvalue " + _controller[widget.newsfeedController.currentIndexText].text);
                                                                                  print(tempValue);
                                                                                  print(widget.tags[index]['title']);

                                                                                  /*     _controller[controller.currentIndexText].text =
                                                                      _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                                     ' ' +
                                                                          widget.tags[index]['title'];*/
                                                                                  _controller[widget.newsfeedController.currentIndexText].text = _controller[widget.newsfeedController.currentIndexText].text.substring(0, _controller[widget.newsfeedController.currentIndexText].text.length - tempValue.length);
                                                                                  print("tempvalue" + _controller[widget.newsfeedController.currentIndexText].text);
                                                                                  tempValue = widget.tags[index]['title'] ?? "";
                                                                                  print("tempvalue" + tempValue);

                                                                                  _controller[widget.newsfeedController.currentIndexText].text = _controller[widget.newsfeedController.currentIndexText].text + " " + tempValue + " ";
                                                                                  // tempValue="";
                                                                                  _controller[widget.newsfeedController.currentIndexText].selection = TextSelection.fromPosition(TextPosition(offset: _controller[widget.newsfeedController.currentIndexText].text.length));
                                                                                  widget.tags.clear();
                                                                                  widget.mentionTag = false;
                                                                                  //  widget.tags = [];
                                                                                  tempValue = "";
                                                                                  focusNodeText.requestFocus();

                                                                                  setState(() {});
                                                                                  _controller[widget.newsfeedController.currentIndexText].selection = TextSelection.fromPosition(TextPosition(offset: _controller[widget.newsfeedController.currentIndexText].text.length));

                                                                                  // widget.focusNode
                                                                                  //     .requestFocus();
                                                                                  print('selection tag  ${_controller[widget.newsfeedController.currentIndexText].selection}');
                                                                                  print('value temp${_controller[widget.newsfeedController.currentIndexText].text}');
                                                                                },
                                                                                title: Text(
                                                                                  widget.tags[index]['title'] ?? "",
                                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                    fontWeight: FontWeight.w700,
                                                                                    fontSize: 15,
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }),
                                                                  ),
                                                                ),

                                                          /// mention user  widget
                                                          !widget.mentionUser
                                                              ? SizedBox()
                                                              : Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .centerLeft,
                                                                  child:
                                                                      Container(
                                                                    decoration:
                                                                        BoxDecoration(
                                                                      border:
                                                                          Border.all(
                                                                        color:
                                                                            Colors.grey[300],
                                                                        width:
                                                                            0.5,
                                                                      ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(4),
                                                                    ),
                                                                    height:
                                                                        150,
                                                                    width:
                                                                        300,
                                                                    child: widget.users.length ==
                                                                            0
                                                                        ? SpinKitWave(
                                                                            size: 30,
                                                                            color: Color(0xFFedab30),
                                                                          )
                                                                        : ListView.builder(
                                                                            itemCount: widget.users.length,
                                                                            itemBuilder: (context, index) {
                                                                              return ListTile(
                                                                                onTap: () async {
                                                                                  _controller[widget.newsfeedController.currentIndexText].text = _controller[widget.newsfeedController.currentIndexText].text.substring(0, _controller[widget.newsfeedController.currentIndexText].text.length - tempValue.length);
                                                                                  print("tempvalue" + _controller[widget.newsfeedController.currentIndexText].text);
                                                                                  tempValue = widget.users != null || widget.users.length > 0 ? widget.users[index]['username'] ?? "" : "";
                                                                                  print("tempvalue" + tempValue);

                                                                                  _controller[widget.newsfeedController.currentIndexText].text = _controller[widget.newsfeedController.currentIndexText].text + " " + tempValue + " ";
                                                                                  // tempValue="";
                                                                                  _controller[widget.newsfeedController.currentIndexText].selection = TextSelection.fromPosition(TextPosition(offset: _controller[widget.newsfeedController.currentIndexText].text.length));
                                                                                  widget.users.clear();
                                                                                  widget.mentionUser = false;
                                                                                  //  widget.tags = [];

                                                                                  tempValue = "";
                                                                                  focusNodeText.requestFocus();
                                                                                  setState(() {});
                                                                                  // widget.focusNode
                                                                                  //     .requestFocus();

                                                                                  _controller[widget.newsfeedController.currentIndexText].selection = TextSelection.fromPosition(TextPosition(offset: _controller[widget.newsfeedController.currentIndexText].text.length));
                                                                                },
                                                                                title: Text(
                                                                                  widget.users[index]['username'] ?? "",
                                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                    fontWeight: FontWeight.w700,
                                                                                    fontSize: 15,
                                                                                  ),
                                                                                ),
                                                                              );
                                                                            }),
                                                                  ),
                                                                ),

                                                          /// end mention user

                                                          widget.newsfeedController
                                                                  .postText
                                                              ? widget.newsfeedController.urlOrNot(_controller[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .text)
                                                                  ?
                                                          _controller[widget.newsfeedController.currentIndexText].text[1]!="@"?
                                                          Container(
                                                                      child:
                                                                          urlFetch(),
                                                                    )
                                                                  : Container()
                                                              : Container():Container(),

                                                          ///show pools
                                                          showPolls[ind]
                                                              ? Align(
                                                            alignment:
                                                            Alignment.center,
                                                            child: Container(
                                                              width: 600,
                                                              margin:
                                                              EdgeInsets.only(
                                                                  bottom: 16,
                                                                  top: 16),
                                                              decoration:
                                                              BoxDecoration(
                                                                  borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                      10),
                                                                  border: Border
                                                                      .all(
                                                                    color: Theme.of(context).brightness ==
                                                                        Brightness
                                                                            .dark
                                                                        ? Colors
                                                                        .white
                                                                        : Colors
                                                                        .grey,
                                                                    width: 1,
                                                                  )),
                                                              child: Column(
                                                                children: [
                                                                  SizedBox(
                                                                      height: 10),
                                                                  buildPollOptions(
                                                                    optionNumber: 1,
                                                                    //   indexOf: ind,
                                                                  ),
                                                                  buildPollOptions(
                                                                    optionNumber: 2,
                                                                    // indexOf: ind,
                                                                  ),
                                                                  option == 3 ||
                                                                      option ==
                                                                          4
                                                                      ? buildPollOptions(
                                                                    optionNumber:
                                                                    3,
                                                                    //   indexOf: ind,
                                                                  )
                                                                      : SizedBox(),
                                                                  option == 4
                                                                      ? buildPollOptions(
                                                                    optionNumber:
                                                                    4,
                                                                    // indexOf: ind,
                                                                  )
                                                                      : SizedBox(),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Container(
                                                                    height: 1,
                                                                    color: Theme.of(context)
                                                                        .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                        ? Colors
                                                                        .white
                                                                        : Colors
                                                                        .grey,
                                                                  ),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Padding(
                                                                    padding: EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                        6.0,
                                                                        horizontal:
                                                                        10),
                                                                    child: Align(
                                                                      alignment:
                                                                      Alignment
                                                                          .centerLeft,
                                                                      child: Text(
                                                                        'Poll length',
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize:
                                                                          14,
                                                                          fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Padding(
                                                                    padding: EdgeInsets
                                                                        .symmetric(
                                                                        vertical:
                                                                        6.0,
                                                                        horizontal:
                                                                        10),
                                                                    child: Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .spaceBetween,
                                                                      children: [
                                                                        /// pools days selected button
                                                                        ButtonTheme(
                                                                          materialTapTargetSize:
                                                                          MaterialTapTargetSize
                                                                              .padded,
                                                                          child:
                                                                          Expanded(
                                                                            child: DropdownButtonFormField<
                                                                                String>(
                                                                              icon:
                                                                              Icon(Icons.keyboard_arrow_down),
                                                                              isExpanded:
                                                                              true,
                                                                              decoration:
                                                                              InputDecoration(
                                                                                border:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //width: 1,
                                                                                    //  style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                disabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    // width: 1,
                                                                                    // style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                enabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    // width: 1,
                                                                                    //  style: BorderStyle.none,
                                                                                    color:  widget.newsfeedController.displayColor,
                                                                                  ),
                                                                                ),
                                                                                labelText:
                                                                                'Days',
                                                                                labelStyle:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              value:
                                                                              0.toString(),
                                                                              hint:
                                                                              Text(
                                                                                'Days',
                                                                                style:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              alignment:
                                                                              Alignment.bottomCenter,
                                                                              items:
                                                                              days.map((int value) {
                                                                                return DropdownMenuItem<String>(
                                                                                  value: value.toString(),
                                                                                  child: Text(
                                                                                    value.toString(),
                                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontSize: 14,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }).toList(),
                                                                              onChanged:
                                                                                  (days) {
                                                                                pollDays =
                                                                                    days;
                                                                                widget.newsfeedController
                                                                                  ..replayModelList[ widget.newsfeedController.currentIndexText].days = days;
                                                                                setState(() {});
                                                                              },
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          width: 10,
                                                                        ),

                                                                        /// pools hour selected button
                                                                        ButtonTheme(
                                                                          materialTapTargetSize:
                                                                          MaterialTapTargetSize
                                                                              .padded,
                                                                          child:
                                                                          Expanded(
                                                                            child: DropdownButtonFormField<
                                                                                String>(
                                                                              icon:
                                                                              Icon(Icons.keyboard_arrow_down),
                                                                              isExpanded:
                                                                              true,
                                                                              decoration:
                                                                              InputDecoration(
                                                                                border:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    // width: 1,
                                                                                    // style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                disabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //width: 1,
                                                                                    // style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                enabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //  width: 1,
                                                                                    //  style: BorderStyle.none,
                                                                                    color:  widget.newsfeedController.displayColor,
                                                                                  ),
                                                                                ),
                                                                                labelText:
                                                                                'Hours',
                                                                                labelStyle:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              value:
                                                                              0.toString(),
                                                                              hint:
                                                                              Text(
                                                                                'Hours',
                                                                                style:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              alignment:
                                                                              Alignment.bottomCenter,
                                                                              items: List.generate(
                                                                                  24,
                                                                                      (index) =>
                                                                                  index).map((int
                                                                              value) {
                                                                                return DropdownMenuItem<String>(
                                                                                  value: value.toString(),
                                                                                  child: Text(
                                                                                    value.toString(),
                                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontSize: 14,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }).toList(),
                                                                              onChanged:
                                                                                  (hours) {
                                                                                pollHours =
                                                                                    hours;
                                                                                widget.newsfeedController.replayModelList[ widget.newsfeedController.currentIndexText].hours =
                                                                                    hours;
                                                                                setState(() {});
                                                                              },
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          width: 10,
                                                                        ),

                                                                        /// pools mint selected button
                                                                        ButtonTheme(
                                                                          materialTapTargetSize:
                                                                          MaterialTapTargetSize
                                                                              .padded,
                                                                          child:
                                                                          Expanded(
                                                                            child: DropdownButtonFormField<
                                                                                String>(
                                                                              icon:
                                                                              Icon(Icons.keyboard_arrow_down),
                                                                              isExpanded:
                                                                              true,
                                                                              decoration:
                                                                              InputDecoration(
                                                                                border:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //  width: 1,
                                                                                    // style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                disabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //   width: 1,
                                                                                    //  style: BorderStyle.none,
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                  ),
                                                                                ),
                                                                                enabledBorder:
                                                                                OutlineInputBorder(
                                                                                  borderRadius: BorderRadius.circular(10),
                                                                                  borderSide: BorderSide(
                                                                                    //width: 1,
                                                                                    //  style: BorderStyle.none,
                                                                                    color:  widget.newsfeedController.displayColor,
                                                                                  ),
                                                                                ),
                                                                                labelText:
                                                                                'Minutes',
                                                                                labelStyle:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              value: pollHours == '0' && pollDays == '0'
                                                                                  ? 5.toString()
                                                                                  : 0.toString(),
                                                                              hint:
                                                                              Text(
                                                                                'Minutes',
                                                                                style:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                ),
                                                                              ),
                                                                              alignment:
                                                                              Alignment.bottomCenter,
                                                                              items: pollHours == '0' && pollDays == '0'
                                                                                  ? minutes.map((int value) {
                                                                                return DropdownMenuItem<String>(
                                                                                  value: value.toString(),
                                                                                  child: Text(
                                                                                    value.toString(),
                                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontSize: 14,
                                                                                    ),
                                                                                  ),
                                                                                );
                                                                              }).toList()

                                                                              /// pool mint list generate
                                                                                  : List.generate(60, (index) => index).map((int value) {
                                                                                return DropdownMenuItem<String>(
                                                                                  value: value.toString(),
                                                                                  child: Text(value.toString()),
                                                                                );
                                                                              }).toList(),
                                                                              onChanged:
                                                                                  (minutes) {
                                                                                pollMinutes =
                                                                                    minutes;
                                                                                widget.newsfeedController.replayModelList[ widget.newsfeedController.currentIndexText].minutes =
                                                                                    minutes;
                                                                              },
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Container(
                                                                    height: 1,
                                                                    color: Theme.of(context)
                                                                        .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                        ? Colors
                                                                        .white
                                                                        : Colors
                                                                        .grey,
                                                                  ),

                                                                  /// remove pool button
                                                                  InkWell(
                                                                    hoverColor:
                                                                    Colors.red[
                                                                    100],
                                                                    onTap: () {
                                                                      showPolls[ widget.newsfeedController
                                                                          .currentIndexText] =
                                                                      false;
                                                                      option = 2;
                                                                      isOptionTwo =
                                                                      true;
                                                                      widget.newsfeedController
                                                                          .replayModelList[
                                                                      widget.newsfeedController
                                                                          .currentIndexText]
                                                                          .poolThread = false;

                                                                      setState(
                                                                              () {});
                                                                    },
                                                                    child:
                                                                    Container(
                                                                      alignment:
                                                                      Alignment
                                                                          .center,
                                                                      margin: EdgeInsets
                                                                          .symmetric(
                                                                          vertical:
                                                                          6),
                                                                      width: 600,
                                                                      height: 40,
                                                                      child: Text(
                                                                        'Remove Poll',
                                                                        style: Theme.of(
                                                                            context)
                                                                            .textTheme
                                                                            .headline3
                                                                            .copyWith(
                                                                          fontSize:
                                                                          18,
                                                                          color:
                                                                          Colors.redAccent,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          )
                                                              : SizedBox(),

                                                          /// reply images
                                                    /*      widget.newsfeedController.replayModelList[ind].mediaData2.length >
                                                                      0 &&
                                                                  !widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          ind]
                                                                      .mediaData2[
                                                                          0]
                                                                      .name
                                                                      .contains(
                                                                          '.pdf') &&
                                                                  (widget.newsfeedController.replayModelList[ind].mediaData2[0].thumbnailUrl ==
                                                                          null ||
                                                                      widget
                                                                          .newsfeedController
                                                                          .replayModelList[
                                                                              ind]
                                                                          .mediaData2[
                                                                              0]
                                                                          .thumbnailUrl
                                                                          .isEmpty)*/
                                                          listFiles.length > 0
                                                              ? ConstrainedBox(
                                                                  constraints: BoxConstraints.expand(
                                                                      height:
                                                                          300,
                                                                      width:
                                                                          350),
                                                                  child:
                                                                      Container(
                                                                    height: widget.newsfeedController.replayModelList[ind].mediaData2.length <
                                                                            2
                                                                        ? 300
                                                                        : 350,
                                                                    // width: 180,
                                                                    child: StaggeredGridView.countBuilder(
                                                                        primary: false,
                                                                        shrinkWrap: true,
                                                                        crossAxisSpacing: 0,
                                                                        mainAxisSpacing: 0,
                                                                        itemCount: listFiles.length,
                                                                        crossAxisCount: listFiles.length < 2 ? 1 : 2,
                                                                        itemBuilder: (context, index) {
                                                                       /*   return !widget.newsfeedController.replayModelList[ind].mediaData2.asMap().containsKey(index)
                                                                              ? Container(
                                                                                  height: 100,
                                                                                  alignment: Alignment.center,
                                                                                  child: Column(
                                                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                                                    children: [
                                                                                      CircularProgressIndicator(
                                                                                        color: MyColors.BlueColor,
                                                                                      ),
                                                                                      SizedBox(height: 6),
                                                                                      Text(
                                                                                        'Uploading...',
                                                                                        style: TextStyle(color: MyColors.BlueColor, fontWeight: FontWeight.w700),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                )
                                                                              : */
                                                                          return
                                                                          Container(
                                                                                  // height: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 300,
                                                                                  // width: controller.modelList2[ind].mediaData2.length < 2 ? 350 : 160,
                                                                                  height: 300,
                                                                                  width: 350,
                                                                                  child: Stack(
                                                                                    children: [
                                                                                      Container(
                                                                                        decoration: BoxDecoration(
                                                                                          borderRadius: BorderRadius.circular(15),
                                                                                        ),
                                                                                        // height: controller.modelList2[ind].mediaData2.length < 2 ? 250 : 300,
                                                                                        // width: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 200,
                                                                                        height: 250,
                                                                                        width: 350,
                                                                                        child: ClipRRect(
                                                                                          borderRadius: BorderRadius.circular(15),
                                                                                          child:
                                                                                          Image.memory(
                                                                                            listFiles[index].bytes,
                                                                                            fit: BoxFit.cover,
                                                                                          )
                                                                                          /*Image.network(
                                                                                            widget.newsfeedController.replayModelList[ind].mediaData2[index].url,
                                                                                            fit: BoxFit.cover,
                                                                                          ),*/
                                                                                        ),
                                                                                      ),
                                                                                      Positioned(
                                                                                        left: 10,
                                                                                        top: 10,
                                                                                        child: Align(
                                                                                          alignment: Alignment.topLeft,
                                                                                          child: CircleAvatar(
                                                                                            radius: 14,
                                                                                            backgroundColor: Color(0xFF4b4f53),
                                                                                            child: IconButton(
                                                                                              padding: EdgeInsets.zero,
                                                                                              icon: Icon(
                                                                                                Icons.close_rounded,
                                                                                                size: 16,
                                                                                                color: Colors.white,
                                                                                              ),
                                                                                              onPressed: () {

                                                                                                widget.newsfeedController.imagePickCount = widget.newsfeedController.imagePickCount - 1;
                                                                                                listFiles.removeAt(index);

                                                                                                widget.newsfeedController.replayModelList[ind].mediaData2.removeAt(index);
                                                                                                setState(() {});
                                                                                                if (listFiles.isEmpty) {
                                                                                                  widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isImageAttached = false;
                                                                                                  isImageAttached = false;
                                                                                                  visibility = false;
                                                                                                }

                                                                                                // if(counter!=0)
                                                                                                //   {
                                                                                                //     counter--;
                                                                                                //   }

                                                                                                if (widget
                                                                                                        .newsfeedController
                                                                                                        .replayModelList[ind]
                                                                                                        .bodyText
                                                                                                        .isEmpty &&
                                                                                                    widget
                                                                                                        .post.quoteInfo.postFiles.isEmpty &&
                                                                                                    widget
                                                                                                        .newsfeedController
                                                                                                        .replayModelList[ind]
                                                                                                        .mediaData2
                                                                                                        .isEmpty) {
                                                                                                  widget.newsfeedController.postText = false;
                                                                                                  widget.newsfeedController.update();
                                                                                                }

                                                                                                print("image");
                                                                                                widget.newsfeedController.mediaData.clear();
                                                                                                widget.newsfeedController.update();
                                                                                                if (widget
                                                                                                        .newsfeedController
                                                                                                        .replayModelList[ind]
                                                                                                        .mediaData2
                                                                                                        .length ==
                                                                                                    1) {
                                                                                                  print("image 2 attached if condition ");
                                                                                                  // isMediaAttached = false;

                                                                                                  setState(() {});
                                                                                                }

                                                                                                if (widget
                                                                                                            .newsfeedController
                                                                                                            .replayModelList[ind]
                                                                                                            .imageCounter !=
                                                                                                        null &&
                                                                                                    widget
                                                                                                            .newsfeedController
                                                                                                            .replayModelList[ind]
                                                                                                            .imageCounter >=
                                                                                                        0) {
                                                                                                  print("image index");
                                                                                                  widget
                                                                                                      .newsfeedController
                                                                                                      .replayModelList[ind]
                                                                                                      .imageDescriptionController
                                                                                                      .remove(widget
                                                                                                              .newsfeedController
                                                                                                              .replayModelList[ind]
                                                                                                              .imageDescriptionController[
                                                                                                          index]);
                                                                                                  if (widget
                                                                                                          .newsfeedController
                                                                                                          .replayModelList[ind]
                                                                                                          .imageCounter >=
                                                                                                      1) {
                                                                                                    widget
                                                                                                        .newsfeedController
                                                                                                        .replayModelList[ind]
                                                                                                        .imageCounter--;
                                                                                                  }

                                                                                                  widget.newsfeedController.update();
                                                                                                }
                                                                                                if (widget
                                                                                                            .newsfeedController
                                                                                                            .replayModelList[ind]
                                                                                                            .descriptionCounter !=
                                                                                                        null &&
                                                                                                    widget
                                                                                                            .newsfeedController
                                                                                                            .replayModelList[ind]
                                                                                                            .descriptionCounter >
                                                                                                        1) {
                                                                                                  widget
                                                                                                      .newsfeedController
                                                                                                      .replayModelList[ind]
                                                                                                      .descriptionCounter--;
                                                                                                  widget.newsfeedController.update();
                                                                                                }

                                                                                                print(
                                                                                                    'images length:${widget.newsfeedController.replayModelList[ind].mediaData2.length}');

                                                                                                widget.newsfeedController
                                                                                                    .replayModelList[ind].mediaData2
                                                                                                    .remove(widget
                                                                                                        .newsfeedController
                                                                                                        .replayModelList[ind]
                                                                                                        .mediaData2[index]);
                                                                                                // imageThumbnailsList.removeAt(index);
                                                                                                setState(() {
                                                                                                 /* if (widget
                                                                                                      .newsfeedController
                                                                                                      .replayModelList[ind]
                                                                                                      .mediaData2
                                                                                                      .isEmpty) {
                                                                                                    visibility = false;
                                                                                                  }*/
                                                                                                });
                                                                                              },
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ),
                                                                                    ],
                                                                                  ),
                                                                                );
                                                                        },
                                                                        staggeredTileBuilder: (index) {
                                                                          return StaggeredTile.count(
                                                                              1,
                                                                              widget.newsfeedController.replayModelList[ind].mediaData2.length < 2
                                                                                  ? index.isEven
                                                                                      ? 1.2
                                                                                      : 1.2
                                                                                  : widget.newsfeedController.replayModelList[ind].mediaData2.length < 3
                                                                                      ? index.isEven
                                                                                          ? 1.2
                                                                                          : 1.2
                                                                                      : widget.newsfeedController.replayModelList[ind].mediaData2.length < 4
                                                                                          ? index == 0
                                                                                              ? 1.2
                                                                                              : 0.6
                                                                                          : index.isEven
                                                                                              ? 0.7
                                                                                              : 0.7);
                                                                        }),
                                                                  ),
                                                                ) : SizedBox(),

                                                              ///replay video
/*                                                              : widget.newsfeedController.replayModelList[ind].mediaData2.length >
                                                                          0 &&
                                                                      widget.newsfeedController.replayModelList[ind].mediaData2[0].thumbnailUrl !=
                                                                          null &&
                                                                      widget.newsfeedController.replayModelList[ind].mediaData2[0].name ==
                                                                          "media"*/
                                                          _pickedVideos.isNotEmpty
                                                                  ? Align(
                                                                      alignment:
                                                                          Alignment.center,
                                                                      child:
                                                                          ConstrainedBox(
                                                                        constraints:
                                                                            BoxConstraints.expand(height: 300, width: 350),
                                                                        child:
                                                                            SizedBox(
                                                                              // height: widget.newsfeedController.replayModelList[ind].mediaData2.isEmpty ? 100 : 300,
                                                                              // width: widget.newsfeedController.replayModelList[ind].mediaData2.isEmpty ? 100 : double.infinity,
                                                                          height: _pickedVideos.isEmpty ? 100 : 300,
                                                                          width: _pickedVideos.isEmpty ? 100 : double.infinity,
                                                                          child: Container(
                                                                            child: Stack(
                                                                              children: [
                                                                                Container(
                                                                                  decoration: BoxDecoration(
                                                                                    borderRadius: BorderRadius.circular(15),
                                                                                  ),
                                                                                  // height: controller.modelList2[ind].mediaData2.isEmpty ? 100 : MediaQuery.of(context).size.height / 4,
                                                                                  height: _pickedVideos.isEmpty ? 100 : 250,
                                                                                  width: _pickedVideos.isEmpty ? 100 : double.infinity,
                                                                                  child: _pickedVideos.isEmpty
                                                                                      ? Align(
                                                                                          alignment: Alignment.center,
                                                                                          child: Container(
                                                                                              // width: 62,
                                                                                              // height: 72,
                                                                                              child: Column(
                                                                                            children: [
                                                                                              CircularProgressIndicator(
                                                                                                color: MyColors.BlueColor,
                                                                                              ),
                                                                                              SizedBox(height: 6),
                                                                                              Text(
                                                                                               Strings.uploading,
                                                                                                style: TextStyle(color: MyColors.BlueColor, fontWeight: FontWeight.w700),
                                                                                              ),
                                                                                            ],
                                                                                          )),
                                                                                        )
                                                                                      : ClipRRect(
                                                                                          borderRadius: BorderRadius.circular(15),
                                                                                          child: kIsWeb ? widget.newsfeedController.videoController
                                                                                          : Image.network(
                                                                                            widget.newsfeedController.replayModelList[ind].mediaData2[0].thumbnailUrl ?? 'https://via.placeholder.com/150',
                                                                                            // height: MediaQuery.of(context).size.height / 3.8,
                                                                                            height: 250,
                                                                                            width: double.infinity,
                                                                                            fit: BoxFit.cover,
                                                                                          ),
                                                                                        ),
                                                                                ),
                                                                                Positioned(
                                                                                  left: 10,
                                                                                  top: 10,
                                                                                  child: _pickedVideos.isEmpty
                                                                                      ? SizedBox()
                                                                                      : Align(
                                                                                          alignment: Alignment.topLeft,
                                                                                          child: CircleAvatar(
                                                                                            radius: 14,
                                                                                            backgroundColor: Color(0xFF4b4f53),
                                                                                            child: IconButton(
                                                                                              padding: EdgeInsets.zero,
                                                                                              icon: Icon(
                                                                                                Icons.close_rounded,
                                                                                                size: 16,
                                                                                                color: Colors.white,
                                                                                              ),
                                                                                              onPressed: () {
                                                                                                widget.newsfeedController.postText = false;
                                                                                                widget.newsfeedController.update();
                                                                                                print("enter video");

                                                                                                // controller.modelList2[ind].mediaData2.clear();

                                                                                                // if (controller.modelList2[ind].mediaData2.length == 1) {
                                                                                                //   isMediaAttached = false;
                                                                                                //   setState(
                                                                                                //           () {});
                                                                                                // }

                                                                                                widget.newsfeedController.replayModelList[ind].mediaData2.clear();
                                                                                                _pickedVideos.clear();
                                                                                                _pickedVideosMemeType.clear();
                                                                                                _pickedVideosName.clear();

                                                                                                print(widget.newsfeedController.replayModelList[ind].mediaData2.length);

                                                                                                widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isMediaAttached = false;
                                                                                                // isMediaAttached = false;
                                                                                                widget.newsfeedController.postText = false;
                                                                                                widget.newsfeedController.update();
                                                                                                //  videoWidgetKey =0;
                                                                                                visibility = false;
                                                                                                setState(() {});

                                                                                                // widget.controller.mediaData.clear();
                                                                                                widget.newsfeedController.update();
                                                                                              },
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    )

                                                                  /// replay pdf
                                                                  : widget.newsfeedController.replayModelList[ind].mediaData2.length >
                                                                          0
                                                                      ? widget.newsfeedController.replayModelList[ind].mediaData2[0].name.isNotEmpty && widget.newsfeedController.replayModelList[ind].mediaData2[0].name.contains('.pdf')
                                                                          //  ?
                                                                          ? widget.newsfeedController.replayModelList[ind].mediaData2.length == 0
                                                                              ? Container(width: 100, height: 100, child: CircularProgressIndicator(color: MyColors.BlueColor))
                                                                              : Align(
                                                                                  alignment: Alignment.centerLeft,
                                                                                  child: ConstrainedBox(
                                                                                    constraints: BoxConstraints.expand(height: 300, width: 350),
                                                                                    child: SizedBox(
                                                                                      height: 100,
                                                                                      width: 320,
                                                                                      child: ListView.separated(
                                                                                          scrollDirection: Axis.horizontal,
                                                                                          itemBuilder: (context, index) {
                                                                                            return Container(
                                                                                              height: 100,
                                                                                              width: 320,
                                                                                              child: Stack(
                                                                                                children: [
                                                                                                  Container(
                                                                                                    height: 250,
                                                                                                    width: 320,
                                                                                                    child: ListTile(
                                                                                                      leading: Image.asset('assets/images/document.png'),
                                                                                                      title: Text(widget.newsfeedController.replayModelList[ind].mediaData2[0].name),
                                                                                                      trailing: CircleAvatar(
                                                                                                        radius: 14,
                                                                                                        backgroundColor: Colors.grey,
                                                                                                        child: IconButton(
                                                                                                          padding: EdgeInsets.zero,
                                                                                                          icon: Icon(
                                                                                                            Icons.close_rounded,
                                                                                                            size: 16,
                                                                                                            color: Colors.white,
                                                                                                          ),
                                                                                                          onPressed: () {
                                                                                                            widget.newsfeedController.postText = false;
                                                                                                            widget.newsfeedController.update();
                                                                                                            widget.newsfeedController.replayModelList[ind].mediaData2.clear();
                                                                                                            widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isMediaAttached = false;
                                                                                                            // isMediaAttached = false;
                                                                                                            visibility = false;
                                                                                                            setState(() {});
                                                                                                          },
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            );
                                                                                          },
                                                                                          separatorBuilder: (_, __) {
                                                                                            return SizedBox(width: 4);
                                                                                          },
                                                                                          itemCount: widget.newsfeedController.replayModelList[ind].mediaData2.length),
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                          : Container()
                                                                      : Container(),

                                                          /// tag people and add description
                                                          widget.newsfeedController.replayModelList[0].mediaData2.length >
                                                                      0 &&
                                                                  // && controller.modelList2[ind].mediaData2[0].name=="media"
                                                                  !widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          0]
                                                                      .mediaData2[
                                                                          0]
                                                                      .name
                                                                      .contains(
                                                                          '.pdf') &&
                                                                  (widget.newsfeedController.replayModelList[0].mediaData2[0].thumbnailUrl ==
                                                                          null ||
                                                                      widget
                                                                          .newsfeedController
                                                                          .replayModelList[0]
                                                                          .mediaData2[0]
                                                                          .thumbnailUrl
                                                                          .isEmpty)
                                                              /*  imageWidgetKey ==1*/ ? Row(
                                                                  children: [
                                                                    InkWell(
                                                                        onTap:
                                                                            () {
                                                                          widget.newsfeedController.tagList.clear();
                                                                          widget.newsfeedController.showCustomDialogReply(context, height, width, () {
                                                                            setState(() {
                                                                              widget.newsfeedController.tagList = widget.newsfeedController.tagList;
                                                                            });
                                                                          });
                                                                        },
                                                                        child:
                                                                            Row(
                                                                          children: [
                                                                            Icon(
                                                                              Icons.person,
                                                                              size: 20,
                                                                              color: widget.newsfeedController.displayColor,
                                                                            ),
                                                                            // Text(controller.tagList.isNotEmpty? "${controller.tagList.length >1?controller.tagList[0].firstname + " and ${controller.tagList.length-1} Others":"${controller.tagList[0].firstname}" } " :"Tag People",style:TextStyle(color: Colors.blue,fontSize: 12)),
                                                                            Text(widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList.isNotEmpty ? "${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList.length > 1 ? widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList[0].firstname + " and ${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList.length - 1} Others" : "${widget.newsfeedController.replayModelList[ind].mediaData2[0].mentionUserList[0].firstname}"} " : "Tag People", style: TextStyle(color: widget.newsfeedController.displayColor, fontSize: 14)),
                                                                          ],
                                                                        )),
                                                                    SizedBox(
                                                                      width:
                                                                          20,
                                                                    ),
                                                                    widget.newsfeedController.replayModelList[0].descriptionCounter != null &&
                                                                            widget.newsfeedController.replayModelList[0].mediaData2[0].description.isNotEmpty
                                                                        ? InkWell(
                                                                            onTap: () {
                                                                              if (kIsWeb) {
                                                                                showDialog(
                                                                                    context: context,
                                                                                    builder: (BuildContext con) {
                                                                                      return Shortcuts(
                                                                                        shortcuts: {
                                                                                          LogicalKeySet(LogicalKeyboardKey.escape): EscIntent()
                                                                                        },
                                                                                        child: AlertDialog(
                                                                                            backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                                            insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                                            contentPadding: EdgeInsets.zero,
                                                                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                                            content: SingleChildScrollView(
                                                                                              child: PostImageDescriptionForReply(
                                                                                                ind: 0,
                                                                                              ),
                                                                                            )

                                                                                            //     Deactivation(
                                                                                            //   context2: context,
                                                                                            // ),
                                                                                            ),
                                                                                      );
                                                                                    });
                                                                              } else {
                                                                                Navigator.push(
                                                                                  context,
                                                                                  MaterialPageRoute(
                                                                                      builder: (context) => PostImageDescriptionForReply(
                                                                                            ind: 0,
                                                                                          )),
                                                                                );
                                                                              }
                                                                            },
                                                                            child: Row(
                                                                              children: [
                                                                                Icon(
                                                                                  Icons.note_add,
                                                                                  size: 20,
                                                                                  color: widget.newsfeedController.displayColor,
                                                                                ),
                                                                                SizedBox(
                                                                                  width: 2,
                                                                                ),
                                                                                Container(
                                                                                  width: 100,
                                                                                  child: Text(
                                                                                    widget.newsfeedController.replayModelList[0].mediaData2[0].description,
                                                                                    style: TextStyle(
                                                                                      color: widget.newsfeedController.displayColor,
                                                                                      fontSize: 14,
                                                                                    ),
                                                                                    overflow: TextOverflow.ellipsis,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ))
                                                                        : widget.newsfeedController.replayModelList[0].descriptionCounter != null && widget.newsfeedController.replayModelList[0].mediaData2.length > 1 && widget.newsfeedController.replayModelList[0].descriptionCounter >= 1
                                                                            ? InkWell(
                                                                                onTap: () {
                                                                                  if (kIsWeb) {
                                                                                    showDialog(
                                                                                        context: context,
                                                                                        builder: (BuildContext con) {
                                                                                          return Shortcuts(
                                                                                            shortcuts: {
                                                                                              LogicalKeySet(LogicalKeyboardKey.escape): EscIntent()
                                                                                            },
                                                                                            child: AlertDialog(
                                                                                                backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                                                insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                                                contentPadding: EdgeInsets.zero,
                                                                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                                                content: SingleChildScrollView(
                                                                                                  child: PostImageDescriptionForReply(
                                                                                                    ind: 0,
                                                                                                  ),
                                                                                                )

                                                                                                //     Deactivation(
                                                                                                //   context2: context,
                                                                                                // ),
                                                                                                ),
                                                                                          );
                                                                                        });
                                                                                  } else {
                                                                                    Navigator.push(
                                                                                      context,
                                                                                      MaterialPageRoute(
                                                                                          builder: (context) => PostImageDescriptionForReply(
                                                                                                ind: 0,
                                                                                              )),
                                                                                    );
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  children: [
                                                                                    Icon(
                                                                                      Icons.note_add,
                                                                                      size: 20,
                                                                                      color: widget.newsfeedController.displayColor,
                                                                                    ),
                                                                                    SizedBox(
                                                                                      width: 2,
                                                                                    ),
                                                                                    Text("${widget.newsfeedController.replayModelList[0].descriptionCounter} ${Strings.ImageDescription}", style: TextStyle(color: widget.newsfeedController.displayColor, fontSize: 14)),
                                                                                  ],
                                                                                ))
                                                                            : InkWell(
                                                                                onTap: () {
                                                                                  if (kIsWeb) {
                                                                                    showDialog(
                                                                                        context: context,
                                                                                        builder: (BuildContext con) {
                                                                                          return Shortcuts(
                                                                                            shortcuts: {
                                                                                              LogicalKeySet(LogicalKeyboardKey.escape): EscIntent()
                                                                                            },
                                                                                            child: AlertDialog(
                                                                                                backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                                                insetPadding: EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                                                contentPadding: EdgeInsets.zero,
                                                                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                                                content: SingleChildScrollView(
                                                                                                  child: PostImageDescriptionForReply(
                                                                                                    ind: 0,
                                                                                                    addDescriptionCheck: 1,
                                                                                                  ),
                                                                                                )

                                                                                                //     Deactivation(
                                                                                                //   context2: context,
                                                                                                // ),
                                                                                                ),
                                                                                          );
                                                                                        });
                                                                                  } else {
                                                                                    Navigator.push(
                                                                                      context,
                                                                                      MaterialPageRoute(
                                                                                          builder: (context) => PostImageDescriptionForReply(
                                                                                                ind: 0,
                                                                                                addDescriptionCheck: 1,
                                                                                              )),
                                                                                    );
                                                                                  }
                                                                                },
                                                                                child: Row(
                                                                                  children: [
                                                                                    Icon(
                                                                                      Icons.note_add,
                                                                                      size: 20,
                                                                                      color: widget.newsfeedController.displayColor,
                                                                                    ),
                                                                                    SizedBox(
                                                                                      width: 2,
                                                                                    ),
                                                                                    Text(Strings.addDescription, style: TextStyle(color: widget.newsfeedController.displayColor, fontSize: 14)),
                                                                                  ],
                                                                                )),
                                                                  ],
                                                                )
                                                              : SizedBox(),

                                                          ///reply location
                                                          widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          ind]
                                                                      .location !=
                                                                  ""
                                                              ? Row(
                                                                  children: [
                                                                    Icon(Icons
                                                                        .location_on_outlined),
                                                                    Text(widget
                                                                        .newsfeedController
                                                                        .replayModelList[ind]
                                                                        .location),
                                                                    SizedBox(
                                                                      width:
                                                                          15,
                                                                    ),
                                                                    InkWell(
                                                                      onTap:
                                                                          () {
                                                                        widget.newsfeedController.replayModelList[ind].location =
                                                                            "";
                                                                        // SingleTone.instance.selectedLocation = null;
                                                                        Get.find<NewsfeedController>().postText =
                                                                            false;
                                                                        Get.find<NewsfeedController>().update();
                                                                        setState(() {});
                                                                      },
                                                                      child:
                                                                          Icon(
                                                                        Icons.clear,
                                                                      ),
                                                                    )
                                                                  ],
                                                                )
                                                              : SizedBox()
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),

                                /// optionsformedia
                                widget.newsfeedController.mediaApiCheck !=
                                        true
                                    ? Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          /// images icon
                                          CreatePostIcons(AppImages.uploadImagePNG, widget
                                              .newsfeedController
                                              .replayModelList[widget
                                              .newsfeedController
                                              .currentIndexText]
                                              .mediaData2
                                              .length >
                                              0 &&
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[widget
                                                  .newsfeedController
                                                  .currentIndexText]
                                                  .isMediaAttached ==
                                                  true ||
                                              showPolls[widget
                                                  .newsfeedController
                                                  .currentIndexText] ==
                                                  true
                                              ? () {}
                                              : callGetImage,),

                                          ///video icon
                                          CreatePostIcons(AppImages.uploadVideoPNG, widget
                                              .newsfeedController
                                              .replayModelList[widget
                                              .newsfeedController
                                              .currentIndexText]
                                              .mediaData2
                                              .length >
                                              0 &&
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[widget
                                                  .newsfeedController
                                                  .currentIndexText]
                                                  .isMediaAttached ==
                                                  true ||
                                              showPolls[widget
                                                  .newsfeedController
                                                  .currentIndexText] ==
                                                  true ||
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[widget
                                                  .newsfeedController
                                                  .currentIndexText]
                                                  .isImageAttached ==
                                                  true
                                              ? () {}
                                              : callGetVideo,),

                                          ///pdf icon
                                          CreatePostIcons(AppImages.uploadFilePNG, widget
                                              .newsfeedController
                                              .replayModelList[widget
                                              .newsfeedController
                                              .currentIndexText]
                                              .mediaData2
                                              .length >
                                              0 ||
                                              showPolls[widget
                                                  .newsfeedController
                                                  .currentIndexText] ==
                                                  true ||
                                              widget
                                                  .newsfeedController
                                                  .replayModelList[widget
                                                  .newsfeedController
                                                  .currentIndexText]
                                                  .isImageAttached ==
                                                  true
                                              ? () {}
                                              : callGetFile,),

                                          ///poll icon
                                          ///
                                         /* InkWell(
                                            onTap:
                                            // isMediaUploading
                                            widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].mediaData2.length > 0
                                                ? () {}
                                                :
                                            showPolls[widget.newsfeedController.currentIndexText] || widget.isPostScheduled
                                                ? () {}
                                                : () {

                                              print(_controller.length);
                                              print("controller.currentIndexText poll ${widget.newsfeedController.currentIndexText}");
                                              // _controller[controller.currentIndexText] = TextEditingController();
                                              showPolls[widget.newsfeedController.currentIndexText] = true;
                                              widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poolThread = true;
                                              setState(() {});
                                            },
                                            child: Container(
                                              height: 25,
                                              width: 25,
                                              child: SvgPicture.asset(
                                                'assets/post_icons/polls.svg',

                                                color:
                                                widget.newsfeedController
                                                    .replayModelList[
                                                widget.newsfeedController
                                                    .currentIndexText]
                                                    .mediaData2
                                                    .length >
                                                    0
                                                    ? Colors.grey[400]
                                                    :
                                                widget.isPostScheduled ||
                                                    showPolls[widget.newsfeedController
                                                        .currentIndexText]
                                                    ? Colors.grey[400]
                                                    : widget.newsfeedController.displayColor,
                                                //  : Colors.green,
                                              ),
                                            ),
                                          ),*/

                                          ///schdeule icon
                                          CreatePostIcons(AppImages.uploadSchedulePostPNG, widget
                                              .newsfeedController
                                              .replayModelList[widget
                                              .newsfeedController
                                              .currentIndexText]
                                              .mediaData2
                                              .length >
                                              0
                                              ? () {}
                                              : () async {

                                            isEditable  =false;
                                            showScheduledWerfs = false;
                                            selectedALL = false;


                                            bool val =
                                            await showDialog(
                                              context: context,
                                              builder: (context) {
                                                selectedDateTime =
                                                    DateTime.now()
                                                        .toString();

                                                return AlertDialog(
                                                  content: StatefulBuilder(
                                                      builder: (context,
                                                          setState) {
                                                        return AnimatedContainer(
                                                          curve: Curves
                                                              .easeIn,
                                                          width:
                                                          Get.width *
                                                              0.35,
                                                          duration: Duration(
                                                              microseconds:
                                                              500000),
                                                          height: showScheduledWerfs
                                                              ? Get.height *
                                                              0.8
                                                              : 480,
                                                          child: Column(
                                                            crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  GestureDetector(
                                                                      onTap: () {
                                                                        Navigator.pop(context, false);
                                                                      },
                                                                      child: Icon(
                                                                        Icons.close,
                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      )),
                                                                  SizedBox(
                                                                      width: 12),
                                                                  Text(
                                                                    Strings.schedule,
                                                                    style:
                                                                    Styles.baseTextTheme.headline2.copyWith(
                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      //   fontSize: kIsWeb ? 16 : 14,
                                                                      fontWeight: FontWeight.bold,
                                                                    ),
                                                                  ),
                                                                  Spacer(),
                                                                  RoundedButton(
                                                                    Strings.confirm,
                                                                        () {
                                                                      if (monthValidatedSuccessfully) {
                                                                        widget.isPostScheduled = true;
                                                                        Navigator.pop(context, true);
                                                                      }
                                                                    },
                                                                    horizontalPadding:
                                                                    20.0,
                                                                    verticalPadding:
                                                                    0.0,
                                                                    roundedButtonColor:
                                                                    widget.newsfeedController.displayColor,
                                                                  ),
                                                                ],
                                                              ),
                                                              // ListTile(
                                                              // //  horizontalTitleGap: 30.0,
                                                              //   leading: Icon(
                                                              //       Icons.calendar_today,
                                                              //     color: Color(0xFF586976),
                                                              //   ),
                                                              //   title: Text(
                                                              //       'Will send on ${selectedDayValue}, ${selectedMonthValue != null ? selectedMonthValue : DateFormat('MMM').format(DateTime.now())} ,${selectedYearValue} at ${selectedHourValue}:${selectedMinutesValue}',
                                                              //           style: Styles.baseTextTheme.headline2.copyWith(
                                                              //            // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              //             fontSize: kIsWeb ? 14 : 14,
                                                              //             fontWeight: FontWeight.w400,
                                                              //           ),
                                                              //   ),
                                                              // ),
                                                              SizedBox(
                                                                height:
                                                                20,
                                                              ),

                                                              Row(
                                                                children: [
                                                                  Icon(
                                                                    Icons.calendar_today,
                                                                    color:
                                                                    Color(0xFF586976),
                                                                  ),
                                                                  SizedBox(
                                                                    width:
                                                                    20,
                                                                  ),
                                                                  Text(
                                                                    '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                    // 'Will Post on ${DateFormat("yyyy-MM-dd hh:mm ").parse(selectedDateTime)}',
                                                                    // 'Will Post on ${DateFormat.yMMMMd().add_jm().format(widget.dateTimeData)}',
                                                                    style:
                                                                    Styles.baseTextTheme.headline2.copyWith(
                                                                      // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontSize: kIsWeb ? 14 : 14,
                                                                      fontWeight: FontWeight.w400,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height:
                                                                10,
                                                              ),
                                                              Text(
                                                                Strings.date,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontSize: kIsWeb
                                                                      ? 16
                                                                      : 14,
                                                                  fontWeight:
                                                                  FontWeight.w500,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                  10),
                                                              /* Date DropDown Section */
                                                              Row(
                                                                mainAxisAlignment:
                                                                MainAxisAlignment.spaceBetween,
                                                                children: [
                                                                  // Drop Down Button for Month
                                                                  ButtonTheme(
                                                                    materialTapTargetSize:
                                                                    MaterialTapTargetSize.padded,
                                                                    child:
                                                                    Expanded(
                                                                      flex: 2,
                                                                      child: DropdownButtonFormField<String>(
                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                        isExpanded: true,

                                                                        decoration: InputDecoration(
                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                          border: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                              //  width: 1,
                                                                              // style: BorderStyle.none,
                                                                            ),
                                                                          ),
                                                                          disabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                              // width: 1,
                                                                              // style: BorderStyle.none,
                                                                            ),
                                                                          ),
                                                                          enabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              color: widget.newsfeedController.displayColor,
                                                                              //  width: 1,
                                                                              //  style: BorderStyle.none,
                                                                            ),
                                                                          ),
                                                                          labelText: Strings.month,
                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        // value: 0.toString(),
                                                                        hint: Text(
                                                                          months[DateTime.now().month - 1],
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),

                                                                        alignment: Alignment.bottomCenter,
                                                                        items: months.map((String value) {
                                                                          return DropdownMenuItem<String>(
                                                                            value: value,
                                                                            child: Text(
                                                                              value.toString(),
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged: (month) {
                                                                          /*        int selectedMonthIndex = months.indexWhere((element) =>
                                                        element ==
                                                            month);
                                                        int currentMonthIndex = months.indexWhere((element) =>
                                                        element ==
                                                            months[DateTime.now().month - 1]);
                                                        selectedMonthValue =
                                                            (months.indexWhere((element) => element == month) + 1).toString();
                                                        scheduleMonthValue =
                                                            (months.indexWhere((element) => element == month) + 1).toString();
                                                        print('SELECTED  $selectedMonthIndex' +
                                                            ' : ' +
                                                            'CURRENT $currentMonthIndex');*/

                                                                          selectedMonthValue = (months.indexWhere((element) => element == month) + 1).toString();

                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                            monthValidatedSuccessfully = true;
                                                                          } else {
                                                                            monthValidatedSuccessfully = false;
                                                                          }
                                                                          setState(() {});

                                                                          // setState(() {});
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      width: 12),
                                                                  // Drop Down Button for Day
                                                                  ButtonTheme(
                                                                    materialTapTargetSize:
                                                                    MaterialTapTargetSize.padded,
                                                                    child:
                                                                    Expanded(
                                                                      flex: 1,
                                                                      child: DropdownButtonFormField<String>(
                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                        isExpanded: true,
                                                                        decoration: InputDecoration(
                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                          border: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //width: 1,
                                                                              // style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          disabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              // width: 1,
                                                                              //  style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          enabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              // width: 1,
                                                                              //  style: BorderStyle.none,
                                                                              color: widget.newsfeedController.displayColor,
                                                                            ),
                                                                          ),
                                                                          labelText: Strings.day,
                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        // value: 0.toString(),
                                                                        hint: Text(
                                                                          selectedDayValue,
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        alignment: Alignment.bottomCenter,
                                                                        items: List.generate(31, (index) => index + 1).map((int value) {
                                                                          return DropdownMenuItem<String>(
                                                                            value: value.toString(),
                                                                            child: Text(
                                                                              value.toString(),
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged: (day) {
                                                                          selectedDayValue = day;
                                                                          scheduleDayValue = day;
                                                                          int currentDay = DateTime.now().day;
                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                            monthValidatedSuccessfully = true;
                                                                          } else {
                                                                            monthValidatedSuccessfully = false;
                                                                          }
                                                                          setState(() {});
                                                                          // }
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),

                                                                  SizedBox(
                                                                      width: 12),

                                                                  // Drop Down Button for Year
                                                                  ButtonTheme(
                                                                    materialTapTargetSize:
                                                                    MaterialTapTargetSize.padded,
                                                                    child:
                                                                    Expanded(
                                                                      flex: 1,
                                                                      child: DropdownButtonFormField<String>(
                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                        isExpanded: true,
                                                                        decoration: InputDecoration(
                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                                                          border: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //  width: 1,
                                                                              // style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          disabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //  width: 1,
                                                                              // style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          enabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //width: 1,
                                                                              // style: BorderStyle.none,
                                                                              color: widget.newsfeedController.displayColor,
                                                                            ),
                                                                          ),
                                                                          labelText: Strings.year,
                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        // value: 0.toString(),
                                                                        hint: Text(
                                                                          DateTime.now().year.toString(),
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        alignment: Alignment.bottomCenter,
                                                                        items: years.map((int value) {
                                                                          return DropdownMenuItem<String>(
                                                                            value: value.toString(),
                                                                            child: Text(
                                                                              value.toString(),
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged: (year) {
                                                                          selectedYearValue = year;

                                                                          scheduleYearValue = year;

                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                            monthValidatedSuccessfully = true;
                                                                          } else {
                                                                            monthValidatedSuccessfully = false;
                                                                          }
                                                                          setState(() {});
                                                                          //
                                                                          print('Scheduled Year ' + scheduleYearValue.toString());
                                                                          // setState(() {});
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              !monthValidatedSuccessfully
                                                                  ? Text(
                                                                Strings.youCannotScheduleAWerfInThePast,
                                                                style: TextStyle(
                                                                  color: Colors.red,
                                                                  fontSize: kIsWeb ? 14 : 12,
                                                                ),
                                                              )
                                                                  : SizedBox(),
                                                              SizedBox(
                                                                  height:
                                                                  20),
                                                              /* Time DropDown Section */
                                                              Text(
                                                                Strings.time,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontSize: kIsWeb
                                                                      ? 16
                                                                      : 14,
                                                                  fontWeight:
                                                                  FontWeight.w500,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                  10),
                                                              Row(
                                                                children: [
                                                                  /* DropDown Button For Hours */
                                                                  ButtonTheme(
                                                                    materialTapTargetSize:
                                                                    MaterialTapTargetSize.padded,
                                                                    child:
                                                                    Expanded(
                                                                      flex: 1,
                                                                      child: DropdownButtonFormField<String>(
                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                        isExpanded: true,
                                                                        decoration: InputDecoration(
                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                          border: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              // width: 1,
                                                                              //  style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          disabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //  width: 1,
                                                                              //  style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          enabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //  width: 1,
                                                                              // style: BorderStyle.none,
                                                                              color: widget.newsfeedController.displayColor,
                                                                            ),
                                                                          ),
                                                                          labelText: Strings.hours,
                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        // value: 0.toString(),
                                                                        hint: Text(
                                                                          selectedHourValue,
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        alignment: Alignment.bottomCenter,
                                                                        items: List.generate(24, (index) => index).map((int value) {
                                                                          return DropdownMenuItem<String>(
                                                                            value: value.toString(),
                                                                            child: Text(
                                                                              value.toString(),
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged: (hour) {
                                                                          selectedHourValue = hour;
                                                                          scheduleHourValue = hour;

                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                            monthValidatedSuccessfully = true;
                                                                          } else {
                                                                            monthValidatedSuccessfully = false;
                                                                          }
                                                                          setState(() {});
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  /* DropDown Button For Minutes */
                                                                  SizedBox(
                                                                      width: 12),
                                                                  ButtonTheme(
                                                                    materialTapTargetSize:
                                                                    MaterialTapTargetSize.padded,
                                                                    child:
                                                                    Expanded(
                                                                      flex: 1,
                                                                      child: DropdownButtonFormField<String>(
                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                        isExpanded: true,
                                                                        decoration: InputDecoration(
                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                          border: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              // width: 1,
                                                                              // style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          disabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              // width: 1,
                                                                              // style: BorderStyle.none,
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey),
                                                                          ),
                                                                          enabledBorder: OutlineInputBorder(
                                                                            borderRadius: BorderRadius.circular(10),
                                                                            borderSide: BorderSide(
                                                                              //   width: 1,
                                                                              //  style: BorderStyle.none,
                                                                              color: widget.newsfeedController.displayColor,
                                                                            ),
                                                                          ),
                                                                          labelText: Strings.minutes,
                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        // value: 0.toString(),
                                                                        hint: Text(
                                                                          selectedMinutesValue,
                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        alignment: Alignment.bottomCenter,
                                                                        items: List.generate(60, (index) => index).map((int value) {
                                                                          return DropdownMenuItem<String>(
                                                                            value: value.toString(),
                                                                            child: Text(
                                                                              value.toString(),
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          );
                                                                        }).toList(),
                                                                        onChanged: (minute) {
                                                                          selectedMinutesValue = minute;
                                                                          scheduleMinutesValue = minute;
                                                                          print("value$minute");
                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                            monthValidatedSuccessfully = true;
                                                                          } else {
                                                                            monthValidatedSuccessfully = false;
                                                                          }
                                                                          setState(() {});
                                                                        },
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                      width: 12),
                                                                  Expanded(
                                                                      flex: 1,
                                                                      child: SizedBox()),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                  20),
                                                              Text(
                                                                Strings.timeZone,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontSize: kIsWeb
                                                                      ? 16
                                                                      : 14,
                                                                  fontWeight:
                                                                  FontWeight.w500,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  height:
                                                                  10),
                                                              Text(
                                                                DateTime.now()
                                                                    .timeZoneName,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  color: Theme.of(context).brightness == Brightness.dark
                                                                      ? Colors.white
                                                                      : Colors.black,
                                                                  //fontSize: kIsWeb ? 16 : 14,
                                                                  fontWeight:
                                                                  FontWeight.bold,
                                                                ),
                                                              ),
                                                              Divider(
                                                                  height:
                                                                  1),
                                                              GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  widget
                                                                      .newsfeedController
                                                                      .noScheduledPost = true;
                                                                  isEditable =
                                                                  false;
                                                                  showScheduledWerfs =
                                                                  !showScheduledWerfs;
                                                                  setState(
                                                                          () {});
                                                                  widget
                                                                      .newsfeedController
                                                                      .scheduledPosts = await widget.newsfeedController.getScheduledPosts();
                                                                  widget
                                                                      .newsfeedController
                                                                      .noScheduledPost = false;

                                                                  setState(
                                                                          () {});
                                                                },
                                                                child:
                                                                ListTile(
                                                                  title:
                                                                  Text(
                                                                    Strings.scheduledWerfs,
                                                                    style:
                                                                    Styles.baseTextTheme.headline2.copyWith(
                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontSize: kIsWeb ? 16 : 14,
                                                                      fontWeight: FontWeight.w500,
                                                                    ),
                                                                  ),
                                                                  trailing: Icon(showScheduledWerfs
                                                                      ? Icons.expand_less
                                                                      : Icons.expand_more),
                                                                ),
                                                              ),
                                                              if (showScheduledWerfs)
                                                                widget.newsfeedController.noScheduledPost
                                                                    ? CircularProgressIndicator()
                                                                    : widget.newsfeedController.scheduledPosts.isEmpty
                                                                    ? Center(
                                                                  child: Text(
                                                                    Strings.youHaveNoScheduledWerfs,
                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontSize: kIsWeb ? 14 : 12,
                                                                    ),
                                                                  ),
                                                                )
                                                                    : Expanded(
                                                                  child: Column(
                                                                    children: [
                                                                      GestureDetector(
                                                                          onTap: () {
                                                                            isEditable = !isEditable;
                                                                            setState(() {});
                                                                          },
                                                                          child: Align(
                                                                            alignment: Alignment.topRight,
                                                                            child: Text(
                                                                              isEditable ? Strings.cancel : Strings.edit,
                                                                              style: TextStyle(color: Colors.blue, decoration: TextDecoration.underline),
                                                                            ),
                                                                          )),
                                                                      Expanded(
                                                                        child: ListView.separated(
                                                                            shrinkWrap: true,
                                                                            itemBuilder: (context, index) {
                                                                              var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(widget.newsfeedController.scheduledPosts[index].postingTime, true);
                                                                              var postingTime = dateTime.toLocal();
                                                                              postingTime = DateFormat('yyyy-MM-dd HH:mm').parse(postingTime.toString());

                                                                              return ListTile(
                                                                                leading: isEditable
                                                                                    ? Checkbox(
                                                                                    value: widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion,
                                                                                    onChanged: (value) {

                                                                                      widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion = !widget.newsfeedController.scheduledPosts[index].isScheduledPostSelectedForDeletion;
                                                                                      widget.newsfeedController.update();
                                                                                      setState(() {});
                                                                                      if (widget.postsForDeletions.contains(widget.newsfeedController.scheduledPosts[index].id)) {
                                                                                        int ind = widget.postsForDeletions.indexWhere((element) => element == widget.newsfeedController.scheduledPosts[index].id);

                                                                                        widget.postsForDeletions.removeAt(ind);
                                                                                      } else {
                                                                                        widget.postsForDeletions.add(widget.newsfeedController.scheduledPosts[index].id);
                                                                                      }

                                                                                    })
                                                                                    : SizedBox(),
                                                                                title: Text('${Strings.willSendOn} ${DateFormat('dd MMMM, yyyy HH:mm').format(postingTime)}'),
                                                                                subtitle: Text(widget.newsfeedController.scheduledPosts[index].body),
                                                                              );
                                                                            },
                                                                            separatorBuilder: (_, __) {
                                                                              return Divider(height: 1);
                                                                            },
                                                                            itemCount: widget.newsfeedController.scheduledPosts.length),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              isEditable
                                                                  ? ListTile(
                                                                leading:  selectedALL==true?
                                                                GestureDetector(
                                                                    onTap:(){

                                                                      widget.postsForDeletions = [];
                                                                      widget.newsfeedController.scheduledPosts.forEach((element) {
                                                                        element.isScheduledPostSelectedForDeletion = false;
                                                                      });

                                                                      selectedALL = false;
                                                                      print('List....... ' + widget.postsForDeletions.toString());

                                                                      setState(
                                                                              () {});
                                                                    },
                                                                    child: Text(Strings.deselectAll)):
                                                                GestureDetector(
                                                                    onTap:(){

                                                                      widget.newsfeedController.scheduledPosts.forEach((element) {
                                                                        element.isScheduledPostSelectedForDeletion = true;
                                                                      });


                                                                      widget.postsForDeletions = [];
                                                                      widget.newsfeedController.scheduledPosts.forEach((element) {
                                                                        widget.postsForDeletions.add(element.id);
                                                                      });








                                                                      selectedALL = true;


                                                                      setState(
                                                                              () {});

                                                                      print('List....... ' + widget.postsForDeletions.toString());

                                                                    },
                                                                    child: Text(Strings.selectAll)),
                                                                trailing: GestureDetector(
                                                                  onTap: () {
                                                                    print('List ' + widget.postsForDeletions.toString());
                                                                    widget.newsfeedController.deleteScheduledPosts(
                                                                      widget.postsForDeletions,
                                                                      context,
                                                                    );
                                                                    // widget
                                                                    //     .postsForDeletions
                                                                    //     .clear();
                                                                  },
                                                                  child: Text(Strings.delete),
                                                                ),
                                                              )
                                                                  : SizedBox(),
                                                            ],
                                                          ),
                                                        );
                                                      }),
                                                );
                                              },
                                            );
                                            if (val) {
                                              print("getValueFromSchedule" +
                                                  val.toString());
                                              setState(() {});
                                            }
                                          },),


                                          ///location icon
                                          CreatePostIcons(AppImages.uploadLocationPNG, () {
                                            locationController
                                                .locationTextController
                                                .clear();
                                            showDialog(
                                                context: context,
                                                builder: (context) {
                                                  return AlertDialog(
                                                    contentPadding:
                                                    EdgeInsets.zero,
                                                    shape:
                                                    RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                          15),
                                                    ),
                                                    content: StatefulBuilder(
                                                        builder: (context,
                                                            setState) {
                                                          return Container(
                                                            width: 500,
                                                            height: 500,
                                                            child: Padding(
                                                              padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left:
                                                                  10,
                                                                  top: 10,
                                                                  right:
                                                                  10),
                                                              child: Column(
                                                                children: [
                                                                  Row(
                                                                    mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceBetween,
                                                                    children: [
                                                                      IconButton(
                                                                          onPressed:
                                                                              () {
                                                                            Navigator.pop(context);
                                                                            widget.newsfeedController.postText = false;
                                                                          },
                                                                          icon:
                                                                          Icon(
                                                                            Icons.clear,
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          )),
                                                                      Text(
                                                                        Strings.tagLocation,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                          //fontSize: kIsWeb ? 16 : 14,
                                                                          fontWeight:
                                                                          FontWeight.bold,
                                                                        ),
                                                                      ),
                                                                      Spacer(),
                                                                      ElevatedButton(
                                                                        onPressed:
                                                                            () {},
                                                                        child:
                                                                        Text(
                                                                          Strings.done,
                                                                          style:
                                                                          TextStyle(
                                                                            color: Colors.white,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                        style:
                                                                        ElevatedButton.styleFrom(
                                                                          padding: EdgeInsets.only(
                                                                              left: 15,
                                                                              right: 15,
                                                                              top: 15,
                                                                              bottom: 15),
                                                                          primary:
                                                                          widget.newsfeedController.displayColor,
                                                                          shape:
                                                                          new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(20.0)),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  SizedBox(
                                                                    height:
                                                                    20,
                                                                  ),
                                                                  Obx(() {
                                                                    return TextFormField(
                                                                      focusNode:
                                                                      focusNode,
                                                                      cursorRadius:
                                                                      const Radius.circular(500),
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme.of(context).brightness == Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontWeight:
                                                                        FontWeight.w500,
                                                                        fontSize:
                                                                        14,
                                                                      ),
                                                                      onEditingComplete:
                                                                          () {
                                                                        FocusScope.of(context)
                                                                            .requestFocus(FocusNode());
                                                                      },
                                                                      controller:
                                                                      locationController.locationTextController,
                                                                      onChanged:
                                                                          (value) {
                                                                        locationController
                                                                            .callApi(value);
                                                                        print(locationController
                                                                            .locationTextController
                                                                            .text
                                                                            .length);
                                                                        print(
                                                                            value);
                                                                      },
                                                                      decoration:
                                                                      InputDecoration(
                                                                        hintText:
                                                                        Strings.searchLocation,
                                                                        hintStyle: Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontWeight:
                                                                          FontWeight.w500,
                                                                          fontSize:
                                                                          14,
                                                                        ),
                                                                        prefixIcon: checkFocus.value == false
                                                                            ? Row(
                                                                          mainAxisAlignment: MainAxisAlignment.start,
                                                                          children: [
                                                                            SizedBox(
                                                                              width: 10,
                                                                            ),
                                                                            Icon(
                                                                              Icons.search,
                                                                              color: Color(0xFF586976),
                                                                            ),
                                                                            SizedBox(
                                                                              width: 5,
                                                                            ),
                                                                            Text(
                                                                              Strings.searchLocation,
                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontWeight: FontWeight.w500,
                                                                                fontSize: 14,
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        )
                                                                            : Icon(
                                                                          Icons.search,
                                                                          color: Color(0xFF586976),
                                                                        ),
                                                                        suffixIcon: locationController.locationTextController.text.length > 0
                                                                            ? IconButton(
                                                                            icon: Icon(
                                                                              Icons.clear,
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              size: 30,
                                                                            ),
                                                                            onPressed: () {
                                                                              locationController.locationTextController.clear();
                                                                            })
                                                                            : null,

                                                                        //   filled: true,

                                                                        // contentPadding: EdgeInsets.only(top: 20,left: 10),
                                                                        focusedBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius:
                                                                          BorderRadius.circular(30.0),
                                                                          borderSide:
                                                                          BorderSide(
                                                                            width: 2,
                                                                            color: Colors.blue,
                                                                          ),
                                                                        ),

                                                                        enabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius:
                                                                          BorderRadius.circular(30.0),
                                                                          borderSide:
                                                                          BorderSide(
                                                                            color: Colors.grey,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    );
                                                                  }),
                                                                  Expanded(
                                                                    child: Container(
                                                                      // height: Get.height * 0.6,
                                                                        child: locationController.searchPlaces.value != null ? Obx(() => listview(context, locationController.searchPlaces.value)) : Text('')),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        }),
                                                  );
                                                });
                                          },),

                                          ///smile icon
                                          CreatePostIcons(AppImages.uploadEmojisPNG, () {
                                            if (isEmojiVisible) {
                                              widget.newsfeedController
                                                  .focusNode
                                                  .requestFocus();
                                              print("in emjoji");
                                              // controller.postText = true;
                                              // controller.update();

                                              setState(() {});
                                            } else if (!isEmojiVisible) {
                                              FocusScope.of(context)
                                                  .unfocus();

                                              setState(() {});
                                            }
                                            isEmojiVisible =
                                            !isEmojiVisible;
                                            if (this.mounted) {
                                              // check whether the state object is in tree
                                              setState(() {
                                                // make changes here
                                              });
                                            }
                                          }),

                                          SizedBox(
                                            //width: 8,
                                            width: Get.width * 0.004,
                                          ),
                                          widget.isPostScheduled
                                              ? ElevatedButton(
                                                  child: Text(
                                                   Strings.schedule,
                                                    style: TextStyle(
                                                        fontSize: 14,
                                                        color:
                                                            Colors.white),
                                                  ),
                                                  style: ButtonStyle(
                                                    padding:
                                                        MaterialStateProperty
                                                            .all(
                                                      EdgeInsets.symmetric(
                                                          horizontal: 30,
                                                          vertical: 2),
                                                    ),
                                                    backgroundColor: MaterialStateProperty.all(widget
                                                                    .newsfeedController
                                                                    .postText ==
                                                                false &&
                                                            widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isMediaAttached ==
                                                                false
                                                        ? Colors.blueGrey
                                                        : widget.newsfeedController
                                                                        .postText ==
                                                                    true &&
                                                                isMediaUploading ==
                                                                    true &&
                                                                widget
                                                                    .newsfeedController
                                                                    .replayModelList[widget
                                                                        .newsfeedController
                                                                        .currentIndexText]
                                                                    .bodyText
                                                                    .isEmpty &&
                                                                widget
                                                                    .newsfeedController
                                                                    .replayModelList[widget
                                                                        .newsfeedController
                                                                        .currentIndexText]
                                                                    .poll_ques_first
                                                                    .isEmpty &&
                                                                widget
                                                                    .newsfeedController
                                                                    .replayModelList[widget.newsfeedController.currentIndexText]
                                                                    .poll_ques_second
                                                                    .isEmpty
                                                            ? widget.newsfeedController.displayColor.withOpacity(0.5)
                                                            : widget.newsfeedController.displayColor),
                                                    shape: MaterialStateProperty
                                                        .all<
                                                            RoundedRectangleBorder>(
                                                      RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(
                                                                    40),
                                                      ),
                                                    ),
                                                  ),
                                                  onPressed: widget
                                                                  .newsfeedController
                                                                  .postText ==
                                                              false &&
                                                          widget
                                                                  .newsfeedController
                                                                  .replayModelList[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .isMediaAttached ==
                                                              false
                                                      ? null
                                                      : widget.newsfeedController
                                                                      .postText ==
                                                                  true &&
                                                              isMediaUploading ==
                                                                  true
                                                          ? null
                                                          : () async {
                                                              // widget.controller.isLoading = true;
                                                              apiCalled =
                                                                  true;
                                                              setState(
                                                                  () {});
                                                              widget.newsfeedController.schedulePost(
                                                                  context,
                                                                  bodyText: widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          0]
                                                                      .bodyText,
                                                                  fileName: _pdfFilesName.length >
                                                                          0
                                                                      ? _pdfFilesName
                                                                      : null,
                                                                  payload: widget
                                                                      .newsfeedController
                                                                      .replayModelList,
                                                                  // imageWebBytes: _pickedImage.isNotEmpty
                                                                  //     ? _pickedImage
                                                                  //     : _pickedVideos.isNotEmpty
                                                                  //     ? _pickedVideos
                                                                  //     : _pickedAudios != null
                                                                  //     ? _pickedAudios
                                                                  //     : _pickedPdfs,
                                                                  link: link != null
                                                                      ? link
                                                                      : '',
                                                                  linkImage: linkImage != null
                                                                      ? linkImage
                                                                      : '',
                                                                  linkMeta: linkMeta !=
                                                                          null
                                                                      ? linkMeta
                                                                      : '',
                                                                  linkTitle: linkTitle !=
                                                                          null
                                                                      ? linkTitle
                                                                      : '',
                                                                  postingTime:
                                                                      selectedDateTime
                                                                          .toString(),
                                                              isComment: true);
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                              // Navigator.pop(context);
                                                            },
                                                )
                                              : RoundedButton(
                                                  threadCreated == false ||
                                                          widget
                                                                  .newsfeedController
                                                                  .replayModelList
                                                                  .length ==
                                                              1
                                                      ? Strings.reply
                                                      : Strings.allReply,
                                                  widget.newsfeedController.postText ==
                                                              false &&
                                                          widget
                                                                  .newsfeedController
                                                                  .replayModelList[widget
                                                                      .newsfeedController
                                                                      .currentIndexText]
                                                                  .isMediaAttached ==
                                                              false
                                                      ? null
                                                      : widget.newsfeedController
                                                                      .postText ==
                                                                  true &&
                                                              isMediaUploading ==
                                                                  true
                                                          ? null
                                                          : showPolls[widget
                                                                      .newsfeedController
                                                                      .currentIndexText] &&
                                                                  widget.newsfeedController
                                                                          .postText ==
                                                                      true &&
                                                                  txtOption1
                                                                      .isEmpty &&
                                                                  txtOption2
                                                                      .isEmpty &&
                                                                  widget
                                                                      .newsfeedController
                                                                      .replayModelList[widget
                                                                          .newsfeedController
                                                                          .currentIndexText]
                                                                      .bodyText
                                                                      .isEmpty &&
                                                                  widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_first ==
                                                                      "" &&
                                                                  widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].poll_ques_second == ""
                                                              ? () {}
                                                              : () async {

                                                    if ((_pickedVideos.length + listFiles.length) > 4) {
                                                      Fluttertoast.showToast(msg: Strings.pleaseChooseEither1VideoOr1Pdf, toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 5, backgroundColor: Colors.red, textColor: Colors.white, webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)", webPosition: "center", fontSize: kIsWeb ? 18 : 16.0);
                                                      return;
                                                    }
                                                                  List<ModelClass>
                                                                      showPoolList =
                                                                      [];
                                                                  List<ModelClass>
                                                                      commentsList =
                                                                      [];

                                                                  if (showPolls[0] ==
                                                                          true &&
                                                                      threadCreated ==
                                                                          false) {
                                                                    showPoolList.insert(
                                                                        0,
                                                                        ModelClass.fromJson({
                                                                          'body': widget.newsfeedController.replayModelList[0].bodyText,
                                                                          'poll_ques_first': widget.newsfeedController.replayModelList[0].poll_ques_first,
                                                                          'poll_ques_second': widget.newsfeedController.replayModelList[0].poll_ques_second,
                                                                          'poll_ques_third': widget.newsfeedController.replayModelList[0].poll_ques_third == null ? null : widget.newsfeedController.replayModelList[0].poll_ques_third,
                                                                          'poll_ques_fourth': widget.newsfeedController.replayModelList[0].poll_ques_fourth == null ? null : widget.newsfeedController.replayModelList[0].poll_ques_fourth,
                                                                          'files': [],
                                                                          'link_meta': '',
                                                                          'link': '',
                                                                          'link_image': '',
                                                                          'link_title': '',
                                                                          'days': '',
                                                                          'minutes': '',
                                                                          'hours': '',
                                                                          'location': '',
                                                                          'lat': '',
                                                                          'lng': '',
                                                                          'type': 'poll',
                                                                        }));
                                                                  }

                                                                  /*print(
                                                                      "post id");
                                                                  print('AUDIO BYTES WHEN ON PRESSED IS ACTIVATED  ' +
                                                                      _pickedAudios
                                                                          .toString());*/
                                                                  apiCalled =
                                                                      true;
                                                                  setState(
                                                                      () {});
                                                                  var responseCode;

                                                                  {
                                                                    widget
                                                                        .newsfeedController
                                                                        .replayModelList
                                                                        .forEach((ele) {
                                                                      ele.mediaData2
                                                                          .forEach((element) {
                                                                        element.mentionUserList.clear();
                                                                      });
                                                                    });

                                                                    if (isEdit ==
                                                                        false) {
                                                                      widget
                                                                          .newsfeedController
                                                                          .replayModelList
                                                                          .forEach((element) {
                                                                        print("before element.bodyText ${element.bodyText}");
                                                                        element.bodyText =
                                                                            element.bodyText.replaceAll("\n", " " + "\n");

                                                                        print("after element.bodyText ${element.bodyText}");
                                                                      });
                                                                    }
                                                                    if (_pickedVideos.isNotEmpty) {
                                                                      await Get.find<NewsfeedController>().uploadMedia(_pickedVideos[0], 2,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
                                                                    }
                                                                    if (widget.newsfeedController.replayModelList[widget.newsfeedController.currentIndexText].isImageAttached) {
                                                                      await uploadImages();
                                                                    }
                                                                    responseCode = await widget
                                                                        .newsfeedController
                                                                        .createPost(
                                                                      payload: widget
                                                                          .newsfeedController
                                                                          .replayModelList,
                                                                      postId:
                                                                          -1,
                                                                      replyId:
                                                                          widget.replyPageId,
                                                                      getClickId:
                                                                          widget.getClickId,
                                                                      incrementPostId: widget
                                                                          .post
                                                                          .postId,
                                                                    );
                                                                    print(
                                                                        "replay posted created");
                                                                  }
                                             /*       Fluttertoast.showToast(
                                                        msg:'Your reply is being reviewed. We will post it soon.',
                                                        toastLength: Toast.LENGTH_SHORT,
                                                        gravity: ToastGravity.BOTTOM,
                                                        timeInSecForIosWeb: 5,
                                                        backgroundColor: Colors.blue,
                                                        textColor: Colors.white,
                                                        webBgColor: "linear-gradient(to right, #2196F3FF, #2196F3FF)",
                                                        webPosition: "bottom",
                                                        fontSize: kIsWeb ? 18 : 16.0);*/
                                                                  _pickedImage =
                                                                      [];
                                                                  apiCalled =
                                                                      false;
                                                                  widget
                                                                      .newsfeedController
                                                                      .currentIndexText = 0;
                                                                  Navigator.pop(
                                                                      context);
                                                                  widget.newsfeedController
                                                                          .isNewsfeedLoading =
                                                                      false;
                                                                  widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          0]
                                                                      .imageCounter = 0;
                                                                  widget
                                                                      .newsfeedController
                                                                      .replayModelList[
                                                                          0]
                                                                      .descriptionCounter = 0;
                                                    widget.newsfeedController.modelList3[0].bodyText = "";
                                                                  if (widget.newsfeedController.replayModelList[0].imageDescriptionController != null &&
                                                                      widget.newsfeedController.replayModelList[0].imageDescriptionController.isNotEmpty) {
                                                                    widget.newsfeedController.replayModelList[0].imageDescriptionController.forEach((element) {
                                                                      element.clear();
                                                                    });
                                                                  }

                                                                  widget
                                                                      .newsfeedController
                                                                      .update();
                                                                  print('RESPONSEE' +
                                                                      responseCode
                                                                          .toString());
                                                                },
                                                  horizontalPadding: 36.0,
                                                  verticalPadding: 0.0,
                                                  roundedButtonColor: widget
                                                      .newsfeedController
                                                      .displayColor,
                                                ),
                                        ],
                                      )
                                    : const SizedBox(),
                                const SizedBox(height: 10,)
                              ],
                            ),
                            Offstage(
                                offstage: !isEmojiVisible,
                                child: Container(
                                    height: 250,
                                    width: 250,
                                    margin: const EdgeInsets.all(5),
                                    padding: const EdgeInsets.all(2),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border: Border.all(
                                          color: Colors.white,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(10)),
                                    child: DefaultTabController(
                                        length: emojis.length,
                                        child: isPortrait
                                            ? Column(children: [
                                                Container(
                                                    margin:
                                                        const EdgeInsets
                                                                .symmetric(
                                                            horizontal:
                                                                2),
                                                    child: EmojiTabBar(
                                                        tabController:
                                                            _tabController)),
                                                const Divider(
                                                    color: Colors.black45,
                                                    height: 5,
                                                    thickness: .5),
                                                EmojisList(
                                                    controller: widget
                                                        .newsfeedController,
                                                    cross: cross,
                                                    textController:
                                                        _controller[widget
                                                            .newsfeedController
                                                            .currentIndexText],
                                                    // controller: controller,
                                                    emojiSelected: () {
                                                      print(
                                                          "emoji called");
                                                      widget
                                                          .newsfeedController
                                                          .postText = true;
                                                      widget
                                                          .newsfeedController
                                                          .update();
                                                      setState(() {});
                                                    },
                                                    tabController:
                                                        _tabController)
                                              ])
                                            : Row(children: [
                                                emojiSideBar(),
                                                EmojisList(
                                                    controller: widget
                                                        .newsfeedController,
                                                    cross: cross,
                                                    textController:
                                                        _controller[widget
                                                            .newsfeedController
                                                            .currentIndexText],
                                                    // controller: controller,
                                                    emojiSelected: () {
                                                      print(
                                                          "emoji calledd");
                                                      widget
                                                          .newsfeedController
                                                          .postText = true;
                                                      widget
                                                          .newsfeedController
                                                          .update();
                                                      setState(() {});
                                                    },
                                                    tabController:
                                                        _tabController)
                                              ])))),
                          ],
                        ),
                      )
                    ],
                  ),
          ),
        ),
      ),
    );
  }

  uploadImages() async {
    var controller = widget.newsfeedController;
    isMediaUploading = true;
    setState(() {});
    List<_dio.MultipartFile> files = [];
    files = listFiles
        .map((path) => _dio.MultipartFile.fromBytes(
              resizeImage(path.bytes, path.name),
              filename: path.name,
            ))
        .toList();
    Map<String, dynamic> userData = {};
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }
    await controller.multiImageSeleted(userData, 2, null, listBytes: listFiles);
    controller.imagePickCount = controller.imagePickCount + files.length;
    // LoggingUtils.printValue("image pick count: ", controller.imagePickCount);

    controller.postText = true;
    // controller.modelList3[0].isImageAttached = true;
    controller.update();
    controller.mediaApiCheck = false;
    imageThumbnailsList.add(imageThumbnail);
    visibility = true;
    isMediaUploading = false;
    listFiles = [];
    setState(() {});
  }

  Uint8List resizeImage(Uint8List data, String name) {
    if (name.contains("gif")) return data;
    Uint8List resizedData = data;
    IMG.Image img = IMG.decodeImage(data);
    IMG.Image resized = IMG.copyResize(img,
        width: (img.width / 1.5).round(), height: (img.height / 1.5).round());
    resizedData = IMG.encodeJpg(resized);
    return resizedData;
  }

  bool compareSelectedDatetime(String selectedDatetime) {
    DateTime parseDate =
        new DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDatetime);
    DateTime currentDatetime =
        new DateFormat("yyyy-MM-dd HH:mm:ss").parse(DateTime.now().toString());
    bool isValidDate = parseDate.isAfter(currentDatetime);
    print("isValidate" + isValidDate.toString());

    return isValidDate;
  }

  Widget _location(
      {@required StructuredFormatting data,
      @required BuildContext context,
      @required int index}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 200),
                  child: Text(
                    data.maintext,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: "assets/fonts/Arial-Bold.ttf",
                    ),
                  ),
                ),
                const SizedBox(
                  height: 2,
                ),
                data.secondarytext != null
                    ? Text(data.secondarytext,
                        //secnT(data: data),
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: MyColors.grey,
                          fontFamily: "assets/fonts/Regular.ttf",
                        ))
                    : Text(""),
                // Text(
                //   secnT(data: data),
                //   textAlign: TextAlign.left,
                //   style: TextStyle(
                //     color: Colorss.grey,
                //     fontFamily: "assets/fonts/Regular.ttf",
                //   ),
                // ),
              ],
            )),
        Divider(
          thickness: 2,
        ),
      ],
    );
  }

  String secnT({@required StructuredFormatting data}) {
    if (data.secondarytext != null) {
      return data.secondarytext;
    }
    locationController.update();
    return '';
  }

  Widget listview(BuildContext context, AutoComplete data) {
    return Container(
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: data.predict.length,
        padding: const EdgeInsets.only(top: 5),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () async {
              // print(
              //     "index location ${Get.find<NewsfeedController>().currentIndexText}");

              int currentIndex = Get.find<NewsfeedController>().currentIndexText;
              Get.find<NewsfeedController>().replayModelList[currentIndex].location = data.predict[index].structuredformatting.maintext;
              Get.find<NewsfeedController>().replayModelList[currentIndex].lat = locationController.lat.value.toString();
              Get.find<NewsfeedController>().replayModelList[currentIndex].lng = locationController.lng.value.toString();
              // Get.find<NewsfeedController>().modelList2[Get.find<NewsfeedController>().currentIndexText].location =
              //     data.predict[index].structuredformatting.maintext;
              // Get.find<NewsfeedController>().modelList2[Get.find<NewsfeedController>().currentIndexText].lat =
              //     locationController.lat.value.toString();
              // Get.find<NewsfeedController>().modelList2[Get.find<NewsfeedController>().currentIndexText].lng =
              //     locationController.lng.value.toString();
              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              // SingleTone.instance.lat = locationController.lat.value;
              // SingleTone.instance.lng = locationController.lng.value;
              Get.find<NewsfeedController>().postText = true;

              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              // SingleTone.instance.lat = locationController.lat.value;
              // SingleTone.instance.lng = locationController.lng.value;
              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              //
              // locationController.mainText = data.predict[index].structuredformatting.maintext;
              // locationController.secondaryText = data.predict[index].structuredformatting.secondarytext;
              // locationController.callApi(' ');
              // locationController.locationTextController.text = locationController.mainText;
              // // Selectedlocation(context: context);
              // locationController.update();
              // FocusScope.of(context).requestFocus(new FocusNode());
              // await locationController.callApiLatLong(data.predict[index].placeid);

              setState(() {});

              Navigator.pop(context);
            },
            child: _location(
              data: data.predict[index].structuredformatting,
              context: context,
              index: index,
            ),
          );
        },
      ),
    );
  }

  Widget urlFetch() {
    if (widget.newsfeedController.scrapUrl.contains('.com')) {
      return FutureBuilder<ScrappingData>(
        future: widget.newsfeedController
            .urlScraping(widget.newsfeedController.scrapUrl),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            link = snapshot.data.link;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .link = snapshot.data.link;
            linkTitle = snapshot.data.title;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkTitle = snapshot.data.title;
            linkMeta = snapshot.data.meta;
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkMeta = snapshot.data.meta;

            if (snapshot.data.images == null || snapshot.data.images.isEmpty) {
              linkImage =
                  "https://www.challengetires.com/assets/img/placeholder.jpg";
            } else {
              linkImage = snapshot.data.images[0];
            }
            widget
                .newsfeedController
                .replayModelList[widget.newsfeedController.currentIndexText]
                .linkImage = linkImage;
            return cardScrap(context, snapshot.data);
          } else if (snapshot.hasError) {
            print(snapshot.error.toString());
            return Container();
          }
          return Container(
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }

  SizedBox emojiSideBar() {
    return SizedBox(
        width: 50,
        child: ListView.builder(
            controller: _scrollController,
            itemCount: emojis.length,
            itemBuilder: (context, index) {
              final x = emojis[index].split(' ');
              return GestureDetector(
                  onTap: () {
                    _selectedTab = index;
                    _tabController.animateTo(index);
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(2),
                      margin: const EdgeInsets.all(2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: _selectedTab == index
                              ? Colors.grey.shade300
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(x[0], style: const TextStyle(fontSize: 25))));
            }));
  }
}
