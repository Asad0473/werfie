import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/follower_following_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/follower_following/follower_following_tab.dart';
import 'package:werfieapp/screens/topic_screens/other_topic_tab_screen.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/storage_helper.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/web_views/web_main_screen.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';

import '../models/category.dart';
import '../network/controller/other_topic_controller.dart';
import '../network/controller/profile_controller.dart';
import '../network/singleTone.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../widgets/blue_tick.dart';
import '../widgets/chat_screen_mobile.dart' as ChatScreenMob;
import '../widgets/thread_post_card.dart';

class OtherUsersProfile extends StatelessWidget {
  OtherUsersProfile({this.controller, this.userInfo, this.userId});

  final UserProfile userInfo;
   String userId="";
  final NewsfeedController controller;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Responsive(
        mobile: MobileOtherUsersProfile(
          newsfeedController: controller,
          userInfo: userInfo,
          userId: userId,
        ),
        tablet: MobileOtherUsersProfile(
          newsfeedController: controller,
          userInfo: userInfo,
          userId: userId,
        ),
        desktop: MobileOtherUsersProfile(
          newsfeedController: controller,
          userInfo: userInfo,
          userId: userId,
        ),
      ),
    );
  }
}

class MobileOtherUsersProfile extends StatefulWidget {
  MobileOtherUsersProfile(
      {this.newsfeedController, this.userInfo, this.userId});

  UserProfile userInfo;
  String userId;

  final NewsfeedController newsfeedController;

  @override
  State<MobileOtherUsersProfile> createState() =>
      _MobileOtherUsersProfileState();
}

class _MobileOtherUsersProfileState extends State<MobileOtherUsersProfile> {
  OtherTopicController topicController = Get.put(OtherTopicController());

  // ignore: unused_field
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final OtherUserController controller = Get.put(OtherUserController());

  @override
  void initState() {

    callApi();

    // TODO: implement initState
    if (kIsWeb) {

    } else {

      widget.newsfeedController.isChatCreatedYet = true;
      controller.update();
    }
    super.initState();
  }
  addProfileMetaTags(String name,String profileImage){

    MetaTags().addMetaTag(
        pageTitle: "$name ${MetaTagValues.pageTitleProfile}",
        metaTagDescription: "Follow $name ${MetaTagValues.profileMetaDescription}",
        metaTagKeywords: "$name${MetaTagValues.profileMetaKeywords}",
        ogTitle: "$name ${MetaTagValues.profileOGTitle}",
        ogDescription: "Follow $name ${MetaTagValues.profileOGDescription}",
        ogImage: profileImage
    );
  }

  Future<void> callApi() async {
    if(widget.userId!=null&&widget.userId.isNotEmpty){
      controller.newsFeedController.otherUserId=int.parse(widget.userId);
    }

    controller.newsFeedController.userInfo = null;
    controller.newsFeedController.getOtherUserProfile(
      controller.newsFeedController.otherUserId,
      isFromRoute: true,
    );
    addProfileMetaTags(controller.newsFeedController.otherUserProfile?.username ?? "", controller.newsFeedController.otherUserProfile?.profileImage ?? "");
    controller.userPosts = [];
    controller.userPosts = await controller.newsFeedController.filterUsersPost('posts');
    widget.newsfeedController.isChatCreatedYet = true;
    controller.update();

    // await widget.newsfeedController.getUserProfile(isFromRoute: true);
    //
    // print("widget.newsfeedController.userInfo.userId ${SingleTone.instance.userId}");
    //
    // if (GetStorage().read('id').toString() == SingleTone.instance.userId.toString()) {
    //   print(
    //       "widget.newsfeedController.userInfo.sameuserId ${SingleTone.instance.userId}");
    //
    //   if (Get.isRegistered<ProfileController>()) {
    //     await Get.find<ProfileController>().filterUsersPost("posts");
    //     Get.find<ProfileController>().isHiddenPost = false;
    //     Get.find<ProfileController>().isTweets = true;
    //     Get.find<ProfileController>().isTweetsReply = false;
    //     Get.find<ProfileController>().isMedia = false;
    //     Get.find<ProfileController>().isLikes = false;
    //     Get.find<ProfileController>().selectedTab = "isTweets";
    //     Get.find<ProfileController>().userProfile =
    //
    //     Get.find<ProfileController>().userPosts.forEach((element) {
    //       element.likeCount.value = element.simpleLikeCount;
    //       element.rebuzzCount.value = element.retweetCount;
    //       element.commentCount.value = element.commentsCount;
    //       element.reactionType.value = element.isLiked;
    //       // element.comments.forEach((
    //       //     element) {
    //       //   element.reactionType
    //       //       .value =
    //       //       element.isLiked;
    //       //   element.commentCount
    //       //       .value = element
    //       //       .simpleLikeCount;
    //       // });
    //       element.reactionType.refresh();
    //
    //       // if (element.isLiked == true) {
    //       //   element.like.value = true;
    //       //   element.like.refresh();
    //       // }
    //     });
    //     // Get.find<
    //     //     ProfileController>()
    //     //     .update();
    //   }
    //   else {
    //     print("vvvvv");
    //     Get.put(OtherUserController());
    //     Get.find<ProfileController>().userProfile = await widget.newsfeedController.getUserProfile(isFromRoute: true);
    //
    //     await Get.find<ProfileController>().filterUsersPost("posts");
    //     Get.find<ProfileController>().userPosts.forEach((element) {
    //       element.likeCount.value = element.simpleLikeCount;
    //       element.rebuzzCount.value = element.retweetCount;
    //       element.commentCount.value = element.commentsCount;
    //       element.reactionType.value = element.isLiked;
    //       // element.comments.forEach((element) {
    //       //   element.reactionType.value = element.isLiked;
    //       //   element.commentCount.value  = element.simpleLikeCount;
    //       // });
    //       element.reactionType.refresh();
    //
    //       // if (element.isLiked == true) {
    //       //   element.like.value = true;
    //       //   element.like.refresh();
    //       // }
    //     });
    //     Get.find<ProfileController>().update();
    //   }
    // }
    // else {
    //   print("hello other user profile");
    //
    //   await widget.newsfeedController.getOtherUserProfile(int.parse(SingleTone.instance.userId,),
    //       isFromRoute: true);
    //   // controller.update();
    //
    //   widget.newsfeedController.isLoading=false;
    //   //
    //   widget.newsfeedController.update();
    // }
  }

  @override
  Widget build(BuildContext context) {
    // print("widget.newsfeedController.userInfo.firstname${widget.newsfeedController.userInfo.totalPosts}");
    //
    // print("widget.newsfeedController.userInfo.userId ${widget.userInfo.toJson()}");

    final width = Get.width;
    final height = Get.height;
    return GetBuilder<OtherUserController>(builder: (controller) {
      return Scaffold(
          appBar: kIsWeb
              ? controller.newsFeedController.isLoading == false
                  ? PreferredSize(
                      preferredSize: const Size(double.infinity, 60),
                      child: ListTile(
                        leading: IconButton(
                          // splashColor: Colors.white,
                          // hoverColor: Colors.grey[100],
                          icon: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            size: 25,
                          ),
                          onPressed: () {
                            onHomeChange = true;
                            onBrowsChange = false;
                            onTrendsChange = false;
                            onBookMarksChange = false;
                            onChatsChange = false;
                            onProfileChange = false;
                            onSettingChange = false;
                            onListChange = false;
                            onNotificationChange = false;
                            onMoreChange = false;

                            controller.newsFeedController.isTrendsScreen =
                                false;
                            controller.newsFeedController.isNewsFeedScreen =
                                true;
                            controller.newsFeedController.isBrowseScreen =
                                false;
                            controller.newsFeedController.isNotificationScreen =
                                false;

                            controller.newsFeedController.isChatScreen = false;
                            controller.newsFeedController.isSavedPostScreen =
                                false;
                            controller.newsFeedController.isPostDetails = false;
                            controller.newsFeedController.isProfileScreen =
                                false;
                            controller.newsFeedController
                                .isOtherUserProfileScreen = false;

                            controller.newsFeedController.update();
                            Navigator.pop(context);

                            Get.delete<OtherUserController>();

                            if (!kIsWeb) {
                              Get.back();
                            }
                          },
                        ),
                        title: SizedBox(
                            height: 29,
                            child: kIsWeb &&
                                    controller.newsFeedController.userInfo !=
                                        null
                                ? Text(
                                    controller.newsFeedController.userInfo
                                            .firstname +
                                        ' ' +
                                        controller.newsFeedController.userInfo
                                            .lastname,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : Text(
                                    controller.userProfile == null
                                        ? ''
                                        : controller.userProfile.firstname +
                                            ' ' +
                                            controller.userProfile.lastname,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )),
                        subtitle: kIsWeb &&
                                controller.newsFeedController.userInfo != null
                            ? Text(
                                '${controller.newsFeedController.userInfo.totalPosts.toString()} Werfs',
                                style: Styles.baseTextTheme.headline5.copyWith(
                                    fontSize: 14, fontWeight: FontWeight.w400),
                              )
                            : Text(""),
                      ))
                  : PreferredSize(
                      preferredSize: const Size(double.infinity, 60),
                      child: ListTile(
                        leading: IconButton(
                          // splashColor: Colors.white,
                          // hoverColor: Colors.grey[100],
                          icon: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            size: 25,
                          ),
                          onPressed: () {
                            onHomeChange = true;
                            onBrowsChange = false;
                            onTrendsChange = false;
                            onBookMarksChange = false;
                            onChatsChange = false;
                            onProfileChange = false;
                            onSettingChange = false;
                            onListChange = false;
                            onNotificationChange = false;
                            onMoreChange = false;

                            controller.newsFeedController.isTrendsScreen =
                                false;
                            controller.newsFeedController.isNewsFeedScreen =
                                true;
                            controller.newsFeedController.isBrowseScreen =
                                false;
                            controller.newsFeedController.isNotificationScreen =
                                false;

                            controller.newsFeedController.isChatScreen = false;
                            controller.newsFeedController.isSavedPostScreen =
                                false;
                            controller.newsFeedController.isPostDetails = false;
                            controller.newsFeedController.isProfileScreen =
                                false;
                            controller.newsFeedController
                                .isOtherUserProfileScreen = false;

                            controller.newsFeedController.update();
                            Get.delete<OtherUserController>();
                            Get.back();
                          },
                        ),
                        title: SizedBox(
                            height: 29,
                            child: kIsWeb &&
                                    controller.newsFeedController.userInfo !=
                                        null
                                ? Text(
                                    controller.newsFeedController.userInfo
                                            .firstname +
                                        ' ' +
                                        controller.newsFeedController.userInfo
                                            .lastname,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : Text(
                                    controller.userProfile == null
                                        ? ''
                                        : controller.userProfile.firstname +
                                            ' ' +
                                            controller.userProfile.lastname,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )),
                        subtitle: kIsWeb &&
                                controller.newsFeedController.userInfo != null
                            ? controller.newsFeedController.userInfo
                                        .totalPosts !=
                                    null
                                ? Text(
                                    '${controller.newsFeedController.userInfo.totalPosts.toString()} Werfs',
                                    style: Styles.baseTextTheme.headline5
                                        .copyWith(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w400),
                                  )
                                : const Text("")
                            : const Text(""),
                      ))
              : AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  iconTheme: const IconThemeData(
                    color: Color(0xFF4f515b),
                  ),
                  centerTitle: false,
                  title: controller.newsFeedController.userInfo != null
                      ?
                  // SpinKitWave(
                  //         color: const Color(0xFFedab30),
                  //         size: 25.0,
                  //       )
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              controller.newsFeedController.userInfo.firstname +
                                  ' ' +
                                  controller
                                      .newsFeedController.userInfo.lastname,
                              textAlign: TextAlign.left,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            // Container(
                            //   height: 45,
                            //   width: MediaQuery.of(context).size.width / 1.8,
                            //   child: Center(
                            //     child: widget.userInfo == null
                            //         ? SpinKitWave(
                            //       color: Color(0xFFedab30),
                            //       size: 25.0,
                            //     )
                            //         : Text(
                            //       widget.userInfo.firstname + ' ' + widget.userInfo.lastname,
                            //       textAlign: TextAlign.left,
                            //
                            //       style: Styles.baseTextTheme.headline2.copyWith(
                            //         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                            //         fontWeight: FontWeight.bold,
                            //       ),
                            //     ),
                            //   ),
                            // ),

                            Text(
                              '${controller.newsFeedController.userInfo.totalPosts.toString()} Werfs',
                              style: Styles.baseTextTheme.headline5.copyWith(
                                  fontSize: 14, fontWeight: FontWeight.w400),
                            )
                          ],
                        )
                    :  const SizedBox()
            ,
                ),
          body: controller.newsFeedController.isLoading == true
              ? const Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                )
              : SizedBox(
                  height: MediaQuery.of(context).size.height,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10, bottom: 30),
                    child: controller.newsFeedController.isFilter == true
                        ? const Center(
                            child: CircularProgressIndicator(
                            color: MyColors.BlueColor,
                          ))
                        :
                    controller.userPosts == null ||
                                controller.userPosts.isEmpty
                            ?
                             SingleChildScrollView(
                                //MAIN SCREEN VIEW
                                child: Container(
                                  decoration: BoxDecoration(
                                      border:
                                          Border.all(color: Colors.grey[100])),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Stack(
                                        clipBehavior: Clip.antiAlias,
                                        alignment: Alignment.bottomLeft,
                                        children: [
                                          // COVER PHOTO

                                          /* kIsWeb &&*/
                                          widget.newsfeedController.userInfo !=
                                                  null
                                              ? InkWell(
                                                  onTap: () {
                                                    showDialog(
                                                      useSafeArea: false,
                                                      context: context,
                                                      builder: (context) {
                                                        return AlertDialog(
                                                          insetPadding:
                                                              EdgeInsets.zero,
                                                          contentPadding:
                                                              EdgeInsets.zero,
                                                          content: Stack(
                                                            children: [
                                                              Container(
                                                                color: Colors
                                                                    .black,
                                                                width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width,
                                                                height: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .height,
                                                                child:
                                                                    FadeInImage(
                                                                  placeholderErrorBuilder:
                                                                      (context,
                                                                          _,
                                                                          __) {
                                                                    return Image
                                                                        .asset(
                                                                            'assets/images/person_placeholder.png');
                                                                  },
                                                                  imageErrorBuilder:
                                                                      (context,
                                                                          _,
                                                                          __) {
                                                                    return Image
                                                                        .asset(
                                                                            'assets/images/person_placeholder.png');
                                                                  },
                                                                  fit: BoxFit
                                                                      .contain,
                                                                  width: 24,
                                                                  height: 24,
                                                                  placeholder:
                                                                      const AssetImage(
                                                                          'assets/images/person_placeholder.png'),
                                                                  image: NetworkImage(widget
                                                                          .newsfeedController
                                                                          .userInfo
                                                                          .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                top: kIsWeb
                                                                    ? 10
                                                                    : 30,
                                                                left: 10,
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    Navigator.pop(
                                                                        context);
                                                                  },
                                                                  child: const Icon(
                                                                    Icons
                                                                        .cancel,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      },
                                                    );
                                                  },
                                                  child: Container(
                                                      width: Get.width,
                                                      height: kIsWeb
                                                          ? Get.height / 3.5
                                                          : Get.height / 4.5,
                                                      color: Colors.grey[200],
                                                      margin: EdgeInsets.only(
                                                          bottom:
                                                              Get.height / 15),
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(25),
                                                        child: FadeInImage(
                                                            placeholderErrorBuilder:
                                                                (context, _,
                                                                    __) {
                                                              return Image.asset(
                                                                  'assets/images/person_placeholder.png');
                                                            },
                                                            imageErrorBuilder:
                                                                (context, _,
                                                                    __) {
                                                              return Image.asset(
                                                                  'assets/images/person_placeholder.png');
                                                            },
                                                            fit: BoxFit.cover,
                                                            width: 24,
                                                            height: 24,
                                                            placeholder: const AssetImage(
                                                                'assets/images/person_placeholder.png'),
                                                            image: NetworkImage(widget
                                                                    .newsfeedController
                                                                    .userInfo
                                                                    .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                      )),
                                                )
                                              : InkWell(
                                                  onTap: () {
                                                    showDialog(
                                                      useSafeArea: false,
                                                      context: context,
                                                      builder: (context) {
                                                        return AlertDialog(
                                                          insetPadding:
                                                              EdgeInsets.zero,
                                                          contentPadding:
                                                              EdgeInsets.zero,
                                                          content: Stack(
                                                            children: [
                                                              Container(
                                                                color: Colors
                                                                    .black,
                                                                width: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .width,
                                                                height: MediaQuery.of(
                                                                        context)
                                                                    .size
                                                                    .height,
                                                                child:
                                                                    FadeInImage(
                                                                  placeholderErrorBuilder:
                                                                      (context,
                                                                          _,
                                                                          __) {
                                                                    return Image
                                                                        .asset(
                                                                            'assets/images/person_placeholder.png');
                                                                  },
                                                                  imageErrorBuilder:
                                                                      (context,
                                                                          _,
                                                                          __) {
                                                                    return Image
                                                                        .asset(
                                                                            'assets/images/person_placeholder.png');
                                                                  },
                                                                  fit: BoxFit
                                                                      .contain,
                                                                  width: 24,
                                                                  height: 24,
                                                                  placeholder:
                                                                      const AssetImage(
                                                                          'assets/images/person_placeholder.png'),
                                                                  image: NetworkImage(widget
                                                                          .userInfo
                                                                          .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                top: kIsWeb
                                                                    ? 10
                                                                    : 30,
                                                                left: 10,
                                                                child: InkWell(
                                                                  onTap: () {
                                                                    Get.back();
                                                                  },
                                                                  child: const Icon(
                                                                    Icons
                                                                        .cancel,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        );
                                                      },
                                                    );
                                                  },
                                                  child: Container(
                                                      width: Get.width,
                                                      height: kIsWeb
                                                          ? Get.height / 3.5
                                                          : Get.height / 4.5,
                                                      color: Colors.grey[200],
                                                      margin: EdgeInsets.only(
                                                          bottom:
                                                              Get.height / 15),
                                                      child:
                                                          widget.userInfo ==
                                                                  null
                                                              ? const SizedBox()
                                                              : ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              25),
                                                                  child:
                                                                      FadeInImage(
                                                                          placeholderErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          imageErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          fit: BoxFit
                                                                              .cover,
                                                                          width:
                                                                              24,
                                                                          height:
                                                                              24,
                                                                          placeholder: const AssetImage(
                                                                              'assets/images/person_placeholder.png'),
                                                                          image: NetworkImage(widget.userInfo.coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                                )),
                                                ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                left: 20.0,
                                                right: kIsWeb ? 40.0 : 20.0),
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.end,
                                              children: [
                                                /* kIsWeb && */
                                                widget.newsfeedController
                                                            .userInfo !=
                                                        null
                                                    ? InkWell(
                                                        onTap: () {
                                                          showDialog(
                                                              useSafeArea:
                                                                  false,
                                                              context: context,
                                                              builder:
                                                                  (context) {
                                                                return AlertDialog(
                                                                  insetPadding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  contentPadding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  content:
                                                                      Stack(
                                                                    children: [
                                                                      Container(
                                                                        color: Colors
                                                                            .black,
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height: MediaQuery.of(context)
                                                                            .size
                                                                            .height,
                                                                        child:
                                                                            FadeInImage(
                                                                          placeholderErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          imageErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          fit: BoxFit
                                                                              .contain,
                                                                          width:
                                                                              150,
                                                                          height:
                                                                              150,
                                                                          placeholder:
                                                                              const AssetImage('assets/images/person_placeholder.png'),
                                                                          image: NetworkImage(widget.newsfeedController.userInfo.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                                        ),
                                                                      ),
                                                                      Positioned(
                                                                        top: kIsWeb
                                                                            ? 10
                                                                            : 30,
                                                                        left:
                                                                            10,
                                                                        child:
                                                                            InkWell(
                                                                          onTap:
                                                                              () {
                                                                            Navigator.pop(context);
                                                                          },
                                                                          child:
                                                                              const Icon(
                                                                            Icons.cancel,
                                                                            color:
                                                                                Colors.white,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                );
                                                              });
                                                        },
                                                        child: CircleAvatar(
                                                          radius:
                                                              kIsWeb ? 80 : 70,
                                                          backgroundColor:
                                                              Colors.white,
                                                          child: CircleAvatar(
                                                              radius: kIsWeb
                                                                  ? 75
                                                                  : 65,
                                                              backgroundColor:
                                                                  Colors.white,
                                                              child: widget
                                                                          .newsfeedController
                                                                          .userInfo ==
                                                                      null
                                                                  ? const CircularProgressIndicator(
                                                                      color: MyColors
                                                                          .BlueColor,
                                                                    )
                                                                  : ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(kIsWeb
                                                                              ? 80
                                                                              : 70),
                                                                      child: FadeInImage(
                                                                          placeholderErrorBuilder: (context, _, __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          imageErrorBuilder: (context, _, __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          fit: BoxFit.cover,
                                                                          width: 150,
                                                                          height: 150,
                                                                          placeholder: const AssetImage('assets/images/person_placeholder.png'),
                                                                          image: NetworkImage(widget.newsfeedController.userInfo.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                                    )),
                                                        ),
                                                      )
                                                    : InkWell(
                                                        onTap: () {
                                                          showDialog(
                                                              useSafeArea:
                                                                  false,
                                                              context: context,
                                                              builder:
                                                                  (context) {
                                                                return AlertDialog(
                                                                  insetPadding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  contentPadding:
                                                                      EdgeInsets
                                                                          .zero,
                                                                  content:
                                                                      Stack(
                                                                    children: [
                                                                      Container(
                                                                        color: Colors
                                                                            .black,
                                                                        width: MediaQuery.of(context)
                                                                            .size
                                                                            .width,
                                                                        height: MediaQuery.of(context)
                                                                            .size
                                                                            .height,
                                                                        child:
                                                                            FadeInImage(
                                                                          placeholderErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          imageErrorBuilder: (context,
                                                                              _,
                                                                              __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          fit: BoxFit
                                                                              .contain,
                                                                          width:
                                                                              150,
                                                                          height:
                                                                              150,
                                                                          placeholder:
                                                                              const AssetImage('assets/images/person_placeholder.png'),
                                                                          image: NetworkImage(widget.userInfo.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                                        ),
                                                                      ),
                                                                      Positioned(
                                                                        top: kIsWeb
                                                                            ? 10
                                                                            : 30,
                                                                        left:
                                                                            10,
                                                                        child:
                                                                            InkWell(
                                                                          onTap:
                                                                              () {
                                                                            Get.back();
                                                                          },
                                                                          child:
                                                                              const Icon(
                                                                            Icons.cancel,
                                                                            color:
                                                                                Colors.white,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                );
                                                              });
                                                        },
                                                        child: CircleAvatar(
                                                          radius:
                                                              kIsWeb ? 80 : 70,
                                                          backgroundColor:
                                                              Colors.white,
                                                          child: CircleAvatar(
                                                              radius: kIsWeb
                                                                  ? 75
                                                                  : 65,
                                                              backgroundColor:
                                                                  Colors.white,
                                                              child: widget
                                                                          .userInfo ==
                                                                      null
                                                                  ? const CircularProgressIndicator(
                                                                      color: MyColors
                                                                          .BlueColor,
                                                                    )
                                                                  : ClipRRect(
                                                                      borderRadius:
                                                                          BorderRadius.circular(kIsWeb
                                                                              ? 80
                                                                              : 70),
                                                                      child: FadeInImage(
                                                                          placeholderErrorBuilder: (context, _, __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          imageErrorBuilder: (context, _, __) {
                                                                            return Image.asset('assets/images/person_placeholder.png');
                                                                          },
                                                                          fit: BoxFit.cover,
                                                                          width: 150,
                                                                          height: 150,
                                                                          placeholder: const AssetImage('assets/images/person_placeholder.png'),
                                                                          image: NetworkImage(widget.userInfo.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                                    )),
                                                        ),
                                                      ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: EdgeInsets.zero,
                                        child: Column(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 20.0,
                                                  top: 2,
                                                  bottom: 0,
                                                  right: 20.0),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  ///menu
                                                  Row(
                                                    children: [
                                                      const Spacer(),
                                                     /* Container(
                                                          height: 30,
                                                          width: 30,
                                                          decoration:
                                                              BoxDecoration(
                                                            shape:
                                                                BoxShape.circle,
                                                            border: Border.all(
                                                                width: 1,
                                                                color: Colors
                                                                    .grey),
                                                          ),
                                                          child: myPopMenu(widget
                                                              .newsfeedController
                                                              .othersUserid)),*/
                                                      const SizedBox(
                                                        width: 10,
                                                      ),
                                                      widget.newsfeedController
                                                                  .isChatCreatedYet ==
                                                              false
                                                          ? const Center(
                                                              child:
                                                                  CircularProgressIndicator(
                                                                color: MyColors
                                                                    .BlueColor,
                                                              ),
                                                            )
                                                          : InkWell(
                                                              onTap: () {
                                                                createAndGotoChats();
                                                              },
                                                              child: Container(
                                                                  height: 30,
                                                                  width: 30,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    border: Border.all(
                                                                        width:
                                                                            1,
                                                                        color: Colors
                                                                            .grey),
                                                                  ),
                                                                  child:
                                                                      Container(
                                                                    padding:
                                                                        const EdgeInsets.all(
                                                                            3.0),
                                                                    child: SvgPicture
                                                                        .asset(
                                                                      'assets/svg_drawer_icons/messages.svg',
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                    ),
                                                                  )),
                                                            ),
                                                      const SizedBox(
                                                        width: 10,
                                                      ),
                                                      /*kIsWeb&&*/
                                                      widget.newsfeedController
                                                                  .userInfo !=
                                                              null
                                                          ? widget.newsfeedController
                                                                      .isLoading ==
                                                                  true
                                                              ? const Center(
                                                                  child:
                                                                      CircularProgressIndicator(
                                                                    color: MyColors
                                                                        .BlueColor,
                                                                  ),
                                                                )
                                                              : Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .topRight,
                                                                  child: UnfollowBtnWidget(
                                                                      controller),
                                                                )
                                                          : widget.userInfo ==
                                                                  null
                                                              ? const SizedBox()
                                                              : widget.newsfeedController
                                                                          .isLoading ==
                                                                      true
                                                                  ? const Center(
                                                                      child:
                                                                          CircularProgressIndicator(
                                                                        color: MyColors
                                                                            .BlueColor,
                                                                      ),
                                                                    )
                                                                  : Align(
                                                                      alignment:
                                                                          Alignment
                                                                              .topRight,
                                                                      child: UnfollowBtnWidget(
                                                                          controller),
                                                                    ),
                                                    ],
                                                  ),
                                                  /* kIsWeb &&*/
                                                  widget.newsfeedController
                                                              .userInfo !=
                                                          null
                                                      ? Row(
                                                          children: [
                                                            Text(
                                                              "${widget.newsfeedController.userInfo.firstname} ${widget.newsfeedController.userInfo.lastname}",
                                                              // style: TextStyle(
                                                              //     fontSize: kIsWeb ? 20.0 : 16.0,
                                                              //     color: Colors.black),
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline2
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                              ),
                                                            ),
                                                            const SizedBox(
                                                              width: 5,
                                                            ),
                                                            widget
                                                                        .newsfeedController
                                                                        .userInfo
                                                                        .accountVerified ==
                                                                    "verified"
                                                                ? BlueTick(
                                                                    height: 15,
                                                                    width: 15,
                                                                    iconSize:
                                                                        10,
                                                                  )
                                                                : SizedBox(),
                                                          ],
                                                        )
                                                      : widget.userInfo == null
                                                          ? const SizedBox()
                                                          : Row(
                                                              children: [
                                                                Text(
                                                                  "${widget.userInfo.firstname} ${widget.userInfo.lastname}",
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline2
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    overflow: TextOverflow.ellipsis,

                                                                  ),

                                                                  // style: TextStyle(
                                                                  //     fontSize: kIsWeb ? 20.0 : 16.0,
                                                                  //     color: Colors.black),
                                                                ),
                                                                const SizedBox(
                                                                  width: 2,
                                                                ),
                                                                widget.userInfo
                                                                            .accountVerified ==
                                                                        "verified"
                                                                    ? BlueTick(
                                                                        height:
                                                                            15,
                                                                        width:
                                                                            15,
                                                                        iconSize:
                                                                            10,
                                                                      )
                                                                    : const SizedBox(),
                                                              ],
                                                            ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  /* kIsWeb &&*/
                                                  widget.newsfeedController
                                                              .userInfo !=
                                                          null
                                                      ? Row(
                                                          children: [
                                                            Text(
                                                              "@${widget.newsfeedController.userInfo.username}",
                                                              // style: TextStyle(
                                                              //   fontSize: kIsWeb ? 18.0 : 14.0,
                                                              // ),
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline5
                                                                  .copyWith(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      : Text(
                                                          widget.userInfo ==
                                                                  null
                                                              ? ""
                                                              : "@${widget.userInfo.username}",
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline5
                                                              .copyWith(
                                                            fontWeight:
                                                                FontWeight.w400,
                                                          ),
                                                        ),
                                                  // /* kIsWeb &&*/ widget.newsfeedController.userInfo!=null?
                                                  //  Text(
                                                  //   "${widget.newsfeedController.userInfo.email}",
                                                  //    style:  Styles.baseTextTheme.headline5.copyWith(
                                                  //      fontWeight: FontWeight.w400,
                                                  //    ),
                                                  //  ):
                                                  //  Text(
                                                  //    widget.userInfo == null ? "" : "${widget.userInfo.email}",
                                                  //    style: Styles.baseTextTheme.headline5.copyWith(
                                                  //      fontWeight: FontWeight.w400,
                                                  //    ),
                                                  //  ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  /* kIsWeb &&*/
                                                  widget.newsfeedController
                                                              .userInfo !=
                                                          null
                                                      ? widget.newsfeedController
                                                                  .userInfo ==
                                                              null
                                                          ? const SizedBox()
                                                          : widget
                                                                      .newsfeedController
                                                                      .userInfo
                                                                      .bio ==
                                                                  null
                                                              ? const SizedBox()
                                                              : Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    // Icon(
                                                                    //   Icons.calendar_today_outlined,
                                                                    //   color: Colors.grey[300],
                                                                    // ),
                                                                    // SizedBox(
                                                                    //   width: 10.0,
                                                                    // ),
                                                                    Expanded(
                                                                      child:
                                                                          Align(
                                                                        alignment:
                                                                            Alignment.topLeft,
                                                                        child:
                                                                            Text(
                                                                          "${widget.newsfeedController.userInfo.bio}",
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline5
                                                                              .copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                                ? Colors.white
                                                                                : Colors.black,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                )
                                                      : widget.userInfo == null
                                                          ? const SizedBox()
                                                          : widget.userInfo
                                                                      .bio ==
                                                                  null
                                                              ? const SizedBox()
                                                              : Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    const Icon(
                                                                      Icons
                                                                          .calendar_today_outlined,
                                                                      color: Color(
                                                                          0xFF586976),
                                                                    ),
                                                                    const SizedBox(
                                                                      width:
                                                                          10.0,
                                                                    ),
                                                                    Expanded(
                                                                      child:
                                                                          Align(
                                                                        alignment:
                                                                            Alignment.topLeft,
                                                                        child:
                                                                            Text(
                                                                          "${widget.userInfo.bio}",
                                                                          // style: TextStyle(
                                                                          //     height: 1.2,
                                                                          //     fontSize:
                                                                          //         kIsWeb ? 18.0 : 14.0),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline5
                                                                              .copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                                ? Colors.white
                                                                                : Colors.black,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                          ),
                                                                          maxLines:
                                                                              3,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                  const SizedBox(
                                                    height: 5,
                                                  ),
                                                  /*  kIsWeb &&*/
                                                  widget.newsfeedController
                                                              .userInfo !=
                                                          null
                                                      ? Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            TextButton(
                                                              onPressed: kIsWeb
                                                                  ? () async {
                                                                      /*   Get.put(FollowerController());
                                            Get.find<FollowerController>()
                                                .getFollower(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .getFollowing(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .followingCheck = 1;
                                            Get.find<FollowerController>()
                                                .update();
                                            controller.newsFeedController.isSearch = false;
                                            controller.isFilter = false;
                                            controller.newsFeedController
                                                .isFilterScreen = false;
                                            controller.newsFeedController
                                                .isTrendsScreen = false;
                                            controller.newsFeedController
                                                .isNewsFeedScreen = false;
                                            controller.newsFeedController
                                                .isBrowseScreen = false;
                                            controller.newsFeedController
                                                .isNotificationScreen = false;
                                            controller.newsFeedController
                                                .isSavedPostScreen = false;
                                            controller.newsFeedController
                                                .isChatScreen = false;
                                            controller.newsFeedController
                                                .isPostDetails = false;
                                            controller.newsFeedController
                                                .isProfileScreen = false;
                                            controller.newsFeedController
                                                .isOtherUserProfileScreen = false;
                                            controller.newsFeedController
                                                .isFollwerScreen = true;
                                            controller.newsFeedController
                                                .navRoute = "isOtherUserScreen";
                                            controller.newsFeedController
                                                .update();*/
                                                                      // SingleTone.instance.userId=post.authorId.toString();
                                                                    await  Get.put(
                                                                          FollowerController());
                                                                   /*   Get.find<FollowerController>().getFollower(
                                                                          userId: controller
                                                                              .newsFeedController
                                                                              .othersUserid);
                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId: controller
                                                                              .newsFeedController
                                                                              .othersUserid);*/
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 1;
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                      Get.toNamed(FluroRouters
                                                                              .mainScreen +
                                                                          "/followings/" +
                                                                          controller
                                                                              .newsFeedController
                                                                              .othersUserid
                                                                              .toString());
                                                                    }
                                                                  : () {
                                                                      Get.delete<
                                                                          OtherUserController>();
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId: controller
                                                                              .newsFeedController
                                                                              .othersUserid);
                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 1;
                                                                      Navigator.push(
                                                                          context,
                                                                          MaterialPageRoute(
                                                                              builder: (BuildContext context) => FollowerScreen(
                                                                                    isOtherUserProfile: true,
                                                                                    controller: controller.newsFeedController,
                                                                                  )));

                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                    },
                                                              child: Row(
                                                                children: [
                                                                  Text(
                                                                    "${widget.newsfeedController.userInfo.followings} ",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    Strings
                                                                        .followings,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            const SizedBox(
                                                              width: 15,
                                                            ),
                                                            TextButton(
                                                              onPressed: kIsWeb
                                                                  ? () {
                                                                      /*  Get.put(FollowerController());
                                            Get.find<FollowerController>()
                                                .getFollower(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .getFollowing(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .followingCheck = 0;
                                            Get.find<FollowerController>()
                                                .update();
                                            controller.newsFeedController
                                                .isSearch = false;
                                            controller.isFilter = false;
                                            controller.newsFeedController
                                                .isFilterScreen = false;
                                            controller.newsFeedController
                                                .isTrendsScreen = false;
                                            controller.newsFeedController
                                                .isNewsFeedScreen = false;
                                            controller.newsFeedController
                                                .isBrowseScreen = false;
                                            controller.newsFeedController
                                                .isNotificationScreen = false;
                                            controller.newsFeedController
                                                .isSavedPostScreen = false;
                                            controller.newsFeedController
                                                .isChatScreen = false;
                                            controller.newsFeedController
                                                .isPostDetails = false;
                                            controller.newsFeedController
                                                .isProfileScreen = false;
                                            controller.newsFeedController
                                                .isOtherUserProfileScreen = false;
                                            controller.newsFeedController
                                                .isFollwerScreen = true;
                                            controller.newsFeedController
                                                .navRoute = "isOtherUserScreen";
                                            controller.newsFeedController
                                                .update();*/
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId: controller
                                                                              .newsFeedController
                                                                              .othersUserid);
                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId: controller
                                                                              .newsFeedController
                                                                              .othersUserid);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 0;
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                      Get.toNamed(FluroRouters
                                                                              .mainScreen +
                                                                          "/followers/" +
                                                                          controller
                                                                              .newsFeedController
                                                                              .othersUserid
                                                                              .toString());
                                                                    }
                                                                  : () {
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 0;

                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId:
                                                                              controller.userId);
                                                                      Navigator.push(
                                                                          context,
                                                                          MaterialPageRoute(
                                                                              builder: (BuildContext context) => FollowerScreen(
                                                                                    controller: controller.newsFeedController,
                                                                                  )));
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                    },
                                                              child: Row(
                                                                children: [
                                                                  Text(
                                                                    "${widget.newsfeedController.userInfo.followers} ",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    Strings
                                                                        .followers,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      : Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            TextButton(
                                                              onPressed: kIsWeb
                                                                  ? () {
                                                                      /*  Get.put(FollowerController());
                                                  Get.find<FollowerController>()
                                                      .getFollower(
                                                          userId: controller.userId);
                                                  Get.find<FollowerController>()
                                                      .getFollowing(
                                                          userId: controller.userId);
                                                  Get.find<FollowerController>()
                                                      .followingCheck = 1;
                                                  Get.find<FollowerController>()
                                                      .update();
                                                  controller.newsFeedController
                                                      .isSearch = false;
                                                  controller.isFilter = false;
                                                  controller.newsFeedController
                                                      .isFilterScreen = false;
                                                  controller.newsFeedController
                                                      .isTrendsScreen = false;
                                                  controller.newsFeedController
                                                      .isNewsFeedScreen = false;
                                                  controller.newsFeedController
                                                      .isBrowseScreen = false;
                                                  controller.newsFeedController
                                                      .isNotificationScreen = false;
                                                  controller.newsFeedController
                                                      .isSavedPostScreen = false;
                                                  controller.newsFeedController
                                                      .isChatScreen = false;
                                                  controller.newsFeedController
                                                      .isPostDetails = false;
                                                  controller.newsFeedController
                                                      .isProfileScreen = false;
                                                  controller.newsFeedController
                                                      .isOtherUserProfileScreen = false;
                                                  controller.newsFeedController
                                                      .isFollwerScreen = true;
                                                  controller.newsFeedController
                                                      .navRoute = "isOtherUserScreen";
                                                  controller.newsFeedController
                                                      .update();*/
                                                                      Get.toNamed(FluroRouters
                                                                              .mainScreen +
                                                                          "/followers/" +
                                                                          controller
                                                                              .newsFeedController
                                                                              .othersUserid
                                                                              .toString());
                                                                    }
                                                                  : () {
                                                                      Get.delete<
                                                                          OtherUserController>();
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 1;
                                                                      Navigator.push(
                                                                          context,
                                                                          MaterialPageRoute(
                                                                              builder: (BuildContext context) => FollowerScreen(
                                                                                    isOtherUserProfile: true,
                                                                                    controller: controller.newsFeedController,
                                                                                  )));

                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                    },
                                                              child: Row(
                                                                children: [
                                                                  Text(
                                                                    widget.userInfo ==
                                                                            null
                                                                        ? ""
                                                                        : "${widget.userInfo.followings} ",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    Strings
                                                                        .followings,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            const SizedBox(
                                                              width: 15,
                                                            ),
                                                            TextButton(
                                                              onPressed: kIsWeb
                                                                  ? () {
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 0;
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                      controller
                                                                          .newsFeedController
                                                                          .isSearch = false;
                                                                      controller
                                                                              .isFilter =
                                                                          false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isFilterScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isTrendsScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isNewsFeedScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isBrowseScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isNotificationScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isSavedPostScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isChatScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isPostDetails = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isProfileScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isOtherUserProfileScreen = false;
                                                                      controller
                                                                          .newsFeedController
                                                                          .isFollwerScreen = true;
                                                                      controller
                                                                          .newsFeedController
                                                                          .navRoute = "isOtherUserScreen";
                                                                      controller
                                                                          .newsFeedController
                                                                          .update();
                                                                    }
                                                                  : () {
                                                                      Get.put(
                                                                          FollowerController());
                                                                      Get.find<FollowerController>().getFollower(
                                                                          userId:
                                                                              controller.userId);
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .followingCheck = 0;

                                                                      Get.find<FollowerController>().getFollowing(
                                                                          userId:
                                                                              controller.userId);
                                                                      Navigator.push(
                                                                          context,
                                                                          MaterialPageRoute(
                                                                              builder: (BuildContext context) => FollowerScreen(
                                                                                    controller: controller.newsFeedController,
                                                                                  )));
                                                                      Get.find<
                                                                              FollowerController>()
                                                                          .update();
                                                                    },
                                                              child: Row(
                                                                children: [
                                                                  Text(
                                                                    widget.userInfo ==
                                                                            null
                                                                        ? ""
                                                                        : "${widget.userInfo.followers} ",
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    Strings
                                                                        .followers,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      fontSize: kIsWeb
                                                                          ? 16.0
                                                                          : 14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),

                                                  // SizedBox(
                                                  //   height: height / 20,
                                                  // ),
                                                ],
                                              ),
                                            ),
                                            kIsWeb
                                                ? Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    TabButton(
                                                      title: Strings.werfs,
                                                      onTap: () async {
                                                        controller
                                                                .isTweets =
                                                            true;
                                                        controller
                                                                .isTweetsReply =
                                                            false;
                                                        controller.isMedia =
                                                            false;
                                                        controller.isLikes =
                                                            false;
                                                        controller.selectedTab = "isTweets";
                                                        controller.update();
                                                        controller.userPosts = await widget.newsfeedController.filterUsersPost("posts");
                                                        controller.userPosts
                                                            .forEach(
                                                                (element) {
                                                          element.likeCount
                                                                  .value =
                                                              element
                                                                  .simpleLikeCount;
                                                          element.rebuzzCount
                                                                  .value =
                                                              element
                                                                  .retweetCount;
                                                          element.commentCount
                                                                  .value =
                                                              element
                                                                  .commentsCount;
                                                          if (element
                                                                  .isLiked ==
                                                              true) {
                                                            element.like
                                                                    .value =
                                                                true;
                                                            element.like
                                                                .refresh();
                                                          }
                                                        });
                                                        // controller.filterUsersPost(
                                                        //   id: controller.searchSelected.id,
                                                        //   type: controller.searchSelected.type,
                                                        // );

                                                        controller.update();
                                                      },
                                                      isSelected: controller
                                                          .isTweets,
                                                    ),
                                                    TabButton(
                                                      title: kIsWeb
                                                          ? Strings
                                                              .tweetsAndReplies
                                                          : Strings
                                                              .tweetsAndReplies,
                                                      onTap: () async {
                                                        controller
                                                                .isTweets =
                                                            false;
                                                        controller
                                                                .isTweetsReply =
                                                            true;
                                                        controller.isMedia =
                                                            false;
                                                        controller.isLikes =
                                                            false;
                                                        controller
                                                                .selectedTab =
                                                            "isTweetsReply";
                                                        controller.update();
                                                        controller
                                                                .userPosts =
                                                            await widget
                                                                .newsfeedController
                                                                .filterUsersPost(
                                                                    "post_commented");

                                                        controller.userPosts
                                                            .forEach(
                                                                (element) {
                                                          element.likeCount
                                                                  .value =
                                                              element
                                                                  .simpleLikeCount;
                                                          element.rebuzzCount
                                                                  .value =
                                                              element
                                                                  .retweetCount;
                                                          element.commentCount
                                                                  .value =
                                                              element
                                                                  .commentsCount;
                                                          if (element
                                                                  .isLiked ==
                                                              true) {
                                                            element.like
                                                                    .value =
                                                                true;
                                                            element.like
                                                                .refresh();
                                                          }
                                                        });
                                                        // controller.filterUsers(
                                                        //   id: controller.searchSelected.id,
                                                        //   type: controller.searchSelected.type,
                                                        // );

                                                        controller.update();
                                                      },
                                                      isSelected: controller
                                                          .isTweetsReply,
                                                    ),
                                                    TabButton(
                                                      title: Strings.media,
                                                      onTap: () async {
                                                        controller
                                                                .isTweets =
                                                            false;
                                                        controller
                                                                .isTweetsReply =
                                                            false;
                                                        controller.isMedia =
                                                            true;
                                                        controller.isLikes =
                                                            false;
                                                        controller
                                                                .selectedTab =
                                                            "isMedia";
                                                        controller.update();
                                                        controller
                                                                .userPosts =
                                                            await widget
                                                                .newsfeedController
                                                                .filterUsersPost(
                                                                    "media");
                                                        controller.userPosts
                                                            .forEach(
                                                                (element) {
                                                          element.likeCount
                                                                  .value =
                                                              element
                                                                  .simpleLikeCount;
                                                          element.rebuzzCount
                                                                  .value =
                                                              element
                                                                  .retweetCount;
                                                          element.commentCount
                                                                  .value =
                                                              element
                                                                  .commentsCount;
                                                          if (element
                                                                  .isLiked ==
                                                              true) {
                                                            element.like
                                                                    .value =
                                                                true;
                                                            element.like
                                                                .refresh();
                                                          }
                                                        });
                                                        // controller.filterUsers(
                                                        //   id: controller.searchSelected.id,
                                                        //   type: controller.searchSelected.type,
                                                        // );

                                                        controller.update();
                                                      },
                                                      isSelected: controller
                                                          .isMedia,
                                                    ),
                                                    TabButton(
                                                      title: Strings.likes,
                                                      onTap: () async {
                                                        controller
                                                                .isTweets =
                                                            false;
                                                        controller
                                                                .isTweetsReply =
                                                            false;
                                                        controller.isMedia =
                                                            false;
                                                        controller.isLikes =
                                                            true;
                                                        controller
                                                                .selectedTab =
                                                            "isLikes";
                                                        controller.update();
                                                        controller
                                                                .userPosts =
                                                            await widget
                                                                .newsfeedController
                                                                .filterUsersPost(
                                                                    "likes");
                                                        controller.userPosts
                                                            .forEach(
                                                                (element) {
                                                          element.likeCount
                                                                  .value =
                                                              element
                                                                  .simpleLikeCount;
                                                          element.rebuzzCount
                                                                  .value =
                                                              element
                                                                  .retweetCount;
                                                          element.commentCount
                                                                  .value =
                                                              element
                                                                  .commentsCount;
                                                          if (element
                                                                  .isLiked ==
                                                              true) {
                                                            element.like
                                                                    .value =
                                                                true;
                                                            element.like
                                                                .refresh();
                                                          }
                                                        });
                                                        // controller.filterUsers(
                                                        //   id: controller.searchSelected.id,
                                                        //   type: controller.searchSelected.type,
                                                        // );

                                                        controller.update();
                                                      },
                                                      isSelected: controller
                                                          .isLikes,
                                                    ),
                                                  ],
                                                )
                                                : FittedBox(
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: [
                                                      TabButton(
                                                        title:
                                                            Strings.werfs,
                                                        onTap: () async {
                                                          controller
                                                                  .isTweets =
                                                              true;
                                                          controller
                                                                  .isTweetsReply =
                                                              false;
                                                          controller
                                                                  .isMedia =
                                                              false;
                                                          controller
                                                                  .isLikes =
                                                              false;
                                                          controller
                                                                  .selectedTab =
                                                              "isTweets";
                                                          controller
                                                              .update();
                                                          controller
                                                                  .userPosts =
                                                              await widget
                                                                  .newsfeedController
                                                                  .filterUsersPost(
                                                                      "posts");
                                                          controller
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element.likeCount
                                                                    .value =
                                                                element
                                                                    .simpleLikeCount;
                                                            element.rebuzzCount
                                                                    .value =
                                                                element
                                                                    .retweetCount;
                                                            element.commentCount
                                                                    .value =
                                                                element
                                                                    .commentsCount;
                                                            if (element
                                                                    .isLiked ==
                                                                true) {
                                                              element.like
                                                                      .value =
                                                                  true;
                                                              element.like
                                                                  .refresh();
                                                            }
                                                          });
                                                          // controller.filterUsersPost(
                                                          //   id: controller.searchSelected.id,
                                                          //   type: controller.searchSelected.type,
                                                          // );

                                                          controller
                                                              .update();
                                                        },
                                                        isSelected:
                                                            controller
                                                                .isTweets,
                                                      ),
                                                      TabButton(
                                                        title: kIsWeb
                                                            ? Strings
                                                                .tweetsAndReplies
                                                            : Strings
                                                                .tweetsAndReplies,
                                                        onTap: () async {
                                                          controller
                                                                  .isTweets =
                                                              false;
                                                          controller
                                                                  .isTweetsReply =
                                                              true;
                                                          controller
                                                                  .isMedia =
                                                              false;
                                                          controller
                                                                  .isLikes =
                                                              false;
                                                          controller
                                                                  .selectedTab =
                                                              "isTweetsReply";
                                                          controller
                                                              .update();
                                                          controller
                                                                  .userPosts =
                                                              await widget
                                                                  .newsfeedController
                                                                  .filterUsersPost(
                                                                      "post_commented");
                                                          controller
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element.likeCount
                                                                    .value =
                                                                element
                                                                    .simpleLikeCount;
                                                            element.rebuzzCount
                                                                    .value =
                                                                element
                                                                    .retweetCount;
                                                            element.commentCount
                                                                    .value =
                                                                element
                                                                    .commentsCount;
                                                            if (element
                                                                    .isLiked ==
                                                                true) {
                                                              element.like
                                                                      .value =
                                                                  true;
                                                              element.like
                                                                  .refresh();
                                                            }
                                                          });
                                                          // controller.filterUsers(
                                                          //   id: controller.searchSelected.id,
                                                          //   type: controller.searchSelected.type,
                                                          // );

                                                          controller
                                                              .update();
                                                        },
                                                        isSelected: controller
                                                            .isTweetsReply,
                                                      ),
                                                      TabButton(
                                                        title:
                                                            Strings.media,
                                                        onTap: () async {
                                                          controller
                                                                  .isTweets =
                                                              false;
                                                          controller
                                                                  .isTweetsReply =
                                                              false;
                                                          controller
                                                                  .isMedia =
                                                              true;
                                                          controller
                                                                  .isLikes =
                                                              false;
                                                          controller
                                                                  .selectedTab =
                                                              "isMedia";
                                                          controller
                                                              .update();
                                                          controller
                                                                  .userPosts =
                                                              await widget
                                                                  .newsfeedController
                                                                  .filterUsersPost(
                                                                      "media");
                                                          controller
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element.likeCount
                                                                    .value =
                                                                element
                                                                    .simpleLikeCount;
                                                            element.rebuzzCount
                                                                    .value =
                                                                element
                                                                    .retweetCount;
                                                            element.commentCount
                                                                    .value =
                                                                element
                                                                    .commentsCount;
                                                            if (element
                                                                    .isLiked ==
                                                                true) {
                                                              element.like
                                                                      .value =
                                                                  true;
                                                              element.like
                                                                  .refresh();
                                                            }
                                                          });
                                                          // controller.filterUsers(
                                                          //   id: controller.searchSelected.id,
                                                          //   type: controller.searchSelected.type,
                                                          // );

                                                          controller
                                                              .update();
                                                        },
                                                        isSelected:
                                                            controller
                                                                .isMedia,
                                                      ),
                                                      TabButton(
                                                        title:
                                                            Strings.likes,
                                                        onTap: () async {
                                                          controller
                                                                  .isTweets =
                                                              false;
                                                          controller
                                                                  .isTweetsReply =
                                                              false;
                                                          controller
                                                                  .isMedia =
                                                              false;
                                                          controller
                                                                  .isLikes =
                                                              true;
                                                          controller
                                                                  .selectedTab =
                                                              "isLikes";
                                                          controller
                                                              .update();
                                                          controller
                                                                  .userPosts =
                                                              await widget
                                                                  .newsfeedController
                                                                  .filterUsersPost(
                                                                      "likes");
                                                          controller
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element.likeCount
                                                                    .value =
                                                                element
                                                                    .simpleLikeCount;
                                                            element.rebuzzCount
                                                                    .value =
                                                                element
                                                                    .retweetCount;
                                                            element.commentCount
                                                                    .value =
                                                                element
                                                                    .commentsCount;
                                                            if (element
                                                                    .isLiked ==
                                                                true) {
                                                              element.like
                                                                      .value =
                                                                  true;
                                                              element.like
                                                                  .refresh();
                                                            }
                                                          });
                                                          // controller.filterUsers(
                                                          //   id: controller.searchSelected.id,
                                                          //   type: controller.searchSelected.type,
                                                          // );

                                                          controller
                                                              .update();
                                                        },
                                                        isSelected:
                                                            controller
                                                                .isLikes,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: 1,
                                        color: Colors.grey[300],
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),

                                      Center(child: Text(Strings.noPosts))
                                      ,
                                    ],
                                  ),
                                ),
                              )
                           :
                    PagedL(emptyStateWidget:
                                Text(
                                  Strings.noPosts,
                                  style: Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? const TextStyle(
                                    color: Colors.white,
                                  )
                                      : const TextStyle(
                                    color: Colors.black,
                                  ),
                                ),
                                itemBuilder: _itemRow,

                                padding: const EdgeInsets.only(top: 10, bottom: 30),
                                loadingIndicator: const Padding(
                                  padding: EdgeInsets.all(16.00),
                                  child: Center(
                                    child: CircularProgressIndicator(
                                      color: MyColors.BlueColor,
                                    ),
                                  ),
                                ),
                                itemDataProvider: _fetchData,
                                list: controller.userPosts,
                                listSize:
                                    _checkPage(controller.userPosts.length),
                              ),
                  ),
                ));
    });
  }

  Widget myPopMenu(int userId) {
    return Align(
        alignment: Alignment.topRight,
        child: PopupMenuButton(
            padding: EdgeInsets.zero,
            icon: const Icon(
              Icons.more_horiz,
              size: kIsWeb ? 30 : 22,
              color: Colors.grey,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            // Callback that sets the selected popup menu item.
            onSelected: (value) async {
              if(value ==1) {
                if (kIsWeb) {
                  print("object");
                  widget.newsfeedController.isSearch = false;
                  widget.newsfeedController.isFilter = false;
                  widget.newsfeedController.isFilterScreen = false;
                  widget.newsfeedController.isTrendsScreen = false;
                  widget.newsfeedController.isNewsFeedScreen = false;
                  widget.newsfeedController.isBrowseScreen = false;
                  widget.newsfeedController.isNotificationScreen = false;
                  widget.newsfeedController.isWhoToFollowScreen = false;
                  widget.newsfeedController.isSavedPostScreen = false;
                  widget.newsfeedController.isChatScreen = false;
                  widget.newsfeedController.isPostDetails = false;
                  widget.newsfeedController.isFollwerScreen = false;
                  widget.newsfeedController.isProfileScreen = false;
                  widget.newsfeedController.isListScreen = false;
                  widget.newsfeedController.isListDetailScreen = false;
                  widget.newsfeedController.isOtherUserProfileScreen = false;
                  widget.newsfeedController.searchText.text = '';
                  widget.newsfeedController.isSettingsScreen = false;
                  widget.newsfeedController.isTopicScreen = false;
                  widget.newsfeedController.isOtherTopicTabScreen = true;
                  widget.newsfeedController.update();

                  await topicController.otherUsersTopic(
                      othersUsersID: controller.newsFeedController.otherUserId);
                  if (topicController.suggestedFollowingTopicForOtherProfile
                      .data
                      .topics.isEmpty) {
                    UtilsMethods.toastMessageShow(
                        widget.newsfeedController.displayColor,
                        widget.newsfeedController.displayColor,
                        widget.newsfeedController.displayColor,
                        message: 'Nothing to show');
                  }
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => OtherTopicTabScreen()),
                  );

                  await topicController.otherUsersTopic(
                      othersUsersID: widget.newsfeedController.otherUserId);
                }
              }

              else if (value == 5) {
                showReportUserDialog(
                    context, widget.userId.toString(), controller.newsFeedController);
                controller.newsFeedController.update();
              }


            },
            itemBuilder: (BuildContext context) => [
                  PopupMenuItem(
                    value: 1,
                    child:InkWell(
                      onTap: (){
                        Navigator.pop(context); // Close the popup on item tap

                      },
                      child: Row(children: [
                        Icon(Icons.star),
                        SizedBox(width: 5,),
                        Text(

                          Strings.viewTopics,
                          textAlign: TextAlign.start,
                          style: Theme.of(context).brightness == Brightness.dark
                              ? TextStyle(
                            color: Colors.white,
                            fontSize: 14.0,
                          )
                              : TextStyle(
                            color: Colors.black,
                            fontSize: 14.0,
                          ),
                        )
                      ],),
                    )

                  ),
              PopupMenuItem(
                  value: 1,
                  child:InkWell(
                    onTap: (){
                      Navigator.pop(context); // Close the popup on item tap

                    },
                    child: Row(children: [
                      Icon(Icons.star),
                      SizedBox(width: 5,),
                      Text(

                        Strings.viewTopics,
                        textAlign: TextAlign.start,
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                          color: Colors.white,
                          fontSize: 14.0,
                        )
                            : TextStyle(
                          color: Colors.black,
                          fontSize: 14.0,
                        ),
                      )
                    ],),
                  )

              ),
              PopupMenuItem(
                value: 4,
                child: Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/block_user.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.blockUser,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontSize: 14
                      ),
                    ),
                  ],
                ),),
              PopupMenuItem(
                value: 5,
                child: Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/reportWerf_icon.svg',
                          color: Colors.red,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.reportUser,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontSize: 14
                      ),
                    ),
                  ],
                ),),
              PopupMenuItem(
                  value: 7,
                  child: Row(
                    children: [
                      Container(
                          width: 20,
                          height: 20,
                          child: SvgPicture.asset(
                            'assets/popup_munu_icons/copy_lint.svg',
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          )
                      ),
                      SizedBox(width: 5),
                      Text(
                        Strings.copyProfileLink,
                        style:
                        TextStyle(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors
                                .black,
                            fontSize: 14
                        ),
                      ),
                    ],
                  )),
                ]));
  }

  createAndGotoChats() async {
    widget.newsfeedController.idList.clear();
    widget.newsfeedController.idList
        .add(controller.newsFeedController.otherUserId);
    widget.newsfeedController.selectedPeople
        .add(widget.newsfeedController.userInfo.username);
    widget.newsfeedController.randomGroup =
        widget.newsfeedController.randomGroup +
            "${widget.newsfeedController.userInfo.username} ";

    if (!kIsWeb) {
      widget.newsfeedController.isChatCreatedYet = false;
      widget.newsfeedController.update();
      await widget.newsfeedController.createChat(
          widget.newsfeedController.idList,
          widget.newsfeedController.idList.length > 1 ? "group" : "single",
          groupMemberName: widget.newsfeedController.randomGroup);
      widget.newsfeedController.chatUserList =
          await widget.newsfeedController.getChat();
      widget.newsfeedController.idList.clear();
      widget.newsfeedController.isChatCreatedYet = true;
      // controller.usersList.clear();
      // controller.selectedPeople.clear();

      // controller.chatName = controller.randomGroup;
      // controller.update();
      // controller.isChatScreenWeb = true;


      int currentIndex = 0;
      if (widget.newsfeedController.chatUserList != null) {
        currentIndex =
            widget.newsfeedController.chatUserList.indexWhere((element) {
          return element.username ==
              widget.newsfeedController.userInfo.username;
        });
      }
      if (currentIndex == -1) currentIndex = 0;

      widget.newsfeedController.isImagePickedChat = false;
      widget.newsfeedController.isVideoPickedChat = false;
      widget.newsfeedController.isDocumentPickedChat = false;
      widget.newsfeedController.messageController.clear();
      widget.newsfeedController.showOverlay = false;
      widget.newsfeedController.messageController.text = "";
      widget.newsfeedController.chatName =
          widget.newsfeedController.chatUserList[currentIndex];
      widget.newsfeedController.groupName =
          widget.newsfeedController.chatName.conversationType == "group"
              ? "${widget.newsfeedController.chatName.name}"
              : "${widget.newsfeedController.chatName.name}";
      widget.newsfeedController.usersList?.clear();
      widget.newsfeedController.selectedPeople?.clear();
      widget.newsfeedController.idList?.clear();
      widget.newsfeedController
          .getMessagesOfAConversation(widget.newsfeedController.chatName.conversationId);
      widget.newsfeedController.isVideoThumbnail = false;
      widget.newsfeedController.videoThumbnail = null;
      widget.newsfeedController.chatIndex = currentIndex;
      widget.newsfeedController.tempGroupName = "";
      widget.newsfeedController.tempProfileImageGroupChat = null;
      widget.newsfeedController.update();
      // Navigator.of(context).pop();
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (BuildContext context) => ChatScreenMob.ChatScreenMobile(
                  widget.newsfeedController, false)));
    } else {
      widget.newsfeedController.isChatCreatedYet = false;
      widget.newsfeedController.update();
      await widget.newsfeedController.createChat(
          widget.newsfeedController.idList,
          widget.newsfeedController.idList.length > 1 ? "group" : "single",
          groupMemberName: widget.newsfeedController.randomGroup);
      widget.newsfeedController.chatUserList =
          await widget.newsfeedController.getChat();

      int currentIndex = 0;
      if (widget.newsfeedController.chatUserList != null) {
        currentIndex =
            widget.newsfeedController.chatUserList.indexWhere((element) {
          return element.username ==
              widget.newsfeedController.userInfo.username;
        });
      }
      if (currentIndex == -1) currentIndex = 0;
      // int findUser = 0;
      // String temp = "";
      //
      // if (widget.newsfeedController.idList.length == 1) {
      //   int counter = -1;
      //   widget.newsfeedController.chatUserList.forEach((element) {
      //     counter++;
      //     temp = '${element.username}';
      //
      //     print("temp ${temp}");
      //     if (temp == widget.newsfeedController.userInfo.username) {
      //       findUser = counter;
      //     }
      //   });
      // }

      // print("findUser ${findUser}");

      widget.newsfeedController.usersList?.clear();
      widget.newsfeedController.idList?.clear();
      widget.newsfeedController.isChatCreatedYet = true;

      widget.newsfeedController.isImagePickedChat = false;
      widget.newsfeedController.isVideoPickedChat = false;
      widget.newsfeedController.isDocumentPickedChat = false;
      widget.newsfeedController.messageController?.clear();
      widget.newsfeedController.showOverlay = false;
      widget.newsfeedController.messageController.text = "";
      widget.newsfeedController.isChatScreenWeb = true;
      widget.newsfeedController.chatName =
          widget.newsfeedController.chatUserList[currentIndex];
      widget.newsfeedController.groupName =
          widget.newsfeedController.chatName.conversationType == "group"
              ? "${widget.newsfeedController.chatName.name}"
              : "${widget.newsfeedController.chatName.name}";
      widget.newsfeedController.infoChatInfo = false;
      widget.newsfeedController
          .getMessagesOfAConversation(widget.newsfeedController.chatName.conversationId);
      widget.newsfeedController.chatIndex = currentIndex;
      widget.newsfeedController.highlighteTheChat = currentIndex;
      // widget.newsfeedController.update();
      widget.newsfeedController.selectedPeople?.clear();
      widget.newsfeedController.isNewsFeedScreen = false;

      if (widget.newsfeedController.isChatScreen == false) {
        widget.newsfeedController.isChatScreen = true;
        onChatsChange = true;
        onBookMarksChange = false;
        onTrendsChange = false;
        onHomeChange = false;

        onBrowsChange = false;
        onMoreChange = false;
        onNotificationChange = false;
        onListChange = false;
        onSettingChange = false;
        onProfileChange = false;
      }

      // controller.chatName = controller.randomGroup;
      // controller.isChatScreenWeb = true;

      if (widget.newsfeedController.navRoute != "isChatScreen") {
        widget.newsfeedController.navRoute = "isChatScreen";
        Get.toNamed(FluroRouters.mainScreen + '/chats');
      }
      widget.newsfeedController.update();
    }
  }

  // ignore: missing_return
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }
  showReportUserDialog(context, userId, NewsfeedController controller) {
    final reportText = TextEditingController();
    bool isCategory = false;
    int selectedReason;
    final _formKey = GlobalKey<FormState>();
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return Container(
                    width: kIsWeb ? Get.width * 0.30:Get.width / 4.5,
                    // height: kIsWeb ? Get.width * 0.30 : 300,
                    padding: const EdgeInsets.all(10),
                    child: Form(
                      key: _formKey,
                      child:Container(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                IconButton(
                                  icon: const Icon(Icons.close),
                                  onPressed: () {
                                    Navigator.of(context).pop(); // Close dialog on cross icon press
                                  },
                                ),
                                const Text(
                                  'Gethering info',
                                  style: TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(width: 48.0), // Adjust the width as needed
                              ],
                            ),
                            const SizedBox(height: 16.0),
                            const Text(
                              'What type of issue are you reporting?',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize:kIsWeb? 20:16
                              ),
                            ),
                            const SizedBox(height: 16.0),
                            SizedBox(
                              height: 200, // Height of the ListView
                              child: ListView.builder(
                                itemCount: controller.categoryList.length,
                                itemBuilder: (BuildContext context, int index) {
                                  return RadioListTile<int>(
                                    title: Text(controller.categoryList[index].name),
                                    activeColor: MyColors.werfieBlue,
                                    value: index,
                                    groupValue: selectedReason,
                                    onChanged: (int value) {
                                      setState(() {
                                        controller.selectedCategory = controller.categoryList[index].name;
                                        controller.selectcategoryId = controller.categoryList[index].id;
                                        selectedReason = value; // Update checked value
                                          // print('Checkbox $index is checked');
                                          // Perform actions on checkbox checked here

                                      });
                                    },
                                  );
                                },
                              ),
                            ),
                            const SizedBox(height: 16.0),
                            ElevatedButton(
                              onPressed:  () async {
                                if (_formKey.currentState.validate()) {
                                  await controller.blockUser(
                                      widget.userId);

                                  if (controller.selectcategoryId !=
                                      null) {
                                    setState(() {
                                      isCategory = false;
                                    });
                                    int response = await controller
                                        .reportUser(
                                      widget.userId,
                                      controller.selectcategoryId,
                                    );
                                    if (response == 200) {
                                      Navigator.of(context).pop();
                                      // postChangeStatus(true);
                                      UtilsMethods.toastMessageShow(
                                          controller.displayColor,
                                          controller.displayColor,
                                          controller.displayColor,
                                          message: Strings
                                              .userReportedSuccessfully);
                                      // ScaffoldMessenger.of(context)
                                      //
                                      //     .showSnackBar(SnackBar(
                                      //     backgroundColor: Colors.blue,
                                      //     content: Text(
                                      //       'User reported successfully!',
                                      //       style:
                                      //       TextStyle(
                                      //         color: Theme
                                      //             .of(context)
                                      //             .brightness ==
                                      //             Brightness.dark
                                      //             ? Colors.white
                                      //             : Colors.black,
                                      //
                                      //       ),
                                      //     )));
                                    }
                                    if (response == 400) {
                                      Navigator.of(context).pop();
                                      UtilsMethods.toastMessageShow(
                                          controller.displayColor,
                                          controller.displayColor,
                                          controller.displayColor,
                                          message: 'There was an error in reporting this user!');
                                      // ScaffoldMessenger.of(context)
                                      //     .showSnackBar(SnackBar(
                                      //     backgroundColor: Colors.blue,
                                      //     content: Text(
                                      //       'There was an error in reporting this user!',
                                      //       style: TextStyle(
                                      //         color: Theme
                                      //             .of(context)
                                      //             .brightness ==
                                      //             Brightness.dark
                                      //             ? Colors.white
                                      //             : Colors.black,
                                      //       ),)));
                                    }
                                  } else {
                                    setState(() {
                                      isCategory = true;
                                    });
                                  }
                                }

                              },
                              style: ElevatedButton.styleFrom(
                                primary: controller.displayColor,
                                // padding: EdgeInsets.symmetric(vertical: 16),
                                minimumSize: const Size(220, 60),
                                shape: const StadiumBorder(),
                              ),

                              child: Text(
                                Strings.report,

                                // style: Theme.of(context).textTheme.headline6.copyWith(
                                //     color: Colors.white,
                                //     fontWeight: FontWeight.bold,
                                //     fontSize: 18),
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ), /*SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: EdgeInsets.only(
                                  left: 10, right: 10, top: 0, bottom: 25),
                              padding: EdgeInsets.symmetric(
                                  vertical: 10, horizontal: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    color:
                                    isCategory ? Colors.red : Colors.grey[200],
                                  ),
                                  borderRadius: BorderRadius.circular(10)),
                              width: Get.width,
                              height: 55,
                              child: DropdownButton<CategoryModel>(
                                isExpanded: true,
                                underline: Container(
                                  height: 0.0,
                                ),
                                hint: Text(
                                    controller.selectedCategory == null ||
                                        controller.selectedCategory == ""
                                        ? Strings.selectCategory
                                        : controller.selectedCategory),
                                items: controller.categoryList
                                    .map((CategoryModel value) {
                                  return DropdownMenuItem<CategoryModel>(
                                    value: value,
                                    child: new Text(value.name,
                                      style: TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),),
                                  );
                                }).toList(),
                                onChanged: (CategoryModel _) {
                                  setState(() {
                                    controller.selectedCategory = _.name;
                                    controller.selectcategoryId = _.id;
                                  });
                                },
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  MaterialButton(
                                      color: Colors.grey,
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      //
                                      child: Text(
                                        Strings.cancel,
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                        ),
                                      )),
                                  MaterialButton(
                                      color: Colors.blueAccent,
                                      onPressed: () async {
                                        if (_formKey.currentState.validate()) {
                                          await controller.blockUser(
                                              widget.userId);

                                          if (controller.selectcategoryId !=
                                              null) {
                                            setState(() {
                                              isCategory = false;
                                            });
                                            int response = await controller
                                                .reportUser(
                                              widget.userId,
                                              controller.selectcategoryId,
                                            );
                                            if (response == 200) {
                                              Navigator.of(context).pop();
                                              // postChangeStatus(true);
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: Strings
                                                      .userReportedSuccessfully);
                                              // ScaffoldMessenger.of(context)
                                              //
                                              //     .showSnackBar(SnackBar(
                                              //     backgroundColor: Colors.blue,
                                              //     content: Text(
                                              //       'User reported successfully!',
                                              //       style:
                                              //       TextStyle(
                                              //         color: Theme
                                              //             .of(context)
                                              //             .brightness ==
                                              //             Brightness.dark
                                              //             ? Colors.white
                                              //             : Colors.black,
                                              //
                                              //       ),
                                              //     )));
                                            }
                                            if (response == 400) {
                                              Navigator.of(context).pop();
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: 'There was an error in reporting this user!');
                                              // ScaffoldMessenger.of(context)
                                              //     .showSnackBar(SnackBar(
                                              //     backgroundColor: Colors.blue,
                                              //     content: Text(
                                              //       'There was an error in reporting this user!',
                                              //       style: TextStyle(
                                              //         color: Theme
                                              //             .of(context)
                                              //             .brightness ==
                                              //             Brightness.dark
                                              //             ? Colors.white
                                              //             : Colors.black,
                                              //       ),)));
                                            }
                                          } else {
                                            setState(() {
                                              isCategory = true;
                                            });
                                          }
                                        }
                                      },
                                      child: Text(
                                        Strings.report,
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                        ),
                                      )),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),*/
                    ),
                  );
                }),
          );
        });
  }

  // ignore: missing_return
  Future<List<Post>> _fetchData(int page) async {


    if (Get.find<OtherUserController>().selectedTab == "isTweets") {
      return await Get.find<OtherUserController>()
          .filterUsersPostPagged("posts", page: page);
    } else if (Get.find<OtherUserController>().selectedTab == "isTweetsReply") {
      return await Get.find<OtherUserController>()
          .filterUsersPostPagged("post_commented", page: page);
    } else if (Get.find<OtherUserController>().selectedTab == "isMedia") {
      return await Get.find<OtherUserController>()
          .filterUsersPostPagged("media", page: page);
    } else if (Get.find<OtherUserController>().selectedTab == "isLikes") {
      return await Get.find<OtherUserController>()
          .filterUsersPostPagged("likes", page: page);
    }
  }

  Widget _itemRow(BuildContext context, Post post) {
    // return Text('dfdggdf');
    int index = controller.userPosts.indexWhere((element) {
      return element.postId == post.postId;
    });

    if (index != -1) {
      return VisibilityDetector(
          key: Key('postCard-widget-key'),
          onVisibilityChanged: (visibilityInfo) {
            double visiblePercentage = visibilityInfo.visibleFraction * 100;
            // debugPrint(
            //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
            if (visiblePercentage > 20 &&
                post.authorId != controller.newsFeedController.userId) {
              controller.newsFeedController.emitImpressionsSocket(post.postId);
            }
          },
          child: Column(
            children: [
              index == 0
                  ? SingleChildScrollView(
                      //MAIN SCREEN VIEW
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey[100])),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              clipBehavior: Clip.antiAlias,
                              alignment: Alignment.bottomLeft,
                              children: [
                                widget.newsfeedController.userInfo != null
                                    ? InkWell(
                                        onTap: () {
                                          showDialog(
                                            useSafeArea: false,
                                            context: context,
                                            builder: (context) {
                                              return AlertDialog(
                                                insetPadding: EdgeInsets.zero,
                                                contentPadding: EdgeInsets.zero,
                                                content: Stack(
                                                  children: [
                                                    Container(
                                                      color: Colors.black,
                                                      width:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .width,
                                                      height:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .height,
                                                      child: FadeInImage(
                                                        placeholderErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        imageErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        fit: BoxFit.contain,
                                                        width: 24,
                                                        height: 24,
                                                        placeholder: const AssetImage(
                                                            'assets/images/person_placeholder.png'),
                                                        image: NetworkImage(widget
                                                                .newsfeedController
                                                                .userInfo
                                                                .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: kIsWeb ? 10 : 30,
                                                      left: 10,
                                                      child: InkWell(
                                                        onTap: () {
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        child: const Icon(
                                                          Icons.cancel,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          );
                                        },
                                        child: Container(
                                            width: Get.width,
                                            height: kIsWeb
                                                ? Get.height / 3.5
                                                : Get.height / 4.5,
                                            color: Colors.grey[200],
                                            margin: EdgeInsets.only(
                                                bottom: Get.height / 15),
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(25),
                                              child: FadeInImage(
                                                  placeholderErrorBuilder:
                                                      (context, _, __) {
                                                    return Image.asset(
                                                        'assets/images/person_placeholder.png');
                                                  },
                                                  imageErrorBuilder:
                                                      (context, _, __) {
                                                    return Image.asset(
                                                        'assets/images/person_placeholder.png');
                                                  },
                                                  fit: BoxFit.cover,
                                                  width: 24,
                                                  height: 24,
                                                  placeholder: const AssetImage(
                                                      'assets/images/person_placeholder.png'),
                                                  image: NetworkImage(widget
                                                          .newsfeedController
                                                          .userInfo
                                                          .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                            )),
                                      )
                                    : InkWell(
                                        onTap: () {
                                          showDialog(
                                            useSafeArea: false,
                                            context: context,
                                            builder: (context) {
                                              return AlertDialog(
                                                insetPadding: EdgeInsets.zero,
                                                contentPadding: EdgeInsets.zero,
                                                content: Stack(
                                                  children: [
                                                    Container(
                                                      color: Colors.black,
                                                      width:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .width,
                                                      height:
                                                          MediaQuery.of(context)
                                                              .size
                                                              .height,
                                                      child: FadeInImage(
                                                        placeholderErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        imageErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        fit: BoxFit.contain,
                                                        width: 24,
                                                        height: 24,
                                                        placeholder: const AssetImage(
                                                            'assets/images/person_placeholder.png'),
                                                        image: NetworkImage(widget.userInfo
                                                                .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      top: kIsWeb ? 10 : 30,
                                                      left: 10,
                                                      child: InkWell(
                                                        onTap: () {
                                                          Get.back();
                                                        },
                                                        child: const Icon(
                                                          Icons.cancel,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          );
                                        },
                                        child: Container(
                                            width: Get.width,
                                            height: kIsWeb
                                                ? Get.height / 3.5
                                                : Get.height / 4.5,
                                            color: Colors.grey[200],
                                            margin: EdgeInsets.only(
                                                bottom: Get.height / 15),
                                            child: widget.userInfo == null
                                                ? SizedBox()
                                                : ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            25),
                                                    child: FadeInImage(
                                                        placeholderErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        imageErrorBuilder:
                                                            (context, _, __) {
                                                          return Image.asset(
                                                              'assets/images/person_placeholder.png');
                                                        },
                                                        fit: BoxFit.cover,
                                                        width: 24,
                                                        height: 24,
                                                        placeholder: const AssetImage(
                                                            'assets/images/person_placeholder.png'),
                                                        image: NetworkImage(widget.userInfo
                                                                .coverImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                  )),
                                      ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                      left: 20.0, right: kIsWeb ? 40.0 : 20.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      /* kIsWeb && */ widget.newsfeedController
                                                  .userInfo !=
                                              null
                                          ? InkWell(
                                              onTap: () {
                                                showDialog(
                                                    useSafeArea: false,
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        insetPadding:
                                                            EdgeInsets.zero,
                                                        contentPadding:
                                                            EdgeInsets.zero,
                                                        content: Stack(
                                                          children: [
                                                            Container(
                                                              color:
                                                                  Colors.black,
                                                              width:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width,
                                                              height:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height,
                                                              child:
                                                                  FadeInImage(
                                                                placeholderErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                imageErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                fit: BoxFit
                                                                    .contain,
                                                                width: 150,
                                                                height: 150,
                                                                placeholder:
                                                                    const AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                image: NetworkImage(widget
                                                                        .newsfeedController
                                                                        .userInfo
                                                                        .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              top: kIsWeb
                                                                  ? 10
                                                                  : 30,
                                                              left: 10,
                                                              child: InkWell(
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                                child: const Icon(
                                                                  Icons.cancel,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    });
                                              },
                                              child: CircleAvatar(
                                                radius: kIsWeb ? 80 : 70,
                                                backgroundColor: Colors.white,
                                                child: CircleAvatar(
                                                    radius: kIsWeb ? 75 : 65,
                                                    backgroundColor:
                                                        Colors.white,
                                                    child: widget
                                                                .newsfeedController
                                                                .userInfo ==
                                                            null
                                                        ? const CircularProgressIndicator(
                                                            color: MyColors
                                                                .BlueColor,
                                                          )
                                                        : ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        kIsWeb
                                                                            ? 80
                                                                            : 70),
                                                            child: FadeInImage(
                                                                placeholderErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                imageErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                fit: BoxFit
                                                                    .cover,
                                                                width: 150,
                                                                height: 150,
                                                                placeholder:
                                                                    const AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                image: NetworkImage(widget
                                                                        .newsfeedController
                                                                        .userInfo
                                                                        .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                          )),
                                              ),
                                            )
                                          : InkWell(
                                              onTap: () {
                                                showDialog(
                                                    useSafeArea: false,
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        insetPadding:
                                                            EdgeInsets.zero,
                                                        contentPadding:
                                                            EdgeInsets.zero,
                                                        content: Stack(
                                                          children: [
                                                            Container(
                                                              color:
                                                                  Colors.black,
                                                              width:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .width,
                                                              height:
                                                                  MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height,
                                                              child:
                                                                  FadeInImage(
                                                                placeholderErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                imageErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                fit: BoxFit
                                                                    .contain,
                                                                width: 150,
                                                                height: 150,
                                                                placeholder:
                                                                    const AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                image: NetworkImage(widget
                                                                        .userInfo
                                                                        .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              top: kIsWeb
                                                                  ? 10
                                                                  : 30,
                                                              left: 10,
                                                              child: InkWell(
                                                                onTap: () {
                                                                  Get.back();
                                                                },
                                                                child: const Icon(
                                                                  Icons.cancel,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      );
                                                    });
                                              },
                                              child: CircleAvatar(
                                                radius: kIsWeb ? 80 : 70,
                                                backgroundColor: Colors.white,
                                                child: CircleAvatar(
                                                    radius: kIsWeb ? 75 : 65,
                                                    backgroundColor:
                                                        Colors.white,
                                                    child: widget.userInfo ==
                                                            null
                                                        ? const CircularProgressIndicator(
                                                            color: MyColors
                                                                .BlueColor,
                                                          )
                                                        : ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        kIsWeb
                                                                            ? 80
                                                                            : 70),
                                                            child: FadeInImage(
                                                                placeholderErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                imageErrorBuilder:
                                                                    (context, _,
                                                                        __) {
                                                                  return Image
                                                                      .asset(
                                                                          'assets/images/person_placeholder.png');
                                                                },
                                                                fit: BoxFit
                                                                    .cover,
                                                                width: 150,
                                                                height: 150,
                                                                placeholder:
                                                                    const AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                image: NetworkImage(widget
                                                                        .userInfo
                                                                        .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                          )),
                                              ),
                                            ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsets.zero,
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 20.0,
                                        top: 2,
                                        bottom: 0,
                                        right: 20.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        ///menu
                                        Row(
                                          children: [
                                            Spacer(),
                                          /*  Container(
                                                height: 30,
                                                width: 30,
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  border: Border.all(
                                                      width: 1,
                                                      color: Colors.grey),
                                                ),
                                                child: myPopMenu(widget
                                                    .newsfeedController
                                                    .othersUserid)),*/
                                            SizedBox(
                                              width: 10,
                                            ),
                                            widget.newsfeedController
                                                        .isChatCreatedYet ==
                                                    false
                                                ? Center(
                                                    child:
                                                        CircularProgressIndicator(
                                                      color: MyColors.BlueColor,
                                                    ),
                                                  )
                                                : InkWell(
                                                    onTap: () {
                                                      createAndGotoChats();
                                                    },
                                                    child: Container(
                                                        height: 30,
                                                        width: 30,
                                                        decoration:
                                                            BoxDecoration(
                                                          shape:
                                                              BoxShape.circle,
                                                          border: Border.all(
                                                              width: 1,
                                                              color:
                                                                  Colors.grey),
                                                        ),
                                                        child: Container(
                                                          padding:
                                                              EdgeInsets.all(
                                                                  3.0),
                                                          child:
                                                              SvgPicture.asset(
                                                            'assets/svg_drawer_icons/messages.svg',
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                        )),
                                                  ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            /*kIsWeb&&*/
                                            widget.newsfeedController
                                                        .userInfo !=
                                                    null
                                                ? widget.newsfeedController
                                                            .isLoading ==
                                                        true
                                                    ? Center(
                                                        child:
                                                            CircularProgressIndicator(
                                                          color: MyColors
                                                              .BlueColor,
                                                        ),
                                                      )
                                                    :

                                                    ///follow unfollow button for web
                                                    Align(
                                                        alignment:
                                                            Alignment.topRight,
                                                        child:
                                                            UnfollowBtnWidget(
                                                                controller),
                                                      )
                                                : widget.userInfo == null
                                                    ? SizedBox()
                                                    : widget.newsfeedController
                                                                .isLoading ==
                                                            true
                                                        ? Center(
                                                            child:
                                                                CircularProgressIndicator(
                                                              color: MyColors
                                                                  .BlueColor,
                                                            ),
                                                          )
                                                        : Align(
                                                            alignment: Alignment
                                                                .topRight,
                                                            child:
                                                                UnfollowBtnWidget(
                                                                    controller),
                                                          ),
                                          ],
                                        ),
                                        /* kIsWeb &&*/
                                        widget.newsfeedController.userInfo !=
                                                null
                                            ? Row(
                                                children: [
                                                  Text(
                                                    "${widget.newsfeedController.userInfo.firstname + " " + widget.newsfeedController.userInfo.lastname}",
                                                    // style: TextStyle(
                                                    //     fontSize: kIsWeb ? 20.0 : 16.0,
                                                    //     color: Colors.black),
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  widget
                                                              .newsfeedController
                                                              .userInfo
                                                              .accountVerified ==
                                                          "verified"
                                                      ? BlueTick(
                                                          height: 15,
                                                          width: 15,
                                                          iconSize: 10,
                                                        )
                                                      : SizedBox(),
                                                ],
                                              )
                                            : widget.userInfo == null
                                                ? SizedBox()
                                                : Row(
                                                    children: [
                                                      Text(
                                                        "${widget.userInfo.firstname + " " + widget.userInfo.lastname}",
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                        // style: TextStyle(
                                                        //     fontSize: kIsWeb ? 20.0 : 16.0,
                                                        //     color: Colors.black),
                                                      ),
                                                      SizedBox(
                                                        width: 2,
                                                      ),
                                                      widget.userInfo
                                                                  .accountVerified ==
                                                              "verified"
                                                          ? BlueTick(
                                                              height: 15,
                                                              width: 15,
                                                              iconSize: 10,
                                                            )
                                                          : SizedBox(),
                                                    ],
                                                  ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        /* kIsWeb &&*/
                                        widget.newsfeedController.userInfo !=
                                                null
                                            ? Row(
                                                children: [
                                                  Text(
                                                    "@${widget.newsfeedController.userInfo.username}",
                                                    // style: TextStyle(
                                                    //   fontSize: kIsWeb ? 18.0 : 14.0,
                                                    // ),
                                                    style: Styles
                                                        .baseTextTheme.headline5
                                                        .copyWith(
                                                      fontWeight:
                                                          FontWeight.w400,
                                                    ),
                                                  ),
                                                ],
                                              )
                                            : Text(
                                                widget.userInfo == null
                                                    ? ""
                                                    : "@${widget.userInfo.username}",
                                                style: Styles
                                                    .baseTextTheme.headline5
                                                    .copyWith(
                                                  fontWeight: FontWeight.w400,
                                                ),
                                              ),
                                        // /* kIsWeb &&*/ widget.newsfeedController.userInfo!=null?
                                        //  Text(
                                        //   "${widget.newsfeedController.userInfo.email}",
                                        //    style:  Styles.baseTextTheme.headline5.copyWith(
                                        //      fontWeight: FontWeight.w400,
                                        //    ),
                                        //  ):
                                        //  Text(
                                        //    widget.userInfo == null ? "" : "${widget.userInfo.email}",
                                        //    style: Styles.baseTextTheme.headline5.copyWith(
                                        //      fontWeight: FontWeight.w400,
                                        //    ),
                                        //  ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        /* kIsWeb &&*/
                                        widget.newsfeedController.userInfo !=
                                                null
                                            ? widget.newsfeedController
                                                        .userInfo ==
                                                    null
                                                ? SizedBox()
                                                : widget.newsfeedController
                                                            .userInfo.bio ==
                                                        null
                                                    ? SizedBox()
                                                    : Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          // Icon(
                                                          //   Icons.calendar_today_outlined,
                                                          //   color: Colors.grey[300],
                                                          // ),
                                                          // SizedBox(
                                                          //   width: 10.0,
                                                          // ),
                                                          Expanded(
                                                            child: Align(
                                                              alignment:
                                                                  Alignment
                                                                      .topLeft,
                                                              child: Text(
                                                                "${widget.newsfeedController.userInfo.bio}",
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline5
                                                                    .copyWith(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                            : widget.userInfo == null
                                                ? SizedBox()
                                                : widget.userInfo.bio == null
                                                    ? SizedBox()
                                                    : Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Icon(
                                                            Icons
                                                                .calendar_today_outlined,
                                                            color: Color(
                                                                0xFF586976),
                                                          ),
                                                          SizedBox(
                                                            width: 10.0,
                                                          ),
                                                          Expanded(
                                                            child: Align(
                                                              alignment:
                                                                  Alignment
                                                                      .topLeft,
                                                              child: Text(
                                                                "${widget.userInfo.bio}",
                                                                // style: TextStyle(
                                                                //     height: 1.2,
                                                                //     fontSize:
                                                                //         kIsWeb ? 18.0 : 14.0),
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline5
                                                                    .copyWith(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                ),
                                                                maxLines: 3,
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                        SizedBox(
                                          height: 5,
                                        ),
                                        locationAndJoinedDate(widget.newsfeedController.userInfo),
                                        ///folower and following for web
                                        /*  kIsWeb &&*/
                                        widget.newsfeedController.userInfo != null
                                            ? Row(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  TextButton(
                                                    style: ButtonStyle(padding: MaterialStateProperty.all(EdgeInsets.zero)),
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          "${widget.newsfeedController.userInfo.followings} ",
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                          ),
                                                        ),
                                                        Text(
                                                          Strings.followings,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    onPressed: kIsWeb
                                                        ? () {
                                                            /*   Get.put(FollowerController());
                                            Get.find<FollowerController>()
                                                .getFollower(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .getFollowing(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .followingCheck = 1;
                                            Get.find<FollowerController>()
                                                .update();
                                            controller.newsFeedController.isSearch = false;
                                            controller.isFilter = false;
                                            controller.newsFeedController
                                                .isFilterScreen = false;
                                            controller.newsFeedController
                                                .isTrendsScreen = false;
                                            controller.newsFeedController
                                                .isNewsFeedScreen = false;
                                            controller.newsFeedController
                                                .isBrowseScreen = false;
                                            controller.newsFeedController
                                                .isNotificationScreen = false;
                                            controller.newsFeedController
                                                .isSavedPostScreen = false;
                                            controller.newsFeedController
                                                .isChatScreen = false;
                                            controller.newsFeedController
                                                .isPostDetails = false;
                                            controller.newsFeedController
                                                .isProfileScreen = false;
                                            controller.newsFeedController
                                                .isOtherUserProfileScreen = false;
                                            controller.newsFeedController
                                                .isFollwerScreen = true;
                                            controller.newsFeedController
                                                .navRoute = "isOtherUserScreen";
                                            controller.newsFeedController
                                                .update();*/
                                                            // SingleTone.instance.userId=post.authorId.toString();
                                                            Get.put(FollowerController());
                                                            Get.find<FollowerController>()
                                                                .getFollower(userId: controller.newsFeedController.othersUserid);
                                                            Get.find<FollowerController>()
                                                                .getFollowing(userId: controller.newsFeedController.othersUserid);
                                                            Get.find<FollowerController>().followingCheck = 1;
                                                            Get.find<FollowerController>().update();
                                                            Get.toNamed(FluroRouters.mainScreen +
                                                                "/followings/" +
                                                                controller.newsFeedController.othersUserid.toString());
                                                          }
                                                        : () {
                                                            Get.delete<OtherUserController>();
                                                            Get.put(FollowerController());
                                                            Get.find<FollowerController>()
                                                                .getFollower(userId: controller.newsFeedController.othersUserid);
                                                            Get.find<FollowerController>().getFollowing(userId: controller.userId);
                                                            Get.find<FollowerController>().followingCheck = 1;
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext context) => FollowerScreen(
                                                                          isOtherUserProfile: true,
                                                                          controller: controller.newsFeedController,
                                                                        )));

                                                            Get.find<FollowerController>().update();
                                                          },
                                                  ),
                                                  SizedBox(
                                                    width: 15,
                                                  ),
                                                  TextButton(
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          "${widget.newsfeedController.userInfo.followers} ",
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                          ),
                                                        ),
                                                        Text(
                                                          Strings.followers,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    onPressed: kIsWeb
                                                        ? () {
                                                            /*  Get.put(FollowerController());
                                            Get.find<FollowerController>()
                                                .getFollower(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .getFollowing(
                                                userId: controller.userId);
                                            Get.find<FollowerController>()
                                                .followingCheck = 0;
                                            Get.find<FollowerController>()
                                                .update();
                                            controller.newsFeedController
                                                .isSearch = false;
                                            controller.isFilter = false;
                                            controller.newsFeedController
                                                .isFilterScreen = false;
                                            controller.newsFeedController
                                                .isTrendsScreen = false;
                                            controller.newsFeedController
                                                .isNewsFeedScreen = false;
                                            controller.newsFeedController
                                                .isBrowseScreen = false;
                                            controller.newsFeedController
                                                .isNotificationScreen = false;
                                            controller.newsFeedController
                                                .isSavedPostScreen = false;
                                            controller.newsFeedController
                                                .isChatScreen = false;
                                            controller.newsFeedController
                                                .isPostDetails = false;
                                            controller.newsFeedController
                                                .isProfileScreen = false;
                                            controller.newsFeedController
                                                .isOtherUserProfileScreen = false;
                                            controller.newsFeedController
                                                .isFollwerScreen = true;
                                            controller.newsFeedController
                                                .navRoute = "isOtherUserScreen";
                                            controller.newsFeedController
                                                .update();*/
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .newsFeedController
                                                                        .othersUserid);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .newsFeedController
                                                                        .othersUserid);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 0;
                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                            Get.toNamed(FluroRouters
                                                                    .mainScreen +
                                                                "/followers/" +
                                                                controller
                                                                    .newsFeedController
                                                                    .othersUserid
                                                                    .toString());
                                                          }
                                                        : () {
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 0;

                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .userId);
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        FollowerScreen(
                                                                          controller:
                                                                              controller.newsFeedController,
                                                                        )));
                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                          },
                                                  ),
                                                ],
                                              )
                                            : Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  TextButton(
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          widget.userInfo ==
                                                                  null
                                                              ? ""
                                                              : "${widget.userInfo.followings} ",
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                          ),
                                                        ),
                                                        Text(
                                                          Strings.followings,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    onPressed: kIsWeb
                                                        ? () {
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 1;
                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                            controller
                                                                .newsFeedController
                                                                .isSearch = false;
                                                            controller
                                                                    .isFilter =
                                                                false;
                                                            controller
                                                                .newsFeedController
                                                                .isFilterScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isTrendsScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isNewsFeedScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isBrowseScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isNotificationScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isSavedPostScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isChatScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isPostDetails = false;
                                                            controller
                                                                .newsFeedController
                                                                .isProfileScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isOtherUserProfileScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isFollwerScreen = true;
                                                            controller
                                                                    .newsFeedController
                                                                    .navRoute =
                                                                "isOtherUserScreen";
                                                            controller
                                                                .newsFeedController
                                                                .update();

                                                            Get.toNamed(FluroRouters
                                                                    .mainScreen +
                                                                "/followers/" +
                                                                controller
                                                                    .newsFeedController
                                                                    .othersUserid
                                                                    .toString());
                                                          }
                                                        : () {
                                                            Get.delete<
                                                                OtherUserController>();
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 1;
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        FollowerScreen(
                                                                          isOtherUserProfile:
                                                                              true,
                                                                          controller:
                                                                              controller.newsFeedController,
                                                                        )));

                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                          },
                                                  ),
                                                  SizedBox(
                                                    width: 15,
                                                  ),
                                                  TextButton(
                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          widget.userInfo ==
                                                                  null
                                                              ? ""
                                                              : "${widget.userInfo.followers} ",
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                          ),
                                                        ),
                                                        Text(
                                                          Strings.followers,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 16.0
                                                                : 14.0,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    onPressed: kIsWeb
                                                        ? () {
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .userId);

                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 0;
                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                            controller
                                                                .newsFeedController
                                                                .isSearch = false;
                                                            controller
                                                                    .isFilter =
                                                                false;
                                                            controller
                                                                .newsFeedController
                                                                .isFilterScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isTrendsScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isNewsFeedScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isBrowseScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isNotificationScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isSavedPostScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isChatScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isPostDetails = false;
                                                            controller
                                                                .newsFeedController
                                                                .isProfileScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isOtherUserProfileScreen = false;
                                                            controller
                                                                .newsFeedController
                                                                .isFollwerScreen = true;
                                                            controller
                                                                    .newsFeedController
                                                                    .navRoute =
                                                                "isOtherUserScreen";
                                                            controller
                                                                .newsFeedController
                                                                .update();
                                                          }
                                                        : () {
                                                            Get.put(
                                                                FollowerController());
                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollower(
                                                                    userId: controller
                                                                        .userId);
                                                            Get.find<
                                                                    FollowerController>()
                                                                .followingCheck = 0;

                                                            Get.find<
                                                                    FollowerController>()
                                                                .getFollowing(
                                                                    userId: controller
                                                                        .userId);
                                                            Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder: (BuildContext
                                                                            context) =>
                                                                        FollowerScreen(
                                                                          controller:
                                                                              controller.newsFeedController,
                                                                        )));
                                                            Get.find<
                                                                    FollowerController>()
                                                                .update();
                                                          },
                                                  ),
                                                ],
                                              ),
                                        followedByWidget(widget.newsfeedController.userInfo),

                                        // SizedBox(
                                        //   height: height / 20,
                                        // ),
                                      ],
                                    ),
                                  ),
                                  kIsWeb
                                      ? Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          TabButton(
                                            title: Strings.werfs,
                                            onTap: () async {
                                              controller.isTweets = true;
                                              controller.isTweetsReply =
                                                  false;
                                              controller.isMedia = false;
                                              controller.isLikes = false;
                                              controller.selectedTab =
                                                  "isTweets";
                                              controller.update();
                                              controller.userPosts =
                                                  await widget
                                                      .newsfeedController
                                                      .filterUsersPost(
                                                          "posts");
                                              controller.userPosts
                                                  .forEach((element) {
                                                element.likeCount.value =
                                                    element.simpleLikeCount;
                                                element.rebuzzCount.value =
                                                    element.retweetCount;
                                                element.commentCount.value =
                                                    element.commentsCount;
                                                if (element.isLiked ==
                                                    true) {
                                                  element.like.value = true;
                                                  element.like.refresh();
                                                }
                                              });
                                              // controller.filterUsersPost(
                                              //   id: controller.searchSelected.id,
                                              //   type: controller.searchSelected.type,
                                              // );

                                              controller.update();
                                            },
                                            isSelected: controller.isTweets,
                                          ),
                                          TabButton(
                                            title: kIsWeb
                                                ? Strings.tweetsAndReplies
                                                : Strings.tweetsAndReplies,
                                            onTap: () async {
                                              controller.isTweets = false;
                                              controller.isTweetsReply =
                                                  true;
                                              controller.isMedia = false;
                                              controller.isLikes = false;
                                              controller.selectedTab =
                                                  "isTweetsReply";
                                              controller.update();
                                              controller.userPosts =
                                                  await widget
                                                      .newsfeedController
                                                      .filterUsersPost(
                                                          "post_commented");

                                              controller.userPosts
                                                  .forEach((element) {
                                                element.likeCount.value =
                                                    element.simpleLikeCount;
                                                element.rebuzzCount.value =
                                                    element.retweetCount;
                                                element.commentCount.value =
                                                    element.commentsCount;
                                                if (element.isLiked ==
                                                    true) {
                                                  element.like.value = true;
                                                  element.like.refresh();
                                                }
                                              });
                                              // controller.filterUsers(
                                              //   id: controller.searchSelected.id,
                                              //   type: controller.searchSelected.type,
                                              // );

                                              controller.update();
                                            },
                                            isSelected:
                                                controller.isTweetsReply,
                                          ),
                                          TabButton(
                                            title: Strings.media,
                                            onTap: () async {
                                              controller.isTweets = false;
                                              controller.isTweetsReply =
                                                  false;
                                              controller.isMedia = true;
                                              controller.isLikes = false;
                                              controller.selectedTab =
                                                  "isMedia";
                                              controller.update();
                                              controller.userPosts =
                                                  await widget
                                                      .newsfeedController
                                                      .filterUsersPost(
                                                          "media");
                                              controller.userPosts
                                                  .forEach((element) {
                                                element.likeCount.value =
                                                    element.simpleLikeCount;
                                                element.rebuzzCount.value =
                                                    element.retweetCount;
                                                element.commentCount.value =
                                                    element.commentsCount;
                                                if (element.isLiked ==
                                                    true) {
                                                  element.like.value = true;
                                                  element.like.refresh();
                                                }
                                              });
                                              // controller.filterUsers(
                                              //   id: controller.searchSelected.id,
                                              //   type: controller.searchSelected.type,
                                              // );

                                              controller.update();
                                            },
                                            isSelected: controller.isMedia,
                                          ),
                                          TabButton(
                                            title: Strings.likes,
                                            onTap: () async {
                                              controller.isTweets = false;
                                              controller.isTweetsReply =
                                                  false;
                                              controller.isMedia = false;
                                              controller.isLikes = true;
                                              controller.selectedTab =
                                                  "isLikes";
                                              controller.update();
                                              controller.userPosts =
                                                  await widget
                                                      .newsfeedController
                                                      .filterUsersPost(
                                                          "likes");
                                              controller.userPosts
                                                  .forEach((element) {
                                                element.likeCount.value =
                                                    element.simpleLikeCount;
                                                element.rebuzzCount.value =
                                                    element.retweetCount;
                                                element.commentCount.value =
                                                    element.commentsCount;
                                                if (element.isLiked ==
                                                    true) {
                                                  element.like.value = true;
                                                  element.like.refresh();
                                                }
                                              });
                                              // controller.filterUsers(
                                              //   id: controller.searchSelected.id,
                                              //   type: controller.searchSelected.type,
                                              // );

                                              controller.update();
                                            },
                                            isSelected: controller.isLikes,
                                          ),
                                        ],
                                      )
                                      : FittedBox(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            TabButton(
                                              title: Strings.werfs,
                                              onTap: () async {
                                                controller.isTweets = true;
                                                controller.isTweetsReply =
                                                    false;
                                                controller.isMedia = false;
                                                controller.isLikes = false;
                                                controller.selectedTab =
                                                    "isTweets";
                                                controller.update();
                                                controller.userPosts =
                                                    await widget
                                                        .newsfeedController
                                                        .filterUsersPost(
                                                            "posts");
                                                controller.userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                          .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                          .value =
                                                      element.commentsCount;
                                                  if (element.isLiked ==
                                                      true) {
                                                    element.like.value =
                                                        true;
                                                    element.like.refresh();
                                                  }
                                                });
                                                // controller.filterUsersPost(
                                                //   id: controller.searchSelected.id,
                                                //   type: controller.searchSelected.type,
                                                // );

                                                controller.update();
                                              },
                                              isSelected:
                                                  controller.isTweets,
                                            ),
                                            TabButton(
                                              title: kIsWeb
                                                  ? Strings.tweetsAndReplies
                                                  : Strings
                                                      .tweetsAndReplies,
                                              onTap: () async {
                                                controller.isTweets = false;
                                                controller.isTweetsReply =
                                                    true;
                                                controller.isMedia = false;
                                                controller.isLikes = false;
                                                controller.selectedTab =
                                                    "isTweetsReply";
                                                controller.update();
                                                controller.userPosts =
                                                    await widget
                                                        .newsfeedController
                                                        .filterUsersPost(
                                                            "post_commented");
                                                controller.userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                          .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                          .value =
                                                      element.commentsCount;
                                                  if (element.isLiked ==
                                                      true) {
                                                    element.like.value =
                                                        true;
                                                    element.like.refresh();
                                                  }
                                                });
                                                // controller.filterUsers(
                                                //   id: controller.searchSelected.id,
                                                //   type: controller.searchSelected.type,
                                                // );

                                                controller.update();
                                              },
                                              isSelected:
                                                  controller.isTweetsReply,
                                            ),
                                            TabButton(
                                              title: Strings.media,
                                              onTap: () async {
                                                controller.isTweets = false;
                                                controller.isTweetsReply =
                                                    false;
                                                controller.isMedia = true;
                                                controller.isLikes = false;
                                                controller.selectedTab =
                                                    "isMedia";
                                                controller.update();
                                                controller.userPosts =
                                                    await widget
                                                        .newsfeedController
                                                        .filterUsersPost(
                                                            "media");
                                                controller.userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                          .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                          .value =
                                                      element.commentsCount;
                                                  if (element.isLiked ==
                                                      true) {
                                                    element.like.value =
                                                        true;
                                                    element.like.refresh();
                                                  }
                                                });
                                                // controller.filterUsers(
                                                //   id: controller.searchSelected.id,
                                                //   type: controller.searchSelected.type,
                                                // );

                                                controller.update();
                                              },
                                              isSelected:
                                                  controller.isMedia,
                                            ),
                                            TabButton(
                                              title: Strings.likes,
                                              onTap: () async {
                                                controller.isTweets = false;
                                                controller.isTweetsReply =
                                                    false;
                                                controller.isMedia = false;
                                                controller.isLikes = true;
                                                controller.selectedTab =
                                                    "isLikes";
                                                controller.update();
                                                controller.userPosts =
                                                    await widget
                                                        .newsfeedController
                                                        .filterUsersPost(
                                                            "likes");
                                                controller.userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                          .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                          .value =
                                                      element.commentsCount;
                                                  if (element.isLiked ==
                                                      true) {
                                                    element.like.value =
                                                        true;
                                                    element.like.refresh();
                                                  }
                                                });
                                                // controller.filterUsers(
                                                //   id: controller.searchSelected.id,
                                                //   type: controller.searchSelected.type,
                                                // );

                                                controller.update();
                                              },
                                              isSelected:
                                                  controller.isLikes,
                                            ),
                                          ],
                                        ),
                                      ),
                                ],
                              ),
                            ),
                            Container(
                              height: 1,
                              color: Colors.grey[300],
                            ),
                          ],
                        ),
                      ),
                    )
                  : const SizedBox(),
              controller.userPosts[index].type == 'thread'
                  ? ThreadPostCard(
                      index: index,
                      post: controller.userPosts[index],
                      scaffoldKey: _scaffoldKey,
                      controller: Get.find<NewsfeedController>(),
                      otherUserController: controller,
                      mute: 1,
                      deletePostId: 9,
                    )
                  : PostCard(
                      userProfileCheck: true,
                      index: index,
                      post: controller.userPosts[index],
                      scaffoldKey: _scaffoldKey,
                      controller: Get.find<NewsfeedController>(),
                      otherUserController: controller,
                      mute: 1,
                      deletePostId: 9,
                    )
            ],
          ));
    }
  }

  Widget locationAndJoinedDate(UserProfile userProfile) {

    return userProfile == null ? const SizedBox() : Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        !kIsWeb ? location(userProfile) : const SizedBox(),
        const SizedBox(height: 4,),
        Row(
          children: [
            kIsWeb ? Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: location(userProfile),
            ) : const SizedBox(),
            Icon(Icons.calendar_month, size: 15, color: Colors.grey.shade600,),
            const SizedBox(width: 6),
            Text(
              'Joined ${userProfile.createdAt}',
              style: Styles.baseTextTheme.headline2.copyWith(
                fontSize: kIsWeb ? 16.0 : 14.0,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        const SizedBox(height: kIsWeb ? 4 : 0,),
      ],
    );
  }

  Widget location(UserProfile userProfile){
    return Row(
      children: [
        Icon(Icons.location_on_outlined, size: 15, color: Colors.grey.shade600,),
        const SizedBox(width: 6),
        Text(
          userProfile.region,
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: kIsWeb ? 16.0 : 14.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget followedByWidget(UserProfile userProfile){
    String followedBy = userProfile?.followedBy ?? "";
    if (followedBy != "") followedBy = "Followed by $followedBy";
    return followedBy == "" ? const SizedBox() : Padding(
      padding: const EdgeInsets.only(bottom:  kIsWeb ? 12.0 : 8.0, top: kIsWeb ? 4 : 0,),
      child: Text(
        followedBy,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: Styles.baseTextTheme.headline2.copyWith(
          fontSize: 13.0,
          fontWeight: FontWeight.w400,
        ),
      ),
    );
  }
}

class TabButton extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  const TabButton({Key key, this.title, this.isSelected, this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    NewsfeedController newsfeedController = Get.put((NewsfeedController()));
    return MaterialButton(
      onPressed: onTap,
      child: Column(
        children: [
          isSelected
              ? FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 18 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    //   fontWeight: FontWeight.bold,
                    //   fontSize: kIsWeb ? 18 : 16,
                    // ),
                    maxLines: 1,
                  ),
                )
              : FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 18 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                    //   fontSize: kIsWeb ? 18 : 16,
                    //   fontWeight: FontWeight.bold,
                    // ),
                    maxLines: 1,
                  ),
                ),
          const SizedBox(
            height: 10,
          ),
          isSelected
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    //color: MyColors.yellow,
                    color: newsfeedController.displayColor,
                  ),
                  height: 5,
                  width: title.length * 8.toDouble(),
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}

class UnfollowBtnWidget extends StatefulWidget {
  OtherUserController controller;

  UnfollowBtnWidget(
    this.controller, {
    Key key,
  }) : super(key: key);

  @override
  State<UnfollowBtnWidget> createState() => _UnfollowBtnWidgetState();
}

class _UnfollowBtnWidgetState extends State<UnfollowBtnWidget> {
  bool isloadFollowing = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: isloadFollowing
          ? const Center(child: CircularProgressIndicator())
          : MaterialButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(40),
              ),
              color: Theme.of(context).brightness == Brightness.dark
                  ? !widget.controller.newsFeedController.userInfo.is_follow
                      ? Colors.white
                      : Colors.black
                  : !widget.controller.newsFeedController.userInfo.is_follow
                      ? Colors.black
                      : Colors.white,
              onPressed: () async {
                isloadFollowing = true;
                setState(() {});

                if (widget.controller.newsFeedController.userInfo.is_follow ==
                    false) {
                  widget.controller.newsFeedController.userInfo.is_follow =
                      true;

                  await widget.controller.newsFeedController.addFollowing(
                      widget.controller.newsFeedController.userInfo.userId,
                      "follow");
                  widget.controller.userPosts.forEach((element) {
                    if (widget.controller.newsFeedController.userInfo.userId ==
                        element.userInfo.userId) {
                      element.userInfo.is_follow = true;
                    }
                  });
                  widget.controller.update();
                  isloadFollowing = false;
                  setState(() {});
                } else if (widget
                        .controller.newsFeedController.userInfo.is_follow ==
                    true) {
                  widget.controller.newsFeedController.userInfo.is_follow =
                      false;
                  await widget.controller.newsFeedController.addFollowing(
                      widget.controller.newsFeedController.userInfo.userId,
                      "unFollow");
                  widget.controller.userPosts.forEach((element) {
                    if (widget.controller.newsFeedController.userInfo.userId ==
                        element.userInfo.userId) {
                      element.userInfo.is_follow = false;
                    }
                  });
                  widget.controller.update();
                  isloadFollowing = false;
                  setState(() {});
                }
              },
              child: Text(
                !widget.controller.newsFeedController.userInfo.is_follow
                    ? "${Strings.follow}".capitalizeFirst
                    : "${Strings.unFollow}".capitalizeFirst,
                style: TextStyle(
                    height: 1.2,
                    fontSize: kIsWeb ? 14 : 12,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? !widget.controller.newsFeedController.userInfo
                                .is_follow
                            ? Colors.black
                            : Colors.white
                        : !widget.controller.newsFeedController.userInfo
                                .is_follow
                            ? Colors.white
                            : Colors.black,
                    fontWeight: FontWeight.w700),
                textAlign: TextAlign.center,
              ),
            ),
    );
  }
}
