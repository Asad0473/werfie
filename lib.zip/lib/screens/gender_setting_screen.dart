import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/rounded_button.dart';
import '../network/controller/profile_controller.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class GenderSettingScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  ProfileController profileController = Get.put(ProfileController());

  TextEditingController username = TextEditingController();

//  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.gender,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                    // TextStyle(
                    //     color: Colors.white,
                    //     fontSize: 18,
                    //     fontWeight: FontWeight.w700
                    // ),
                    // style: Theme.of(context).textTheme.headline6.copyWith(
                    //   fontSize: 18,
                    //   fontWeight: FontWeight.w700,
                    //   color: Colors.black,
                    // ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = true;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                if (!kIsWeb) {
                                  FocusManager.instance.primaryFocus?.unfocus();
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Column(
            children: [
              kIsWeb
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 17.0,
                        horizontal: 12,
                      ),
                      child: Row(
                        children: [
                          // MediaQuery.of(context).size.width >= 1050
                          //     ? SizedBox()
                          //     :
                          MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = false;
                                controller.isSettingDetail = false;
                                controller.isSettingTypeDetail = false;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                controller.isChangeUserName = false;
                                controller.isSettinggender = false;
                                controller.isAccountInformation = true;

                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.gender,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                                // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                //     fontSize: 18,fontWeight: FontWeight.w700
                                // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                //),
                                // style: Theme.of(context)
                                //     .textTheme
                                //     .headline6
                                //     .copyWith(
                                //       fontSize: 18,
                                //       fontWeight: FontWeight.w700,
                                //       color: Colors.black,
                                //     ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : Container(),
              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Text(
                  Strings.genderSettingTextDescription,
                  style: Styles.baseTextTheme.bodyText1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : kIsWeb
                            ? Colors.black.withOpacity(0.5)
                            : Colors.black,
                  ),
                ),
              ),
              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 30.0, right: 30),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: new Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            Strings.male,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                          Spacer(),
                          Radio(
                            value: 0,
                            groupValue: controller.radioValueGender,
                            onChanged: _handleRadioValueChange,
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Text(
                            Strings.female,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                          Spacer(),
                          new Radio(
                            value: 1,
                            groupValue: controller.radioValueGender,
                            onChanged: _handleRadioValueChange,
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          new Text(
                            Strings.other,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontWeight: FontWeight.w400,
                              fontSize: 14,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                          Spacer(),
                          new Radio(
                            value: 2,
                            groupValue: controller.radioValueGender,
                            onChanged: _handleRadioValueChange,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              SizedBox(
                height: 10,
              ),
              RoundedButton(
                Strings.save,
                () async {
                  await Get.find<ProfileController>()
                      .createData(gender: controller.gender)
                      .whenComplete(() => {
                            UtilsMethods.toastMessageShow(
                                controller.displayColor,
                                controller.displayColor,
                                controller.displayColor,
                                message: 'Gender Changed Successfully')
                          });

                  controller.update();

                  if (Get.isRegistered<ProfileController>()) {
                    Get.find<ProfileController>().userProfile =
                        await controller.getUserProfile();
                    profileController.update();
                    controller.isAccountInformation = true;
                    controller.isChangeUserName = false;

                    controller.update();
                  } else {
                    profileController.userProfile =
                        await controller.getUserProfile();
                    controller.isAccountInformation = true;
                    controller.isChangeUserName = false;
                    profileController.update();
                    controller.update();
                  }
                },
                horizontalPadding: 20.0,
                verticalPadding: 10.00,
                roundedButtonColor: controller.displayColor,
              ),
            ],
          ),
        );
      },
    );
  }

  void _handleRadioValueChange(int value) {
    print("privacy value${controller.gender}");

    controller.radioValueGender = value;

    switch (controller.radioValueGender) {
      case 0:
        controller.gender = "M";

        break;
      case 1:
        controller.gender = "F";

        break;
      case 2:
        controller.gender = "O";
        break;
    }
    controller.update();
  }
}
