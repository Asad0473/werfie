import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/message_request_screen.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/chat_screen_mobile.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/new_message_dialog.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/chatUserModel.dart';
import '../models/message.dart';
import '../utils/chat_utils.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import '../widgets/RegexTextHighlight.dart';
import '../widgets/blue_tick.dart';
import 'package:werfieapp/screens/chat_screen.dart';

class MobileMessageScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();
  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return WillPopScope(
          onWillPop: () async {
            controller.isBrowseScreen = false;
            controller.isNewsFeedScreen = true;
            controller.isTrendsScreen = false;
            controller.isWhoToFollowScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            controller.isProfileScreen = false;
            controller.isSettingsScreen = false;
            controller.update();
            Navigator.pop(context);
            return false;
          },
          child: Scaffold(
            appBar: !Responsive.isDesktop(context)
                ? kIsWeb
                    ? AppBar(
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        iconTheme: IconThemeData(
                          color: Color(0xFF4f515b),
                        ),
                        title: Container(
                          height: 45,
                          width: MediaQuery.of(context).size.width * 0.7,
                          child: TextField(
                            textAlignVertical: TextAlignVertical.bottom,
                            style: LightStyles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              // fontWeight: FontWeight.bold,
                            ),
                            cursorColor:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            decoration: InputDecoration(
                              hintText: Strings.search,
                              prefixIcon: Icon(
                                Icons.search,
                                size: 20,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                              hintStyle: LightStyles.baseTextTheme.headline3,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 1,
                                  color: Colors.grey,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 1,
                                  color: Colors.grey,
                                ),
                              ),
                              fillColor: Colors.grey[250],
                              filled: true,
                            ),
                          ),
                        ),
                        automaticallyImplyLeading:
                            !Responsive.isDesktop(context) ? true : false,
                      )
                    : AppBar(
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        iconTheme: IconThemeData(
                          color: Color(0xFF4f515b),
                        ),
                        leading: controller.userProfile == null
                            ? Container(
                                width: 24,
                                child: Center(
                                  child: SpinKitCircle(
                                    color: Colors.grey,
                                    size: 40,
                                  ),
                                ),
                              )
                            : GestureDetector(
                                onTap: () {
                                  Scaffold.of(context).openDrawer();
                                },
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(40),
                                    child: FadeInImage(
                                      fit: BoxFit.cover,
                                      width: 30,
                                      height: 30,
                                      placeholder: AssetImage(
                                          'assets/images/person_placeholder.png'),
                                      image: NetworkImage(controller
                                                  .userProfile.profileImage !=
                                              null
                                          ? controller.userProfile.profileImage
                                          : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                    ),
                                  ),
                                ),
                              ),
                        title: Container(
                          height: 45,
                          width: MediaQuery.of(context).size.width * 0.9,
                          child: searchChatBar(context),
                          // GestureDetector(
                          //   onTap: () {
                          //     Navigator.push(
                          //       context,
                          //       MaterialPageRoute(
                          //         builder: (BuildContext context) =>
                          //             const MobileSearchChatScreen(),
                          //       ),
                          //     );
                          //   },
                          //   child: TextField(
                          //     style: LightStyles.baseTextTheme.headline2.copyWith(
                          //       color: Theme.of(context).brightness ==
                          //               Brightness.dark
                          //           ? Colors.white
                          //           : Colors.black,
                          //       // fontWeight: FontWeight.bold,
                          //     ),
                          //     cursorColor:
                          //         Theme.of(context).brightness == Brightness.dark
                          //             ? Colors.white
                          //             : Colors.black,
                          //     onTap: () {
                          //       // Navigator.push(
                          //       //   context,
                          //       //   MaterialPageRoute(
                          //       //     builder: (BuildContext context) =>
                          //       //         SearchScreen(),
                          //       //   ),
                          //       // );
                          //     },
                          //     enabled: false,
                          //     textAlignVertical: TextAlignVertical.bottom,
                          //     decoration: InputDecoration(
                          //       hintText: "Strings.search",
                          //       hintStyle: LightStyles.baseTextTheme.headline3,
                          //       prefixIcon: Icon(
                          //         Icons.search,
                          //         size: 20,
                          //         color: Theme.of(context).brightness ==
                          //                 Brightness.dark
                          //             ? Colors.white
                          //             : Colors.black,
                          //       ),
                          //       border: OutlineInputBorder(
                          //         borderRadius: BorderRadius.circular(40),
                          //       ),
                          //       enabledBorder: OutlineInputBorder(
                          //         borderRadius: BorderRadius.circular(40),
                          //         borderSide: BorderSide(
                          //           width: 0,
                          //           style: BorderStyle.none,
                          //         ),
                          //       ),
                          //       disabledBorder : OutlineInputBorder(
                          //         borderRadius: BorderRadius.circular(40),
                          //         borderSide: BorderSide(
                          //           color:Colors.grey,
                          //           // width: 0,
                          //           // style: BorderStyle.none,
                          //         ),
                          //       ),
                          //       fillColor: Colors.grey[250],
                          //       filled: true,
                          //     ),
                          //   ),
                          // ),
                        ),
                        automaticallyImplyLeading:
                            !Responsive.isDesktop(context) ? true : false,
                      )
                : PreferredSize(
                    preferredSize: Size(0.0, 0.0),
                    child: Container(),
                  ),
            drawer: !Responsive.isDesktop(context)
                ? MainDrawer(controller)
                : Container(),
            drawerEnableOpenDragGesture:
                !Responsive.isDesktop(context) ? false : true,
            floatingActionButton: FloatingActionButton(
              heroTag: UniqueKey(),

              backgroundColor: controller.displayColor,
              onPressed: () {
                controller.idList.clear();
                controller.chatSearchTEC.clear();
                controller.usersList = null;
                controller.randomGroup = "";
                controller.update();
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      contentPadding: EdgeInsets.zero,
                      insetPadding: EdgeInsets.zero,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      content: NewMessageDialogBox(),
                    );
                  },
                );
              },
              child: Image.asset(
                'assets/chaticons/message_icon.png',
                width: 25,
                height: 25,
                color: Colors.white,
              ),
              // Icon(Icons.mark_email_unread,color: Colors.white,),
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  // Padding(
                  //   padding: const EdgeInsets.symmetric(horizontal: 10),
                  //   child: Row(
                  //     crossAxisAlignment: CrossAxisAlignment.end,
                  //     children: [
                  //       Expanded(
                  //         child: Text(
                  //           Strings.chats,
                  //           // style: TextStyle(
                  //           //     fontSize: 18,
                  //           //     color: Colors.black,
                  //           //     fontWeight: FontWeight.w900),
                  //           style: Styles.baseTextTheme.headline2.copyWith(
                  //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                  //             fontWeight: FontWeight.bold,
                  //           ),
                  //         ),
                  //       ),
                  //       // IconButton(
                  //       //   onPressed: () {},
                  //       //   icon: Icon(Icons.settings),
                  //       // ),
                  //       Padding(
                  //         padding: const EdgeInsets.only(top: 10.0),
                  //         child: InkWell(
                  //           onTap: () {
                  //             controller.idList.clear();
                  //             controller.chatSearchTEC.clear();
                  //             controller.usersList =null;
                  //             controller.randomGroup = "";
                  //             controller.update();
                  //             showDialog(
                  //               context: context,
                  //               builder: (BuildContext context) {
                  //                 return AlertDialog(
                  //                   contentPadding: EdgeInsets.zero,
                  //                   insetPadding: EdgeInsets.zero,
                  //                   shape: RoundedRectangleBorder(
                  //                     borderRadius: BorderRadius.circular(20),
                  //                   ),
                  //                   content: NewMessageDialogBox(),
                  //                 );
                  //               },
                  //             );
                  //           },
                  //           child: Column(
                  //             mainAxisAlignment: MainAxisAlignment.end,
                  //             crossAxisAlignment: CrossAxisAlignment.center,
                  //             children: [
                  //               Icon(Icons.mark_email_unread),
                  //               Text(
                  //                 "Create Chat",
                  //                 style: Styles.baseTextTheme.headline2.copyWith(
                  //                   color: Theme.of(context).brightness == Brightness.dark
                  //                       ? Colors.white
                  //                       : Colors.black,
                  //                   fontWeight: FontWeight.bold,
                  //                 ),
                  //               //   style: TextStyle(
                  //               //       color: Color(0xFFedab30), fontSize: 12),
                  //               // ),
                  //               )],
                  //           ),
                  //         ),
                  //       ),
                  //     ],
                  //   ),
                  // ),
                  Divider(),
                  SizedBox(height: 4),
                  controller.isChatLoad
                      ? Center(
                          child: CircularProgressIndicator(
                          color: MyColors.BlueColor,
                        ))
                      : controller == null || controller.chatUserList == null
                          ? CircularProgressIndicator(
                              color: MyColors.BlueColor,
                            ) : controller.isChatSearchActive && controller.messageSearchController.text.trim() != ""
                  // Chat search is active with a valid search string
                      ? allTabsSearchChat(context)
                      : controller.chatUserList != null ||
                                  controller.chatUserList.isNotEmpty
                              ? Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height: Get.height,
                                      child: SingleChildScrollView(
                                        child:  Column(
                                            children: [
                                              controller != null && controller.chatRequestUserList != null?
                                              InkWell(
                                                onTap: (){
                                                  Get.to(MessageRequestScreen());
                                                },
                                                child: ListTile(
                                                  leading: CircleAvatar(
                                                    child: Image.asset("assets/chaticons/message_icon.png",
                                                    color: Colors.black,
                                                      height: 50,
                                                      width: 50,
                                                    ),
                                                    backgroundColor: Colors.white,
                                                  ),
                                                  title: Text(Strings.messageRequests,
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold,
                                                      color: Theme.of(context).brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    ),
                                                  ),
                                                  subtitle: Text(controller.chatRequestUserList == null || controller == null? "0 " +Strings.pendingRequest:"${controller.chatRequestUserList.length} "+Strings.pendingRequest,
                                                  style: TextStyle(color: Theme.of(context).brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,),),

                                                ),
                                              )
                                                  :SizedBox(),
                                              ListView.separated(
                                            physics: ScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount:
                                                controller.chatUserList.length,
                                            itemBuilder: (context, index) {
                                              String getChatDate;
                                              getChatDate = controller
                                                          .chatUserList[index]
                                                          .latestMessageTime ==
                                                      null
                                                  ? ""
                                                  : UtilsMethods.getChatDate(
                                                      controller
                                                          .chatUserList[index]
                                                          .latestMessageTime);

                                              String ChatUserName = controller
                                                  .chatUserList[index].username;
                                              //   String ChatUserName = controller.chatUserList[index].username;
                                              String chatAuthorName = controller
                                                  .chatUserList[index].name;

                                              String conversationTitle = "";
                                              if (controller.chatUserList[index].conversationType == "group"){
                                                conversationTitle = ChatUtils.getGroupChatName(controller.chatUserList[index].members);
                                              } else {
                                                conversationTitle = controller.chatUserList[index].name ?? Strings.werfieUser;
                                              }

                                              return Slidable(
                                                endActionPane: ActionPane(
                                                  extentRatio: 0.3,
                                                  closeThreshold: 0.5,
                                                  motion: ScrollMotion(),
                                                  children: [
                                                    SlidableAction(
                                                      onPressed:
                                                          (context) async {
                                                        await controller
                                                            .leaveConversation(
                                                                controller
                                                                    .chatUserList[
                                                                        index]
                                                                    .conversationId);
                                                        controller
                                                                .chatUserList =
                                                            await controller
                                                                .getChat();
                                                        controller.update();
                                                      },
                                                      backgroundColor:
                                                          Color(0xFFFE4A49),
                                                      foregroundColor:
                                                          Colors.white,
                                                      icon: Icons.delete,
                                                      label: Strings.delete,
                                                    ),
                                                  ],
                                                ),
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          top: 0.0,
                                                          left: 0,
                                                          right: 0,
                                                          bottom: 0),
                                                  child: InkWell(
                                                    onTap: () {
                                                      controller
                                                              .isImagePickedChat =
                                                          false;
                                                      controller
                                                              .isVideoPickedChat =
                                                          false;
                                                      controller
                                                              .isDocumentPickedChat =
                                                          false;
                                                      controller
                                                          .messageController
                                                          .clear();
                                                      controller.showOverlay =
                                                          false;
                                                      controller.chatName =
                                                          controller
                                                                  .chatUserList[
                                                              index];
                                                      controller
                                                          .groupName = controller
                                                                  .chatName
                                                                  .conversationType ==
                                                              "group"
                                                          ? "${controller.chatName.name}"
                                                          : "${controller.chatName.name}";

                                                      // controller.update();
                                                      print("pressed");
                                                      controller.getMessagesOfAConversation(
                                                          controller.chatName
                                                              .conversationId);
                                                      controller
                                                              .isVideoThumbnail =
                                                          false;
                                                      controller
                                                              .videoThumbnail =
                                                          null;
                                                      controller.chatIndex =
                                                          index;

                                                      controller.tempGroupName =
                                                          "";
                                                      controller
                                                              .tempProfileImageGroupChat =
                                                          null;

                                                      controller.update();

                                                      controller.update();
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              ChatScreenMobile(
                                                                  controller, false),
                                                        ),
                                                      );
                                                    },
                                                    child: Card(
                                                      elevation: 0,
                                                      margin:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 0),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .symmetric(
                                                                horizontal:
                                                                    14.0,
                                                                vertical: 12),
                                                        child: Row(
                                                          children: [
                                                            controller
                                                                        .chatUserList[
                                                                            index]
                                                                        .conversationType !=
                                                                    "group"
                                                                ? CircleAvatar(
                                                                    backgroundImage: controller.chatUserList[index].profileImage !=
                                                                            null
                                                                        ? NetworkImage(controller
                                                                            .chatUserList[
                                                                                index]
                                                                            .profileImage)
                                                                        : AssetImage(
                                                                            'assets/images/person_placeholder.png'),
                                                                    radius: 22,
                                                                  )
                                                                : CircleAvatar(
                                                                    backgroundImage: controller.chatUserList[index].groupImage !=
                                                                            null
                                                                        ? NetworkImage(controller
                                                                            .chatUserList[
                                                                                index]
                                                                            .groupImage)
                                                                        : AssetImage(
                                                                            'assets/images/person_placeholder.png'),
                                                                    radius: 22,
                                                                  ),
                                                            SizedBox(
                                                              width: 20,
                                                            ),
                                                            Expanded(
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceEvenly,
                                                                children: [
                                                                  // FittedBox(
                                                                  //   child: Row(
                                                                  //
                                                                  //
                                                                  //     children: [
                                                                  //       controller.chatUserList[index].conversationType =="group" ?
                                                                  //       controller.chatUserList[index].name != null
                                                                  //           ? Text(
                                                                  //         "${controller.chatUserList[index].name}",
                                                                  //         style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //           fontSize: 15,
                                                                  //           fontWeight: FontWeight.bold,
                                                                  //         ),
                                                                  //       )
                                                                  //           : controller.chatUserList[index].members.length ==1
                                                                  //           ? FittedBox(
                                                                  //           child : Row(
                                                                  //             children: [
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members[0].firstname}",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //
                                                                  //
                                                                  //             ],
                                                                  //           )
                                                                  //       )
                                                                  //           : controller.chatUserList[index].members.length ==2
                                                                  //           ? FittedBox(
                                                                  //           child : Row(
                                                                  //             children: [
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members[0].firstname}, ",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members[1].firstname}",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //
                                                                  //             ],
                                                                  //           )
                                                                  //       )
                                                                  //           : controller.chatUserList[index].members.length==3
                                                                  //           ? FittedBox(
                                                                  //         child: Row(
                                                                  //           children: [
                                                                  //             Text(
                                                                  //               "${controller.chatUserList[index].members[0].firstname}, ",
                                                                  //               style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                 fontSize: 15,
                                                                  //                 fontWeight: FontWeight.bold,
                                                                  //               ),
                                                                  //             ),
                                                                  //             Text(
                                                                  //               "${controller.chatUserList[index].members.length - 1} other...",
                                                                  //               style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                 fontSize: 15,
                                                                  //                 fontWeight: FontWeight.bold,
                                                                  //               ),
                                                                  //             ),
                                                                  //           ],
                                                                  //         ),
                                                                  //       )
                                                                  //           : controller.chatUserList[index].members.length>=4
                                                                  //           ? FittedBox(
                                                                  //           child : Row(
                                                                  //             children: [
                                                                  //
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members[0].firstname}, ",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members[1].firstname}, ",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //               // Text(
                                                                  //               //   "${controller.chatUserList[index].members[2].firstname} and ",
                                                                  //               //   style: Theme.of(context).brightness == Brightness.dark ?
                                                                  //               //   TextStyle(color: Colors.white,
                                                                  //               //       fontWeight: FontWeight.w600,overflow:
                                                                  //               //       TextOverflow.ellipsis
                                                                  //               //   )
                                                                  //               //       : TextStyle(color: Colors.black,
                                                                  //               //       fontWeight: FontWeight.w600,overflow:
                                                                  //               //       TextOverflow.ellipsis
                                                                  //               //   ),
                                                                  //               // ),
                                                                  //               Text(
                                                                  //                 "${controller.chatUserList[index].members.length - 2} other...",
                                                                  //                 style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //                   fontSize: 15,
                                                                  //                   fontWeight: FontWeight.bold,
                                                                  //                 ),
                                                                  //               ),
                                                                  //             ],
                                                                  //           )
                                                                  //       )
                                                                  //
                                                                  //
                                                                  //           : SizedBox() :SizedBox(),
                                                                  //
                                                                  //
                                                                  //
                                                                  //
                                                                  //       controller.chatUserList[index].conversationType =="single"?
                                                                  //       Text(
                                                                  //         "${controller.chatUserList[index].name}",
                                                                  //         style:Styles.baseTextTheme.headline4.copyWith(
                                                                  //           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  //           fontSize: 15,
                                                                  //           fontWeight: FontWeight.bold,
                                                                  //         ),
                                                                  //       ):SizedBox(),
                                                                  //
                                                                  //       controller.chatUserList[index].accountVerified =="verified"?
                                                                  //       Row(children: [
                                                                  //         SizedBox(
                                                                  //           width: 5,
                                                                  //         ),
                                                                  //         BlueTick(
                                                                  //           height: 15,
                                                                  //           width: 15,
                                                                  //           iconSize:10,
                                                                  //         ),
                                                                  //       ],):SizedBox(),
                                                                  //       controller.chatUserList[index].conversationType =="group"
                                                                  //           ? Text("Group")
                                                                  //           : controller.chatUserList[index].conversationType =="single"?
                                                                  //       Container(
                                                                  //         width : ChatUserName.length>15 ? 100: null,
                                                                  //         child: Text(
                                                                  //           "@${ChatUserName}",
                                                                  //           overflow: ChatUserName.length>15 ? TextOverflow.ellipsis : null,
                                                                  //           softWrap: false,
                                                                  //           maxLines: 1,
                                                                  //           style: Styles.baseTextTheme.headline2.copyWith(
                                                                  //             fontWeight: FontWeight.w400,
                                                                  //             fontSize: kIsWeb ? 14 : 14,
                                                                  //           ),
                                                                  //         ),
                                                                  //       )
                                                                  //           : SizedBox(),
                                                                  //       controller.chatUserList[index].latestMessageTime == null  ? SizedBox() : Row(
                                                                  //         children: [
                                                                  //           Padding(
                                                                  //             padding: EdgeInsets
                                                                  //                 .only(
                                                                  //                 bottom: 10,
                                                                  //                 left: 2,
                                                                  //                 right: 2),
                                                                  //             child: Text(
                                                                  //               ".",
                                                                  //               style: Styles
                                                                  //                   .baseTextTheme
                                                                  //                   .headline2
                                                                  //                   .copyWith(
                                                                  //                 fontSize: 20,
                                                                  //                 fontWeight: FontWeight
                                                                  //                     .w500,
                                                                  //               ),
                                                                  //             ),
                                                                  //           ),
                                                                  //           Text(
                                                                  //             getChatDate == null
                                                                  //                 ? ""
                                                                  //                 : getChatDate,
                                                                  //             overflow: TextOverflow.ellipsis,
                                                                  //             maxLines: 1,
                                                                  //             style: Styles.baseTextTheme.headline2.copyWith(
                                                                  //               fontSize: kIsWeb ? 14 : 12,
                                                                  //             ),
                                                                  //           ),
                                                                  //         ],
                                                                  //       ),
                                                                  //     ],
                                                                  //   ),
                                                                  // ),
                                                                  Row(
                                                                    children: [
                                                                      controller.chatUserList[index].conversationType ==
                                                                              "group"
                                                                          ? /*controller.chatUserList[index].name != null
                                                                              ? Container(
                                                                                  width: chatAuthorName.length > 10 ? 85 : null,
                                                                                  child: Text(
                                                                                    "${chatAuthorName}",
                                                                                    overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                                                                                    maxLines: 1,
                                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontSize: 15,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              : controller.chatUserList[index].members.length == 1
                                                                                  ? FittedBox(
                                                                                      child: Row(
                                                                                      children: [
                                                                                        Container(
                                                                                          width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                          child: Text(
                                                                                            "${controller.chatUserList[index].members[0].firstname}",
                                                                                            overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                            maxLines: 1,
                                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                              fontSize: 15,
                                                                                              fontWeight: FontWeight.bold,
                                                                                            ),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ))
                                                                                  : controller.chatUserList[index].members.length == 2
                                                                                      ? FittedBox(
                                                                                          child: Row(
                                                                                          children: [
                                                                                            Container(
                                                                                              width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                              child: Text(
                                                                                                "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                                overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                                maxLines: 1,
                                                                                                style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight.bold,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                            Container(
                                                                                              width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                                                              child: Text(
                                                                                                "${controller.chatUserList[index].members[1].firstname}",
                                                                                                overflow: controller.chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                                maxLines: 1,
                                                                                                style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight.bold,
                                                                                                ),
                                                                                              ),
                                                                                            ),
                                                                                          ],
                                                                                        ))
                                                                                      : controller.chatUserList[index].members.length == 3
                                                                                          ? FittedBox(
                                                                                              child: Row(
                                                                                                children: [
                                                                                                  Container(
                                                                                                    width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                                    child: Text(
                                                                                                      "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                                      overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                                      maxLines: 1,
                                                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight.bold,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ),
                                                                                                  Text(
                                                                                                    "${controller.chatUserList[index].members.length - 1} ${Strings.otherChat}",
                                                                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                      fontSize: 15,
                                                                                                      fontWeight: FontWeight.bold,
                                                                                                    ),
                                                                                                  ),
                                                                                                ],
                                                                                              ),
                                                                                            )
                                                                                          : controller.chatUserList[index].members.length >= 4
                                                                                              ? FittedBox(
                                                                                                  child: Row(
                                                                                                  children: [
                                                                                                    Container(
                                                                                                      width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                                                                      child: Text(
                                                                                                        "${controller.chatUserList[index].members[0].firstname}, ",
                                                                                                        overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                                        maxLines: 1,
                                                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                          fontSize: 15,
                                                                                                          fontWeight: FontWeight.bold,
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                    Container(
                                                                                                      width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                                                                      child: Text(
                                                                                                        "${controller.chatUserList[index].members[1].firstname}, ",
                                                                                                        overflow: controller.chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                                                                        maxLines: 1,
                                                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                          fontSize: 15,
                                                                                                          fontWeight: FontWeight.bold,
                                                                                                        ),
                                                                                                      ),
                                                                                                    ),
                                                                                                    // Text(
                                                                                                    //   "${controller.chatUserList[index].members[2].firstname} and ",
                                                                                                    //   style: Theme.of(context).brightness == Brightness.dark ?
                                                                                                    //   TextStyle(color: Colors.white,
                                                                                                    //       fontWeight: FontWeight.w600,overflow:
                                                                                                    //       TextOverflow.ellipsis
                                                                                                    //   )
                                                                                                    //       : TextStyle(color: Colors.black,
                                                                                                    //       fontWeight: FontWeight.w600,overflow:
                                                                                                    //       TextOverflow.ellipsis
                                                                                                    //   ),
                                                                                                    // ),
                                                                                                    Text(
                                                                                                      "${controller.chatUserList[index].members.length - 2} ${Strings.otherChat}",
                                                                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                        fontSize: 15,
                                                                                                        fontWeight: FontWeight.bold,
                                                                                                      ),
                                                                                                    ),
                                                                                                  ],
                                                                                                ))
                                                                                              : SizedBox()*/
                                                                      Flexible(
                                                                        child: Container(
                                                                          // width: chatAuthorName.length > 10 ? 85 : null,
                                                                          child: Text(
                                                                            conversationTitle,
                                                                            overflow: TextOverflow.ellipsis,
                                                                            maxLines: 1,
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 15,
                                                                              fontWeight: FontWeight.bold,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      )
                                                                          : SizedBox(),

                                                                      controller.chatUserList[index].conversationType ==
                                                                              "single"
                                                                          ? Flexible(
                                                                            child: Container(
                                                                                // width: chatAuthorName.length > 10 ? 85 : null,
                                                                                child: Text(
                                                                                  chatAuthorName,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                  maxLines: 1,
                                                                                  style: Styles.baseTextTheme.headline4.copyWith(
                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                    fontSize: 15,
                                                                                    fontWeight: FontWeight.bold,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                          )
                                                                          : SizedBox(),

                                                                      // controller.chatUserList[index].accountVerified =="verified"?
                                                                      // Row(children: [
                                                                      //   SizedBox(
                                                                      //     width: 5,
                                                                      //   ),
                                                                      //   BlueTick(
                                                                      //     height: 15,
                                                                      //     width: 15,
                                                                      //     iconSize:10,
                                                                      //   ),
                                                                      // ],):SizedBox()
                                                                      controller.chatUserList[index].conversationType ==
                                                                              "group"
                                                                          ? Text(
                                                                              Strings.groupsTabChat,
                                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                                fontWeight: FontWeight.w400,
                                                                                fontSize: 15,
                                                                              ),
                                                                            )
                                                                          : controller.chatUserList[index].conversationType == "single"
                                                                              ? Container(
                                                                                  width: ChatUserName.length > 15 ? 100 : null,
                                                                                  child: Text(
                                                                                    "@${ChatUserName}",
                                                                                    overflow: ChatUserName.length > 15 ? TextOverflow.ellipsis : null,
                                                                                    softWrap: false,
                                                                                    maxLines: 1,
                                                                                    style: Styles.baseTextTheme.headline2.copyWith(
                                                                                      fontWeight: FontWeight.w400,
                                                                                      fontSize: 15,
                                                                                    ),
                                                                                  ),
                                                                                )
                                                                              : SizedBox(),
                                                                      controller.chatUserList[index].latestMessageTime ==
                                                                              null
                                                                          ? SizedBox()
                                                                          : Row(
                                                                              children: [
                                                                                SizedBox(
                                                                                  width: 2,
                                                                                ),
                                                                                Text(
                                                                                  "·",
                                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                                    fontSize: 20,
                                                                                    fontWeight: FontWeight.w500,
                                                                                  ),
                                                                                ),
                                                                                SizedBox(
                                                                                  width: 2,
                                                                                ),
                                                                                Text(
                                                                                  getChatDate == null ? "" : getChatDate,
                                                                                  overflow: TextOverflow.ellipsis,
                                                                                  maxLines: 1,
                                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                                    fontSize: 15,
                                                                                    fontWeight: FontWeight.w400,
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                    ],
                                                                  ),

                                                                  Text(
                                                                    controller.chatUserList[index].latest_message_type ==
                                                                            1
                                                                        ? controller
                                                                            .chatUserList[
                                                                                index]
                                                                            .latestMessage
                                                                        : controller.chatUserList[index].latest_message_type ==
                                                                                2
                                                                            ? Strings.photoChat
                                                                            : controller.chatUserList[index].latest_message_type == 3
                                                                                ? Strings.videoChat
                                                                                : controller.chatUserList[index].latest_message_type == 9
                                                                                    ? Strings.videoChat
                                                                                    : '',
                                                                    overflow:
                                                                        TextOverflow
                                                                            .ellipsis,
                                                                    maxLines: 1,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize:
                                                                          15,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w400,
                                                                    ),
                                                                  ),
                                                                  // SizedBox(
                                                                  //   width: kIsWeb
                                                                  //       ? 150
                                                                  //       : MediaQuery.of(context)
                                                                  //               .size
                                                                  //               .width *
                                                                  //           0.65,
                                                                  //   child: Text(
                                                                  //     controller.chatUserList[index].latestMessage == null
                                                                  //         ? ""
                                                                  //         : controller
                                                                  //             .chatUserList[index]
                                                                  //             .latestMessage,
                                                                  //     overflow:
                                                                  //         TextOverflow
                                                                  //             .ellipsis,
                                                                  //     maxLines: 1,
                                                                  //     style: Styles.baseTextTheme.headline4.copyWith(
                                                                  //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                                                  //       fontSize: 14,
                                                                  //     ),
                                                                  //   ),
                                                                  // ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              );
                                            },
                                            separatorBuilder: (_, __) {
                                              return Container(
                                                height: 0.5,
                                                color: Colors.grey[300],
                                              );
                                            },
                                          ),
                                        ]),
                                      ),
                                    ),
                                  ],
                                )
                              : Column(
                                  children: [
                                    Text(
                                      Strings.sendAMessageGetAMessage,
                                      // style: TextStyle(
                                      //     fontSize: 18,
                                      //     color: Colors.black,
                                      //     fontWeight: FontWeight.w900),
                                      style: Styles.baseTextTheme.headline4
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb ? 14 : 12,
                                      ),
                                    ),
                                    SizedBox(height: 10),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0),
                                      child: Text(
                                        Strings
                                            .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                                        textAlign: TextAlign.center,
                                        style: Styles.baseTextTheme.headline4
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: kIsWeb ? 14 : 12,
                                        ),
                                      ),
                                    ),
                                    SizedBox(height: 14),
                                    RoundedButton(
                                      Strings.startAConversation,
                                      () {
                                        showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return AlertDialog(
                                              contentTextStyle:
                                                  Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.black,
                                                        ),
                                              contentPadding: EdgeInsets.zero,
                                              insetPadding: EdgeInsets.zero,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              content: NewMessageDialogBox(),
                                            );
                                          },
                                        );
                                      },
                                      horizontalPadding: 40.0,
                                      roundedButtonColor:
                                          controller.displayColor,
                                    ),
                                  ],
                                )
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /* Chat Search related methods */
  Widget searchChatBar(var context){
    return Row(
      children: [
        controller.isChatSearchActive ? GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            controller.isChatSearchActive = false;
            controller.messageSearchController.text= "";
            controller.update();
          },
          child: Container(
            margin: const EdgeInsets.only(right:5.0),
            child: Icon(
              Icons.arrow_back,
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
              size: 25,
            ),
          ),
        ) : Container(),
        Expanded(
          child: TextField(
            controller: controller.messageSearchController,
            onTap: (){
              controller.isChatSearchActive = true;
              controller.update();

            },
            onChanged: (value){
              controller.isChatSearchActive = true;
              if (value != null && value.trim() != ""){
                controller.searchChat(value);
              }
              // controller.update();
            },
            onTapOutside: (event) => FocusScope.of(context).unfocus(),
            style: LightStyles.baseTextTheme.headline2.copyWith(
              color:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              //fontWeight: FontWeight.w500,
              // fontSize: 14,
            ),
            cursorColor:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            textAlignVertical: TextAlignVertical.bottom,
            decoration: InputDecoration(
              hintText: Strings.searchChats, //Strings.search,
              hintStyle: LightStyles.baseTextTheme.headline3,
              prefixIcon: Icon(
                Icons.search,
                size: 20,
                color: Theme.of(context).brightness ==
                    Brightness.dark
                    ? Colors.white
                    : Colors.black,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(40),
                borderSide:
                BorderSide(color: Colors.grey, width: 1),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(40),
                borderSide:
                BorderSide(color: Colors.grey, width: 1),
                // style: BorderStyle.none,
              ),
              fillColor: Colors.grey[250],
              filled: true,
            ),
          ),
        ),
      ],
    );
  }
  Widget noSearchResultMessage(var context){
    return Container(
      margin: const EdgeInsets.only(top: 50),
      child: Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "${Strings.noResultsFor} '${controller.messageSearchController.text}'", // Strings.youDoNotHaveAChatSelected,
            // style: TextStyle(
            //     fontSize: 18,
            //     color: Colors.black,
            //     fontWeight: FontWeight.w900),

            style: Styles.baseTextTheme.headline2.copyWith(
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 25 : 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            Strings.theTermYouEnteredDidNotBring,
            // Strings.chooseOneFromYourExistingChatsOrStartANewOne,
            // style: TextStyle(color: Colors.black),

            style: Theme.of(context).brightness ==
                Brightness.dark
                ? TextStyle(color: Colors.white)
                : TextStyle(color: Colors.black),
          ),
          SizedBox(height: 14),
          // RoundedButton(
          //   Strings.newChat,
          //       () {
          //     showDialog(
          //       context: context,
          //       builder: (BuildContext context) {
          //         return AlertDialog(
          //           backgroundColor:
          //           Theme.of(context).brightness ==
          //               Brightness.dark
          //               ? Colors.black
          //               : Colors.white,
          //           contentPadding: EdgeInsets.zero,
          //           insetPadding: EdgeInsets.zero,
          //           shape: RoundedRectangleBorder(
          //             borderRadius: BorderRadius.circular(20),
          //           ),
          //           content: NewMessageDialogBox(),
          //         );
          //       },
          //     );
          //   },
          //   horizontalPadding: 40,
          //   roundedButtonColor: controller.displayColor,
          // ),
        ],
      ),
    );
  }
  Widget allTabsSearchChat(var context){
    return Column(
      children: [
        controller.chatSearchPeopleList.isEmpty && controller.chatSearchGroupList.isEmpty && controller.chatSearchMessageList.isEmpty
            ? noSearchResultMessage(context) : SizedBox(),
        controller.chatSearchPeopleList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    'assets/svg_drawer_icons/profileFill.svg',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),

                Text(
                  Strings.people,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchPeopleList(controller.chatSearchPeopleList, context),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        controller.chatSearchGroupList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                    margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                    child: const Icon(Icons.group,)),
                Text(
                  Strings.groupsTabChat,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchGroupList(controller.chatSearchGroupList,  context),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        controller.chatSearchMessageList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    'assets/svg_drawer_icons/messageFill.svg',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),
                Text(
                  Strings.message,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchMessageList(controller.chatSearchMessageList, context),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        const SizedBox(height: 10.0,),
      ],
    );
  }
  Widget searchPeopleList(List<MessageModel> searchPeopleList, var context){
    if(searchPeopleList.isEmpty){
      return noSearchResultMessage(context);
    }

    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: searchPeopleList.length,
        itemBuilder: (BuildContext context, int index){

          String ChatUserName = searchPeopleList[index].username ?? "";
          String chatAuthorName = searchPeopleList[index].firstname ?? "";

          return Padding(
            padding: const EdgeInsets.only(
                top: 0.0, left: 0, right: 0),
            child: Card(
              elevation: 0.0,
              color:
              /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
              controller.chatName != null && controller.chatName.conversationId != null
                  // && controller.chatUserList[index].conversationId != null
                  && controller.chatName.conversationId == searchPeopleList[index].id
              // controller.highlighteTheChat ==  index
                  ? Theme.of(context).brightness == Brightness.dark
                  ? Color(0xff202327)
                  : Color(0xffeff3f4)
                  : Colors.transparent,
              child: InkWell(
                onTap: () {
                  gotoChatMessage(context, searchPeopleList[index].conversationId);
                  // controller.messageController.text = "";
                  // controller.tempGroupName = "";
                  // controller.tempProfileImageGroupChat = null;
                  // controller.update();
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             ChatScreenMobile(
                  //                 controller, false)));
                },
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: searchPeopleList[
                          index]
                              .profileImage !=
                              null
                              ? NetworkImage(searchPeopleList[
                          index]
                              .profileImage)
                              : AssetImage(
                              'assets/images/person_placeholder.png'),
                          radius: 22,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: [
                              FittedBox(
                                child: Row(
                                  children: [
                                    Container(width: 1.0, height:1.0),
                                    Container(
                                      width: chatAuthorName.length > 10 ? 85 : null,
                                      child: Text(
                                        "${chatAuthorName}",
                                        overflow: chatAuthorName.length > 10
                                            ? TextOverflow.ellipsis : null,
                                        maxLines: 1,
                                        style: Styles
                                            .baseTextTheme
                                            .headline4
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors
                                              .white
                                              : Colors
                                              .black,
                                          fontSize:
                                          15,
                                          fontWeight:
                                          FontWeight
                                              .bold,
                                        ),
                                      ),
                                    ),


                                    // controller.chatUserList[index].accountVerified =="verified"?
                                    // Row(children: [
                                    //   SizedBox(
                                    //     width: 5,
                                    //   ),
                                    //   BlueTick(
                                    //     height: 15,
                                    //     width: 15,
                                    //     iconSize:10,
                                    //   ),
                                    // ],):SizedBox()



                                  ],
                                ),
                              ),
                              RegexTextHighlight(text: "@$ChatUserName",
                                maxLines: 1,
                                highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                                highlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                                nonHighlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                              ),
                              // Container(
                              //   // width: ChatUserName.length >
                              //   //     15
                              //   //     ? 100
                              //   //     : null,
                              //   child: Text(
                              //     "@${ChatUserName}",
                              //     overflow: TextOverflow.ellipsis,
                              //     softWrap:
                              //     false,
                              //     maxLines:
                              //     1,
                              //     style: Styles
                              //         .baseTextTheme
                              //         .headline2
                              //         .copyWith(
                              //       fontWeight:
                              //       FontWeight.w400,
                              //       fontSize:
                              //       15,
                              //     ),
                              //   ),
                              // ),

                            ],
                          ),
                        ),

                      ],
                    )),
              ),
            ),
          );
        });
  }
  Widget searchGroupList(List<ChatUserModel> searchChatUserList, var context){
    if(searchChatUserList.isEmpty){
      return noSearchResultMessage(context);
    }
    int groupLength = searchChatUserList.length;
    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: groupLength,
        itemBuilder: (BuildContext context, int index){
          String chatAuthorName = searchChatUserList[index].name ?? "";
          return Padding(
            padding: const EdgeInsets.only(
                top: 0.0, left: 0, right: 0),
            child: Card(
              elevation: 0.0,
              // color:
              /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
              // controller.chatName != null && controller.chatName.conversationId != null
              //     && controller.chatUserList[index].conversationId != null
              //     && controller.chatName.conversationId == controller.chatUserList[index].conversationId
              // // controller.highlighteTheChat ==  index
              //     ? Theme.of(context).brightness == Brightness.dark
              //     ? Color(0xff202327)
              //     : Color(0xffeff3f4)
              //     : Colors.transparent,
              child: InkWell(
                onTap: () {
                  gotoChatMessage(context, searchChatUserList[index].conversationId);
                  // print("pressed");
                  // controller.messageController.text =
                  // "";
                  // controller.tempGroupName = "";
                  // controller
                  //     .tempProfileImageGroupChat =
                  // null;
                  // controller.update();
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             ChatScreenMobile(
                  //                 controller, false)));
                },
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [

                        CircleAvatar(
                          backgroundImage:
                          searchChatUserList[
                          index]
                              .groupImage !=
                              null
                              ? NetworkImage(

                              searchChatUserList[
                              index]
                                  .groupImage)
                              : AssetImage(
                              'assets/images/person_placeholder.png'),
                          radius: 22,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: [
                              FittedBox(
                                child: Row(
                                  children: [
                                    Container(width: 1.0, height:1.0),
                                    // chatUserList[index].conversationType == "group" ?
                                    // : chatUserList[index].members.length == 1
                                    //         ? FittedBox(
                                    //         child:
                                    //         Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10
                                    //                   ? 85
                                    //                   : null,
                                    //               child:
                                    //               Text(
                                    //                 "${chatUserList[index].members[0].firstname}",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : chatUserList[index].members.length ==
                                    //         2
                                    //         ? FittedBox(
                                    //         child:
                                    //         Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[0].firstname}, ",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             Container(
                                    //               width: chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[1].firstname}",
                                    //                 overflow: chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : chatUserList[index].members.length ==
                                    //         3
                                    //         ? FittedBox(
                                    //       child: Row(
                                    //         children: [
                                    //           Container(
                                    //             width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //             child: Text(
                                    //               "${chatUserList[index].members[0].firstname}, ",
                                    //               overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //               maxLines: 1,
                                    //               style: Styles.baseTextTheme.headline4.copyWith(
                                    //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                 fontSize: 15,
                                    //                 fontWeight: FontWeight.bold,
                                    //               ),
                                    //             ),
                                    //           ),
                                    //           Text(
                                    //             "${chatUserList[index].members.length - 1} other...",
                                    //             style: Styles.baseTextTheme.headline4.copyWith(
                                    //               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //               fontSize: 15,
                                    //               fontWeight: FontWeight.bold,
                                    //             ),
                                    //           ),
                                    //         ],
                                    //       ),
                                    //     )
                                    //         : chatUserList[index].members.length >= 4
                                    //         ? FittedBox(
                                    //         child: Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[0].firstname}, ",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             Container(
                                    //               width: chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[1].firstname}, ",
                                    //                 overflow: chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             // Text(
                                    //             //   "${controller.chatUserList[index].members[2].firstname} and ",
                                    //             //   style: Theme.of(context).brightness == Brightness.dark ?
                                    //             //   TextStyle(color: Colors.white,
                                    //             //       fontWeight: FontWeight.w600,overflow:
                                    //             //       TextOverflow.ellipsis
                                    //             //   )
                                    //             //       : TextStyle(color: Colors.black,
                                    //             //       fontWeight: FontWeight.w600,overflow:
                                    //             //       TextOverflow.ellipsis
                                    //             //   ),
                                    //             // ),
                                    //             Text(
                                    //               "${chatUserList[index].members.length - 2} other...",
                                    //               style: Styles.baseTextTheme.headline4.copyWith(
                                    //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                 fontSize: 15,
                                    //                 fontWeight: FontWeight.bold,
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : SizedBox()
                                    //         : SizedBox(),

                                    // controller.chatUserList[index].accountVerified != null &&
                                    // controller.chatUserList[index].accountVerified =="verified"?
                                    // Row(children: [
                                    //   SizedBox(
                                    //     width: 5,
                                    //   ),
                                    //   BlueTick(
                                    //     height: 15,
                                    //     width: 15,
                                    //     iconSize:10,
                                    //   ),
                                    // ],):SizedBox(),
                                    Text(
                                      Strings.groupsTabChat,
                                      style: Styles
                                          .baseTextTheme
                                          .headline2
                                          .copyWith(
                                        fontWeight:
                                        FontWeight
                                            .bold,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark ? Colors.white : Colors.black,
                                        fontSize: 15,
                                      ),
                                    ),
                                    // chatUserList[index].latestMessageTime == null
                                    //     ? SizedBox()
                                    //     : Row(
                                    //   children: [
                                    //     SizedBox(
                                    //       width: 2,
                                    //     ),
                                    //     Text(
                                    //       ".",
                                    //       style: Styles
                                    //           .baseTextTheme
                                    //           .headline2
                                    //           .copyWith(
                                    //         fontSize:
                                    //         20,
                                    //         fontWeight:
                                    //         FontWeight
                                    //             .w500,
                                    //       ),
                                    //     ),
                                    //     SizedBox(
                                    //       width: 2,
                                    //     ),
                                    //     Text(
                                    //       getChatDate ==
                                    //           null
                                    //           ? ""
                                    //           : getChatDate,
                                    //       overflow:
                                    //       TextOverflow
                                    //           .ellipsis,
                                    //       maxLines: 1,
                                    //       style: Styles
                                    //           .baseTextTheme
                                    //           .headline2
                                    //           .copyWith(
                                    //         fontSize:
                                    //         15,
                                    //         fontWeight:
                                    //         FontWeight
                                    //             .w400,
                                    //       ),
                                    //     ),
                                    //   ],
                                    // ),


                                  ],
                                ),
                              ),
                              RegexTextHighlight(text: chatAuthorName,
                                maxLines: 1,
                                highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                                highlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                                nonHighlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                              ),

                              // chatUserList[index].name != null
                              //     ? Container(
                              //   width: 170, //chatAuthorName.length > 10 ? 85 : null,
                              //   child: Text(
                              //     "${chatAuthorName}",
                              //     overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                              //     maxLines: 1,
                              //     style: Styles.baseTextTheme.headline4
                              //         .copyWith(
                              //
                              //       fontSize: 15,
                              //       fontWeight: FontWeight.w400,
                              //     ),
                              //   ),
                              // ) : Container(),
                            ],
                          ),
                        ),

                      ],
                    )),
              ),
            ),
          );
        });
  }
  Widget searchMessageList(List<MessageModel> msgModelList, var context){
    if(msgModelList.isEmpty){
      return noSearchResultMessage(context);
    }
    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: msgModelList.length,
        itemBuilder: (BuildContext context, int index){
          // String getChatDate;
          // getChatDate = chatUserList[index]
          //     .latestMessageTime ==
          //     null
          //     ? ""
          //     : UtilsMethods.getChatDate(chatUserList[index].latestMessageTime);

          // String ChatUserName = msgModelList[index].username ?? "";
          String chatAuthorName = msgModelList[index].firstname ?? "";
          String message = msgModelList[index].body ?? "";

          // return Text("Search $index");
          return Padding(
            padding: const EdgeInsets.only(
                top: 0.0, left: 0, right: 0),
            child: Card(
              elevation: 0.0,
              // color:
              /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
              // controller.chatName != null && controller.chatName.conversationId != null
              //     && controller.chatUserList[index].conversationId != null
              //     && controller.chatName.conversationId == controller.chatUserList[index].conversationId
              // // controller.highlighteTheChat ==  index
              //     ? Theme.of(context).brightness == Brightness.dark
              //     ? Color(0xff202327)
              //     : Color(0xffeff3f4)
              //     : Colors.transparent,
              child: InkWell(
                onTap: () {
                  gotoChatMessage(context, msgModelList[index].conversationId);
                  // controller.messageController.text =
                  // "";
                  // controller.tempGroupName = "";
                  // controller
                  //     .tempProfileImageGroupChat =
                  // null;
                  // controller.update();
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(
                  //         builder: (context) =>
                  //             ChatScreenMobile(
                  //                 controller, false)));
                },
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: msgModelList[
                          index]
                              .profileImage !=
                              null
                              ? NetworkImage(msgModelList[
                          index]
                              .profileImage)
                              : AssetImage(
                              'assets/images/person_placeholder.png'),
                          radius: 22,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: [
                              FittedBox(
                                child: Row(
                                  children: [
                                    Container(width: 1.0, height:1.0),
                                    Container(
                                      width: chatAuthorName.length > 10 ? 85 : null,
                                      child: Text(
                                        "${chatAuthorName}",
                                        overflow: chatAuthorName.length > 10
                                            ? TextOverflow.ellipsis : null,
                                        maxLines: 1,
                                        style: Styles
                                            .baseTextTheme
                                            .headline4
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors
                                              .white
                                              : Colors
                                              .black,
                                          fontSize:
                                          15,
                                          fontWeight:
                                          FontWeight
                                              .bold,
                                        ),
                                      ),
                                    ),


                                    // msgModelList[index].accountVerified =="verified"?
                                    // Row(children: [
                                    //   SizedBox(
                                    //     width: 5,
                                    //   ),
                                    //   BlueTick(
                                    //     height: 15,
                                    //     width: 15,
                                    //     iconSize:10,
                                    //   ),
                                    // ],):SizedBox()



                                  ],
                                ),
                              ),

                              RegexTextHighlight(text: message,
                                maxLines: 2,
                                highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                                highlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                                nonHighlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                              ),
                              // Container(
                              //   // width: ChatUserName.length >
                              //   //     15
                              //   //     ? 100
                              //   //     : null,
                              //   child: Text(
                              //     message,
                              //     overflow: TextOverflow.ellipsis,
                              //     softWrap: false,
                              //     maxLines: 2,
                              //     style: Styles
                              //         .baseTextTheme
                              //         .headline2
                              //         .copyWith(
                              //       fontWeight:
                              //       FontWeight.w400,
                              //       fontSize:
                              //       15,
                              //     ),
                              //   ),
                              // ),

                            ],
                          ),
                        ),

                      ],
                    )),
              ),
            ),
          );
        });
  }
  gotoChatMessage(var context, var conversationId){
    print("conversation ID : $conversationId");
    controller.isImagePickedChat = false;
    controller.isVideoPickedChat = false;
    controller.isDocumentPickedChat = false;
    controller.messageController.clear();
    controller.showOverlay = false;
    for(int i = 0; i < controller.chatUserList.length; i++ ){
      if (controller.chatUserList[i].conversationId == conversationId){
        controller.chatName = controller.chatUserList[i];
      }
    }
    controller.groupName = controller.chatName.conversationType == "group"
        ? "${controller.chatName.name}"
        : "${controller.chatName.name}";
    controller.getMessagesOfAConversation(conversationId);
    controller.isVideoThumbnail = false;
    controller.videoThumbnail = null;
    // controller.chatIndex = index;

    controller.tempGroupName = "";
    controller.tempProfileImageGroupChat = null;
    controller.update();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ChatScreenMobile(controller, false),
      ),
    );
  }
}
