import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/hash_taga_werfs_screen.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';

import '../network/api.dart';
import '../network/singleTone.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../utils/urls.dart';
import '../web_views/web_guest_user/components/guest_user_tab_button.dart';
import '../widgets/blue_tick.dart';
import 'filter_screen.dart';

class BrowseScreen extends StatefulWidget {
  BrowseScreen({this.controller});

  final NewsfeedController controller;

  @override
  State<BrowseScreen> createState() => _BrowseScreenState();
}

class _BrowseScreenState extends State<BrowseScreen> {
  @override
  void initState() {
    addExploreMetaTags();
    super.initState();
  }

  addExploreMetaTags(){
    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleExplore,
        metaTagDescription: MetaTagValues.exploreMetaDescription,
        metaTagKeywords: MetaTagValues.exploreMetaKeywords,
        ogTitle: MetaTagValues.exploreOGTitle,
        ogDescription: MetaTagValues.exploreOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
          onWillPop: () async {
            widget.controller.isBrowseScreen = false;
            widget.controller.isNewsFeedScreen = true;
            widget.controller.isTrendsScreen = false;
            widget.controller.isWhoToFollowScreen = false;
            widget.controller.isNotificationScreen = false;
            widget.controller.isChatScreen = false;
            widget.controller.isSavedPostScreen = false;
            widget.controller.isProfileScreen = false;
            widget.controller.isSettingsScreen = false;
            widget.controller.update();
            Navigator.pop(context);
            return false;
          },
          child: MobileBrowseScreen(
            newsfeedController: widget.controller,
          ),
        ),
        tablet: MobileBrowseScreen(
          newsfeedController: widget.controller,
        ),
        desktop: MobileBrowseScreen(
          newsfeedController: widget.controller,
        ),
      ),
    );
  }
}

class MobileBrowseScreen extends StatefulWidget {
  MobileBrowseScreen({this.newsfeedController});

  final NewsfeedController newsfeedController;

  @override
  State<MobileBrowseScreen> createState() => _MobileBrowseScreenState();
}

class _MobileBrowseScreenState extends State<MobileBrowseScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final BrowseController controller = Get.put(BrowseController());

  final storage = GetStorage();
  var api = Api();

  bool _isLastPage;
  int _pageNumber;
  bool _error;
  bool _loading;
  int _numberOfPostsPerRequest;
  List<Post> _posts;
  ScrollController _scrollController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _pageNumber = 0;
    _posts = [];
    _isLastPage = false;
    _loading = true;
    _error = false;
    _numberOfPostsPerRequest = 10;
    _scrollController = ScrollController();
    fetchData();
  }

  @override
  void dispose() {
    super.dispose();
    _scrollController.dispose();
  }

  Future<void> fetchData() async {
    try {
      String getResponse = await api.get(
        Uri.parse(Url.getBrowsePostUrl + '?page_no=' + _pageNumber.toString()),
        token: {
          'X-Requested-With': 'XMLHttpRequest',
          'Authorization': 'Bearer e06b4395-4411-4c2c-9585-952900e5ba25',
          'Token': storage.read('token'),
        },
      );
      final response = jsonDecode(getResponse);
      if (response['meta']["code"] == 200) {
        if (response['data'] != null) {
          var postData = response['data'] as List;

          List<Post> postList = postData.map((e) => Post.fromJson(e)).toList();
          if (mounted) {
            setState(() {
              _isLastPage = postList.length < _numberOfPostsPerRequest;
              _loading = false;
              _pageNumber = _pageNumber + 1;
              _posts.addAll(postList);
            });
          }
        }
      }
    } catch (e) {
      print("error --> $e");

      if (mounted) {
        setState(() {
          _loading = false;
          _error = true;
        });
      }
    }
  }

  // Widget buildPostsView() {
  //   if (_posts.isEmpty) {
  //     if (_loading) {
  //       return const Center(
  //           child: Padding(
  //             padding: EdgeInsets.all(8),
  //             child: CircularProgressIndicator(color: MyColors.BlueColor,),
  //           ));
  //     } else if (_error) {
  //       return Center(child: errorDialog(size: 20));
  //     }
  //   }
  //   return ListView.builder(
  //       shrinkWrap: true,
  //       itemCount: _posts.length + (_isLastPage ? 0 : 1),
  //       itemBuilder: (context, index) {
  //         if (index == _posts.length) {
  //           if (_error) {
  //             return Center(child: errorDialog(size: 15));
  //           } else {
  //             return const Center(
  //                 child: Padding(
  //                   padding: EdgeInsets.all(8),
  //                   child: CircularProgressIndicator(color: MyColors.BlueColor,),
  //                 ));
  //           }
  //         }
  //
  //         final Post post = _posts[index];
  //         return Padding(
  //             padding: const EdgeInsets.all(15.0),
  //             child: VisibilityDetector(
  //               key: Key('postCard-widget-key'),
  //               onVisibilityChanged: (visibilityInfo) {
  //                 double visiblePercentage = visibilityInfo.visibleFraction * 100;
  //                 debugPrint('Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
  //                 if (visiblePercentage > 20 && post.authorId != controller.newsfeedController.userId) {
  //                   controller.newsfeedController.emitImpressionsSocket(post.postId);
  //                 }
  //               },
  //               child: PostCard(
  //
  //                postList: _posts,
  //                 post: post,
  //                 scaffoldKey: _scaffoldKey,
  //                 controller: controller.newsfeedController,
  //                 browseController: controller,
  //                 index: index,
  //                 deletePostId: 3,
  //               ),
  //             ));
  //       });
  // }

  Widget errorDialog({double size}) {
    return SizedBox(
      height: 180,
      width: 200,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'An error occurred when fetching the posts.',
            style: TextStyle(
                fontSize: size,
                fontWeight: FontWeight.w500,
                color: Colors.black),
          ),
          const SizedBox(
            height: 10,
          ),
          ElevatedButton(
              onPressed: () {
                setState(() {
                  _loading = true;
                  _error = false;
                  fetchData();
                });
              },
              child: const Text(
                "Retry",
                style: TextStyle(fontSize: 20, color: Colors.purpleAccent),
              )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BrowseController>(builder: (controller) {
      return GestureDetector(
          onTap: () {
            controller.isSearch = false;
            controller.searchResult = [];
            controller.update();
          },
          child: Scaffold(
            appBar: !Responsive.isDesktop(context)
                ? kIsWeb
                    ? MediaQuery.of(context).size.width >= 500
                        ? PreferredSize(
                            preferredSize: Size(0.0, 0.0),
                            child: Container(),
                          )
                        : AppBar(
                            backgroundColor: Colors.black,
                            iconTheme: IconThemeData(
                              color: Color(0xFF4f515b),
                            ),
                            title: Container(
                              height: 45,
                              width: MediaQuery.of(context).size.width * 0.7,
                              child: TextField(
                                style: LightStyles.baseTextTheme.headline2
                                    .copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  // fontSize: 14,
                                  // fontWeight: FontWeight.bold,
                                ),
                                cursorColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                textAlignVertical: TextAlignVertical.bottom,
                                autofocus: controller.searchField,
                                onTap: () {
                                  controller.searchField = true;
                                  controller.update();
                                },
                                decoration: InputDecoration(
                                  hintText: Strings.search,
                                  prefixIcon: Icon(
                                    Icons.search,
                                    size: 20,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                  hintStyle:
                                      LightStyles.baseTextTheme.headline3,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40),
                                    borderSide: BorderSide(
                                        color: Colors.grey, width: 1),
                                  ),
                                  fillColor: Colors.grey[250],
                                  filled: true,
                                ),
                              ),
                            ),
                            automaticallyImplyLeading:
                                !Responsive.isDesktop(context) ? true : false,
                          )
                    : AppBar(
                        leading: widget.newsfeedController.userProfile == null
                            ? Container(
                                width: 24,
                                child: Center(
                                  child: SpinKitCircle(
                                    color: Colors.grey,
                                    size: 40,
                                  ),
                                ),
                              )
                            : Builder(
                                builder: (BuildContext context) {
                                  return GestureDetector(
                                    onTap: () {
                                      print('pressed');
                                      Scaffold.of(context).openDrawer();
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 10),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(40),
                                        child: FadeInImage(
                                          fit: BoxFit.cover,
                                          width: 30,
                                          height: 30,
                                          placeholder: AssetImage(
                                              'assets/images/person_placeholder.png'),
                                          image: NetworkImage(widget
                                                      .newsfeedController
                                                      .userProfile
                                                      .profileImage !=
                                                  null
                                              ? widget.newsfeedController
                                                  .userProfile.profileImage
                                              : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                        ),
                                      ),
                                    ),
                                  );
                                },
                              ),
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        iconTheme: IconThemeData(
                          color: Color(0xFF4f515b),
                        ),
                        title: Container(
                          height: 45,
                          width: MediaQuery.of(context).size.width * 0.9,
                          child: TextField(
                            readOnly: true,
                            //Clickable and not editable

                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      SearchScreen(),
                                ),
                              );
                            },
                            style: LightStyles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              // fontSize: 14,
                              // fontWeight: FontWeight.bold,
                            ),
                            cursorColor:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            textAlignVertical: TextAlignVertical.bottom,
                            decoration: InputDecoration(
                              hintText: Strings.search,
                              hintStyle: LightStyles.baseTextTheme.headline3,
                              prefixIcon: Icon(
                                Icons.search,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                size: 20,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide:
                                    BorderSide(color: Colors.grey, width: 1),
                              ),
                              fillColor: Colors.grey[250],
                              filled: true,
                            ),
                          ),
                        ),
                        automaticallyImplyLeading:
                            !Responsive.isDesktop(context) ? true : false,
                      )
                : PreferredSize(
                    preferredSize: Size(0.0, 0.0),
                    child: Container(),
                  ),
            drawer: !Responsive.isDesktop(context)
                ? MainDrawer(widget.newsfeedController)
                : Container(),
            drawerEnableOpenDragGesture:
                !Responsive.isDesktop(context) ? false : true,
            body:

                // buildPostsView()

                Stack(
              children: [
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      kIsWeb
                          ? Padding(
                              padding: const EdgeInsets.only(
                                  left: 10.0, right: 10, top: 8.0, bottom: 8.0),
                              child: TextField(
                                style: LightStyles.baseTextTheme.headline2
                                    .copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  // fontSize: 14,
                                  // fontWeight: FontWeight.bold,
                                ),
                                cursorColor: Colors.black,
                                autofocus: controller.searchField,
                                textAlign: TextAlign.start,
                                controller: controller.searchText,
                                keyboardType: TextInputType.text,
                                onChanged: (val) {
                                  controller.isSearch = true;
                                  if (val.length < 1) {
                                    controller.isSearch = false;
                                  } else {
                                    controller.onSearchTextChanged(val);
                                  }
                                  controller.update();
                                },
                                decoration: InputDecoration(
                                  hintText: Strings.searchPost,
                                  hintStyle:
                                      LightStyles.baseTextTheme.headline3,
                                  // TextStyle(
                                  //     fontSize: 14,
                                  //     color: Colors.black,
                                  //     fontWeight: FontWeight.w400,
                                  // ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.grey),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.grey),
                                  ),
                                  filled: true,
                                  contentPadding: EdgeInsets.only(
                                      top: 10, bottom: 10, left: 16, right: 16),
                                  fillColor: Colors.grey[250],
                                ),
                              ),
                            )
                          : SizedBox(),

                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: kIsWeb ? 20 : 0, vertical: 10),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            // mainAxisAlignment:kIsWeb? MainAxisAlignment.spaceBetween:MainAxisAlignment.spaceAround,
                            children: [
                              GuestUserTabButton(
                                title: Strings.hotTrends,
                                onTap: () {
                                  controller.trendingTab();
                                },
                                isSelected: controller.isTrendingTab,
                              ),

                              GuestUserTabButton(
                                title: Strings.newsSocial,
                                onTap: () {
                                  controller.newsAndSocialTabs();
                                },
                                isSelected: controller.isTopicTab,
                              ),

                              GuestUserTabButton(
                                title: Strings.filmTV,
                                onTap: () {
                                  controller.filmsTvTabs();
                                },
                                isSelected: controller.isSuggestedTab,
                              ),

                              GuestUserTabButton(
                                title: Strings.music,
                                onTap: () {
                                  controller.musicTab();
                                },
                                isSelected: controller.isMusicTab,
                              ),

                              GuestUserTabButton(
                                title: Strings.travelAdventure,
                                onTap: () {
                                  controller.travelTab();
                                },
                                isSelected: controller.isTravelTab,
                              ),

                              // FittedBox(
                              //   child: Text(
                              //       Strings.hotTrends,
                              //       // style: Theme.of(context)
                              //       //     .textTheme
                              //       //     .headline6
                              //       //     .copyWith(
                              //       //   fontSize: 16,
                              //       //   fontWeight: FontWeight.w700,
                              //       //   color: Colors.black,
                              //       // ),
                              //
                              //     style: Styles.baseTextTheme.headline2.copyWith(
                              //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                              //       fontWeight: FontWeight.bold,
                              //
                              //
                              //       )
                              //     // Theme.of(context).brightness ==
                              //     //         Brightness.dark
                              //     //     ? TextStyle(
                              //     //         color: Colors.white,
                              //     //         fontSize: 16,
                              //     //         fontWeight: FontWeight.w700,
                              //     //       )
                              //     //     : TextStyle(
                              //     //         color: Colors.black,
                              //     //         fontSize: 16,
                              //     //         fontWeight: FontWeight.w700,
                              //     //       ),
                              //   ),
                              // ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        height: 0.1,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.grey.withOpacity(0.2),
                      ),

                      widget.newsfeedController.isTrendingLoading == true &&
                              controller.isTrendingTab == true
                          ? SizedBox(
                              height: 280,
                              child: Center(
                                child: CircularProgressIndicator(
                                  color: MyColors.BlueColor,
                                ),
                              ),
                            )
                          : widget.newsfeedController.trendingList == null &&
                                      controller.isTrendingTab == true ||
                          widget.newsfeedController.trendingList != null &&
                          widget.newsfeedController.trendingList.trends != null &&
                                  widget.newsfeedController.trendingList.trends
                                          .isEmpty &&
                                      controller.isTrendingTab == true
                              ? Center(
                                  child: Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Text(
                                    Strings.noTrending,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 14,
                                    ),
                                  ),
                                ))
                              : controller.isTrendingTab == true
                                  ? Container(
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.2,
                                      child: ListView.builder(
                                          shrinkWrap: true,
                                          itemCount: widget
                                                      .newsfeedController
                                                      .trendingList
                                                      .trends
                                                      .length <
                                                  5
                                              ? widget.newsfeedController
                                                  .trendingList.trends.length
                                              : 5,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              hoverColor:
                                                  Colors.grey.withOpacity(0.3),
                                              onTap: /*() async {
                                                if (kIsWeb) {
                                                  debugPrint('tapped trending');
                                                  controller.newsfeedController
                                                      .isProfileScreen = false;
                                                  controller.newsfeedController
                                                      .isBrowseScreen = false;
                                                  controller.newsfeedController
                                                      .isFilterScreen = true;
                                                  controller.newsfeedController
                                                          .searchText.text =
                                                      widget
                                                          .newsfeedController
                                                          .trendingList
                                                          .trends[index]
                                                          .title;
                                                  controller.newsfeedController
                                                      .isProfileScreen = false;
                                                  controller.newsfeedController
                                                      .isSettingsScreen = false;
                                                  controller.newsfeedController
                                                          .isSavedPostScreen =
                                                      false;
                                                  controller.newsfeedController
                                                      .isNewsFeedScreen = false;
                                                  controller.newsfeedController
                                                          .isOtherUserProfileScreen =
                                                      false;
                                                  controller.newsfeedController
                                                      .isChatScreen = false;
                                                  controller.newsfeedController
                                                      .isChatScreenWeb = false;
                                                  controller.isBrowseScreen =
                                                      false;
                                                  controller.newsfeedController
                                                          .isClickWhoToFollow =
                                                      false;
                                                  controller.newsfeedController
                                                      .isFollwerScreen = false;
                                                  controller.newsfeedController
                                                      .isPostDetails = false;
                                                  controller.newsfeedController
                                                      .postUserId = 0;
                                                  controller.newsfeedController
                                                      .isSearch = false;
                                                  controller.newsfeedController
                                                      .seletedTab = "top";

                                                  controller.newsfeedController
                                                      .wait = true;
                                                  controller.newsfeedController
                                                          .tagText =
                                                      widget
                                                          .newsfeedController
                                                          .trendingList
                                                          .trends[index]
                                                          .title;
                                                  // controller.newsfeedController.update();
                                                  SingleTone.instance.searchId =
                                                      0.toString();
                                                  SingleTone
                                                          .instance.searchType =
                                                      controller
                                                          .searchSelected.type;
                                                  SingleTone
                                                          .instance.searchTag =
                                                      widget
                                                          .newsfeedController
                                                          .trendingList
                                                          .trends[index]
                                                          .title;
                                                  SingleTone
                                                          .instance.searchTab =
                                                      widget.newsfeedController
                                                          .seletedTab;
                                                  Get.offNamed(FluroRouters
                                                          .mainScreen +
                                                      "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=true");

                                                  *//*      await controller.newsfeedController.onSearchTextChanged(widget.newsfeedController.trendingList.trends[index].title,  isSearchBar: false);
                                    print("kisweb");


                                    controller.newsfeedController.searchSelected = controller.newsfeedController.searchResult[0];
                                    controller.newsfeedController.searchSelected.id = 0;
                                    controller.newsfeedController.searchSelected.type = "tag";

                                    await controller.newsfeedController.filterUsers(
                                      id: 0.toString(),
                                      type: "tag",
                                      tag: widget.newsfeedController.trendingList.trends[index].title,
                                      // id: id,
                                      // type: controller.searchResult[0].type,
                                    );*//*
                                                  controller.newsfeedController
                                                      .isSearch = false;
                                                  controller.newsfeedController
                                                      .searchResult = [];

                                                  controller.newsfeedController.update();
                                                  controller.update();
                                                } else {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (BuildContext context) => FilteredScreen(
                                                        newsfeedController: Get.find<NewsfeedController>(),
                                                      ),
                                                    ),
                                                  );

                                                  controller.newsfeedController.searchText.text = widget.newsfeedController.trendingList.trends[index].title;
                                                  controller.newsfeedController.postUserId = 0;
                                                  controller.newsfeedController.isSearch = false;
                                                  controller.newsfeedController.seletedTab = "top";

                                                  controller.newsfeedController.wait = true;
                                                  controller.newsfeedController.tagText = widget.newsfeedController.trendingList.trends[index].title;
                                                  SingleTone.instance.searchId=0.toString();
                                                  SingleTone.instance.searchType=controller.searchSelected.type;
                                                  SingleTone.instance.searchTag=widget.newsfeedController.trendingList.trends[index].title;
                                                  SingleTone.instance.searchTab=widget.newsfeedController.seletedTab;
                                                  Get.offNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=true");

                                                  controller.newsfeedController.update();

                                    await controller.newsfeedController.onSearchTextChanged(widget.newsfeedController.trendingList.trends[index].title,  isSearchBar: false);


                                    print("kisweb");

                                    controller.newsfeedController.searchSelected = controller.newsfeedController.searchResult[0];
                                    controller.newsfeedController.searchSelected.id = 0;
                                    controller.newsfeedController.searchSelected.type = "tag";

                                    await controller.newsfeedController.filterUsers(
                                      id: 0.toString(),
                                      type: "tag",
                                      tag: widget.newsfeedController.trendingList.trends[index].title,
                                      // id: id,
                                      // type: controller.searchResult[0].type,
                                    );
                                    controller.newsfeedController.isSearch = false;
                                    controller.newsfeedController.searchResult = [];

                                    controller.newsfeedController.update();
                                    controller.update();
                                                }
                                              },*/
                                              (){
                                                if (kIsWeb) {
                                                  Get.toNamed(
                                                      FluroRouters.mainScreen +
                                                          "/tagWerfs/" +
                                                          widget.newsfeedController.trendingList.trends[index].title.toString());
                                                } else {
                                                  Get.to(HashTagWerfsScreen(
                                                    tag: widget.newsfeedController.trendingList.trends[index].title,
                                                    controller: widget.newsfeedController,
                                                  ));
                                                  //LoggingUtils.printValue("tag value", tag);
                                                }
                                              },
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        horizontal: 20,
                                                        vertical: 4),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        Text(
                                                          Strings.trendingIn + ' ${widget.newsfeedController.trendingList.trends[index].region}',
                                                          //  style: TextStyle(
                                                          //   fontSize: 12),
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline4
                                                              .copyWith(
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                        SizedBox(height: 2),
                                                        Text(
                                                            '${widget.newsfeedController.trendingList.trends[index].title}',
                                                            // style: Theme.of(context)
                                                            //   .textTheme
                                                            // .bodyText1,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline3
                                                                .copyWith(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            )),
                                                        Text(
                                                          '${widget.newsfeedController.trendingList.trends[index].trendingCount} ' +
                                                              Strings.werfs,
                                                          // style: TextStyle(
                                                          //   fontSize: 12),
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline4
                                                              .copyWith(
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    // Spacer(),
                                                    // InkWell(
                                                    //     onTap: () {},
                                                    //     child: Icon(
                                                    //       Icons.more_horiz,
                                                    //       color: Colors.grey,
                                                    //       size: 20,
                                                    //     )),
                                                  ),
                                                  Container(
                                                    height: 0.1,
                                                    width:
                                                        MediaQuery.of(context)
                                                            .size
                                                            .width,
                                                    color: Colors.grey
                                                        .withOpacity(0.2),
                                                  ),
                                                ],
                                              ),
                                            );
                                          }),
                                    )
                                  : SizedBox(), //:SizedBox(),

                      Container(
                        height: 0.1,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.grey.withOpacity(0.3),
                      ),
                      SizedBox(
                        height: 10,
                      ),

                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        child: controller.isTravelTab == true
                            ? Text(
                                Strings.travelAdventure,
                                // style: Theme.of(context).textTheme.headline6.copyWith(
                                //   fontSize: 16,
                                //   fontWeight: FontWeight.w700,
                                //   color: Colors.black,
                                // ),
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            : controller.isMusicTab == true
                                ? Text(
                                    Strings.music,
                                    // style: Theme.of(context).textTheme.headline6.copyWith(
                                    //   fontSize: 16,
                                    //   fontWeight: FontWeight.w700,
                                    //   color: Colors.black,
                                    // ),
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                : controller.isSuggestedTab == true
                                    ? Text(
                                        Strings.filmTV,
                                        // style: Theme.of(context).textTheme.headline6.copyWith(
                                        //   fontSize: 16,
                                        //   fontWeight: FontWeight.w700,
                                        //   color: Colors.black,
                                        // ),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      )
                                    : controller.isTopicTab == true
                                        ? Text(
                                            Strings.newsSocial,
                                            // style: Theme.of(context).textTheme.headline6.copyWith(
                                            //   fontSize: 16,
                                            //   fontWeight: FontWeight.w700,
                                            //   color: Colors.black,
                                            // ),
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          )
                                        : Text(
                                            Strings.popularUpdates,
                                            // style: Theme.of(context).textTheme.headline6.copyWith(
                                            //   fontSize: 16,
                                            //   fontWeight: FontWeight.w700,
                                            //   color: Colors.black,
                                            // ),
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                      ),

                      controller.isLoading == true
                          ? Center(
                              child: CircularProgressIndicator(
                              color: MyColors.BlueColor,
                            ))
                          : controller.isTrendingTab == true
                              ? controller?.browsePostList?.length == 0 ||
                                      // ignore: null_aware_in_logical_operator
                                      controller?.browsePostList?.isEmpty
                                  ? Center(
                                      child: Text(
                                      Strings.noPosts,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ))
                                  : Container(
                                      height:
                                          MediaQuery.of(context).size.height,
                                      child: PagedL(
                                        emptyStateWidget: Text(
                                          Strings.noPosts,
                                          style: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 4.00,
                                            right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(16.00),
                                          child: Center(
                                            child: CircularProgressIndicator(
                                              color: MyColors.BlueColor,
                                            ),
                                          ),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: controller.browsePostList,
                                        listSize: _checkPage(
                                            controller.browsePostList.length),
                                      ),
                                    )
                              : controller.topicList.length == 0 ||
                                      controller.topicList.isEmpty
                                  ? Center(
                                      child: Text(
                                      Strings.noPosts,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ))
                                  : Container(
                                      height:
                                          MediaQuery.of(context).size.height,
                                      child: PagedL(
                                        emptyStateWidget: Text(
                                          Strings.noPosts,
                                          style: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                        itemBuilder: _itemRows,
                                        padding: EdgeInsets.only(
                                            top: 16.00,
                                            left: 4.00,
                                            right: 4.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(16.00),
                                          child: Center(
                                            child: CircularProgressIndicator(
                                              color: MyColors.BlueColor,
                                            ),
                                          ),
                                        ),
                                        itemDataProvider: _fetchData2,
                                        list: controller.topicList,
                                        listSize: _checkPage2(
                                            controller.topicList.length),
                                      ),
                                    ),
                    ],
                  ),
                ),
                controller.isSearch == true
                    ? Padding(
                        padding: const EdgeInsets.only(top: 60.0),
                        child: Card(
                          child: Container(
                            height: MediaQuery.of(context).size.height / 2.5,
                            width: kIsWeb
                                ? MediaQuery.of(context).size.width / 2.5
                                : MediaQuery.of(context).size.width / 0.8,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.black
                                    : Colors.white,
                            padding: EdgeInsets.all(5),
                            child: controller.searchResult == null ||
                                    controller.searchResult.isEmpty
                                ? Align(
                                    alignment: Alignment.topCenter,
                                    child: Text(
                                      Strings.noSearchResult,
// style: TextStyle(fontSize: 18),
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.black
                                            : Colors.black,
                                        fontSize: 14,
                                      ),
                                    ))
                                : SingleChildScrollView(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Text(
                                          Strings.searchResult,
// style: TextStyle(fontSize: 18),
                                          style: Styles.baseTextTheme.headline2
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: List.generate(
                                              controller.searchResult.length,
                                              (index) {
                                            if (controller.searchResult[index]
                                                    .username !=
                                                null)
                                              return InkWell(
                                                splashColor: Colors.grey,
                                                onTap: () {
                                                  controller.newsfeedController
                                                      .isFilterScreen = true;
                                                  controller.newsfeedController
                                                      .isNewsFeedScreen = false;
                                                  controller.isSearch = false;
                                                  controller.newsfeedController
                                                      .seletedTab = "top";

                                                  controller.newsfeedController
                                                      .isBrowseScreen = false;
                                                  controller.newsfeedController
                                                          .isSavedPostScreen =
                                                      false;
                                                  controller.newsfeedController
                                                          .searchSelected =
                                                      controller
                                                          .searchResult[index];
                                                  controller.newsfeedController
                                                          .otherUserName =
                                                      controller
                                                          .searchResult[index]
                                                          .username;
                                                  controller.newsfeedController
                                                          .postUserId =
                                                      controller
                                                          .searchResult[index]
                                                          .id;
                                                  SingleTone.instance.searchId =
                                                      controller
                                                          .searchResult[index]
                                                          .id
                                                          .toString();
                                                  SingleTone
                                                          .instance.searchType =
                                                      controller
                                                          .searchResult[index]
                                                          .type;
                                                  SingleTone
                                                          .instance.searchTag =
                                                      controller
                                                          .searchResult[index]
                                                          .username;
                                                  SingleTone
                                                          .instance.searchTab =
                                                      widget.newsfeedController
                                                          .seletedTab;
                                                  Get.offNamed(FluroRouters
                                                          .mainScreen +
                                                      "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

/*

                                          controller.newsfeedController.filterUsers(id: controller.searchResult[index].id,
                                              type: controller.searchResult[index].type,
                                              tag: controller.searchResult[index].username
                                          );


                                          controller.update();
                                          controller.newsfeedController.update();*/
                                                },
                                                child: Container(
                                                  width: Get.width,
                                                  margin: EdgeInsets.only(
                                                      bottom: 5),
                                                  padding: EdgeInsets.all(8.0),
                                                  color: Colors.grey
                                                      .withOpacity(0.05),
                                                  child: Row(
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage: controller
                                                                    .searchResult[
                                                                        index]
                                                                    .profileImage !=
                                                                null
                                                            ? NetworkImage(
                                                                controller
                                                                    .searchResult[
                                                                        index]
                                                                    .profileImage)
                                                            : AssetImage(
                                                                "assets/images/person_placeholder.png"),
                                                        radius: 18,
                                                      ),
                                                      SizedBox(
                                                        width: 20,
                                                      ),
                                                      Row(
                                                        children: [
                                                          new Text(
                                                            "${controller.searchResult[index].username}",
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: 14,
                                                            ),
// Theme.of(context)
//             .brightness ==
//         Brightness
//             .dark
//     ? TextStyle(
//         color: Colors
//             .white,
//       )
//     : TextStyle(
//         color: Colors
//             .black,
//       ),
                                                          ),
                                                          controller
                                                                      .searchResult[
                                                                          index]
                                                                      .accountVerified ==
                                                                  "verified"
                                                              ? Row(
                                                                  children: [
                                                                    SizedBox(
                                                                      width: 5,
                                                                    ),
                                                                    BlueTick(
                                                                      height:
                                                                          15,
                                                                      width: 15,
                                                                      iconSize:
                                                                          10,
                                                                    ),
                                                                  ],
                                                                )
                                                              : SizedBox(),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              );
                                            return InkWell(
                                              splashColor: Colors.green,
                                              onTap: () {
                                                print("bbbbbb");
                                                controller.newsfeedController
                                                    .isFilterScreen = true;
                                                controller.newsfeedController
                                                    .isNewsFeedScreen = false;
                                                controller.isSearch = false;
                                                controller.newsfeedController
                                                    .seletedTab = "top";

                                                controller.newsfeedController
                                                    .isBrowseScreen = false;
                                                controller.newsfeedController
                                                    .isSavedPostScreen = false;
                                                controller.newsfeedController
                                                        .searchSelected =
                                                    controller
                                                        .searchResult[index];
                                                // controller.newsfeedController.otherUserName = controller.searchResult[index].username;
                                                // controller.newsfeedController.postUserId = controller.searchResult[index].id;

                                                SingleTone.instance.searchId =
                                                    controller
                                                        .searchResult[index].id
                                                        .toString();
                                                SingleTone.instance.searchType =
                                                    controller
                                                        .searchResult[index]
                                                        .type;
                                                SingleTone.instance.searchTag =
                                                    controller
                                                        .searchResult[index]
                                                        .username;
                                                SingleTone.instance.searchTab =
                                                    widget.newsfeedController
                                                        .seletedTab;
                                                Get.offNamed(FluroRouters
                                                        .mainScreen +
                                                    "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=true");

/*
                                        controller.newsfeedController.filterUsers(
                                          id: controller.searchResult[index].id,
                                          type: controller.searchResult[index].type,
                                            // tag: controller.searchResult[index].username,

                                        );


                                        controller.update();
                                        controller.newsfeedController.update();*/
                                              },
                                              child: Container(
                                                width: Get.width,
                                                margin:
                                                    EdgeInsets.only(bottom: 5),
                                                padding: EdgeInsets.all(8.0),
                                                color: Colors.grey
                                                    .withOpacity(0.05),
                                                child: Row(
                                                  children: [
                                                    CircleAvatar(
                                                      backgroundImage: controller
                                                                  .searchResult[
                                                                      index]
                                                                  .profileImage !=
                                                              null
                                                          ? NetworkImage(
                                                              controller
                                                                  .searchResult[
                                                                      index]
                                                                  .profileImage)
                                                          : AssetImage(
                                                              "assets/images/person_placeholder.png"),
                                                      radius: 18,
                                                    ),
                                                    SizedBox(
                                                      width: 20,
                                                    ),
                                                    new Text(
                                                      "${controller.searchResult[index].title}",
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline4
                                                          .copyWith(
                                                        fontSize: 12,
                                                      ),
// Theme.of(context)
//             .brightness ==
//         Brightness.dark
//     ? TextStyle(
//         color: Colors
//             .white,
//       )
//     : TextStyle(
//         color: Colors
//             .black,
//       ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            );
                                          }),
                                        ),
                                      ],
                                    ),
                                  ),
                          ),
                        ),
                      )
                    : SizedBox(),
              ],
            ),

            // SizedBox.shrink(),
          ));
    });
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = controller.browsePostList.indexWhere((element) {
      return element.postId == post.postId;
    });
    if (index != -1)
      return
          // controller.browsePostList[index].type!='post'?
          // ThreadPostCard(
          //   index: index,
          //   post: controller.browsePostList[index],
          //   scaffoldKey: _scaffoldKey,
          //   browseController : controller,
          //   controller: newsfeedController,
          // ):
          VisibilityDetector(
        key: Key('postCard-widget-key'),
        onVisibilityChanged: (visibilityInfo) {
          double visiblePercentage = visibilityInfo.visibleFraction * 100;
          // debugPrint(
          //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
          if (visiblePercentage > 20 &&
              post.authorId != controller.newsfeedController.userId) {
            controller..newsfeedController.emitImpressionsSocket(post.postId);
          }
        },
        child: PostCard(
          postList: controller.browsePostList,
          post: controller.browsePostList[index],
          scaffoldKey: _scaffoldKey,
          controller: widget.newsfeedController,
          browseController: controller,
          index: index,
          deletePostId: 3,
        ),
      );
    return SizedBox();
  }

  Widget _itemRows(BuildContext context, Post post) {
    int index = controller.topicList.indexWhere((element) {
      return element.postId == post.postId;
    });

    if (index != -1)
      return
          // controller.browsePostList[index].type!='post'?
          // ThreadPostCard(
          //   index: index,
          //   post: controller.browsePostList[index],
          //   scaffoldKey: _scaffoldKey,
          //   browseController : controller,
          //   controller: newsfeedController,
          // ):
          VisibilityDetector(
        key: Key('postCard-widget-key'),
        onVisibilityChanged: (visibilityInfo) {
          double visiblePercentage = visibilityInfo.visibleFraction * 100;
          // debugPrint(
          //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
          if (visiblePercentage > 20 &&
              post.authorId != controller.newsfeedController.userId) {
            controller..newsfeedController.emitImpressionsSocket(post.postId);
          }
        },
        child: PostCard(
          postList: controller.topicList,
          post: controller.topicList[index],
          scaffoldKey: _scaffoldKey,
          controller: widget.newsfeedController,
          browseController: controller,
          index: index,
          deletePostId: 3,
        ),
      );
    return SizedBox();
  }

  Future<List<Post>> _fetchData(int page) async {
    print("browse api paginations called");
    return await controller.getBrowsePostPaged(page: page);
  }

  Future<List<Post>> _fetchData2(int page) async {
    print("browse api paginations called");

    if (controller.isTopicTab == true) {
      return await controller.getTopicPostPaged(topicId: 2, page: page);
    } else if (controller.isSuggestedTab == true) {
      return await controller.getTopicPostPaged(topicId: 3, page: page);
    } else if (controller.isMusicTab == true) {
      return await controller.getTopicPostPaged(topicId: 6, page: page);
    } else if (controller.isTravelTab == true) {
      return await controller.getTopicPostPaged(topicId: 5, page: page);
    }
  }

  // ignore: missing_return

  int _checkPage2(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }
}
