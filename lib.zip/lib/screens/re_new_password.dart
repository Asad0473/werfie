import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:werfieapp/components/custom_dialog.dart';
import 'package:werfieapp/components/input_password_field.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_password_field.dart';

import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../widgets/sign_in_sign_up_widget/custom_image_view.dart';

// ignore: must_be_immutable
class NewPasswordScreen extends StatefulWidget {
  String code;

  NewPasswordScreen({Key key, this.code}) : super(key: key);

  @override
  State<NewPasswordScreen> createState() => _NewPasswordScreenState();
}

class _NewPasswordScreenState extends State<NewPasswordScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  double _strength = 0;
  String password;
  String confrmPassword;

  TextEditingController newPasswordTxt = TextEditingController();

  TextEditingController confirmPassword = TextEditingController();

  RegExp regExpMedium = RegExp(r'^(?=.*[A-Z])(?=.*\d).+$');
  RegExp regExpStrong = RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=]).+$');
  RegExp emailregExp =
  RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');

  void _checkPassword(String value) {

    password = value.trim();
    if (password.isEmpty) {
      setState(() {
        _strength = 0;
      });
    } else if (password.length > 7 &&
        regExpMedium.hasMatch(password) &&
        !regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 0.5;
      });
    } else if (password.length > 7 && regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 1;
      });
    } else {
      setState(() {
        _strength = 0.3;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: !kIsWeb
          ? AppBar(
              iconTheme: IconThemeData(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black, //change your color here
              ),
              title: Text(
                Strings.ChangePasswordSettings,
                // style: TextStyle(color: Colors.black),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.bold,
                ),
              ),
              centerTitle: true,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
            )
          : PreferredSize(preferredSize: const Size(0, 0), child: Container()),
      // resizeToAvoidBottomInset: false,
      // backgroundColor: Colors/.white,
      body: Responsive(
        mobile: !kIsWeb
            ? SingleChildScrollView(child: newPassword(context))
            : SingleChildScrollView(
                child: SizedBox(
                  width: 400,
                  child: newPassword(context),
                ),
              ),
        tablet: Center(
          child: SizedBox(
            width: 400,
            child: newPassword(context),
          ),
        ),
        desktop: SizedBox(
          height: MediaQuery.of(context).size.height * 1,
          child: Padding(
            padding: MediaQuery.of(context).size.width < 1400
                ? const EdgeInsets.only(left: 20)
                : EdgeInsets.only(
                    right: MediaQuery.of(context).size.width * 0.2,
                    left: MediaQuery.of(context).size.width * 0.1,
                  ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                MediaQuery.of(context).size.width < 1040
                    ? const SizedBox()
                    : SizedBox(
                        width: 450,
                        height: 500,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 200,
                              child: CustomImageShow(
                                imagePath: AppImages.logo,
                              ),
                            ),
                            Text(
                              Strings.werfieTagline,
                              textAlign: TextAlign.center,
                              style: Styles.baseTextTheme.headline4.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontFamily: 'Poppins',
                                fontSize: kIsWeb ? 14 : 12,
                              ),
                            )
                          ],
                        ),
                      ),
                SizedBox(
                  width: 450,
                  height: 500,
                  child: Column(
                    children: [
                      Center(
                        child: SizedBox(
                          width: 450,
                          height: 500,
                          child: Card(
                            color: Colors.grey.shade100,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 4,
                              child: newPassword(context)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container newPassword(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: kIsWeb ? 0 : 50,
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Align(
              alignment: Alignment.center,
              child: Text(
                Strings.enterYourNewPasswordHint,
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            if (kIsWeb)

              const SizedBox(
                height: 16,
              ),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  CustomPasswordField(
                    hintText: Strings.enterNewPassword,
                    textInputAction: TextInputAction.done,
                    textInputType:
                    TextInputType.visiblePassword,
                     contentPadding: const EdgeInsets.symmetric(horizontal: 15,vertical: 20),
                    obscureText: true,
                    onChanged: (value){
                      password=value;
                      // newPasswordTxt.text=value;
                      //_checkPassword(value);
                    },
                    controller: newPasswordTxt,
                    validator: (value) {
                      final text = value;
                      if (text.isEmpty) {
                        return Strings.passwordCannotBeEmpty;
                      } else if (text.length < 8) {
                        return Strings.passwordShouldBeMin8Char;
                      } /*else if (emailregExp.hasMatch(password)) {
                        return Strings.cantChooseEmailAsApass;
                      } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
                        return Strings.passMustContainUpperCaseAndLeeter;
                      } */else if (confrmPassword!=
                          password) {
                        return Strings.bothPasswordAndConfirmPassShouldMatch;
                      } else {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                 /* Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: SizedBox(
                      // width: 160,
                      child: ClipRRect(
                        borderRadius: const BorderRadius.all(Radius.circular(10)),
                        child: LinearProgressIndicator(
                          value: _strength,
                          backgroundColor: Colors.grey,
                          color: _strength == 0.3
                              ? Colors.red
                              : _strength == 0.5
                              ? Colors.yellow
                              : _strength == 1
                              ? Colors.green
                              : Colors.red,
                          minHeight: 5,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),*/
                  CustomPasswordField(
                    textInputAction: TextInputAction.done,
                    textInputType:
                    TextInputType.visiblePassword,
                     contentPadding: const EdgeInsets.symmetric(horizontal: 15,vertical: 20),
                    obscureText: true,
                    hintText: Strings.reEnterPassword,
                    // onPasswordEntered: (value) {
                    //   value = confirmPassword.text;
                    // },
                    onChanged: (val){
                      confrmPassword=val;
                    },
                    controller: confirmPassword,
                    validator: (value) {
                      final text = value;
                      if (text.isEmpty) {
                        return Strings.passwordCannotBeEmpty;
                      } else if (text.length < 8) {
                        return Strings.passwordShouldBeMin8Char;
                      } /*else if (emailregExp.hasMatch(password)) {
                        return Strings.cantChooseEmailAsApass;
                      } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
                        return Strings.passMustContainUpperCaseAndLeeter;
                      }*/ else if (confrmPassword !=
                          password) {
                        return Strings.bothPasswordAndConfirmPassShouldMatch;
                      } else {
                        return null;
                      }
                    },
                  ),
                  const Padding(
                    padding: EdgeInsets.only(left: 12.0, top: 4.0),
                    child: Text(
                      '(Should contain at least 8 characters)',
                      maxLines: 2,
                      style: TextStyle(fontSize: 12, color: Colors.grey,fontFamily: 'Poppins',),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            Row(
              children: [
                Expanded(
                  child:
                  CustomElevatedButton(
                    onPressed: resetFunction,
                    text:  Strings.resetPassword,
                    margin: const EdgeInsets.only(right: 1),
                  ),

                ),
              ],
            )
          ],
        ),
      ),
    );
  }
  resetFunction()async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      DialogBuilder(context).showLoadingIndicator();
      LoginController signupController = LoginController();

      String email =
      await signupController.storage.read('CurrentEmail');
      print("code  new code ${email}");

      int responseCode = await signupController
          .renewPassword(queryParameters: {
        "email": email,
        "password": newPasswordTxt.text,
        "password_confirmation": confirmPassword.text
      }, token: {
        "Authorization": "Bearer ${Url.webAPIKey}",
        "X-Requested-With": "XMLHttpRequest"
      });

      if (responseCode == 200) {
        DialogBuilder(context).hideOpenDialog();
        showDialog(
            barrierDismissible: false,
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                        Radius.circular(10.0))),
                insetPadding: EdgeInsets.symmetric(
                    horizontal: 0, vertical: 0),
                titlePadding: EdgeInsets.zero,
                contentPadding: EdgeInsets.zero,
                content: Container(
                  height: 220,
                  width: 80,
                  padding:
                  EdgeInsets.symmetric(horizontal: 10.0),
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      Spacer(),
                      Center(
                        child: Text(
                          Strings
                              .yourPasswordIsResetSuccessfully,
                          textAlign: TextAlign.center,
                          style: Styles
                              .baseTextTheme.headline3
                              .copyWith(
                            color: Theme.of(context)
                                .brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: 18,
                            fontFamily: 'Poppins',
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      ElevatedButton(
                        onPressed: () {
                          if (!kIsWeb) {
                            newPasswordTxt.clear();
                            confirmPassword.clear();
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (BuildContext context) =>
                                    LoginScreen(),
                              ),
                            );
                          } else {
                            //newPasswordTxt.clear();
                            //confirmPassword.clear();

                            //Navigator.pop(context);
                            //Navigator.pop(context);
                            // Get.to(LoginScreen());
                            Get.toNamed(
                                FluroRouters.loginScreen);
                            // context.push(AppRoute.loginScreen);

                            // Routemaster.of(context)
                            //     .pop();
                            // Routemaster.of(context)
                            //     .pop();
                          }

                          // Navigator.pop(context);
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (BuildContext context) =>
                          //         LoginScreen(),
                          //   ),
                          // );
                        },
                        child: Text(
                          Strings.returnToLogin,
                          style: Theme.of(context)
                              .brightness ==
                              Brightness.dark
                              ? TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w700)
                              : TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontFamily: 'Poppins',
                              fontWeight:
                              FontWeight.w700),
                        ),
                      ),
                      Spacer()
                    ],
                  ),
                ),
              );
            });
      } else if (responseCode == 400) {
        DialogBuilder(context).hideOpenDialog();
        showDialog(
            barrierDismissible: false,
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(
                        Radius.circular(10.0))),
                insetPadding: EdgeInsets.symmetric(
                    horizontal: 0, vertical: 0),
                contentPadding: EdgeInsets.zero,
                content: Container(
                  height: 220,
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 10,
                  ),
                  child: Column(
                    mainAxisAlignment:
                    MainAxisAlignment.spaceAround,
                    children: [
                      Text(Strings

                          .youHaveEnteredAnInvalidCode),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          Strings.goBack,
                        ),
                      )
                    ],
                  ),
                ),
              );
            });
      } else {
        DialogBuilder(context).hideOpenDialog();
      }
    }
  }
}
