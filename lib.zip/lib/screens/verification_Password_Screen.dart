import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/settings_controller.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class verificationPasswordScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  final settingController = Get.find<SettingController>();

  final String email;

  verificationPasswordScreen({this.email});

  TextEditingController verification = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return kIsWeb
            ? Container(
                height: 500,
                width: 450,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.otpSentMsg,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),

                        SizedBox(height: 20),
                        Form(
                          key: formKey,
                          child: InputField(
                            // focusNode: controller.focus1,
                            formatter: [
                              LengthLimitingTextInputFormatter(6),
                              FilteringTextInputFormatter.digitsOnly,
                            ],

                            TextInputAction: TextInputAction.next,
                            onChanged: (_) {},
                            hint: Strings.verificationCode,

                            onValueEntered: (_) {},
                            // onValueEntered: (value) {
                            //   print('value will be' + value);
                            //   value = email.text;
                            // },
                            controller: verification,
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(context,
                                  errorText:
                                      Strings.verificationCodeCannotBeEmpty),
                            ]),
                            textInputType: TextInputType.emailAddress,
                            // fieldIcon: Icons.email,
                          ),
                        ),
                        PopupMenuButton(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                            position: PopupMenuPosition.under,
                            padding: EdgeInsets.zero,
                            child: Text(
                              Strings.DidNoTReceiveCode,
                              style: Styles.baseTextTheme.bodyText1.copyWith(
                                color: Colors.blue,
                                fontSize: 14,
                              ),
                            ),

                            // color: Theme.of(context).brightness == Brightness.dark?Colors.black: Colors.white,
                            // Callback that sets the selected popup menu item.
                            onSelected: (value) async {
                              if (value == 1) {
                                int isSuccess = await settingController
                                    .sendVerification(email);
                                if (isSuccess == 1) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'We sent you a code ');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'error occur while sending you code');
                                }
                              }
                            },
                            itemBuilder: (BuildContext context) => [
                                  PopupMenuItem(
                                    padding: EdgeInsets.all(0),
                                    value: 1,
                                    child: Container(
                                      height: 80,
                                      width: 150,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Strings.DidNoTReceiveCode,
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Text(
                                              Strings.resend,
                                              style: Styles
                                                  .baseTextTheme.headline1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),

                        Spacer(),

                        Align(
                          alignment: Alignment.bottomRight,
                          child: RoundedButton(
                            Strings.confirm,
                            () async {
                              if (formKey.currentState.validate()) {
                                Navigator.pop(context);
                                // var code = int.parse(verification.text);
                                int isSuccess =
                                    await settingController.Verification(
                                        email);

                                if (isSuccess == 1) {
                                  settingController.newPasswordTxt.clear();
                                  settingController.currentPassword.clear();
                                  settingController.confirmPassword.clear();
                                  settingController.update();
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'Code is valid and Password updated successfully');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'Code is not valid');
                                }
                              }
                            },
                            horizontalPadding: 30.0,
                            roundedButtonColor: controller.displayColor,
                          ),
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              )
            : Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          settingController.newPasswordTxt.clear();
                          settingController.currentPassword.clear();
                          settingController.confirmPassword.clear();
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      Spacer(),
                      Image.asset(
                        "assets/drawer_icons/WerfieLogoWIcon.png",
                        alignment: Alignment.centerLeft,
                        width: 60,
                        height: 60,
                      ),
                      Spacer(),
                    ],
                  ),
                  centerTitle: true,
                  elevation: 0.0,
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                ),
                body: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.otpSentMsg,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),

                        SizedBox(height: 20),
                        Form(
                          key: formKey,
                          child: InputField(
                            // focusNode: controller.focus1,
                            formatter: [
                              LengthLimitingTextInputFormatter(6),
                              FilteringTextInputFormatter.digitsOnly,
                            ],

                            TextInputAction: TextInputAction.next,
                            onChanged: (_) {},
                            hint: Strings.verificationCode,

                            onValueEntered: (_) {},
                            // onValueEntered: (value) {
                            //   print('value will be' + value);
                            //   value = email.text;
                            // },
                            controller: verification,
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(context,
                                  errorText:
                                      Strings.verificationCodeCannotBeEmpty),
                            ]),
                            textInputType: TextInputType.emailAddress,
                            // fieldIcon: Icons.email,
                          ),
                        ),
                        PopupMenuButton(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                            position: PopupMenuPosition.under,
                            padding: EdgeInsets.zero,
                            child: Text(
                              Strings.DidNoTReceiveCode,
                              style: Styles.baseTextTheme.bodyText1.copyWith(
                                color: Colors.blue,
                                fontSize: 14,
                              ),
                            ),

                            // color: Theme.of(context).brightness == Brightness.dark?Colors.black: Colors.white,
                            // Callback that sets the selected popup menu item.
                            onSelected: (value) async {
                              if (value == 1) {
                                int isSuccess = await settingController
                                    .sendVerification(email);
                                if (isSuccess == 1) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'We sent you a code ');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'error occur while sending you code');
                                }
                              }
                            },
                            itemBuilder: (BuildContext context) => [
                                  PopupMenuItem(
                                    padding: EdgeInsets.all(0),
                                    value: 1,
                                    child: Container(
                                      height: 80,
                                      width: 150,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Strings.DidNoTReceiveCode,
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Text(
                                              Strings.resend,
                                              style: Styles
                                                  .baseTextTheme.headline1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),

                        SizedBox(height: 20),

                        Align(
                          alignment: Alignment.bottomRight,
                          child: RoundedButton(
                            Strings.confirm,
                            () async {
                              if (formKey.currentState.validate()) {
                                Navigator.pop(context);
                                // var code = int.parse(verification.text);
                                int isSuccess =
                                    await settingController.Verification(
                                        email);

                                if (isSuccess == 1) {
                                  settingController.newPasswordTxt.clear();
                                  settingController.currentPassword.clear();
                                  settingController.confirmPassword.clear();
                                  settingController.update();
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'Code is valid and Password updated successfully');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'Code is not valid');
                                }
                              }
                            },
                            horizontalPadding: 30.0,
                            roundedButtonColor: controller.displayColor,
                          ),
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              );
      },
    );
  }
}
