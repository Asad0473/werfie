import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:werfieapp/components/custom_dialog.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_text_form_field.dart';

import '../network/apis/signup/send_verification_email.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import '../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../widgets/sign_in_sign_up_widget/custom_image_view.dart';
import 'Forget_password_verification_screen.dart';

// ignore: must_be_immutable
class ResetPasswordScreen extends StatefulWidget {
  static final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  TextEditingController email = TextEditingController();

  TextEditingController _emailAndPhoneController = TextEditingController();

  bool _isEmailFieldTouched = false;

  String emailErrorMessage = 'Please enter a valid email';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.grey.shade100,
      appBar: !kIsWeb
          ? AppBar(
              iconTheme: IconThemeData(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black, //change your color here
              ),
              title: Text(
                Strings.resetPassword,
                // style: TextStyle(color: Colors.black),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.bold,
                ),
              ),
              centerTitle: true,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
            )
          : PreferredSize(preferredSize: const Size(0, 0), child: Container()),
      body: Responsive(
        mobile: !kIsWeb
            ? resetPassword(context)
            : SizedBox(
                width: 500,
                child: resetPassword(context),
              ),
        tablet: Center(
          child: SizedBox(
            width: 500,
            child: resetPassword(context),
          ),
        ),
        desktop: Padding(
          padding: MediaQuery.of(context).size.width < 1400
              ? const EdgeInsets.only(left: 20)
              : EdgeInsets.only(
                  right: MediaQuery.of(context).size.width * 0.3,
                  left: MediaQuery.of(context).size.width * 0.1,
                ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              MediaQuery.of(context).size.width < 1040
                  ? const SizedBox()
                  : SizedBox(
                      width: 420,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 200,
                            child: CustomImageShow(
                               imagePath: AppImages.logo,
                            ),
                          ),
                          Text(
                            Strings.werfieTagline,
                            textAlign: TextAlign.center,
                            style: Styles.baseTextTheme.headline4.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontFamily: 'Poppins',
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                          )
                        ],
                      ),
                    ),
              Center(
                child: SizedBox(
                  width: 450,
                  height: 500,
                  child: Card(
                    color: Colors.grey.shade100,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    elevation: 4,
                    child: Column(
                      children: [
                        const SizedBox(height: 50,),

                        resetPassword(context),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Container resetPassword(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
      ),
      child: SingleChildScrollView(
        child: Column(
          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const SizedBox(
              height: 30,
            ),
            !kIsWeb
                ? SizedBox(
                    child: Image.asset(
                      AppImages.logo,
                    ),
                  )
                : const SizedBox(),
            kIsWeb
                ? Align(
                    alignment: Alignment.center,
                    child: Text(
                      Strings.resetYourPassword,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        fontFamily: 'Poppins',
                      ),
                      // style: Theme.of(context).textTheme.headline4.copyWith(
                      //       fontWeight: FontWeight.normal,
                      //     ),
                    ),
                  )
                : const SizedBox(),
            const SizedBox(
              height: 20,
            ),
            Align(
              alignment: Alignment.center,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Text(
                  Strings
                      .lostYourPasswordPleaseEnterYourUsernameOrEmailAddressYouWillReceiveALinkToCreateANewPasswordViaEmail,
                  textAlign: TextAlign.center,
                  // style: Theme.of(context).textTheme.bodyText2,
                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 14 : 12,
                    fontFamily: 'Poppins',
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),

            Form(
              key: ResetPasswordScreen._formKey,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child:  _buildEmailField(),
              ),
            ),
            const SizedBox(height: 60),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: CustomElevatedButton(
                text: Strings.resetPassword,
                margin: const EdgeInsets.only(right: 1),
                onPressed: _resetPasswordFunction,
              ),
            ),
            const SizedBox(height: 30),
            kIsWeb? TextButton(onPressed: (){  Navigator.pop(context);}, child: Text('Back',
              style: Styles.baseTextTheme.headline4.copyWith(
                color:
              MyColors.werfieNewColor,

                fontSize: kIsWeb ? 14 : 12,
                fontFamily: 'Poppins',
              ),
            )):const SizedBox()
          ],
        ),
      ),
    );
  }

  Widget _buildEmailField() {return   CustomTextFormField(
    controller: _emailAndPhoneController,

     hintText: Strings.enterEmailPhone,
      errorText:
      _isEmailFieldTouched ? Strings.pleaseEnterAValidEmail : null,

contentPadding:   const EdgeInsets.symmetric(horizontal: 20,vertical: 17

),
    textInputAction: TextInputAction.done,
    autovalidateMode: AutovalidateMode.onUserInteraction,
    validator: (value){
      if(value.isNotEmpty && !_isEmailFieldTouched){
        return null;
      }else{
        return Strings.pleaseEnterAValidEmail;
      }
    },
    onChanged: (value) {
      value.isNotEmpty ? _isEmailFieldTouched = false :true;
      setState(() {

      });

    },
    onTap: () {
      _isEmailFieldTouched = true;
    },
  );}
  sendVerificationCode(BuildContext context) async {
    DialogBuilder(context).showLoadingIndicator();
    LoginController signupController = LoginController();
    signupController.storage.write(
        "CurrentEmail",
        /*kIsWeb ?  email.text
            :*/ _emailAndPhoneController.text
            );
    SendVerificationEmailAPIRes sendVerificationEmailAPIRes;

    sendVerificationEmailAPIRes = await SendVerificationEmailAPI()
        .sendVerificationEmail(/*kIsWeb ? email.text :*/_emailAndPhoneController.text,
            isResetPasswordFromPhone: _emailAndPhoneController.text.contains("@")
                ? false
                : true);
    if (sendVerificationEmailAPIRes.success) {
      DialogBuilder(context).hideOpenDialog();
      if (!kIsWeb) {
        Get.to(ForgetPasswordVerification());
      } else {
        Get.toNamed(FluroRouters.passwordVerificationScreen);
      }
    } else {
      DialogBuilder(context).hideOpenDialog();
      UtilsMethods.toastMessageShow(
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        message: sendVerificationEmailAPIRes.message,
      );
    }
  }
 Future<void> _resetPasswordFunction()async {
    if (ResetPasswordScreen._formKey.currentState.validate()) {
      ResetPasswordScreen._formKey.currentState.save();

      sendVerificationCode(context);
    }
  }
}
