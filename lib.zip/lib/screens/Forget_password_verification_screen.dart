import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:werfieapp/components/custom_dialog.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/screens/re_new_password.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../components/input_field.dart';
import '../network/apis/signup/send_verification_email.dart';
import '../network/apis/signup/verify_email_code_api.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/loading_dialog_builder.dart';
import '../widgets/sign_in_sign_up_widget/custom_image_view.dart';

// ignore: must_be_immutable
class ForgetPasswordVerification extends StatefulWidget {
  static final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final String email;


  const ForgetPasswordVerification({Key key, this.email}) : super(key: key);

  @override
  State<ForgetPasswordVerification> createState() => _ForgetPasswordVerificationState();
}

class _ForgetPasswordVerificationState extends State<ForgetPasswordVerification> {
  TextEditingController Code = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  String enteredOTP = '';

  @override
  void initState() {
    // TODO: implement initState
    listenToPasswordResetNotification();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: !kIsWeb
          ? AppBar(
              iconTheme: IconThemeData(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black, //change your color here
              ),
              title: Text(
                Strings.verificationCode,

                // style: TextStyle(color: Colors.black),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.bold,
                ),
              ),
              centerTitle: true,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
            )
          : PreferredSize(preferredSize: const Size(0, 0), child: Container()),
      // resizeToAvoidBottomInset: false,
      // backgroundColor: Colors/.white,
      body: Responsive(
        mobile: !kIsWeb
            ? SingleChildScrollView(child: newPassword(context))
            : SingleChildScrollView(
                child: SizedBox(
                  width: 400,
                  child: newPassword(context),
                ),
              ),
        tablet: Center(
          child: SizedBox(
            width: 400,
            child: newPassword(context),
          ),
        ),
        desktop: SizedBox(
          height: MediaQuery.of(context).size.height * 1,

          child: Padding(
            padding: MediaQuery.of(context).size.width < 1400
                ? const EdgeInsets.only(left: 20)
                : EdgeInsets.only(
                    right: MediaQuery.of(context).size.width * 0.2,
                    left: MediaQuery.of(context).size.width * 0.1,
                  ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                MediaQuery.of(context).size.width < 1040
                    ? const SizedBox()
                    : SizedBox(
                        width: 450,
                        height: 500,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 200,
                              child: CustomImageShow(
                                imagePath: AppImages.logo,
                              ),
                            ),
                            Text(
                              Strings.werfieTagline,
                              textAlign: TextAlign.center,
                              style: Styles.baseTextTheme.headline4.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontFamily: 'Poppins',
                                fontSize: kIsWeb ? 14 : 12,
                              ),
                            )
                          ],
                        ),
                      ),
                SizedBox(
                  width: 450,
                  height: 500,
                  child: Column(
                    children: [
                      Center(
                        child: SizedBox(
                          width: 450,
                          height: 500,
                          child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 4,
                              child: newPassword(context)),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Container newPassword(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: kIsWeb ? 10 : 50,
      ),
      child: Center(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            Strings.otpSentMsg,
            style: TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
              fontFamily: 'Poppins',
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
          ),
          const SizedBox(height: 20),

          PinCodeTextField(
            controller: _otpController,
            length: 6,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            obscureText: false,
            keyboardType: TextInputType.number,
            appContext: context,
            onChanged: (value) {
              enteredOTP = value;
            },
            onCompleted: (value) {
              enteredOTP = value;
              if (enteredOTP.isNotEmpty) {
                verifyCode();
              }
            },
            pinTheme: PinTheme(
              shape: PinCodeFieldShape.box,
              borderRadius: BorderRadius.circular(8),
              fieldHeight: 50,
              fieldWidth: 50,
              activeColor: MyColors.werfieBlue,
              activeFillColor: MyColors.werfieBlue.withOpacity(0.1),
              inactiveColor: Colors.grey,
            ),
            autoFocus: true,
            textInputAction: TextInputAction.done,
          ),

          PopupMenuButton(
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10.0),
                ),
              ),
              position: PopupMenuPosition.under,
              padding: EdgeInsets.zero,
              child: Text(
                Strings.DidNoTReceiveCode,
                style: Styles.baseTextTheme.bodyText1.copyWith(
                  color: Colors.blue,
                  fontSize: 14,
                  fontFamily: 'Poppins',
                ),
              ),

              // color: Theme.of(context).brightness == Brightness.dark?Colors.black: Colors.white,
              // Callback that sets the selected popup menu item.
              onSelected: (value) async {
                if (value == 1) {
                  sendVerificationCode(context);
                }
              },
              itemBuilder: (BuildContext context) => [
                    PopupMenuItem(
                      padding: const EdgeInsets.all(0),
                      value: 1,
                      child: SizedBox(
                        height: 120,
                        width: 150,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                Strings.DidNoTReceiveCode,
                                style: Styles.baseTextTheme.bodyText1.copyWith(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                ),
                              ),
                              const SizedBox(
                                height: 20,
                              ),
                              Text(
                                Strings.resend,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  fontSize: 14,
                                  fontFamily: 'Poppins',
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ]),
          Align(
            alignment: Alignment.bottomRight,
            child: RoundedButton(
              Strings.confirm,
              verifyCode,
              verticalPadding: 10.0,
              horizontalPadding: kIsWeb ? 30.0 : 15.0,
              // roundedButtonColor: controller.displayColor,
            ),
          ),

        ],
      )

          ),
    );
  }

  listenToPasswordResetNotification(){
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {

        // Access the inner body data
        Map<String, dynamic> innerBody = json.decode(message.data['body']);
        int otpCodeNotification = innerBody['body'];
        if(kIsWeb){
          Get.snackbar("Password Verification Code",otpCodeNotification.toString(),duration: Duration(seconds: 8),backgroundColor: Colors.white,colorText: Colors.black);
        }

        await Future.delayed(const Duration(seconds: 2));
        _otpController.value=TextEditingValue(text: otpCodeNotification.toString());
        if(mounted) {
          setState(() {

          });
        }

        //print("<======== RESET PASSWORD NOTIFICATION==========>");
      //print(message.data);

    });
  }



  verifyCode() async {
    if (_otpController.text.isNotEmpty && _otpController.text.length == 6) {
      DialogBuilder(context).showLoadingIndicator();
      try {
        LoginController signupController = LoginController();
        String email = signupController.storage
            .read("CurrentEmail");
        signupController.storage.write('verifyCode', _otpController.text);
        VerifyEmailCodeAPIRes verifyEmailCodeAPIRes =
        await VerifyEmailCodeAPI().verifyCode(
            _otpController.text, email);
        if (verifyEmailCodeAPIRes.success) {
          DialogBuilder(context).hideOpenDialog();
          if(kIsWeb){
            Get.toNamed(FluroRouters.newPasswordScreen);
          }else{

            Get.to(NewPasswordScreen(),);
          }
        } else {
          DialogBuilder(context).hideOpenDialog();
          UtilsMethods.toastMessageShow(
            MyColors.werfieBlue,
            MyColors.werfieBlue,
            MyColors.werfieBlue,
            message: verifyEmailCodeAPIRes.message,
          );
        }
      } catch (e) {
        DialogBuilder(context).hideOpenDialog();
      }
    }else{
      UtilsMethods.toastMessageShow(
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        message: "Please Enter the Valid OTP",
      );
    }
  }

  sendVerificationCode(BuildContext context) async {
    LoginController signupController = LoginController();
    String email = signupController.storage
        .read("CurrentEmail");
    SendVerificationEmailAPIRes sendVerificationEmailAPIRes;
    DialogBuilder(context).showLoadingIndicator();
    sendVerificationEmailAPIRes =
    await SendVerificationEmailAPI().sendVerificationEmail(
        email,isResetPasswordFromPhone: email.contains("@") ? false : true);
    if (sendVerificationEmailAPIRes.success) {
      DialogBuilder(context).hideOpenDialog();
      UtilsMethods.toastMessageShow(
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        message: sendVerificationEmailAPIRes.message,
      );
    } else {
      DialogBuilder(context).hideOpenDialog();
      UtilsMethods.toastMessageShow(
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        message: sendVerificationEmailAPIRes.message,
      );
    }

  }


/*verifyCode() async {
    {
      if (_otpController.text.isNotEmpty && _otpController.text.length == 6) {
        //ForgetPasswordVerification._formKey.currentState.save();

        customDialog(
          context,
        );

        LoginController signupController = LoginController();
        signupController.storage.write('verifyCode', Code.text);

        int responseCode =
            await signupController.verificationCode(queryParameters: {
          "code": Code.text,
        }, token: {
          "Authorization": "Bearer ${Url.webAPIKey}",
          "X-Requested-With": "XMLHttpRequest"
        });
        if (responseCode == 200) {
          Code.clear();
          Navigator.of(context).pop();
          if (!kIsWeb) {
            Get.to(
              // MaterialPageRoute(
              //   builder: (context) =>

              NewPasswordScreen(),
              // ),
            );
          } else {
            // Get.to(NewPasswordScreen());

            Get.toNamed(FluroRouters.newPasswordScreen);
            // context.push(AppRoute.newPasswordScreen);
          }

          // Navigator.push(
          //     context,
          //     MaterialPageRoute(
          //         builder: (context) => NewPasswordScreen()));
        } else if (responseCode == 400 || responseCode == 403) {
          Navigator.of(context).pop();
          showDialog(
              barrierDismissible: false,
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(
                      borderRadius:
                      BorderRadius.all(Radius.circular(10.0))),
                  insetPadding: EdgeInsets.symmetric(
                      horizontal: 0, vertical: 0),
                  contentPadding: EdgeInsets.zero,
                  content: Container(
                    height: 100,
                    padding: EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 10,
                    ),
                    child: Column(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceAround,
                      children: [
                        Text(
                          'Warning! Code is not valid',
                          style:
                          Styles.baseTextTheme.headline2.copyWith(
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text(
                            'Go back',
                          ),
                        )
                      ],
                    ),
                  ),
                );
              });
        } else {
          Navigator.pop(context);
        }

        /// remove this code after complete this task
        // if (responseCode == 200) {
        //
        //
        //
        //
        //
        //   showDialog(
        //       barrierDismissible: false,
        //       context: context,
        //       builder: (BuildContext context) {
        //         return AlertDialog(
        //           shape: RoundedRectangleBorder(
        //               borderRadius:
        //               BorderRadius.all(Radius.circular(10.0))),
        //           insetPadding: EdgeInsets.symmetric(
        //               horizontal: 0, vertical: 0),
        //           titlePadding:EdgeInsets.zero ,
        //           contentPadding: EdgeInsets.zero,
        //           content: Container(
        //             height: 220,
        //             width: 80,
        //             child: Column(
        //               children: [
        //                 Spacer(),
        //                 Text(
        //                   Strings.yourPasswordIsResetSuccessfully,
        //                   style: Styles.baseTextTheme.headline3.copyWith(
        //                     color: Theme.of(context).brightness == Brightness.dark
        //                         ? Colors.white
        //                         : Colors.black,
        //                     fontSize: 15,
        //                   ),
        //                 ),
        //                 SizedBox(
        //                   height: 20,
        //                 ),
        //                 ElevatedButton(
        //
        //                   onPressed: () {
        //                     if (!kIsWeb) {
        //                       Navigator.pop(context);
        //                       Navigator.pop(context);
        //                       Navigator.pop(context);
        //                       Navigator.pop(context);
        //                     } else {
        //                       Navigator.pop(context);
        //                       Navigator.pop(context);
        //                       // Get.to(LoginScreen());
        //                       Get.toNamed(FluroRouters.loginScreen);
        //                       // context.push(AppRoute.loginScreen);
        //
        //
        //                       // Routemaster.of(context)
        //                       //     .pop();
        //                       // Routemaster.of(context)
        //                       //     .pop();
        //                     }
        //
        //                     // Navigator.pop(context);
        //                     // Navigator.push(
        //                     //   context,
        //                     //   MaterialPageRoute(
        //                     //     builder: (BuildContext context) =>
        //                     //         LoginScreen(),
        //                     //   ),
        //                     // );
        //                   },
        //                   child: Text(
        //                     Strings.returnToLogin,
        //                     style: Theme.of(context).brightness ==
        //                         Brightness.dark
        //                         ? TextStyle(
        //                         color: Colors.white,
        //                         fontSize: 16,
        //                         fontWeight: FontWeight.w700)
        //                         : TextStyle(
        //                         color: Colors.white,
        //                         fontSize: 16,
        //                         fontWeight: FontWeight.w700),
        //                   ),
        //                 ),
        //                 Spacer()
        //               ],
        //             ),
        //           ),
        //         );
        //       });
        // }
        // else if (responseCode == 400) {
        //   Navigator.of(context).pop();
        //   showDialog(
        //       barrierDismissible: false,
        //       context: context,
        //       builder: (BuildContext context) {
        //         return AlertDialog(
        //           shape: RoundedRectangleBorder(
        //               borderRadius:
        //               BorderRadius.all(Radius.circular(10.0))),
        //           insetPadding: EdgeInsets.symmetric(
        //               horizontal: 0, vertical: 0),
        //           contentPadding: EdgeInsets.zero,
        //           content: Container(
        //             height: 220,
        //             padding: EdgeInsets.symmetric(
        //               horizontal: 20,
        //               vertical: 10,
        //             ),
        //             child: Column(
        //               mainAxisAlignment:
        //               MainAxisAlignment.spaceAround,
        //               children: [
        //                 Text(Strings.youHaveEnteredAnInvalidCode),
        //                 TextButton(
        //                   onPressed: () {
        //                     Navigator.pop(context);
        //                   },
        //                   child: Text(
        //                     Strings.goBack,
        //                   ),
        //                 )
        //               ],
        //             ),
        //           ),
        //         );
        //       });
        // }
        // else {
        //   Navigator.pop(context);
        // }
        /// remove this code after complete this task
      }else{
        UtilsMethods.toastMessageShow(
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          message: "Please Enter the Valid OTP",
        );
      }
    }
  }*/
}
