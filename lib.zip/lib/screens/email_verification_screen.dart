import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../utils/font.dart';

class EmailVerificationScreen extends StatefulWidget {
  @override
  _EmailVerificationScreenState createState() =>
      _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  final _formKey = GlobalKey<FormState>();
  String code;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: !kIsWeb
            ? resetPassword()
            : Container(
                width: 400,
                child: resetPassword(),
              ),
        tablet: Center(
          child: Container(
            width: 400,
            child: resetPassword(),
          ),
        ),
        desktop: Center(
          child: Container(
            width: 400,
            child: resetPassword(),
          ),
        ),
      ),
    );
  }

  Container resetPassword() {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 20,
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: SvgPicture.asset(
                AppImages.logo,
                // width: 180,
                // color: Color((0xFF47b867)),
              ),
              // Image.asset('assets/images/Logo_werfie.png'),
            ),
            SizedBox(
              height: 30,
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                Strings.pleaseEnterVerificationCodeToVerifyYourEmail,
                textAlign: TextAlign.center,
                style: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  //fontWeight: FontWeight.w400,
                  fontSize: kIsWeb ? 14 : 12,
                ),
                // style: Theme.of(context).textTheme.bodyText2,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Align(
              alignment: Alignment.center,
              child: Text(
                Strings.usernameOrEmail,
                // style: Theme.of(context).textTheme.bodyText1,
                style: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  //fontWeight: FontWeight.w400,
                  fontSize: kIsWeb ? 14 : 12,
                ),
              ),
            ),
            SizedBox(
              height: 16,
            ),
            Form(
              key: _formKey,
              child: TextFormField(
                onChanged: (value) {
                  code = value;
                },
                validator: (value) {
                  return UtilsMethods.validateEmail(value);
                },
                decoration: InputDecoration(
                  hintText: Strings.enterVerificationCode,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40),
                    borderSide: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                    ),
                  ),
                  fillColor: Colors.grey[250],
                  filled: true,
                ),
                style: Theme.of(context).brightness == Brightness.dark
                    ? TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w300)
                    : TextStyle(
                        color: Colors.black,
                        fontSize: 17,
                        fontWeight: FontWeight.w300),
                // style: TextStyle(
                //   fontSize: 17.0,
                //   fontFamily: 'sfui_text',
                //   fontWeight: FontWeight.w300,
                // ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            RoundedButton(
              Strings.confirmCode,
              () async {
                _formKey.currentState.validate();
                LoginController loginController = LoginController();
                await loginController.loginVerify(queryParameters: {
                  "verification_code": code
                }, token: {
                  "Authorization": "Bearer ${Url.webAPIKey}",
                  "X-Requested-With": "XMLHttpRequest"
                });

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => MainScreen(),
                  ),
                );
              },
              verticalPadding: 20,
            )
          ],
        ),
      ),
    );
  }
}
