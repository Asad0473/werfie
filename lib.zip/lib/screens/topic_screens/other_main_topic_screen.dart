import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/other_topic_controller.dart';
import 'package:werfieapp/screens/topic_screens/topic_trending_user_list.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';

import '../../models/post.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../widgets/post_card.dart';

class OtherMainTopicScreen extends StatelessWidget {
  final topicController = Get.find<OtherTopicController>();

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<OtherTopicController>(builder: (controller) {
      // print("controller.topicList  ${controller.topicList}");
      return Scaffold(
          body: controller.isLoading == true
              ? Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                )
              : NestedScrollView(
                  controller: controller.scrollController,
                  headerSliverBuilder: (context, innerBoxIsScrolled) {
                    return [
                      SliverAppBar(
                        elevation: 0,
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        automaticallyImplyLeading: false,
                        pinned: true,
                        expandedHeight: 230,
                        flexibleSpace: FlexibleSpaceBar(
                          titlePadding: EdgeInsets.zero,
                          collapseMode: CollapseMode.parallax,
                          title: controller.isShrink
                              ? Container(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.black
                                      : Colors.white,
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: 10,
                                      ),
                                      MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: kIsWeb
                                              ? () async {
                                                  // print("maintopic screen");

                                                  newsfeedController
                                                      .isTrendsScreen = false;
                                                  newsfeedController
                                                      .isNewsFeedScreen = false;
                                                  newsfeedController
                                                      .isBrowseScreen = false;
                                                  newsfeedController
                                                          .isNotificationScreen =
                                                      false;
                                                  newsfeedController
                                                      .isChatScreen = false;
                                                  newsfeedController
                                                          .isSavedPostScreen =
                                                      false;
                                                  newsfeedController
                                                      .isPostDetails = false;
                                                  newsfeedController
                                                      .isProfileScreen = false;
                                                  newsfeedController
                                                          .isOtherUserProfileScreen =
                                                      false;
                                                  newsfeedController
                                                      .isListScreen = false;
                                                  newsfeedController
                                                          .isMainTopicScreen =
                                                      false;
                                                  newsfeedController
                                                          .isOtherTopicTabScreen =
                                                      true;
                                                  newsfeedController.update();

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }

                                                  // Navigator.pop(context);
                                                }
                                              : () async {
                                                  Navigator.pop(context);

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }
                                                },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 25,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        controller
                                            .suggestedFollowingTopicForOtherProfile
                                            .data
                                            .topics[controller.index]
                                            .topic,
                                        // style: TextStyle(
                                        //     fontSize:kIsWeb? 20:14,
                                        //     fontWeight: FontWeight.w700,
                                        //     color: Colors.black),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Spacer(),
                                      Obx(() {
                                        return Wrap(
                                          children: [
                                            controller
                                                        .suggestedFollowingTopicForOtherProfile
                                                        .data
                                                        .topics[
                                                            controller.index]
                                                        .isFollowed
                                                        .value ==
                                                    0
                                                ? MouseRegion(
                                                    cursor: SystemMouseCursors
                                                        .click,
                                                    child: GestureDetector(
                                                      onTap: () async {
                                                        if (controller
                                                                .suggestedFollowingTopicForOtherProfile
                                                                .data
                                                                .topics[
                                                                    controller
                                                                        .index]
                                                                .isFollowed
                                                                .value ==
                                                            0) {
                                                          controller
                                                              .suggestedFollowingTopicForOtherProfile
                                                              .data
                                                              .topics[controller
                                                                  .index]
                                                              .isFollowed
                                                              .value = 1;
                                                          await controller.followUnFollowTopic(
                                                              topicId: controller
                                                                  .suggestedFollowingTopicForOtherProfile
                                                                  .data
                                                                  .topics[
                                                                      controller
                                                                          .index]
                                                                  .id);
                                                        }
                                                      },
                                                      child: Container(
                                                        // height: Get.height*0.1,
                                                        // width: Get.width*0.25,
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border.all(
                                                              width: 1,
                                                              color:
                                                                  Colors.grey),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      100),
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.black
                                                              : Colors.white,
                                                        ),
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 15,
                                                                  right: 15,
                                                                  top: 5,
                                                                  bottom: 5),
                                                          child: Text(
                                                            Strings.following,
                                                            textAlign: TextAlign
                                                                .center,
                                                            // style: TextStyle(
                                                            //     fontSize: kIsWeb?15:10,
                                                            //     fontWeight: FontWeight.bold,
                                                            //     color: Colors.black),
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 14,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                : controller
                                                            .suggestedFollowingTopicForOtherProfile
                                                            .data
                                                            .topics[controller
                                                                .index]
                                                            .isFollowed
                                                            .value ==
                                                        1
                                                    ? MouseRegion(
                                                        cursor:
                                                            SystemMouseCursors
                                                                .click,
                                                        child: GestureDetector(
                                                          onTap: () async {
                                                            if (controller
                                                                    .suggestedFollowingTopicForOtherProfile
                                                                    .data
                                                                    .topics[
                                                                        controller
                                                                            .index]
                                                                    .isFollowed
                                                                    .value ==
                                                                1) {
                                                              controller
                                                                  .suggestedFollowingTopicForOtherProfile
                                                                  .data
                                                                  .topics[
                                                                      controller
                                                                          .index]
                                                                  .isFollowed
                                                                  .value = 0;
                                                              await controller.followUnFollowTopic(
                                                                  topicId: controller
                                                                      .suggestedFollowingTopicForOtherProfile
                                                                      .data
                                                                      .topics[controller
                                                                          .index]
                                                                      .id);
                                                            }
                                                          },
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .black
                                                                    : Colors
                                                                        .white,
                                                                border: Border.all(
                                                                    width: 1,
                                                                    color: Colors
                                                                        .grey),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            100)),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      left: 15,
                                                                      right: 15,
                                                                      top: 5,
                                                                      bottom:
                                                                          5),
                                                              child: Text(
                                                                'Follow Topic',
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style:
                                                                    TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontSize:
                                                                      kIsWeb
                                                                          ? 14
                                                                          : 14,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    : SizedBox(),
                                          ],
                                        );
                                      })
                                    ],
                                  ),
                                )
                              : null,
                          background: SafeArea(
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 10, right: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Row(
                                    children: [
                                      MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: kIsWeb
                                              ? () async {
                                                  newsfeedController
                                                      .isTrendsScreen = false;
                                                  newsfeedController
                                                      .isNewsFeedScreen = false;
                                                  newsfeedController
                                                      .isBrowseScreen = false;
                                                  newsfeedController
                                                          .isNotificationScreen =
                                                      false;
                                                  newsfeedController
                                                      .isChatScreen = false;
                                                  newsfeedController
                                                          .isSavedPostScreen =
                                                      false;
                                                  newsfeedController
                                                      .isPostDetails = false;
                                                  newsfeedController
                                                      .isProfileScreen = false;
                                                  newsfeedController
                                                          .isOtherUserProfileScreen =
                                                      false;
                                                  newsfeedController
                                                      .isListScreen = false;
                                                  newsfeedController
                                                          .isMainTopicScreen =
                                                      false;
                                                  newsfeedController
                                                          .isOtherTopicTabScreen =
                                                      true;
                                                  newsfeedController.update();

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }
                                                }
                                              : () async {
                                                  Navigator.pop(context);

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }
                                                },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 25,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        'Topic',
                                        // style: TextStyle(
                                        //     fontSize: 20,
                                        //     fontWeight: FontWeight.w700,
                                        //     color: Colors.black),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  ListTile(
                                    mouseCursor: MouseCursor.defer,
                                    title: Text(
                                      controller
                                          .suggestedFollowingTopicForOtherProfile
                                          .data
                                          .topics[controller.index]
                                          .topic,
                                      // style: TextStyle(
                                      //     fontSize: kIsWeb?30:20,
                                      //     fontWeight: FontWeight.w900,
                                      //     color: Colors.black),
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: kIsWeb ? 20 : 18,
                                      ),
                                    ),
                                    // subtitle: Text(
                                    //   'All about sports',
                                    //   style: TextStyle(fontSize: 15, color: Colors.black),
                                    // ),
                                  ),
                                  SizedBox(
                                    height: kIsWeb ? 20 : 10,
                                  ),
                                  MouseRegion(
                                    cursor: SystemMouseCursors.click,
                                    child: InkWell(
                                      onTap: kIsWeb
                                          ? () {
                                              // print("profile screen");
                                              newsfeedController
                                                  .isWhoToFollowScreen = false;
                                              newsfeedController
                                                  .isTrendsScreen = false;
                                              newsfeedController
                                                      .isOtherUserProfileScreen =
                                                  false;
                                              newsfeedController
                                                  .isNewsFeedScreen = false;
                                              newsfeedController
                                                  .isBrowseScreen = false;
                                              newsfeedController
                                                  .isNotificationScreen = false;
                                              newsfeedController
                                                  .isSettingsScreen = false;
                                              newsfeedController.isListScreen =
                                                  false;
                                              newsfeedController
                                                  .isProfileScreen = false;
                                              newsfeedController.isChatScreen =
                                                  false;
                                              newsfeedController.isPostDetails =
                                                  false;
                                              newsfeedController
                                                  .isMainTopicScreen = false;
                                              newsfeedController
                                                      .isTopicTrendingUserList =
                                                  true;
                                              newsfeedController.update();
                                            }
                                          : () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        TopicTrendingUserList()),
                                              );
                                            },
                                      child:
                                          controller.topic.data.trendingUsers
                                                      .length >=
                                                  4
                                              ? Row(
                                                  children: [
                                                    Stack(
                                                      clipBehavior: Clip.none,
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundImage: controller
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          0]
                                                                      .profileImage !=
                                                                  null
                                                              ? NetworkImage(controller
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers[
                                                                      0]
                                                                  .profileImage)
                                                              : AssetImage(
                                                                  'assets/images/person_placeholder.png'),
                                                        ),
                                                        Positioned(
                                                          left: 30,
                                                          child: CircleAvatar(
                                                            backgroundImage: controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            1]
                                                                        .profileImage !=
                                                                    null
                                                                ? NetworkImage(
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            1]
                                                                        .profileImage)
                                                                : AssetImage(
                                                                    'assets/images/person_placeholder.png'),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 60,
                                                          child: CircleAvatar(
                                                            backgroundImage: controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            2]
                                                                        .profileImage !=
                                                                    null
                                                                ? NetworkImage(
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            2]
                                                                        .profileImage)
                                                                : AssetImage(
                                                                    'assets/images/person_placeholder.png'),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 90,
                                                          child: CircleAvatar(
                                                            backgroundImage: controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            3]
                                                                        .profileImage !=
                                                                    null
                                                                ? NetworkImage(
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            3]
                                                                        .profileImage)
                                                                : AssetImage(
                                                                    'assets/images/person_placeholder.png'),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      width: 100,
                                                    ),
                                                    Text(
                                                      "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} others are trending in this topic",
                                                      // style: TextStyle(
                                                      //   fontSize: kIsWeb ? 17 : 13,
                                                      //   decoration: TextDecoration.underline,
                                                      // ),
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline4
                                                          .copyWith(
                                                        fontSize:
                                                            kIsWeb ? 14 : 12,
                                                      ),
                                                    ),
                                                  ],
                                                )
                                              : controller
                                                          .topic
                                                          .data
                                                          .trendingUsers
                                                          .length ==
                                                      3
                                                  ? Row(
                                                      children: [
                                                        Stack(
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            CircleAvatar(
                                                              backgroundImage: controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage !=
                                                                      null
                                                                  ? NetworkImage(
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage)
                                                                  : AssetImage(
                                                                      'assets/images/person_placeholder.png'),
                                                            ),
                                                            Positioned(
                                                              left: 30,
                                                              child:
                                                                  CircleAvatar(
                                                                backgroundImage: controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                1]
                                                                            .profileImage !=
                                                                        null
                                                                    ? NetworkImage(controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            1]
                                                                        .profileImage)
                                                                    : AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 60,
                                                              child:
                                                                  CircleAvatar(
                                                                backgroundImage: controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                2]
                                                                            .profileImage !=
                                                                        null
                                                                    ? NetworkImage(controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            2]
                                                                        .profileImage)
                                                                    : AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          width: 100,
                                                        ),
                                                        Text(
                                                          "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} others are trending in this topic",
                                                          // style: TextStyle(
                                                          //   fontSize: kIsWeb ? 17 : 13,
                                                          //   decoration: TextDecoration.underline,
                                                          // ),
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline4
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 14
                                                                : 12,
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  : controller
                                                              .topic
                                                              .data
                                                              .trendingUsers
                                                              .length ==
                                                          2
                                                      ? Row(
                                                          children: [
                                                            Stack(
                                                              clipBehavior:
                                                                  Clip.none,
                                                              children: [
                                                                CircleAvatar(
                                                                  backgroundImage: controller
                                                                              .topic
                                                                              .data
                                                                              .trendingUsers[
                                                                                  0]
                                                                              .profileImage !=
                                                                          null
                                                                      ? NetworkImage(controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage)
                                                                      : AssetImage(
                                                                          'assets/images/person_placeholder.png'),
                                                                ),
                                                                Positioned(
                                                                  left: 30,
                                                                  child:
                                                                      CircleAvatar(
                                                                    backgroundImage: controller.topic.data.trendingUsers[1].profileImage !=
                                                                            null
                                                                        ? NetworkImage(controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                1]
                                                                            .profileImage)
                                                                        : AssetImage(
                                                                            'assets/images/person_placeholder.png'),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              width: 120,
                                                            ),
                                                            Text(
                                                              "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} other are trending in this topic",
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 12,
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      : controller
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers
                                                                  .length ==
                                                              1
                                                          ? Row(
                                                              children: [
                                                                Stack(
                                                                  clipBehavior:
                                                                      Clip.none,
                                                                  children: [
                                                                    CircleAvatar(
                                                                      backgroundImage: controller.topic.data.trendingUsers[0].profileImage !=
                                                                              null
                                                                          ? NetworkImage(controller
                                                                              .topic
                                                                              .data
                                                                              .trendingUsers[0]
                                                                              .profileImage)
                                                                          : AssetImage('assets/images/person_placeholder.png'),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 30,
                                                                ),
                                                                Text(
                                                                  "${controller.topic.data.trendingUsers[0].firstname} are trending in this topic",
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 12,
                                                                  ),
                                                                ),
                                                              ],
                                                            )
                                                          : SizedBox(),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Obx(() {
                                    return Wrap(
                                      children: [
                                        controller
                                                    .suggestedFollowingTopicForOtherProfile
                                                    .data
                                                    .topics[controller.index]
                                                    .isFollowed
                                                    .value ==
                                                0
                                            ? MouseRegion(
                                                cursor:
                                                    SystemMouseCursors.click,
                                                child: GestureDetector(
                                                  onTap: () async {
                                                    if (controller
                                                            .suggestedFollowingTopicForOtherProfile
                                                            .data
                                                            .topics[controller
                                                                .index]
                                                            .isFollowed
                                                            .value ==
                                                        0) {
                                                      controller
                                                          .suggestedFollowingTopicForOtherProfile
                                                          .data
                                                          .topics[
                                                              controller.index]
                                                          .isFollowed
                                                          .value = 4;
                                                      await controller
                                                          .followUnFollowTopic(
                                                              topicId: controller
                                                                  .suggestedFollowingTopicForOtherProfile
                                                                  .data
                                                                  .topics[
                                                                      controller
                                                                          .index]
                                                                  .id);
                                                    }
                                                  },
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Container(
                                                          // height: Get.height*0.1,
                                                          // width: Get.width*0.25,
                                                          decoration: BoxDecoration(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.black
                                                                  : Colors
                                                                      .white,
                                                              border: Border.all(
                                                                  width: 1,
                                                                  color: Colors
                                                                      .grey),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          100)),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 15,
                                                                    right: 15,
                                                                    top: 5,
                                                                    bottom: 5),
                                                            child: Text(
                                                              Strings.following,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 14,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : controller
                                                        .suggestedFollowingTopicForOtherProfile
                                                        .data
                                                        .topics[
                                                            controller.index]
                                                        .isFollowed
                                                        .value ==
                                                    3
                                                ? Row(
                                                    children: [
                                                      Expanded(
                                                        child: MouseRegion(
                                                          cursor:
                                                              SystemMouseCursors
                                                                  .click,
                                                          child:
                                                              GestureDetector(
                                                            onTap: () async {
                                                              if (controller
                                                                      .suggestedFollowingTopicForOtherProfile
                                                                      .data
                                                                      .topics[controller
                                                                          .index]
                                                                      .isFollowed
                                                                      .value ==
                                                                  3) {
                                                                controller
                                                                    .suggestedFollowingTopicForOtherProfile
                                                                    .data
                                                                    .topics[
                                                                        controller
                                                                            .index]
                                                                    .isFollowed
                                                                    .value = 4;
                                                                await controller.addRemoveNotInterested(
                                                                    topicId: controller
                                                                        .suggestedFollowingTopicForOtherProfile
                                                                        .data
                                                                        .topics[
                                                                            controller.index]
                                                                        .id);
                                                              }
                                                            },
                                                            child: Container(
                                                              // height: Get.height*0.1,
                                                              // width: Get.width*0.25,
                                                              decoration: BoxDecoration(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .black
                                                                      : Colors
                                                                          .white,
                                                                  border: Border.all(
                                                                      width: 1,
                                                                      color: Colors
                                                                          .grey),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              100)),
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            10,
                                                                        right:
                                                                            10,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                child: Text(
                                                                  'Not interested',
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style:
                                                                      TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                : controller
                                                            .suggestedFollowingTopicForOtherProfile
                                                            .data
                                                            .topics[controller
                                                                .index]
                                                            .isFollowed
                                                            .value ==
                                                        4
                                                    ? Row(
                                                        children: [
                                                          Expanded(
                                                            child: MouseRegion(
                                                              cursor:
                                                                  SystemMouseCursors
                                                                      .click,
                                                              child:
                                                                  GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  if (controller
                                                                          .suggestedFollowingTopicForOtherProfile
                                                                          .data
                                                                          .topics[
                                                                              controller.index]
                                                                          .isFollowed
                                                                          .value ==
                                                                      4) {
                                                                    controller
                                                                        .suggestedFollowingTopicForOtherProfile
                                                                        .data
                                                                        .topics[
                                                                            controller.index]
                                                                        .isFollowed
                                                                        .value = 3;

                                                                    await controller.addRemoveNotInterested(
                                                                        topicId: controller
                                                                            .suggestedFollowingTopicForOtherProfile
                                                                            .data
                                                                            .topics[controller.index]
                                                                            .id);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  // height: Get.height*0.1,
                                                                  // width: Get.width*0.25,
                                                                  decoration: BoxDecoration(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      border: Border.all(
                                                                          width:
                                                                              1,
                                                                          color: Colors
                                                                              .grey),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100)),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            10,
                                                                        right:
                                                                            10,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                    child: Text(
                                                                      'Not interested',
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style:
                                                                          TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize: kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 20,
                                                          ),
                                                          Expanded(
                                                            child: MouseRegion(
                                                              cursor:
                                                                  SystemMouseCursors
                                                                      .click,
                                                              child:
                                                                  GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  if (controller
                                                                          .suggestedFollowingTopicForOtherProfile
                                                                          .data
                                                                          .topics[
                                                                              controller.index]
                                                                          .isFollowed
                                                                          .value ==
                                                                      4) {
                                                                    controller
                                                                        .suggestedFollowingTopicForOtherProfile
                                                                        .data
                                                                        .topics[
                                                                            controller.index]
                                                                        .isFollowed
                                                                        .value = 0;
                                                                    await controller.followUnFollowTopic(
                                                                        topicId: controller
                                                                            .suggestedFollowingTopicForOtherProfile
                                                                            .data
                                                                            .topics[controller.index]
                                                                            .id);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  decoration: BoxDecoration(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      border: Border.all(
                                                                          width:
                                                                              1,
                                                                          color: Colors
                                                                              .grey),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100)),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            15,
                                                                        right:
                                                                            15,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                    child: Text(
                                                                      Strings.follow,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      // style: TextStyle(
                                                                      //     fontSize: 15,
                                                                      //     fontWeight: FontWeight
                                                                      //         .bold,
                                                                      //     color: Colors.white
                                                                      // ),
                                                                      style:
                                                                          TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize: kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    : SizedBox()
                                      ],
                                    );
                                  }),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ];
                  },
                  body: CustomScrollView(slivers: [
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.only(top: 10, bottom: 30),
                        child: controller.topicList == null ||
                                controller.topicList.isEmpty
                            ? Center(
                                child: Text(
                                  Strings.noPosts,
                                  style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize: kIsWeb ? 16 : 14,
                                  ),
                                ),
                              )
                            :
                            // Text('')
                            PagedL(
                                emptyStateWidget: Text(
                                  Strings.noPosts,
                                  style: TextStyle(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize: kIsWeb ? 16 : 14,
                                  ),
                                ),
                                itemBuilder: _itemRow,
                                padding: EdgeInsets.only(top: 10, bottom: 30),
                                loadingIndicator: Padding(
                                  padding: EdgeInsets.all(16.00),
                                  child: Center(
                                    child: CircularProgressIndicator(
                                      color: MyColors.BlueColor,
                                    ),
                                  ),
                                ),
                                itemDataProvider: _fetchData,
                                list: controller.topicList,
                                listSize:
                                    _checkPage(controller.topicList.length),
                              ),
                      ),
                    ),
                  ])));
    });
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    // print("fetchdata");

    return await topicController.topic_Post(
        topicId: topicController.othertopicid, pageNO: page);
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = topicController.topicList.indexWhere((element) {
      return element.postId == post.postId;
    });

    // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        post.pinPost == 1
            ? Row(
                children: [
                  Icon(
                    Icons.push_pin,
                    color: newsfeedController.displayColor,
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    "Pinned Werf",
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 16 : 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              )
            : SizedBox(),
        PostCard(
          postList: topicController.topicList,
          index: index,
          post: topicController.topicList[index],
          scaffoldKey: _scaffoldKey,
          controller: topicController.newsfeedController,
          deletePostId: 7,
          topicId: topicController.othertopicid,
        ),
      ],
    );
  }
}
