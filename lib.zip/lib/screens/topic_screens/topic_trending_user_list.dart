import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/network/controller/topic_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/blue_tick.dart';

import '../../models/topic_model/topic_details_model.dart';
import '../../utils/font.dart';

class TopicTrendingUserList extends StatelessWidget {
  // const TopicTrendingUserList({this.controller});

  final NewsfeedController controller = Get.put(NewsfeedController());

  TopicController topicController = Get.find<TopicController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return WillPopScope(
          onWillPop: () async {
            controller.isBrowseScreen = false;
            controller.isNewsFeedScreen = true;
            controller.isTrendsScreen = false;
            controller.isWhoToFollowScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            controller.isProfileScreen = false;
            controller.isSettingsScreen = false;
            controller.update();
            Navigator.pop(context);
            return false;
          },
          child: Scaffold(
            appBar: AppBar(
                elevation: 0.0,
                automaticallyImplyLeading: false,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                iconTheme: IconThemeData(
                  color: Color(0xFF4f515b),
                ),
                title: Row(
                  children: [
                    GestureDetector(
                        onTap: kIsWeb
                            ? () {
                                controller.isSearch = false;
                                controller.isFilter = false;
                                controller.isFilterScreen = false;
                                controller.isTrendsScreen = false;
                                controller.isNewsFeedScreen = false;
                                controller.isBrowseScreen = false;
                                controller.isNotificationScreen = false;
                                controller.isChatScreen = false;
                                controller.isSavedPostScreen = false;
                                controller.isPostDetails = false;
                                controller.isProfileScreen = false;
                                controller.isFollwerScreen = false;
                                controller.isWhoToFollowScreen = false;
                                controller.isSettingsScreen = false;
                                controller.isMainTopicScreen = true;
                                controller.isTopicTrendingUserList = false;
                                controller.update();
                              }
                            : () {
                                Get.back();
                              },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          size: 25,
                        )),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            topicController.topic.data.topicDetail.topic,
                            textAlign: TextAlign.left,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            "Trending in this post",
                            textAlign: TextAlign.left,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                            // style: Theme
                            //     .of(context)
                            //     .textTheme
                            //     .headline6
                            //     .copyWith(
                            //   fontSize: 10,
                            //   fontWeight: FontWeight.w700,
                            //   color: Colors.black,
                            // ),
                          ),
                        ])
                  ],
                )),
            body: SingleChildScrollView(
              controller: ScrollController(),
              child: Column(
                children: [
                  Container(
                    height: 1,
                    color: Colors.grey[300],
                  ),
                  topicController.topic.data.trendingUsers == null ||
                          topicController.topic.data.trendingUsers.isEmpty
                      ? Center(child: Text(Strings.noSuggestion))
                      : Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: List.generate(
                              topicController.topic.data.trendingUsers.length,
                              (index) {
                            return InkWell(
                              hoverColor: Colors.grey.withOpacity(0.3),
                              onTap: kIsWeb
                                  ? () {
                                      // print("kisweb");

                                      Get.find<NewsfeedController>().userInfo =
                                          UserProfile();
                                      Get.find<NewsfeedController>().update();

                                      _clickWho(topicController
                                          .topic.data.trendingUsers[index]);
                                    }
                                  : () async {
                                      _clickWho(topicController
                                          .topic.data.trendingUsers[index]);
                                      // print("who to aya ");
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  OtherUsersProfile(
                                                      controller: controller)));
                                    },
                              child: ListTile(
                                mouseCursor: MouseCursor.defer,
                                minVerticalPadding: 0,
                                leading: controller.userProfile == null
                                    ? Container(
                                        width: 24,
                                        child: Center(
                                          child: SpinKitCircle(
                                            color: Colors.grey,
                                            size: 40,
                                          ),
                                        ))
                                    : topicController
                                                .topic
                                                .data
                                                .trendingUsers[index]
                                                .profileImage ==
                                            null
                                        ? CircleAvatar(
                                            radius: 18,
                                            backgroundImage: AssetImage(
                                                "assets/images/person_placeholder.png"))
                                        : ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(30),
                                            child: FadeInImage(
                                                fit: BoxFit.cover,
                                                width: 38,
                                                height: 38,
                                                placeholder: AssetImage(
                                                    'assets/images/person_placeholder.png'),
                                                image: NetworkImage(topicController
                                                            .topic
                                                            .data
                                                            .trendingUsers[
                                                                index]
                                                            .profileImage !=
                                                        null
                                                    ? topicController
                                                        .topic
                                                        .data
                                                        .trendingUsers[index]
                                                        .profileImage
                                                    : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                          ),
                                title: Align(
                                  alignment: Alignment.bottomLeft,

                                  ///blue tick
                                  child: Row(
                                    children: [
                                      Text(
                                        '${topicController.topic.data.trendingUsers[index].firstname}',
                                        style: Styles.baseTextTheme.headline5
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      topicController
                                                  .topic
                                                  .data
                                                  .trendingUsers[index]
                                                  .accountVerified ==
                                              "verified"
                                          ? Row(
                                              children: [
                                                SizedBox(
                                                  width: 5,
                                                ),
                                                BlueTick(
                                                  height: 15,
                                                  width: 15,
                                                  iconSize: 10,
                                                ),
                                              ],
                                            )
                                          : SizedBox(),
                                    ],
                                  ),
                                ),
                                subtitle: Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    '${topicController.topic.data.trendingUsers[index].username}',
                                    style:
                                        Styles.baseTextTheme.headline5.copyWith(
                                      fontSize: kIsWeb ? 14 : 12,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                                trailing: topicController.topic.data
                                            .trendingUsers[index].id !=
                                        GetStorage().read('id')
                                    ? Obx(() {
                                        return ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          child: MediaQuery.of(context)
                                                      .size
                                                      .width <=
                                                  1250
                                              ? SizedBox(
                                                  width: Get.width / 4.45,
                                                  height: 30,
                                                  child: MaterialButton(
                                                      padding:
                                                          EdgeInsets.all(4),
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .isFollower
                                                                      .value ==
                                                                  0
                                                              ? Colors.white
                                                              : Colors.black
                                                          : topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .isFollower
                                                                      .value ==
                                                                  0
                                                              ? Colors.black
                                                              : Colors.white,

                                                      // topicController.topic.data.trendingUsers[index].isFollower.value == 0 ? Color(0xFFedab30) : Colors.blueAccent,

                                                      onPressed: () async {
                                                        if (topicController
                                                                .topic
                                                                .data
                                                                .trendingUsers[
                                                                    index]
                                                                .isFollower
                                                                .value ==
                                                            0) {
                                                          topicController
                                                              .topic
                                                              .data
                                                              .trendingUsers[
                                                                  index]
                                                              .isFollower
                                                              .value = 1;

                                                          await controller
                                                              .addFollowing(
                                                                  topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .id,
                                                                  "follow");
                                                        } else if (topicController
                                                                .topic
                                                                .data
                                                                .trendingUsers[
                                                                    index]
                                                                .isFollower
                                                                .value ==
                                                            1) {
                                                          topicController
                                                              .topic
                                                              .data
                                                              .trendingUsers[
                                                                  index]
                                                              .isFollower
                                                              .value = 0;

                                                          await controller
                                                              .addFollowing(
                                                                  topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .id,
                                                                  "unFollow");
                                                        }
                                                      },
                                                      child: Text(
                                                        topicController
                                                                    .topic
                                                                    .data
                                                                    .trendingUsers[
                                                                        index]
                                                                    .isFollower
                                                                    .value ==
                                                                0
                                                            ? "${Strings.follow}"
                                                                .capitalizeFirst
                                                            : "${Strings.unFollow}"
                                                                .capitalizeFirst,
                                                        style: TextStyle(
                                                          fontSize:
                                                              kIsWeb ? 14 : 14,
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? topicController
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              index]
                                                                          .isFollower
                                                                          .value ==
                                                                      0
                                                                  ? Colors.black
                                                                  : Colors.white
                                                              : topicController
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              index]
                                                                          .isFollower
                                                                          .value ==
                                                                      0
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                        textAlign:
                                                            TextAlign.center,
                                                      )),
                                                )
                                              : MaterialButton(
                                                  padding: EdgeInsets.all(4),
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? topicController
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers[
                                                                      index]
                                                                  .isFollower
                                                                  .value ==
                                                              0
                                                          ? Colors.white
                                                          : Colors.black
                                                      : topicController
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers[
                                                                      index]
                                                                  .isFollower
                                                                  .value ==
                                                              0
                                                          ? Colors.black
                                                          : Colors.white,
                                                  onPressed: () async {
                                                    if (topicController
                                                            .topic
                                                            .data
                                                            .trendingUsers[
                                                                index]
                                                            .isFollower
                                                            .value ==
                                                        0) {
                                                      topicController
                                                          .topic
                                                          .data
                                                          .trendingUsers[index]
                                                          .isFollower
                                                          .value = 1;

                                                      await controller
                                                          .addFollowing(
                                                              topicController
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers[
                                                                      index]
                                                                  .id,
                                                              "follow");
                                                    } else if (topicController
                                                            .topic
                                                            .data
                                                            .trendingUsers[
                                                                index]
                                                            .isFollower
                                                            .value ==
                                                        1) {
                                                      topicController
                                                          .topic
                                                          .data
                                                          .trendingUsers[index]
                                                          .isFollower
                                                          .value = 0;

                                                      await controller
                                                          .addFollowing(
                                                              topicController
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers[
                                                                      index]
                                                                  .id,
                                                              "unFollow");
                                                    }
                                                  },
                                                  child: Text(
                                                    topicController
                                                                .topic
                                                                .data
                                                                .trendingUsers[
                                                                    index]
                                                                .isFollower
                                                                .value ==
                                                            0
                                                        ? "${Strings.follow}"
                                                            .capitalizeFirst
                                                        : "${Strings.unFollow}"
                                                            .capitalizeFirst,
                                                    style: TextStyle(
                                                      fontSize:
                                                          kIsWeb ? 14 : 14,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .isFollower
                                                                      .value ==
                                                                  0
                                                              ? Colors.black
                                                              : Colors.white
                                                          : topicController
                                                                      .topic
                                                                      .data
                                                                      .trendingUsers[
                                                                          index]
                                                                      .isFollower
                                                                      .value ==
                                                                  0
                                                              ? Colors.white
                                                              : Colors.black,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                        );
                                      })
                                    : Container(
                                        height: 10,
                                        width: 50,
                                        color: Colors.transparent,
                                      ),
                              ),
                            );
                          }),
                        ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _clickWho(TrendingUsers post) async {
    // print("Lll");

    // print('CCCLLIIICKKKK' + post.id.toString());
    controller.otherUserId = post.id;
    controller.isProfileScreen = false;
    // controller.isClickWhoToFollow = true;
    controller.isTopicTrendingUserList = false;
    controller.isWhoToFollowScreen = false;
    controller.isOtherUserProfileScreen = true;
    controller.isTrendsScreen = false;
    controller.isNewsFeedScreen = false;
    controller.isBrowseScreen = false;
    controller.isNotificationScreen = false;
    controller.isChatScreen = false;
    controller.isPostDetails = false;
    controller.isSettingsScreen = false;
    controller.isListScreen = false;

    try {
      // Get.find<NewsfeedController>().otherUserId = post.id;
      //
      // print(
      //     "other user id >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${controller.otherUserId}");

      Get.find<NewsfeedController>().userInfo = UserProfile();
      Get.find<NewsfeedController>().userInfo =
          await controller.getOtherUserProfile(post.id);

      await Get.find<OtherUserController>()
          .filterUsersPostPagged("posts", page: 1);
      Get.find<OtherUserController>().userPosts.forEach((element) {
        element.mute = Get.find<NewsfeedController>().userInfo.muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {}
    // Get.to(() => OtherUsersProfile(controller: controller));
    controller.update();
    // try{
    //   if(controller.isOtherUserProfileScreen || controller.isClickWhoToFollow){
    //     final otherUserController = Get.find<OtherUserController>();
    //     controller.otherUserId = post.id;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isClickWhoToFollow = true;
    //     controller.isWhoToFollowScreen = false;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isTrendsScreen = false;
    //     controller.isNewsFeedScreen = false;
    //     controller.isQuestScreen = false;
    //     controller.isNotificationScreen = false;
    //     controller.isChatScreen = false;
    //     controller.isPostDetails = false;
    //     otherUserController.update();
    // } else {

    // }finally{
  }
}
