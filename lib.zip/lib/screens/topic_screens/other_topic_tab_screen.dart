import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/topic_screens/other_main_topic_screen.dart';
import 'package:werfieapp/utils/colors.dart';

import '../../network/controller/other_topic_controller.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';

class OtherTopicTabScreen extends StatelessWidget {
  final topicController = Get.put(OtherTopicController());

  @override
  Widget build(BuildContext context) {
    return GetBuilder<OtherTopicController>(builder: (controller) {
      return Scaffold(
          appBar: kIsWeb
              ? PreferredSize(
                  preferredSize:
                      kIsWeb ? Size.fromHeight(50.0) : Size.fromHeight(60.0),
                  child: Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        kIsWeb
                            ? SizedBox(
                                height: 20,
                              )
                            : SizedBox(height: 49),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Row(
                            children: [
                              MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: GestureDetector(
                                  onTap: kIsWeb
                                      ? () {
                                          controller.newsfeedController
                                              .isTrendsScreen = false;
                                          controller.newsfeedController
                                              .isNewsFeedScreen = true;
                                          controller.newsfeedController
                                              .isBrowseScreen = false;
                                          controller.newsfeedController
                                              .isNotificationScreen = false;
                                          controller.newsfeedController
                                              .isChatScreen = false;
                                          controller.newsfeedController
                                              .isSavedPostScreen = false;
                                          controller.newsfeedController
                                              .isPostDetails = false;
                                          controller.newsfeedController
                                              .isProfileScreen = false;
                                          controller.newsfeedController
                                              .isOtherUserProfileScreen = false;
                                          controller.newsfeedController
                                              .isTopicScreen = false;
                                          controller.newsfeedController
                                              .isListScreen = false;
                                          controller.newsfeedController
                                              .isMainTopicScreen = false;
                                          controller.newsfeedController
                                              .update();
                                        }
                                      : () {
                                          Navigator.pop(context);
                                        },
                                  child: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    size: 25,
                                  ),
                                ),
                              ),
                              kIsWeb
                                  ? SizedBox(
                                      width: 50,
                                    )
                                  : SizedBox(width: 20),
                              Text(Strings.topics,
                                  style:
                                      Styles.baseTextTheme.headline2.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontWeight: FontWeight.bold,
                                  )),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : AppBar(
                  automaticallyImplyLeading: false,
                  backgroundColor: Colors.white,
                  title: Row(
                    children: [
                      MouseRegion(
                        cursor: SystemMouseCursors.click,
                        child: GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            )),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        Strings.topics,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
          body: controller.isLoading == true
              ? Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                )
              : CustomScrollView(
                  controller: ScrollController(),
                  slivers: [
                    SliverToBoxAdapter(
                      child: kIsWeb
                          ? Divider(
                              thickness: 2,
                            )
                          : SizedBox(
                              height: 10,
                            ),
                    ),
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (BuildContext context, int index) {
                          return controller
                                  .suggestedFollowingTopicForOtherProfile
                                  .data
                                  .topics
                                  .isEmpty
                              ? SizedBox()
                              : InkWell(
                                  onTap: kIsWeb
                                      ? () async {
                                          if (controller
                                                  .suggestedFollowingTopicForOtherProfile
                                                  .data
                                                  .topics[index]
                                                  .isFollowed
                                                  .value ==
                                              1) {
                                            Fluttertoast.showToast(
                                                msg:
                                                    "Your are not Follow this Topic",
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: Colors.red,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                          } else {
                                            controller.newsfeedController
                                                .isTrendsScreen = false;
                                            controller.newsfeedController
                                                .isNewsFeedScreen = false;
                                            controller.newsfeedController
                                                .isBrowseScreen = false;
                                            controller.newsfeedController
                                                .isNotificationScreen = false;
                                            controller.newsfeedController
                                                .isChatScreen = false;
                                            controller.newsfeedController
                                                .isSavedPostScreen = false;
                                            controller.newsfeedController
                                                .isPostDetails = false;
                                            controller.newsfeedController
                                                .isProfileScreen = false;
                                            controller.newsfeedController
                                                    .isOtherUserProfileScreen =
                                                false;
                                            controller.newsfeedController
                                                .isTopicScreen = false;
                                            controller.newsfeedController
                                                .otherProfileScreen = false;
                                            controller.newsfeedController
                                                .isListScreen = false;
                                            controller.newsfeedController
                                                .isMainTopicScreen = false;
                                            controller.newsfeedController
                                                .isOtherTopicTabScreen = false;
                                            controller.newsfeedController
                                                .isOtherMainTopicScreen = true;

                                            // print(
                                            //     " controller.newsfeedController.isOtherMainTopicScreen ${controller.newsfeedController.isOtherMainTopicScreen}");

                                            // print("qwert");
                                            controller.index = index;
                                            controller.topicName = controller
                                                .suggestedFollowingTopicForOtherProfile
                                                .data
                                                .topics[index]
                                                .topic;
                                            controller.newsfeedController
                                                .update();
                                            controller.screenCheck = 2;
                                            controller.update();

                                            controller.othertopicid = controller
                                                .suggestedFollowingTopicForOtherProfile
                                                .data
                                                .topics[index]
                                                .id;

                                            await controller.topicPost(
                                                topicId: controller
                                                    .suggestedFollowingTopicForOtherProfile
                                                    .data
                                                    .topics[index]
                                                    .id,
                                                pageNO: 1);

                                            // print("idheeret");
                                          }
                                        }
                                      : () async {
                                          if (controller
                                                  .suggestedFollowingTopicForOtherProfile
                                                  .data
                                                  .topics[index]
                                                  .isFollowed
                                                  .value ==
                                              1) {
                                            Fluttertoast.showToast(
                                                msg:
                                                    "Your are not Follow this Topic",
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: Colors.red,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                          } else {
                                            controller.screenCheck = 2;
                                            controller.update();
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      OtherMainTopicScreen()),
                                            );

                                            await controller.topicPost(
                                                topicId: controller
                                                    .suggestedFollowingTopicForOtherProfile
                                                    .data
                                                    .topics[index]
                                                    .id,
                                                pageNO: 1);
                                          }
                                        },
                                  child: ListTile(
                                    mouseCursor: MouseCursor.defer,
                                    leading: GestureDetector(
                                      child: CircleAvatar(
                                        backgroundColor: controller
                                            .newsfeedController.displayColor,
                                        radius: 20,
                                        child: Icon(
                                          Icons.topic,
                                          size: 25,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    title: Text(
                                      controller
                                          .suggestedFollowingTopicForOtherProfile
                                          .data
                                          .topics[index]
                                          .topic,
                                      style: Styles.baseTextTheme.headline5
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    // subtitle: Text('Here is a second line'),
                                    trailing: Obx(() {
                                      return MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () async {
                                            if (controller
                                                    .suggestedFollowingTopicForOtherProfile
                                                    .data
                                                    .topics[index]
                                                    .isFollowed
                                                    .value ==
                                                0) {
                                              controller
                                                  .suggestedFollowingTopicForOtherProfile
                                                  .data
                                                  .topics[index]
                                                  .isFollowed
                                                  .value = 1;

                                              await controller.followUnFollowTopic(
                                                  topicId: controller
                                                      .suggestedFollowingTopicForOtherProfile
                                                      .data
                                                      .topics[index]
                                                      .id);
                                            } else if (controller
                                                    .suggestedFollowingTopicForOtherProfile
                                                    .data
                                                    .topics[index]
                                                    .isFollowed
                                                    .value ==
                                                1) {
                                              controller
                                                  .suggestedFollowingTopicForOtherProfile
                                                  .data
                                                  .topics[index]
                                                  .isFollowed
                                                  .value = 0;

                                              await controller.followUnFollowTopic(
                                                  topicId: controller
                                                      .suggestedFollowingTopicForOtherProfile
                                                      .data
                                                      .topics[index]
                                                      .id);
                                            }
                                          },
                                          child: controller
                                                      .suggestedFollowingTopicForOtherProfile
                                                      .data
                                                      .topics[index]
                                                      .isFollowed
                                                      .value ==
                                                  0
                                              ? MouseRegion(
                                                  cursor:
                                                      SystemMouseCursors.click,
                                                  child: Container(
                                                    // height: Get.height*0.1,
                                                    // width: Get.width*0.25,
                                                    decoration: BoxDecoration(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.black
                                                            : Colors.white,
                                                        border: Border.all(
                                                            width: 1,
                                                            color: Colors.grey),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(100)),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 15,
                                                              right: 15,
                                                              top: 5,
                                                              bottom: 5),
                                                      child: Text(
                                                        Strings.following,
                                                        // style: TextStyle(
                                                        //     fontSize: 15,
                                                        //     fontWeight: FontWeight.w900,
                                                        //     color: Colors.black
                                                        // ),
                                                        style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize:
                                                              kIsWeb ? 14 : 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : MouseRegion(
                                                  cursor:
                                                      SystemMouseCursors.click,
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.black
                                                            : Colors.white,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(100)),
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 15,
                                                              right: 15,
                                                              top: 5,
                                                              bottom: 5),
                                                      child: Text(
                                                        Strings.follow,
                                                        // style: TextStyle(
                                                        //     fontSize: 15,
                                                        //     fontWeight: FontWeight.w600,
                                                        //     color: Colors.white
                                                        // ),
                                                        style: TextStyle(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize:
                                                              kIsWeb ? 14 : 14,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                        ),
                                      );
                                    }),
                                  ),
                                );
                        },

                        ///error
                        childCount: controller
                                .suggestedFollowingTopicForOtherProfile
                                .data
                                .topics
                                .isEmpty
                            ? 0
                            : controller.suggestedFollowingTopicForOtherProfile
                                .data.topics.length,
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: controller.suggestedFollowingTopicForOtherProfile
                              .data.topics.isEmpty
                          ? SizedBox()
                          : Divider(),
                    ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              Strings.suggestedTopics,
                              // style: Get.textTheme.headline4.copyWith(
                              //     color: Colors.black,
                              //     fontWeight: FontWeight.bold,
                              //     fontSize: 18
                              // ),
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              Strings.youllSeeTopWerfs,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: kIsWeb ? 14 : 12,
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                        child: Column(
                      children: [
                        SizedBox(
                          height: 20,
                        )
                      ],
                    )),

                    ///followedSuggestedList

                    controller.suggestedFollowingTopicForOtherProfile.data
                            .suggestedTopics.isEmpty
                        ? SliverToBoxAdapter(
                            child: Container(),
                          )
                        : SliverGrid(
                            gridDelegate:
                                const SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: kIsWeb ? 290.0 : 350,
                              mainAxisExtent: 50,
                              mainAxisSpacing: 10.0,
                              crossAxisSpacing: 10.0,
                              childAspectRatio: 4.0,
                            ),
                            delegate: SliverChildBuilderDelegate(
                              (BuildContext context, int index) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: SuggestedListWidget(
                                    title: controller
                                        .suggestedFollowingTopicForOtherProfile
                                        .data
                                        .suggestedTopics[index]
                                        .topic,
                                    topicController: controller,
                                    index: index,
                                  ),
                                );
                              },
                              childCount: controller
                                      .suggestedFollowingTopicForOtherProfile
                                      .data
                                      .suggestedTopics
                                      .isEmpty
                                  ? 0
                                  : controller
                                      .suggestedFollowingTopicForOtherProfile
                                      .data
                                      .suggestedTopics
                                      .length,
                            ),
                          ),
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 15),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 20,
                            ),
                            Divider(),
                            SizedBox(
                              height: 20,
                            ),
                            Divider(),
                            SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ));
    });
  }
}

class SuggestedListWidget extends StatelessWidget {
  SuggestedListWidget({
    this.title,
    this.topicController,
    this.index,
  });

  String title;
  int index;
  OtherTopicController topicController;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: () async {
            if (topicController.suggestedFollowingTopicForOtherProfile.data
                    .suggestedTopics[index].type.value ==
                0) {
              topicController.suggestedFollowingTopicForOtherProfile.data
                  .suggestedTopics[index].type.value = 1;

              await topicController.followUnFollowTopic(
                  topicId: topicController
                      .suggestedFollowingTopicForOtherProfile
                      .data
                      .suggestedTopics[index]
                      .id);
            } else if (topicController.suggestedFollowingTopicForOtherProfile
                    .data.suggestedTopics[index].type.value ==
                1) {
              topicController.suggestedFollowingTopicForOtherProfile.data
                  .suggestedTopics[index].type.value = 0;

              await topicController.followUnFollowTopic(
                  topicId: topicController
                      .suggestedFollowingTopicForOtherProfile
                      .data
                      .suggestedTopics[index]
                      .id);
            }
          },
          child: topicController.suggestedFollowingTopicForOtherProfile.data
                      .suggestedTopics[index].type.value ==
                  0
              ? MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Container(
                    // height: 50,
                    width: title.removeAllWhitespace.length * 10.toDouble(),
                    decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                        border: Border.all(width: 1, color: Colors.grey),
                        borderRadius: BorderRadius.circular(100)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Center(
                            child: Container(
                              width: kIsWeb ? 120 : 120,
                              child: Text(
                                title,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 14 : 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                          Icon(
                            Icons.add,
                            size: 20,
                            color:
                                topicController.newsfeedController.displayColor,
                          ),
                          Container(
                            height: 30,
                            width: 1,
                            color: Colors.grey,
                          ),
                          InkWell(
                            onTap: () async {
                              Fluttertoast.showToast(
                                  msg: Strings.weWontSuggestThisTopic,
                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.red,
                                  textColor: Colors.white,
                                  fontSize: 16.0);
                              topicController
                                  .suggestedFollowingTopicForOtherProfile
                                  .data
                                  .suggestedTopics[index]
                                  .type
                                  .value = 2;
                              await topicController.addRemoveNotInterested(
                                  topicId: topicController
                                      .suggestedFollowingTopicForOtherProfile
                                      .data
                                      .suggestedTopics[index]
                                      .id);
                            },
                            child: Icon(
                              Icons.clear,
                              size: 20,
                              color: Colors.grey,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              : topicController.suggestedFollowingTopicForOtherProfile.data
                          .suggestedTopics[index].type.value ==
                      1
                  ? MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: Container(
                        // height: 50,
                        width: title.removeAllWhitespace.length * 10.toDouble(),
                        decoration: BoxDecoration(
                            color:
                                topicController.newsfeedController.displayColor,
                            borderRadius: BorderRadius.circular(100)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Center(
                                child: Container(
                                  width: kIsWeb ? 120 : 120,
                                  child: Text(
                                    title,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style:
                                        Styles.baseTextTheme.headline1.copyWith(
                                      color: Colors.white,
                                      fontSize: kIsWeb ? 14 : 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              Icon(
                                Icons.check,
                                size: 20,
                                color: Colors.white,
                              )
                            ],
                          ),
                        ),
                      ),
                    )
                  : MouseRegion(
                      cursor: SystemMouseCursors.click,
                      child: Container(
                        // height: 50,
                        width: title.removeAllWhitespace.length * 10.toDouble(),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              width: 1,
                              color: Colors.grey.withOpacity(0.5),
                            ),
                            borderRadius: BorderRadius.circular(100)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Center(
                                child: Container(
                                  width: kIsWeb ? 120 : 120,
                                  child: Text(
                                    title,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontSize: kIsWeb ? 14 : 14,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
        ),
      );
    });
  }
}
