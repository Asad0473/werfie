import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/topic_screens/topic_tab_screen.dart';

import '../../network/controller/news_feed_controller.dart';
import '../../network/controller/topic_controller.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';

class TopicsCategoriesDetailsScreen extends StatelessWidget {
  TopicsCategoriesDetailsScreen({Key key}) : super(key: key);

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TopicController>(
      builder: (controller) {
        return Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(100.0),
            child: Container(
              // color: Colors.orange,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            newsfeedController.isTrendsScreen = false;
                            newsfeedController.isNewsFeedScreen = false;
                            newsfeedController.isBrowseScreen = false;
                            newsfeedController.isNotificationScreen = false;
                            newsfeedController.isChatScreen = false;
                            newsfeedController.isSavedPostScreen = false;
                            newsfeedController.isPostDetails = false;
                            newsfeedController.isProfileScreen = false;
                            newsfeedController.isOtherUserProfileScreen = false;
                            newsfeedController.isTopicScreen = true;
                            newsfeedController.isListScreen = false;
                            newsfeedController.isTopicsCategoriesDetailsScreen =
                                false;
                            newsfeedController.update();
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            size: 25,
                          ),
                        ),
                        SizedBox(
                          width: 50,
                        ),
                        Text(
                          Strings.topics,
                          style: Styles.baseTextTheme.headline2.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                          // style: TextStyle(
                          //     fontSize: 20,
                          //     fontWeight: FontWeight.w700,
                          //     color: Colors.black
                          //
                          // ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          body: ListView.builder(
              itemCount: controller.modelData.length,
              itemBuilder: (BuildContext context, int ind) {
                return Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        controller.modelData[ind].mainCateName,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                        // style: TextStyle(
                        //     color: Colors.black,
                        //     fontSize: 20,
                        //     fontWeight: FontWeight.bold
                        // ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        height: 170,
                        width: MediaQuery.of(context).size.width,
                        color: Colors.black26,
                        child: GridView.builder(
                            scrollDirection: Axis.horizontal,
                            shrinkWrap: true,
                            gridDelegate:
                                SliverGridDelegateWithMaxCrossAxisExtent(
                              maxCrossAxisExtent: 50.0,
                              mainAxisExtent: 250,
                              mainAxisSpacing: 10.0,
                              crossAxisSpacing: 10.0,
                              // childAspectRatio: 4.0,
                              // crossAxisCount: 2,
                              // mainAxisSpacing: 10.0,
                              // crossAxisSpacing: 10.0,
                              // // maxCrossAxisExtent: 130.0,
                              //  mainAxisExtent: 170,
                              // mainAxisSpacing: 10.0,
                              // crossAxisSpacing: 10.0,
                              //  childAspectRatio: 1/5,
                            ),
                            itemCount:
                                controller.modelData[ind].subCategory.length,
                            itemBuilder: (BuildContext ctx, index) {
                              return SuggestedListWidget(
                                title: controller.modelData[ind]
                                    .subCategory[index].subCategoryName,
                              );
                            }),
                      ),
                      Divider(
                        thickness: 2,
                      )
                    ],
                  ),
                );
              }),
        );
      },
    );
  }
}
