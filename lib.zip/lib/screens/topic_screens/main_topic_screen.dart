import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/screens/topic_screens/topic_trending_user_list.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';

import '../../models/post.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../network/controller/topic_controller.dart';
import '../../utils/colors.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../widgets/post_card.dart';

class MainTopicScreen extends StatefulWidget {
  String index;

  MainTopicScreen({this.index});

  @override
  State<MainTopicScreen> createState() => _MainTopicScreenState();
}

class _MainTopicScreenState extends State<MainTopicScreen> {
  TopicController topicController = Get.put(TopicController());

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    scrollController = ScrollController()..addListener(scrollListener);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      // print("WidgetsBinding");
      if (kIsWeb) {
        topicController.topicPost(
            topicId: int.parse(widget.index), pageNO: 1, isFromRoute: true);
        getTopicsData(
          int.parse(widget.index),
        );
      }
    });
  }

  void scrollListener() {
    // print("sdfdf");
    if (isShrink != lastStatus) {
      {
        lastStatus = isShrink;
        setState(() {});
      }
      setState(() {});
    }
  }

  ScrollController scrollController;

  bool lastStatus = true;
  double height = 200;

  bool get isShrink {
    // print("shrink");
    return scrollController != null &&
        scrollController.hasClients &&
        scrollController.offset > (height - kToolbarHeight);
  }

  getTopicsData(int index) async {
    topicController.screenCheck = 1;
    // topicController.update();

    await topicController.topicPost(
        topicId: topicController.notInterestedTopic.data[index].id,
        pageNO: 1,
        isFromRoute: true);

    topicController.update();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TopicController>(builder: (controller) {
      return Scaffold(
          body: controller.isLoading == true || controller.topic == null
              ? Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                )
              : NestedScrollView(
                  controller: scrollController,
                  headerSliverBuilder: (context, innerBoxIsScrolled) {
                    return [
                      SliverAppBar(
                        elevation: 0,
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        automaticallyImplyLeading: false,
                        pinned: true,
                        expandedHeight: 230,
                        flexibleSpace: FlexibleSpaceBar(
                          titlePadding: EdgeInsets.zero,
                          collapseMode: CollapseMode.parallax,
                          title: isShrink
                              ? Container(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.black
                                      : Colors.white,
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: 10,
                                      ),
                                      GestureDetector(
                                        onTap: kIsWeb
                                            ? () async {
                                                // print("maintopic screen");

                                                // newsfeedController.isTrendsScreen = false;
                                                // newsfeedController.isNewsFeedScreen =
                                                // false;
                                                // newsfeedController.isBrowseScreen = false;
                                                // newsfeedController.isNotificationScreen =
                                                // false;
                                                // newsfeedController.isChatScreen = false;
                                                // newsfeedController.isSavedPostScreen = false;
                                                // newsfeedController.isPostDetails = false;
                                                // newsfeedController.isProfileScreen = false;
                                                // newsfeedController.isOtherUserProfileScreen = false;
                                                // newsfeedController.isListScreen = false;
                                                // newsfeedController.isMainTopicScreen = false;
                                                // newsfeedController.isTopicScreen = true;
                                                Get.toNamed(FluroRouters.mainScreen + '/topics');
                                                newsfeedController.update();

                                                if (controller.screenCheck ==
                                                    1) {
                                                  await controller
                                                      .notInterestedTopicFunction();
                                                } else if (controller
                                                        .screenCheck ==
                                                    2) {
                                                  await controller
                                                      .suggestedTopic();
                                                }

                                                // Navigator.pop(context);
                                              }
                                            : () async {
                                                Navigator.pop(context);

                                                if (controller.screenCheck ==
                                                    1) {
                                                  await controller
                                                      .notInterestedTopicFunction();
                                                } else if (controller
                                                        .screenCheck ==
                                                    2) {
                                                  await controller
                                                      .suggestedTopic();
                                                }
                                              },
                                        child: Icon(
                                          Icons.arrow_back,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          size: 25,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        controller.topic.data.topicDetail.topic,
                                        // style: TextStyle(
                                        //     fontSize:kIsWeb? 20:14,
                                        //     fontWeight: FontWeight.w700,
                                        //     color: Colors.black),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        // TextStyle(
                                        //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                        //   fontSize:kIsWeb?20:14,
                                        //   fontWeight: FontWeight.bold,
                                        // ),
                                      ),
                                      Spacer(),
                                      Obx(() {
                                        return Wrap(
                                          children: [
                                            controller.topic.data.topicDetail
                                                        .type.value ==
                                                    "follow"
                                                ? MouseRegion(
                                                    cursor: SystemMouseCursors
                                                        .click,
                                                    child: GestureDetector(
                                                      onTap: () async {
                                                        if (controller
                                                                .topic
                                                                .data
                                                                .topicDetail
                                                                .type
                                                                .value ==
                                                            "follow") {
                                                          controller
                                                                  .topic
                                                                  .data
                                                                  .topicDetail
                                                                  .type
                                                                  .value =
                                                              "nothing";
                                                          await controller
                                                              .followUnFollowTopic(
                                                                  topicId:
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .topicDetail
                                                                          .id);
                                                        }
                                                      },
                                                      child: Container(
                                                        // height: Get.height*0.1,
                                                        // width: Get.width*0.25,
                                                        decoration: BoxDecoration(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.black
                                                                : Colors.white,
                                                            border: Border.all(
                                                                width: 1,
                                                                color: Colors
                                                                    .grey),
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        100)),
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  left: 15,
                                                                  right: 15,
                                                                  top: 5,
                                                                  bottom: 5),
                                                          child: Text(
                                                            Strings.following,
                                                            textAlign: TextAlign
                                                                .center,
                                                            // style: TextStyle(
                                                            //     fontSize: kIsWeb?15:10,
                                                            //     fontWeight: FontWeight.bold,
                                                            //     color: Colors.black),
                                                            style: TextStyle(
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 14,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                : controller
                                                                .topic
                                                                .data
                                                                .topicDetail
                                                                .type
                                                                .value ==
                                                            "nothing" ||
                                                        controller
                                                                .topic
                                                                .data
                                                                .topicDetail
                                                                .type
                                                                .value ==
                                                            "not_interested"
                                                    ? MouseRegion(
                                                        cursor:
                                                            SystemMouseCursors
                                                                .click,
                                                        child: GestureDetector(
                                                          onTap: () async {
                                                            if (controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .type
                                                                        .value ==
                                                                    "nothing" ||
                                                                controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .type
                                                                        .value ==
                                                                    "not_interested") {
                                                              controller
                                                                      .topic
                                                                      .data
                                                                      .topicDetail
                                                                      .type
                                                                      .value =
                                                                  "follow";
                                                              await controller
                                                                  .followUnFollowTopic(
                                                                      topicId: controller
                                                                          .topic
                                                                          .data
                                                                          .topicDetail
                                                                          .id);
                                                            }
                                                          },
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                                border: Border.all(
                                                                    width: 1,
                                                                    color: Colors
                                                                        .grey),
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .black
                                                                    : Colors
                                                                        .white,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            100)),
                                                            child: Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      left: 15,
                                                                      right: 15,
                                                                      top: 5,
                                                                      bottom:
                                                                          5),
                                                              child: Text(
                                                                'Follow Topic',
                                                                textAlign:
                                                                    TextAlign
                                                                        .center,
                                                                style:
                                                                    TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontSize:
                                                                      kIsWeb
                                                                          ? 14
                                                                          : 14,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    : SizedBox(),
                                          ],
                                        );
                                      }),
                                      SizedBox(
                                        width: 10,
                                      ),
                                    ],
                                  ),
                                )
                              : null,
                          background: SafeArea(
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 10, right: 10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 15,
                                  ),
                                  Row(
                                    children: [
                                      MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: kIsWeb
                                              ? () async {
                                                  // newsfeedController.isTrendsScreen = false;
                                                  // newsfeedController.isNewsFeedScreen =
                                                  // false;
                                                  // newsfeedController.isBrowseScreen = false;
                                                  // newsfeedController.isNotificationScreen =
                                                  // false;
                                                  // newsfeedController.isChatScreen = false;
                                                  // newsfeedController.isSavedPostScreen =
                                                  // false;
                                                  // newsfeedController.isPostDetails = false;
                                                  // newsfeedController.isProfileScreen =
                                                  // false;
                                                  // newsfeedController
                                                  //     .isOtherUserProfileScreen = false;
                                                  // newsfeedController.isListScreen = false;
                                                  // newsfeedController.isMainTopicScreen =
                                                  // false;
                                                  // newsfeedController.isTopicScreen = true;

                                                  Get.toNamed(
                                                      FluroRouters.mainScreen +
                                                          '/topics');
                                                  newsfeedController.update();

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }
                                                }
                                              : () async {
                                                  Navigator.pop(context);

                                                  if (controller.screenCheck ==
                                                      1) {
                                                    await controller
                                                        .notInterestedTopicFunction();
                                                  } else if (controller
                                                          .screenCheck ==
                                                      2) {
                                                    await controller
                                                        .suggestedTopic();
                                                  }
                                                },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 25,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        'Topic',
                                        // style: TextStyle(
                                        //     fontSize: 20,
                                        //     fontWeight: FontWeight.w700,
                                        //     color: Colors.black),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  ListTile(
                                    title: Text(
                                      controller.topic.data.topicDetail.topic,
                                      // style: TextStyle(
                                      //     fontSize: kIsWeb?30:20,
                                      //     fontWeight: FontWeight.w900,
                                      //     color: Colors.black),
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: kIsWeb ? 20 : 18,
                                      ),
                                    ),
                                    // subtitle: Text(
                                    //   'All about sports',
                                    //   style: TextStyle(fontSize: 15, color: Colors.black),
                                    // ),
                                  ),
                                  SizedBox(
                                    height: kIsWeb ? 20 : 10,
                                  ),
                                  MouseRegion(
                                    cursor: SystemMouseCursors.click,
                                    child: InkWell(
                                      onTap: kIsWeb
                                          ? () {
                                              // print("profile screen");
                                              newsfeedController
                                                  .isWhoToFollowScreen = false;
                                              newsfeedController
                                                  .isTrendsScreen = false;
                                              newsfeedController
                                                      .isOtherUserProfileScreen =
                                                  false;
                                              newsfeedController
                                                  .isNewsFeedScreen = false;
                                              newsfeedController
                                                  .isBrowseScreen = false;
                                              newsfeedController
                                                  .isNotificationScreen = false;
                                              newsfeedController
                                                  .isSettingsScreen = false;
                                              newsfeedController.isListScreen =
                                                  false;
                                              newsfeedController
                                                  .isProfileScreen = false;
                                              newsfeedController.isChatScreen =
                                                  false;
                                              newsfeedController.isPostDetails =
                                                  false;
                                              newsfeedController
                                                  .isMainTopicScreen = false;
                                              newsfeedController
                                                      .isTopicTrendingUserList =
                                                  true;
                                              newsfeedController.update();
                                            }
                                          : () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        TopicTrendingUserList()),
                                              );
                                            },
                                      child:
                                          controller.topic.data.trendingUsers
                                                      .length >=
                                                  4
                                              ? FittedBox(
                                                  child: Row(
                                                    children: [
                                                      Stack(
                                                        clipBehavior: Clip.none,
                                                        children: [
                                                          CircleAvatar(
                                                            backgroundImage: controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            0]
                                                                        .profileImage !=
                                                                    null
                                                                ? NetworkImage(
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            0]
                                                                        .profileImage)
                                                                : AssetImage(
                                                                    'assets/images/person_placeholder.png'),
                                                          ),
                                                          Positioned(
                                                            left: 30,
                                                            child: CircleAvatar(
                                                              backgroundImage: controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              1]
                                                                          .profileImage !=
                                                                      null
                                                                  ? NetworkImage(
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              1]
                                                                          .profileImage)
                                                                  : AssetImage(
                                                                      'assets/images/person_placeholder.png'),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 60,
                                                            child: CircleAvatar(
                                                              backgroundImage: controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              2]
                                                                          .profileImage !=
                                                                      null
                                                                  ? NetworkImage(
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              2]
                                                                          .profileImage)
                                                                  : AssetImage(
                                                                      'assets/images/person_placeholder.png'),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 90,
                                                            child: CircleAvatar(
                                                              backgroundImage: controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              3]
                                                                          .profileImage !=
                                                                      null
                                                                  ? NetworkImage(
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              3]
                                                                          .profileImage)
                                                                  : AssetImage(
                                                                      'assets/images/person_placeholder.png'),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      SizedBox(
                                                        width: 100,
                                                      ),
                                                      Text(
                                                        "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} others are trending in this topic",
                                                        // style: TextStyle(
                                                        //   fontSize: kIsWeb ? 17 : 13,
                                                        //   decoration: TextDecoration.underline,
                                                        // ),
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline4
                                                            .copyWith(
                                                          fontSize:
                                                              kIsWeb ? 14 : 12,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              : controller
                                                          .topic
                                                          .data
                                                          .trendingUsers
                                                          .length ==
                                                      3
                                                  ? Row(
                                                      children: [
                                                        Stack(
                                                          clipBehavior:
                                                              Clip.none,
                                                          children: [
                                                            CircleAvatar(
                                                              backgroundImage: controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage !=
                                                                      null
                                                                  ? NetworkImage(
                                                                      controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage)
                                                                  : AssetImage(
                                                                      'assets/images/person_placeholder.png'),
                                                            ),
                                                            Positioned(
                                                              left: 30,
                                                              child:
                                                                  CircleAvatar(
                                                                backgroundImage: controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                1]
                                                                            .profileImage !=
                                                                        null
                                                                    ? NetworkImage(controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            1]
                                                                        .profileImage)
                                                                    : AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 60,
                                                              child:
                                                                  CircleAvatar(
                                                                backgroundImage: controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                2]
                                                                            .profileImage !=
                                                                        null
                                                                    ? NetworkImage(controller
                                                                        .topic
                                                                        .data
                                                                        .trendingUsers[
                                                                            2]
                                                                        .profileImage)
                                                                    : AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          width: 50,
                                                        ),
                                                        Text(
                                                          "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} others are trending in this topic",
                                                          // style: TextStyle(
                                                          //   fontSize: kIsWeb ? 17 : 13,
                                                          //   decoration: TextDecoration.underline,
                                                          // ),
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline4
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 14
                                                                : 12,
                                                          ),
                                                        ),
                                                      ],
                                                    )
                                                  : controller
                                                              .topic
                                                              .data
                                                              .trendingUsers
                                                              .length ==
                                                          2
                                                      ? Row(
                                                          children: [
                                                            Stack(
                                                              clipBehavior:
                                                                  Clip.none,
                                                              children: [
                                                                CircleAvatar(
                                                                  backgroundImage: controller
                                                                              .topic
                                                                              .data
                                                                              .trendingUsers[
                                                                                  0]
                                                                              .profileImage !=
                                                                          null
                                                                      ? NetworkImage(controller
                                                                          .topic
                                                                          .data
                                                                          .trendingUsers[
                                                                              0]
                                                                          .profileImage)
                                                                      : AssetImage(
                                                                          'assets/images/person_placeholder.png'),
                                                                ),
                                                                Positioned(
                                                                  left: 30,
                                                                  child:
                                                                      CircleAvatar(
                                                                    backgroundImage: controller.topic.data.trendingUsers[1].profileImage !=
                                                                            null
                                                                        ? NetworkImage(controller
                                                                            .topic
                                                                            .data
                                                                            .trendingUsers[
                                                                                1]
                                                                            .profileImage)
                                                                        : AssetImage(
                                                                            'assets/images/person_placeholder.png'),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              width: 40,
                                                            ),
                                                            Text(
                                                              "${controller.topic.data.trendingUsers[0].firstname} and ${controller.topic.data.trendingUsers.length - 1} other are trending in this topic",
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 12,
                                                              ),
                                                            ),
                                                          ],
                                                        )
                                                      : controller
                                                                  .topic
                                                                  .data
                                                                  .trendingUsers
                                                                  .length ==
                                                              1
                                                          ? Row(
                                                              children: [
                                                                Stack(
                                                                  clipBehavior:
                                                                      Clip.none,
                                                                  children: [
                                                                    CircleAvatar(
                                                                      backgroundImage: controller.topic.data.trendingUsers[0].profileImage !=
                                                                              null
                                                                          ? NetworkImage(controller
                                                                              .topic
                                                                              .data
                                                                              .trendingUsers[0]
                                                                              .profileImage)
                                                                          : AssetImage('assets/images/person_placeholder.png'),
                                                                    ),
                                                                  ],
                                                                ),
                                                                SizedBox(
                                                                  width: 30,
                                                                ),
                                                                Text(
                                                                  "${controller.topic.data.trendingUsers[0].firstname} are trending in this topic",
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 12,
                                                                  ),
                                                                ),
                                                              ],
                                                            )
                                                          : SizedBox(),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Obx(() {
                                    return Wrap(
                                      children: [
                                        controller.topic.data.topicDetail.type
                                                    .value ==
                                                "follow"
                                            ? MouseRegion(
                                                cursor:
                                                    SystemMouseCursors.click,
                                                child: GestureDetector(
                                                  onTap: () async {
                                                    if (controller
                                                            .topic
                                                            .data
                                                            .topicDetail
                                                            .type
                                                            .value ==
                                                        "follow") {
                                                      controller
                                                          .topic
                                                          .data
                                                          .topicDetail
                                                          .type
                                                          .value = "nothing";
                                                      await controller
                                                          .followUnFollowTopic(
                                                              topicId: controller
                                                                  .topic
                                                                  .data
                                                                  .topicDetail
                                                                  .id);
                                                    }
                                                  },
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Container(
                                                          // height: Get.height*0.1,
                                                          // width: Get.width*0.25,
                                                          decoration: BoxDecoration(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.black
                                                                  : Colors
                                                                      .white,
                                                              border: Border.all(
                                                                  width: 1,
                                                                  color: Colors
                                                                      .grey),
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          100)),
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 15,
                                                                    right: 15,
                                                                    top: 5,
                                                                    bottom: 5),
                                                            child: Text(
                                                              Strings.following,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: TextStyle(
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 14,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              )
                                            : controller.topic.data.topicDetail
                                                        .type ==
                                                    "not_interested"
                                                ? Row(
                                                    children: [
                                                      Expanded(
                                                        child: MouseRegion(
                                                          cursor:
                                                              SystemMouseCursors
                                                                  .click,
                                                          child:
                                                              GestureDetector(
                                                            onTap: () async {
                                                              if (controller
                                                                      .topic
                                                                      .data
                                                                      .topicDetail
                                                                      .type
                                                                      .value ==
                                                                  "not_interested") {
                                                                controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .type
                                                                        .value =
                                                                    "nothing";
                                                                await controller.addRemoveNotInterested(
                                                                    topicId: controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .id);
                                                              }
                                                            },
                                                            child: Container(
                                                              // height: Get.height*0.1,
                                                              // width: Get.width*0.25,
                                                              decoration: BoxDecoration(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .black
                                                                      : Colors
                                                                          .white,
                                                                  border: Border.all(
                                                                      width: 1,
                                                                      color: Colors
                                                                          .grey),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              100)),
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            15,
                                                                        right:
                                                                            15,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                child: Text(
                                                                  'Not interested',
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style:
                                                                      TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  )
                                                : controller.topic.data
                                                            .topicDetail.type ==
                                                        "nothing"
                                                    ? Row(
                                                        children: [
                                                          Expanded(
                                                            child: MouseRegion(
                                                              cursor:
                                                                  SystemMouseCursors
                                                                      .click,
                                                              child:
                                                                  GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  if (controller
                                                                          .topic
                                                                          .data
                                                                          .topicDetail
                                                                          .type
                                                                          .value ==
                                                                      "nothing") {
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .type
                                                                        .value = "not_interested";
                                                                    await controller.addRemoveNotInterested(
                                                                        topicId: controller
                                                                            .topic
                                                                            .data
                                                                            .topicDetail
                                                                            .id);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  // height: Get.height*0.1,
                                                                  // width: Get.width*0.25,
                                                                  decoration: BoxDecoration(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      border: Border.all(
                                                                          width:
                                                                              1,
                                                                          color: Colors
                                                                              .grey),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100)),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            10,
                                                                        right:
                                                                            10,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                    child: Text(
                                                                      'Not interested',
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      style:
                                                                          TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize: kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 20,
                                                          ),
                                                          Expanded(
                                                            child: MouseRegion(
                                                              cursor:
                                                                  SystemMouseCursors
                                                                      .click,
                                                              child:
                                                                  GestureDetector(
                                                                onTap:
                                                                    () async {
                                                                  if (controller
                                                                          .topic
                                                                          .data
                                                                          .topicDetail
                                                                          .type
                                                                          .value ==
                                                                      "nothing") {
                                                                    controller
                                                                        .topic
                                                                        .data
                                                                        .topicDetail
                                                                        .type
                                                                        .value = "follow";
                                                                    await controller.followUnFollowTopic(
                                                                        topicId: controller
                                                                            .topic
                                                                            .data
                                                                            .topicDetail
                                                                            .id);
                                                                  }
                                                                },
                                                                child:
                                                                    Container(
                                                                  decoration: BoxDecoration(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      border: Border.all(
                                                                          width:
                                                                              1,
                                                                          color: Colors
                                                                              .grey),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100)),
                                                                  child:
                                                                      Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        left:
                                                                            15,
                                                                        right:
                                                                            15,
                                                                        top: 5,
                                                                        bottom:
                                                                            5),
                                                                    child: Text(
                                                                      Strings.follow,
                                                                      textAlign:
                                                                          TextAlign
                                                                              .center,
                                                                      // style: TextStyle(
                                                                      //     fontSize: 15,
                                                                      //     fontWeight: FontWeight
                                                                      //         .bold,
                                                                      //     color: Colors.white
                                                                      // ),
                                                                      style:
                                                                          TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize: kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      )
                                                    : SizedBox()
                                      ],
                                    );
                                  }),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ];
                  },
                  body:

                      //         CustomScrollView(
                      //           controller: controller.scrollController,
                      //             slivers: [
                      //               SliverToBoxAdapter(child: Padding(
                      //                 padding: EdgeInsets.only(top: 10, bottom: 30),
                      //                 child:       controller.topicList == null ||
                      //                     controller.topicList.isEmpty
                      //                     ? Center(child:
                      //                 Text(
                      //                   Strings.noPosts,
                      //                   style:
                      //                   TextStyle(
                      //                     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      //                     fontSize: kIsWeb ? 16 : 14,
                      //                   ),
                      //                 ),
                      //                 ):SizedBox()
                      //               ), ),
                      // ],
                      //
                      //
                      //
                      //         )

                      //     :
                      // // Text('')
                      PagedL(
                    emptyStateWidget: Text(
                      Strings.noPosts,
                      style: TextStyle(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                    ),
                    itemBuilder: _itemRow,
                    padding: EdgeInsets.only(top: 10, bottom: 30),
                    loadingIndicator: Padding(
                      padding: EdgeInsets.all(16.00),
                      child: Center(
                        child: CircularProgressIndicator(
                          color: MyColors.BlueColor,
                        ),
                      ),
                    ),
                    itemDataProvider: _fetchData,
                    list: controller.topicList,
                    listSize: _checkPage(controller.topicList.length),
                  ),

                  // CustomScrollView(
                  //     slivers: [
                  //       SliverToBoxAdapter(child: Padding(
                  //         padding: EdgeInsets.only(top: 10, bottom: 30),
                  //         child:
                  //       ), ),
                  //
                  //     ]
                  //
                  //
                  //
                  // )
                ));
    });
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    // print("fetchdata");

    return await topicController.topic_Post(
        topicId: topicController.topic.data.topicDetail.id, pageNO: page);
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = topicController.topicList.indexWhere((element) {
      return element.postId == post.postId;
    });

    // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        VisibilityDetector(
          key: Key('postCard-widget-key'),
          onVisibilityChanged: (visibilityInfo) {
            double visiblePercentage = visibilityInfo.visibleFraction * 100;
            // debugPrint(
            //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
            if (visiblePercentage > 20 &&
                post.authorId != topicController.newsfeedController.userId) {
              topicController.newsfeedController
                  .emitImpressionsSocket(post.postId);
            }
          },
          child: PostCard(
            postList: topicController.topicList,
            index: index,
            post: topicController.topicList[index],
            scaffoldKey: _scaffoldKey,
            controller: topicController.newsfeedController,
            deletePostId: 6,
            topicId: topicController.topic.data.topicDetail.id,
          ),
        ),
      ],
    );
  }
}
