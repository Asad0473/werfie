import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/colors.dart';

import '../../network/controller/topic_controller.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../web_views/web_main_screen.dart';
import 'main_topic_screen.dart';

class Topic_Tab_Screen extends StatelessWidget {
  final topicController = Get.put(TopicController());

  // final NewsfeedController newsfeedController =  Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TopicController>(builder: (controller) {
      return Scaffold(
          appBar: PreferredSize(
            preferredSize:
                kIsWeb ? Size.fromHeight(170.0) : Size.fromHeight(145.0),
            child: Container(
              // color: Colors.orange,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  kIsWeb
                      ? SizedBox(
                          height: 20,
                        )
                      : SizedBox(height: 49),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Row(
                      children: [
                        MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                            onTap: kIsWeb
                                ? () {
                                    onHomeChange = true;
                                    onBrowsChange = false;
                                    onTrendsChange = false;
                                    onBookMarksChange = false;
                                    onChatsChange = false;
                                    onProfileChange = false;
                                    onSettingChange = false;
                                    onListChange = false;
                                    onNotificationChange = false;
                                    onMoreChange = false;
                                    onMomentChange = false;

                                    controller.newsfeedController
                                        .isTrendsScreen = false;
                                    controller.newsfeedController
                                        .isNewsFeedScreen = true;
                                    controller.newsfeedController
                                        .isBrowseScreen = false;
                                    controller.newsfeedController
                                        .isNotificationScreen = false;
                                    controller.newsfeedController.isChatScreen =
                                        false;
                                    controller.newsfeedController
                                        .isSavedPostScreen = false;
                                    controller.newsfeedController
                                        .isPostDetails = false;
                                    controller.newsfeedController
                                        .isProfileScreen = false;
                                    controller.newsfeedController
                                        .isOtherUserProfileScreen = false;
                                    controller.newsfeedController
                                        .isTopicScreen = false;
                                    controller.newsfeedController.isListScreen =
                                        false;
                                    controller.newsfeedController
                                        .isMainTopicScreen = false;
                                    controller.newsfeedController.update();
                                    Get.back();
                                  }
                                : () {
                                    Navigator.pop(context);
                                  },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            ),
                          ),
                        ),
                        kIsWeb
                            ? SizedBox(
                                width: 50,
                              )
                            : SizedBox(width: 20),
                        Text(
                          Strings.topics,
                          // style: TextStyle(
                          //     fontSize: 20,
                          //     fontWeight: FontWeight.w700,
                          //     color: Colors.black
                          //
                          // ),
                          style: Styles.baseTextTheme.headline2.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                          // TextStyle(
                          //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          //   fontWeight: FontWeight.bold,
                          //   fontSize: 20,
                          // )
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Divider(),
                  Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TabButton(
                          title: Strings.followed,
                          onTap: () {
                            controller.followedTab();
                            controller.update();
                          },
                          isSelected: controller.isFollowed,
                        ),
                        TabButton(
                          title: Strings.suggested,
                          onTap: () {
                            controller.suggestedTab();
                            controller.update();
                          },
                          isSelected: controller.isSuggested,
                        ),
                        TabButton(
                          title: Strings.notInterested,
                          onTap: () {
                            controller.notIntrestedTab();
                            controller.update();
                          },
                          isSelected: controller.isNotIntrested,
                        ),
                      ],
                    ),
                  ),
                  Divider(),
                ],
              ),
            ),
          ),
          body: controller.isLoading == true
              ? Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                )
              : CustomScrollView(
                  controller: ScrollController(),
                  slivers: [
                    controller.isFollowed == true
                        ? SliverToBoxAdapter(
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Text(
                                    Strings.theTopicsYouFollow,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 14 : 12,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ?
                                    // TextStyle(color: Colors.white,  fontWeight: FontWeight.bold,
                                    // )
                                    //     : TextStyle(color: Colors.black, fontWeight: FontWeight.bold,
                                    // ),
                                  ),
                                ),
                                Divider(),
                              ],
                            ),
                          )
                        : controller.isSuggested == true
                            ? SliverToBoxAdapter(
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 10, bottom: 10),
                                  child: Text(Strings.suggestedTopics,
                                      // style: TextStyle(
                                      //   fontSize: 20,
                                      //   fontWeight: FontWeight.bold,
                                      //   color: Colors.black,
                                      // ),
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.bold,
                                      )
                                      // Theme.of(context).brightness == Brightness.dark ?
                                      // TextStyle(color: Colors.white,fontSize: 20,  fontWeight: FontWeight.bold,
                                      // )
                                      //     : TextStyle(color: Colors.black,fontSize: 20,  fontWeight: FontWeight.bold,
                                      // ),
                                      ),
                                ),
                              )
                            :

                            ///notInterestedFOllowList
                            controller.isNotIntrested == true
                                ? SliverList(
                                    delegate: SliverChildBuilderDelegate(
                                      (BuildContext context, int index) {
                                        return controller.notInterestedTopic ==
                                                null
                                            ? Center(
                                                child: Text(
                                                  Strings.nothingToSeeHere,
                                                  style: Styles
                                                      .baseTextTheme.headline2
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 16 : 14,
                                                  ),
                                                  // Theme.of(context).brightness == Brightness.dark ?
                                                  // TextStyle(color: Colors.white,fontSize: 30,  fontWeight: FontWeight.bold,
                                                  // )
                                                  //     : TextStyle(color: Colors.black,fontSize: 30,  fontWeight: FontWeight.bold,
                                                  // ),
                                                ),
                                              )
                                            : InkWell(
                                                onTap: kIsWeb
                                                    ? () async {
                                                        /* controller.newsfeedController.isTrendsScreen =
                              false;
                              controller.newsfeedController.isNewsFeedScreen =
                              false;
                              controller.newsfeedController.isBrowseScreen =
                              false;
                              controller.newsfeedController
                                  .isNotificationScreen = false;
                              controller.newsfeedController.isChatScreen =
                              false;
                              controller.newsfeedController.isSavedPostScreen =
                              false;
                              controller.newsfeedController.isPostDetails =
                              false;
                              controller.newsfeedController.isProfileScreen =
                              false;
                              controller.newsfeedController
                                  .isOtherUserProfileScreen = false;
                              controller.newsfeedController.isTopicScreen =
                              false;
                              controller.newsfeedController.isListScreen =
                              false;
                              controller.newsfeedController.isMainTopicScreen =
                              true;
                              controller.newsfeedController.update();


                              topicController.screenCheck =1;
                              topicController.update();

                              await controller.topicPost(topicId: controller.notInterestedTopic.data[index].id, pageNO: 1);
                          */
                                                        Get.toNamed(FluroRouters
                                                                .mainScreen +
                                                            "/mainTopics/" +
                                                            index.toString());
                                                      }
                                                    : () async {
                                                        topicController
                                                            .screenCheck = 1;
                                                        topicController
                                                            .update();

                                                        Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                              builder: (context) =>
                                                                  MainTopicScreen()),
                                                        );

                                                        await controller.topicPost(
                                                            topicId: controller
                                                                .notInterestedTopic
                                                                .data[index]
                                                                .id,
                                                            pageNO: 1);
                                                      },
                                                child: ListTile(
                                                  mouseCursor:
                                                      MouseCursor.defer,
                                                  leading: GestureDetector(
                                                    child: CircleAvatar(
                                                      backgroundColor: controller
                                                          .newsfeedController
                                                          .displayColor,
                                                      radius: 20,
                                                      child: Icon(
                                                        Icons.topic,
                                                        size: 25,
                                                        color: Colors.white,
                                                      ),
                                                    ),
                                                  ),
                                                  title: Text(
                                                    controller
                                                        .notInterestedTopic
                                                        .data[index]
                                                        .topic,
                                                    style: Styles
                                                        .baseTextTheme.headline5
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    // TextStyle(
                                                    //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //   fontWeight: FontWeight.bold,
                                                    // ),
                                                  ),
                                                  // subtitle: Text('Here is a second line'),
                                                  trailing: Obx(() {
                                                    return InkWell(
                                                      onTap: () async {
                                                        if (controller
                                                                .notInterestedTopic
                                                                .data[index]
                                                                .isFollow
                                                                .value ==
                                                            false) {
                                                          controller
                                                              .notInterestedTopic
                                                              .data[index]
                                                              .isFollow
                                                              .value = true;

                                                          await controller
                                                              .followUnFollowTopic(
                                                                  topicId: controller
                                                                      .notInterestedTopic
                                                                      .data[
                                                                          index]
                                                                      .id);
                                                        } else if (controller
                                                                .notInterestedTopic
                                                                .data[index]
                                                                .isFollow
                                                                .value ==
                                                            true) {
                                                          controller
                                                              .notInterestedTopic
                                                              .data[index]
                                                              .isFollow
                                                              .value = false;

                                                          await controller
                                                              .followUnFollowTopic(
                                                                  topicId: controller
                                                                      .notInterestedTopic
                                                                      .data[
                                                                          index]
                                                                      .id);
                                                        }
                                                      },
                                                      child: controller
                                                                  .notInterestedTopic
                                                                  .data[index]
                                                                  .isFollow
                                                                  .value ==
                                                              false
                                                          ? Container(
                                                              // height: Get.height*0.1,
                                                              // width: Get.width*0.25,
                                                              decoration:
                                                                  BoxDecoration(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      border: Border.all(
                                                                          width:
                                                                              1,
                                                                          color: controller.followingAndSuggestedTopics.data.followingTopics[index].isHoverFollow.value == false
                                                                              ? Colors
                                                                                  .grey
                                                                              : Colors
                                                                                  .red),
                                                                      // border: Border.all(
                                                                      //     width: 1,
                                                                      //     color: Colors.grey
                                                                      // ),
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              100)),
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left: 8,
                                                                        right:
                                                                            8,
                                                                        top: 4,
                                                                        bottom:
                                                                            4),
                                                                child: Text(
                                                                  Strings.following,
                                                                  style:
                                                                      TextStyle(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                              ),
                                                            )
                                                          : Container(
                                                              decoration: BoxDecoration(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              100)),
                                                              child: Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        left: 8,
                                                                        right:
                                                                            8,
                                                                        top: 4,
                                                                        bottom:
                                                                            4),
                                                                child: Text(
                                                                    Strings.follow,
                                                                    // style: TextStyle(
                                                                    //     fontSize: 15,
                                                                    //     fontWeight: FontWeight.w600,
                                                                    //     color: Colors.white
                                                                    // ),
                                                                    style:
                                                                        TextStyle(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .black
                                                                          : Colors
                                                                              .white,
                                                                      fontSize:
                                                                          kIsWeb
                                                                              ? 14
                                                                              : 14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    )),
                                                              ),
                                                            ),
                                                    );
                                                  }),
                                                ),
                                              );
                                      },
                                      childCount:
                                          controller.notInterestedTopic == null
                                              ? 1
                                              : controller.notInterestedTopic
                                                  .data.length,
                                    ),
                                  )
                                : SliverToBoxAdapter(
                                    child: Container(),
                                  ),

                    ///
                    ///
                    /// followingslist
                    controller.isFollowed == true
                        ? SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (BuildContext context, int index) {
                                return controller.followingAndSuggestedTopics
                                        .data.followingTopics.isEmpty
                                    ? SizedBox()
                                    : InkWell(
                                        onTap: kIsWeb
                                            ? () async {
                                                if (controller
                                                        .followingAndSuggestedTopics
                                                        .data
                                                        .followingTopics[index]
                                                        .isFollow
                                                        .value ==
                                                    true) {
                                                  Fluttertoast.showToast(
                                                      msg:
                                                          "Your are not Follow this Topic",
                                                      toastLength:
                                                          Toast.LENGTH_SHORT,
                                                      gravity:
                                                          ToastGravity.CENTER,
                                                      timeInSecForIosWeb: 1,
                                                      backgroundColor:
                                                          Colors.red,
                                                      textColor: Colors.white,
                                                      fontSize: 16.0);
                                                } else {
                                                  Get.toNamed(
                                                      FluroRouters.mainScreen +
                                                          "/mainTopics/" +
                                                          index.toString());
                                                  // controller.newsfeedController.isTrendsScreen =
                                                  // false;
                                                  // controller.newsfeedController.isNewsFeedScreen =
                                                  // false;
                                                  // controller.newsfeedController.isBrowseScreen =
                                                  // false;
                                                  // controller.newsfeedController
                                                  //     .isNotificationScreen = false;
                                                  // controller.newsfeedController.isChatScreen =
                                                  // false;
                                                  // controller.newsfeedController.isSavedPostScreen =
                                                  // false;
                                                  // controller.newsfeedController.isPostDetails =
                                                  // false;
                                                  // controller.newsfeedController.isProfileScreen =
                                                  // false;
                                                  // controller.newsfeedController
                                                  //     .isOtherUserProfileScreen = false;
                                                  // controller.newsfeedController.isTopicScreen =
                                                  // false;
                                                  // controller.newsfeedController.isListScreen =
                                                  // false;
                                                  // controller.newsfeedController.isMainTopicScreen =
                                                  // true;
                                                  //
                                                  // controller.newsfeedController.update();
                                                  topicController.screenCheck =
                                                      2;
                                                  topicController.update();

                                                  await controller.topicPost(
                                                      topicId: controller
                                                          .followingAndSuggestedTopics
                                                          .data
                                                          .followingTopics[
                                                              index]
                                                          .id,
                                                      pageNO: 1);
                                                }
                                              }
                                            : () async {
                                                if (controller
                                                        .followingAndSuggestedTopics
                                                        .data
                                                        .followingTopics[index]
                                                        .isFollow
                                                        .value ==
                                                    true) {
                                                  Fluttertoast.showToast(
                                                      msg:
                                                          "Your are not Follow this Topic",
                                                      toastLength:
                                                          Toast.LENGTH_SHORT,
                                                      gravity:
                                                          ToastGravity.CENTER,
                                                      timeInSecForIosWeb: 1,
                                                      backgroundColor:
                                                          Colors.red,
                                                      textColor: Colors.white,
                                                      fontSize: 16.0);
                                                } else {
                                                  topicController.screenCheck =
                                                      2;
                                                  topicController.update();
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            MainTopicScreen()),
                                                  );

                                                  await controller.topicPost(
                                                      topicId: controller
                                                          .followingAndSuggestedTopics
                                                          .data
                                                          .followingTopics[
                                                              index]
                                                          .id,
                                                      pageNO: 1);
                                                }
                                              },
                                        child: ListTile(
                                          mouseCursor: MouseCursor.defer,
                                          leading: GestureDetector(
                                            child: CircleAvatar(
                                              backgroundColor: controller
                                                  .newsfeedController
                                                  .displayColor,
                                              radius: 20,
                                              child: Icon(
                                                Icons.topic,
                                                size: 25,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                          title: Text(
                                            controller
                                                .followingAndSuggestedTopics
                                                .data
                                                .followingTopics[index]
                                                .topic,
                                            style: Styles
                                                .baseTextTheme.headline5
                                                .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            // Theme.of(context).brightness == Brightness.dark ?
                                            // TextStyle(color: Colors.white,  fontWeight: FontWeight.bold,
                                            // )
                                            //     : TextStyle(color: Colors.black,  fontWeight: FontWeight.bold,
                                            // ),
                                          ),
                                          // subtitle: Text('Here is a second line'),
                                          trailing: Obx(() {
                                            return InkWell(
                                              onHover: (bool value) {
                                                // print("hello");
                                                if (controller
                                                            .followingAndSuggestedTopics
                                                            .data
                                                            .followingTopics[
                                                                index]
                                                            .isFollow
                                                            .value ==
                                                        false &&
                                                    value == true) {
                                                  controller
                                                      .followingAndSuggestedTopics
                                                      .data
                                                      .followingTopics[index]
                                                      .isHoverFollow
                                                      .value = true;

                                                  // print("hellox");
                                                  // print( controller.isFollow.value);
                                                } else {
                                                  // print("helloxss");
                                                  controller
                                                      .followingAndSuggestedTopics
                                                      .data
                                                      .followingTopics[index]
                                                      .isHoverFollow
                                                      .value = false;
                                                  // controller.isFollow.value = false;
                                                  // print( controller.isFollow.value);
                                                }
                                              },
                                              onTap: () async {
                                                if (controller
                                                        .followingAndSuggestedTopics
                                                        .data
                                                        .followingTopics[index]
                                                        .isFollow
                                                        .value ==
                                                    false) {
                                                  controller
                                                      .followingAndSuggestedTopics
                                                      .data
                                                      .followingTopics[index]
                                                      .isFollow
                                                      .value = true;

                                                  await controller
                                                      .followUnFollowTopic(
                                                          topicId: controller
                                                              .followingAndSuggestedTopics
                                                              .data
                                                              .followingTopics[
                                                                  index]
                                                              .id);
                                                } else if (controller
                                                        .followingAndSuggestedTopics
                                                        .data
                                                        .followingTopics[index]
                                                        .isFollow
                                                        .value ==
                                                    true) {
                                                  controller
                                                      .followingAndSuggestedTopics
                                                      .data
                                                      .followingTopics[index]
                                                      .isFollow
                                                      .value = false;

                                                  await controller
                                                      .followUnFollowTopic(
                                                          topicId: controller
                                                              .followingAndSuggestedTopics
                                                              .data
                                                              .followingTopics[
                                                                  index]
                                                              .id);
                                                }
                                              },
                                              child: controller
                                                          .followingAndSuggestedTopics
                                                          .data
                                                          .followingTopics[
                                                              index]
                                                          .isFollow
                                                          .value ==
                                                      false
                                                  ? Container(
                                                      // height: Get.height*0.1,
                                                      // width: Get.width*0.25,
                                                      decoration: BoxDecoration(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.black
                                                              : Colors.white,
                                                          border: Border.all(
                                                              width: 1,
                                                              color: controller
                                                                          .followingAndSuggestedTopics
                                                                          .data
                                                                          .followingTopics[
                                                                              index]
                                                                          .isHoverFollow
                                                                          .value ==
                                                                      false
                                                                  ? Colors.grey
                                                                  : Colors.red),
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      100)),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                left: 15,
                                                                right: 15,
                                                                top: 5,
                                                                bottom: 5),
                                                        child: controller
                                                                    .followingAndSuggestedTopics
                                                                    .data
                                                                    .followingTopics[
                                                                        index]
                                                                    .isHoverFollow
                                                                    .value ==
                                                                false
                                                            ? Text(
                                                          Strings.following,
                                                                style:
                                                                    TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontSize:
                                                                      kIsWeb
                                                                          ? 14
                                                                          : 14,
                                                                ),
                                                              )
                                                            : Text(
                                                                'UnFollow',
                                                                style:
                                                                    TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                  color: Colors
                                                                      .redAccent,
                                                                  fontSize:
                                                                      kIsWeb
                                                                          ? 14
                                                                          : 14,
                                                                ),
                                                              ),
                                                      ),
                                                    )
                                                  : Container(
                                                      decoration: BoxDecoration(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      100)),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                left: 8,
                                                                right: 8,
                                                                top: 4,
                                                                bottom: 4),
                                                        child: Text(
                                                          Strings.follow,
                                                          // style: TextStyle(
                                                          //     fontSize: 15,
                                                          //     fontWeight: FontWeight.w600,
                                                          //     color: Colors.white
                                                          // ),
                                                          // style: Theme.of(context).brightness == Brightness.dark ?
                                                          // TextStyle(color: Colors.white,fontSize: 15,  fontWeight: FontWeight.w600,
                                                          // )
                                                          //     : TextStyle(color: Colors.black,fontSize: 15,  fontWeight: FontWeight.w600,
                                                          // ),
                                                          style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.black
                                                                : Colors.white,
                                                            fontSize: kIsWeb
                                                                ? 14
                                                                : 14,
                                                          ),
                                                          // TextStyle(
                                                          //     color: Colors.white,
                                                          //     fontSize: 14,
                                                          //     fontWeight: FontWeight.w500
                                                          // ),
                                                        ),
                                                      ),
                                                    ),
                                            );
                                          }),
                                        ),
                                      );
                              },
                              childCount: controller.followingAndSuggestedTopics
                                      .data.followingTopics.isEmpty
                                  ? 0
                                  : controller.followingAndSuggestedTopics.data
                                      .followingTopics.length,
                            ),
                          )
                        : controller.isSuggested == true
                            ? controller.followingAndSuggestedTopics.data
                                    .suggestedTopics.isEmpty
                                ? SliverToBoxAdapter(
                                    child: Container(),
                                  )
                                : SliverGrid(
                                    gridDelegate:
                                        const SliverGridDelegateWithMaxCrossAxisExtent(
                                      maxCrossAxisExtent: kIsWeb ? 290.0 : 390,
                                      mainAxisExtent: 50,
                                      mainAxisSpacing: 10.0,
                                      crossAxisSpacing: 10.0,
                                      childAspectRatio: 4.0,
                                    ),
                                    delegate: SliverChildBuilderDelegate(
                                      (BuildContext context, int index) {
                                        // print("a");
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 15),
                                          child: SuggestedListWidget(
                                            title: controller
                                                .followingAndSuggestedTopics
                                                .data
                                                .suggestedTopics[index]
                                                .topic,
                                            topicController: controller,
                                            index: index,
                                          ),
                                        );

                                        //   Container(
                                        //   alignment: Alignment.center,
                                        //   color: Colors.teal[100 * (index % 9)],
                                        //   child: Text('Grid Item $index'),
                                        // );
                                      },
                                      childCount: controller
                                              .followingAndSuggestedTopics
                                              .data
                                              .suggestedTopics
                                              .isEmpty
                                          ? 0
                                          : controller
                                              .followingAndSuggestedTopics
                                              .data
                                              .suggestedTopics
                                              .length,
                                    ),
                                  )
                            : controller.isFollowed == true
                                ? SliverToBoxAdapter(
                                    child: controller
                                            .followingAndSuggestedTopics
                                            .data
                                            .followingTopics
                                            .isEmpty
                                        ? SizedBox()
                                        : Divider(),
                                  )
                                : controller.isSuggested == true
                                    ? SliverToBoxAdapter(
                                        child: Divider(),
                                      )
                                    : SliverToBoxAdapter(
                                        child: Container(),
                                      ),

                    ///
                    controller.isFollowed == true
                        ? SliverToBoxAdapter(
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 15),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    Strings.suggestedTopics,
                                    // style: Get.textTheme.headline4.copyWith(
                                    //     color: Colors.black,
                                    //     fontWeight: FontWeight.bold,
                                    //     fontSize: 18
                                    // ),
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ?
                                    // TextStyle(color: Colors.white,fontSize: 18,  fontWeight: FontWeight.bold,
                                    // )
                                    //     : TextStyle(color: Colors.grey.shade700,fontSize: 18,  fontWeight: FontWeight.bold,
                                    // ),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    Strings.youllSeeTopWerfs,

                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 14 : 12,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ?
                                    // TextStyle(color: Colors.white, fontWeight: FontWeight.bold,
                                    // )
                                    //     : TextStyle(color: Colors.grey.shade700,  fontWeight: FontWeight.bold,
                                    // ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                ],
                              ),
                            ),
                          )
                        : controller.isSuggested == true
                            ? SliverToBoxAdapter(
                                child: SizedBox(
                                  height: 50,
                                ),
                              )
                            : SliverToBoxAdapter(
                                child: Container(),
                              ),
                    controller.isFollowed == true
                        ? SliverToBoxAdapter(
                            child: Column(
                            children: [
                              SizedBox(
                                height: 20,
                              )
                            ],
                          ))
                        : SliverToBoxAdapter(
                            child: Container(),
                          ),

                    ///followedSuggestedList
                    controller.isFollowed == true
                        ? controller.followingAndSuggestedTopics.data
                                .suggestedTopics.isEmpty
                            ? SliverToBoxAdapter(
                                child: Container(),
                              )
                            : SliverGrid(
                                gridDelegate:
                                    const SliverGridDelegateWithMaxCrossAxisExtent(
                                  maxCrossAxisExtent: kIsWeb ? 290.0 : 380,
                                  mainAxisExtent: 50,
                                  mainAxisSpacing: 10.0,
                                  crossAxisSpacing: 10.0,
                                  childAspectRatio: 4.0,
                                ),
                                delegate: SliverChildBuilderDelegate(
                                  (BuildContext context, int index) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: SuggestedListWidget(
                                        title: controller
                                            .followingAndSuggestedTopics
                                            .data
                                            .suggestedTopics[index]
                                            .topic,
                                        topicController: controller,
                                        index: index,
                                      ),
                                    );
                                  },
                                  childCount: controller
                                          .followingAndSuggestedTopics
                                          .data
                                          .suggestedTopics
                                          .isEmpty
                                      ? 0
                                      : controller.followingAndSuggestedTopics
                                          .data.suggestedTopics.length,
                                ),
                              )
                        : SliverToBoxAdapter(
                            child: Container(),
                          ),

                    ///
                    controller.isFollowed == true
                        ? SliverToBoxAdapter(
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 15),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Divider(),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Divider(),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    Strings.topicsThatYouFollowShownHere,

                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 14 : 12,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ?
                                    // TextStyle(color: Colors.white,  fontWeight: FontWeight.bold,
                                    // )
                                    //     : TextStyle(color: Colors.black,  fontWeight: FontWeight.bold,
                                    // ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                ],
                              ),
                            ),
                          )
                        : SliverToBoxAdapter(
                            child: Container(),
                          ),
                  ],
                ));
    });
  }
}

// class CategoriesListWidget extends StatelessWidget {
//   CategoriesListWidget({
//     this.title,
//     this.controller,
//     this.topicController,
//     this.index
//   });
//
//   String title;
//   NewsfeedController controller;
//   TopicController topicController;
//   int index;
//
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: kIsWeb ? ()async {
//         controller.isTrendsScreen = false;
//         controller.isNewsFeedScreen = false;
//         controller.isBrowseScreen = false;
//         controller.isNotificationScreen = false;
//         controller.isChatScreen = false;
//         controller.isSavedPostScreen = false;
//         controller.isPostDetails = false;
//         controller.isProfileScreen = false;
//         controller.isOtherUserProfileScreen = false;
//         controller.isTopicScreen = false;
//         controller.isListScreen = false;
//         controller.isMainTopicScreen = true;
//         controller.update();
//
//
//
//
//
//
//
//         print("asadasd");
//         print("topicController.followingAndSuggestedTopics.data.suggestedTopics[index].id  ${topicController.followingAndSuggestedTopics.data.suggestedTopics[index].id}");
//
//         await topicController.topicPost(topicId: topicController.followingAndSuggestedTopics.data.suggestedTopics[index].id, pageNO: 1);
//
//
//       } : () async{
//         Navigator.push(
//           context, MaterialPageRoute(builder: (context) => MainTopicScreen()),);
//
//         await topicController.topicPost(topicId: topicController.followingAndSuggestedTopics.data.suggestedTopics[index].id, pageNO: 1);
//       }
//
//       ,
//       child: Container(
//         // height: 50,
//         width: title.removeAllWhitespace.length * 10.toDouble(),
//         decoration: BoxDecoration(
//             color: Colors.blue,
//             border: Border.all(width: 1,
//                 color: Colors.white
//             ),
//             borderRadius: BorderRadius.circular(15)
//
//         ),
//         child: Center(
//           child: Text(title,
//             textAlign: TextAlign.center,
//             style: Get.textTheme.bodyText1.copyWith(
//               color: Colors.white,
//               fontSize: 20,
//               fontWeight: FontWeight.w600,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

class SuggestedListWidget extends StatelessWidget {
  SuggestedListWidget({
    this.title,
    this.topicController,
    this.index,
  });

  String title;
  int index;
  TopicController topicController;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
          onTap: () async {
            if (topicController.followingAndSuggestedTopics.data
                    .suggestedTopics[index].type.value ==
                0) {
              topicController.followingAndSuggestedTopics.data
                  .suggestedTopics[index].type.value = 1;

              await topicController.followUnFollowTopic(
                  topicId: topicController.followingAndSuggestedTopics.data
                      .suggestedTopics[index].id);
            } else if (topicController.followingAndSuggestedTopics.data
                    .suggestedTopics[index].type.value ==
                1) {
              topicController.followingAndSuggestedTopics.data
                  .suggestedTopics[index].type.value = 0;

              await topicController.followUnFollowTopic(
                  topicId: topicController.followingAndSuggestedTopics.data
                      .suggestedTopics[index].id);
            }
          },
          child: topicController.followingAndSuggestedTopics.data
                      .suggestedTopics[index].type.value ==
                  0
              ? Container(
                  // height: 50,
                  width: title.removeAllWhitespace.length * 10.toDouble(),
                  decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                      border: Border.all(width: 1, color: Colors.grey),
                      borderRadius: BorderRadius.circular(100)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Center(
                          child: Container(
                            width: kIsWeb ? 120 : 80,
                            child: Text(
                              title,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              // style: Get.textTheme.bodyText1.copyWith(
                              //   color: Colors.black,
                              //   fontSize:kIsWeb? 15:12,
                              //   fontWeight: FontWeight.w600,
                              // ),
                              style: Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: kIsWeb ? 14 : 14,
                                fontWeight: FontWeight.bold,
                              ),
                              // TextStyle(
                              //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                              //   fontWeight: FontWeight.w600,
                              //   fontSize: 14,
                              // ),
                            ),
                          ),
                        ),
                        Icon(
                          Icons.add,
                          size: 20,
                          color:
                              topicController.newsfeedController.displayColor,
                        ),
                        Container(
                          height: 30,
                          width: 1,
                          color: Colors.grey,
                        ),
                        InkWell(
                          onTap: () async {
                            Fluttertoast.showToast(
                                msg: Strings.weWontSuggestThisTopic,
                                toastLength: Toast.LENGTH_SHORT,
                                gravity: ToastGravity.CENTER,
                                timeInSecForIosWeb: 1,
                                backgroundColor: Colors.red,
                                textColor: Colors.white,
                                fontSize: 16.0);
                            topicController.followingAndSuggestedTopics.data
                                .suggestedTopics[index].type.value = 2;
                            await topicController.addRemoveNotInterested(
                                topicId: topicController
                                    .followingAndSuggestedTopics
                                    .data
                                    .suggestedTopics[index]
                                    .id);
                          },
                          child: Icon(
                            Icons.clear,
                            size: 20,
                            color: Colors.grey,
                          ),
                        )
                      ],
                    ),
                  ),
                )
              : topicController.followingAndSuggestedTopics.data
                          .suggestedTopics[index].type.value ==
                      1
                  ? Container(
                      // height: 50,
                      width: title.removeAllWhitespace.length * 10.toDouble(),
                      decoration: BoxDecoration(
                          color:
                              topicController.newsfeedController.displayColor,
                          borderRadius: BorderRadius.circular(100)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Center(
                              child: Container(
                                width: kIsWeb ? 120 : 100,
                                child: Text(
                                  title,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  // style: Get.textTheme.bodyText1.copyWith(
                                  //   color: Colors.white,
                                  //   fontSize: 15,
                                  //   fontWeight: FontWeight.w600,
                                  // ),
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Colors.white,
                                    fontSize: kIsWeb ? 14 : 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  // TextStyle(color: Colors.white,
                                  //   fontWeight: FontWeight.w600,  fontSize: 15,
                                  // )
                                ),
                              ),
                            ),
                            Icon(
                              Icons.check,
                              size: 20,
                              color: Colors.white,
                            )
                          ],
                        ),
                      ),
                    )
                  : Container(
                      // height: 50,
                      width: title.removeAllWhitespace.length * 10.toDouble(),
                      decoration: BoxDecoration(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white,
                          border: Border.all(
                            width: 1,
                            color: Colors.grey.withOpacity(0.5),
                          ),
                          borderRadius: BorderRadius.circular(100)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Center(
                              child: Container(
                                width: kIsWeb ? 120 : 80,
                                child: Text(
                                  title,
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 1,
                                  // style: Get.textTheme.bodyText1.copyWith(
                                  //   color: Colors.grey.withOpacity(0.5),
                                  //   fontSize: 15,
                                  //   fontWeight: FontWeight.w600,
                                  // ),
                                  style:
                                      Styles.baseTextTheme.headline2.copyWith(
                                    fontWeight: FontWeight.bold,
                                    fontSize: kIsWeb ? 14 : 14,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
        ),
      );
    });
  }
}

class TabButton extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  const TabButton({this.title, this.isSelected, this.onTap});

  @override
  Widget build(BuildContext context) {
    NewsfeedController newsfeedController = Get.put((NewsfeedController()));
    return MaterialButton(
      onPressed: onTap,
      child: Column(
        children: [
          isSelected
              ? FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 16 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    //   fontWeight: FontWeight.bold,
                    //   fontSize: kIsWeb ? 18 : 16,
                    // ),
                    maxLines: 1,
                  ),
                )
              : FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 16 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                    //   fontSize: kIsWeb ? 18 : 16,
                    //   fontWeight: FontWeight.bold,
                    // ),
                    maxLines: 1,
                  ),
                ),
          SizedBox(
            height: 10,
          ),
          isSelected
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    //color: MyColors.yellow,
                    color: newsfeedController.displayColor,
                  ),
                  height: 3,
                  width: title.length * 8.toDouble(),
                )
              : SizedBox(),
        ],
      ),
    );
  }
}
