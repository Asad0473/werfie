import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/strings.dart';

import '../utils/font.dart';

class RegistrationSuccessful extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          child: Image.asset(
            AppImages.logo,
            // width: 180,
            // height: 150,
            // color: Color((0xFF47b867)),
          ),
          // Image.asset('assets/images/Logo_werfie.png'),
        ),
        SizedBox(height: 20),
        Text(
          Strings.success,
          style: Styles.baseTextTheme.headline2.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: kIsWeb ? 20 : 18,
          ),
          // style: TextStyle(
          //     color: Colors.green, fontSize: 32, fontWeight: FontWeight.bold),
        ),
        Text(
          Strings
              .thankYouForCreatingYourAccountWithBuzznBeeOurTeamWillContactYouWithIn24OursStaySafe,
          // style: TextStyle(fontSize: 17),
          style: Styles.baseTextTheme.headline4.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontSize: kIsWeb ? 14 : 12,
          ),
        ),
        TextButton(
          onPressed: () {},
          child: Text(
            Strings.goBackToHomePage,
            // style: TextStyle(
            //   color: Color(0xFFedab30),
            // ),
            style: Theme.of(context).brightness == Brightness.dark
                ? TextStyle(color: Colors.green, fontWeight: FontWeight.bold)
                : TextStyle(
                    color: Color(0xFFedab30), fontWeight: FontWeight.bold),
          ),
        )
      ],
    );
  }
}
