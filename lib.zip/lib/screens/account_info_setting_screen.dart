import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/password_screen.dart';
import 'package:werfieapp/screens/select_country_screen.dart';
import 'package:werfieapp/screens/username_setting_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../network/controller/profile_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import '../widgets/verification.dart';

// ignore: must_be_immutable
class accountInformationSettingScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  ProfileController profileController = Get.put(ProfileController());

  TextEditingController username = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    centerTitle: true,
                    title: Text(
                      Strings.accountInformation,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 20,
                      ),
                      // TextStyle(
                      //     color: Colors.white,
                      //     fontSize: 18,
                      //     fontWeight: FontWeight.w700
                      // ),
                      // style: Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 18,
                      //   fontWeight: FontWeight.w700,
                      //   color: Colors.black,
                      // ),
                    ),
                    leading: !kIsWeb
                        ? MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                                onTap: () {
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isTranslations = false;
                                  controller.isLanguageSettings = true;
                                  controller.isLanguageType = false;
                                  controller.isListOfBlockedAccounts = false;
                                  if (!kIsWeb) {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    Navigator.of(context).pop();
                                  }
                                  controller.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                          )
                        : SizedBox(),
                  )
                : PreferredSize(
                    child: Container(),
                    preferredSize: Size(0, 0),
                  ),
            body: Get.find<ProfileController>().userProfile == null
                ? Center(
                    child: CircularProgressIndicator(),
                  )
                : Padding(
                    padding: const EdgeInsets.only(left: 10, top: 20),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          kIsWeb
                              ? Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 8.0,
                                    horizontal: 12,
                                  ),
                                  child: Row(
                                    children: [
                                      // MediaQuery.of(context).size.width >= 1050
                                      //     ? SizedBox()
                                      //     :
                                      MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () {
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isTranslations = false;
                                            controller.isLanguageSettings =
                                                false;
                                            controller.isSettingDetail = false;
                                            controller.isSettingTypeDetail =
                                                false;
                                            controller.isLanguageType = false;
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isChangeUserName = false;
                                            controller.isAccountInformation =
                                                false;
                                            controller.isYourAccount = true;

                                            controller.update();
                                          },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                            Strings.accountInformation,
                                            textAlign: TextAlign.left,
                                            style: Styles
                                                .baseTextTheme.headline1
                                                .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                            // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                            //     fontSize: 18,fontWeight: FontWeight.w700
                                            // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                            //),
                                            // style: Theme.of(context)
                                            //     .textTheme
                                            //     .headline6
                                            //     .copyWith(
                                            //       fontSize: 18,
                                            //       fontWeight: FontWeight.w700,
                                            //       color: Colors.black,
                                            //     ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : Container(),
                          kIsWeb
                              ? Container(
                                  height: 1,
                                  color: Colors.grey[300],
                                )
                              : SizedBox(),
                          ListTile(
                            onTap: () {
                              controller.isListOfBlockedAccounts = false;
                              controller.isTranslations = false;
                              controller.isLanguageSettings = false;
                              controller.isLanguageType = false;
                              controller.isAccountPrivacy = false;
                              controller.isProfileLanguagetype = false;
                              controller.isAccountPrivacySettings = false;
                              controller.isAccountInformation = false;
                              controller.isChangeUserName = true;
                              controller.isSettingDetail = false;
                              controller.isSettingTypeDetail = true;

                              controller.update();
                              !kIsWeb
                                  ? Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              UserNameSettingScreen()))
                                  : Container();
                            },
                            title: kIsWeb
                                ? Text(
                                    Strings.username,
                                    style: TextStyle(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 16 : 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    // Styles.baseTextTheme.headline1.copyWith(
                                    //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //    fontSize: kIsWeb ? 16 : 14,
                                    //   fontWeight:FontWeight.w600,
                                    // ),
                                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                    //     fontWeight: FontWeight.w500
                                    // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                    //
                                    //
                                    // ),
                                  )
                                : Text(
                                    Strings.username,
                                    style:
                                        Styles.baseTextTheme.headline3.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 20,
                                    ),
                                  ),
                            subtitle: Get.find<ProfileController>()
                                        .userProfile ==
                                    null
                                ? Text(
                                    "- - -",
                                    style:
                                        Styles.baseTextTheme.bodyText1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  )
                                : Get.isRegistered<ProfileController>()
                                    ? Text(
                                        "@${Get.find<ProfileController>().userProfile.username}",
                                        style: Styles.baseTextTheme.bodyText1
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : kIsWeb
                                                  ? Colors.black
                                                      .withOpacity(0.5)
                                                  : Colors.black,
                                        ),
                                      )
                                    : Text(
                                        "@${controller.userName}",
                                        style: Styles.baseTextTheme.bodyText1
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : kIsWeb
                                                  ? Colors.black
                                                      .withOpacity(0.5)
                                                  : Colors.black,
                                        ),
                                      ),
                            trailing: kIsWeb
                                ? Icon(Icons.arrow_forward_ios,
                                    size: 20,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.black)
                                : null,
                          ),
                          ListTile(
                            onTap: () {
                              controller.isListOfBlockedAccounts = false;
                              controller.isTranslations = false;
                              controller.isLanguageSettings = false;
                              controller.isLanguageType = false;
                              controller.isAccountPrivacy = false;
                              controller.isProfileLanguagetype = false;
                              controller.isAccountPrivacySettings = false;
                              controller.isChangeUserName = false;
                              controller.isSettingDetail = false;
                              controller.isSettingTypeDetail = false;
                              controller.isAccountInformation = false;
                              controller.isChangeEmail = true;

                              controller.update();
                              !kIsWeb
                                  ? Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              passwordScreen()))
                                  : Container();
                            },
                            title: kIsWeb
                                ? Text(
                              Get.find<ProfileController>().userProfile.email != null && Get.find<ProfileController>().userProfile.email.isNotEmpty ?
                              Strings.email : Strings.phone,
                                    style: TextStyle(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 16 : 14,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    // Styles.baseTextTheme.headline1.copyWith(
                                    //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //    fontSize: kIsWeb ? 16 : 14,
                                    //   fontWeight:FontWeight.w600,
                                    // ),
                                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                    //     fontWeight: FontWeight.w500
                                    // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                    //
                                    //
                                    // ),
                                  )
                                : Text(
                                Get.find<ProfileController>().userProfile.email != null && Get.find<ProfileController>().userProfile.email.isNotEmpty ?
                                Strings.email : Strings.phone,
                                    style:
                                        Styles.baseTextTheme.headline3.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 20,
                                    ),
                                  ),
                            subtitle: Get.isRegistered<ProfileController>()
                                ? Text(
                                Get.find<ProfileController>().userProfile.email != null && Get.find<ProfileController>().userProfile.email.isNotEmpty ? "${Get.find<ProfileController>().userProfile.email}" :
                                "${Get.find<ProfileController>().userProfile.phone}",
                                    style:
                                        Styles.baseTextTheme.bodyText1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : kIsWeb
                                              ? Colors.black.withOpacity(0.5)
                                              : Colors.black,
                                    ),
                                  )
                                : Text(
                                    "${controller.email}" ,
                                    style:
                                        Styles.baseTextTheme.bodyText1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : kIsWeb
                                              ? Colors.black.withOpacity(0.5)
                                              : Colors.black,
                                    ),
                                  ),
                            trailing: kIsWeb
                                ? Icon(Icons.arrow_forward_ios,
                                    size: 20,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.black)
                                : null,
                          ),
                          InkWell(
                            onTap: () {
                              controller.isListOfBlockedAccounts = false;
                              controller.isTranslations = false;
                              controller.isLanguageSettings = false;
                              controller.isLanguageType = false;
                              controller.isAccountPrivacy = false;
                              controller.isProfileLanguagetype = false;
                              controller.isAccountPrivacySettings = false;
                              controller.isChangeUserName = false;
                              controller.isSettingDetail = false;
                              controller.isSettingTypeDetail = false;
                              controller.isAccountInformation = false;
                              controller.isChangeEmail = false;
                              controller.isChangeCountry = true;

                              controller.update();
                              !kIsWeb
                                  ? Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext context) =>
                                              selectCountrySettingScreen()))
                                  : Container();
                            },
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ListTile(
                                  title: kIsWeb
                                      ? Text(
                                          Strings.country,
                                          style: TextStyle(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 16 : 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          // Styles.baseTextTheme.headline1.copyWith(
                                          //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          //    fontSize: kIsWeb ? 16 : 14,
                                          //   fontWeight:FontWeight.w600,
                                          // ),
                                          // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                          //     fontWeight: FontWeight.w500
                                          // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                          //
                                          //
                                          // ),
                                        )
                                      : Text(
                                          Strings.country,
                                          style: Styles.baseTextTheme.headline3
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: 20,
                                          ),
                                        ),
                                  subtitle: Get.find<ProfileController>()
                                              .userProfile
                                              .region ==
                                          null
                                      ? Text(
                                          "- - -",
                                          style: Styles.baseTextTheme.bodyText1
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                          ),
                                        )
                                      : Get.isRegistered<ProfileController>()
                                          ? Text(
                                              "${Get.find<ProfileController>().userProfile.region}",
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                              ),
                                            )
                                          : SizedBox(),
                                  trailing: kIsWeb
                                      ? Icon(
                                          Icons.arrow_forward_ios,
                                          size: 20,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : MyColors.black,
                                        )
                                      : null,
                                ),

                                // Padding(
                                //   padding: const EdgeInsets.only(left: 15, top: 0),
                                //   child: Text(
                                //     "Select the country you live in",
                                //     style: Styles.baseTextTheme.bodyText1.copyWith(
                                //       color:
                                //           Theme.of(context).brightness == Brightness.dark
                                //               ? Colors.white
                                //               : kIsWeb?Colors.black.withOpacity(0.5):Colors.black,
                                //     ),
                                //   ),
                                // )
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: ListTile(
                              title: Text(
                                Strings.verificationAccount,
                                style: !kIsWeb
                                    ? Styles.baseTextTheme.headline3.copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 20,
                                      )
                                    : Styles.baseTextTheme.headline1.copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb ? 16 : 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                // Theme.of(context).brightness == Brightness.dark ?
                                // TextStyle(color: Colors.white,fontSize: 14,
                                //
                                // )
                                //     : TextStyle( color: Colors.grey,fontSize: 14,
                                // ),
                              ),
                              trailing: controller.verification == null ||
                                      controller.verification == "cancel"
                                  ? InkWell(
                                      onTap: () {
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext con) {
                                              return AlertDialog(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                32.0))),
                                                contentPadding: EdgeInsets.zero,
                                                content: Verification(),
                                              );
                                            });
                                      },
                                      child: Text(
                                        Strings.requestVerification,
                                        style: TextStyle(
                                          color: controller.displayColor,
                                          fontSize: 15,
                                        ),
                                      ))
                                  : Text(
                                      controller.verification == "pending"
                                          ? "Pending"
                                          : controller.verification ==
                                                  "verified"
                                              ? Strings.verificationAccount
                                              : "${controller.verification}",
                                      style: TextStyle(
                                        color: controller.displayColor,
                                        fontSize: 15,
                                      ),
                                    ),
                              contentPadding:
                                  EdgeInsets.only(right: 0, left: 0),
                            ),
                          ),
                          kIsWeb
                              ? Container(
                                  height: 1,
                                  color: Colors.grey[300],
                                )
                              : SizedBox(),
                          kIsWeb
                              ? Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    ListTile(
                                      title: kIsWeb
                                          ? Text(
                                              Strings.birthDate,
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 16 : 14,
                                                fontWeight: FontWeight.w500,
                                              ),
                                              // Styles.baseTextTheme.headline1.copyWith(
                                              //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              //    fontSize: kIsWeb ? 16 : 14,
                                              //   fontWeight:FontWeight.w600,
                                              // ),
                                              // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                              //     fontWeight: FontWeight.w500
                                              // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                              //
                                              //
                                              // ),
                                            )
                                          : Text(
                                              Strings.birthDate,
                                              style: Styles
                                                  .baseTextTheme.headline3
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 20,
                                              ),
                                            ),
                                      subtitle: Get.find<ProfileController>()
                                                  .userProfile
                                                  .dob ==
                                              null || Get.find<ProfileController>()
                                          .userProfile
                                          .dob.isEmpty
                                          ? Text(
                                              "- - -",
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                              ),
                                            )
                                          : Get.isRegistered<
                                                  ProfileController>()
                                              ? Text(
                                                  "${Get.find<ProfileController>().userProfile.dob.replaceAll(RegExp(r"\s+"), " ")}",
                                                  style: Styles
                                                      .baseTextTheme.bodyText1
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : kIsWeb
                                                            ? Colors.black
                                                                .withOpacity(
                                                                    0.5)
                                                            : Colors.black,
                                                  ),
                                                )
                                              : SizedBox(),
                                      trailing: kIsWeb
                                          ? Icon(
                                              null,
                                              size: 20,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : MyColors.black,
                                            )
                                          : null,
                                    ),
                                    Visibility(
                                      visible: Get.find<ProfileController>()
                                          .userProfile
                                          .dob ==
                                          null || Get.find<ProfileController>()
                                          .userProfile.dob.isEmpty,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            left: 15, top: 0),
                                        child: RichText(
                                          overflow: TextOverflow.clip,

                                          // Controls how the text should be aligned horizontally
                                          textAlign: TextAlign.end,

                                          // Control the text direction
                                          textDirection: TextDirection.rtl,

                                          // Whether the text should break at soft line breaks
                                          softWrap: true,
                                          text: TextSpan(
                                            text:Strings.dobAddMsg,
                                            style: Styles.baseTextTheme.bodyText1
                                                .copyWith(
                                              color:
                                                  Theme.of(context).brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : kIsWeb
                                                          ? Colors.black
                                                              .withOpacity(0.5)
                                                          : Colors.black,
                                            ),
                                            // style: DefaultTextStyle.of(context).style,
                                            children: <TextSpan>[
                                              TextSpan(
                                                  text: 'profile.',
                                                  style: Styles
                                                      .baseTextTheme.bodyText1
                                                      .copyWith(
                                                          color: Colors.blue),
                                                  recognizer:
                                                      TapGestureRecognizer()
                                                        ..onTap = () async {
                                                          onProfileChange = true;
                                                          controller.navRoute =
                                                              "isProfileScreen";
                                                          //
                                                          Get.toNamed(FluroRouters
                                                                  .mainScreen +
                                                              '/profile');
                                                        }),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : SizedBox(),
                          kIsWeb
                              ? ListTile(
                                  // onTap: () {
                                  //   controller.isListOfBlockedAccounts = false;
                                  //   controller.isTranslations = false;
                                  //   controller.isLanguageSettings = false;
                                  //   controller.isLanguageType = false;
                                  //   controller.isAccountPrivacy = false;
                                  //   controller.isProfileLanguagetype = false;
                                  //   controller.isAccountPrivacySettings = false;
                                  //   controller.isAccountInformation = false;
                                  //   controller.isChangeUserName = true;
                                  //   controller.isSettingDetail = false;
                                  //   controller.isSettingTypeDetail = true;
                                  //
                                  //   controller.update();
                                  //   !kIsWeb
                                  //       ? Navigator.push(
                                  //       context,
                                  //       MaterialPageRoute(
                                  //           builder: (BuildContext context) =>
                                  //               UserNameSettingScreen()))
                                  //       : Container();
                                  // },
                                  title: kIsWeb
                                      ? Text(
                                          Strings.Age,
                                          style: TextStyle(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 16 : 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          // Styles.baseTextTheme.headline1.copyWith(
                                          //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          //    fontSize: kIsWeb ? 16 : 14,
                                          //   fontWeight:FontWeight.w600,
                                          // ),
                                          // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                          //     fontWeight: FontWeight.w500
                                          // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                          //
                                          //
                                          // ),
                                        )
                                      : Text(
                                          Strings.Age,
                                          style: Styles.baseTextTheme.headline3
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: 20,
                                          ),
                                        ),
                                  subtitle: Get.find<ProfileController>()
                                              .userProfile
                                              .age ==
                                          null
                                      ? SizedBox()
                                      : Get.find<ProfileController>()
                                                  .userProfile
                                                  .age !=
                                              null
                                          ? Text(
                                      Get.find<ProfileController>().userProfile.age!=0? "${Get.find<ProfileController>().userProfile.age}":'--',
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                              ),
                                            )
                                          : SizedBox(),
                                  trailing: kIsWeb
                                      ? Icon(null,
                                          size: 20,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : MyColors.black)
                                      : null,
                                )
                              : SizedBox(),
                          kIsWeb
                              ? ListTile(
                                  title: kIsWeb
                                      ? Text(
                                          Strings.accountCreation,
                                          style: TextStyle(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 16 : 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          // Styles.baseTextTheme.headline1.copyWith(
                                          //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          //    fontSize: kIsWeb ? 16 : 14,
                                          //   fontWeight:FontWeight.w600,
                                          // ),
                                          // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                          //     fontWeight: FontWeight.w500
                                          // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                          //
                                          //
                                          // ),
                                        )
                                      : Text(
                                          Strings.accountCreation,
                                          style: Styles.baseTextTheme.headline3
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: 20,
                                          ),
                                        ),
                                  subtitle: Get.find<ProfileController>()
                                              .userProfile
                                              .createdAt ==
                                          null
                                      ? SizedBox()
                                      : Text(
                                          "${Get.find<ProfileController>().userProfile.createdAt}",
                                          style: Styles.baseTextTheme.bodyText1
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                          ),
                                        ),
                                  trailing: kIsWeb
                                      ? Icon(null,
                                          size: 20,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : MyColors.black)
                                      : null,
                                )
                              : SizedBox(),
                          kIsWeb
                              ? ListTile(
                                  onTap: () {
                                    controller.isListOfBlockedAccounts = false;
                                    controller.isTranslations = false;
                                    controller.isLanguageSettings = false;
                                    controller.isLanguageType = false;
                                    controller.isAccountPrivacy = false;
                                    controller.isProfileLanguagetype = false;
                                    controller.isAccountPrivacySettings = false;
                                    controller.isAccountInformation = false;
                                    controller.isChangeUserName = false;
                                    controller.isSettingDetail = false;
                                    controller.isSettingTypeDetail = false;
                                    controller.isSettinggender = true;

                                    if (Get.find<ProfileController>()
                                            .userProfile
                                            .gender ==
                                        "M") {
                                      controller.radioValueGender = 0;
                                    } else if (Get.find<ProfileController>()
                                            .userProfile
                                            .gender ==
                                        "F") {
                                      controller.radioValueGender = 1;
                                    } else if (Get.find<ProfileController>()
                                            .userProfile
                                            .gender ==
                                        "O") {
                                      controller.radioValueGender = 2;
                                    }
                                    controller.update();

                                    controller.update();
                                    // !kIsWeb
                                    //     ? Navigator.push(
                                    //     context,
                                    //     MaterialPageRoute(
                                    //         builder: (BuildContext context) =>
                                    //             UserNameSettingScreen()))
                                    //     : Container();
                                  },
                                  title: kIsWeb
                                      ? Text(
                                          Strings.gender,
                                          style: TextStyle(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 16 : 14,
                                            fontWeight: FontWeight.w500,
                                          ),
                                          // Styles.baseTextTheme.headline1.copyWith(
                                          //    color : Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          //    fontSize: kIsWeb ? 16 : 14,
                                          //   fontWeight:FontWeight.w600,
                                          // ),
                                          // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                          //     fontWeight: FontWeight.w500
                                          // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                          //
                                          //
                                          // ),
                                        )
                                      : Text(
                                          Strings.gender,
                                          style: Styles.baseTextTheme.headline3
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: 20,
                                          ),
                                        ),
                                  subtitle: Get.find<ProfileController>()
                                              .userProfile
                                              .gender ==
                                          null
                                      ? SizedBox()
                                      : Get.find<ProfileController>()
                                                  .userProfile
                                                  .gender ==
                                              "M"
                                          ? Text(
                                              Strings.male,
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : kIsWeb
                                                        ? Colors.black
                                                            .withOpacity(0.5)
                                                        : Colors.black,
                                              ),
                                            )
                                          : Get.find<ProfileController>()
                                                      .userProfile
                                                      .gender ==
                                                  "F"
                                              ? Text(
                                                 Strings.female,
                                                  style: Styles
                                                      .baseTextTheme.bodyText1
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : kIsWeb
                                                            ? Colors.black
                                                                .withOpacity(
                                                                    0.5)
                                                            : Colors.black,
                                                  ),
                                                )
                                              : Text(
                                                  Strings.other,
                                                  style: Styles
                                                      .baseTextTheme.bodyText1
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : kIsWeb
                                                            ? Colors.black
                                                                .withOpacity(
                                                                    0.5)
                                                            : Colors.black,
                                                  ),
                                                ),
                                  trailing: kIsWeb
                                      ? Icon(Icons.arrow_forward_ios,
                                          size: 20,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : MyColors.black)
                                      : null,
                                )
                              : SizedBox(),
                        ],
                      ),
                    ),
                  ));
      },
    );
  }
}
