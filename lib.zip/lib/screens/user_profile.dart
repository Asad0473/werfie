import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:lazy_load_scrollview/lazy_load_scrollview.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/follower_following_controller.dart';

import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/profile_controller.dart';

import 'package:werfieapp/screens/follower_following/follower_following_tab.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/metaTags/MetaTags.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';

import 'package:werfieapp/widgets/post_card.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../main.dart';
import '../models/create_post_model/create_post_model.dart';
import '../utils/fluro_router.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../web_views/web_main_screen.dart';
import '../widgets/blue_tick.dart';
import '../widgets/thread_post_card.dart';
import 'create_post_mobile.dart';
import 'edit_profile_screen.dart';

// ignore: must_be_immutable
class ProfileScreen extends StatelessWidget {
  ProfileScreen({this.controller, this.profileId});

  bool isUserNameExist = false;
  final NewsfeedController controller;
  String profileId;

  ProfileController profileController = Get.put(ProfileController());

  @override
  Widget build(BuildContext context) {
    // print("user profile called yep Yep");
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
          onWillPop: () async {
            Navigator.pop(context);
            // print(profileId);
            controller.isNewsFeedScreen = true;

            controller.isProfileScreen = false;
            controller.navRoute = "isProfileScreen";
            controller.update();
            return false;
          },
          child: MobileProfileScreen(
            newsFeedcontroller: controller,
          ),
        ),
        tablet: MobileProfileScreen(
          newsFeedcontroller: controller,
        ),
        desktop: MobileProfileScreen(
          newsFeedcontroller: controller,
        ),
      ),
      floatingActionButton: kIsWeb
          ? MediaQuery.of(context).size.width >= 500
          ? SizedBox()
          : FloatingActionButton(
        heroTag: UniqueKey(),
        onPressed: () {
          controller.modelList2 = [];

          controller.modelList2.add(ModelClass.fromJson({
            'body': '',
            'poll_ques_first': null,
            'poll_ques_first': null,
            'poll_ques_third': null,
            'poll_ques_fourth': null,
            //  selectType: "Public",
            'files': [],
            'link_meta': '',
            'link': '',
            'link_image': '',
            'link_title': '',
            'days': '',
            'minutes': '',
            'hours': '',
            'location': '',
            'lat': '',
            'lng': '',
            'poll_thread': false,
            'type':
            controller.modelList2.length < 2 ? 'post' : 'thread'
          }));

          //   widget.controller. indexOfText();
          print('list of ');
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => CreatePostMobile(
                controller,
                isUserProfile: true,
              ),
            ),
          );
        },
        backgroundColor: controller.displayColor,
        child: Icon(
          Icons.add,
          color: Colors.white,
        ),
      )
          : FloatingActionButton(
        heroTag: UniqueKey(),
        onPressed: () {
          controller.modelList2 = [];

          controller.modelList2.add(ModelClass.fromJson({
            'body': '',
            'poll_ques_first': null,
            'poll_ques_first': null,
            'poll_ques_third': null,
            'poll_ques_fourth': null,
            //  selectType: "Public",
            'files': [],
            'link_meta': '',
            'link': '',
            'link_image': '',
            'link_title': '',
            'days': '',
            'minutes': '',
            'hours': '',
            'location': '',
            'lat': '',
            'lng': '',
            'poll_thread': false,
            'type': controller.modelList2.length < 2 ? 'post' : 'thread'
          }));

          //   widget.controller. indexOfText();
          print('list of ');
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) =>
                  CreatePostMobile(controller, isUserProfile: true),
            ),
          );
        },
        backgroundColor: controller.displayColor,
        child: Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }
}

class MobileProfileScreen extends StatefulWidget {
  MobileProfileScreen({this.newsFeedcontroller});

  final NewsfeedController newsFeedcontroller;

  @override
  State<MobileProfileScreen> createState() => _MobileProfileScreenState();
}

class _MobileProfileScreenState extends State<MobileProfileScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final controller = Get.find<ProfileController>();

  addProfileMetaTags(String name,String profileImage){

    MetaTags().addMetaTag(
        pageTitle: "$name ${MetaTagValues.pageTitleProfile}",
        metaTagDescription: "Follow $name ${MetaTagValues.profileMetaDescription}",
        metaTagKeywords: "$name${MetaTagValues.profileMetaKeywords}",
        ogTitle: "$name ${MetaTagValues.profileOGTitle}",
        ogDescription: "Follow $name ${MetaTagValues.profileOGDescription}",
        ogImage: profileImage
    );
  }

  @override
  void initState() {
    if(!widget.newsFeedcontroller.isLoading && controller.userProfile != null ){
      addProfileMetaTags("${controller.userProfile.firstname} ${controller.userProfile.lastname}",controller.userProfile.profileImage ?? "assets/images/person_placeholder.png");
    }
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final width = Get.width;
    final height = Get.height;
    return GetBuilder<ProfileController>(builder: (controller) {

      return widget.newsFeedcontroller.isLoading == true && kIsWeb && controller.userProfile == null
          ? Center(
        child: CircularProgressIndicator(
          color: MyColors.BlueColor,
        ),
      )
          : Scaffold(
        // key: _scaffoldKey,
        // drawer:
        //     !Responsive.isDesktop(context) ? MainDrawer(newsFeedcontroller) : Container(),
        // drawerEnableOpenDragGesture:
        //     !Responsive.isDesktop(context) ? false : true,
        appBar: kIsWeb
            ? PreferredSize(
          child: ListTile(
            leading: IconButton(
              // splashColor: Colors.white,
              // hoverColor:  Colors.grey[200],
              icon: Icon(
                Icons.arrow_back,
                color:
                Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
              ),
              onPressed: () {
                Get.back();
                onHomeChange = true;
                onBrowsChange = false;
                onTrendsChange = false;
                onBookMarksChange = false;
                onChatsChange = false;
                onProfileChange = false;
                onSettingChange = false;
                onListChange = false;
                onNotificationChange = false;
                onMoreChange = false;

                widget.newsFeedcontroller.isTrendsScreen = false;
                widget.newsFeedcontroller.isNewsFeedScreen = true;
                widget.newsFeedcontroller.isBrowseScreen = false;
                widget.newsFeedcontroller.isNotificationScreen = false;
                widget.newsFeedcontroller.isChatScreen = false;
                widget.newsFeedcontroller.isSavedPostScreen = false;
                widget.newsFeedcontroller.isPostDetails = false;
                widget.newsFeedcontroller.isProfileScreen = false;
                widget.newsFeedcontroller.isOtherUserProfileScreen = false;
                widget.newsFeedcontroller.update();
              },
            ),
            title: SizedBox(
              height: 28,
              child: Text(
                controller.userProfile.firstname??'' +
                    ' ' +
                    controller.userProfile.lastname??'',
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontWeight: FontWeight.bold,
                ),
                // TextStyle(
                //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                //   fontSize: 20,
                //   fontWeight: FontWeight.bold,
                //
                // )
              ),
            ),
            subtitle: SizedBox(
              height: 18,
              child: Text(
                '${controller.userProfile.totalPosts} ' +
                    Strings.werfs,
                style: Styles.baseTextTheme.headline5.copyWith(
                    fontSize: 14, fontWeight: FontWeight.w400),
                // TextStyle(
                //     color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                //     fontSize: 14,
                //     fontWeight: FontWeight.w400,
                // ),
              ),
            ),
          ),

          // Row(
          //   children: [
          //     IconButton(
          //       splashColor: Colors.white,
          //       hoverColor: Colors.grey[100],
          //       icon: Icon(Icons.arrow_back),
          //       onPressed: () {
          //         controller.newsFeedController.isTrendsScreen =
          //             false;
          //         controller.newsFeedController.isNewsFeedScreen =
          //             true;
          //         controller.newsFeedController.isQuestScreen = false;
          //         controller.newsFeedController.isNotificationScreen =
          //             false;
          //         controller.newsFeedController.isChatScreen = false;
          //         controller.newsFeedController.isSavedPostScreen =
          //             false;
          //         controller.newsFeedController.isPostDetails = false;
          //         controller.newsFeedController.isProfileScreen =
          //             false;
          //         controller.newsFeedController
          //             .isOtherUserProfileScreen = false;

          //         controller.newsFeedController.update();
          //       },
          //     ),
          //     SizedBox(width: 30),

          //     Text(
          //       controller.otherUserName,
          //       style: Theme.of(context).textTheme.headline6,
          //     ),
          //   ],
          // ),
          preferredSize: Size(double.infinity, 60),
        )
            : AppBar(
          backgroundColor:
          Theme.of(context).brightness == Brightness.dark
              ? Colors.black
              : Colors.white,
          iconTheme: IconThemeData(
            // color: Color(0xFF4f515b),
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          ),
          title: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                controller.userProfile.firstname +
                    '  ' +
                    controller.userProfile.lastname,
                textAlign: TextAlign.left,
                // style:
                // Theme.of(context).textTheme.headline6.copyWith(
                //   fontSize: 18,
                //   fontWeight: FontWeight.w700,
                //   color: Colors.black,
                // ),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontWeight: FontWeight.bold,
                ),
                // TextStyle(
                //   color:Theme.of(context).brightness == Brightness.dark ? Colors.white  : Colors.black,
                //   fontSize: 18,
                //   fontWeight: FontWeight.bold,
                // ),
              ),
              Text(
                '${controller.userProfile.totalPosts} ' +
                    Strings.werfs,
                style: Styles.baseTextTheme.headline5.copyWith(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                ),
                // TextStyle(
                //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                //   fontSize: 14,
                //   fontWeight: FontWeight.w400,
                // ),
              ),
              SizedBox(
                height: 10,
              ),
            ],
          ),
        ),

        body: Container(
          height: Get.height,
          decoration:
          BoxDecoration(border: Border.all(color: Colors.grey[100])),
          child:
          /*controller.isFilter == true
                    ? Center(
                        child: CircularProgressIndicator(
                        color: MyColors.BlueColor,
                      ))
                    :*/
          controller.userPosts.isEmpty ||
              controller.userPosts.isEmpty
              ? SingleChildScrollView(
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.antiAlias,
                  alignment: Alignment.bottomLeft,
                  children: [
                    // COVER PHOTO
                    InkWell(
                      onTap: () {
                        showDialog(
                          useSafeArea: false,
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              insetPadding: EdgeInsets.zero,
                              contentPadding: EdgeInsets.zero,
                              content: Stack(
                                children: [
                                  Container(
                                    color: Colors.black,
                                    width:
                                    MediaQuery.of(context)
                                        .size
                                        .width,
                                    height:
                                    MediaQuery.of(context)
                                        .size
                                        .height,
                                    child: FadeInImage(
                                      placeholderErrorBuilder:
                                          (context, _, __) {
                                        return Image.asset(
                                            'assets/images/person_placeholder.png');
                                      },
                                      imageErrorBuilder:
                                          (context, _, __) {
                                        return Image.asset(
                                            'assets/images/person_placeholder.png');
                                      },
                                      fit: BoxFit.contain,
                                      width: 24,
                                      height: 24,
                                      placeholder: AssetImage(
                                          'assets/images/person_placeholder.png'),
                                      image:  controller
                                          .userProfile
                                          .coverImage !=
                                          null
                                          ? NetworkImage(
                                          controller
                                              .userProfile.coverImage)
                                          : AssetImage(
                                          'assets/images/person_placeholder.png'),
                                    ),
                                  ),
                                  Positioned(
                                    top: kIsWeb ? 10 : 30,
                                    left: 10,
                                    child: InkWell(
                                      onTap: () {
                                        kIsWeb
                                            ? Navigator.pop(
                                            context)
                                            : Get.back();
                                      },
                                      child: Actions(
                                        actions: {
                                          ClearIntent: CallbackAction<
                                              ClearIntent>(
                                              onInvoke: (Intent) =>
                                                  Navigator.of(
                                                      context)
                                                      .pop()),
                                        },
                                        child: Focus(
                                          autofocus: true,
                                          child: Icon(
                                            Icons.cancel,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                      child: Container(
                        width: Get.width,
                        height: kIsWeb
                            ? Get.height / 3.5
                            : Get.height / 4.5,
                        color: Colors.grey[200],
                        margin: EdgeInsets.only(
                            bottom: Get.height / 15),
                        child: controller.userProfile == null
                            ? SizedBox()
                            : ClipRRect(
                          borderRadius:
                          BorderRadius.circular(0),
                          child: FadeInImage(
                            placeholderErrorBuilder:
                                (context, _, __) {
                              return Image.asset(
                                  'assets/images/person_placeholder.png');
                            },
                            imageErrorBuilder:
                                (context, _, __) {
                              return Image.asset(
                                  'assets/images/person_placeholder.png');
                            },
                            fit: BoxFit.cover,
                            width: 24,
                            height: 24,
                            placeholder: AssetImage(
                                'assets/images/person_placeholder.png'),
                            image: controller.userProfile
                                .coverImage !=
                                null
                                ? NetworkImage(controller
                                .userProfile
                                .coverImage)
                                : AssetImage(
                                'assets/images/person_placeholder.png'),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0,
                          right: kIsWeb ? 40.0 : 20.0),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        crossAxisAlignment:
                        CrossAxisAlignment.end,
                        children: [
                          InkWell(
                            onTap: () {
                              showDialog(
                                  useSafeArea: false,
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      insetPadding:
                                      EdgeInsets.zero,
                                      contentPadding:
                                      EdgeInsets.zero,
                                      content: Stack(
                                        children: [
                                          Container(
                                            color: Colors.black,
                                            width:
                                            MediaQuery.of(
                                                context)
                                                .size
                                                .width,
                                            height:
                                            MediaQuery.of(
                                                context)
                                                .size
                                                .height,
                                            child: FadeInImage(
                                              placeholderErrorBuilder:
                                                  (context, _,
                                                  __) {
                                                return Image.asset(
                                                    'assets/images/person_placeholder.png');
                                              },
                                              imageErrorBuilder:
                                                  (context, _,
                                                  __) {
                                                return Image.asset(
                                                    'assets/images/person_placeholder.png');
                                              },
                                              fit: BoxFit
                                                  .contain,
                                              width: 150,
                                              height: 150,
                                              placeholder:
                                              AssetImage(
                                                  'assets/images/person_placeholder.png'),
                                              image: controller
                                                  .userProfile
                                                  .profileImage !=
                                                  null
                                                  ? NetworkImage(
                                                  controller
                                                      .userProfile
                                                      .profileImage)
                                                  : AssetImage(
                                                  'assets/images/person_placeholder.png'),
                                            ),
                                          ),
                                          Positioned(
                                            top: kIsWeb
                                                ? 10
                                                : 30,
                                            left: 10,
                                            child: InkWell(
                                              onTap: () {
                                                kIsWeb
                                                    ? Navigator.pop(
                                                    context)
                                                    : Get
                                                    .back();
                                              },
                                              child: Actions(
                                                  actions: {
                                                    ClearIntent: CallbackAction<
                                                        ClearIntent>(
                                                        onInvoke:
                                                            (Intent) =>
                                                            Navigator.of(context).pop()),
                                                  },
                                                  child: Focus(
                                                    autofocus:
                                                    true,
                                                    child: Icon(
                                                      Icons
                                                          .cancel,
                                                      color: Colors
                                                          .white,
                                                    ),
                                                  )),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  });
                            },
                            child: CircleAvatar(
                              radius: kIsWeb ? 80 : 70,
                              backgroundColor: Colors.white,
                              child: CircleAvatar(
                                radius: kIsWeb ? 75 : 65,
                                backgroundColor: Colors.white,
                                child: controller.userProfile ==
                                    null
                                    ? CircularProgressIndicator(
                                  color:
                                  MyColors.BlueColor,
                                )
                                    : ClipRRect(
                                  borderRadius:
                                  BorderRadius
                                      .circular(kIsWeb
                                      ? 80
                                      : 70),
                                  child: controller
                                      .userProfile
                                      .profileImage !=
                                      null
                                      ? Image.network(
                                    controller
                                        .userProfile
                                        .profileImage,
                                    fit: BoxFit
                                        .cover,
                                    width: 150,
                                    height: 150,
                                  )
                                      : Image.asset(
                                    'assets/images/person_placeholder.png',
                                    fit: BoxFit
                                        .cover,
                                    width: 150,
                                    height: 150,
                                  ),

                                  //     FadeInImage(
                                  //   placeholderErrorBuilder:
                                  //       (context, _, __) {
                                  //     return Image.asset(
                                  //         'assets/images/person_placeholder.png');
                                  //   },
                                  //   imageErrorBuilder:
                                  //       (context, _, __) {
                                  //     return Image.asset(
                                  //         'assets/images/person_placeholder.png');
                                  //   },
                                  //   fit: BoxFit.cover,
                                  //   width: 150,
                                  //   height: 150,
                                  //   placeholder: AssetImage(
                                  //       'assets/images/person_placeholder.png'),
                                  //   image: NetworkImage(controller.userProfile.profileImage != null ? controller.userProfile.profileImage
                                  //       : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                  // ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(right: 10.0),
                      child: Align(
                        alignment: Alignment.topRight,
                        child: ElevatedButton(
                          onPressed: () {
                            controller.isProfile = true;
                            controller.selectedView =
                            "isProfile";
                            controller.isCover = false;
                            controller.isBio = false;
                            controller.profileImage = null;
                            controller.coverImage = null;
                            controller.bioText.text =
                                controller.userProfile.bio;
                            controller
                                .usernameText.text = controller
                                .userProfile.firstname +
                                controller.userProfile.lastname;

                            controller.update();
                            if (kIsWeb) {
                              showProfileDialog(
                                  context,
                                  // controller,
                                  Get.width,
                                  Get.height);
                            } else {
                              Get.to(EditProfileWidget());
                            }
                            controller.dob = true;
                          },
                          child: Text(
                            Strings.editProfile,
                            // style: Theme.of(context).brightness == Brightness.dark ?
                            // TextStyle(
                            //     color: Colors.white,
                            //     fontWeight: FontWeight.bold,
                            //
                            //
                            // )
                            //     : TextStyle(  color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold
                            // ),
                            style: TextStyle(
                              color: Theme.of(context)
                                  .brightness ==
                                  Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                              primary: Theme.of(context)
                                  .brightness ==
                                  Brightness.dark
                                  ? Colors.black
                                  : Colors.white,
                              shape: StadiumBorder(),
                              side: BorderSide(
                                  color: Theme.of(context)
                                      .brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  width: 2.0),
                              // color: Colorss.yellow,
                              elevation: 0.0,
                              padding: kIsWeb
                                  ? EdgeInsets.symmetric(
                                  horizontal: 25.0,
                                  vertical: 20.0)
                                  : EdgeInsets.symmetric(
                                  horizontal: 15.0,
                                  vertical: 10.0)),
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                          left: 20.0,
                          top: 2,
                          bottom: 0,
                          right: 20.0),
                      child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: kIsWeb ? 250 : 150,
                                // : 120,
                                child: Text(
                                  controller.userProfile == null
                                      ? ""
                                      : "${controller.userProfile.firstname + " " + controller.userProfile.lastname}",
                                  maxLines: 1,
                                  overflow: controller
                                      .userProfile
                                      .firstname
                                      .length +
                                      controller
                                          .userProfile
                                          .lastname
                                          .length >
                                      30
                                      ? TextOverflow.ellipsis
                                      : null,
                                  style: Styles
                                      .baseTextTheme.headline2
                                      .copyWith(
                                    color: Theme.of(context)
                                        .brightness ==
                                        Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  // TextStyle(
                                  //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                  //   fontSize: kIsWeb ? 20.0 : 18,
                                  //   height: 1.5,
                                  //   fontWeight: FontWeight.bold,
                                  // )
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              controller.userProfile
                                  .accountVerified ==
                                  "verified"
                                  ? Padding(
                                padding:
                                const EdgeInsets.only(
                                    top: 3.0),
                                child: BlueTick(
                                  height: 20,
                                  width: 20,
                                  iconSize: 14,
                                ),
                              )
                                  : SizedBox(),
                            ],
                          ),

                          SizedBox(
                            height: 5,
                          ),

                          // Text(
                          //   controller.userProfile == null
                          //       ? ""
                          //       : "${controller.userProfile.email}",
                          //   style: Styles.baseTextTheme.headline5.copyWith(
                          //     fontWeight: FontWeight.w400,
                          //   ),
                          //   // TextStyle(
                          //   //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                          //   //   fontSize: kIsWeb ? 18.0 : 16.0,
                          //   //   fontWeight: FontWeight.w400,
                          //   // ),
                          // ),
                          Text(
                            controller.userProfile == null
                                ? ""
                                : "@${controller.userProfile.username}",
                            style: Styles
                                .baseTextTheme.headline5
                                .copyWith(
                              fontWeight: FontWeight.w400,
                            ),
                            // TextStyle(
                            //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                            //   fontSize: kIsWeb ? 18.0 : 16.0,
                            //  fontWeight: FontWeight.w400,
                            // ),
                          ),
                          controller.userProfile == null
                              ? SizedBox()
                              : controller.userProfile.bio ==
                              null
                              ? SizedBox()
                              : Text(
                            "${controller.userProfile.bio}",
                            style: Styles
                                .baseTextTheme
                                .headline5
                                .copyWith(
                              color: Theme.of(context)
                                  .brightness ==
                                  Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight:
                              FontWeight.w400,
                            ),
                            // TextStyle(
                            //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                            //   fontSize: kIsWeb ? 18.0 : 16.0,
                            //   fontWeight: FontWeight.w400,
                            //
                            // )
                          ),

                          SizedBox(
                            height: 5,
                          ),

                          /// dob
                          controller.userProfile == null
                              ? SizedBox()
                              : controller.userProfile.dob ==
                              null
                              ? SizedBox()
                              : Row(
                            children: [
                              Icon(
                                Icons
                                    .calendar_today_outlined,
                                color:
                                Color(0xFF586976),
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              Text(
                                "${controller.userProfile.dob.replaceAll(RegExp(r"\s+"), " ")}",
                                style: Styles
                                    .baseTextTheme
                                    .headline5
                                    .copyWith(
                                  fontWeight:
                                  FontWeight.w400,
                                ),
                                // TextStyle(
                                //     color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                                //     fontSize: kIsWeb ? 18.0 : 16.0,
                                //     fontWeight: FontWeight.w400,
                                // ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              InkWell(
                                onTap: kIsWeb
                                    ? () {
                                  if (kIsWeb) {
                                    // For Follow Tab: On web if any action like follow or unfollow is done on the second tab
                                    // its resetting the tab index to 0.
                                    // To avoid that we save the current tab index and apply it when the page reloads
                                    // Here we reset the index to 0. we have to show the first tab when user enters the page freshly
                                    widget.newsFeedcontroller
                                        .followTabIndex = 0;
                                  }
                                  /* onProfileChange = false;
                                                print(
                                                    "agiya hai  ${onProfileChange}");
                                                Get.put(FollowerController());

                                                Get.find<FollowerController>().getFollower(userId: GetStorage().read('id'));
                                                Get.find<FollowerController>().getFollowing(userId: GetStorage().read('id'));
                                                Get.find<FollowerController>()
                                                    .followingCheck = 1;
                                                Get.find<FollowerController>()
                                                    .update();
                                                controller.isSearch = false;
                                                controller.isFilter = false;
                                                newsFeedcontroller
                                                    .isFilterScreen = false;
                                                newsFeedcontroller
                                                    .isTrendsScreen = false;
                                                newsFeedcontroller
                                                    .isNewsFeedScreen = false;
                                                newsFeedcontroller
                                                    .isBrowseScreen = false;
                                                newsFeedcontroller
                                                    .isNotificationScreen = false;
                                                newsFeedcontroller
                                                    .isSavedPostScreen = false;
                                                newsFeedcontroller.isChatScreen =
                                                    false;
                                                newsFeedcontroller.isPostDetails =
                                                    false;
                                                newsFeedcontroller
                                                    .isProfileScreen = false;
                                                newsFeedcontroller
                                                        .isOtherUserProfileScreen =
                                                    false;
                                                newsFeedcontroller
                                                    .isFollwerScreen = true;

                                                newsFeedcontroller.navRoute =
                                                    "isProfileScreen";
                                                newsFeedcontroller.update();*/
                                  Get.put(
                                      FollowerController());
                                  Get.find<
                                      FollowerController>()
                                      .getFollower(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'),
                                      isFromRoute:
                                      true);
                                  Get.find<
                                      FollowerController>()
                                      .getFollowing(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'),
                                      isFromRoute:
                                      true);
                                  Get.find<
                                      FollowerController>()
                                      .followingCheck = 1;
                                  Get.find<
                                      FollowerController>()
                                      .update();
                                  Get.toNamed(FluroRouters
                                      .mainScreen +
                                      "/followings/" +
                                      GetStorage()
                                          .read('id')
                                          .toString());
                                }
                                    : () {
                                  Get.put(
                                      FollowerController());
                                  Get.find<
                                      FollowerController>()
                                      .getFollower(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'));
                                  Get.find<
                                      FollowerController>()
                                      .getFollowing(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'));
                                  Get.find<
                                      FollowerController>()
                                      .followingCheck = 1;
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext
                                          context) =>
                                              FollowerScreen(
                                                isOtherUserProfile:
                                                false,
                                                controller:
                                                widget.newsFeedcontroller,
                                              )));

                                  Get.find<
                                      FollowerController>()
                                      .update();
                                },
                                child: Row(
                                  children: [
                                    Text(
                                      controller.userProfile ==
                                          null
                                          ? ""
                                          : "${controller.userProfile.followings} ",
                                      style: Styles
                                          .baseTextTheme
                                          .headline1
                                          .copyWith(
                                        color: Theme.of(context)
                                            .brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb
                                            ? 16.0
                                            : 14.0,
                                      ),
                                      // TextStyle(
                                      //   color: Theme.of(context).brightness == Brightness.dark
                                      //       ? Colors.white
                                      //       : Colors.black,
                                      //   fontSize: kIsWeb ? 18.0 : 16.0,
                                      //   fontWeight: FontWeight.bold,
                                      //
                                      // ),
                                    ),
                                    Text(
                                      controller.userProfile ==
                                          null
                                          ? ""
                                          : Strings.followings,
                                      style: Styles
                                          .baseTextTheme
                                          .headline2
                                          .copyWith(
                                        fontSize: kIsWeb
                                            ? 16.0
                                            : 14.0,
                                        fontWeight:
                                        FontWeight.w500,
                                      ),
                                      // TextStyle(
                                      //   color: Theme.of(context).brightness == Brightness.dark
                                      //       ? Color(0xFF586976)
                                      //       : Color(0xFF586976),
                                      //   fontSize: kIsWeb ? 18.0 : 16.0,
                                      //   fontWeight: FontWeight.bold,
                                      //
                                      // ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 15,
                              ),
                              InkWell(
                                onTap: kIsWeb
                                    ? () {
                                  if (kIsWeb) {
                                    // For Follow Tab: On web if any action like follow or unfollow is done on the second tab
                                    // its resetting the tab index to 0.
                                    // To avoid that we save the current tab index and apply it when the page reloads
                                    // Here we reset the index to 0. we have to show the first tab when user enters the page freshly
                                    widget.newsFeedcontroller
                                        .followTabIndex = 0;
                                  }
                                  /* onProfileChange = false;
                                                Get.put(FollowerController());
                                                Get.find<FollowerController>().getFollower(userId: GetStorage().read('id'));
                                                Get.find<FollowerController>().getFollowing(userId: GetStorage().read('id'));
                                                Get.find<FollowerController>().followingCheck = 0;
                                                Get.find<FollowerController>().update();
                                                controller.isSearch = false;
                                                controller.isFilter = false;
                                                newsFeedcontroller.isFilterScreen = false;
                                                newsFeedcontroller.isTrendsScreen = false;
                                                newsFeedcontroller.isNewsFeedScreen = false;
                                                newsFeedcontroller.isBrowseScreen = false;
                                                newsFeedcontroller.isNotificationScreen = false;
                                                newsFeedcontroller.isSavedPostScreen = false;
                                                newsFeedcontroller.isChatScreen = false;
                                                newsFeedcontroller.isPostDetails = false;
                                                newsFeedcontroller.isProfileScreen = false;
                                                newsFeedcontroller.isOtherUserProfileScreen = false;
                                                newsFeedcontroller.isFollwerScreen = true;
                                                newsFeedcontroller.navRoute = "isProfileScreen";
                                                newsFeedcontroller.update();*/

                                  Get.put(
                                      FollowerController());
                                  Get.find<
                                      FollowerController>()
                                      .getFollower(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'),
                                      isFromRoute:
                                      true);
                                  Get.find<
                                      FollowerController>()
                                      .getFollowing(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'),
                                      isFromRoute:
                                      true);
                                  Get.find<
                                      FollowerController>()
                                      .followingCheck = 0;
                                  Get.find<
                                      FollowerController>()
                                      .update();
                                  Get.toNamed(FluroRouters
                                      .mainScreen +
                                      "/followers/" +
                                      GetStorage()
                                          .read('id')
                                          .toString());
                                }
                                    : () {
                                  Get.put(
                                      FollowerController());
                                  Get.find<
                                      FollowerController>()
                                      .getFollower(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'));
                                  Get.find<
                                      FollowerController>()
                                      .getFollowing(
                                      userId:
                                      GetStorage()
                                          .read(
                                          'id'));
                                  Get.find<
                                      FollowerController>()
                                      .followingCheck = 0;
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (BuildContext
                                          context) =>
                                              FollowerScreen(
                                                controller:
                                                widget.newsFeedcontroller,
                                              )));
                                  Get.find<
                                      FollowerController>()
                                      .update();
                                },
                                child: Row(
                                  children: [
                                    Text(
                                      controller.userProfile ==
                                          null
                                          ? ""
                                          : "${controller.userProfile.followers} ",
                                      style: Styles
                                          .baseTextTheme
                                          .headline1
                                          .copyWith(
                                        color: Theme.of(context)
                                            .brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb
                                            ? 16.0
                                            : 14.0,
                                      ),
                                      // TextStyle(
                                      //   color: Theme.of(context).brightness == Brightness.dark
                                      //       ? Colors.white
                                      //       : Colors.black,
                                      //   fontSize: kIsWeb ? 18.0 : 16.0,
                                      //   fontWeight: FontWeight.bold,
                                      //
                                      // ),
                                    ),
                                    Text(
                                      controller.userProfile ==
                                          null
                                          ? ""
                                          : Strings.followers,
                                      // style: Theme.of(context).brightness == Brightness.dark ?
                                      // TextStyle(color: Colors.white,fontSize: kIsWeb ? 18.0 : 14.0,
                                      //
                                      // )
                                      //     : TextStyle(  color: Colors.black,fontSize: kIsWeb ? 18.0 : 14.0,
                                      // ),
                                      style: Styles
                                          .baseTextTheme
                                          .headline2
                                          .copyWith(
                                        fontSize: kIsWeb
                                            ? 16.0
                                            : 14.0,
                                        fontWeight:
                                        FontWeight.w500,
                                      ),
                                      // TextStyle(
                                      //   color: Theme.of(context).brightness == Brightness.dark
                                      //       ? Color(0xFF586976)
                                      //       : Color(0xFF586976),
                                      //   fontSize: kIsWeb ? 18.0 : 16.0,
                                      //  fontWeight: FontWeight.bold,
                                      //
                                      //
                                      // ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 15,
                          ),
                        ],
                      ),
                    ),
                    kIsWeb
                        ? Container(
                      child: FittedBox(
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment
                              .spaceBetween,
                          children: [
                            TabButton(
                              title: Strings.werfs,
                              onTap: () async {
                                controller.isHiddenPost =
                                false;
                                controller.isTweets =
                                true;
                                controller.isTweetsReply =
                                false;
                                controller.isMedia =
                                false;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isTweets";
                                await controller
                                    .filterUsersPost(
                                    "posts");
                                controller.update();
                                // newsFeedcontroller.update();
                              },
                              isSelected:
                              controller.isTweets,
                            ),
                            TabButton(
                              title: Strings
                                  .tweetsAndReplies,
                              onTap: () async {
                                print("jjjasda");
                                controller.isTweets =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isTweetsReply =
                                true;
                                controller.isMedia =
                                false;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isTweetsReply";

                                await controller
                                    .filterUsersPost(
                                    "post_commented");

                                controller.update();
                                // newsFeedcontroller.update();
                              },
                              isSelected: controller
                                  .isTweetsReply,
                            ),
                            TabButton(
                              title: Strings.media,
                              onTap: () async {
                                controller.isTweets =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isTweetsReply =
                                false;
                                controller.isMedia = true;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isMedia";
                                await controller
                                    .filterUsersPost(
                                    "media");
                                controller.update();
                              },
                              isSelected:
                              controller.isMedia,
                            ),
                            TabButton(
                              title: Strings.likes,
                              onTap: () async {
                                controller.isTweets =
                                false;
                                controller.isTweetsReply =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isMedia =
                                false;
                                controller.isLikes = true;
                                controller.selectedTab =
                                "isLikes";
                                controller.userPosts =
                                await controller
                                    .filterUsersPost(
                                    "likes");

                                controller.update();
                              },
                              isSelected:
                              controller.isLikes,
                            ),
                            TabButton(
                              title: Strings.hiddenPost,
                              onTap: () async {
                                controller.isHiddenPost = true;
                                controller.isTweets = false;
                                controller.isTweetsReply = false;
                                controller.isMedia = false;
                                controller.isLikes = false;
                                controller.selectedTab = "isHiddenPost";
                                controller.userPosts =
                                await controller
                                    .filterUsersPost("likes");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount.value =
                                      element.simpleLikeCount;
                                  element.rebuzzCount.value =
                                      element.retweetCount;
                                  element.commentCount.value =
                                      element.commentsCount;
                                  if (element.isLiked == true) {
                                    element.like.value = true;
                                    element.like.refresh();
                                  }
                                });
                                // controller.filterUsers(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller.update();
                              },
                              isSelected: controller.isHiddenPost,
                            ),
                            // TabButton(
                            //   title: Strings.hiddenPost,
                            //   onTap: () async {
                            //     controller.isHiddenPost = true;
                            //     controller.isTweets = false;
                            //     controller.isTweetsReply = false;
                            //     controller.isMedia = false;
                            //     controller.isLikes = false;
                            //     controller.selectedTab = "isHiddenPost";
                            //     controller.userPosts =
                            //     await controller.filterUsersPost("likes");
                            //     controller.userPosts
                            //         .forEach((element) {
                            //       element.likeCount.value =
                            //           element.simpleLikeCount;
                            //       element.rebuzzCount.value =
                            //           element.retweetCount;
                            //       element.commentCount.value =
                            //           element.commentsCount;
                            //       if (element.isLiked == true) {
                            //         element.like.value = true;
                            //         element.like.refresh();
                            //       }
                            //     });
                            //     // controller.filterUsers(
                            //     //   id: controller.searchSelected.id,
                            //     //   type: controller.searchSelected.type,
                            //     // );
                            //
                            //     controller.update();
                            //     newsFeedcontroller.update();
                            //   },
                            //   isSelected: controller.isHiddenPost,
                            // ),
                          ],
                        ),
                      ),
                    )
                        : Container(
                      child: FittedBox(
                        child: Row(
                          mainAxisAlignment:
                          MainAxisAlignment
                              .spaceEvenly,
                          children: [
                            TabButton(
                              title: Strings.werfs,
                              onTap: () async {
                                controller.isHiddenPost =
                                false;
                                controller.isTweets =
                                true;
                                controller.isTweetsReply =
                                false;
                                controller.isMedia =
                                false;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isTweets";

                                controller.userPosts =
                                await controller
                                    .filterUsersPost(
                                    "posts");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount
                                      .value =
                                      element
                                          .simpleLikeCount;
                                  element.rebuzzCount
                                      .value =
                                      element
                                          .retweetCount;
                                  element.commentCount
                                      .value =
                                      element
                                          .commentsCount;
                                  if (element.isLiked ==
                                      true) {
                                    element.like.value =
                                    true;
                                    element.like
                                        .refresh();
                                  }
                                });
                                // controller.filterUsersPost(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller
                                    .update();
                              },
                              isSelected:
                              controller.isTweets,
                            ),
                            TabButton(
                              title: Strings
                                  .tweetsAndReplies,
                              onTap: () async {
                                controller.isTweets =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isTweetsReply =
                                true;
                                controller.isMedia =
                                false;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isTweetsReply";

                                controller.userPosts =
                                await controller
                                    .filterUsersPost(
                                    "post_commented");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount
                                      .value =
                                      element
                                          .simpleLikeCount;
                                  element.rebuzzCount
                                      .value =
                                      element
                                          .retweetCount;
                                  element.commentCount
                                      .value =
                                      element
                                          .commentsCount;
                                  if (element.isLiked ==
                                      true) {
                                    element.like.value =
                                    true;
                                    element.like
                                        .refresh();
                                  }
                                });
                                // controller.filterUsers(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller
                                    .update();
                              },
                              isSelected: controller
                                  .isTweetsReply,
                            ),
                            TabButton(
                              title: Strings.media,
                              onTap: () async {
                                controller.isTweets =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isTweetsReply =
                                false;
                                controller.isMedia = true;
                                controller.isLikes =
                                false;
                                controller.selectedTab =
                                "isMedia";

                                controller.userPosts =
                                await controller
                                    .filterUsersPost(
                                    "media");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount
                                      .value =
                                      element
                                          .simpleLikeCount;
                                  element.rebuzzCount
                                      .value =
                                      element
                                          .retweetCount;
                                  element.commentCount
                                      .value =
                                      element
                                          .commentsCount;
                                  if (element.isLiked ==
                                      true) {
                                    element.like.value =
                                    true;
                                    element.like
                                        .refresh();
                                  }
                                });
                                // controller.filterUsers(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller
                                    .update();
                              },
                              isSelected:
                              controller.isMedia,
                            ),
                            TabButton(
                              title: Strings.likes,
                              onTap: () async {
                                controller.isTweets =
                                false;
                                controller.isTweetsReply =
                                false;
                                controller.isHiddenPost =
                                false;
                                controller.isMedia =
                                false;
                                controller.isLikes = true;
                                controller.selectedTab =
                                "isLikes";
                                controller.userPosts =
                                await controller
                                    .filterUsersPost(
                                    "likes");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount
                                      .value =
                                      element
                                          .simpleLikeCount;
                                  element.rebuzzCount
                                      .value =
                                      element
                                          .retweetCount;
                                  element.commentCount
                                      .value =
                                      element
                                          .commentsCount;
                                  if (element.isLiked ==
                                      true) {
                                    element.like.value =
                                    true;
                                    element.like
                                        .refresh();
                                  }
                                });
                                // controller.filterUsers(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller
                                    .update();
                              },
                              isSelected:
                              controller.isLikes,
                            ),
                            TabButton(
                              title: Strings.hiddenPost,
                              onTap: () async {
                                controller.isHiddenPost = true;
                                controller.isTweets = false;
                                controller.isTweetsReply = false;
                                controller.isMedia = false;
                                controller.isLikes = false;
                                controller.selectedTab = "isHiddenPost";
                                controller.userPosts =
                                await controller
                                    .filterUsersPost("likes");
                                controller.userPosts
                                    .forEach((element) {
                                  element.likeCount.value =
                                      element.simpleLikeCount;
                                  element.rebuzzCount.value =
                                      element.retweetCount;
                                  element.commentCount.value =
                                      element.commentsCount;
                                  if (element.isLiked == true) {
                                    element.like.value = true;
                                    element.like.refresh();
                                  }
                                });
                                // controller.filterUsers(
                                //   id: controller.searchSelected.id,
                                //   type: controller.searchSelected.type,
                                // );

                                controller.update();
                                widget.newsFeedcontroller.update();
                              },
                              isSelected: controller.isHiddenPost,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  height: 1,
                  color: Colors.grey[300],
                ),
                SizedBox(
                  height: 20,
                ),
                controller.isFilter == true
                    ? const Center(
                    child: CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    )) : Center(
                  child: Text(
                    Strings.noPosts,
                    style: TextStyle(
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              ],
            ),
          )
              : Theme(
            data: Theme.of(context).brightness ==
                Brightness.dark
                ? Styles.appTheme
                : ThemeData(
              backgroundColor: Colors.black,
              scrollbarTheme: ScrollbarThemeData(
                radius: Radius.circular(10.0),
                thumbColor: MaterialStateProperty.all(
                    Colors.grey),
                trackColor: MaterialStateProperty.all(
                    Color(0xFFf7f9f9)),
                trackBorderColor:
                MaterialStateProperty.all(
                    Color(0xFFf7f9f9)),
                showTrackOnHover: true,
                trackVisibility:
                MaterialStateProperty.all(true),
                thickness: MaterialStateProperty.all(10),
                minThumbLength: 100,
                isAlwaysShown: true,
              ),
            ),
            child: PagedL(
              emptyStateWidget: Text(
                Strings.noPosts,
                style: TextStyle(
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                ),
              ),
              itemBuilder: _itemRow,
              // PostCard(
              //   post: controller?.userPosts[index],
              //   scaffoldKey: _scaffoldKey,
              //   controller:
              //   controller.newsFeedControloler,
              //   // browseController: controller,
              // ),
              padding:
              const EdgeInsets.only(top: 0, bottom: 30, right: 5),
              loadingIndicator: const Padding(
                padding: EdgeInsets.all(16.00),
                child: Center(
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                ),
              ),
              itemDataProvider: _fetchData,
              list: controller.userPosts,
              listSize: _checkPage(controller.userPosts.length),
            ),
          ),
        ),
      );
    });
  }

  //
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    // print("page dfsdfs no $page");
    if (controller.selectedTab == "isTweets") {
      // print("hr;sdfsdfsdf");
      return await controller.filterUsersPostPagged("posts", page: page);
    } else if (controller.selectedTab == "isTweetsReply") {
      return await controller.filterUsersPostPagged("post_commented",
          page: page);
    }
    else if (controller.selectedTab == "isMedia") {
      return await controller.filterUsersPostPagged("media", page: page);
    }
    else if (controller.selectedTab == "isHiddenPost") {

      // print("idhr kkkkkk");
      return await controller.filterUsersPostPaggedForHiddenReplies(page:page);
    }

    else {
      return await controller.filterUsersPostPagged("posts", page: page);
    }
  }

  Widget _itemRow(BuildContext context, Post post) {
    //print("hellovvv");
    int index = controller.userPosts.indexWhere((element) {
      return element.postId == post.postId;
    });

    // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");

    ///all tabs
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        index == 0
            ? SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                clipBehavior: Clip.antiAlias,
                alignment: Alignment.bottomLeft,
                children: [
                  // COVER PHOTO
                  InkWell(
                    hoverColor: Colors.white,
                    onTap: () {
                      showDialog(
                        useSafeArea: false,
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            insetPadding: EdgeInsets.zero,
                            contentPadding: EdgeInsets.zero,
                            content: Stack(
                              children: [
                                Container(
                                  color: Colors.black,
                                  width:
                                  MediaQuery.of(context).size.width,
                                  height:
                                  MediaQuery.of(context).size.height,
                                  child: FadeInImage(
                                    placeholderErrorBuilder:
                                        (context, _, __) {
                                      return Image.asset(
                                          'assets/images/person_placeholder.png');
                                    },
                                    imageErrorBuilder: (context, _, __) {
                                      return Image.asset(
                                          'assets/images/person_placeholder.png');
                                    },
                                    fit: BoxFit.contain,
                                    width: 24,
                                    height: 24,
                                    placeholder: AssetImage(
                                        'assets/images/person_placeholder.png'),
                                    image: controller
                                        .userProfile.coverImage !=
                                        null
                                        ? NetworkImage(controller
                                        .userProfile.coverImage)
                                        : AssetImage(
                                        'assets/images/person_placeholder.png'),
                                  ),
                                ),
                                Positioned(
                                  top: kIsWeb ? 10 : 30,
                                  left: 10,
                                  child: InkWell(
                                    onTap: () {
                                      kIsWeb
                                          ? Navigator.pop(context)
                                          : Get.back();
                                    },
                                    child: Actions(
                                      actions: {
                                        ClearIntent:
                                        CallbackAction<ClearIntent>(
                                            onInvoke: (Intent) =>
                                                Navigator.of(context)
                                                    .pop()),
                                      },
                                      child: Focus(
                                        autofocus: true,
                                        child: Icon(
                                          Icons.cancel,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                    child: Container(
                      width: Get.width,
                      height:
                      kIsWeb ? Get.height / 3.5 : Get.height / 4.5,
                      color: Colors.grey[200],
                      margin: EdgeInsets.only(bottom: Get.height / 15),
                      child: controller.userProfile == null
                          ? SizedBox()
                          : ClipRRect(
                        borderRadius: BorderRadius.circular(0),
                        child: FadeInImage(
                            placeholderErrorBuilder:
                                (context, _, __) {
                              return Image.asset(
                                  'assets/images/person_placeholder.png');
                            },
                            imageErrorBuilder: (context, _, __) {
                              return Image.asset(
                                  'assets/images/person_placeholder.png');
                            },
                            fit: BoxFit.cover,
                            width: 24,
                            height: 24,
                            placeholder: AssetImage(
                                'assets/images/person_placeholder.png'),
                            image: controller
                                .userProfile.coverImage !=
                                null
                                ? NetworkImage(controller
                                .userProfile.coverImage)
                                : AssetImage(
                                'assets/images/person_placeholder.png')),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, right: kIsWeb ? 40.0 : 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        InkWell(
                          hoverColor: Colors.white,
                          onTap: () {
                            showDialog(
                                useSafeArea: false,
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    insetPadding: EdgeInsets.zero,
                                    contentPadding: EdgeInsets.zero,
                                    content: Stack(
                                      children: [
                                        Container(
                                          color: Colors.black,
                                          width: MediaQuery.of(context)
                                              .size
                                              .width,
                                          height: MediaQuery.of(context)
                                              .size
                                              .height,
                                          child: FadeInImage(
                                            placeholderErrorBuilder:
                                                (context, _, __) {
                                              return Image.asset(
                                                  'assets/images/person_placeholder.png');
                                            },
                                            imageErrorBuilder:
                                                (context, _, __) {
                                              return Image.asset(
                                                  'assets/images/person_placeholder.png');
                                            },
                                            fit: BoxFit.contain,
                                            width: 150,
                                            height: 150,
                                            placeholder: AssetImage(
                                                'assets/images/person_placeholder.png'),
                                            image: controller.userProfile
                                                .profileImage !=
                                                null
                                                ? NetworkImage(controller
                                                .userProfile
                                                .profileImage)
                                                : AssetImage(
                                                'assets/images/person_placeholder.png'),
                                          ),
                                        ),
                                        Positioned(
                                          top: kIsWeb ? 10 : 30,
                                          left: 10,
                                          child: InkWell(
                                            onTap: () {
                                              kIsWeb
                                                  ? Navigator.pop(context)
                                                  : Get.back();
                                            },
                                            child: Actions(
                                                actions: {
                                                  ClearIntent: CallbackAction<
                                                      ClearIntent>(
                                                      onInvoke: (Intent) =>
                                                          Navigator.of(
                                                              context)
                                                              .pop()),
                                                },
                                                child: Focus(
                                                  autofocus: true,
                                                  child: Icon(
                                                    Icons.cancel,
                                                    color: Colors.white,
                                                  ),
                                                )),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                });
                          },
                          child: CircleAvatar(
                            radius: kIsWeb ? 80 : 70,
                            backgroundColor: Colors.white,
                            child: CircleAvatar(
                              radius: kIsWeb ? 75 : 65,
                              backgroundColor: Colors.white,
                              child: controller.userProfile == null
                                  ? CircularProgressIndicator(
                                color: MyColors.BlueColor,
                              )
                                  : ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                      kIsWeb ? 80 : 70),
                                  child: controller.userProfile
                                      .profileImage !=
                                      null
                                      ? Image.network(
                                    controller.userProfile
                                        .profileImage,
                                    fit: BoxFit.cover,
                                    width: 150,
                                    height: 150,
                                  )
                                      : Image.asset(
                                    'assets/images/person_placeholder.png',
                                    fit: BoxFit.cover,
                                    width: 150,
                                    height: 150,
                                  )

                                //     FadeInImage(
                                //   placeholderErrorBuilder:
                                //       (context, _, __) {
                                //     return Image.asset(
                                //         'assets/images/person_placeholder.png');
                                //   },
                                //   imageErrorBuilder:
                                //       (context, _, __) {
                                //     return Image.asset(
                                //         'assets/images/person_placeholder.png');
                                //   },
                                //   fit: BoxFit.cover,
                                //   width: 150,
                                //   height: 150,
                                //   placeholder: AssetImage(
                                //       'assets/images/person_placeholder.png'),
                                //   image: NetworkImage(controller.userProfile.profileImage != null ? controller.userProfile.profileImage
                                //       : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                // ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: Align(
                      alignment: Alignment.topRight,
                      child: ElevatedButton(
                        onPressed: () {
                          controller.isProfile = true;
                          controller.selectedView = "isProfile";
                          controller.isCover = false;
                          controller.isBio = false;
                          controller.profileImage = null;
                          controller.coverImage = null;
                          controller.bioText.text =
                              controller.userProfile.bio;
                          controller.usernameText.text =
                              controller.userProfile.firstname +
                                  controller.userProfile.lastname;

                          controller.update();
                          if (kIsWeb) {
                            showProfileDialog(
                                context,
                                // controller,
                                Get.width,
                                Get.height);
                          } else {
                            Get.to(EditProfileWidget());
                          }
                          controller.dob = true;
                        },
                        child: Text(
                          Strings.editProfile,
                          // style: Theme.of(context).brightness == Brightness.dark ?
                          // TextStyle(
                          //     color: Colors.white,
                          //     fontWeight: FontWeight.bold,
                          //
                          //
                          // )
                          //     : TextStyle(  color: Colors.black,fontSize: 18,fontWeight: FontWeight.bold
                          // ),
                          style: TextStyle(
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                            primary: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.black
                                : Colors.white,
                            shape: StadiumBorder(),
                            side: BorderSide(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                width: 2.0),
                            // color: Colorss.yellow,
                            elevation: 0.0,
                            padding: kIsWeb
                                ? EdgeInsets.symmetric(
                                horizontal: 25.0, vertical: 20.0)
                                : EdgeInsets.symmetric(
                                horizontal: 15.0, vertical: 10.0)),
                      ),
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 20.0, top: 2, bottom: 0, right: 20.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: kIsWeb ? 250 : 150,
                              child: Text(
                                controller.userProfile == null
                                    ? ""
                                    : "${controller.userProfile.firstname + " " + controller.userProfile.lastname}",
                                // textAlign: TextAlign.start,
                                maxLines: 1,
                                overflow: controller.userProfile.firstname
                                    .length +
                                    controller.userProfile
                                        .lastname.length >
                                    30
                                    ? TextOverflow.ellipsis
                                    : null,
                                style: Styles.baseTextTheme.headline2
                                    .copyWith(
                                  color: Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                                // TextStyle(
                                //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                //   fontSize: kIsWeb ? 20.0 : 18,
                                //   height: 1.5,
                                //   fontWeight: FontWeight.bold,
                                // )
                              ),
                            ),
                            // SizedBox(
                            //   width: 5,
                            // ),
                            controller.userProfile.accountVerified ==
                                "verified"
                                ? Padding(
                              padding:
                              const EdgeInsets.only(top: 3.0),
                              child: BlueTick(
                                height: 20,
                                width: 20,
                                iconSize: 14,
                              ),
                            )
                                : SizedBox(),
                          ],
                        ),

                        SizedBox(
                          height: 5,
                        ),
                        Text(
                          controller.userProfile == null
                              ? ""
                              : "@${controller.userProfile.username}",
                          style: Styles.baseTextTheme.headline5.copyWith(
                            fontWeight: FontWeight.w400,
                          ),
                          // TextStyle(
                          //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                          //   fontSize: kIsWeb ? 18.0 : 16.0,
                          //  fontWeight: FontWeight.w400,
                          // ),
                        ),
                        controller.userProfile == null
                            ? SizedBox()
                            : controller.userProfile.bio == null
                            ? SizedBox()
                            : Text(
                          "${controller.userProfile.bio}",
                          style: Styles.baseTextTheme.headline5
                              .copyWith(
                            color:
                            Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.w400,
                          ),
                          // TextStyle(
                          //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          //   fontSize: kIsWeb ? 18.0 : 16.0,
                          //   fontWeight: FontWeight.w400,
                          //
                          // )
                        ),

                        SizedBox(
                          height: 5,
                        ),

                        /// dob
                        controller.userProfile == null
                            ? SizedBox()
                            : controller.userProfile.dob == null
                            ? SizedBox()
                            : Row(
                          children: [
                            Icon(
                              Icons.calendar_today_outlined,
                              color: Color(0xFF586976),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            Text(
                              "${controller.userProfile.dob.replaceAll(RegExp(r"\s+"), " ")}",
                              style: Styles
                                  .baseTextTheme.headline5
                                  .copyWith(
                                fontWeight: FontWeight.w400,
                              ),
                              // TextStyle(
                              //     color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                              //     fontSize: kIsWeb ? 18.0 : 16.0,
                              //     fontWeight: FontWeight.w400,
                              // ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            InkWell(
                              onTap: kIsWeb
                                  ? () {
                                if (kIsWeb) {
                                  // For Follow Tab: On web if any action like follow or unfollow is done on the second tab
                                  // its resetting the tab index to 0.
                                  // To avoid that we save the current tab index and apply it when the page reloads
                                  // Here we reset the index to 0. we have to show the first tab when user enters the page freshly
                                  widget.newsFeedcontroller
                                      .followTabIndex = 0;
                                }
                                /* onProfileChange = false;
                                                  print(
                                                      "agiya hai  ${onProfileChange}");
                                                  Get.put(FollowerController());

                                                  Get.find<FollowerController>().getFollower(userId: GetStorage().read('id'));
                                                  Get.find<FollowerController>().getFollowing(userId: GetStorage().read('id'));
                                                  Get.find<FollowerController>()
                                                      .followingCheck = 1;
                                                  Get.find<FollowerController>()
                                                      .update();
                                                  controller.isSearch = false;
                                                  controller.isFilter = false;
                                                  newsFeedcontroller
                                                      .isFilterScreen = false;
                                                  newsFeedcontroller
                                                      .isTrendsScreen = false;
                                                  newsFeedcontroller
                                                      .isNewsFeedScreen = false;
                                                  newsFeedcontroller
                                                      .isBrowseScreen = false;
                                                  newsFeedcontroller
                                                      .isNotificationScreen = false;
                                                  newsFeedcontroller
                                                      .isSavedPostScreen = false;
                                                  newsFeedcontroller.isChatScreen =
                                                      false;
                                                  newsFeedcontroller.isPostDetails =
                                                      false;
                                                  newsFeedcontroller
                                                      .isProfileScreen = false;
                                                  newsFeedcontroller
                                                          .isOtherUserProfileScreen =
                                                      false;
                                                  newsFeedcontroller
                                                      .isFollwerScreen = true;

                                                  newsFeedcontroller.navRoute =
                                                      "isProfileScreen";
                                                  newsFeedcontroller.update();*/
                                Get.put(FollowerController());
                                Get.find<FollowerController>()
                                    .getFollower(
                                    userId:
                                    GetStorage().read('id'),
                                    isFromRoute: true);
                                Get.find<FollowerController>()
                                    .getFollowing(
                                    userId:
                                    GetStorage().read('id'),
                                    isFromRoute: true);
                                Get.find<FollowerController>()
                                    .followingCheck = 1;
                                Get.find<FollowerController>()
                                    .update();
                                Get.toNamed(
                                    FluroRouters.mainScreen +
                                        "/followings/" +
                                        GetStorage()
                                            .read('id')
                                            .toString());
                              }
                                  : () {
                                Get.put(FollowerController());
                                Get.find<FollowerController>()
                                    .getFollower(
                                    userId: GetStorage()
                                        .read('id'));
                                Get.find<FollowerController>()
                                    .getFollowing(
                                    userId: GetStorage()
                                        .read('id'));
                                Get.find<FollowerController>()
                                    .followingCheck = 1;
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext
                                        context) =>
                                            FollowerScreen(
                                              isOtherUserProfile:
                                              false,
                                              controller:
                                              widget.newsFeedcontroller,
                                            )));

                                Get.find<FollowerController>()
                                    .update();
                              },
                              child: Row(
                                children: [
                                  Text(
                                    controller.userProfile == null
                                        ? ""
                                        : "${controller.userProfile.followings} ",
                                    style: Styles.baseTextTheme.headline1
                                        .copyWith(
                                      color:
                                      Theme.of(context).brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 16.0 : 14.0,
                                    ),
                                    // TextStyle(
                                    //   color: Theme.of(context).brightness == Brightness.dark
                                    //       ? Colors.white
                                    //       : Colors.black,
                                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                                    //   fontWeight: FontWeight.bold,
                                    //
                                    // ),
                                  ),
                                  Text(
                                    controller.userProfile == null
                                        ? ""
                                        : Strings.followings,
                                    style: Styles.baseTextTheme.headline2
                                        .copyWith(
                                      fontSize: kIsWeb ? 16.0 : 14.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    // TextStyle(
                                    //   color: Theme.of(context).brightness == Brightness.dark
                                    //       ? Color(0xFF586976)
                                    //       : Color(0xFF586976),
                                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                                    //   fontWeight: FontWeight.bold,
                                    //
                                    // ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 15,
                            ),
                            InkWell(
                              onTap: kIsWeb
                                  ? () {
                                if (kIsWeb) {
                                  // For Follow Tab: On web if any action like follow or unfollow is done on the second tab
                                  // its resetting the tab index to 0.
                                  // To avoid that we save the current tab index and apply it when the page reloads
                                  // Here we reset the index to 0. we have to show the first tab when user enters the page freshly
                                  widget.newsFeedcontroller
                                      .followTabIndex = 0;
                                }

                                Get.put(FollowerController());
                                Get.find<FollowerController>()
                                    .getFollower(
                                    userId:
                                    GetStorage().read('id'),
                                    isFromRoute: true);
                                Get.find<FollowerController>()
                                    .getFollowing(
                                    userId:
                                    GetStorage().read('id'),
                                    isFromRoute: true);
                                Get.find<FollowerController>()
                                    .followingCheck = 0;
                                Get.find<FollowerController>()
                                    .update();
                                Get.toNamed(
                                    FluroRouters.mainScreen +
                                        "/followers/" +
                                        GetStorage()
                                            .read('id')
                                            .toString());
                              }
                                  : () {
                                Get.put(FollowerController());
                                Get.find<FollowerController>()
                                    .getFollower(
                                    userId: GetStorage()
                                        .read('id'));
                                Get.find<FollowerController>()
                                    .getFollowing(
                                    userId: GetStorage()
                                        .read('id'));
                                Get.find<FollowerController>()
                                    .followingCheck = 0;
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext
                                        context) =>
                                            FollowerScreen(
                                              controller:
                                              widget.newsFeedcontroller,
                                            )));
                                Get.find<FollowerController>()
                                    .update();
                              },
                              child: Row(
                                children: [
                                  Text(
                                    controller.userProfile == null
                                        ? ""
                                        : "${controller.userProfile.followers} ",
                                    style: Styles.baseTextTheme.headline1
                                        .copyWith(
                                      color:
                                      Theme.of(context).brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: kIsWeb ? 16.0 : 14.0,
                                    ),
                                    // TextStyle(
                                    //   color: Theme.of(context).brightness == Brightness.dark
                                    //       ? Colors.white
                                    //       : Colors.black,
                                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                                    //   fontWeight: FontWeight.bold,
                                    //
                                    // ),
                                  ),
                                  Text(
                                    controller.userProfile == null
                                        ? ""
                                        : Strings.followers,
                                    // style: Theme.of(context).brightness == Brightness.dark ?
                                    // TextStyle(color: Colors.white,fontSize: kIsWeb ? 18.0 : 14.0,
                                    //
                                    // )
                                    //     : TextStyle(  color: Colors.black,fontSize: kIsWeb ? 18.0 : 14.0,
                                    // ),
                                    style: Styles.baseTextTheme.headline2
                                        .copyWith(
                                      fontSize: kIsWeb ? 16.0 : 14.0,
                                      fontWeight: FontWeight.w500,
                                    ),
                                    // TextStyle(
                                    //   color: Theme.of(context).brightness == Brightness.dark
                                    //       ? Color(0xFF586976)
                                    //       : Color(0xFF586976),
                                    //   fontSize: kIsWeb ? 18.0 : 16.0,
                                    //  fontWeight: FontWeight.bold,
                                    //
                                    //
                                    // ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 15,
                        ),
                      ],
                    ),
                  ),

                  /// idhar hai TabButton
                  kIsWeb
                      ? Container(
                    child: FittedBox(
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: [
                          TabButton(
                            title: Strings.werfs,
                            onTap: () async {
                              controller.isHiddenPost = false;
                              controller.isTweets = true;
                              controller.isTweetsReply = false;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab = "isTweets";
                              await controller
                                  .filterUsersPost("posts");
                              controller.update();
                              // newsFeedcontroller.update();
                            },
                            isSelected: controller.isTweets,
                          ),
                          TabButton(
                            title: Strings.tweetsAndReplies,
                            onTap: () async {
                              print("jjjasda");
                              controller.isTweets = false;
                              controller.isHiddenPost = false;
                              controller.isTweetsReply = true;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab =
                              "isTweetsReply";

                              await controller.filterUsersPost(
                                  "post_commented");

                              controller.update();
                              // newsFeedcontroller.update();
                            },
                            isSelected: controller.isTweetsReply,
                          ),
                          TabButton(
                            title: Strings.media,
                            onTap: () async {
                              controller.isTweets = false;
                              controller.isHiddenPost = false;
                              controller.isTweetsReply = false;
                              controller.isMedia = true;
                              controller.isLikes = false;
                              controller.selectedTab = "isMedia";
                              await controller
                                  .filterUsersPost("media");
                              controller.update();
                            },
                            isSelected: controller.isMedia,
                          ),
                          TabButton(
                            title: Strings.likes,
                            onTap: () async {
                              controller.isTweets = false;
                              controller.isTweetsReply = false;
                              controller.isHiddenPost = false;
                              controller.isMedia = false;
                              controller.isLikes = true;
                              controller.selectedTab = "isLikes";
                              controller.userPosts =
                              await controller
                                  .filterUsersPost("likes");

                              controller.update();
                            },
                            isSelected: controller.isLikes,
                          ),
                          TabButton(
                            title: Strings.hiddenPost,
                            onTap: () async {
                              controller.isHiddenPost = true;
                              controller.isTweets = false;
                              controller.isTweetsReply = false;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab = "isHiddenPost";
                              controller.userPosts = await controller.filterUsersPostForHiddenReplies(page: 1);
                              print("hidden asdasda");
                              controller.update();

                            },
                            isSelected: controller.isHiddenPost,
                          ),
                        ],
                      ),
                    ),
                  )
                      : Container(
                    child: FittedBox(
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceEvenly,
                        children: [
                          TabButton(
                            title: Strings.werfs,
                            onTap: () async {
                              controller.isHiddenPost = false;
                              controller.isTweets = true;
                              controller.isTweetsReply = false;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab = "isTweets";

                              controller.userPosts =
                              await controller
                                  .filterUsersPost("posts");
                              controller.userPosts
                                  .forEach((element) {
                                element.likeCount.value =
                                    element.simpleLikeCount;
                                element.rebuzzCount.value =
                                    element.retweetCount;
                                element.commentCount.value =
                                    element.commentsCount;
                                if (element.isLiked == true) {
                                  element.like.value = true;
                                  element.like.refresh();
                                }
                              });
                              // controller.filterUsersPost(
                              //   id: controller.searchSelected.id,
                              //   type: controller.searchSelected.type,
                              // );

                              controller.update();
                              widget.newsFeedcontroller.update();
                            },
                            isSelected: controller.isTweets,
                          ),
                          TabButton(
                            title: Strings.tweetsAndReplies,
                            onTap: () async {
                              controller.isTweets = false;
                              controller.isHiddenPost = false;
                              controller.isTweetsReply = true;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab =
                              "isTweetsReply";

                              controller.userPosts =
                              await controller.filterUsersPost(
                                  "post_commented");
                              controller.userPosts
                                  .forEach((element) {
                                element.likeCount.value =
                                    element.simpleLikeCount;
                                element.rebuzzCount.value =
                                    element.retweetCount;
                                element.commentCount.value =
                                    element.commentsCount;
                                if (element.isLiked == true) {
                                  element.like.value = true;
                                  element.like.refresh();
                                }
                              });
                              // controller.filterUsers(
                              //   id: controller.searchSelected.id,
                              //   type: controller.searchSelected.type,
                              // );

                              controller.update();
                              widget.newsFeedcontroller.update();
                            },
                            isSelected: controller.isTweetsReply,
                          ),
                          TabButton(
                            title: Strings.media,
                            onTap: () async {
                              controller.isTweets = false;
                              controller.isHiddenPost = false;
                              controller.isTweetsReply = false;
                              controller.isMedia = true;
                              controller.isLikes = false;
                              controller.selectedTab = "isMedia";

                              controller.userPosts =
                              await controller
                                  .filterUsersPost("media");
                              controller.userPosts
                                  .forEach((element) {
                                element.likeCount.value =
                                    element.simpleLikeCount;
                                element.rebuzzCount.value =
                                    element.retweetCount;
                                element.commentCount.value =
                                    element.commentsCount;
                                if (element.isLiked == true) {
                                  element.like.value = true;
                                  element.like.refresh();
                                }
                              });
                              // controller.filterUsers(
                              //   id: controller.searchSelected.id,
                              //   type: controller.searchSelected.type,
                              // );

                              controller.update();
                              widget.newsFeedcontroller.update();
                            },
                            isSelected: controller.isMedia,
                          ),
                          TabButton(
                            title: Strings.likes,
                            onTap: () async {
                              controller.isTweets = false;
                              controller.isTweetsReply = false;
                              controller.isHiddenPost = false;
                              controller.isMedia = false;
                              controller.isLikes = true;
                              controller.selectedTab = "isLikes";
                              controller.userPosts =
                              await controller
                                  .filterUsersPost("likes");
                              controller.userPosts
                                  .forEach((element) {
                                element.likeCount.value =
                                    element.simpleLikeCount;
                                element.rebuzzCount.value =
                                    element.retweetCount;
                                element.commentCount.value =
                                    element.commentsCount;
                                if (element.isLiked == true) {
                                  element.like.value = true;
                                  element.like.refresh();
                                }
                              });
                              // controller.filterUsers(
                              //   id: controller.searchSelected.id,
                              //   type: controller.searchSelected.type,
                              // );

                              controller.update();
                              widget.newsFeedcontroller.update();
                            },
                            isSelected: controller.isLikes,
                          ),
                          TabButton(
                            title: Strings.hiddenPost,
                            onTap: () async {
                              controller.isHiddenPost = true;
                              controller.isTweets = false;
                              controller.isTweetsReply = false;
                              controller.isMedia = false;
                              controller.isLikes = false;
                              controller.selectedTab = "isHiddenPost";
                              controller.userPosts = await controller.filterUsersPostForHiddenReplies(page: 1);
                              controller.update();
                              widget.newsFeedcontroller.update();
                            },
                            isSelected: controller.isHiddenPost,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              // SizedBox(
              //   height: kIsWeb
              //       ? MediaQuery.of(context).size.height * 0.82
              //       : MediaQuery.of(context).size.height * 0.8,
              //   child:
              // ),
              //
            ],
          ),
        )
            : SizedBox(),
        post.pinPost == 1
            ? Row(
          children: [
            Icon(Icons.push_pin),
            SizedBox(
              width: 5,
            ),
            Text(
              Strings.pinnedWerf,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
              ),
            ),
          ],
        )
            : SizedBox(),
        controller.userPosts[index].type == 'thread'
            ? ThreadPostCard(
          postList: controller.userPosts,
          index: index,
          post: controller.userPosts[index],
          scaffoldKey: _scaffoldKey,
          controller: widget.newsFeedcontroller,
          deletePostId: controller.deletePostId,
        )
            : PostCard(
          postList: controller.userPosts,
          index: index,
          post: controller.userPosts[index],
          scaffoldKey: _scaffoldKey,
          controller: widget.newsFeedcontroller,
          deletePostId: controller.deletePostId,
          userProfileHideWerfCheck: controller.isHiddenPost,
        ),
      ],
    );
  }
}

showProfileDialog(
    BuildContext context,
    // controller,
    width,
    height,
    ) {
  return showDialog(
    barrierDismissible: false,
    context: context,
    builder: (context) {
      // ignore: unused_local_variable
      bool isUserNameExisting = false;
      // ignore: unused_local_variable
      String contentText = Strings.contentOfDialog;
      return GetBuilder<ProfileController>(builder: (controller) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Shortcuts(
              shortcuts: {
                LogicalKeySet(LogicalKeyboardKey.escape): EscEditProfileIntent()
              },
              child: AlertDialog(
                insetPadding: EdgeInsets.zero,
                contentPadding: EdgeInsets.zero,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(25.0))),
                content: Container(
                  height: 700,
                  width: 600,
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(25),
                      child: EditProfileWidget()),
                  // child: Scaffold(
                  //   backgroundColor: Colors.white,
                  //   appBar: AppBar(
                  //     backgroundColor: Colors.white,
                  //     centerTitle: false,
                  //     title:  Text("Edit profile",style: Get.textTheme.headline3.copyWith(
                  //       color: Colors.black,
                  //     )),
                  //
                  //     actions: [
                  //       Padding(padding: const EdgeInsets.all(10),
                  //         child: ElevatedButton(
                  //             style: ElevatedButton.styleFrom(
                  //               elevation: 0.5,
                  //               backgroundColor: Colors.black,
                  //               shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  //             ),
                  //             onPressed: (){},
                  //             child: Text("Save",style: Get.textTheme.headline3.copyWith(color: Colors.white),)
                  //         ),
                  //       ),
                  //     ],
                  //     leading: IconButton(
                  //       // highlightColor: Colors.transparent,
                  //       // hoverColor: Colors.transparent,
                  //       // focusColor: Colors.transparent,
                  //       onPressed: () {
                  //         // controller.isProfile = false;
                  //         // controller.isCover = false;
                  //         // controller.isBio = false;
                  //         // controller.isUsername = false;
                  //         // controller.selectedView = "";
                  //         // controller.update();
                  //         Navigator.of(context).pop();
                  //       },
                  //       icon: Icon(Icons.close, size: 15,color: Colors.black,),
                  //     ),
                  //     // SizedBox(width: width / 20),
                  //     // SvgPicture.asset(
                  //     //   AppImages.logo,
                  //     //   width: kIsWeb ? width / 10 : 120,
                  //     //   // height: 150,
                  //     //   // color: Color((0xFF47b867)),
                  //     // ),
                  //     // // Image(
                  //     // //   image:
                  //     // //   AssetImage("assets/images/Logo_werfie.png"),
                  //     // //   // height: kIsWeb ? width / 10 : 80,
                  //     // //   width: kIsWeb ? width / 10 : 120,
                  //     // //   fit: BoxFit.contain,
                  //     // // )
                  //   ),
                  //   body: SingleChildScrollView(
                  //     child: Column(
                  //       crossAxisAlignment: CrossAxisAlignment.start,
                  //       mainAxisAlignment: MainAxisAlignment.start,
                  //       children: [
                  //         // Align(
                  //         //   alignment: Alignment.topLeft,
                  //         //   child: Row(
                  //         //     crossAxisAlignment: CrossAxisAlignment.center,
                  //         //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //         //     children: [
                  //         //      Row(
                  //         //        children: [
                  //         //          IconButton(
                  //         //            // highlightColor: Colors.transparent,
                  //         //            // hoverColor: Colors.transparent,
                  //         //            // focusColor: Colors.transparent,
                  //         //            onPressed: () {
                  //         //              // controller.isProfile = false;
                  //         //              // controller.isCover = false;
                  //         //              // controller.isBio = false;
                  //         //              // controller.isUsername = false;
                  //         //              // controller.selectedView = "";
                  //         //              // controller.update();
                  //         //              Navigator.of(context).pop();
                  //         //            },
                  //         //            icon: Icon(Icons.close, size: MediaQuery.of(context).size.width >= 1200 ? 36 : 24,color: Colors.black,),
                  //         //          ),
                  //         //          SizedBox(width: width / 20),
                  //         //          Text("Edit profile",style: Get.textTheme.headline3.copyWith(
                  //         //            color: Colors.black,
                  //         //          )),
                  //         //        ],
                  //         //      ),
                  //         //       ElevatedButton(
                  //         //         style: ElevatedButton.styleFrom(
                  //         //           elevation: 0.5,
                  //         //           backgroundColor: Colors.black,
                  //         //           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  //         //         ),
                  //         //           onPressed: (){},
                  //         //           child: Text("Save",style: Get.textTheme.headline3.copyWith(color: Colors.white),)
                  //         //       ),
                  //         //
                  //         //       // SvgPicture.asset(
                  //         //       //   AppImages.logo,
                  //         //       //   width: kIsWeb ? width / 10 : 120,
                  //         //       //   // height: 150,
                  //         //       //   // color: Color((0xFF47b867)),
                  //         //       // ),
                  //         //       // // Image(
                  //         //       // //   image:
                  //         //       // //   AssetImage("assets/images/Logo_werfie.png"),
                  //         //       // //   // height: kIsWeb ? width / 10 : 80,
                  //         //       // //   width: kIsWeb ? width / 10 : 120,
                  //         //       // //   fit: BoxFit.contain,
                  //         //       // // )
                  //         //     ],
                  //         //   ),
                  //         // ),
                  //         Stack(
                  //           clipBehavior: Clip.antiAlias,
                  //           alignment: Alignment.bottomLeft,
                  //           children: [
                  //             // COVER PHOTO
                  //
                  //                 // showDialog(
                  //                 //   useSafeArea: false,
                  //                 //   context: context,
                  //                 //   builder: (context) {
                  //                 //     return AlertDialog(
                  //                 //       insetPadding: EdgeInsets.zero,
                  //                 //       contentPadding: EdgeInsets.zero,
                  //                 //       content: Stack(
                  //                 //         children: [
                  //                 //           Container(
                  //                 //             color: Colors.black,
                  //                 //             width:
                  //                 //             MediaQuery.of(context).size.width,
                  //                 //             height: MediaQuery.of(context)
                  //                 //                 .size
                  //                 //                 .height,
                  //                 //             child: FadeInImage(
                  //                 //               placeholderErrorBuilder:
                  //                 //                   (context, _, __) {
                  //                 //                 return Image.asset(
                  //                 //                     'assets/images/person_placeholder.png');
                  //                 //               },
                  //                 //               imageErrorBuilder:
                  //                 //                   (context, _, __) {
                  //                 //                 return Image.asset(
                  //                 //                     'assets/images/person_placeholder.png');
                  //                 //               },
                  //                 //               fit: BoxFit.contain,
                  //                 //               width: 24,
                  //                 //               height: 24,
                  //                 //               placeholder: AssetImage(
                  //                 //                   'assets/images/person_placeholder.png'),
                  //                 //               image: NetworkImage(controller
                  //                 //                   .userProfile
                  //                 //                   .coverImage !=
                  //                 //                   null
                  //                 //                   ? controller
                  //                 //                   .userProfile.coverImage
                  //                 //                   : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                  //                 //             ),
                  //                 //           ),
                  //                 //           Positioned(
                  //                 //             top: 30,
                  //                 //             left: 10,
                  //                 //             child: InkWell(
                  //                 //               onTap: () {
                  //                 //                 Get.back();
                  //                 //               },
                  //                 //               child: Icon(Icons.arrow_back),
                  //                 //             ),
                  //                 //           ),
                  //                 //         ],
                  //                 //       ),
                  //                 //     );
                  //                 //   },
                  //                 // );
                  //              // Container(
                  //              //    width: width,
                  //              //    height: height / 3.5,
                  //              //    color: Colors.grey,
                  //              //    // margin: EdgeInsets.only(bottom: height / 15),
                  //              //    child: controller.coverImage == null?
                  //              //    Center(
                  //              //      child:InkWell(
                  //              //      onTap: () async{
                  //              //        controller.coverImage =
                  //              //        await controller.callGetImage();
                  //              //        controller.update;
                  //              //      },
                  //              //      child: Container(
                  //              //        padding: const EdgeInsets.all(20),
                  //              //        decoration: BoxDecoration(
                  //              //          color: Colors.grey[600],
                  //              //          shape: BoxShape.circle,
                  //              //        ),
                  //              //        child: Icon(Icons.camera_alt_outlined,color: Colors.white,),
                  //              //      ),
                  //              //    ),)
                  //              //        :Stack(
                  //              //      children: [
                  //              //        Container(
                  //              //          width: width,
                  //              //          height: height / 3.5,
                  //              //          color: Colors.grey,
                  //              //          child: controller.coverImage !=
                  //              //              null
                  //              //              ? Image.memory(
                  //              //            controller.coverImage,
                  //              //            fit: BoxFit.cover,
                  //              //          )
                  //              //              : controller.userProfile ==
                  //              //              null
                  //              //              ? SizedBox()
                  //              //              :
                  //              //          // controller.userProfile
                  //              //          //             .coverImage ==
                  //              //          //         null
                  //              //          //     ?
                  //              //          //     :
                  //              //          ClipRRect(borderRadius: BorderRadius.circular(0),
                  //              //            child: FadeInImage(
                  //              //                fit: BoxFit
                  //              //                    .cover,
                  //              //                width: 24,
                  //              //                height: 24,
                  //              //                placeholder:
                  //              //                AssetImage(
                  //              //                    'assets/images/person_placeholder.png'),
                  //              //                image: NetworkImage(controller
                  //              //                    .userProfile
                  //              //                    .coverImage !=
                  //              //                    null
                  //              //                    ? controller
                  //              //                    .userProfile
                  //              //                    .coverImage
                  //              //                    : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //              //          ),
                  //              //        ),
                  //              //        Positioned(
                  //              //          top: 100,
                  //              //          left: 340,
                  //              //          child: InkWell(
                  //              //            onTap: () async{
                  //              //              controller.coverImage =
                  //              //                  await controller.callGetImage();
                  //              //              controller.update;
                  //              //            },
                  //              //            child: Container(
                  //              //              padding: const EdgeInsets.all(20),
                  //              //              decoration: BoxDecoration(
                  //              //                color: Colors.grey[600],
                  //              //                shape: BoxShape.circle,
                  //              //              ),
                  //              //              child: Icon(Icons.camera_alt_outlined,color: Colors.white,),
                  //              //            ),
                  //              //          ),
                  //              //        ),
                  //              //      ],
                  //              //    ),
                  //              //    // child:
                  //              //    // controller.userProfile == null
                  //              //    //     ? SizedBox()
                  //              //    //     : ClipRRect(
                  //              //    //   borderRadius: BorderRadius.circular(0),
                  //              //    //   child: FadeInImage(
                  //              //    //     placeholderErrorBuilder:
                  //              //    //         (context, _, __) {
                  //              //    //       return Image.asset(
                  //              //    //           'assets/images/person_placeholder.png');
                  //              //    //     },
                  //              //    //     imageErrorBuilder: (context, _, __) {
                  //              //    //       return Image.asset(
                  //              //    //           'assets/images/person_placeholder.png');
                  //              //    //     },
                  //              //    //     fit: BoxFit.cover,
                  //              //    //     width: 24,
                  //              //    //     height: 24,
                  //              //    //     placeholder: AssetImage(
                  //              //    //         'assets/images/person_placeholder.png'),
                  //              //    //     image: NetworkImage(controller
                  //              //    //         .userProfile.coverImage !=
                  //              //    //         null
                  //              //    //         ? controller.userProfile.coverImage
                  //              //    //         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                  //              //    //   ),
                  //              //    // ),
                  //              //  ),
                  //             Container(
                  //               width: width,
                  //               height: height / 3.5,
                  //               color: Colors.grey,
                  //               margin: EdgeInsets.only(bottom: height / 15),
                  //               child:
                  //               controller.coverImage == null?
                  //               Center(
                  //                 child: InkWell(
                  //                   onTap: () async{
                  //                     controller.coverImage =
                  //                     await controller.callGetImage();
                  //                     controller.update();
                  //                   },
                  //                   child: Container(
                  //
                  //                     height: 50,
                  //                     width: 50,
                  //                     alignment: Alignment.center,
                  //                     padding: const EdgeInsets.all(13),
                  //                     decoration: BoxDecoration(
                  //                       color: Colors.grey[600],
                  //                       shape: BoxShape.circle,
                  //                     ),
                  //                     child: Icon(Icons.camera_alt_outlined,size: 25,color: Colors.white,),
                  //                   ),
                  //
                  //                 ),
                  //               ):
                  //               Stack(
                  //                 children: [
                  //                   Container(
                  //                     width: width,
                  //                     height: Get.height,
                  //                     color: Colors.grey,
                  //                     // margin: EdgeInsets.only(bottom: height / 15),
                  //                     child: controller.coverImage !=
                  //                         null?
                  //                     Image.memory(
                  //                       controller.coverImage,
                  //                       fit: BoxFit.cover,
                  //                     )
                  //                         : controller.userProfile ==
                  //                         null
                  //                         ? SizedBox()
                  //                         : // controller.userProfile
                  //                     //             .coverImage ==
                  //                     //         null
                  //                     //     ?
                  //                     //     :
                  //                     ClipRRect(borderRadius: BorderRadius.circular(0),
                  //                       child: FadeInImage(
                  //                           fit: BoxFit
                  //                               .cover,
                  //                           // width: 24,
                  //                           // height: 24,
                  //                           placeholder:
                  //                           AssetImage(
                  //                               'assets/images/person_placeholder.png'),
                  //                           image: NetworkImage(controller
                  //                               .userProfile
                  //                               .coverImage !=
                  //                               null
                  //                               ? controller
                  //                               .userProfile
                  //                               .coverImage
                  //                               : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //                     ),
                  //                   ),
                  //                   Positioned(
                  //                       left: 185,
                  //                       top: 40,
                  //                       child:
                  //                       InkWell(
                  //                         onTap: () async{
                  //                           controller.coverImage =
                  //                           await controller.callGetImage();
                  //                           controller.update();
                  //                         },
                  //                         child: Container(
                  //                           height: 50,
                  //                           width: 50,
                  //                           alignment: Alignment.center,
                  //                           padding: const EdgeInsets.all(13),
                  //                           decoration: BoxDecoration(
                  //                             color: Colors.white,
                  //                             shape: BoxShape.circle,
                  //                           ),
                  //                           child: Icon(Icons.camera_alt_outlined,size: 25,color: Colors.white,),
                  //
                  //                         ),
                  //
                  //                       )),
                  //                 ],
                  //               ),
                  //               // child: controller.userProfile == null
                  //               //     ? SizedBox()
                  //               //     : ClipRRect(
                  //               //   borderRadius: BorderRadius.circular(0),
                  //               //   child: FadeInImage(
                  //               //     placeholderErrorBuilder:
                  //               //         (context, _, __) {
                  //               //       return Image.asset(
                  //               //           'assets/images/person_placeholder.png');
                  //               //     },
                  //               //     imageErrorBuilder: (context, _, __) {
                  //               //       return Image.asset(
                  //               //           'assets/images/person_placeholder.png');
                  //               //     },
                  //               //     fit: BoxFit.cover,
                  //               //     width: 24,
                  //               //     height: 24,
                  //               //     placeholder: AssetImage(
                  //               //         'assets/images/person_placeholder.png'),
                  //               //     image: NetworkImage(controller
                  //               //         .userProfile.coverImage !=
                  //               //         null
                  //               //         ? controller.userProfile.coverImage
                  //               //         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                  //               //   ),
                  //               // ),
                  //             ),
                  //             Padding(
                  //               padding: const EdgeInsets.only(
                  //                   left: 20.0, right: kIsWeb ? 40.0 : 20.0),
                  //               child: Row(
                  //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //                 crossAxisAlignment: CrossAxisAlignment.end,
                  //                 children: [
                  //                   CircleAvatar(
                  //                     radius: 85,
                  //                     // backgroundColor: Theme.of(context).colorScheme.secondary,
                  //                     backgroundColor: Colors.blue,
                  //                     child: CircleAvatar(
                  //                       radius: 80,
                  //                       backgroundColor: Colors.grey,
                  //                       child: Container(
                  //                         alignment: Alignment.center,
                  //                         decoration: BoxDecoration(
                  //                           color: Colors.grey,
                  //                           borderRadius: BorderRadius.circular(80),
                  //                         ),
                  //                         child: Stack(
                  //                           children: [
                  //                             Container(
                  //                               decoration: BoxDecoration(
                  //                                 color: Colors.grey,
                  //                                 borderRadius: BorderRadius.circular(80),
                  //                               ),
                  //                               child: controller.profileImage != null
                  //                                   ? CircleAvatar(
                  //                                 radius: 80,
                  //                                 backgroundImage: MemoryImage(
                  //                                     controller.profileImage),
                  //                                 backgroundColor: Colors.grey,
                  //                               )
                  //                                   : controller.userProfile == null
                  //                                   ? CircularProgressIndicator()
                  //                                   : ClipRRect(
                  //                                 borderRadius:
                  //                                 BorderRadius.circular(
                  //                                     80),
                  //                                 child: FadeInImage(
                  //                                     fit: BoxFit.cover,
                  //                                     width: 180,
                  //                                     height: 180,
                  //                                     placeholder: AssetImage(
                  //                                         'assets/images/person_placeholder.png'),
                  //                                     image: NetworkImage(controller.userProfile.profileImage != null
                  //                                         ? controller.userProfile.profileImage
                  //                                         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //                               ),
                  //                             ),
                  //                             Positioned(
                  //                               left: 32,
                  //                               top: 30,
                  //                               child: InkWell(
                  //                                 onTap: () async{
                  //                                   controller.profileImage = await controller.callGetImage();
                  //                                   controller.update();
                  //                                 },
                  //                                 child: Container(
                  //
                  //                                   alignment: Alignment.center,
                  //                                   padding: const EdgeInsets.all(8),
                  //                                   decoration: BoxDecoration(
                  //                                     color: Colors.grey[600],
                  //                                     shape: BoxShape.circle,
                  //                                   ),
                  //                                   child: Icon(Icons.camera_alt_outlined,size: 20,color: Colors.white,),
                  //
                  //                                 ),
                  //                               ),
                  //                             ),
                  //
                  //                           ],
                  //                         ),
                  //                       ),
                  //                       // child: controller.userProfile == null
                  //                       //     ? CircularProgressIndicator()
                  //                       //     : ClipRRect(
                  //                       //   borderRadius:
                  //                       //   BorderRadius.circular(60),
                  //                       //   child: FadeInImage(
                  //                       //     placeholderErrorBuilder:
                  //                       //         (context, _, __) {
                  //                       //       return Image.asset(
                  //                       //           'assets/images/person_placeholder.png');
                  //                       //     },
                  //                       //     imageErrorBuilder:
                  //                       //         (context, _, __) {
                  //                       //       return Image.asset(
                  //                       //           'assets/images/person_placeholder.png');
                  //                       //     },
                  //                       //     fit: BoxFit.cover,
                  //                       //     width: 150,
                  //                       //     height: 150,
                  //                       //     placeholder: AssetImage(
                  //                       //         'assets/images/person_placeholder.png'),
                  //                       //     image: NetworkImage(controller
                  //                       //         .userProfile
                  //                       //         .profileImage !=
                  //                       //         null
                  //                       //         ? controller.userProfile
                  //                       //         .profileImage
                  //                       //         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                  //                       //   ),
                  //                       // ),
                  //                     ),
                  //                   ),
                  //                       // showDialog(
                  //                       //     useSafeArea: false,
                  //                       //     context: context,
                  //                       //     builder: (context) {
                  //                       //       return AlertDialog(
                  //                       //         insetPadding: EdgeInsets.zero,
                  //                       //         contentPadding: EdgeInsets.zero,
                  //                       //         content: Stack(
                  //                       //           children: [
                  //                       //             Container(
                  //                       //               color: Colors.black,
                  //                       //               width: MediaQuery.of(context)
                  //                       //                   .size
                  //                       //                   .width,
                  //                       //               height: MediaQuery.of(context)
                  //                       //                   .size
                  //                       //                   .height,
                  //                       //               child: FadeInImage(
                  //                       //                 placeholderErrorBuilder:
                  //                       //                     (context, _, __) {
                  //                       //                   return Image.asset(
                  //                       //                       'assets/images/person_placeholder.png');
                  //                       //                 },
                  //                       //                 imageErrorBuilder:
                  //                       //                     (context, _, __) {
                  //                       //                   return Image.asset(
                  //                       //                       'assets/images/person_placeholder.png');
                  //                       //                 },
                  //                       //                 fit: BoxFit.contain,
                  //                       //                 width: 150,
                  //                       //                 height: 150,
                  //                       //                 placeholder: AssetImage(
                  //                       //                     'assets/images/person_placeholder.png'),
                  //                       //                 image: NetworkImage(controller
                  //                       //                     .userProfile
                  //                       //                     .profileImage !=
                  //                       //                     null
                  //                       //                     ? controller.userProfile
                  //                       //                     .profileImage
                  //                       //                     : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                  //                       //               ),
                  //                       //             ),
                  //                       //             Positioned(
                  //                       //               top: 30,
                  //                       //               left: 10,
                  //                       //               child: InkWell(
                  //                       //                 onTap: () {
                  //                       //                   Get.back();
                  //                       //                 },
                  //                       //                 child:
                  //                       //                 Icon(Icons.arrow_back),
                  //                       //               ),
                  //                       //             ),
                  //                       //           ],
                  //                       //         ),
                  //                       //       );
                  //                       //     });
                  //                     //  CircleAvatar(
                  //                     //   radius: 80,
                  //                     //   backgroundColor: Colors.white,
                  //                     //   // Theme.of(context).colorScheme.secondary,
                  //                     //   child: Stack(
                  //                     //     children: [
                  //                     //       CircleAvatar(
                  //                     //         radius: 75,
                  //                     //         backgroundColor: Colors.white,
                  //                     //         child: controller.profileImage != null
                  //                     //             ? CircleAvatar(
                  //                     //           radius: 75,
                  //                     //           backgroundImage: MemoryImage(
                  //                     //               controller.profileImage),
                  //                     //           backgroundColor: Colors.white,
                  //                     //         )
                  //                     //             : controller.userProfile == null
                  //                     //             ? CircularProgressIndicator()
                  //                     //             : ClipRRect(
                  //                     //           borderRadius:
                  //                     //           BorderRadius.circular(
                  //                     //               75),
                  //                     //           child: FadeInImage(
                  //                     //               fit: BoxFit.cover,
                  //                     //               // width: 180,
                  //                     //               // height: 180,
                  //                     //               placeholder: AssetImage(
                  //                     //                   'assets/images/person_placeholder.png'),
                  //                     //               image: NetworkImage(controller.userProfile.profileImage != null
                  //                     //                   ? controller.userProfile.profileImage
                  //                     //                   : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //                     //         ),
                  //                     //       ),
                  //                     //       Positioned(
                  //                     //         top: 45,
                  //                     //         left: 40,
                  //                     //
                  //                     //         child: InkWell(
                  //                     //           onTap: () async{
                  //                     //             controller.profileImage = await controller.callGetImage();
                  //                     //             controller.update;
                  //                     //           },
                  //                     //           child: Container(
                  //                     //             padding: const EdgeInsets.all(20),
                  //                     //             decoration: BoxDecoration(
                  //                     //               color: Colors.grey[600],
                  //                     //               shape: BoxShape.circle,
                  //                     //             ),
                  //                     //             child: Icon(Icons.camera_alt_outlined,color: Colors.white,),
                  //                     //           ),
                  //                     //         ),
                  //                     //       ),
                  //                     //     ],
                  //                     //   ),
                  //                     // ),
                  //                 ],
                  //               ),
                  //             ),
                  //           ],
                  //         ),
                  //         const SizedBox(height: 10,),
                  //         Padding(padding: const EdgeInsets.all(20),
                  //           child: Column(
                  //             children: [
                  //               ProfileDialogTextField(
                  //                 controller: controller.nameController,
                  //                 text: "Name",
                  //                 maxLength: 50,
                  //                 maxLines: 2,
                  //               ),
                  //               const SizedBox(height: 10,),
                  //               ProfileDialogTextField(
                  //                 controller: controller.bioController,
                  //                 text: "Bio",
                  //                 maxLines: 3,
                  //                 maxLength: 160,
                  //               ),
                  //               // ProfileDialogTextField(
                  //               //   text: "Bio",
                  //               //   maxLength: 160,
                  //               // ),
                  //               const SizedBox(height: 10,),
                  //               ProfileDialogTextField(
                  //                 controller: controller.locationController,
                  //                 text: "Location",
                  //                 maxLength: 30,
                  //                 maxLines: 1,
                  //               ),
                  //               const SizedBox(height: 10,),
                  //               ProfileDialogTextField(
                  //                 controller: controller.websiteController,
                  //                 text: "Website",
                  //                 maxLength: 100,
                  //                 maxLines: 2,
                  //               ),
                  //               const SizedBox(height: 10,),
                  //               Row(
                  //                 children: [
                  //                   Text("Birth Date",style: Get.textTheme.headline3.copyWith(color: Colors.black)),
                  //                   const SizedBox(width: 5,),
                  //                   InkWell(
                  //                     onTap: (){},
                  //                     child: Text("Edit",style: Get.textTheme.headline3.copyWith(color: Colors.blue)),
                  //                   ),
                  //                 ],
                  //               )
                  //             ],
                  //           ),
                  //         ),
                  //         // Center(
                  //         //   child: Column(
                  //         //     crossAxisAlignment: CrossAxisAlignment.center,
                  //         //     mainAxisAlignment: MainAxisAlignment.center,
                  //         //     children: [
                  //         //       // SizedBox(height: kIsWeb ? 50 : 15),
                  //         //       // controller.isProfile
                  //         //       //     ? Column(
                  //         //       //         children: [
                  //         //       //           Stack(
                  //         //       //             alignment: Alignment.center,
                  //         //       //             children: [
                  //         //       //               CircleAvatar(
                  //         //       //                   radius: 90,
                  //         //       //                   backgroundColor: Colors.white,
                  //         //       //                   child: controller.profileImage != null
                  //         //       //                       ? CircleAvatar(
                  //         //       //                           radius: 90,
                  //         //       //                           backgroundImage: MemoryImage(
                  //         //       //                               controller.profileImage),
                  //         //       //                           backgroundColor: Colors.white,
                  //         //       //                         )
                  //         //       //                       : controller.userProfile == null
                  //         //       //                           ? CircularProgressIndicator()
                  //         //       //                           : ClipRRect(
                  //         //       //                               borderRadius:
                  //         //       //                                   BorderRadius.circular(
                  //         //       //                                       100),
                  //         //       //                               child: FadeInImage(
                  //         //       //                                   fit: BoxFit.cover,
                  //         //       //                                   width: 180,
                  //         //       //                                   height: 180,
                  //         //       //                                   placeholder: AssetImage(
                  //         //       //                                       'assets/images/person_placeholder.png'),
                  //         //       //                                   image: NetworkImage(controller.userProfile.profileImage != null
                  //         //       //                                       ? controller.userProfile.profileImage
                  //         //       //                                       : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //         //       //                             )),
                  //         //       //               IconButton(
                  //         //       //                 icon: Icon(
                  //         //       //                   Icons.camera_alt_outlined,
                  //         //       //                   color: Colors.black,
                  //         //       //                 ),
                  //         //       //                 onPressed: () async {
                  //         //       //                   controller.profileImage = await controller.callGetImage();
                  //         //       //                   setState(() {});
                  //         //       //                 },
                  //         //       //               )
                  //         //       //             ],
                  //         //       //           ),
                  //         //       //           SizedBox(
                  //         //       //             height: kIsWeb ? height / 15 : 20,
                  //         //       //           ),
                  //         //       //           Text(
                  //         //       //             controller.selectedView == "isSetUp"
                  //         //       //                 ? Strings.yourProfileIsUpdated
                  //         //       //                 : "",
                  //         //       //             style: TextStyle(
                  //         //       //                 fontSize: kIsWeb ? 20.0 : 16.0,
                  //         //       //                 color: Colors.black),
                  //         //       //           ),
                  //         //       //           OutlinedButton(
                  //         //       //             style: OutlinedButton.styleFrom(
                  //         //       //               side: BorderSide(
                  //         //       //                 color: Color(0xFFedab30),
                  //         //       //                 width: 2.0,
                  //         //       //               ),
                  //         //       //               shape: StadiumBorder(),
                  //         //       //               padding: EdgeInsets.symmetric(
                  //         //       //                 horizontal: 60,
                  //         //       //                 vertical: 10,
                  //         //       //               ),
                  //         //       //             ),
                  //         //       //             onPressed: () {
                  //         //       //               setState(() {
                  //         //       //                 if (controller.selectedView ==
                  //         //       //                     "isProfile") {
                  //         //       //                   controller.isProfile = false;
                  //         //       //                   controller.isCover = true;
                  //         //       //                   controller.isBio = false;
                  //         //       //                   controller.isUsername = false;
                  //         //       //                   controller.selectedView = "isCover";
                  //         //       //                 } else if (controller.selectedView ==
                  //         //       //                     "isCover") {
                  //         //       //                   controller.isProfile = false;
                  //         //       //                   controller.isCover = false;
                  //         //       //                   controller.isBio = false;
                  //         //       //                   controller.isUsername = true;
                  //         //       //                   controller.selectedView =
                  //         //       //                       "isUsername";
                  //         //       //                 } else if (controller.selectedView ==
                  //         //       //                     "isUsername") {
                  //         //       //                   controller.isProfile = false;
                  //         //       //                   controller.isCover = false;
                  //         //       //                   controller.isBio = true;
                  //         //       //                   controller.isUsername = false;
                  //         //       //                   controller.selectedView = "isBio";
                  //         //       //                 } else if (controller.selectedView ==
                  //         //       //                     "isBio") {
                  //         //       //                   controller.isProfile = false;
                  //         //       //                   controller.isCover = false;
                  //         //       //                   controller.isBio = false;
                  //         //       //                   controller.isUsername = false;
                  //         //       //                   controller.selectedView = "isSetUp";
                  //         //       //                 } else if (controller.selectedView ==
                  //         //       //                     "isSetUp") {
                  //         //       //                   controller.isProfile = false;
                  //         //       //                   controller.isCover = false;
                  //         //       //                   controller.isBio = false;
                  //         //       //                   Navigator.of(context).pop();
                  //         //       //                 }
                  //         //       //               });
                  //         //       //             },
                  //         //       //             child: controller.profileImage != null
                  //         //       //                 ? Text(
                  //         //       //                     Strings.next,
                  //         //       //                     style: TextStyle(
                  //         //       //                         fontSize: kIsWeb ? 20.0 : 16.0,
                  //         //       //                         color: Theme.of(context)
                  //         //       //                             .colorScheme
                  //         //       //                             .secondary),
                  //         //       //                   )
                  //         //       //                 : Text(
                  //         //       //                     controller.selectedView == "isSetUp"
                  //         //       //                         ? Strings.seeProfile
                  //         //       //                         : Strings.skipForNow,
                  //         //       //                     style: TextStyle(
                  //         //       //                         fontSize: kIsWeb ? 20.0 : 16.0,
                  //         //       //                         color: Theme.of(context)
                  //         //       //                             .colorScheme
                  //         //       //                             .secondary),
                  //         //       //                   ),
                  //         //       //           )
                  //         //       //         ],
                  //         //       //       )
                  //         //       //     : controller.isCover
                  //         //       //         ? Column(
                  //         //       //             children: [
                  //         //       //               Stack(
                  //         //       //                 clipBehavior: Clip.antiAlias,
                  //         //       //                 alignment: Alignment.bottomLeft,
                  //         //       //                 children: [
                  //         //       //                   Container(
                  //         //       //                     width: width,
                  //         //       //                     height: 150,
                  //         //       //                     color: Colors.grey[200],
                  //         //       //                     margin: EdgeInsets.only(
                  //         //       //                         bottom: height / 15),
                  //         //       //                     child: InkWell(
                  //         //       //                         onTap: () async {
                  //         //       //                           controller.coverImage =
                  //         //       //                               await controller
                  //         //       //                                   .callGetImage();
                  //         //       //                           setState(() {});
                  //         //       //                         },
                  //         //       //                         child: controller.coverImage !=
                  //         //       //                                 null
                  //         //       //                             ? Image.memory(
                  //         //       //                                 controller.coverImage,
                  //         //       //                                 fit: BoxFit.cover,
                  //         //       //                               )
                  //         //       //                             : controller.userProfile ==
                  //         //       //                                     null
                  //         //       //                                 ? SizedBox()
                  //         //       //                                 :
                  //         //       //                                 // controller.userProfile
                  //         //       //                                 //             .coverImage ==
                  //         //       //                                 //         null
                  //         //       //                                 //     ?
                  //         //       //                                 //     :
                  //         //       //                                 ClipRRect(
                  //         //       //                                     borderRadius:
                  //         //       //                                         BorderRadius
                  //         //       //                                             .circular(
                  //         //       //                                                 0),
                  //         //       //                                     child: FadeInImage(
                  //         //       //                                         fit: BoxFit
                  //         //       //                                             .cover,
                  //         //       //                                         width: 24,
                  //         //       //                                         height: 24,
                  //         //       //                                         placeholder:
                  //         //       //                                             AssetImage(
                  //         //       //                                                 'assets/images/person_placeholder.png'),
                  //         //       //                                         image: NetworkImage(controller
                  //         //       //                                                     .userProfile
                  //         //       //                                                     .coverImage !=
                  //         //       //                                                 null
                  //         //       //                                             ? controller
                  //         //       //                                                 .userProfile
                  //         //       //                                                 .coverImage
                  //         //       //                                             : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //         //       //                                   )),
                  //         //       //                   ),
                  //         //       //                   Padding(
                  //         //       //                     padding: const EdgeInsets.only(
                  //         //       //                         left: 20.0,
                  //         //       //                         right: kIsWeb ? 40.0 : 20.0),
                  //         //       //                     child: Row(
                  //         //       //                       mainAxisAlignment:
                  //         //       //                           MainAxisAlignment
                  //         //       //                               .spaceBetween,
                  //         //       //                       crossAxisAlignment:
                  //         //       //                           CrossAxisAlignment.start,
                  //         //       //                       children: [
                  //         //       //                         CircleAvatar(
                  //         //       //                             radius: 62,
                  //         //       //                             backgroundColor:
                  //         //       //                                 Color(0xFFedab30),
                  //         //       //                             child: controller
                  //         //       //                                         .profileImage !=
                  //         //       //                                     null
                  //         //       //                                 ? CircleAvatar(
                  //         //       //                                     radius: 55,
                  //         //       //                                     backgroundImage:
                  //         //       //                                         MemoryImage(
                  //         //       //                                             controller
                  //         //       //                                                 .profileImage),
                  //         //       //                                     backgroundColor:
                  //         //       //                                         Colors.white,
                  //         //       //                                   )
                  //         //       //                                 : controller.userProfile ==
                  //         //       //                                         null
                  //         //       //                                     ? CircularProgressIndicator()
                  //         //       //                                     : ClipRRect(
                  //         //       //                                         borderRadius:
                  //         //       //                                             BorderRadius
                  //         //       //                                                 .circular(
                  //         //       //                                                     80),
                  //         //       //                                         child: FadeInImage(
                  //         //       //                                             fit: BoxFit
                  //         //       //                                                 .cover,
                  //         //       //                                             width: 120,
                  //         //       //                                             height: 120,
                  //         //       //                                             placeholder:
                  //         //       //                                                 AssetImage(
                  //         //       //                                                     'assets/images/person_placeholder.png'),
                  //         //       //                                             image: NetworkImage(controller.userProfile.profileImage !=
                  //         //       //                                                     null
                  //         //       //                                                 ? controller
                  //         //       //                                                     .userProfile
                  //         //       //                                                     .profileImage
                  //         //       //                                                 : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                  //         //       //                                       )),
                  //         //       //                       ],
                  //         //       //                     ),
                  //         //       //                   ),
                  //         //       //                   Positioned(
                  //         //       //                     top: 30,
                  //         //       //                     right: 0,
                  //         //       //                     left: 0,
                  //         //       //                     child: IconButton(
                  //         //       //                       icon: Icon(
                  //         //       //                         Icons.camera_alt_outlined,
                  //         //       //                         size: kIsWeb ? 60 : 60,
                  //         //       //                       ),
                  //         //       //                       onPressed: () async {
                  //         //       //                         controller.coverImage =
                  //         //       //                             await controller
                  //         //       //                                 .callGetImage();
                  //         //       //                         setState(() {});
                  //         //       //                       },
                  //         //       //                     ),
                  //         //       //                   )
                  //         //       //                 ],
                  //         //       //               ),
                  //         //       //               SizedBox(
                  //         //       //                 height: kIsWeb ? 48 : 16,
                  //         //       //               ),
                  //         //       //               Text(
                  //         //       //                 controller.selectedView == "isSetUp"
                  //         //       //                     ? Strings.yourProfileIsUpdated
                  //         //       //                     : "",
                  //         //       //                 style: TextStyle(
                  //         //       //                     fontSize: kIsWeb ? 20.0 : 16.0,
                  //         //       //                     color: Colors.black),
                  //         //       //               ),
                  //         //       //               OutlinedButton(
                  //         //       //                 style: OutlinedButton.styleFrom(
                  //         //       //                   side: BorderSide(
                  //         //       //                     color: Color(0xFFedab30),
                  //         //       //                     width: 2.0,
                  //         //       //                   ),
                  //         //       //                   shape: StadiumBorder(),
                  //         //       //                   padding: EdgeInsets.symmetric(
                  //         //       //                     horizontal: 60,
                  //         //       //                     vertical: 10,
                  //         //       //                   ),
                  //         //       //                 ),
                  //         //       //                 onPressed: () {
                  //         //       //                   setState(() {
                  //         //       //                     if (controller.selectedView ==
                  //         //       //                         "isProfile") {
                  //         //       //                       controller.isProfile = false;
                  //         //       //                       controller.isCover = true;
                  //         //       //                       controller.isBio = false;
                  //         //       //                       controller.isUsername = false;
                  //         //       //
                  //         //       //                       controller.selectedView =
                  //         //       //                           "isCover";
                  //         //       //                     } else if (controller
                  //         //       //                             .selectedView ==
                  //         //       //                         "isCover") {
                  //         //       //                       controller.isProfile = false;
                  //         //       //                       controller.isCover = false;
                  //         //       //                       controller.isBio = false;
                  //         //       //                       controller.isUsername = true;
                  //         //       //                       controller.selectedView =
                  //         //       //                           "isUsername";
                  //         //       //                     } else if (controller
                  //         //       //                             .selectedView ==
                  //         //       //                         "isUsername") {
                  //         //       //                       controller.isProfile = false;
                  //         //       //                       controller.isCover = false;
                  //         //       //                       controller.isBio = true;
                  //         //       //                       controller.isUsername = false;
                  //         //       //                       controller.selectedView = "isBio";
                  //         //       //                     } else if (controller
                  //         //       //                             .selectedView ==
                  //         //       //                         "isBio") {
                  //         //       //                       controller.isProfile = false;
                  //         //       //                       controller.isCover = false;
                  //         //       //                       controller.isBio = false;
                  //         //       //                       controller.isUsername = false;
                  //         //       //                       controller.selectedView =
                  //         //       //                           "isSetUp";
                  //         //       //                     } else if (controller
                  //         //       //                             .selectedView ==
                  //         //       //                         "isSetUp") {
                  //         //       //                       controller.isProfile = false;
                  //         //       //                       controller.isCover = false;
                  //         //       //                       controller.isBio = false;
                  //         //       //                       Navigator.of(context).pop();
                  //         //       //                     }
                  //         //       //                   });
                  //         //       //                 },
                  //         //       //                 child: controller.coverImage != null
                  //         //       //                     ? Text(
                  //         //       //                         Strings.next,
                  //         //       //                         style: TextStyle(
                  //         //       //                             fontSize:
                  //         //       //                                 kIsWeb ? 20.0 : 16.0,
                  //         //       //                             color: Theme.of(context)
                  //         //       //                                 .colorScheme
                  //         //       //                                 .secondary),
                  //         //       //                       )
                  //         //       //                     : Text(
                  //         //       //                         controller.selectedView ==
                  //         //       //                                 "isSetUp"
                  //         //       //                             ? Strings.seeProfile
                  //         //       //                             : Strings.skipForNow,
                  //         //       //                         style: TextStyle(
                  //         //       //                             fontSize:
                  //         //       //                                 kIsWeb ? 20.0 : 16.0,
                  //         //       //                             color: Theme.of(context)
                  //         //       //                                 .colorScheme
                  //         //       //                                 .secondary),
                  //         //       //                       ),
                  //         //       //               )
                  //         //       //             ],
                  //         //       //           )
                  //         //       //         : controller.isUsername
                  //         //       //             ? Column(
                  //         //       //                 children: [
                  //         //       //                   Text('Edit your Werfie Handle'),
                  //         //       //                   TextFormField(
                  //         //       //                     inputFormatters: [
                  //         //       //                       LengthLimitingTextInputFormatter(
                  //         //       //                           20),
                  //         //       //                       FilteringTextInputFormatter.allow(
                  //         //       //                           RegExp(
                  //         //       //                               '[a-zA-Z]+[ a-zA-Z]*')),
                  //         //       //                       FilteringTextInputFormatter.deny(
                  //         //       //                           '@'),
                  //         //       //                       FilteringTextInputFormatter.deny(
                  //         //       //                           ' '),
                  //         //       //                     ],
                  //         //       //                     minLines: 1,
                  //         //       //                     maxLines: 2,
                  //         //       //                     controller: controller.usernameText,
                  //         //       //                     keyboardType:
                  //         //       //                         TextInputType.multiline,
                  //         //       //                     decoration: InputDecoration(
                  //         //       //                       hintText: 'Add werfie handle',
                  //         //       //                       hintStyle:
                  //         //       //                           TextStyle(color: Colors.grey),
                  //         //       //                       focusedBorder: OutlineInputBorder(
                  //         //       //                         borderRadius:
                  //         //       //                             BorderRadius.circular(25.0),
                  //         //       //                         borderSide: BorderSide(
                  //         //       //                           color: Theme.of(context)
                  //         //       //                               .colorScheme
                  //         //       //                               .secondary,
                  //         //       //                         ),
                  //         //       //                       ),
                  //         //       //                       enabledBorder: OutlineInputBorder(
                  //         //       //                         borderRadius:
                  //         //       //                             BorderRadius.circular(25.0),
                  //         //       //                         borderSide: BorderSide(
                  //         //       //                           color: Colors.grey[300],
                  //         //       //                           width: 2.0,
                  //         //       //                         ),
                  //         //       //                       ),
                  //         //       //                     ),
                  //         //       //                   ),
                  //         //       //                   controller.doesUsernameExist &&
                  //         //       //                           controller
                  //         //       //                                   .usernameText.text !=
                  //         //       //                               controller
                  //         //       //                                   .userProfile.username
                  //         //       //                       ? Padding(
                  //         //       //                           padding: EdgeInsets.only(
                  //         //       //                               top: 8.0, left: 16.0),
                  //         //       //                           child: Row(
                  //         //       //                             children: [
                  //         //       //                               Icon(
                  //         //       //                                 Icons.error_outline,
                  //         //       //                                 color: Colors.red,
                  //         //       //                                 size: 14,
                  //         //       //                               ),
                  //         //       //                               SizedBox(width: 2),
                  //         //       //                               Text(
                  //         //       //                                 'Werfie Handle already exists',
                  //         //       //                                 style: TextStyle(
                  //         //       //                                     color: Colors.red,
                  //         //       //                                     fontSize: 14),
                  //         //       //                               )
                  //         //       //                             ],
                  //         //       //                           ),
                  //         //       //                         )
                  //         //       //                       : SizedBox(),
                  //         //       //                   SizedBox(
                  //         //       //                     height: height / 10,
                  //         //       //                   ),
                  //         //       //                   OutlinedButton(
                  //         //       //                     style: OutlinedButton.styleFrom(
                  //         //       //                       side: BorderSide(
                  //         //       //                         color: Color(0xFFedab30),
                  //         //       //                         width: 2.0,
                  //         //       //                       ),
                  //         //       //                       shape: StadiumBorder(),
                  //         //       //                       padding: EdgeInsets.symmetric(
                  //         //       //                         horizontal: 60,
                  //         //       //                         vertical: 10,
                  //         //       //                       ),
                  //         //       //                     ),
                  //         //       //                     onPressed: () async {
                  //         //       //                       if (controller.selectedView ==
                  //         //       //                           "isProfile") {
                  //         //       //                         controller.isProfile = false;
                  //         //       //                         controller.isCover = true;
                  //         //       //                         controller.isBio = false;
                  //         //       //                         controller.isUsername = false;
                  //         //       //                         controller.selectedView =
                  //         //       //                             "isCover";
                  //         //       //                       } else if (controller
                  //         //       //                               .selectedView ==
                  //         //       //                           "isCover") {
                  //         //       //                         controller.isProfile = false;
                  //         //       //                         controller.isCover = false;
                  //         //       //                         controller.isBio = false;
                  //         //       //                         controller.isUsername = true;
                  //         //       //                         controller.selectedView =
                  //         //       //                             "isUsername";
                  //         //       //                       } else if (controller
                  //         //       //                               .selectedView ==
                  //         //       //                           "isUsername") {
                  //         //       //                         if (controller
                  //         //       //                                 .usernameText.text !=
                  //         //       //                             controller
                  //         //       //                                 .userProfile.username) {
                  //         //       //                           controller.doesUsernameExist =
                  //         //       //                               await controller
                  //         //       //                                   .checkUsername(
                  //         //       //                                       controller
                  //         //       //                                           .usernameText
                  //         //       //                                           .text
                  //         //       //                                           .toString());
                  //         //       //                           setState(() {});
                  //         //       //                         }
                  //         //       //                         setState(() {});
                  //         //       //
                  //         //       //                         if (controller
                  //         //       //                             .doesUsernameExist) {
                  //         //       //                           print(controller
                  //         //       //                               .doesUsernameExist
                  //         //       //                               .toString());
                  //         //       //                           print(controller
                  //         //       //                               .userProfile.username);
                  //         //       //                           print(controller
                  //         //       //                               .usernameText.text);
                  //         //       //                           setState(() {});
                  //         //       //                           print(
                  //         //       //                               'This username already exists');
                  //         //       //                         }
                  //         //       //                         if (!controller
                  //         //       //                                 .doesUsernameExist ||
                  //         //       //                             controller.usernameText
                  //         //       //                                     .text ==
                  //         //       //                                 controller.userProfile
                  //         //       //                                     .username) {
                  //         //       //                           print('Username changed');
                  //         //       //
                  //         //       //                           controller.isProfile = false;
                  //         //       //                           controller.isCover = false;
                  //         //       //                           controller.isBio = true;
                  //         //       //                           controller.isUsername = false;
                  //         //       //                           controller.selectedView =
                  //         //       //                               "isBio";
                  //         //       //                         }
                  //         //       //                       } else if (controller
                  //         //       //                               .selectedView ==
                  //         //       //                           "isBio") {
                  //         //       //                         controller.isProfile = false;
                  //         //       //                         controller.isCover = false;
                  //         //       //                         controller.isBio = false;
                  //         //       //                         controller.selectedView =
                  //         //       //                             "isSetUp";
                  //         //       //                       } else if (controller
                  //         //       //                               .selectedView ==
                  //         //       //                           "isSetUp") {
                  //         //       //                         // await controller.updateProfile(
                  //         //       //                         //     coverImageBytes: controller
                  //         //       //                         //                 .coverImage !=
                  //         //       //                         //             null
                  //         //       //                         //         ? controller.coverImage
                  //         //       //                         //         : null,
                  //         //       //                         //     aboutMeText:
                  //         //       //                         //         controller.bioText.text,
                  //         //       //                         //     profileImageBytes: controller
                  //         //       //                         //                 .profileImage !=
                  //         //       //                         //             null
                  //         //       //                         //         ? controller
                  //         //       //                         //             .profileImage
                  //         //       //                         //         : null);
                  //         //       //                         // print(response);
                  //         //       //                         // print(response);
                  //         //       //                         // print(response);
                  //         //       //                         // if (response == '0') {
                  //         //       //                         //   Navigator.of(context).pop();
                  //         //       //                         //   print(
                  //         //       //                         //       'TTTTTRRRRRUUUUUUEEEEE CCCCCOOOOONNNNNNDDDDIIIITTTTTIIIIOOOONNNNN');
                  //         //       //                         //   showDialog(
                  //         //       //                         //       context: context,
                  //         //       //                         //       builder: (context) {
                  //         //       //                         //         return Container(
                  //         //       //                         //           width: 300,
                  //         //       //                         //           child: Column(
                  //         //       //                         //             children: [
                  //         //       //                         //               Text(
                  //         //       //                         //                   'Could not update your profile because username already exits'),
                  //         //       //                         //               InkWell(
                  //         //       //                         //                 onTap: () {
                  //         //       //                         //                   Navigator.of(context).pop();
                  //         //       //                         //                 },
                  //         //       //                         //                 child: Text(
                  //         //       //                         //                     'Go Back',
                  //         //       //                         //                     style: Theme.of(
                  //         //       //                         //                             context)
                  //         //       //                         //                         .textTheme
                  //         //       //                         //                         .headline3
                  //         //       //                         //                         .copyWith(
                  //         //       //                         //                           color:
                  //         //       //                         //                               Color(0xFF0157d3),
                  //         //       //                         //                         )),
                  //         //       //                         //               ),
                  //         //       //                         //             ],
                  //         //       //                         //           ),
                  //         //       //                         //         );
                  //         //       //                         //       });
                  //         //       //                         // }
                  //         //       //                         controller.isProfile = false;
                  //         //       //                         controller.selectedView =
                  //         //       //                             "isUpdated";
                  //         //       //                         controller.isCover = false;
                  //         //       //                         controller.isBio = false;
                  //         //       //
                  //         //       //                         Navigator.of(context).pop();
                  //         //       //                       }
                  //         //       //                       setState(() {});
                  //         //       //                     },
                  //         //       //                     child: controller.usernameText !=
                  //         //       //                             null
                  //         //       //                         ? Text(
                  //         //       //                             Strings.next,
                  //         //       //                             style: TextStyle(
                  //         //       //                                 fontSize: kIsWeb
                  //         //       //                                     ? 20.0
                  //         //       //                                     : 16.0,
                  //         //       //                                 color: Theme.of(context)
                  //         //       //                                     .colorScheme
                  //         //       //                                     .secondary),
                  //         //       //                           )
                  //         //       //                         : Text(
                  //         //       //                             controller.selectedView ==
                  //         //       //                                     "isSetUp"
                  //         //       //                                 ? Strings.seeProfile
                  //         //       //                                 : Strings.skipForNow,
                  //         //       //                             style: TextStyle(
                  //         //       //                                 fontSize: kIsWeb
                  //         //       //                                     ? 20.0
                  //         //       //                                     : 16.0,
                  //         //       //                                 color: Theme.of(context)
                  //         //       //                                     .colorScheme
                  //         //       //                                     .secondary),
                  //         //       //                           ),
                  //         //       //                   )
                  //         //       //                 ],
                  //         //       //               )
                  //         //       //             : controller.isBio
                  //         //       //                 ? Column(
                  //         //       //                     children: [
                  //         //       //                       Text('Edit your Bio'),
                  //         //       //                       TextFormField(
                  //         //       //                         minLines: 1,
                  //         //       //                         maxLines: 5,
                  //         //       //                         controller: controller.bioText,
                  //         //       //                         keyboardType:
                  //         //       //                             TextInputType.multiline,
                  //         //       //                         decoration: InputDecoration(
                  //         //       //                           hintText: Strings.addBio,
                  //         //       //                           hintStyle: TextStyle(
                  //         //       //                               color: Colors.grey),
                  //         //       //                           focusedBorder:
                  //         //       //                               OutlineInputBorder(
                  //         //       //                             borderRadius:
                  //         //       //                                 BorderRadius.circular(
                  //         //       //                                     25.0),
                  //         //       //                             borderSide: BorderSide(
                  //         //       //                               color: Theme.of(context)
                  //         //       //                                   .colorScheme
                  //         //       //                                   .secondary,
                  //         //       //                             ),
                  //         //       //                           ),
                  //         //       //                           enabledBorder:
                  //         //       //                               OutlineInputBorder(
                  //         //       //                             borderRadius:
                  //         //       //                                 BorderRadius.circular(
                  //         //       //                                     25.0),
                  //         //       //                             borderSide: BorderSide(
                  //         //       //                               color: Colors.grey[300],
                  //         //       //                               width: 2.0,
                  //         //       //                             ),
                  //         //       //                           ),
                  //         //       //                         ),
                  //         //       //                       ),
                  //         //       //                       SizedBox(
                  //         //       //                         height: height / 10,
                  //         //       //                       ),
                  //         //       //                       OutlinedButton(
                  //         //       //                         style: OutlinedButton.styleFrom(
                  //         //       //                           side: BorderSide(
                  //         //       //                             color: Color(0xFFedab30),
                  //         //       //                             width: 2.0,
                  //         //       //                           ),
                  //         //       //                           shape: StadiumBorder(),
                  //         //       //                           padding: EdgeInsets.symmetric(
                  //         //       //                             horizontal: 60,
                  //         //       //                             vertical: 10,
                  //         //       //                           ),
                  //         //       //                         ),
                  //         //       //                         onPressed: () async {
                  //         //       //                           if (controller.selectedView ==
                  //         //       //                               "isProfile") {
                  //         //       //                             controller.isProfile =
                  //         //       //                                 false;
                  //         //       //                             controller.isCover = true;
                  //         //       //                             controller.isBio = false;
                  //         //       //                             controller.selectedView =
                  //         //       //                                 "isCover";
                  //         //       //                           } else if (controller
                  //         //       //                                   .selectedView ==
                  //         //       //                               "isCover") {
                  //         //       //                             controller.isProfile =
                  //         //       //                                 false;
                  //         //       //                             controller.isCover = false;
                  //         //       //                             controller.isBio = true;
                  //         //       //                             controller.selectedView =
                  //         //       //                                 "isBio";
                  //         //       //                           } else if (controller
                  //         //       //                                   .selectedView ==
                  //         //       //                               "isBio") {
                  //         //       //                             controller.isProfile =
                  //         //       //                                 false;
                  //         //       //                             controller.isCover = false;
                  //         //       //                             controller.isBio = false;
                  //         //       //                             controller.selectedView =
                  //         //       //                                 "isSetUp";
                  //         //       //                           } else if (controller
                  //         //       //                                   .selectedView ==
                  //         //       //                               "isSetUp") {
                  //         //       //                             await controller.updateProfile(
                  //         //       //                                 coverImageBytes:
                  //         //       //                                     controller.coverImage !=
                  //         //       //                                             null
                  //         //       //                                         ? controller
                  //         //       //                                             .coverImage
                  //         //       //                                         : null,
                  //         //       //                                 aboutMeText: controller
                  //         //       //                                     .bioText.text,
                  //         //       //                                 profileImageBytes:
                  //         //       //                                     controller.profileImage !=
                  //         //       //                                             null
                  //         //       //                                         ? controller
                  //         //       //                                             .profileImage
                  //         //       //                                         : null);
                  //         //       //
                  //         //       //                             controller.isProfile =
                  //         //       //                                 false;
                  //         //       //                             controller.selectedView =
                  //         //       //                                 "isUpdated";
                  //         //       //                             controller.isCover = false;
                  //         //       //                             controller.isBio = false;
                  //         //       //                           }
                  //         //       //                           setState(() {});
                  //         //       //                         },
                  //         //       //                         child: controller.bioText !=
                  //         //       //                                 null
                  //         //       //                             ? Text(
                  //         //       //                                 Strings.next,
                  //         //       //                                 style: TextStyle(
                  //         //       //                                     fontSize: kIsWeb
                  //         //       //                                         ? 20.0
                  //         //       //                                         : 16.0,
                  //         //       //                                     color: Theme.of(
                  //         //       //                                             context)
                  //         //       //                                         .colorScheme
                  //         //       //                                         .secondary),
                  //         //       //                               )
                  //         //       //                             : Text(
                  //         //       //                                 controller.selectedView ==
                  //         //       //                                         "isSetUp"
                  //         //       //                                     ? Strings.seeProfile
                  //         //       //                                     : Strings
                  //         //       //                                         .skipForNow,
                  //         //       //                                 style: TextStyle(
                  //         //       //                                     fontSize: kIsWeb
                  //         //       //                                         ? 20.0
                  //         //       //                                         : 16.0,
                  //         //       //                                     color: Theme.of(
                  //         //       //                                             context)
                  //         //       //                                         .colorScheme
                  //         //       //                                         .secondary),
                  //         //       //                               ),
                  //         //       //                       )
                  //         //       //                     ],
                  //         //       //                   )
                  //         //       //                 : controller.selectedView == "isSetUp"
                  //         //       //                     ? Column(
                  //         //       //                         children: [
                  //         //       //                           SizedBox(
                  //         //       //                             height: kIsWeb ? 50 : 20,
                  //         //       //                           ),
                  //         //       //                           Text(
                  //         //       //                             controller.selectedView ==
                  //         //       //                                     "isSetUp"
                  //         //       //                                 ? 'All Done!'
                  //         //       //                                 // Strings.profileUpdated
                  //         //       //                                 : "",
                  //         //       //                             style: TextStyle(
                  //         //       //                                 fontSize: kIsWeb
                  //         //       //                                     ? 20.0
                  //         //       //                                     : 16.0,
                  //         //       //                                 color: Colors.black),
                  //         //       //                           ),
                  //         //       //                           SizedBox(
                  //         //       //                             height: kIsWeb ? 50 : 20,
                  //         //       //                           ),
                  //         //       //                           controller.isUpdateProfile
                  //         //       //                               ? Center(
                  //         //       //                                   child: SpinKitWave(
                  //         //       //                                   size: 20,
                  //         //       //                                   color:
                  //         //       //                                       Color(0xFFedab30),
                  //         //       //                                 ))
                  //         //       //                               : OutlinedButton(
                  //         //       //                                   style: OutlinedButton
                  //         //       //                                       .styleFrom(
                  //         //       //                                     side: BorderSide(
                  //         //       //                                       color: Color(
                  //         //       //                                           0xFFedab30),
                  //         //       //                                       width: 2.0,
                  //         //       //                                     ),
                  //         //       //                                     shape:
                  //         //       //                                         StadiumBorder(),
                  //         //       //                                     padding: EdgeInsets
                  //         //       //                                         .symmetric(
                  //         //       //                                       horizontal: 60,
                  //         //       //                                       vertical: 10,
                  //         //       //                                     ),
                  //         //       //                                   ),
                  //         //       //                                   onPressed: () async {
                  //         //       //                                     if (controller
                  //         //       //                                             .selectedView ==
                  //         //       //                                         "isProfile") {
                  //         //       //                                       controller
                  //         //       //                                               .isProfile =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .isCover =
                  //         //       //                                           true;
                  //         //       //                                       controller.isBio =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .selectedView =
                  //         //       //                                           "isCover";
                  //         //       //                                     } else if (controller
                  //         //       //                                             .selectedView ==
                  //         //       //                                         "isCover") {
                  //         //       //                                       controller
                  //         //       //                                               .isProfile =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .isCover =
                  //         //       //                                           false;
                  //         //       //                                       controller.isBio =
                  //         //       //                                           true;
                  //         //       //                                       controller
                  //         //       //                                               .selectedView =
                  //         //       //                                           "isBio";
                  //         //       //                                     } else if (controller
                  //         //       //                                             .selectedView ==
                  //         //       //                                         "isBio") {
                  //         //       //                                       controller
                  //         //       //                                               .isProfile =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .isCover =
                  //         //       //                                           false;
                  //         //       //                                       controller.isBio =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .selectedView =
                  //         //       //                                           "isSetUp";
                  //         //       //                                     } else if (controller
                  //         //       //                                             .selectedView ==
                  //         //       //                                         "isSetUp") {
                  //         //       //                                       controller
                  //         //       //                                               .isUpdateProfile =
                  //         //       //                                           true;
                  //         //       //                                       setState(() {});
                  //         //       //                                       controller.isUserNameTaken = await controller.updateProfile(
                  //         //       //                                           userName:
                  //         //       //                                               controller
                  //         //       //                                                   .usernameText
                  //         //       //                                                   .text,
                  //         //       //                                           coverImageBytes: controller.coverImage !=
                  //         //       //                                                   null
                  //         //       //                                               ? controller
                  //         //       //                                                   .coverImage
                  //         //       //                                               : null,
                  //         //       //                                           aboutMeText:
                  //         //       //                                               controller
                  //         //       //                                                   .bioText
                  //         //       //                                                   .text,
                  //         //       //                                           profileImageBytes: controller
                  //         //       //                                                       .profileImage !=
                  //         //       //                                                   null
                  //         //       //                                               ? controller
                  //         //       //                                                   .profileImage
                  //         //       //                                               : null);
                  //         //       //                                       if (!controller
                  //         //       //                                           .isUserNameTaken) {
                  //         //       //                                         GetStorage().write(
                  //         //       //                                             'userName',
                  //         //       //                                             controller
                  //         //       //                                                 .userProfile
                  //         //       //                                                 .username
                  //         //       //                                                 .toString());
                  //         //       //                                       }
                  //         //       //
                  //         //       //                                       controller
                  //         //       //                                               .isUpdateProfile =
                  //         //       //                                           false;
                  //         //       //                                       setState(() {});
                  //         //       //
                  //         //       //                                       controller
                  //         //       //                                               .isProfile =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .isCover =
                  //         //       //                                           false;
                  //         //       //                                       controller.isBio =
                  //         //       //                                           false;
                  //         //       //                                       controller
                  //         //       //                                               .selectedView =
                  //         //       //                                           "isUpdated";
                  //         //       //                                       setState(() {});
                  //         //       //
                  //         //       //                                       // Navigator.of(context).pop();
                  //         //       //                                     }
                  //         //       //                                   },
                  //         //       //                                   // child: InkWell(
                  //         //       //                                   //   onTap: () {
                  //         //       //                                   //     controller.updateProfile(
                  //         //       //                                   //         coverImageBytes:
                  //         //       //                                   //             controller.coverImage !=
                  //         //       //                                   //                     null
                  //         //       //                                   //                 ? controller
                  //         //       //                                   //                     .coverImage
                  //         //       //                                   //                 : null,
                  //         //       //                                   //         aboutMeText:
                  //         //       //                                   //             controller
                  //         //       //                                   //                 .bioText.text,
                  //         //       //                                   //         profileImageBytes:
                  //         //       //                                   //             controller.profileImage !=
                  //         //       //                                   //                     null
                  //         //       //                                   //                 ? controller
                  //         //       //                                   //                     .profileImage
                  //         //       //                                   //                 : null);
                  //         //       //                                   //   },
                  //         //       //                                   child: Text(
                  //         //       //                                     Strings.upDate,
                  //         //       //                                     style: TextStyle(
                  //         //       //                                         fontSize: kIsWeb
                  //         //       //                                             ? 20.0
                  //         //       //                                             : 16.0,
                  //         //       //                                         color: Theme.of(
                  //         //       //                                                 context)
                  //         //       //                                             .colorScheme
                  //         //       //                                             .secondary),
                  //         //       //                                   ),
                  //         //       //                                   // ),
                  //         //       //                                 ),
                  //         //       //                         ],
                  //         //       //                       )
                  //         //       //                     : controller.selectedView ==
                  //         //       //                             "isUpdated"
                  //         //       //                         ? Column(
                  //         //       //                             children: [
                  //         //       //                               SizedBox(
                  //         //       //                                 height:
                  //         //       //                                     kIsWeb ? 50 : 20,
                  //         //       //                               ),
                  //         //       //                               Text(
                  //         //       //                                 controller.selectedView ==
                  //         //       //                                         "isUpdated"
                  //         //       //                                     ? controller
                  //         //       //                                             .isUserNameTaken
                  //         //       //                                         ? "Could not update your profile because this username already exists"
                  //         //       //                                         : Strings
                  //         //       //                                             .yourProfileIsUpdated
                  //         //       //                                     : "",
                  //         //       //                                 textAlign:
                  //         //       //                                     TextAlign.center,
                  //         //       //                                 style: TextStyle(
                  //         //       //                                     fontSize: kIsWeb
                  //         //       //                                         ? 20.0
                  //         //       //                                         : 16.0,
                  //         //       //                                     color:
                  //         //       //                                         Colors.black),
                  //         //       //                               ),
                  //         //       //                               SizedBox(
                  //         //       //                                 height:
                  //         //       //                                     kIsWeb ? 50 : 20,
                  //         //       //                               ),
                  //         //       //                               controller
                  //         //       //                                       .isProfileUpdating
                  //         //       //                                   ? SpinKitWave(
                  //         //       //                                       size: 20,
                  //         //       //                                       color: Color(
                  //         //       //                                           0xFFedab30),
                  //         //       //                                     )
                  //         //       //                                   : OutlinedButton(
                  //         //       //                                       style:
                  //         //       //                                           OutlinedButton
                  //         //       //                                               .styleFrom(
                  //         //       //                                         side:
                  //         //       //                                             BorderSide(
                  //         //       //                                           color: Color(
                  //         //       //                                               0xFFedab30),
                  //         //       //                                           width: 2.0,
                  //         //       //                                         ),
                  //         //       //                                         shape:
                  //         //       //                                             StadiumBorder(),
                  //         //       //                                         padding: EdgeInsets
                  //         //       //                                             .symmetric(
                  //         //       //                                           horizontal:
                  //         //       //                                               60,
                  //         //       //                                           vertical: 10,
                  //         //       //                                         ),
                  //         //       //                                       ),
                  //         //       //                                       onPressed:
                  //         //       //                                           () async {
                  //         //       //                                         if (controller
                  //         //       //                                                 .selectedView ==
                  //         //       //                                             "isProfile") {
                  //         //       //                                           controller
                  //         //       //                                                   .isProfile =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isCover =
                  //         //       //                                               true;
                  //         //       //                                           controller
                  //         //       //                                                   .isBio =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .selectedView =
                  //         //       //                                               "isCover";
                  //         //       //                                         } else if (controller
                  //         //       //                                                 .selectedView ==
                  //         //       //                                             "isCover") {
                  //         //       //                                           controller
                  //         //       //                                                   .isProfile =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isCover =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isBio =
                  //         //       //                                               true;
                  //         //       //                                           controller
                  //         //       //                                                   .selectedView =
                  //         //       //                                               "isBio";
                  //         //       //                                         } else if (controller
                  //         //       //                                                 .selectedView ==
                  //         //       //                                             "isBio") {
                  //         //       //                                           controller
                  //         //       //                                                   .isProfile =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isCover =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isBio =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                               .selectedView = "";
                  //         //       //                                         } else if (controller
                  //         //       //                                                     .selectedView ==
                  //         //       //                                                 "isUpdated" &&
                  //         //       //                                             controller
                  //         //       //                                                     .isUserNameTaken ==
                  //         //       //                                                 false) {
                  //         //       //                                           controller
                  //         //       //                                                   .isProfile =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isCover =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isBio =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isProfileUpdating =
                  //         //       //                                               true;
                  //         //       //                                           controller
                  //         //       //                                               .update();
                  //         //       //                                           setState(
                  //         //       //                                               () {});
                  //         //       //                                           controller
                  //         //       //                                                   .newsFeedControler
                  //         //       //                                                   .userProfile =
                  //         //       //                                               await controller
                  //         //       //                                                   .newsFeedControler
                  //         //       //                                                   .getUserProfile();
                  //         //       //                                           // Navigator.of(context).pop();
                  //         //       //                                           controller
                  //         //       //                                               .newsFeedControler
                  //         //       //                                               .update();
                  //         //       //
                  //         //       //                                           controller
                  //         //       //                                               .update();
                  //         //       //                                           Navigator.of(
                  //         //       //                                                   context)
                  //         //       //                                               .pop();
                  //         //       //                                           controller
                  //         //       //                                                   .isProfileUpdating =
                  //         //       //                                               false;
                  //         //       //                                         } else {
                  //         //       //                                           controller
                  //         //       //                                                   .isProfile =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isCover =
                  //         //       //                                               false;
                  //         //       //                                           controller
                  //         //       //                                                   .isBio =
                  //         //       //                                               false;
                  //         //       //                                           Navigator.of(
                  //         //       //                                                   context)
                  //         //       //                                               .pop();
                  //         //       //                                         }
                  //         //       //                                         // setState(() {});
                  //         //       //                                       },
                  //         //       //                                       // child: InkWell(
                  //         //       //                                       //   onTap: () {
                  //         //       //                                       //     controller.updateProfile(
                  //         //       //                                       //         coverImageBytes:
                  //         //       //                                       //             controller.coverImage !=
                  //         //       //                                       //                     null
                  //         //       //                                       //                 ? controller
                  //         //       //                                       //                     .coverImage
                  //         //       //                                       //                 : null,
                  //         //       //                                       //         aboutMeText:
                  //         //       //                                       //             controller
                  //         //       //                                       //                 .bioText.text,
                  //         //       //                                       //         profileImageBytes:
                  //         //       //                                       //             controller.profileImage !=
                  //         //       //                                       //                     null
                  //         //       //                                       //                 ? controller
                  //         //       //                                       //                     .profileImage
                  //         //       //                                       //                 : null);
                  //         //       //                                       //   },
                  //         //       //                                       child: Text(
                  //         //       //                                         Strings
                  //         //       //                                             .goToProfile,
                  //         //       //                                         style: TextStyle(
                  //         //       //                                             fontSize: kIsWeb
                  //         //       //                                                 ? 20.0
                  //         //       //                                                 : 16.0,
                  //         //       //                                             color: Theme.of(
                  //         //       //                                                     context)
                  //         //       //                                                 .colorScheme
                  //         //       //                                                 .secondary),
                  //         //       //                                       ),
                  //         //       //                                       // ),
                  //         //       //                                     ),
                  //         //       //                             ],
                  //         //       //                           )
                  //         //       //                         : SizedBox(),
                  //         //
                  //         //     ],
                  //         //   ),
                  //         //
                  //       ],
                  //     ),
                  //   ),
                  // ),
                ),
              ),
            );
          },
        );
      });
    },
  );
}

class TabButton extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  const TabButton({this.title, this.isSelected, this.onTap});

  @override
  Widget build(BuildContext context) {
    NewsfeedController newsfeedController = Get.put((NewsfeedController()));
    return MaterialButton(
      onPressed: onTap,
      child: Column(
        children: [
          isSelected
              ? FittedBox(
            child: Text(
              title,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 10 : 14,
              ),
              // TextStyle(
              //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
              //   fontWeight: FontWeight.bold,
              //   fontSize: kIsWeb ? 18 : 16,
              // ),
              maxLines: 1,
            ),
          )
              : FittedBox(
            child: Text(
              title,
              style: Styles.baseTextTheme.headline2.copyWith(
                fontWeight: FontWeight.w500,
                fontSize: kIsWeb ? 10 : 14,
              ),
              // TextStyle(
              //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
              //   fontSize: kIsWeb ? 18 : 16,
              //   fontWeight: FontWeight.bold,
              // ),
              maxLines: 1,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          isSelected
              ? Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              //color: MyColors.yellow,
              color: newsfeedController.displayColor,
            ),
            height: 3,
            width: title.length * 5.toDouble(),
          )
              : SizedBox(),
        ],
      ),
    );
  }
}

class EscEditProfileIntent extends Intent {}
