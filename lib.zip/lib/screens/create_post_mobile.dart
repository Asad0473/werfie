import 'dart:async';
import 'dart:io';
import 'package:file_support/file_support.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:flutter_sharing_intent/model/sharing_file.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

// import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/models/upload_media.dart';
import 'package:werfieapp/network/controller/google_search_location.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_post_icons.dart';

import '../models/create_post_model/create_post_model.dart';
import '../models/post.dart';
import '../utils/colors.dart';
import '../utils/emojis.dart';
import '../utils/font.dart';

import '../utils/utils_methods.dart';
import '../web_views/web_guest_user/components/guest_user_post_card.dart';
import '../widgets/post_image_description.dart';
import '../widgets/web_createpostModule/create_PostWeb.dart';
import 'google_search_screen.dart';
import 'package:dio/dio.dart' as _dio;

class CreatePostMobile extends StatefulWidget {
  bool mentionUser = false;
  bool mentionTag = false;
  bool isPostScheduled = false;
  DateTime dateTimeData;
  List postsForDeletions = [];

  bool isUserProfile ;

  List<dynamic> users = [];
  List<dynamic> tags = [];
  final NewsfeedController controller;
  Post post;

  List<SharedFile> sharedMediaFiles;

  CreatePostMobile(this.controller, {this.post, this.sharedMediaFiles,this.isUserProfile});

  @override
  _CreatePostMobileState createState() => _CreatePostMobileState();
}

class _CreatePostMobileState extends State<CreatePostMobile>
    with SingleTickerProviderStateMixin {
  Uint8List pickedAudio;
  bool isMediaUploading = false;
  bool checkLocation = false;
  int postId = 0;
  MediaData mediaData;
  GoogleSearchLocation locationController = Get.put(GoogleSearchLocation());
  List<Uint8List> _pickedAudios = [];
  final DummyData dataController = Get.find();
  String link, linkTitle, linkMeta, linkImage;

  List<Uint8List> _pickedImage = [];
  bool postText = false;
  File _pickedVideo;
  File videoPicker;
  PlatformFile _pickedDocument;
  bool closeIcon = false;

  int imageWidgetKey = 0;
  int videoWidgetKey = 0;
  int pdfWidgetKey = 0;

  List<FocusNode> nodeFirst = [];

  /// list of textField and controller

  // List<TextEditingController> _controllers = [];
  // final controllerTextField = TextEditingController();
  // var textField=HashTagTextField();

  /// end
  /// changing in post text form field and condition in different
  ///
  var postTextController = TextEditingController();
  final List<TextEditingController> _controller = [];

  ///
  File pickedMedia;
  Uint8List imageBytes, videoBytes, pdfBytes;
  bool isMediaAttached = false;
  Map<String, dynamic> _pdfs;
  List<Uint8List> _pickedPdfs = [];
  List<String> _pdfFilesName = [];
  // List<Uint8List> _pickedVideos = [];
  List<String> _pickedVideosName = [];
  List<String> _pickedVideosMemeType = [];
  List<bool> showPolls = [];
  int option = 2;
  bool isOptionThree = false;
  bool isOptionTwo = true;
  List<int> days = [0, 1, 2, 3, 4, 5, 6, 7];

  String pollDays = '';
  String pollHours = '';
  String pollMinutes = '';

  // String pollQuestionOne, pollQuestionTwo, pollQuestionThree, pollQuestionFour;

  List<String> txtOption1 = [];
  List<String> txtOption2 = [];
  List<String> txtOption3 = [];
  List<String> txtOption4 = [];

  String temp = '';
  String tempValue = '';
  FocusNode focusNodeText = FocusNode();

  String tempUsername = '';
  String timezone = '';
  String videoThumbnail = '';
  String imageThumbnail = '';
  String pdfName = '';
  String audioUrl = '';
  List<String> imageThumbnailsList = [];
  List EditimageThumbnailsList = [];
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;

  List<Files> getMedia = [];
  bool threadCreated = false;
  bool monthValidatedSuccessfully = true;
  bool dayValidatedSuccessfully = true;
  bool hourValidatedSuccessfully = true;
  bool minutesValidatedSuccessfully = true;
  bool showScheduledWerfs = false;
  bool isEditable = false;
  bool isCheckBoxSelected = false;

  List<int> minutes = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59
  ];
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List<int> years = [2022, 2023, 2024];
  String scheduleMonthValue = DateTime.now().month.toString();
  String scheduleDayValue = DateTime.now().day.toString();
  String scheduleYearValue = DateTime.now().year.toString();
  String scheduleHourValue = DateTime.now().hour.toString();
  String selectedMonthValue = DateTime.now().month.toString();
  String selectedDayValue = DateTime.now().day.toString();
  String selectedYearValue = DateTime.now().year.toString();
  String selectedHourValue = DateTime.now().hour.toString();
  String selectedMinutesValue = DateTime.now().minute.toString();
  String scheduleMinutesValue = DateTime.now().minute.toString();
  final controller = Get.find<NewsfeedController>();
  FocusNode focusNode = FocusNode();
  String selectedDateTime;

  List<PlatformFile> _paths;
  // List<PlatformFile> listFiles = [];
  List<PlatformFile> compressedFiles = [];
  bool _loadingPath = false;
  final bool _multiPick = true;

  var selectedALL =false;

  callGetImage() async {

    widget.controller.postText = true;
    widget.controller.update();
    imageWidgetKey = 1;
    videoWidgetKey = 0;
    pdfWidgetKey = 0;
    // listFiles = [];
    if (controller.modelList2[controller.currentIndexText].listFilesMob.length >= 4) {
      Fluttertoast.showToast(
          msg: Strings.pleaseChooseEither1VideoOr1Pdf,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 5,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
          webPosition: "center",
          fontSize: kIsWeb ? 18 : 16.0);
      return;
    } else {
      setState(() => _loadingPath = true);
      try {
        _paths = (await FilePicker.platform.pickFiles(
          type: FileType.image,
          // allowedExtensions: ['jpg', 'jpeg', 'png','webp'],
          allowMultiple: _multiPick,
        ))?.files;


        print(" files ${_paths[0].path}");
        print(" files ${_paths[0].bytes}");
        print(" files ${_paths[0].extension}");

        await Future.forEach(_paths, (element) async {
          File compressedImage;
          if (element.extension == "jpg") {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 50);
          } else if (element.extension == "jpeg") {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 100);
          } else {
            compressedImage = await FileSupport().compressImage(File(element.path), quality: 50);
          }

          var size = await FileSupport().getFileSize(file: compressedImage);

          String filePath = compressedImage.path;
          String fileName = filePath.split('/').last;

          String splitSize = size.substring(0, 2).replaceAll(".", "").trim();
          int fileSize = int.parse(splitSize);

          PlatformFile convertedFile = await PlatformFile(
            name: fileName,
            path: filePath,
            size: fileSize,
          );
          compressedFiles.add(convertedFile);
        });

        if (_paths == null || _paths.isEmpty) {
          setState(() => _loadingPath = false);
          return;
        }
      } on PlatformException catch (e) {
        if (kDebugMode) {
          print("Unsupported operation" + e.toString());
          setState(() => _loadingPath = false);
        }
      } catch (error) {
        if (kDebugMode) {
          print(error);
        }
        setState(() => _loadingPath = false);
      }
      if (!mounted) return;
      setState(() {
        _loadingPath = false;
        /*  if (_paths.first.size > 1999999) {

        print("File size must not exceed 2 MB");
      } else {*/
        controller.modelList2[controller.currentIndexText].listFilesMob.addAll(compressedFiles);
        compressedFiles.clear();
        // print("listfile length" + listFiles.length.toString());

        // print(listFiles.length.toString() + " - images length");
        // print("posting image size" + _paths.first.size.toString());
      });
      if (controller.modelList2[controller.currentIndexText].listFilesMob.length > 4 || (controller.modelList2[controller.currentIndexText].imagePickCount + controller.modelList2[controller.currentIndexText].listFilesMob.length) > 4) {
        Fluttertoast.showToast(
            msg: Strings.pleaseChooseEither1VideoOr1Pdf,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 5,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
            webPosition: "center",
            fontSize: kIsWeb ? 18 : 16.0);
        return;
      } else {
        // List<_dio.MultipartFile> files = [];
        // files = listFiles.map((path) => _dio.MultipartFile.fromFileSync(
        //           path.path,
        //           filename: path.name,
        //         ))
        //     .toList();
        // if (kDebugMode) {
        //   print(files.length);
        // }
        // Map<String, dynamic> userData = {};


        // print("filesx ${files[0].contentType}");
        // print("files ${files[0].filename}");
        // print("files ${files[0].headers}");
        // if (files.isNotEmpty) {
        //   userData.addAll({'files[]': files});
        // }
        // isMediaUploading = true;
        // await controller.multiImageSeleted(userData, 1);
        controller.modelList2[controller.currentIndexText].imagePickCount =
            controller.modelList2[controller.currentIndexText].imagePickCount +
                controller.modelList2[controller.currentIndexText].listFilesMob.length;

        // Get.back();
        // print("pick image ${imageThumbnailsList}");
        visibility = true;
        // isMediaUploading = false;
        isMediaAttached = false;
        setState(() {});

      }
    }
  }

  callGetVideo() async {
    widget.controller.postText = true;
    widget.controller.update();

    videoWidgetKey = 1;
    imageWidgetKey = 0;
    pdfWidgetKey = 0;
    setState(() {});
    // File pickedMedia;
    Map<String, dynamic> map = await dataController.getVideo();
    videoBytes = await map['bytes'];

    // _pickedVideo = pickedMedia.path;
    print(videoBytes.toString());

    // _pickedImage.add(videoBytes);
    // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
    if (videoBytes != null) {
      controller.modelList2[controller.currentIndexText].pickedVideos.add(videoBytes);
      _pickedVideosName.add(map['name'] ?? 'fileName');
      _pickedVideosMemeType.add(map['memeType'] ?? 'mp4');
      isMediaUploading = true;

      // videoThumbnail = await controller.uploadMedia(_pickedVideos[0], 1);
      // Get.back();
      videoWidgetKey = 1;
      setState(() {
        widget.controller.postText = true;
      });

      // print("video check $videoThumbnail");

      //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
      // if (videoThumbnail != null) {
      //   print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          isMediaAttached = true;
          isMediaUploading = false;
        });
      // } else {
      //   print('IN ELSE BLOCK');
      // }
    }
  }

  callGetFile() async {
    print("pdf file");
    pdfWidgetKey = 1;
    videoWidgetKey = 0;
    imageWidgetKey = 0;

    _pdfs = await dataController.getFile();

    widget.controller.postText = true;
    widget.controller.update();
    // pickedMedia = await dataController.getImageWeb();

    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (ext!='pdf') {
        UtilsMethods.toastMessageShow(
          controller.displayColor,
          controller.displayColor,
          controller.displayColor,
          message:Strings.fileTypeIsNotAllowed,
        );
      } else {
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        isMediaUploading = true;
        setState(() {});
        pdfName = await controller.uploadMedia(_pickedPdfs[0], 1,
            type: 'file', fileName: _pdfFilesName[0],fileType: 'pdf');
        // Get.back();
        // controller.modelList2[controller.currentIndexText].mediaData2.add();

        // pdfWidgetKey =0;
        print(" pdfkey $pdfWidgetKey");
        isMediaAttached = true;
        print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;
        setState(() {});
      }
    }
  }

  callGetAudio() async {
    pickedAudio = await dataController.getAudio();
    // print(pickedAudio.path);
    if (pickedAudio != null) {
      isMediaUploading = true;
      _pickedAudios.add(pickedAudio);
      setState(() {});
      audioUrl = await controller.uploadMedia(_pickedAudios[0], 1,fileType: 'mp3');
      isMediaAttached = true;
      isMediaUploading = false;
      setState(() {});
    } else {
      print('NANANANANA');
    }
  }

  bool isEveryone = true;
  bool isFollowers = false;
  bool isMentionedPeople = false;
  bool apiCalled = false;
  int indexItem = 1;
  List items = [];

  /// check for  threading button is enable or disable
  bool visibility = false;

  ///
  buildPollOptions({
    @required int optionNumber,

    //  @required int indexOf
  }) {
    if (optionNumber == 1 || optionNumber == 4) {
      return Padding(
        padding: const EdgeInsets.only(top: 6.0, bottom: 6.0, right: 34, left: 10),
        child: TextFormField(
          onChanged: (value) {
            if (optionNumber == 1) {
              //  txtOption1[controller.currentIndexText]=value;
              controller.modelList2[controller.currentIndexText]
                  .poll_ques_first = value;
              //  print('value pool ${txtOption1[controller.currentIndexText]}');
              print(
                  'model values in pool ${controller.modelList2[controller.currentIndexText].poll_ques_first}');
            } else {
              //  txtOption4[controller.currentIndexText]=value;
              controller.modelList2[controller.currentIndexText]
                  .poll_ques_fourth = value;
              // print('value pool ${txtOption4[controller.currentIndexText]}');
              print(
                  'model values in pool ${controller.modelList2[controller.currentIndexText].poll_ques_fourth}');
            }
          },
          style: Styles.baseTextTheme.headline4.copyWith(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
            fontSize: 14,
          ),
          // controller: optionNumber == 1 ? txtOption1 : txtOption4,
          inputFormatters: [
            LengthLimitingTextInputFormatter(25),
          ],
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            labelText: '${Strings.choice} $optionNumber',
            labelStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            hintText: optionNumber == 4
                ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                : '${Strings.choice} $optionNumber',
            hintStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            border: const OutlineInputBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(0.0),
              ),
              borderSide: BorderSide(
                color: Colors.grey,
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(
          top: 8.0,
          bottom: 8.0,
          left: 10,
          right: optionNumber == 2 && !isOptionTwo
              ? 34
              : option == 3 || option == 2 && isOptionTwo
                  ? 10
                  : option == 3 && !isOptionTwo
                      ? 34
                      : 34),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              onChanged: (value) {
                if (optionNumber == 2) {
                  // txtOption2[controller.currentIndexText]=value;
                  controller.modelList2[controller.currentIndexText]
                      .poll_ques_second = value;
                } else {
                  // txtOption3[controller.currentIndexText]=value;
                  controller.modelList2[controller.currentIndexText]
                      .poll_ques_third = value;
                }

                setState(() {});
              },
              // controller: optionNumber == 2 ? txtOption2 : txtOption3,
              inputFormatters: [
                LengthLimitingTextInputFormatter(25),
              ],
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 14,
              ),
              decoration: InputDecoration(
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(0.0),
                  ),
                  borderSide: BorderSide(
                    color: Colors.grey,
                  ),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                labelText: '${Strings.choice} $optionNumber',
                labelStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
                hintText: optionNumber == 3
                    ? '${Strings.choice}  $optionNumber' + '${Strings.optionalPoll}'
                    : '${Strings.choice}  $optionNumber',
                hintStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
              ),
            ),
          ),
          optionNumber == 2 && option == 2 && isOptionTwo
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : const SizedBox(),
          !isOptionTwo && option == 3 && optionNumber == 3
              ? Align(
                  alignment: Alignment.topCenter,
                  child: InkWell(
                    onTap: () {
                      option = optionNumber + 1;
                      isOptionTwo = false;
                      setState(() {});
                    },
                    child: Icon(
                      Icons.add,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                )
              : const SizedBox(),
        ],
      ),
    );
  }

  /// controllers dispose
  @override
  void dispose() {
    _tabController.dispose();
    nodeFirst = [];
    super.dispose();
  }

  /// emojis variable
  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  int _selectedTab = 0;
  StreamSubscription<bool> keyboardSubscription;
  TabController _tabController;

  ScrollController _scrollController;

  bool isPortrait = false;
  double width = 0, height = 0;

  bool editImageCheck = false;

  /// initstate
  @override
  void initState() {
    // widget.controller.imageCounter=0;
    // widget.controller.descriptionCounter = 0;
    // if(controller.imageDescriptionController.length>0){
    //
    //   controller.imageDescriptionController.forEach((element) {
    //     element.clear();
    //   });
    // }

    controller.focusNode.requestFocus();
    for (int i = 1; i < 30; i++) {
      _controller.add(TextEditingController());
    }

    bool b = false;
    for (int i = 0; i < 30; i++) {
      showPolls.add(b);
    }
    //  FocusNode focusNode = FocusNode();
    // // nodeFirst.add(focusNode);
    //  for (int i = 0; i < 30 ; i++)
    //  {
    //    nodeFirst.add(focusNode);
    //  }

    _tabController = TabController(vsync: this, length: emojis.length);
    _scrollController = ScrollController();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
      if (visible && isEmojiVisible) {
        isEmojiVisible = false;
        if (mounted) {
          // check whether the state object is in tree
          setState(() {
            // make changes here
          });
        }
      } else {}
    });

//isMediaAttached=true;
    widget.controller.mediaData.clear();
    // print( " widget post ${widget.post}");
    if (widget.post != null) {
      // controller.modelList2[0].postId = widget.post.postId;

      widget.controller.postText = true;
      isEdit = true;
      print(isEdit);
      postId = widget.post.postId;
      print("widget post ${widget.post.type}");
      if (widget.post.body.isNotEmpty) {
        print("bodyy");
        _controller[0].text = widget.post.body;
        postTextController.text = widget.post.body;
        print(widget.post.body);
        print(controller.modelList2[0].bodyText);
      }
      if (widget.post.location != null) {
        controller.modelList2[0].location = widget.post.location;
        controller.modelList2[0].lat = widget.post.lat;
        controller.modelList2[0].lng = widget.post.lng;

        print(controller.modelList2[0].location);
        print(controller.modelList2[0].lat);
        print(controller.modelList2[0].lng);

        print("location");
        SingleTone.instance.selectedLocation = widget.post.location;
      }
      if (widget.post.postFiles.isNotEmpty) {
        print(" widget  ${widget.post.postFiles}");

        if (widget.post.postFiles[0]["file_type"] == "image") {
          imageWidgetKey = 1;
          widget.post.postFiles.forEach((element) {
            imageThumbnail = element["file_path"];
            EditimageThumbnailsList.add(imageThumbnail);
            imageThumbnailsList.add(imageThumbnail);
            print(widget.post.postFiles);
            isEditCheckForImage = 0;
            editImageCheck = true;
            isMediaAttached = true;
            isEdit = true;
            print('bool check$isMediaAttached');
            print('bool check edit image:$editImageCheck');
            print(" list of images ${imageThumbnailsList}");
          });

          int length = widget.post.postFiles.length;
          print("length: $length");
          // var details = new Files();
          int length3 = imageThumbnailsList.length;
          print("length4546: $length3");

          print("inside if");

          for (int i = 0; i < length3; i++) {
            controller.modelList2[0].mediaData2.add(Files.fromJson({
              'url': imageThumbnailsList[i],
              'thumbnail_url': widget.post.postFiles[i]["thumbnail_url"],
              'name': widget.post.postFiles[i]["original_name"],
              'size': widget.post.postFiles[i]["size"],
            }));


          }

          if( widget.post.postFiles[0]['mention_users']!=null &&  widget.post.postFiles[0]['mention_users'].isNotEmpty)
          {
            var data = widget.post.postFiles[0]['mention_users'] as List;
            for (var element in data) {
              controller.modelList2[0].mediaData2[0].mentionUserList.add(MentionUserList.fromJson(element));
            }
          }
          int i =0;
          widget.post.postFiles.forEach((element) {

            if(element["description"]!=null)
            {
              controller.modelList2[0].mediaData2[i].description = element["description"];
              i++;
            }

          });
          if(i>1)
          {
            controller.modelList2[0].descriptionCounter= i;

          }



        }
        else if (widget.post.postFiles[0]["file_type"] == "attachment") {
          videoWidgetKey = 1;
          pdfName = widget.post.postFiles[0]["file_path"];
          isEditCheckForPdf = 1;
          widget.controller.mediaData.clear();
          print(widget.controller.mediaData);
          print("attach");
          isMediaAttached = true;
          print("pdf ${pdfName}");
          controller.modelList2[0].mediaData2.add(Files.fromJson({
            'url': pdfName,
            'thumbnail_url': widget.post.postFiles[0]["thumbnail_path"],
            'name': widget.post.postFiles[0]["original_name"],
            'size': widget.post.postFiles[0]["size"],
          }));
        }
        else if (widget.post.postFiles[0]["file_type"] == "video") {
          pdfWidgetKey = 1;
          controller.modelList2[0].videoThumbnail = widget.post.postFiles[0]["file_path"];

          isMediaAttached = true;
          // print("video ${videoThumbnail}");

          controller.modelList2[0].mediaData2.add(Files.fromJson({
            'url': controller.modelList2[0].videoThumbnail,
            'thumbnail_url': widget.post.postFiles[0]["thumbnail_path"],
            'name': widget.post.postFiles[0]["original_name"],
            'size': widget.post.postFiles[0]["size"],
          }));


        }
      }









    } else {
      //print("hello");
      widget.controller.postText = false;
      isEditCheckForImage = -1;
      isEdit = false;
      //print("isCheckEdit: $isEditCheckForImage");
    }
    selectedDateTime = DateTime.now().toString();
    /*  if (int.parse(selectedMonthValue) < 10) {
      selectedMonthValue = "0" + selectedMonthValue;
      selectedDateTime =
          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
              " $selectedHourValue:$selectedMinutesValue:00";
    }
    if (int.parse(selectedDayValue) < 10) {
      selectedDayValue = "0" + selectedDayValue;
      selectedDateTime =
          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
              " $selectedHourValue:$selectedMinutesValue:00";
    }
    if (int.parse(selectedHourValue) < 10) {
      selectedHourValue = "0" + selectedHourValue;
      selectedDateTime =
          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
              " $selectedHourValue:$selectedMinutesValue:00";
    }
    if (int.parse(selectedMinutesValue) < 10) {
      selectedMinutesValue = "0" + selectedMinutesValue;
      selectedDateTime =
          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
              " $selectedHourValue:$selectedMinutesValue:00";
    }*/
    //   else {
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      addFilesFromShareIntent();
    });
    super.initState();
  }

  addFilesFromShareIntent() async {
    if (widget.sharedMediaFiles != null && widget.sharedMediaFiles.isNotEmpty) {
      if (widget.sharedMediaFiles.first.type == SharedMediaType.image) {
        if (widget.sharedMediaFiles.length > 4) {
          Fluttertoast.showToast(
              msg: Strings.pleaseChooseEither1VideoOr1Pdf,
              toastLength:
              Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb:
              5,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
              webPosition: "center",
              fontSize: kIsWeb?18:16.0);
          return;
        } else {
          widget.controller.postText = true;

          widget.controller.update();
          imageWidgetKey = 1;
          videoWidgetKey = 0;
          pdfWidgetKey = 0;
          controller.modelList2[controller.currentIndexText].listFilesMob = [];
          await Future.forEach(widget.sharedMediaFiles, (element) async {
            PlatformFile convertedFile = await PlatformFile(
              name: element.value.split(".")[0],
              path: element.value,
              // size: fileSize,
            );
            controller.modelList2[controller.currentIndexText].listFilesMob.add(convertedFile);
          });


          // List<_dio.MultipartFile> files = [];
          // files = widget.sharedMediaFiles
          //     .map((files) => _dio.MultipartFile.fromFileSync(
          //           files.value,
          //           filename: files.value.split(".")[0],
          //         ))
          //     .toList();
          //
          // Map<String, dynamic> userData = {};
          // if (files.isNotEmpty) {
          //   userData.addAll({'files[]': files});
          // }
          //
          // isMediaUploading = true;
          // await controller.multiImageSeleted(userData, 1);
          //Get.back(closeOverlays: true);

          print("pick image $imageThumbnailsList");
          visibility = true;
          // Get.back();
          // isMediaUploading = false;
          isMediaAttached = false;
          _loadingPath = false;

          setState(() {});
        }
      } else
        if (widget.sharedMediaFiles.first.type == SharedMediaType.video) {

          //region Video thiumbnail
          widget.controller.postText = true;
          widget.controller.update();

          videoWidgetKey = 1;
          imageWidgetKey = 0;
          pdfWidgetKey = 0;
          setState(() {});
          // File pickedMedia;
          String filename = 'filename.mp4';
          String fileMemeType = 'mp4';
          File file = File(widget.sharedMediaFiles.first.value);
          filename = file.path.split("/").last ?? 'video.mp4';
          fileMemeType = file.path.split("/").last.split(".").last ?? 'mp4';

          LoggingUtils.printValue("video", file.path);



          if (Platform.isIOS) {
            videoBytes =
                File.fromUri(Uri.parse(widget.sharedMediaFiles.first.value))
                    .readAsBytesSync();
            File file = File.fromUri(Uri.parse(widget.sharedMediaFiles.first.value));

            filename = file.path.split("/").last ?? 'video.mp4';
            fileMemeType = file.path.split("/").last.split(".").last ?? 'mp4';
          } else {
            videoBytes =
                File(widget.sharedMediaFiles.first.value).readAsBytesSync();

          }
          //videoBytes = await dataController.getVideo();

          controller.modelList2[controller.currentIndexText].videoThumbnail =
          await VideoThumbnail.thumbnailData(
            video: file.path,
            imageFormat: ImageFormat.JPEG,
            maxWidth: 128,
            // specify the width of the thumbnail, let the height auto-scaled to keep the source aspect ratio
            quality: 100,
          );

          // _pickedVideo = pickedMedia.path;
          //print(videoBytes.toString());

          // _pickedImage.add(videoBytes);
          // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
          if (videoBytes != null) {
            controller.modelList2[controller.currentIndexText].pickedVideos.add(videoBytes);
            _pickedVideosName.add(filename ?? 'fileName');
            _pickedVideosMemeType.add(fileMemeType ?? 'mp4');
            isMediaUploading = true;

            // videoThumbnail = await controller.uploadMedia(_pickedVideos[0], 1);
            // Get.back();
            videoWidgetKey = 1;
            setState(() {
              widget.controller.postText = true;
            });

            // print("video check $videoThumbnail");

            //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
            // if (videoThumbnail != null) {
            // print('IN CREATE POST $videoThumbnail');
            setState(() {
              visibility = true;
              isMediaAttached = true;
              isMediaUploading = false;
            });
            // } else {
            //   print('IN ELSE BLOCK');
            // }
          }
      }else
        if(widget.sharedMediaFiles.first.type == SharedMediaType.url){
          _controller[0].text = '';
          controller.modelList2[0].link = '';
          controller.modelList2[0].linkTitle = '';
          controller.modelList2[0].linkMeta = '';
          controller.modelList2[0].linkImage = '';
          controller.modelList2[0].link = '';
          link ='';
          linkTitle = '';
          linkMeta = '';
          controller.scrapUrl = null;
          controller.postText = true;
          /*widget.controller.urlOrNot(
             widget.sharedMediaFiles.first.value);*/

          _controller[0].text = widget.sharedMediaFiles.first.value;

          //urlFetch();
        }
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _controller[controller.currentIndexText].addListener(() {

      controller.modelList2[controller.currentIndexText].bodyText =
          _controller[controller.currentIndexText].text;
    });

    width = MediaQuery.of(context).size.width;
    height = MediaQuery.of(context).size.height;
    isPortrait = height > width ? true : false;
    _tabController.addListener(() {
      _selectedTab = _tabController.index;
      if (!isPortrait) {
        _scrollController.jumpTo(_selectedTab * height * .075);
      }
      if (mounted) {
        // check whether the state object is in tree
        setState(() {
          // make changes here
        });
      }
      // setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final cross = (MediaQuery.of(context).size.width * .025).round();
    return WillPopScope(
      onWillPop: _willPopCallback,
      child: Scaffold(
          appBar: AppBar(
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            automaticallyImplyLeading: false,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  highlightColor: Colors.transparent,
                  splashColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  onPressed: () {
                    imageThumbnailsList.clear();
                    widget.controller.mediaData.clear();
                    controller.modelList2[controller.currentIndexText]
                        .imagePickCount = 0;
                    widget.controller.currentIndexText = 0;
                    apiCalled = false;
                    checkLocation = true;
                    print(checkLocation);
                    SingleTone.instance.selectedLocation = null;

                    setState(() {});

                    Navigator.of(context).pop();
                  },
                  icon: Icon(
                    Icons.close,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),
                /* When Scheduling a Post*/
                widget.isPostScheduled
                    ? ElevatedButton(
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all(
                            const EdgeInsets.symmetric(horizontal: 30, vertical: 2),
                          ),
                          backgroundColor: MaterialStateProperty.all(
                              widget.controller.postText == false &&
                                      isMediaAttached == false
                                  ? widget.controller.displayColor
                                      .withOpacity(0.6)
                                  : widget.controller.postText == true &&
                                          isMediaUploading == true
                                      ? widget.controller.displayColor
                                          .withOpacity(0.6)
                                      : widget.controller.displayColor),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40),
                            ),
                          ),
                        ),
                        onPressed: widget.controller.postText == false &&
                                isMediaAttached == false
                            ? null
                            : widget.controller.postText == true &&
                                    isMediaUploading == true
                                ? null
                                : () async {
                                    if (controller.modelList2[0].bodyText ==
                                            '' ||
                                        controller
                                            .modelList2[0].bodyText.isEmpty) {
                                      UtilsMethods.toastMessageShow(
                                        controller.displayColor,
                                        controller.displayColor,
                                        controller.displayColor,
                                        message: Strings.pleaseEnterValidText,
                                      );
                                      //  Get.snackbar('message', "please enter some Thing");
                                    } else {
                                      print('PRINT dksakdskodksodsa  ');
                                      // widget.controller.isLoading = true;
                                      apiCalled = true;
                                      setState(() {});
                                      widget.controller.schedulePost(context,
                                          bodyText:
                                              controller.modelList2[0].bodyText,
                                          fileName: _pdfFilesName.length > 0
                                              ? _pdfFilesName
                                              : null,
                                          // imageWebBytes: _pickedImage.isNotEmpty ? _pickedImage
                                          //     : _pickedVideos.isNotEmpty ? _pickedVideos
                                          //     : _pickedAudios != null
                                          //     ? _pickedAudios
                                          //     : _pickedPdfs,
                                          payload: controller.modelList2,
                                          link: link ?? '',
                                          linkImage: linkImage ?? '',
                                          linkMeta:
                                              linkMeta ?? '',
                                          linkTitle: linkTitle ?? '',
                                          postingTime:
                                              selectedDateTime.toString());

                                      Navigator.of(context).pop();
                                    }

                                    // Navigator.pop(context);
                                  },
                        child: Text(
                          Strings.schedule,
                          style: TextStyle(fontSize: 14, color: Colors.grey.shade100),
                        ),
                      )
                    : ElevatedButton(
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all(
                            const EdgeInsets.symmetric(horizontal: 30, vertical: 2),
                          ),
                          backgroundColor: MaterialStateProperty.all(widget
                                          .controller.postText ==
                                      false &&
                                  isMediaAttached == false
                              ? widget.controller.displayColor.withOpacity(0.6)
                              : widget.controller.postText == true &&
                                      isMediaUploading == true
                                  ? widget.controller.displayColor
                                      .withOpacity(0.6)
                                  : showPolls[controller.currentIndexText] &&
                                          widget.controller.postText == true &&
                                          txtOption1.isEmpty &&
                                          txtOption2.isEmpty &&
                                          controller
                                              .modelList2[
                                                  controller.currentIndexText]
                                              .bodyText
                                              .isEmpty &&
                                          controller
                                                  .modelList2[controller
                                                      .currentIndexText]
                                                  .poll_ques_first ==
                                              "" &&
                                          controller
                                                  .modelList2[controller.currentIndexText]
                                                  .poll_ques_second ==
                                              ""
                                      ? widget.controller.displayColor.withOpacity(0.6)
                                      : widget.controller.displayColor),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40),
                            ),
                          ),
                        ),
                        onPressed: widget.controller.postText == false &&
                                isMediaAttached == false
                            ? null
                            : widget.controller.postText == true &&
                                    isMediaUploading == true
                                ? null
                                : showPolls[controller.currentIndexText] &&
                                        widget.controller.postText == true &&
                                        controller
                                                .modelList2[
                                                    controller.currentIndexText]
                                                .bodyText ==
                                            null &&
                                        txtOption1.isEmpty &&
                                        txtOption2.isEmpty
                                    ? () {}
                                    : () async {
                                        // widget.controller.isLoading = true;
                                        if ((controller.modelList2[controller.currentIndexText].pickedVideos.length + controller.modelList2[controller.currentIndexText].listFilesMob.length) > 4) {
                                          Fluttertoast.showToast(
                                              msg: Strings.pleaseChooseEither1VideoOr1Pdf,
                                              toastLength:
                                              Toast.LENGTH_SHORT,
                                              gravity: ToastGravity.CENTER,
                                              timeInSecForIosWeb:
                                              5,
                                              backgroundColor: Colors.red,
                                              textColor: Colors.white,
                                              webBgColor: "linear-gradient(to right, #F5BCBCFF, #FF0000FF)",
                                              webPosition: "center",
                                              fontSize: kIsWeb?18:16.0);
                                          return;
                                        }
                                        apiCalled = true;
                                        setState(() {});
                                      /*  if (_pickedVideos.length > 0){
                                          await controller.uploadMedia(_pickedVideos[0], 1,fileName:_pickedVideosName[0],fileType: 'mp4',memeType: _pickedVideosMemeType[0]);
                                        }

                                        if (listFiles.length > 0){
                                          await uploadImages();
                                        }*/

                                        print('mediaData : ' +
                                            widget.controller.mediaData
                                                .toString());


                                        print("check postid ${postId}");

                                        ///edit post
                                        List<ModelClass> EditList = [];
                                        List<ModelClass> showPoolList = [];
                                        if (isEdit == true) {
                                          EditList.insert(
                                              0,
                                              ModelClass.fromJson({
                                                'body': '',
                                                'poll_ques_first': null,
                                                'poll_ques_second': null,
                                                'poll_ques_third': null,
                                                'poll_ques_fourth': null,
                                                'files': [],
                                                'link_meta': '',
                                                'link': '',
                                                'link_image': '',
                                                'link_title': '',
                                                'days': '',
                                                'minutes': '',
                                                'hours': '',
                                                'location': '',
                                                'lat': '',
                                                'lng': '',
                                                'type': "post",
                                                "post_id": 0,
                                              }));

                                          EditList[0].location =
                                              controller.modelList2[0].location;
                                          EditList[0].lat =
                                              controller.modelList2[0].lat;
                                          EditList[0].lng =
                                              controller.modelList2[0].lng;

                                          print("eidt pay aya hai");

                                          int length = controller
                                              .modelList2[0].mediaData2.length;
                                          print("length: $length");
                                          // var details = new Files();
                                          // int length3 = imageThumbnailsList.length;
                                          // print("length4546: $length3");

                                          for (int i = 0; i < length; i++) {
                                            EditList[0]
                                                .mediaData2
                                                .add(Files.fromJson({
                                                  'url': controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .url,
                                                  'thumbnail_url': controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .thumbnailUrl,
                                                  'name': controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .name,
                                                  'size': controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .size,
                                                }));
                                          }


                                          /// mention user  and image description
                                          if(controller.modelList2[0].mediaData2.isNotEmpty) {
                                            if (controller.modelList2[0]
                                                .mediaData2[0].mentionUserList
                                                .isNotEmpty) {
                                              controller.modelList2[0]
                                                  .mediaData2[0].mentionUserList
                                                  .forEach((element) {
                                                EditList[0].mediaData2[0]
                                                    .mentionUserList.add(
                                                    element);
                                              });
                                            }

                                            int i = 0;
                                            controller.modelList2[0].mediaData2
                                                .forEach((element) {
                                              if (element.description != null) {
                                                EditList[0].mediaData2[i]
                                                    .description =
                                                    element.description;
                                                i++;
                                              }
                                            });


                                            String mentionUserIds = "";


                                            for (int i = 0; i < EditList[0]
                                                .mediaData2[0].mentionUserList
                                                .length; i++) {
                                              if (i == 0 || i == EditList[0]
                                                  .mediaData2[0].mentionUserList
                                                  .length) {
                                                mentionUserIds =
                                                    mentionUserIds + EditList[0]
                                                        .mediaData2[0]
                                                        .mentionUserList[i].id
                                                        .toString();
                                                EditList[0].mediaData2[0]
                                                    .mentionUserId =
                                                    mentionUserIds.toString();
                                              }
                                              else {
                                                mentionUserIds =
                                                    mentionUserIds + "," +
                                                        EditList[0]
                                                            .mediaData2[0]
                                                            .mentionUserList[i]
                                                            .id.toString();
                                                EditList[0].mediaData2[0]
                                                    .mentionUserId =
                                                    mentionUserIds.toString();
                                              }
                                            }
                                          }


                                          EditList[0].bodyText =
                                              controller.modelList2[0].bodyText;
                                          EditList[0].postId =
                                              widget.post.postId;
                                          EditList[0].postType = "post";
                                        }

                                        /// show poll

                                        else if (showPolls[0] == true &&
                                            threadCreated == false) {
                                          showPoolList.insert(
                                              0,
                                              ModelClass.fromJson({
                                                'body': controller
                                                    .modelList2[0].bodyText,
                                                'poll_ques_first': controller
                                                    .modelList2[0]
                                                    .poll_ques_first,
                                                'poll_ques_second': controller
                                                    .modelList2[0]
                                                    .poll_ques_second,
                                                'poll_ques_third': controller
                                                            .modelList2[0]
                                                            .poll_ques_third ==
                                                        null
                                                    ? null
                                                    : controller.modelList2[0]
                                                        .poll_ques_third,
                                                'poll_ques_fourth': controller
                                                            .modelList2[0]
                                                            .poll_ques_fourth ==
                                                        null
                                                    ? null
                                                    : controller.modelList2[0]
                                                        .poll_ques_fourth,
                                                'files': [],
                                                'link_meta': '',
                                                'link': '',
                                                'link_image': '',
                                                'link_title': '',
                                                'days':  controller.modelList2[0].days,
                                                'minutes': controller.modelList2[0].minutes == null || controller.modelList2[0].minutes.isEmpty ? '5' : controller.modelList2[0].minutes,
                                                'hours': controller.modelList2[0].hours,
                                                'location': '',
                                                'lat': '',
                                                'lng': '',
                                                'type': 'poll',
                                              }));
                                        }

                                        if (isEdit == false) {
                                          controller.modelList2
                                              .forEach((element) {
                                            print(
                                                "before element.bodyText ${element.bodyText}");
                                            element.bodyText = element.bodyText
                                                .replaceAll("\n", " " + "\n");

                                            print(
                                                "after element.bodyText ${element.bodyText}");
                                          });

                                          // Upload Images and Videos
                                          for (int i = 0; i < controller.modelList2.length; i++) {
                                            // Upload Images
                                            if (controller.modelList2[i].listFilesMob.isNotEmpty) {
                                              await uploadImages(i);
                                            }

                                            // Upload Videos
                                            if (controller.modelList2[i].pickedVideos.isNotEmpty) {
                                              await controller.uploadMedia(controller.modelList2[i].pickedVideos[0], 1,
                                                  fileName:_pickedVideosName[0],
                                                  fileType: 'mp4',
                                                  memeType: _pickedVideosMemeType[0],
                                                  index: i);
                                            }
                                          }
                                        }
                                        else {
                                          EditList.forEach((element) {
                                            print(
                                                "before element.bodyText ${element.bodyText}");
                                            element.bodyText = element.bodyText
                                                .replaceAll("\n", " " + "\n");

                                            print(
                                                "after element.bodyText ${element.bodyText}");
                                          });
                                        }

                                        var responseCode;

                                        {

                                          responseCode = await controller.createPost(
                                            payload: isEdit == true ? EditList : showPolls[0] == true && threadCreated == false ?
                                            showPoolList : controller.modelList2,
                                            postId: isEdit == true ? widget.post.postId : 0,
                                            replyId: null,
                                            isUserProfile: widget.isUserProfile,
                                              isEdit:isEdit == true && EditList[0].mediaData2.isNotEmpty?true:false
                                          );
                                          print(controller.modelList2);
                                          print(
                                              'controller.modelList2.length : ${controller.modelList2.length}');
                                          controller
                                              .modelList2[
                                          controller.currentIndexText]
                                              .imagePickCount = 0;

                                          apiCalled = false;
                                          controller.modelList2[0].listFilesMob.clear();
                                          // controller.videoThumbnail= null;
                                          controller.modelList2[0].pickedVideos = [];
                                          controller.modelList2[0].videoThumbnail = null;
                                          _pickedVideosName = [];
                                          _pickedVideosMemeType = [];
                                          _pickedAudios = [];
                                          _pickedImage = [];
                                          widget.controller.mediaData = [];
                                          _pickedPdfs = [];
                                          controller.currentIndexText = 0;

                                          setState(() {});
                                          Navigator.pop(context);
                                          widget.controller.isNewsfeedLoading = false;

                                          widget.controller.update();
                                          print('RESPONSE : ' + responseCode.toString());
                                          widget.controller.postText = false;






                                        }

                                      },
                        child: threadCreated == false ||
                                controller.modelList2.length == 1
                            ? isEdit == true
                                ? Text(
                                    Strings.editWerf,
                                    style:  TextStyle(
                                        fontSize: 14, color: Colors.grey.shade100,),
                                  )
                                : Text(
                                    Strings.werf,
                                    style:  TextStyle(
                                        fontSize: 14, color: Colors.grey.shade100),
                                  )
                            : Text(Strings.allwerf),
                      )
              ],
            ),
          ),
          resizeToAvoidBottomInset: true,
          body:
              //  !showPolls
              // ?
              SafeArea(
            minimum: _pickedAudios.isNotEmpty ||
                controller.modelList2[0].pickedVideos.isNotEmpty ||
                    _pickedPdfs.isNotEmpty ||
                    imageThumbnailsList.isNotEmpty
                ? const EdgeInsets.symmetric(vertical: 0, horizontal: 16)
                : const EdgeInsets.all(16.0),
            child: SizedBox(
              height: _pickedAudios.isNotEmpty ||
                  controller.modelList2[0].pickedVideos.isNotEmpty ||
                      _pickedPdfs.isNotEmpty ||
                      imageThumbnailsList.isNotEmpty
                  ? MediaQuery.of(context).size.height * 0.99
                  : MediaQuery.of(context).size.height * 0.96,
              child: apiCalled
                  ? const Center(
                      child: CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    ))
                  : Column(
                      children: [
                        /// thread expanded widget

                        Expanded(
                          child: ListView.builder(
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount: controller.modelList2.length,
                            itemBuilder: (context, ind) {

                              bool isThread = controller.modelList2.length > 1;

                              return Container(
                                margin: const EdgeInsets.all(5),
                                child: GestureDetector(
                                  onTap: () {
                                    controller.currentIndexText = ind;
                                  },
                                  child: Column(
                                    children: [
                                      ///  scdeudle  widget
                                      widget.isPostScheduled
                                          ? ListTile(
                                              minVerticalPadding: 0.0,
                                              horizontalTitleGap: 0.0,
                                              leading: Container(
                                                width: 20,
                                                height: 20,
                                                child: SvgPicture.asset(
                                                  // _pickedPdfs.length > 0 ||
                                                  //     _pickedAudios.length > 0 ||
                                                  //     _pickedVideos.length > 0
                                                  //     ?
                                                  'assets/post_icons/calendar.svg',
                                                  fit: BoxFit.cover,
                                                  height: 200,
                                                  width: 200,
                                                  color: controller.modelList2[ind].pickedVideos
                                                              .isNotEmpty ||
                                                          isMediaAttached ||
                                                          showPolls[controller
                                                              .currentIndexText]
                                                      ? Colors.grey[400]
                                                      : controller.displayColor,
                                                  // : Colors.purple,
                                                ),
                                              ),
                                              title: Text(
                                                '${Strings.thisPostIsScheduledFor} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',

                                                // 'This post is scheduled for ${DateFormat("y-MMM-d hh:mm a")..parse(selectedDateTime)}',
                                              ),
                                              subtitle: GestureDetector(
                                                onTap: () {
                                                  widget.isPostScheduled =
                                                      false;
                                                  setState(() {});
                                                },
                                                child: Text(
                                                  Strings.clear,
                                                  style: const TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                  ),

                                                  // style: Theme.of(context).brightness == Brightness.dark ?
                                                  // TextStyle(color: Colors.white, decoration: TextDecoration.underline)
                                                  //     : TextStyle(color: Colors.black, decoration: TextDecoration.underline),
                                                ),
                                              ),
                                            )
                                          : const SizedBox(),

                                      ///

                                      ListTile(
                                        contentPadding:
                                            const EdgeInsets.only(left: 6),
                                        trailing: closeIcon == false || ind == 0
                                            ? const SizedBox()
                                            : GestureDetector(
                                                onTap: () {
                                                  print(
                                                      'print string :${controller.modelList2[ind].bodyText}');
                                                  setState(() {
                                                    if ((controller
                                                                        .modelList2[
                                                                            ind]
                                                                        .bodyText ==
                                                                    null ||
                                                                controller
                                                                        .modelList2[
                                                                            ind]
                                                                        .bodyText
                                                                        .length ==
                                                                    0) &&
                                                            controller
                                                                .modelList2[ind]
                                                                .mediaData2
                                                                .isEmpty
                                                        // controller.modelList2[ind].listOfVideos.isEmpty &&
                                                        // controller.modelList2[ind].listOfDocuments.isEmpty&&
                                                        // controller.modelList2[ind].listOfAudio.isEmpty

                                                        ) if (widget.controller
                                                            .currentIndexText >
                                                        0) {
                                                      widget.controller
                                                          .currentIndexText = widget
                                                              .controller
                                                              .currentIndexText -
                                                          1;
                                                    }

                                                    controller.modelList2
                                                        .remove(controller
                                                            .modelList2[ind]);
                                                    // {
                                                    //   controller.modelList2.remove(controller.modelList2[ind]);
                                                    // }
                                                  });
                                                  threadCreated = false;
                                                },
                                                child: Icon(
                                                  Icons.clear,
                                                  size: 17,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                        /*leading: widget
                                                    .controller.userProfile ==
                                                null
                                            ? SizedBox(
                                                width: 24,
                                                child: Center(
                                                  child: SpinKitCircle(
                                                    color: Colors.grey,
                                                    size: 40,
                                                  ),
                                                ))
                                            : widget.controller.userProfile
                                                        .profileImage ==
                                                    null
                                                ? const CircleAvatar(
                                                    radius: 22,
                                                    backgroundImage: AssetImage(
                                                        "assets/images/person_placeholder.png"))
                                                : ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30),
                                                    child: FadeInImage(
                                                        fit: BoxFit.cover,
                                                        width: 40,
                                                        height: 40,
                                                        placeholder: const AssetImage(
                                                            'assets/images/person_placeholder.png'),
                                                        image: NetworkImage(widget
                                                                .controller
                                                                .userProfile
                                                                .profileImage
                                                            : "assets/images/person_placeholder.png")),
                                                  ),*/
                                        title: IntrinsicHeight(
                                          child: Row(
                                            children: [
                                              Column(
                                                children: [
                                                  widget.controller.userProfile == null
                                                      ? SizedBox(
                                                          width: 24,
                                                          child: Center(
                                                            child: SpinKitCircle(
                                                              color: Colors.grey,
                                                              size: 40,
                                                            ),
                                                          ))
                                                      : Opacity(
                                                        opacity: widget.controller.currentIndexText == ind ? 1 : 0.5,
                                                        child: widget.controller.userProfile.profileImage == null
                                                            ? CircleAvatar(
                                                                radius: isThread ? 18 : 22,
                                                                backgroundImage: AssetImage("assets/images/person_placeholder.png"))
                                                            : ClipRRect(
                                                                borderRadius: BorderRadius.circular(30),
                                                                child: FadeInImage(
                                                                    fit: BoxFit.cover,
                                                                    width: isThread ? 36 : 40,
                                                                    height: isThread ? 36 : 40,
                                                                    placeholder: AssetImage('assets/images/person_placeholder.png'),
                                                                    image: NetworkImage(widget.controller.userProfile.profileImage != null
                                                                        ? widget.controller.userProfile.profileImage
                                                                        : "assets/images/person_placeholder.png")),
                                                              ),
                                                      ),
                                                  Expanded(child: controller.modelList2.length == ind + 1
                                                      ? const SizedBox() : Container(width: 2, color: Colors.grey.shade400)),
                                                ],
                                              ),
                                              const SizedBox(width: 20),
                                              Expanded(
                                                child: GestureDetector(
                                                  onTap: () {
                                                    controller.currentIndexText = ind;
                                                    isMediaAttached = false;
                                                  },
                                                  child: HashTagTextField(
                                                    autofocus: true,
                                                      onChanged: (value) {

                                                        if (value.length > 5000) {
                                                          setState(() {});
                                                          widget.controller.postText = false;

                                                          // print("widget.controller.postText ${widget.controller.postText}");
                                                          widget.controller.update();
                                                          UtilsMethods.toastMessageShow(Colors.red, Colors.red, Colors.red,
                                                              message: Strings.textLimitExceeded);
                                                        } else {
                                                          setState(() {});

                                                          widget.controller.postText = true;
                                                          widget.controller.update();
                                                        }

                                                        if (value.contains("#") && value.contains("@")) {
                                                          setState(() {
                                                            widget.mentionUser = false;
                                                            widget.mentionTag = false;
                                                          });
                                                        }

                                                        if (value.isEmpty) {
                                                          widget.users.clear();
                                                          widget.tags.clear();

                                                          // print("idjjjjj");
                                                          setState(() {
                                                            widget.mentionUser = true;
                                                            widget.mentionTag = true;
                                                          });
                                                        }

                                                        widget.controller.currentIndexText = ind;
                                                        setState(() {});

                                                        controller.modelList2[ind].bodyText = _controller[ind].text;

                                                        if (value.length > 0 && _controller[ind].text.trim().isNotEmpty)
                                                          setState(() {
                                                            widget.controller.postText = true;
                                                            if (widget.isPostScheduled) {
                                                              visibility = false;
                                                            } else {
                                                              visibility = true;
                                                            }
                                                            closeIcon = false;
                                                          });
                                                        else
                                                          setState(() {
                                                            widget.controller.postText = false;
                                                            visibility = false;
                                                            closeIcon = true;
                                                          });
                                                        if (value.length < 2) {
                                                          /// user tag and mention tag
                                                          widget.mentionUser = false;
                                                          widget.mentionTag = false;
                                                          temp = '';
                                                          tempUsername = '';
                                                          widget.tags.clear();
                                                          widget.users.clear();

                                                          /// end
                                                          visibility = true;
                                                          setState(() {});
                                                        }

                                                        if (isEmojiVisible) {
                                                          widget.controller.focusNode.requestFocus();
                                                          isEmojiVisible = !isEmojiVisible;
                                                        }

                                                      },
                                                    inputFormatters: <TextInputFormatter>[
                                                      UpperCaseSentenceFormatter()
                                                    ],

                                                    /// Called when detection (word starts with #, or # and @) is being typed
                                                    onDetectionTyped:
                                                        (text) async {


                                                      if (!text.contains("#") || !text.contains("@")) {
                                                        setState(
                                                                () {
                                                              widget.mentionUser = false;
                                                              widget.mentionTag = false;
                                                            });
                                                      }

                                                      if (text.contains("#")) {
                                                        tempValue = text;
                                                        print('start with #');
                                                        widget.mentionUser =
                                                        false;
                                                        widget.tags = await widget.controller.searchTags(tempValue.substring(1));

                                                        print(
                                                            "widget.tags ${widget.tags.length}");

                                                        if (widget
                                                            .tags
                                                            .length <=
                                                            0) {
                                                          widget
                                                              .tags
                                                              .clear();
                                                          widget.mentionTag =
                                                          false;
                                                          //  temp='';
                                                          setState(
                                                                  () {});
                                                        } else {
                                                          widget.mentionUser =
                                                          false;
                                                          widget.mentionTag =
                                                          true;
                                                          setState(
                                                                  () {});
                                                        }
                                                      }
                                                      else if (text.contains("@"))
                                                      {
                                                        tempValue = text;
                                                        print("start with @" + tempValue.substring(1));
                                                        widget.mentionTag = false;
                                                        widget.users = await widget.controller.searchChatUser(tempValue.substring(1),
                                                          type: "mention_users",
                                                        );
                                                        if (widget.users.length <= 0) {
                                                          widget.users.clear();
                                                          widget.mentionUser = false;
                                                          setState(() {});
                                                        } else {
                                                          widget.mentionUser = true;
                                                          setState(
                                                                  () {});
                                                        }
                                                      }
                                                    },

                                                    /// Called when detection is fully typed
                                                    onDetectionFinished:
                                                        () {
                                                      tempValue = "";
                                                      print("detection finishedd");
                                                      // tempValue="";
                                                      setState(() {
                                                        widget.mentionUser = false;
                                                        widget.mentionTag = false;
                                                      });


                                                    },
                                                    decorateAtSign: true,
                                                    // focusNode:
                                                    // fNode2[ind],
                                                    // autofocus: true,
                                                    onTap: () {
                                                      widget
                                                          .controller
                                                          .currentIndexText = ind;
                                                     setState(
                                                              () {});
                                                    },
                                                      basicStyle: LightStyles.baseTextTheme.headline2.copyWith(
                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : widget.controller.currentIndexText == ind ? Colors.black : Colors.grey,
                                                        fontWeight: FontWeight.w500,
                                                        fontSize: 14,
                                                      ),
                                                      cursorColor: Theme.of(context)
                                                        .brightness ==
                                                        Brightness
                                                            .dark
                                                        ? Colors
                                                        .white
                                                        : Colors
                                                        .black,
                                                    maxLength: 5000,
                                                    maxLines: showPolls[widget
                                                        .controller
                                                        .currentIndexText]
                                                        ? null
                                                        : widget.mentionUser ||
                                                        widget.mentionTag
                                                        ? null
                                                        : null,
                                                    keyboardType:
                                                    TextInputType
                                                        .multiline,

                                                    maxLengthEnforcement: MaxLengthEnforcement.enforced,
                                                    controller:
                                                    _controller[
                                                    ind] /*isEdit == true?postTextController:controller.modelList2[0].textEditingController*/,
                                                    decoratedStyle:
                                                    LightStyles
                                                        .baseTextTheme
                                                        .headline2
                                                        .copyWith(
                                                      color: Colors
                                                          .blue,
                                                      fontWeight:
                                                      FontWeight
                                                          .w500,
                                                      fontSize: 14,
                                                    ),
                                                    decoration:
                                                    InputDecoration(
                                                        counterText: isThread ? "" : null,
                                                        counterStyle: TextStyle(
                                                          fontSize: 14,
                                                        ),
                                                        contentPadding: EdgeInsets.only(top: 0),
                                                        hintText: showPolls[controller.currentIndexText]
                                                            ? Strings.askAQuestion
                                                            : Strings.writeSomethingHere,
                                                        border: InputBorder.none,
                                                        hintStyle: LightStyles.baseTextTheme.headline3.copyWith(
                                                          fontSize: 13,
                                                        ),
                                                      ),
                                                    )

//                                           HashTagTextField(
//                                             textInputAction:
//                                                 TextInputAction.newline,
//
//                                             decorateAtSign: true,
//                                             focusNode: controller.focusNode,
//
//                                             onTap: () {
//                                               controller.currentIndexText = ind;
//                                               //   nodeFirst[controller.currentIndexText].hasFocus;
//                                               print(
//                                                   'on coursel changes the index:${controller.currentIndexText}');
//                                             },
//                                             basicStyle: LightStyles
//                                                 .baseTextTheme.headline2
//                                                 .copyWith(
//                                               color: Theme.of(context)
//                                                           .brightness ==
//                                                       Brightness.dark
//                                                   ? Colors.white
//                                                   : Colors.black,
//                                               // fontWeight: FontWeight.bold,
//                                             ),
//                                             cursorColor:
//                                                 Theme.of(context).brightness ==
//                                                         Brightness.dark
//                                                     ? Colors.white
//                                                     : Colors.black,
//                                             maxLength: 2000,
//                                             buildCounter: (context,
//                                                     {currentLength,
//                                                     isFocused,
//                                                     maxLength}) =>
//                                                 null,
//                                             maxLines:
//
//                                                 /// changing in mention tag
//                                                 showPolls[controller
//                                                         .currentIndexText]
//                                                     ? 3
//                                                     : widget.mentionUser ||
//                                                             widget.mentionTag
//                                                         ? 2
//                                                         : null,
//                                             keyboardType:
//                                                 TextInputType.multiline,
//                                             maxLengthEnforcement:
//                                                 MaxLengthEnforcement.enforced,
//                                             // focusNode: focusNodeText,
//                                             // focusNode: nodeFirst[controller.currentIndexText],
//
//                                             controller: _controller[
//                                                 ind] /*isEdit == true?postTextController:controller.modelList2[0].textEditingController*/,
//                                             // decoratedStyle:
//                                             // TextStyle(fontSize: 16, color: Colors.blue),
//                                             decoratedStyle: LightStyles
//                                                 .baseTextTheme.headline2
//                                                 .copyWith(
//                                               color: Theme.of(context)
//                                                           .brightness ==
//                                                       Brightness.dark
//                                                   ? Colors.blue
//                                                   : Colors.blue,
//                                               // fontWeight: FontWeight.bold,
//                                             ),
//                                             decoration: InputDecoration(
//                                               contentPadding:
//                                                   EdgeInsets.only(top: 16),
//                                               hintText: showPolls[controller
//                                                       .currentIndexText]
//                                                   ? 'Ask a question...'
//                                                   : Strings.writeSomethingHere,
//                                               hintStyle: LightStyles
//                                                   .baseTextTheme.headline3,
//                                               border: InputBorder.none,
//                                             ),
//
//                                             onChanged: (value) {
//                                               if (value == "\n") {
//                                                 print("endl");
//                                               }
//
//                                               if (value.contains("#") &&
//                                                   value.contains("@")) {
//                                                 setState(() {
//                                                   widget.mentionUser = false;
//                                                   widget.mentionTag = false;
//                                                 });
//                                               }
//                                               print('change value $value');
//                                               widget.controller
//                                                   .currentIndexText = ind;
//                                               setState(() {
//                                                 controller.modelList2[controller.currentIndexText].postBodyLength = value.length;
//
//                                                 if(widget.controller.modelList2[widget.controller.currentIndexText].postBodyLength>2000)
//                                                 {
//
//                                                   widget.controller.postText = false;
//                                                   widget.controller.update();
//                                                   UtilsMethods.toastMessageShow(
//                                                       Colors.red,
//                                                       Colors.red,
//                                                       Colors.red,
//                                                       message: Strings.textLimitExceeded);
//
//                                                 }
//                                                 else{
//                                                   widget.controller.postText = true;
//                                                   widget.controller.update();
//
//                                                 }
//
//                                               });
//
//                                               print(_controller[ind].text);
//
//                                               controller.modelList2[ind]
//                                                       .bodyText =
//                                                   _controller[ind].text;
//
//                                               print('textttttttttt');
//                                               print("list of indexprint:$ind");
//                                               print(
//                                                   'current index value:${widget.controller.currentIndexText}');
//                                               print(
//                                                   'vlaue of controller:${widget.controller.modelList2[ind].bodyText}');
//                                               if (value.length > 0 &&
//                                                   _controller[ind]
//                                                       .text
//                                                       .trim()
//                                                       .isNotEmpty)
//                                                 setState(() {
//                                                   widget.controller.postText =
//                                                       true;
//                                                   if (widget.isPostScheduled) {
//                                                     visibility = false;
//                                                   } else {
//                                                     visibility = true;
//                                                   }
//                                                   closeIcon = false;
//                                                 });
//                                               else
//                                                 setState(() {
//                                                   widget.controller.postText =
//                                                       false;
//                                                   visibility = false;
//                                                   closeIcon = true;
//                                                 });
//                                               if (value.length < 2) {
//                                                 /// user tag and mention tag
//                                                 widget.mentionUser = false;
//                                                 widget.mentionTag = false;
//                                                 temp = '';
//                                                 tempUsername = '';
//                                                 widget.tags.clear();
//                                                 widget.users.clear();
//
//                                                 /// end
//                                                 visibility = true;
//                                                 setState(() {});
//                                               }
//                                             },
//
//                                             /// Called when detection (word starts with #, or # and @) is being typed
//                                             onDetectionTyped: (text) async {
//                                               print(
//                                                   "detection finished " + text);
//                                               print('change value $text');
//                                               if (!text.contains("#") ||
//                                                   !text.contains("@")) {
//                                                 setState(() {
//                                                   widget.mentionUser = false;
//                                                   widget.mentionTag = false;
//                                                 });
//                                               }
//
//                                               if (text.contains("#")) {
//                                                 tempValue = text;
//
//                                                 print('start with #');
//                                                 widget.mentionUser = false;
//                                                 widget.tags = await widget
//                                                     .controller
//                                                     .searchTags(
//                                                         tempValue.substring(1));
//                                                 if (widget.tags.length <= 0) {
//                                                   widget.tags.clear();
//                                                   widget.mentionTag = false;
//                                                   //  temp='';
//                                                   setState(() {});
//                                                 } else {
//                                                   widget.mentionUser = false;
//                                                   widget.mentionTag = true;
//
//                                                   setState(() {});
//                                                 }
//                                               } else if (text.contains("@")) {
//                                                 tempValue = text;
//
//                                                 print("start with @" +
//                                                     tempValue.substring(2));
//                                                 widget.mentionTag = false;
//                                                 widget.users = await widget
//                                                     .controller
//                                                     .searchChatUser(
//                                                   tempValue.substring(1),
//                                                   type: "mention_users",
//                                                 );
//                                                 if (widget.users.length <= 0) {
//                                                   widget.users.clear();
//                                                   widget.mentionUser = false;
//                                                   setState(() {});
//                                                 } else {
//                                                   widget.mentionUser = true;
//                                                   setState(() {});
//                                                 }
//                                               }
//                                             },
//
//                                             /// Called when detection is fully typed
//                                             onDetectionFinished: () {
//                                               print("detection finishedd");
//                                               // tempValue="";
//
//                                               setState(() {
//                                                 widget.mentionUser = false;
//                                                 widget.mentionTag = false;
//                                               });
//
// /*
//                                                             setState(() {
//                                                               widget.mentionTag=false;
//                                                               widget.mentionUser=false;
//
//                                                             });*/
//                                             },
//                                           ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),

                                      /// mention tag  widget
                                      !widget.mentionTag
                                          ? const SizedBox()
                                          : Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    color: Colors.grey[300],
                                                    width: 0.5,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                ),
                                                height: 150,
                                                width: 300,
                                                child: widget.tags.length == 0
                                                    ? SpinKitWave(
                                                        size: 30,
                                                        color:
                                                            const Color(0xFFedab30),
                                                      )
                                                    : ListView.builder(
                                                        itemCount:
                                                            widget.tags.length,
                                                        itemBuilder:
                                                            (context, index) {
                                                          return ListTile(
                                                            onTap: () async {
                                                              //   temp='';
                                                              print("textvalue " +
                                                                  _controller[controller
                                                                          .currentIndexText]
                                                                      .text);
                                                              print(tempValue);
                                                              print(widget.tags[
                                                                      index]
                                                                  ['title']);

                                                              /*     _controller[controller.currentIndexText].text =
                                                        _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                       ' ' +
                                                            widget.tags[index]['title'];*/
                                                              _controller[controller
                                                                      .currentIndexText]
                                                                  .text = _controller[
                                                                      controller
                                                                          .currentIndexText]
                                                                  .text
                                                                  .substring(
                                                                      0,
                                                                      _controller[controller.currentIndexText]
                                                                              .text
                                                                              .length -
                                                                          tempValue
                                                                              .length);
                                                              print("tempvalue" +
                                                                  _controller[controller
                                                                          .currentIndexText]
                                                                      .text);
                                                              tempValue =
                                                                  widget.tags[
                                                                          index]
                                                                      ['title'];
                                                              print("tempvalue" +
                                                                  tempValue);

                                                              _controller[controller
                                                                      .currentIndexText]
                                                                  .text = _controller[
                                                                          controller
                                                                              .currentIndexText]
                                                                      .text +
                                                                  " " +
                                                                  tempValue +
                                                                  " ";
                                                              // tempValue="";
                                                              _controller[controller
                                                                          .currentIndexText]
                                                                      .selection =
                                                                  TextSelection.fromPosition(TextPosition(
                                                                      offset: _controller[
                                                                              controller.currentIndexText]
                                                                          .text
                                                                          .length));
                                                              widget.tags
                                                                  .clear();
                                                              widget.mentionTag =
                                                                  false;
                                                              //  widget.tags = [];
                                                              tempValue = "";
                                                              focusNodeText
                                                                  .requestFocus();

                                                              setState(() {});
                                                              _controller[controller
                                                                          .currentIndexText]
                                                                      .selection =
                                                                  TextSelection.fromPosition(TextPosition(
                                                                      offset: _controller[
                                                                              controller.currentIndexText]
                                                                          .text
                                                                          .length));

                                                              // widget.focusNode
                                                              //     .requestFocus();
                                                              print(
                                                                  'selection tag  ${_controller[controller.currentIndexText].selection}');
                                                              print(
                                                                  'value temp${_controller[controller.currentIndexText].text}');
                                                            },
                                                            title: Text(
                                                              widget.tags
                                                                      .isNotEmpty
                                                                  ? widget.tags[
                                                                          index]
                                                                      ['title']
                                                                  : "",
                                                            ),
                                                          );
                                                        }),
                                              ),
                                            ),

                                      /// mention user  widget
                                      !widget.mentionUser
                                          ? const SizedBox()
                                          : Align(
                                              alignment: Alignment.centerLeft,
                                              child: Container(
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    color: Colors.grey[300],
                                                    width: 0.5,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(4),
                                                ),
                                                height: 150,
                                                width: 300,
                                                child: widget.users.length == 0
                                                    ? SpinKitWave(
                                                        size: 30,
                                                        color:
                                                            const Color(0xFFedab30),
                                                      )
                                                    : ListView.builder(
                                                        itemCount:
                                                            widget.users.length,
                                                        itemBuilder:
                                                            (context, index) {
                                                          return ListTile(
                                                            onTap: () async {
                                                              /*     _controller[controller.currentIndexText].text =
                                                        _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                       ' ' +
                                                            widget.tags[index]['title'];*/
                                                              _controller[controller
                                                                      .currentIndexText]
                                                                  .text = _controller[
                                                                      controller
                                                                          .currentIndexText]
                                                                  .text
                                                                  .substring(
                                                                      0,
                                                                      _controller[controller.currentIndexText]
                                                                              .text
                                                                              .length -
                                                                          tempValue
                                                                              .length);
                                                              print("tempvalue" +
                                                                  _controller[controller
                                                                          .currentIndexText]
                                                                      .text);
                                                              tempValue = widget
                                                                          .users[
                                                                      index]
                                                                  ['username'];
                                                              print("tempvalue" +
                                                                  tempValue);

                                                              _controller[controller
                                                                      .currentIndexText]
                                                                  .text = _controller[
                                                                          controller
                                                                              .currentIndexText]
                                                                      .text +
                                                                  " " +
                                                                  tempValue +
                                                                  " ";
                                                              // tempValue="";
                                                              _controller[controller
                                                                          .currentIndexText]
                                                                      .selection =
                                                                  TextSelection.fromPosition(TextPosition(
                                                                      offset: _controller[
                                                                              controller.currentIndexText]
                                                                          .text
                                                                          .length));
                                                              widget.users
                                                                  .clear();
                                                              widget.mentionUser =
                                                                  false;
                                                              //  widget.tags = [];

                                                              tempValue = "";
                                                              focusNodeText
                                                                  .requestFocus();
                                                              setState(() {});
                                                              // widget.focusNode
                                                              //     .requestFocus();

                                                              _controller[controller
                                                                          .currentIndexText]
                                                                      .selection =
                                                                  TextSelection.fromPosition(TextPosition(
                                                                      offset: _controller[
                                                                              controller.currentIndexText]
                                                                          .text
                                                                          .length));
                                                            },
                                                            title: Text(widget
                                                                        .users[
                                                                    index]
                                                                ['username']),
                                                          );
                                                        }),
                                              ),
                                            ),

                                      /// end mention user
                                      widget.controller.postText
                                          ? widget.controller.urlOrNot(
                                                  _controller[controller
                                                          .currentIndexText]
                                                      .text)
                                              ?
                                      _controller[controller.currentIndexText].text[1]!="@"?
                                      Container(
                                                  child: urlFetch(),
                                                )
                                              : Container()
                                          : Container():Container(),

                                      ///show pools
                                      showPolls[ind]
                                          ? Align(
                                              alignment: Alignment.center,
                                              child: Container(
                                                width: 600,
                                                margin: const EdgeInsets.only(
                                                    bottom: 16, top: 16),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    border: Border.all(
                                                        color: Colors.grey,
                                                        width: 1)),
                                                child: Column(
                                                  children: [
                                                    const SizedBox(height: 10),
                                                    buildPollOptions(
                                                      optionNumber: 1,
                                                      //   indexOf: ind,
                                                    ),
                                                    buildPollOptions(
                                                      optionNumber: 2,
                                                      // indexOf: ind,
                                                    ),
                                                    option == 3 || option == 4
                                                        ? buildPollOptions(
                                                            optionNumber: 3,
                                                            //   indexOf: ind,
                                                          )
                                                        : SizedBox(),
                                                    option == 4
                                                        ? buildPollOptions(
                                                            optionNumber: 4,
                                                            // indexOf: ind,
                                                          )
                                                        : const SizedBox(),
                                                    const SizedBox(
                                                      height: 6,
                                                    ),
                                                    Container(
                                                      height: 1,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.grey,
                                                    ),
                                                    const SizedBox(
                                                      height: 6,
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                              vertical: 6.0,
                                                              horizontal: 10),
                                                      child: Align(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        child: Text(
                                                          Strings.pollLength,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline4
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      height: 6,
                                                    ),
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                              vertical: 6.0,
                                                              horizontal: 10),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                        children: [
                                                          /// pools days selected button
                                                          ButtonTheme(
                                                            materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                            child: Expanded(
                                                              child:
                                                                  DropdownButtonFormField<
                                                                      String>(
                                                                icon: const Icon(Icons
                                                                    .keyboard_arrow_down),
                                                                isExpanded:
                                                                    true,
                                                                decoration:
                                                                    InputDecoration(
                                                                  border:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  disabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: controller
                                                                          .displayColor,
                                                                    ),
                                                                  ),
                                                                  labelText:
                                                                      Strings.day,
                                                                  labelStyle: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : controller
                                                                            .displayColor,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                value: 0
                                                                    .toString(),
                                                                hint: Text(
                                                                  Strings.day,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                items: days.map(
                                                                    (int
                                                                        value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value
                                                                        .toString(),
                                                                    child: Text(
                                                                      value
                                                                          .toString(),
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize:
                                                                            14,
                                                                      ),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged:
                                                                    (days) {
                                                                  pollDays =
                                                                      days;
                                                                  controller
                                                                      .modelList2[
                                                                          controller
                                                                              .currentIndexText]
                                                                      .days = days;
                                                                  setState(
                                                                      () {});
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            width: 10,
                                                          ),

                                                          /// pools hour selected button
                                                          ButtonTheme(
                                                            materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                            child: Expanded(
                                                              child:
                                                                  DropdownButtonFormField<
                                                                      String>(
                                                                icon: const Icon(Icons
                                                                    .keyboard_arrow_down),
                                                                isExpanded:
                                                                    true,
                                                                decoration:
                                                                    InputDecoration(
                                                                  border:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  disabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: controller
                                                                          .displayColor,
                                                                    ),
                                                                  ),
                                                                  labelText:
                                                                      Strings.hours,
                                                                  labelStyle: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : controller
                                                                            .displayColor,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                value: 0
                                                                    .toString(),
                                                                hint: Text(
                                                                 Strings.hours,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                items: List.generate(
                                                                    24,
                                                                    (index) =>
                                                                        index).map(
                                                                    (int
                                                                        value) {
                                                                  return DropdownMenuItem<
                                                                      String>(
                                                                    value: value
                                                                        .toString(),
                                                                    child: Text(
                                                                      value
                                                                          .toString(),
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme.of(context).brightness ==
                                                                                Brightness.dark
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                        fontSize:
                                                                            14,
                                                                      ),
                                                                    ),
                                                                  );
                                                                }).toList(),
                                                                onChanged:
                                                                    (hours) {
                                                                  pollHours =
                                                                      hours;
                                                                  controller
                                                                      .modelList2[
                                                                          controller
                                                                              .currentIndexText]
                                                                      .hours = hours;
                                                                  setState(
                                                                      () {});
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                          const SizedBox(
                                                            width: 10,
                                                          ),

                                                          /// pools mint selected button
                                                          ButtonTheme(
                                                            materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                            child: Expanded(
                                                              child:
                                                                  DropdownButtonFormField<
                                                                      String>(
                                                                icon: const Icon(Icons
                                                                    .keyboard_arrow_down),
                                                                isExpanded:
                                                                    true,
                                                                decoration:
                                                                    InputDecoration(
                                                                  border:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  disabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .grey,
                                                                    ),
                                                                  ),
                                                                  enabledBorder:
                                                                      OutlineInputBorder(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            10),
                                                                    borderSide:
                                                                        BorderSide(
                                                                      color: controller
                                                                          .displayColor,
                                                                    ),
                                                                  ),
                                                                  labelText:
                                                                    Strings.minutes,
                                                                  labelStyle: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : controller
                                                                            .displayColor,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                value: pollHours ==
                                                                            '0' &&
                                                                        pollDays ==
                                                                            '0'
                                                                    ? 5.toString()
                                                                    : 0.toString(),
                                                                hint: Text(
                                                                 Strings.minutes,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                alignment: Alignment
                                                                    .bottomCenter,
                                                                items: pollHours ==
                                                                            '0' &&
                                                                        pollDays ==
                                                                            '0'
                                                                    ? minutes
                                                                        .map((int
                                                                            value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value:
                                                                              value.toString(),
                                                                          child:
                                                                              Text(
                                                                            value.toString(),
                                                                            style:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList()

                                                                    /// pool mint list generate
                                                                    : List.generate(
                                                                        60,
                                                                        (index) =>
                                                                            index).map((int
                                                                        value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value:
                                                                              value.toString(),
                                                                          child:
                                                                              Text(value.toString()),
                                                                        );
                                                                      }).toList(),
                                                                onChanged:
                                                                    (minutes) {
                                                                  pollMinutes =
                                                                      minutes;
                                                                  controller
                                                                      .modelList2[
                                                                          controller
                                                                              .currentIndexText]
                                                                      .minutes = minutes;
                                                                },
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      height: 6,
                                                    ),
                                                    Container(
                                                      height: 1,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.grey,
                                                    ),

                                                    /// remove pool button
                                                    InkWell(
                                                      hoverColor:
                                                          Colors.red[100],
                                                      onTap: () {
                                                        showPolls[controller
                                                                .currentIndexText] =
                                                            false;
                                                        option = 2;
                                                        isOptionTwo = true;
                                                        controller
                                                            .modelList2[controller
                                                                .currentIndexText]
                                                            .poolThread = false;

                                                        setState(() {});
                                                      },
                                                      child: Container(
                                                        alignment:
                                                            Alignment.center,
                                                        margin: const EdgeInsets
                                                            .symmetric(
                                                                vertical: 6),
                                                        width: 600,
                                                        height: 40,
                                                        child: Text(
                                                          Strings.removePoll,
                                                          style:
                                                              Theme.of(context)
                                                                  .textTheme
                                                                  .headline3
                                                                  .copyWith(
                                                                    fontSize:
                                                                        18,
                                                                    color: Colors
                                                                        .redAccent,
                                                                  ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            )
                                          : const SizedBox(),

                                      // Edit Images & Videos
                                      isEdit && controller.modelList2[ind].mediaData2.isNotEmpty
                                      // &&
                                      //     // && controller.modelList2[ind].mediaData2[0].name=="media"
                                      //     !controller.modelList2[ind]
                                      //         .mediaData2[0].name
                                      //         .contains('.pdf') &&
                                      //     (controller
                                      //                 .modelList2[ind]
                                      //                 .mediaData2[0]
                                      //                 .thumbnailUrl ==
                                      //             null ||
                                      //         controller
                                      //             .modelList2[ind]
                                      //             .mediaData2[0]
                                      //             .thumbnailUrl
                                      //             .isEmpty)
                                      /*  imageWidgetKey ==1*/ ? SizedBox(
                                        height: controller.modelList2[ind].mediaData2.length <
                                            2
                                            ? 500
                                            : 200,
                                        // width: 180,
                                        child: ListView.separated(
                                            separatorBuilder: (_, __) {
                                              return const SizedBox(width: 4);
                                            },
                                            scrollDirection:
                                            Axis.horizontal,
                                            itemCount: controller.modelList2[ind].mediaData2
                                                .length,
                                            itemBuilder:
                                                (context, index) {
                                              debugPrint("controller.modelList2[ind].mediaData2[0].fileType::: ${controller.modelList2[ind].mediaData2[0].toJson()}");
                                              return
                                                // !controller
                                                //       .modelList2[ind]
                                                //       .mediaData2
                                                //       .asMap()
                                                //       .containsKey(index)
                                                //   ? Container(
                                                //       height: 100,
                                                //       alignment: Alignment
                                                //           .center,
                                                //       child: Column(
                                                //         crossAxisAlignment:
                                                //             CrossAxisAlignment
                                                //                 .center,
                                                //         children: [
                                                //           CircularProgressIndicator(
                                                //             color: MyColors
                                                //                 .BlueColor,
                                                //           ),
                                                //           SizedBox(
                                                //               height: 6),
                                                //           Text(
                                                //             'Uploading...',
                                                //             style: TextStyle(
                                                //                 color: MyColors
                                                //                     .BlueColor,
                                                //                 fontWeight:
                                                //                     FontWeight
                                                //                         .w700),
                                                //           ),
                                                //         ],
                                                //       ),
                                                //     )
                                                //   :
                                                SizedBox(
                                                  height: controller.modelList2[ind].mediaData2
                                                      .length <
                                                      2
                                                      ? 450
                                                      : 200,
                                                  width: controller.modelList2[ind].mediaData2
                                                      .length <
                                                      2
                                                      ? MediaQuery.of(
                                                      context)
                                                      .size
                                                      .width *
                                                      0.9
                                                      : 160,
                                                  child: Stack(
                                                    children: [
                                                      Container(
                                                        decoration:
                                                        BoxDecoration(
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                        ),
                                                        height:
                                                        _pickedImage.length <
                                                            2
                                                            ? 450
                                                            : 200,
                                                        width: controller.modelList2[ind].mediaData2
                                                            .length <
                                                            2
                                                            ? MediaQuery.of(context)
                                                            .size
                                                            .width *
                                                            0.9
                                                            : 160,
                                                        child:
                                                        ClipRRect(
                                                          borderRadius:
                                                          BorderRadius.circular(
                                                              15),
                                                          child: controller.modelList2[ind].mediaData2[0].name == "media"
                                                                      ? Image.network(
                                                                          controller.modelList2[ind].mediaData2[0].thumbnailUrl ??
                                                                              'https://via.placeholder.com/150',
                                                                          height: MediaQuery.of(context).size.height / 3.8,
                                                                          width: double.infinity,
                                                                          fit: BoxFit.cover,
                                                                        )
                                                                      : Image.network(
                                                                          controller.modelList2[ind].mediaData2[index].url,
                                                                          fit: BoxFit.cover,
                                                                        )
                                                            ),
                                                      ),
                                                      Positioned(
                                                        right: 6,
                                                        top: 10,
                                                        child:
                                                        CircleAvatar(
                                                          radius: 14,
                                                          backgroundColor:
                                                          const Color(
                                                              0xFF4b4f53),
                                                          child:
                                                          IconButton(
                                                            padding:
                                                            EdgeInsets
                                                                .zero,
                                                            icon:
                                                            const Icon(
                                                              Icons
                                                                  .close_rounded,
                                                              size:
                                                              16,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                            onPressed:
                                                                () {
                                                              LoggingUtils.printValue(
                                                                  "close image",
                                                                  controller.modelList2[controller.currentIndexText].imagePickCount);
                                                              controller
                                                                  .modelList2[controller
                                                                  .currentIndexText]
                                                                  .imagePickCount = controller
                                                                  .modelList2[controller.currentIndexText].imagePickCount -
                                                                  1;

                                                              if (controller
                                                                  .modelList2[controller.currentIndexText]
                                                                  .bodyText
                                                                  .isEmpty) {
                                                                widget
                                                                    .controller
                                                                    .postText = false;
                                                                widget
                                                                    .controller
                                                                    .update();
                                                              }

                                                              print(
                                                                  "image");
                                                              widget
                                                                  .controller
                                                                  .mediaData
                                                                  .clear();
                                                              //  widget.controller.update();
                                                              if (controller.modelList2[ind].mediaData2.length ==
                                                                  1) {
                                                                print(
                                                                    "image");
                                                                isMediaAttached =
                                                                false;
                                                                //  isEdit=false;
                                                              }

                                                              if (controller.modelList2[ind].imageCounter !=
                                                                  null &&
                                                                  controller.modelList2[ind].imageCounter >=
                                                                      0) {
                                                                print(
                                                                    "image index ${index}");
                                                                controller
                                                                    .modelList2[controller.currentIndexText]
                                                                    .imageDescriptionController
                                                                    .remove(controller.modelList2[controller.currentIndexText].imageDescriptionController[index]);
                                                                if (controller.modelList2[ind].imageCounter >=
                                                                    1) {
                                                                  controller.modelList2[controller.currentIndexText].imageCounter--;
                                                                }

                                                                widget
                                                                    .controller
                                                                    .update();
                                                              }
                                                              if (controller.modelList2[ind].descriptionCounter !=
                                                                  null &&
                                                                  controller.modelList2[ind].descriptionCounter >
                                                                      1) {
                                                                print(
                                                                    "   before    controller.modelList2[controller.currentIndexText].descriptionCounter-- ${controller.modelList2[controller.currentIndexText].descriptionCounter}");
                                                                controller
                                                                    .modelList2[controller.currentIndexText]
                                                                    .descriptionCounter--;
                                                                print(
                                                                    "    after   controller.modelList2[controller.currentIndexText].descriptionCounter-- ${controller.modelList2[controller.currentIndexText].descriptionCounter} ");
                                                                widget
                                                                    .controller
                                                                    .update();
                                                              }

                                                              setState(
                                                                      () {});

                                                              print(controller.modelList2[ind].mediaData2.length.toString() +
                                                                  "remaining images length");
                                                              // controller
                                                              //     .modelList2[ind]
                                                              //     .mediaData2
                                                              //     .remove(controller.modelList2[ind].mediaData2[index]);
                                                              controller.modelList2[ind].mediaData2.removeAt(index);
                                                              // imageThumbnailsList.removeAt(index);
                                                              setState(
                                                                      () {});
                                                            },
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );
                                            }),
                                      )
                                          :const SizedBox(),

                                      /// threadimages

                                      controller.modelList2[ind].listFilesMob.isNotEmpty
                                          // &&
                                          //     // && controller.modelList2[ind].mediaData2[0].name=="media"
                                          //     !controller.modelList2[ind]
                                          //         .mediaData2[0].name
                                          //         .contains('.pdf') &&
                                          //     (controller
                                          //                 .modelList2[ind]
                                          //                 .mediaData2[0]
                                          //                 .thumbnailUrl ==
                                          //             null ||
                                          //         controller
                                          //             .modelList2[ind]
                                          //             .mediaData2[0]
                                          //             .thumbnailUrl
                                          //             .isEmpty)
                                          /*  imageWidgetKey ==1*/ ? SizedBox(
                                              height: controller.modelList2[ind].listFilesMob.length <
                                                      2
                                                  ? 500
                                                  : 200,
                                              // width: 180,
                                              child: ListView.separated(
                                                  separatorBuilder: (_, __) {
                                                    return const SizedBox(width: 4);
                                                  },
                                                  scrollDirection:
                                                      Axis.horizontal,
                                                  itemCount: controller.modelList2[ind].listFilesMob
                                                      .length,
                                                  itemBuilder:
                                                      (context, index) {
                                                    return
                                                      // !controller
                                                      //       .modelList2[ind]
                                                      //       .mediaData2
                                                      //       .asMap()
                                                      //       .containsKey(index)
                                                      //   ? Container(
                                                      //       height: 100,
                                                      //       alignment: Alignment
                                                      //           .center,
                                                      //       child: Column(
                                                      //         crossAxisAlignment:
                                                      //             CrossAxisAlignment
                                                      //                 .center,
                                                      //         children: [
                                                      //           CircularProgressIndicator(
                                                      //             color: MyColors
                                                      //                 .BlueColor,
                                                      //           ),
                                                      //           SizedBox(
                                                      //               height: 6),
                                                      //           Text(
                                                      //             'Uploading...',
                                                      //             style: TextStyle(
                                                      //                 color: MyColors
                                                      //                     .BlueColor,
                                                      //                 fontWeight:
                                                      //                     FontWeight
                                                      //                         .w700),
                                                      //           ),
                                                      //         ],
                                                      //       ),
                                                      //     )
                                                      //   :
                                                    SizedBox(
                                                            height: controller.modelList2[ind].listFilesMob
                                                                        .length <
                                                                    2
                                                                ? 450
                                                                : 200,
                                                            width: controller.modelList2[ind].listFilesMob
                                                                        .length <
                                                                    2
                                                                ? MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.9
                                                                : 160,
                                                            child: Stack(
                                                              children: [
                                                                Container(
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            15),
                                                                  ),
                                                                  height:
                                                                      _pickedImage.length <
                                                                              2
                                                                          ? 450
                                                                          : 200,
                                                                  width: controller.modelList2[ind].listFilesMob
                                                                              .length <
                                                                          2
                                                                      ? MediaQuery.of(context)
                                                                              .size
                                                                              .width *
                                                                          0.9
                                                                      : 160,
                                                                  child:
                                                                      ClipRRect(
                                                                    borderRadius:
                                                                        BorderRadius.circular(
                                                                            15),
                                                                    child: 
                                                                          Image.file(File(controller.modelList2[ind].listFilesMob[index].path), fit: BoxFit.cover,),
                                                                    // Image
                                                                    //     .network(
                                                                    //   controller
                                                                    //       .modelList2[
                                                                    //           ind]
                                                                    //       .mediaData2[
                                                                    //           index]
                                                                    //       .url,
                                                                    //   fit: BoxFit
                                                                    //       .cover,
                                                                    // ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  right: 6,
                                                                  top: 10,
                                                                  child:
                                                                      CircleAvatar(
                                                                    radius: 14,
                                                                    backgroundColor:
                                                                        const Color(
                                                                            0xFF4b4f53),
                                                                    child:
                                                                        IconButton(
                                                                      padding:
                                                                          EdgeInsets
                                                                              .zero,
                                                                      icon:
                                                                          const Icon(
                                                                        Icons
                                                                            .close_rounded,
                                                                        size:
                                                                            16,
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      onPressed:
                                                                          () {
                                                                        controller
                                                                            .modelList2[controller
                                                                                .currentIndexText]
                                                                            .imagePickCount = controller
                                                                                .modelList2[controller.currentIndexText].imagePickCount -
                                                                            1;

                                                                        if (controller
                                                                            .modelList2[controller.currentIndexText]
                                                                            .bodyText
                                                                            .isEmpty) {
                                                                          widget
                                                                              .controller
                                                                              .postText = false;
                                                                          widget
                                                                              .controller
                                                                              .update();
                                                                        }

                                                                        print(
                                                                            "image");
                                                                        widget
                                                                            .controller
                                                                            .mediaData
                                                                            .clear();
                                                                        //  widget.controller.update();
                                                                        if (controller.modelList2[ind].listFilesMob.length ==
                                                                            1) {
                                                                          print(
                                                                              "image");
                                                                          isMediaAttached =
                                                                              false;
                                                                          //  isEdit=false;
                                                                        }

                                                                        if (controller.modelList2[ind].imageCounter !=
                                                                                null &&
                                                                            controller.modelList2[ind].imageCounter >=
                                                                                0) {
                                                                          print(
                                                                              "image index ${index}");
                                                                          controller
                                                                              .modelList2[controller.currentIndexText]
                                                                              .imageDescriptionController
                                                                              .remove(controller.modelList2[controller.currentIndexText].imageDescriptionController[index]);
                                                                          if (controller.modelList2[ind].imageCounter >=
                                                                              1) {
                                                                            controller.modelList2[controller.currentIndexText].imageCounter--;
                                                                          }

                                                                          widget
                                                                              .controller
                                                                              .update();
                                                                        }
                                                                        if (controller.modelList2[ind].descriptionCounter !=
                                                                                null &&
                                                                            controller.modelList2[ind].descriptionCounter >
                                                                                1) {
                                                                          controller
                                                                              .modelList2[controller.currentIndexText]
                                                                              .descriptionCounter--;
                                                                          widget
                                                                              .controller
                                                                              .update();
                                                                        }

                                                                        setState(
                                                                            () {});

                                                                        print(controller.modelList2[ind].mediaData2.length.toString() +
                                                                            "remaining images length");
                                                                        // controller
                                                                        //     .modelList2[ind]
                                                                        //     .mediaData2
                                                                        //     .remove(controller.modelList2[ind].mediaData2[index]);
                                                                        controller.modelList2[ind].listFilesMob.removeAt(index);
                                                                        // imageThumbnailsList.removeAt(index);
                                                                        setState(
                                                                            () {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          );
                                                  }),
                                            )
                                          :const SizedBox(),
                                          ///threadvideo
                                      controller.modelList2[ind].pickedVideos.isNotEmpty
                                      // controller.modelList2[ind].mediaData2.length > 0 &&
                                      //             controller.modelList2[ind]
                                      //                     .mediaData2[0].name ==
                                      //                 "media"
                                              /*videoWidgetKey ==1*/ ? Align(
                                                  alignment: Alignment.center,
                                                  child: SizedBox(
                                                    height: controller.modelList2[ind].pickedVideos.isEmpty
                                                    // controller
                                                    //         .modelList2[ind]
                                                    //         .mediaData2
                                                    //   .isEmpty
                                                        ? 100
                                                        : MediaQuery.of(context)
                                                                .size
                                                                .height /
                                                            4,
                                                    width: controller.modelList2[ind].pickedVideos.isEmpty
                                                    // controller
                                                    //         .modelList2[ind]
                                                    //         .mediaData2
                                                    //         .isEmpty
                                                        ? 100
                                                        : double.infinity,
                                                    child: Stack(
                                                      children: [
                                                        SizedBox(
                                                          height: controller.modelList2[ind].pickedVideos.isEmpty
                                                          // controller
                                                          //         .modelList2[
                                                          //             ind]
                                                          //         .mediaData2
                                                          //         .isEmpty
                                                              ? 100
                                                              : MediaQuery.of(
                                                                          context)
                                                                      .size
                                                                      .height /
                                                                  4,
                                                          width: controller.modelList2[ind].pickedVideos.isEmpty
                                                          // controller
                                                          //         .modelList2[
                                                          //             ind]
                                                          //         .mediaData2
                                                          //         .isEmpty
                                                              ? 100
                                                              : double
                                                                  .infinity,
                                                          child: controller.modelList2[ind].pickedVideos.isEmpty
                                                          // controller
                                                          //         .modelList2[
                                                          //             ind]
                                                          //         .mediaData2
                                                          //         .isEmpty
                                                              ? Align(
                                                                  alignment:
                                                                      Alignment
                                                                          .center,
                                                                  child: Column(
                                                                    children: [
                                                                  const CircularProgressIndicator(
                                                                      color:
                                                                          MyColors.BlueColor),
                                                                  const SizedBox(
                                                                      height:
                                                                          6),
                                                                  Text(
                                                                    Strings.uploading,
                                                                    style: const TextStyle(
                                                                        color: Color(0xFFedab30),
                                                                        fontWeight: FontWeight.w700),
                                                                  ),
                                                                    ],
                                                                  ),
                                                                )
                                                              : controller.modelList2[ind].videoThumbnail != null ? Image.memory(
                                                            controller.modelList2[ind].videoThumbnail,
                                                            // controller.videoThumbnail ?? 'https://via.placeholder.com/150',
                                                                  // controller
                                                                  //         .modelList2[ind]
                                                                  //         .mediaData2[0]
                                                                  //         .thumbnailUrl ??
                                                                  //     'https://via.placeholder.com/150',
                                                            // "https://www.urba-ea.org/wp-content/plugins/video-thumbnails/default.jpg",
                                                                  height: MediaQuery.of(context)
                                                                          .size
                                                                          .height /
                                                                      3.8,
                                                                  width: double
                                                                      .infinity,
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ) : Text("no video")/*Image.asset("assets/images/video_placeholder.png",height: MediaQuery.of(context)
                                                              .size
                                                              .height /
                                                              3.8,
                                                            width: double
                                                                .infinity,
                                                            fit: BoxFit
                                                                .cover,)*/,
                                                        ),
                                                        Positioned(
                                                          right: 6,
                                                          top: 10,
                                                          child: controller.modelList2[ind].pickedVideos.isEmpty
                                                          // controller
                                                          //         .modelList2[
                                                          //             ind]
                                                          //         .mediaData2
                                                          //         .isEmpty
                                                              ? const SizedBox()
                                                              : CircleAvatar(
                                                                  radius: 14,
                                                                  backgroundColor:
                                                                      Colors
                                                                          .grey,
                                                                  child:
                                                                      IconButton(
                                                                    padding:
                                                                        EdgeInsets
                                                                            .zero,
                                                                    icon:
                                                                        const Icon(
                                                                      Icons
                                                                          .close_rounded,
                                                                      size:
                                                                          16,
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                    onPressed:
                                                                        () {
                                                                      widget
                                                                          .controller
                                                                          .postText = false;
                                                                      widget
                                                                          .controller
                                                                          .update();

                                                                      print(
                                                                          "enter video");

                                                                      // controller.modelList2[ind].mediaData2.clear();

                                                                      // if (controller.modelList2[ind].mediaData2.length == 1) {
                                                                      //   isMediaAttached = false;
                                                                      //   setState(
                                                                      //           () {});
                                                                      // }

                                                                      controller
                                                                          .modelList2[ind]
                                                                          .mediaData2
                                                                          .clear();
                                                                      controller.modelList2[ind].pickedVideos
                                                                          .clear();
                                                                      _pickedVideosMemeType.clear();
                                                                      _pickedVideosName.clear();
                                                                      // controller.videoThumbnail = null;
                                                                      controller.modelList2[ind].videoThumbnail = null;

                                                                      print(controller
                                                                          .modelList2[ind]
                                                                          .mediaData2
                                                                          .length);

                                                                      // controller
                                                                      //     .modelList2[0]
                                                                      //     .mediaData2
                                                                      //     .forEach((element) {
                                                                      //   print(
                                                                      //       "Data");
                                                                      //   print(
                                                                      //       element.url);
                                                                      //   print(
                                                                      //       element.size);
                                                                      //   print(
                                                                      //       element.name);
                                                                      //   print(
                                                                      //       element.thumbnailUrl);
                                                                      // });

                                                                      isMediaAttached =
                                                                          false;
                                                                      if (controller
                                                                          .modelList2[ind]
                                                                          .bodyText
                                                                          .isEmpty) {
                                                                        widget
                                                                            .controller
                                                                            .postText = false;
                                                                        widget
                                                                            .controller
                                                                            .update();
                                                                      }
                                                                      videoWidgetKey =
                                                                          0;
                                                                      setState(
                                                                          () {});
                                                                      // videoThumbnail = '';
                                                                      // widget.controller.mediaData.clear();
                                                                      widget
                                                                          .controller
                                                                          .update();
                                                                    },
                                                                  ),
                                                                ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                )
                                              // ///threadaudio
                                              //     : controller.modelList2[ind].mediaData2.length > 0 && controller.modelList2[ind].mediaData2!= null
                                              //     ? audioUrl.isEmpty
                                              //     ? Container(
                                              //     width: 100,
                                              //     height: 100,
                                              //     child: Column(
                                              //       children: [
                                              //         CircularProgressIndicator(),
                                              //         SizedBox(height: 6),
                                              //         Text(
                                              //           'Uploading...',
                                              //           style: TextStyle(
                                              //               color: Color(
                                              //                   0xFFedab30),
                                              //               fontWeight:
                                              //               FontWeight
                                              //                   .w700),
                                              //         ),
                                              //       ],
                                              //     ))
                                              //     : Stack(
                                              //   children: [
                                              //     Container(
                                              //       child:
                                              //       ChewieAudioPlayer(
                                              //         audioUrl: audioUrl,
                                              //       ),
                                              //     ),
                                              //     Positioned(
                                              //       right: 6,
                                              //       top: 10,
                                              //       child: CircleAvatar(
                                              //         radius: 14,
                                              //         backgroundColor:
                                              //         Colors.grey,
                                              //         child: IconButton(
                                              //           padding:
                                              //           EdgeInsets.zero,
                                              //           icon: Icon(
                                              //             Icons
                                              //                 .close_rounded,
                                              //             size: 16,
                                              //             color:
                                              //             Colors.white,
                                              //           ),
                                              //           onPressed: () {
                                              //             widget.controller
                                              //                 .mediaData
                                              //                 .clear();
                                              //             if (controller.modelList2[ind].mediaData2.length == 1) {
                                              //               isMediaAttached = false;
                                              //
                                              //               setState(() {});
                                              //             }
                                              //             print(controller.modelList2[ind].mediaData2.length);
                                              //             controller.modelList2[ind].mediaData2.remove(
                                              //                 controller.modelList2[ind].mediaData2[0]);
                                              //             audioUrl = '';
                                              //             setState(() {});
                                              //           },
                                              //         ),
                                              //       ),
                                              //     ),
                                              //   ],
                                              // )
                                              ///threadpdf
                                              : controller.modelList2[ind]
                                                          .mediaData2.length >
                                                      0
                                                  ? controller
                                                              .modelList2[ind]
                                                              .mediaData2[0]
                                                              .name
                                                              .isNotEmpty &&
                                                          controller
                                                              .modelList2[ind]
                                                              .mediaData2[0]
                                                              .name
                                                              .contains('.pdf')
                                                      ?
                                                      /*pdfWidgetKey ==1?*/
                                                      controller.modelList2[ind].mediaData2.length == 0
                                                          ? const SizedBox(
                                                              width: 100,
                                                              height: 100,
                                                              child: CircularProgressIndicator(
                                                                color: MyColors
                                                                    .BlueColor,
                                                              ))
                                                          : Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: SizedBox(
                                                                height: 100,
                                                                width: 320,
                                                                child: ListView
                                                                    .separated(
                                                                        scrollDirection:
                                                                            Axis
                                                                                .horizontal,
                                                                        itemBuilder:
                                                                            (context,
                                                                                index) {
                                                                          return SizedBox(
                                                                            height:
                                                                                100,
                                                                            width:
                                                                                320,
                                                                            child:
                                                                                Stack(
                                                                              children: [
                                                                                SizedBox(
                                                                                  height: 250,
                                                                                  width: 320,
                                                                                  child: ListTile(
                                                                                    leading: Image.asset('assets/images/document.png'),
                                                                                    title: Text(controller.modelList2[ind].mediaData2[0].name),
                                                                                    trailing: CircleAvatar(
                                                                                      radius: 14,
                                                                                      backgroundColor: Colors.grey,
                                                                                      child: IconButton(
                                                                                        padding: EdgeInsets.zero,
                                                                                        icon: const Icon(
                                                                                          Icons.close_rounded,
                                                                                          size: 16,
                                                                                          color: Colors.white,
                                                                                        ),
                                                                                        onPressed: () {
                                                                                          widget.controller.postText = false;
                                                                                          widget.controller.update();
                                                                                          controller.modelList2[ind].mediaData2.clear();
                                                                                          isMediaAttached = false;
                                                                                          pdfWidgetKey = 0;
                                                                                          setState(() {});
                                                                                          // print(controller.modelList2[ind].mediaData2.length);
                                                                                          // pdfName = '';
                                                                                          // print(" hello pdf");
                                                                                          widget.controller.update();
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        },
                                                                        separatorBuilder: (_,
                                                                            __) {
                                                                          return const SizedBox(
                                                                              width: 4);
                                                                        },
                                                                        itemCount: controller
                                                                            .modelList2[ind]
                                                                            .mediaData2
                                                                            .length),
                                                              ),
                                                            )
                                                      : Container()
                                                  : Container(),

                                      ///thread tag people and add description
                                      controller.modelList2[ind].mediaData2
                                                      .length >
                                                  0 &&
                                              // && controller.modelList2[ind].mediaData2[0].name=="media"
                                              !controller.modelList2[ind]
                                                  .mediaData2[0].name
                                                  .contains('.pdf') &&
                                              (controller
                                                          .modelList2[ind]
                                                          .mediaData2[0]
                                                          .thumbnailUrl ==
                                                      null ||
                                                  controller
                                                      .modelList2[ind]
                                                      .mediaData2[0]
                                                      .thumbnailUrl
                                                      .isEmpty)
                                          /*  imageWidgetKey ==1*/ ? GetBuilder<
                                                  NewsfeedController>(
                                              builder: (logic) {
                                              return Row(
                                                children: [
                                                  InkWell(
                                                      onTap: () {
                                                        controller
                                                                .currentIndexText =
                                                            ind;
                                                        controller.update();
                                                        controller.tagList
                                                            .clear();
                                                        controller
                                                            .showCustomDialog(
                                                          context,
                                                          height,
                                                          width,
                                                          () {
                                                            setState(() {
                                                              controller
                                                                      .tagList =
                                                                  controller
                                                                      .tagList;
                                                            });
                                                          },
                                                          ind,
                                                        );
                                                      },
                                                      child: Row(
                                                        children: [
                                                          Icon(
                                                            Icons.person,
                                                            size: 20,
                                                            color: controller
                                                                .displayColor,
                                                          ),
                                                          // Text(controller.tagList.isNotEmpty? "${controller.tagList.length >1?controller.tagList[0].firstname + " and ${controller.tagList.length-1} Others":"${controller.tagList[0].firstname}" } " :"Tag People",style:TextStyle(color: Colors.blue,fontSize: 12)),
                                                          Text(
                                                              controller
                                                                      .modelList2[
                                                                          ind]
                                                                      .mediaData2[
                                                                          0]
                                                                      .mentionUserList
                                                                      .isNotEmpty
                                                                  ? "${controller.modelList2[ind].mediaData2[0].mentionUserList.length > 1 ? controller.modelList2[ind].mediaData2[0].mentionUserList[0].firstname + " and ${controller.modelList2[ind].mediaData2[0].mentionUserList.length - 1} Others" : "${controller.modelList2[ind].mediaData2[0].mentionUserList[0].firstname}"} "
                                                                  : "Tag People",
                                                              style: TextStyle(
                                                                  color: controller
                                                                      .displayColor,
                                                                  fontSize:
                                                                      14)),
                                                        ],
                                                      )),
                                                  const SizedBox(
                                                    width: 20,
                                                  ),
                                                  controller.modelList2[ind]
                                                                  .descriptionCounter !=
                                                              null &&
                                                          controller
                                                                  .modelList2[
                                                                      ind]
                                                                  .mediaData2
                                                                  .length ==
                                                              1 &&
                                                          controller
                                                              .modelList2[ind]
                                                              .mediaData2[0]
                                                              .description
                                                              .isNotEmpty
                                                      ? InkWell(
                                                          onTap: () {
                                                            if (kIsWeb) {
                                                              showDialog(
                                                                  context:
                                                                      context,
                                                                  builder:
                                                                      (BuildContext
                                                                          con) {
                                                                    return Shortcuts(
                                                                      shortcuts: {
                                                                        LogicalKeySet(LogicalKeyboardKey.escape):
                                                                            EscIntent()
                                                                      },
                                                                      child: AlertDialog(
                                                                          backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                          insetPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                          contentPadding: EdgeInsets.zero,
                                                                          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                          content: SingleChildScrollView(
                                                                            child:
                                                                                PostImageDescription(
                                                                              ind: ind,
                                                                            ),
                                                                          )

                                                                          //     Deactivation(
                                                                          //   context2: context,
                                                                          // ),
                                                                          ),
                                                                    );
                                                                  });
                                                            } else {
                                                              Navigator.push(
                                                                context,
                                                                MaterialPageRoute(
                                                                    builder:
                                                                        (context) =>
                                                                            PostImageDescription(
                                                                              ind: ind,
                                                                            )),
                                                              );
                                                            }
                                                          },
                                                          child: Row(
                                                            children: [
                                                              Icon(
                                                                Icons.note_add,
                                                                size: 20,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                              const SizedBox(
                                                                width: 2,
                                                              ),
                                                              SizedBox(
                                                                width: 100,
                                                                child: Text(
                                                                  controller
                                                                      .modelList2[
                                                                          ind]
                                                                      .mediaData2[
                                                                          0]
                                                                      .description,
                                                                  style:
                                                                      TextStyle(
                                                                    color: controller
                                                                        .displayColor,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                ),
                                                              ),
                                                            ],
                                                          ))
                                                      : controller
                                                                      .modelList2[
                                                                          ind]
                                                                      .descriptionCounter !=
                                                                  null &&
                                                              controller
                                                                      .modelList2[
                                                                          ind]
                                                                      .mediaData2
                                                                      .length >
                                                                  1 &&
                                                              widget
                                                                      .controller
                                                                      .modelList2[
                                                                          ind]
                                                                      .descriptionCounter >=
                                                                  1
                                                          ? InkWell(
                                                              onTap: () {
                                                                if (kIsWeb) {
                                                                  showDialog(
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (BuildContext
                                                                              con) {
                                                                        return Shortcuts(
                                                                          shortcuts: {
                                                                            LogicalKeySet(LogicalKeyboardKey.escape):
                                                                                EscIntent()
                                                                          },
                                                                          child: AlertDialog(
                                                                              backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                              insetPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                              contentPadding: EdgeInsets.zero,
                                                                              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                              content: SingleChildScrollView(
                                                                                child: PostImageDescription(
                                                                                  ind: ind,
                                                                                ),
                                                                              )

                                                                              //     Deactivation(
                                                                              //   context2: context,
                                                                              // ),
                                                                              ),
                                                                        );
                                                                      });
                                                                } else {
                                                                  Navigator
                                                                      .push(
                                                                    context,
                                                                    MaterialPageRoute(
                                                                        builder: (context) =>
                                                                            PostImageDescription(
                                                                              ind: ind,
                                                                            )),
                                                                  );
                                                                }
                                                              },
                                                              child: Row(
                                                                children: [
                                                                  Icon(
                                                                    Icons
                                                                        .note_add,
                                                                    size: 20,
                                                                    color: controller
                                                                        .displayColor,
                                                                  ),
                                                                  const SizedBox(
                                                                    width: 2,
                                                                  ),
                                                                  Text(
                                                                      "${widget.controller.modelList2[ind].descriptionCounter} ${Strings.ImageDescription}",
                                                                      style: TextStyle(
                                                                          color: controller
                                                                              .displayColor,
                                                                          fontSize: kIsWeb?14:11)),
                                                                ],
                                                              ))
                                                          : InkWell(
                                                              onTap: () {
                                                                print(
                                                                    "indexa dex $ind");
                                                                if (kIsWeb) {
                                                                  showDialog(
                                                                      context:
                                                                          context,
                                                                      builder:
                                                                          (BuildContext
                                                                              con) {
                                                                        return Shortcuts(
                                                                          shortcuts: {
                                                                            LogicalKeySet(LogicalKeyboardKey.escape):
                                                                                EscIntent()
                                                                          },
                                                                          child: AlertDialog(
                                                                              backgroundColor: Theme.of(context).brightness == Brightness.dark ? MyColors.liteDark : Colors.white,
                                                                              insetPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                                                                              contentPadding: EdgeInsets.zero,
                                                                              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                                                              content: SingleChildScrollView(
                                                                                child: PostImageDescription(
                                                                                  ind: ind,
                                                                                  addDescriptionCheck: 1,
                                                                                ),
                                                                              )

                                                                              //     Deactivation(
                                                                              //   context2: context,
                                                                              // ),
                                                                              ),
                                                                        );
                                                                      });
                                                                } else {
                                                                  Navigator
                                                                      .push(
                                                                    context,
                                                                    MaterialPageRoute(
                                                                        builder: (context) =>
                                                                            PostImageDescription(
                                                                              ind: ind,
                                                                              addDescriptionCheck: 1,
                                                                            )),
                                                                  );
                                                                }
                                                              },
                                                              child: Row(
                                                                children: [
                                                                  Icon(
                                                                    Icons
                                                                        .note_add,
                                                                    size: 20,
                                                                    color: controller
                                                                        .displayColor,
                                                                  ),
                                                                  const SizedBox(
                                                                    width: 2,
                                                                  ),
                                                                  Text(
                                                                     Strings.addDescription,
                                                                      style: TextStyle(
                                                                          color: controller
                                                                              .displayColor,
                                                                          fontSize:
                                                                              14)),
                                                                ],
                                                              )),
                                                ],
                                              );
                                            })
                                          : const SizedBox(),

                                      controller.modelList2[ind].location != ""
                                          ? Row(
                                              children: [
                                                const Icon(
                                                    Icons.location_on_outlined),
                                                Text(controller
                                                    .modelList2[ind].location),
                                                const SizedBox(
                                                  width: 15,
                                                ),
                                                InkWell(
                                                  onTap: () {
                                                    controller.modelList2[ind].location = "";
                                                    // SingleTone.instance.selectedLocation = null;\
                                                    if (controller.modelList2[controller.currentIndexText].bodyText.isEmpty) {
                                                      widget.controller.postText = false;
                                                      widget.controller.update();
                                                    }
                                                    setState(() {});
                                                  },
                                                  child: const Icon(
                                                    Icons.clear,
                                                  ),
                                                )
                                              ],
                                            )
                                          : const SizedBox()
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        SizedBox(
                          height: !isEmojiVisible ? 150 : 300,
                          child: Column(
                            children: [
                              const SizedBox(),
                              widget.isPostScheduled
                                  ? const SizedBox()
                                  : isMediaUploading
                                      ? const SizedBox()
                                      : const Divider(),
                              widget.isPostScheduled
                                  ? const SizedBox()
                                  : isMediaUploading
                                      ? const SizedBox()
                                      : ListTile(
                                          onTap: () {
                                            Get.bottomSheet(
                                              Container(
                                                padding: const EdgeInsets.symmetric(
                                                    horizontal: 16,
                                                    vertical: 8),
                                                color: Theme.of(context)
                                                    .scaffoldBackgroundColor,
                                                child: Column(
                                                  children: [
                                                    const SizedBox(height: 2),
                                                    Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Text(
                                                        Strings.whoCanReply,
                                                        // style: Theme.of(context).textTheme.headline6
                                                        //   .copyWith(fontWeight: FontWeight.bold),

                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          // fontSize: kIsWeb ? 14 : 12
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(height: 6),
                                                    Text(
                                                      Strings.pickWhoCanReplyMsg,
                                                      // style: Theme.of(context).textTheme.bodyText1.copyWith(
                                                      //     color: Colors.grey[500]),

                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline4
                                                          .copyWith(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12),
                                                    ),
                                                    const SizedBox(height: 8),
                                                    ListTile(
                                                      onTap: () {
                                                        isEveryone = true;
                                                        isFollowers = false;
                                                        isMentionedPeople =
                                                            false;
                                                        widget
                                                            .controller
                                                            .modelList2[widget
                                                                .controller
                                                                .currentIndexText]
                                                            .selectedType = "public";
                                                        Navigator.of(context)
                                                            .pop();
                                                        setState(() {});
                                                      },
                                                      contentPadding:
                                                          EdgeInsets.zero,
                                                      leading:  CircleAvatar(
                                                        backgroundColor:widget.controller.displayColor,

                                                        child: const Icon(
                                                          Icons
                                                              .public_outlined,
                                                          color:
                                                          Colors.white,
                                                          size:
                                                          20,
                                                        ),
                                                      ),
                                                      title: Text(
                                                        Strings.everyOne,
                                                        //  style: TextStyle(
                                                        //    fontSize: 18),

                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          //fontSize: kIsWeb ? 14 : 12
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(height: 8),
                                                    ListTile(
                                                      onTap: () {
                                                        isEveryone = false;
                                                        isFollowers = true;
                                                        isMentionedPeople =
                                                            false;
                                                        widget
                                                                .controller
                                                                .modelList2[widget
                                                                    .controller
                                                                    .currentIndexText]
                                                                .selectedType =
                                                            "follow_followers";
                                                        Navigator.of(context)
                                                            .pop();
                                                        setState(() {});
                                                      },
                                                      contentPadding:
                                                          EdgeInsets.zero,
                                                      leading:  CircleAvatar(
                                                        backgroundColor:widget.controller.displayColor,

                                                        child: const Icon(
                                                          Icons
                                                              .person_add_alt_outlined,
                                                          color: Colors.white,
                                                          size: 20,
                                                        ),
                                                      ),
                                                      title: Text(
                                                        Strings.peopleYouFollow,
                                                        //  style: TextStyle(
                                                        //    fontSize: 18),

                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          //fontSize: kIsWeb ? 14 : 12
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                    const SizedBox(height: 8),
                                                    ListTile(
                                                      onTap: () {
                                                        isEveryone = false;
                                                        isFollowers = false;
                                                        isMentionedPeople =
                                                            true;
                                                        widget
                                                                .controller
                                                                .modelList2[widget
                                                                    .controller
                                                                    .currentIndexText]
                                                                .selectedType =
                                                            "mention_users";

                                                        print(
                                                            " widget.controller.modelList2[widget.controller.currentIndexText].selectedType ${widget.controller.modelList2[widget.controller.currentIndexText].selectedType}");

                                                        Navigator.of(context)
                                                            .pop();
                                                        setState(() {});
                                                      },
                                                      contentPadding:
                                                          EdgeInsets.zero,
                                                      leading: CircleAvatar(
                                                        backgroundColor:
                                                        widget.controller.displayColor,

                                                        child: const Icon(
                                                          Icons
                                                              .alternate_email_outlined,
                                                          color:
                                                          Colors.white,
                                                          size:
                                                          20,
                                                        ),
                                                      ),
                                                      title: Text(
                                                        Strings.onlyPeopleYouMention,
                                                        // style: TextStyle(
                                                        //    fontSize: 18),

                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          //fontSize: kIsWeb ? 14 : 12
                                                          fontSize: 16,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            );
                                          },
                                          minLeadingWidth: 0,
                                          leading:
                                          Icon(
                                            isEveryone ? Icons.public_outlined
                                                : isFollowers ? Icons.person_add_alt_outlined :
                                            Icons.alternate_email_outlined,
                                            color:widget.controller.displayColor
                                            ,
                                            size: 22,
                                          )/*FaIcon(
                                            isEveryone
                                                ? FontAwesomeIcons
                                                : isFollowers
                                                    ? FontAwesomeIcons
                                                        .userFriends
                                                    : FontAwesomeIcons.user,
                                            size: 22,
                                            color: controller.displayColor,
                                          )*/,
                                          horizontalTitleGap: 4,
                                          title: Text(
                                            isEveryone
                                                ? Strings.everyoneCanReply
                                                : isFollowers
                                                    ? Strings.peopleYouFollow
                                                    : Strings.onlyPeopleYouMention,
                                            style:  TextStyle(
                                              fontSize: 15,
                                              height: 1.3,
                                              color:
                                              widget.controller.displayColor,
                                                //  controller.displayColor,
                                            ),
                                          ),
                                        ),
                              isMediaUploading ? const SizedBox() : const Divider(),
                              isMediaUploading
                                  ? const SizedBox()
                                  : Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceAround,
                                      children: [
                                        /// imagesicon
                                        isEdit == true && editImageCheck == true
                                            ? /*InkWell(
                                                onTap: editImageCheck == false
                                                    ? () {}
                                                    : callGetImage,
                                                child: Container(
                                                    width: 25,
                                                    height: 25,
                                                    child: SvgPicture.asset(
                                                      'assets/post_icons/image.svg',
                                                      height: 150,
                                                      color: editImageCheck ==
                                                              false
                                                          ? Colors.grey[400]
                                                          : controller
                                                              .displayColor,
                                                    )),
                                              )*/
                                        CreatePostIcons(AppImages.uploadImage, editImageCheck == false
                                            ? () {}
                                            : callGetImage)
                                            : CreatePostIcons(AppImages.uploadImage, widget.controller.modelList2[widget.controller.currentIndexText].mediaData2.length >
                                            0 &&
                                            isMediaAttached == true ||
                                            showPolls[controller.currentIndexText] == true
                                            ? () {}
                                            :(){
                                          showModalBottomSheet<void>(
                                            backgroundColor: Colors.grey.shade200,
                                            context: context,
                                            builder: (BuildContext context) {
                                              return Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  ListTile(
                                                      leading: const Icon(Icons.camera_alt),
                                                      title:  Text(Strings.takeAPhoto),
                                                      onTap: () async {
                                                        /*Get.back();
                                                                takeAPhoto();
                                                                return;*/
                                                        Get.back();
                                                        widget.controller.postText = true;

                                                        widget.controller.update();
                                                        imageWidgetKey = 1;
                                                        videoWidgetKey = 0;
                                                        pdfWidgetKey = 0;
                                                        controller.modelList2[controller.currentIndexText].listFilesMob = [];

                                                        var image = await UtilsMethods.getImageFromCamera();

                                                        if (image != null) {
                                                          File compressedImage = await FileSupport()
                                                              .compressImage(File(image.path), quality: 50);

                                                          var size = await FileSupport().getFileSize(file: compressedImage);

                                                          String filePath = compressedImage.path;
                                                          String fileName = filePath.split('/').last;

                                                          String splitSize = size.substring(0, 2).replaceAll(".", "").trim();
                                                          int fileSize = int.parse(splitSize);

                                                          PlatformFile convertedFile = await PlatformFile(
                                                            name: fileName,
                                                            path: filePath,
                                                            size: fileSize,
                                                          );
                                                          List<PlatformFile> compressedFiles = [];
                                                          compressedFiles.add(convertedFile);
                                                          // List<PlatformFile> listFiles = [];
                                                          controller.modelList2[controller.currentIndexText].listFilesMob.addAll(compressedFiles);
                                                          compressedFiles.clear();

                                                          // List<_dio.MultipartFile> files = [];
                                                          // files = listFiles
                                                          //     .map((path) => _dio.MultipartFile.fromFileSync(
                                                          //           path.path,
                                                          //           filename: path.name,
                                                          //         ))
                                                          //     .toList();
                                                          // if (kDebugMode) {
                                                          //   print(files.length);
                                                          // }
                                                          // Map<String, dynamic> userData = {};
                                                          // if (files.isNotEmpty) {
                                                          //   userData.addAll({'files[]': files});
                                                          // }
                                                          //
                                                          // isMediaUploading = true;
                                                          // await controller.multiImageSeleted(userData, 1);
                                                          controller.modelList2[controller.currentIndexText].imagePickCount =
                                                              controller.modelList2[controller.currentIndexText]
                                                                  .imagePickCount +
                                                                  controller.modelList2[controller.currentIndexText].listFilesMob.length;

                                                          print("pick image ${imageThumbnailsList}");
                                                          visibility = true;
                                                          // isMediaUploading = false;
                                                          isMediaAttached = false;
                                                          setState(() {});

                                                          // Get.back();
                                                        } else {
                                                          Get.back();
                                                        }
                                                      }
                                                  ),
                                                  ListTile(
                                                      leading: const Icon(Icons.image),
                                                      title: Text(Strings.chooseFromGallery),
                                                      onTap: () async {
                                                        Get.back();
                                                        callGetImage();

                                                      }
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        })
                                        /*InkWell(
                                                onTap: widget.controller.modelList2[widget.controller.currentIndexText].mediaData2.length >
                                                                0 &&
                                                            isMediaAttached == true ||
                                                        showPolls[controller.currentIndexText] == true
                                                    ? () {}
                                                    :(){
                                                  showModalBottomSheet<void>(
                                                    backgroundColor: Colors.grey.shade200,
                                                    context: context,
                                                    builder: (BuildContext context) {
                                                      return Column(
                                                        mainAxisSize: MainAxisSize.min,
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [
                                                          ListTile(
                                                              leading: const Icon(Icons.camera_alt),
                                                              title:  Text(Strings.takeAPhoto),
                                                              onTap: () async {
                                                                *//*Get.back();
                                                                takeAPhoto();
                                                                return;*//*
                                                                      Get.back();
                                                                      widget.controller.postText = true;

                                                                      widget.controller.update();
                                                                      imageWidgetKey = 1;
                                                                      videoWidgetKey = 0;
                                                                      pdfWidgetKey = 0;
                                                                      listFiles = [];

                                                                      var image = await UtilsMethods.getImageFromCamera();

                                                                      if (image != null) {
                                                                        File compressedImage = await FileSupport()
                                                                            .compressImage(File(image.path), quality: 50);

                                                                        var size = await FileSupport().getFileSize(file: compressedImage);

                                                                        String filePath = compressedImage.path;
                                                                        String fileName = filePath.split('/').last;

                                                                        String splitSize = size.substring(0, 2).replaceAll(".", "").trim();
                                                                        int fileSize = int.parse(splitSize);

                                                                        PlatformFile convertedFile = await PlatformFile(
                                                                          name: fileName,
                                                                          path: filePath,
                                                                          size: fileSize,
                                                                        );
                                                                        List<PlatformFile> compressedFiles = [];
                                                                        compressedFiles.add(convertedFile);
                                                                        // List<PlatformFile> listFiles = [];
                                                                        listFiles.addAll(compressedFiles);
                                                                        compressedFiles.clear();

                                                                        // List<_dio.MultipartFile> files = [];
                                                                        // files = listFiles
                                                                        //     .map((path) => _dio.MultipartFile.fromFileSync(
                                                                        //           path.path,
                                                                        //           filename: path.name,
                                                                        //         ))
                                                                        //     .toList();
                                                                        // if (kDebugMode) {
                                                                        //   print(files.length);
                                                                        // }
                                                                        // Map<String, dynamic> userData = {};
                                                                        // if (files.isNotEmpty) {
                                                                        //   userData.addAll({'files[]': files});
                                                                        // }
                                                                        //
                                                                        // isMediaUploading = true;
                                                                        // await controller.multiImageSeleted(userData, 1);
                                                                        controller.modelList2[controller.currentIndexText].imagePickCount =
                                                                            controller.modelList2[controller.currentIndexText]
                                                                                    .imagePickCount +
                                                                                    listFiles.length;

                                                                        print("pick image ${imageThumbnailsList}");
                                                                        visibility = true;
                                                                        // isMediaUploading = false;
                                                                        isMediaAttached = false;
                                                                        setState(() {});

                                                                        // Get.back();
                                                                      } else {
                                                                        Get.back();
                                                                      }
                                                                    }
                                                          ),
                                                          ListTile(
                                                              leading: Icon(Icons.image),
                                                              title: Text(Strings.chooseFromGallery),
                                                              onTap: () async {
                                                                Get.back();
                                                                callGetImage();

                                                              }
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  );
                                                },
                                                child: Container(
                                                    width: 25,
                                                    height: 25,
                                                    child: SvgPicture.asset(
                                                      // _pickedPdfs.length > 0 ||
                                                      //     _pickedAudios.length > 0 ||
                                                      //     _pickedVideos.length > 0
                                                      //     ?
                                                      'assets/post_icons/image.svg',
                                                      height: 150,
                                                      color: *//*_pickedVideos.isNotEmpty || isMediaAttached || showPolls ?*//*
                                                          controller.modelList2[widget.controller.currentIndexText].mediaData2.length >
                                                                          0 &&
                                                                      isMediaAttached ==
                                                                          true ||
                                                                  showPolls[controller
                                                                          .currentIndexText] ==
                                                                      true
                                                              //  ||editImageCheck==false

                                                              ? Colors.grey[400]
                                                              : controller
                                                                  .displayColor,

                                                      //  : Color(0xFF47b867),
                                                      // : 'assets/post_icons/image_color.png',
                                                    )
                                                    // Image.asset(_pickedPdfs.length > 0 ||
                                                    //     _pickedAudios.length > 0 ||
                                                    //     _pickedVideos.length > 0
                                                    //     ? 'assets/post_icons/image.png'
                                                    //     : 'assets/post_icons/image_color.png'),
                                                    ),
                                              )*/,


                                        CreatePostIcons(AppImages.uploadVideo, controller.modelList2[widget.controller.currentIndexText].mediaData2.length > 0 ||
                                            showPolls[controller.currentIndexText]
                                            ? () {} : (){
                                          showModalBottomSheet<void>(
                                            backgroundColor: Colors.grey.shade200,
                                            context: context,
                                            builder: (BuildContext context) {
                                              return Column(
                                                mainAxisSize: MainAxisSize.min,
                                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                                children: [
                                                  ListTile(
                                                      leading: Icon(Icons.camera_alt),
                                                      title: Text(Strings.makeVideoWithPhoneCamera),
                                                      onTap: () async {
                                                        Get.back();
                                                        widget.controller.postText = true;

                                                        widget.controller.update();

                                                        videoWidgetKey = 1;
                                                        imageWidgetKey = 0;
                                                        pdfWidgetKey = 0;
                                                        setState(() {});
                                                        // File pickedMedia;
                                                        Map<String,dynamic> map = await dataController.getVideoFromCamera();
                                                        videoBytes = await map['bytes'];

                                                        // _pickedVideo = pickedMedia.path;
                                                        print(videoBytes.toString());

                                                        // _pickedImage.add(videoBytes);
                                                        // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
                                                        if (videoBytes != null) {
                                                          controller.modelList2[widget.controller.currentIndexText].pickedVideos.add(videoBytes);
                                                          _pickedVideosMemeType.add(map['memeType']);
                                                          _pickedVideosName.add(map['name']);
                                                          isMediaUploading = true;

                                                          // videoThumbnail = await controller.uploadMedia(_pickedVideos[0], 1);
                                                          // Get.back();
                                                          videoWidgetKey = 1;
                                                          setState(() {
                                                            widget.controller.postText = true;
                                                          });

                                                          // print("video check $videoThumbnail");

                                                          //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
                                                          // if (videoThumbnail != null) {
                                                          // print('IN CREATE POST ' + videoThumbnail);
                                                          setState(() {
                                                            visibility = true;
                                                            isMediaAttached = true;
                                                            isMediaUploading = false;
                                                          });
                                                          // } else {
                                                          //   print('IN ELSE BLOCK');
                                                          // }
                                                        }



                                                      }
                                                  ),
                                                  ListTile(
                                                      leading: Icon(Icons.image),
                                                      title: Text(Strings.chooseFromGallery),
                                                      onTap: () async {
                                                        Get.back();
                                                        callGetVideo();

                                                      }
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        }),
                                        /// videoicon
                                       /* InkWell(
                                          onTap:
                                              //isMediaUploading
                                              controller.modelList2[widget.controller.currentIndexText].mediaData2.length > 0 ||
                                                      showPolls[controller.currentIndexText]
                                                  ? () {}

                                                  *//*
                        : _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {}
                        : _picke*//*
                                                  : (){
                                                showModalBottomSheet<void>(
                                                  backgroundColor: Colors.grey.shade200,
                                                  context: context,
                                                  builder: (BuildContext context) {
                                                    return Column(
                                                      mainAxisSize: MainAxisSize.min,
                                                      crossAxisAlignment: CrossAxisAlignment.stretch,
                                                      children: [
                                                        ListTile(
                                                            leading: Icon(Icons.camera_alt),
                                                            title: Text(Strings.makeVideoWithPhoneCamera),
                                                            onTap: () async {
                                                              Get.back();
                                                              widget.controller.postText = true;

                                                              widget.controller.update();

                                                              videoWidgetKey = 1;
                                                              imageWidgetKey = 0;
                                                              pdfWidgetKey = 0;
                                                              setState(() {});
                                                              // File pickedMedia;
                                                              Map<String,dynamic> map = await dataController.getVideoFromCamera();
                                                              videoBytes = await map['bytes'];

                                                              // _pickedVideo = pickedMedia.path;
                                                              print(videoBytes.toString());

                                                              // _pickedImage.add(videoBytes);
                                                              // print(_pickedImage);xxxxxxxxxxxxxxxxxxxxxx
                                                              if (videoBytes != null) {
                                                                _pickedVideos.add(videoBytes);
                                                                _pickedVideosMemeType.add(map['memeType']);
                                                                _pickedVideosName.add(map['name']);
                                                                isMediaUploading = true;

                                                                // videoThumbnail = await controller.uploadMedia(_pickedVideos[0], 1);
                                                                // Get.back();
                                                                videoWidgetKey = 1;
                                                                setState(() {
                                                                  widget.controller.postText = true;
                                                                });

                                                                print("video check $videoThumbnail");

                                                                //   controller.modelList2[controller.currentIndexText].mediaData2.add(videoThumbnail);
                                                                // if (videoThumbnail != null) {
                                                                  print('IN CREATE POST ' + videoThumbnail);
                                                                  setState(() {
                                                                    visibility = true;
                                                                    isMediaAttached = true;
                                                                    isMediaUploading = false;
                                                                  });
                                                                // } else {
                                                                //   print('IN ELSE BLOCK');
                                                                // }
                                                              }



                                                            }
                                                        ),
                                                        ListTile(
                                                            leading: Icon(Icons.image),
                                                            title: Text(Strings.chooseFromGallery),
                                                            onTap: () async {
                                                              Get.back();
                                                              callGetVideo();

                                                            }
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                              }


                                          ,
                                          child: Container(
                                              width: 20,
                                              height: 20,
                                              child: SvgPicture.asset(
                                                // _pickedPdfs.length > 0 ||
                                                //     _pickedAudios.length > 0 ||
                                                //     _pickedVideos.length > 0
                                                //     ?
                                                'assets/post_icons/video.svg',
                                                color:
                                                    // isMediaUploading
                                                    controller
                                                                    .modelList2[widget
                                                                        .controller
                                                                        .currentIndexText]
                                                                    .mediaData2
                                                                    .length >
                                                                0 ||
                                                            showPolls[controller
                                                                .currentIndexText]
                                                        ? Colors.grey[
                                                            400] *//*: _pickedVideos.isNotEmpty || isMediaAttached || showPolls
                              ? Colors.grey[400]*//*
                                                        : controller
                                                            .displayColor,
                                                // : Color(0xFFef5994),
                                              )),
                                        ),*/

                                        /// audioicon
                                        // InkWell(
                                        //   onTap:
                                        //   //  isMediaUploading ? () {} : _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {} : _pickedPdfs.length > 0 || _pickedVideos.length > 0 || _pickedImage.length > 0
                                        //   controller.modelList2[widget.controller.currentIndexText].mediaData2.length>0 || showPolls[controller.currentIndexText]
                                        //       ? () {}
                                        //       : callGetAudio,
                                        //   child: Container(
                                        //       width: 20,
                                        //       height: 20,
                                        //       child: SvgPicture.asset(
                                        //         // _pickedPdfs.length > 0 ||
                                        //         //     _pickedAudios.length > 0 ||
                                        //         //     _pickedVideos.length > 0
                                        //         //     ?
                                        //         'assets/post_icons/mic.svg',
                                        //         color:
                                        //         controller.modelList2[widget.controller.currentIndexText].mediaData2.length>0 || showPolls[controller.currentIndexText]
                                        //             ? Colors.grey[400] :
                                        //         //   _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? Colors.grey[400] :
                                        //         Color(0xFFedc01c),
                                        //         // : 'assets/post_icons/image_color.png',
                                        //       )
                                        //     // Image.asset(_pickedPdfs.length > 0 ||
                                        //     //         _pickedVideos.length > 0 ||
                                        //     //         _pickedImage.length > 0
                                        //     //     ? 'assets/post_icons/mic.png'
                                        //     //     : 'assets/post_icons/mic_color.png'),
                                        //   ),
                                        // ),

                                        CreatePostIcons(AppImages.uploadFile, controller
                                            .modelList2[widget
                                            .controller
                                            .currentIndexText]
                                            .mediaData2
                                            .length >
                                            0 ||
                                            showPolls[controller
                                                .currentIndexText]
                                            ? () {} /*: _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {} : _pickedAudios.length > 0 || _pickedVideos.length > 0 || _pickedImage.length > 0 ? () {}*/
                                            : callGetFile,),
                                        ///pdficon
                                        /*InkWell(
                                          onTap: controller
                                                          .modelList2[widget
                                                              .controller
                                                              .currentIndexText]
                                                          .mediaData2
                                                          .length >
                                                      0 ||
                                                  showPolls[controller
                                                      .currentIndexText]
                                              ? () {} *//*: _pickedVideos.isNotEmpty || isMediaAttached || showPolls ? () {} : _pickedAudios.length > 0 || _pickedVideos.length > 0 || _pickedImage.length > 0 ? () {}*//*
                                              : callGetFile,
                                          child: Container(
                                              width: 20,
                                              height: 20,
                                              child: SvgPicture.asset(
                                                // _pickedPdfs.length > 0 ||
                                                //     _pickedAudios.length > 0 ||
                                                //     _pickedVideos.length > 0
                                                //     ?
                                                'assets/post_icons/attach.svg',
                                                color:
                                                    //  isMediaUploading
                                                    controller
                                                                    .modelList2[widget
                                                                        .controller
                                                                        .currentIndexText]
                                                                    .mediaData2
                                                                    .length >
                                                                0 ||
                                                            showPolls[controller
                                                                .currentIndexText]
                                                        ? Colors.grey[
                                                            400] *//*: _pickedVideos.isNotEmpty || isMediaAttached || showPolls
                              ? Colors.grey[400]*//*
                                                        : controller
                                                            .displayColor,
                                                // : Color(0xFF6e89c5),
                                                // : 'assets/post_icons/image_color.png',
                                              )
                                              // Image.asset(_pickedAudios.length > 0 ||
                                              //         _pickedVideos.length > 0 ||
                                              //         _pickedImage.length > 0
                                              //     ? 'assets/post_icons/attach.png'
                                              //     : 'assets/post_icons/attach_color.png'),
                                              ),
                                        ),*/

                                        ///poll icon
                                        ///
                                        CreatePostIcons(AppImages.uploadPoll, showPolls[controller
                                            .currentIndexText] ||
                                            widget.isPostScheduled
                                            ? () {}
                                            : () {
                                          showPolls[controller
                                              .currentIndexText] =
                                          true;
                                          controller
                                              .modelList2[controller
                                              .currentIndexText]
                                              .poolThread = true;
                                          setState(() {});
                                        }),
                                       /* InkWell(
                                          onTap:
                                              // isMediaUploading
                                              controller
                                                          .modelList2[widget
                                                              .controller
                                                              .currentIndexText]
                                                          .mediaData2
                                                          .length >
                                                      0
                                                  ? () {}
                                                  :
                                                  //_pickedVideos.isNotEmpty ||
                                                  //   isMediaAttached ||
                                                  showPolls[controller
                                                              .currentIndexText] ||
                                                          widget.isPostScheduled
                                                      ? () {}
                                                      : () {
                                                          showPolls[controller
                                                                  .currentIndexText] =
                                                              true;
                                                          controller
                                                              .modelList2[controller
                                                                  .currentIndexText]
                                                              .poolThread = true;
                                                          setState(() {});
                                                        },
                                          child: SvgPicture.asset(
                                            // _pickedPdfs.length > 0 ||
                                            //     _pickedAudios.length > 0 ||
                                            //     _pickedVideos.length > 0
                                            //     ?
                                            'assets/post_icons/polls.svg',
                                            // fit: BoxFit.fill,
                                            height: 20,
                                            width: 20,
                                            color:
                                                //  isMediaUploading
                                                controller
                                                            .modelList2[widget
                                                                .controller
                                                                .currentIndexText]
                                                            .mediaData2
                                                            .length >
                                                        0
                                                    ? Colors.grey[400]
                                                    :
                                                    // _pickedVideos.isNotEmpty ||
                                                    //  isMediaAttached ||
                                                    widget.isPostScheduled ||
                                                            showPolls[controller
                                                                .currentIndexText]
                                                        ? Colors.grey[400]
                                                        : controller
                                                            .displayColor,
                                            // : Colors.green,
                                          ),
                                        ),*/

                                        ///scheduleposticon
                                        CreatePostIcons(AppImages.uploadSchedulePost, controller
                                            .modelList2[widget
                                            .controller
                                            .currentIndexText]
                                            .mediaData2
                                            .length >
                                            0 ||
                                            isFollowers == true ||
                                            isMentionedPeople ==
                                                true ||
                                            threadCreated == true
                                        //  ||
                                        //   showPolls
                                            ? () {}
                                            : () async {
                                          isEditable  =false;
                                          showScheduledWerfs = false;
                                          selectedALL = false;
                                          setState(() {

                                          });


                                          bool val =
                                          await showModalBottomSheet(
                                            // isDismissible: false,

                                              shape: const RoundedRectangleBorder(
                                                  borderRadius: BorderRadius.only(
                                                      topLeft: Radius
                                                          .circular(
                                                          20),
                                                      topRight:
                                                      Radius.circular(
                                                          20))),
                                              context: context,
                                              isScrollControlled:
                                              true,
                                              constraints:
                                              const BoxConstraints(
                                                  maxHeight:
                                                  520),
                                              builder:
                                                  (context) {
                                                return StatefulBuilder(
                                                    builder:
                                                        (context,
                                                        setState) {
                                                      return Container(
                                                        padding: const EdgeInsets.symmetric(
                                                            horizontal:
                                                            16,
                                                            vertical:
                                                            16),
                                                        child: showScheduledWerfs
                                                            ?
                                                        // GetBuilder<
                                                        //         NewsfeedController>(
                                                        //         builder: (controller) {
                                                        //           return
                                                        Column(
                                                          children: [


                                                            ListTile(
                                                              leading: GestureDetector(
                                                                  onTap: () {
                                                                    showScheduledWerfs = false;
                                                                    // visibility==false;
                                                                    setState(() {});
                                                                  },
                                                                  child: Icon(Icons.arrow_back)),
                                                              title:widget.controller.scheduledPosts.isEmpty?Text(''): Text('Unsent Werfs'),
                                                              trailing: widget.controller.scheduledPosts.isEmpty?SizedBox():RoundedButton(
                                                                Strings.edit,
                                                                    () {
                                                                  isEditable = true;
                                                                  setState(() {});
                                                                },
                                                                horizontalPadding: 10.0,
                                                                verticalPadding: 4.0,
                                                                roundedButtonColor: controller.displayColor,
                                                              ),
                                                            ),
                                                            const SizedBox(height: 10),
                                                            const Divider(height: 1),
                                                            widget.controller.noScheduledPost
                                                                ? const CircularProgressIndicator(
                                                              color: MyColors.BlueColor,
                                                            )
                                                                : widget.controller.scheduledPosts.isEmpty || widget.controller.scheduledPosts.isEmpty==null
                                                                ? Center(
                                                              child: Text(Strings.youHaveNoScheduledWerfs),
                                                            )
                                                                : Expanded(
                                                              child: ListView.separated(
                                                                  shrinkWrap: true,
                                                                  itemBuilder: (context, index) {
                                                                    var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(widget.controller.scheduledPosts[index].postingTime, true);
                                                                    var postingTime = dateTime.toLocal();
                                                                    postingTime = DateFormat('yyyy-MM-dd HH:mm').parse(postingTime.toString());

                                                                    ///changes made in this section of code in edit schedule
                                                                    return GestureDetector(
                                                                      onTap: () {
                                                                        widget.isPostScheduled = true;
                                                                        monthValidatedSuccessfully = true;
                                                                        hourValidatedSuccessfully = true;
                                                                        postTextController.text = widget.controller.scheduledPosts[index].body;
                                                                        Navigator.of(context).pop();
                                                                        setState(() {});

                                                                        //
                                                                        // Get.back(result: [
                                                                        //   {"PostBody": widget.controller.scheduledPosts[index].body,
                                                                        //     "PostTiming": DateFormat.yMMMMd().add_jm().format(postingTime).toString(),
                                                                        //   }
                                                                        //]);
                                                                      },
                                                                      child: ListTile(
                                                                        leading: isEditable
                                                                            ? Checkbox(
                                                                            value: widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion,
                                                                            onChanged: (value) {

                                                                              widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion = !widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion;
                                                                              widget.controller.update();
                                                                              setState(() {});
                                                                              if (widget.postsForDeletions.contains(widget.controller.scheduledPosts[index].id)) {
                                                                                int ind = widget.postsForDeletions.indexWhere((element) => element == widget.controller.scheduledPosts[index].id);

                                                                                widget.postsForDeletions.removeAt(ind);
                                                                              } else {
                                                                                widget.postsForDeletions.add(widget.controller.scheduledPosts[index].id);
                                                                              }

                                                                            })
                                                                            : const SizedBox(),

                                                                        title: Text(
                                                                          '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                          style: Styles.baseTextTheme.headline2.copyWith(
                                                                            // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontSize: kIsWeb ? 14 : 12,
                                                                            fontWeight: FontWeight.w400,
                                                                          ),
                                                                        ),
                                                                        // Text('Will Post on ${DateFormat.yMMMMd().add_jm().format(postingTime)}'),

                                                                        subtitle: Text(widget.controller.scheduledPosts[index].body),
                                                                      ),
                                                                    );
                                                                  },

                                                                  ///changes made in this section of code
                                                                  separatorBuilder: (_, __) {
                                                                    return Divider(height: 1);
                                                                  },
                                                                  itemCount: widget.controller.scheduledPosts.length),
                                                            ),
                                                            isEditable
                                                                ? ListTile(
                                                              leading: selectedALL==true?
                                                              GestureDetector(
                                                                  onTap:(){

                                                                    widget.postsForDeletions = [];
                                                                    widget.controller.scheduledPosts.forEach((element) {
                                                                      element.isScheduledPostSelectedForDeletion = false;
                                                                    });

                                                                    selectedALL = false;
                                                                    print('List....... ' + widget.postsForDeletions.toString());

                                                                    setState(
                                                                            () {});
                                                                  },
                                                                  child: Text(Strings.deselectAll)):
                                                              GestureDetector(
                                                                  onTap:(){

                                                                    widget.controller.scheduledPosts.forEach((element) {
                                                                      element.isScheduledPostSelectedForDeletion = true;
                                                                    });


                                                                    widget.postsForDeletions = [];
                                                                    widget.controller.scheduledPosts.forEach((element) {
                                                                      widget.postsForDeletions.add(element.id);
                                                                    });








                                                                    selectedALL = true;


                                                                    setState(
                                                                            () {});

                                                                    print('List....... ' + widget.postsForDeletions.toString());

                                                                  },
                                                                  child: Text(Strings.selectAll)),
                                                              trailing: GestureDetector(
                                                                onTap: () {
                                                                  print('List ' + widget.postsForDeletions.toString());
                                                                  widget.controller.deleteScheduledPosts(widget.postsForDeletions, context);
                                                                  // widget
                                                                  //     .postsForDeletions
                                                                  //     .clear();
                                                                },
                                                                child: Text(Strings.delete),
                                                              ),
                                                            )
                                                                : const SizedBox(),
                                                          ],
                                                        )
                                                        //     ;
                                                        //   },
                                                        // )
                                                            : Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                          children: [
                                                            Row(
                                                              children: [
                                                                GestureDetector(
                                                                    onTap: () {
                                                                      Navigator.pop(context, false);
                                                                    },
                                                                    child: Icon(
                                                                      Icons.close,
                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                    )),
                                                                const SizedBox(width: 12),
                                                                Text(
                                                                  Strings.schedule,
                                                                  //  style: Theme.of(context).textTheme.headline4

                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                    fontWeight: FontWeight.bold,
                                                                  ),
                                                                ),
                                                                const Spacer(),
                                                                RoundedButton(
                                                                  Strings.confirm,

                                                                  // hourValidatedSuccessfully &&
                                                                  //         minutesValidatedSuccessfully &&
                                                                  //         monthValidatedSuccessfully &&
                                                                  //         dayValidatedSuccessfully
                                                                  //     ? null
                                                                  //     :
                                                                      () {
                                                                    if (monthValidatedSuccessfully) {
                                                                      widget.isPostScheduled = true;

                                                                      //  visibility=false;

                                                                      Navigator.pop(context, true);
                                                                    }
                                                                  },
                                                                  horizontalPadding: 20.0,
                                                                  verticalPadding: 0.0,
                                                                  roundedButtonColor: controller.displayColor,
                                                                ),
                                                              ],
                                                            ),
                                                            // ListTile(
                                                            //   horizontalTitleGap:
                                                            //   0.0,
                                                            //   leading: Icon(
                                                            //       Icons
                                                            //           .calendar_today),
                                                            //   title: Text(
                                                            //       'Will Post on ${DateFormat.yMMMMd().add_jm().format(DateTime.parse(selectedDateTime))}',
                                                            //
                                                            //   ),
                                                            // ),
                                                            const SizedBox(
                                                              height: 20,
                                                            ),

                                                            Row(
                                                              children: [
                                                                Icon(
                                                                  Icons.calendar_today,
                                                                  color: Color(0xFF586976),
                                                                ),
                                                                // SizedBox(width: 20,),
                                                                Padding(
                                                                  padding: const EdgeInsets.only(left: 8),
                                                                  child: Text(
                                                                    '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                    // 'Will Post on ${DateFormat("yyyy-MM-dd hh:mm").parse(selectedDateTime)}',
                                                                    style: Styles.baseTextTheme.headline2.copyWith(
                                                                      // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontSize: kIsWeb ? 14 : 10,
                                                                      fontWeight: FontWeight.w400,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            const SizedBox(
                                                              height: 10,
                                                            ),

                                                            Text(
                                                              Strings.date,
                                                              //  style: Theme.of(context).textTheme.headline6,

                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                fontSize: 14,
                                                                fontWeight: FontWeight.w500,
                                                              ),
                                                            ),
                                                            const SizedBox(height: 10),
                                                            /* Date DropDown Section */
                                                            Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              children: [
                                                                // Drop Down Button for Month
                                                                ButtonTheme(
                                                                  materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                  child: Expanded(
                                                                    flex: 1,
                                                                    child: DropdownButtonFormField<String>(
                                                                      icon: const Icon(Icons.keyboard_arrow_down),
                                                                      isExpanded: true,

                                                                      decoration: InputDecoration(
                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                        border: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: controller.displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText: Strings.month,
                                                                        labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      // value: 0.toString(),
                                                                      hint: Text(
                                                                        months[DateTime.now().month - 1],
                                                                        //,
                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),

                                                                      alignment: Alignment.bottomCenter,
                                                                      items: months.map((String value) {
                                                                        return DropdownMenuItem<String>(
                                                                          value: value,
                                                                          child: Text(
                                                                            value.toString(),
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList(),
                                                                      onChanged: (month) {
                                                                        /*        int selectedMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                month);
                                                            int currentMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                months[DateTime.now().month - 1]);
                                                            selectedMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            scheduleMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            print('SELECTED  $selectedMonthIndex' +
                                                                ' : ' +
                                                                'CURRENT $currentMonthIndex');*/

                                                                        selectedMonthValue = (months.indexWhere((element) => element == month) + 1).toString();

                                                                        selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                        if (compareSelectedDatetime(selectedDateTime)) {
                                                                          monthValidatedSuccessfully = true;
                                                                        } else {
                                                                          monthValidatedSuccessfully = false;
                                                                        }
                                                                        setState(() {});

                                                                        // setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                                const SizedBox(width: 12),
                                                                // Drop Down Button for Day
                                                                ButtonTheme(
                                                                  materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                  child: Expanded(
                                                                    flex: 1,
                                                                    child: DropdownButtonFormField<String>(
                                                                      icon: const Icon(Icons.keyboard_arrow_down),
                                                                      isExpanded: true,
                                                                      decoration: InputDecoration(
                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                        border: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: controller.displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText: Strings.day,
                                                                        labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      // value: 0.toString(),
                                                                      hint: Text(
                                                                        selectedDayValue,
                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment: Alignment.bottomCenter,
                                                                      items: List.generate(31, (index) => index + 1).map((int value) {
                                                                        return DropdownMenuItem<String>(
                                                                          value: value.toString(),
                                                                          child: Text(
                                                                            value.toString(),
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList(),
                                                                      onChanged: (day) {
                                                                        selectedDayValue = day;
                                                                        scheduleDayValue = day;
                                                                        int currentDay = DateTime.now().day;
                                                                        selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                        if (compareSelectedDatetime(selectedDateTime)) {
                                                                          monthValidatedSuccessfully = true;
                                                                        } else {
                                                                          monthValidatedSuccessfully = false;
                                                                        }
                                                                        setState(() {});
                                                                        // }
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),

                                                                const SizedBox(width: 12),

                                                                // Drop Down Button for Year
                                                                ButtonTheme(
                                                                  materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                  child: Expanded(
                                                                    flex: 1,
                                                                    child: DropdownButtonFormField<String>(
                                                                      icon: const Icon(Icons.keyboard_arrow_down),
                                                                      isExpanded: true,
                                                                      decoration: InputDecoration(
                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                                                        border: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: controller.displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText:Strings.year ,
                                                                        labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      // value: 0.toString(),
                                                                      hint: Text(
                                                                        DateTime.now().year.toString(),
                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment: Alignment.bottomCenter,
                                                                      items: years.map((int value) {
                                                                        return DropdownMenuItem<String>(
                                                                          value: value.toString(),
                                                                          child: Text(
                                                                            value.toString(),
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList(),
                                                                      onChanged: (year) {
                                                                        selectedYearValue = year;

                                                                        scheduleYearValue = year;

                                                                        selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                        if (compareSelectedDatetime(selectedDateTime)) {
                                                                          monthValidatedSuccessfully = true;
                                                                        } else {
                                                                          monthValidatedSuccessfully = false;
                                                                        }
                                                                        setState(() {});
                                                                        //

                                                                        print('Scheduled Year ' + scheduleYearValue.toString());
                                                                        // setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                            !monthValidatedSuccessfully
                                                                ? Text(
                                                              Strings.youCannotScheduleAWerfInThePast,
                                                              style: const TextStyle(color: Colors.red),
                                                            )
                                                                : const SizedBox(),
                                                            const SizedBox(height: 20),
                                                            /* Time DropDown Section */
                                                            Text(
                                                              Strings.time,
                                                              //  style: Theme.of(context).textTheme.headline6,

                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                fontSize: 14,
                                                                fontWeight: FontWeight.w500,
                                                              ),
                                                            ),
                                                            const SizedBox(height: 10),
                                                            Row(
                                                              children: [
                                                                /* DropDown Button For Hours */
                                                                ButtonTheme(
                                                                  materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                  child: Expanded(
                                                                    flex: 1,
                                                                    child: DropdownButtonFormField<String>(
                                                                      icon: const Icon(Icons.keyboard_arrow_down),
                                                                      isExpanded: true,
                                                                      decoration: InputDecoration(
                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                        border: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: controller.displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText: Strings.hours,
                                                                        labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      // value: 0.toString(),
                                                                      hint: Text(
                                                                        selectedHourValue,
                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment: Alignment.bottomCenter,
                                                                      items: List.generate(24, (index) => index).map((int value) {
                                                                        return DropdownMenuItem<String>(
                                                                          value: value.toString(),
                                                                          child: Text(
                                                                            value.toString(),
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList(),
                                                                      onChanged: (hour) {
                                                                        selectedHourValue = hour;
                                                                        scheduleHourValue = hour;

                                                                        selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                        if (compareSelectedDatetime(selectedDateTime)) {
                                                                          monthValidatedSuccessfully = true;
                                                                        } else {
                                                                          monthValidatedSuccessfully = false;
                                                                        }
                                                                        setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                                /* DropDown Button For Minutes */
                                                                const SizedBox(width: 12),
                                                                ButtonTheme(
                                                                  materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                  child: Expanded(
                                                                    flex: 1,
                                                                    child: DropdownButtonFormField<String>(
                                                                      icon: const Icon(Icons.keyboard_arrow_down),
                                                                      isExpanded: true,
                                                                      decoration: InputDecoration(
                                                                        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                        border: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder: OutlineInputBorder(
                                                                          borderRadius: BorderRadius.circular(10),
                                                                          borderSide: BorderSide(
                                                                            color: controller.displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText: Strings.minutes,
                                                                        labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),

                                                                      // value: 0.toString(),
                                                                      hint: Text(
                                                                        selectedMinutesValue,
                                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment: Alignment.bottomCenter,
                                                                      items: List.generate(60, (index) => index).map((int value) {
                                                                        return DropdownMenuItem<String>(
                                                                          value: value.toString(),
                                                                          child: Text(
                                                                            value.toString(),
                                                                            style: Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      }).toList(),
                                                                      onChanged: (minute) {
                                                                        selectedMinutesValue = minute;
                                                                        scheduleMinutesValue = minute;
                                                                        print("value$minute");
                                                                        selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                        if (compareSelectedDatetime(selectedDateTime)) {
                                                                          monthValidatedSuccessfully = true;
                                                                        } else {
                                                                          monthValidatedSuccessfully = false;
                                                                        }
                                                                        setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                                const SizedBox(width: 12),
                                                                const Expanded(flex: 1, child: SizedBox()),
                                                              ],
                                                            ),
                                                            /* if (!monthValidatedSuccessfully)
                                                    Text(
                                                      'You cannot schedule a Werf in the past',
                                                      style: TextStyle(
                                                        color:
                                                        Colors.red,
                                                        fontSize: 12,
                                                      ),
                                                    )
                                                  else
                                                    SizedBox(),*/
                                                            const SizedBox(height: 20),
                                                            Text(
                                                              Strings.timeZone,
                                                              //  style: Theme.of(context).textTheme.headline6,

                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                fontSize: 14,
                                                                fontWeight: FontWeight.w500,
                                                              ),
                                                            ),

                                                            const SizedBox(height: 10),
                                                            Text(
                                                              DateTime.now().timeZoneName,
                                                              // style: Theme.of(context).textTheme.headline4.copyWith(height: 1.2)

                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                //fontSize: kIsWeb ? 16 : 14,
                                                                fontWeight: FontWeight.bold,
                                                              ),
                                                            ),
                                                            const Divider(height: 1),
                                                            const SizedBox(height: 10),
                                                            GestureDetector(
                                                                onTap: () async {


                                                                  widget.controller.noScheduledPost = true;
                                                                  showScheduledWerfs = true;
                                                                  setState(() {});

                                                                  widget.controller.scheduledPosts = await widget.controller.getScheduledPosts();
                                                                  widget.controller.noScheduledPost = false;

                                                                  setState(() {});
                                                                },
                                                                child: Text(
                                                                  Strings.scheduledWerfs,
                                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                    fontSize: kIsWeb ? 16 : 14,
                                                                    fontWeight: FontWeight.w500,
                                                                  ),
                                                                ))
                                                          ],
                                                        ),
                                                      );
                                                    });
                                              });

                                          if (val) {
                                            print(
                                                "getValueFromSchedule" +
                                                    val.toString());
                                            setState(() {});
                                          }
                                        }),
                                       /* InkWell(
                                          onTap:
                                              //  isMediaUploading
                                              controller
                                                              .modelList2[widget
                                                                  .controller
                                                                  .currentIndexText]
                                                              .mediaData2
                                                              .length >
                                                          0 ||
                                                      isFollowers == true ||
                                                      isMentionedPeople ==
                                                          true ||
                                                      threadCreated == true
                                                  //  ||
                                                  //   showPolls
                                                  ? () {}
                                                  : () async {
                                                isEditable  =false;
                                                showScheduledWerfs = false;
                                                selectedALL = false;
                                                setState(() {

                                                });


                                                      bool val =
                                                          await showModalBottomSheet(
                                                              // isDismissible: false,

                                                              shape: RoundedRectangleBorder(
                                                                  borderRadius: BorderRadius.only(
                                                                      topLeft: Radius
                                                                          .circular(
                                                                              20),
                                                                      topRight:
                                                                          Radius.circular(
                                                                              20))),
                                                              context: context,
                                                              isScrollControlled:
                                                                  true,
                                                              constraints:
                                                                  BoxConstraints(
                                                                      maxHeight:
                                                                          520),
                                                              builder:
                                                                  (context) {
                                                                return StatefulBuilder(
                                                                    builder:
                                                                        (context,
                                                                            setState) {
                                                                  return Container(
                                                                    padding: EdgeInsets.symmetric(
                                                                        horizontal:
                                                                            16,
                                                                        vertical:
                                                                            16),
                                                                    child: showScheduledWerfs
                                                                        ?
                                                                        // GetBuilder<
                                                                        //         NewsfeedController>(
                                                                        //         builder: (controller) {
                                                                        //           return
                                                                        Column(
                                                                            children: [


                                                                              ListTile(
                                                                                leading: GestureDetector(
                                                                                    onTap: () {
                                                                                      showScheduledWerfs = false;
                                                                                      // visibility==false;
                                                                                      setState(() {});
                                                                                    },
                                                                                    child: Icon(Icons.arrow_back)),
                                                                                title:widget.controller.scheduledPosts.isEmpty?Text(''): Text('Unsent Werfs'),
                                                                                trailing: widget.controller.scheduledPosts.isEmpty?SizedBox():RoundedButton(
                                                                                  Strings.edit,
                                                                                  () {
                                                                                    isEditable = true;
                                                                                    setState(() {});
                                                                                  },
                                                                                  horizontalPadding: 10.0,
                                                                                  verticalPadding: 4.0,
                                                                                  roundedButtonColor: controller.displayColor,
                                                                                ),
                                                                              ),
                                                                              SizedBox(height: 10),
                                                                              Divider(height: 1),
                                                                              widget.controller.noScheduledPost
                                                                                  ? CircularProgressIndicator(
                                                                                      color: MyColors.BlueColor,
                                                                                    )
                                                                                  : widget.controller.scheduledPosts.isEmpty || widget.controller.scheduledPosts.isEmpty==null
                                                                                      ? Center(
                                                                                          child: Text(Strings.youHaveNoScheduledWerfs),
                                                                                        )
                                                                                      : Expanded(
                                                                                          child: ListView.separated(
                                                                                              shrinkWrap: true,
                                                                                              itemBuilder: (context, index) {
                                                                                                var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(widget.controller.scheduledPosts[index].postingTime, true);
                                                                                                var postingTime = dateTime.toLocal();
                                                                                                postingTime = DateFormat('yyyy-MM-dd HH:mm').parse(postingTime.toString());

                                                                                                ///changes made in this section of code in edit schedule
                                                                                                return GestureDetector(
                                                                                                  onTap: () {
                                                                                                    widget.isPostScheduled = true;
                                                                                                    monthValidatedSuccessfully = true;
                                                                                                    hourValidatedSuccessfully = true;
                                                                                                    postTextController.text = widget.controller.scheduledPosts[index].body;
                                                                                                    Navigator.of(context).pop();
                                                                                                    setState(() {});

                                                                                                    //
                                                                                                    // Get.back(result: [
                                                                                                    //   {"PostBody": widget.controller.scheduledPosts[index].body,
                                                                                                    //     "PostTiming": DateFormat.yMMMMd().add_jm().format(postingTime).toString(),
                                                                                                    //   }
                                                                                                    //]);
                                                                                                  },
                                                                                                  child: ListTile(
                                                                                                    leading: isEditable
                                                                                                        ? Checkbox(
                                                                                                            value: widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion,
                                                                                                            onChanged: (value) {

                                                                                                              widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion = !widget.controller.scheduledPosts[index].isScheduledPostSelectedForDeletion;
                                                                                                              widget.controller.update();
                                                                                                              setState(() {});
                                                                                                              if (widget.postsForDeletions.contains(widget.controller.scheduledPosts[index].id)) {
                                                                                                                int ind = widget.postsForDeletions.indexWhere((element) => element == widget.controller.scheduledPosts[index].id);

                                                                                                                widget.postsForDeletions.removeAt(ind);
                                                                                                              } else {
                                                                                                                widget.postsForDeletions.add(widget.controller.scheduledPosts[index].id);
                                                                                                              }
                                                                                                             
                                                                                                            })
                                                                                                        : SizedBox(),

                                                                                                    title: Text(
                                                                                                      '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                                                      style: Styles.baseTextTheme.headline2.copyWith(
                                                                                                        // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                        fontSize: kIsWeb ? 14 : 12,
                                                                                                        fontWeight: FontWeight.w400,
                                                                                                      ),
                                                                                                    ),
                                                                                                    // Text('Will Post on ${DateFormat.yMMMMd().add_jm().format(postingTime)}'),

                                                                                                    subtitle: Text(widget.controller.scheduledPosts[index].body),
                                                                                                  ),
                                                                                                );
                                                                                              },

                                                                                              ///changes made in this section of code
                                                                                              separatorBuilder: (_, __) {
                                                                                                return Divider(height: 1);
                                                                                              },
                                                                                              itemCount: widget.controller.scheduledPosts.length),
                                                                                        ),
                                                                              isEditable
                                                                                  ? ListTile(
                                                                                      leading: selectedALL==true?
                                                                                      GestureDetector(
                                                                                          onTap:(){

                                                                                            widget.postsForDeletions = [];
                                                                                            widget.controller.scheduledPosts.forEach((element) {
                                                                                              element.isScheduledPostSelectedForDeletion = false;
                                                                                            });

                                                                                            selectedALL = false;
                                                                                            print('List....... ' + widget.postsForDeletions.toString());

                                                                                            setState(
                                                                                                    () {});
                                                                                          },
                                                                                          child: Text(Strings.deselectAll)):
                                                                                      GestureDetector(
                                                                                          onTap:(){

                                                                                            widget.controller.scheduledPosts.forEach((element) {
                                                                                              element.isScheduledPostSelectedForDeletion = true;
                                                                                            });


                                                                                            widget.postsForDeletions = [];
                                                                                            widget.controller.scheduledPosts.forEach((element) {
                                                                                              widget.postsForDeletions.add(element.id);
                                                                                            });








                                                                                            selectedALL = true;


                                                                                            setState(
                                                                                                    () {});

                                                                                            print('List....... ' + widget.postsForDeletions.toString());

                                                                                          },
                                                                                          child: Text(Strings.selectAll)),
                                                                                      trailing: GestureDetector(
                                                                                        onTap: () {
                                                                                          print('List ' + widget.postsForDeletions.toString());
                                                                                          widget.controller.deleteScheduledPosts(widget.postsForDeletions, context);
                                                                                          // widget
                                                                                          //     .postsForDeletions
                                                                                          //     .clear();
                                                                                        },
                                                                                        child: Text(Strings.delete),
                                                                                      ),
                                                                                    )
                                                                                  : SizedBox(),
                                                                            ],
                                                                          )
                                                                        //     ;
                                                                        //   },
                                                                        // )
                                                                        : Column(
                                                                            crossAxisAlignment:
                                                                                CrossAxisAlignment.start,
                                                                            children: [
                                                                              Row(
                                                                                children: [
                                                                                  GestureDetector(
                                                                                      onTap: () {
                                                                                        Navigator.pop(context, false);
                                                                                      },
                                                                                      child: Icon(
                                                                                        Icons.close,
                                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      )),
                                                                                  SizedBox(width: 12),
                                                                                  Text(
                                                                                    Strings.schedule,
                                                                                    //  style: Theme.of(context).textTheme.headline4

                                                                                    style: Styles.baseTextTheme.headline2.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                  ),
                                                                                  Spacer(),
                                                                                  RoundedButton(
                                                                                    Strings.confirm,

                                                                                    // hourValidatedSuccessfully &&
                                                                                    //         minutesValidatedSuccessfully &&
                                                                                    //         monthValidatedSuccessfully &&
                                                                                    //         dayValidatedSuccessfully
                                                                                    //     ? null
                                                                                    //     :
                                                                                    () {
                                                                                      if (monthValidatedSuccessfully) {
                                                                                        widget.isPostScheduled = true;

                                                                                        //  visibility=false;

                                                                                        Navigator.pop(context, true);
                                                                                      }
                                                                                    },
                                                                                    horizontalPadding: 20.0,
                                                                                    verticalPadding: 0.0,
                                                                                    roundedButtonColor: controller.displayColor,
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              // ListTile(
                                                                              //   horizontalTitleGap:
                                                                              //   0.0,
                                                                              //   leading: Icon(
                                                                              //       Icons
                                                                              //           .calendar_today),
                                                                              //   title: Text(
                                                                              //       'Will Post on ${DateFormat.yMMMMd().add_jm().format(DateTime.parse(selectedDateTime))}',
                                                                              //
                                                                              //   ),
                                                                              // ),
                                                                              SizedBox(
                                                                                height: 20,
                                                                              ),

                                                                              Row(
                                                                                children: [
                                                                                  Icon(
                                                                                    Icons.calendar_today,
                                                                                    color: Color(0xFF586976),
                                                                                  ),
                                                                                  // SizedBox(width: 20,),
                                                                                  Padding(
                                                                                    padding: const EdgeInsets.only(left: 8),
                                                                                    child: Text(
                                                                                      '${Strings.willPostOn} ${DateFormat.yMMMMd().add_jm().format(DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDateTime))}',
                                                                                      // 'Will Post on ${DateFormat("yyyy-MM-dd hh:mm").parse(selectedDateTime)}',
                                                                                      style: Styles.baseTextTheme.headline2.copyWith(
                                                                                        // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                        fontSize: kIsWeb ? 14 : 10,
                                                                                        fontWeight: FontWeight.w400,
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),

                                                                              Text(
                                                                               Strings.date,
                                                                                //  style: Theme.of(context).textTheme.headline6,

                                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                                  //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                              ),
                                                                              SizedBox(height: 10),
                                                                              *//* Date DropDown Section *//*
                                                                              Row(
                                                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                                                children: [
                                                                                  // Drop Down Button for Month
                                                                                  ButtonTheme(
                                                                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                                    child: Expanded(
                                                                                      flex: 1,
                                                                                      child: DropdownButtonFormField<String>(
                                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                                        isExpanded: true,

                                                                                        decoration: InputDecoration(
                                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                                          border: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          disabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          enabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: controller.displayColor,
                                                                                            ),
                                                                                          ),
                                                                                          labelText: Strings.month,
                                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        // value: 0.toString(),
                                                                                        hint: Text(
                                                                                          months[DateTime.now().month - 1],
                                                                                          //,
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),

                                                                                        alignment: Alignment.bottomCenter,
                                                                                        items: months.map((String value) {
                                                                                          return DropdownMenuItem<String>(
                                                                                            value: value,
                                                                                            child: Text(
                                                                                              value.toString(),
                                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                fontSize: 14,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }).toList(),
                                                                                        onChanged: (month) {
                                                                                          *//*        int selectedMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                month);
                                                            int currentMonthIndex = months.indexWhere((element) =>
                                                            element ==
                                                                months[DateTime.now().month - 1]);
                                                            selectedMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            scheduleMonthValue =
                                                                (months.indexWhere((element) => element == month) + 1).toString();
                                                            print('SELECTED  $selectedMonthIndex' +
                                                                ' : ' +
                                                                'CURRENT $currentMonthIndex');*//*

                                                                                          selectedMonthValue = (months.indexWhere((element) => element == month) + 1).toString();

                                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                                            monthValidatedSuccessfully = true;
                                                                                          } else {
                                                                                            monthValidatedSuccessfully = false;
                                                                                          }
                                                                                          setState(() {});

                                                                                          // setState(() {});
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  SizedBox(width: 12),
                                                                                  // Drop Down Button for Day
                                                                                  ButtonTheme(
                                                                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                                    child: Expanded(
                                                                                      flex: 1,
                                                                                      child: DropdownButtonFormField<String>(
                                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                                        isExpanded: true,
                                                                                        decoration: InputDecoration(
                                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                                          border: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          disabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          enabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: controller.displayColor,
                                                                                            ),
                                                                                          ),
                                                                                          labelText: Strings.day,
                                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        // value: 0.toString(),
                                                                                        hint: Text(
                                                                                          selectedDayValue,
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        alignment: Alignment.bottomCenter,
                                                                                        items: List.generate(31, (index) => index + 1).map((int value) {
                                                                                          return DropdownMenuItem<String>(
                                                                                            value: value.toString(),
                                                                                            child: Text(
                                                                                              value.toString(),
                                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                fontSize: 14,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }).toList(),
                                                                                        onChanged: (day) {
                                                                                          selectedDayValue = day;
                                                                                          scheduleDayValue = day;
                                                                                          int currentDay = DateTime.now().day;
                                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                                            monthValidatedSuccessfully = true;
                                                                                          } else {
                                                                                            monthValidatedSuccessfully = false;
                                                                                          }
                                                                                          setState(() {});
                                                                                          // }
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),

                                                                                  SizedBox(width: 12),

                                                                                  // Drop Down Button for Year
                                                                                  ButtonTheme(
                                                                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                                    child: Expanded(
                                                                                      flex: 1,
                                                                                      child: DropdownButtonFormField<String>(
                                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                                        isExpanded: true,
                                                                                        decoration: InputDecoration(
                                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                                                                                          border: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          disabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          enabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: controller.displayColor,
                                                                                            ),
                                                                                          ),
                                                                                          labelText:Strings.year ,
                                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        // value: 0.toString(),
                                                                                        hint: Text(
                                                                                          DateTime.now().year.toString(),
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        alignment: Alignment.bottomCenter,
                                                                                        items: years.map((int value) {
                                                                                          return DropdownMenuItem<String>(
                                                                                            value: value.toString(),
                                                                                            child: Text(
                                                                                              value.toString(),
                                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                fontSize: 14,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }).toList(),
                                                                                        onChanged: (year) {
                                                                                          selectedYearValue = year;

                                                                                          scheduleYearValue = year;

                                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                                            monthValidatedSuccessfully = true;
                                                                                          } else {
                                                                                            monthValidatedSuccessfully = false;
                                                                                          }
                                                                                          setState(() {});
                                                                                          //

                                                                                          print('Scheduled Year ' + scheduleYearValue.toString());
                                                                                          // setState(() {});
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                              !monthValidatedSuccessfully
                                                                                  ? Text(
                                                                                     Strings.youCannotScheduleAWerfInThePast,
                                                                                      style: TextStyle(color: Colors.red),
                                                                                    )
                                                                                  : SizedBox(),
                                                                              SizedBox(height: 20),
                                                                              *//* Time DropDown Section *//*
                                                                              Text(
                                                                                Strings.time,
                                                                                //  style: Theme.of(context).textTheme.headline6,

                                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                                  //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                              ),
                                                                              SizedBox(height: 10),
                                                                              Row(
                                                                                children: [
                                                                                  *//* DropDown Button For Hours *//*
                                                                                  ButtonTheme(
                                                                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                                    child: Expanded(
                                                                                      flex: 1,
                                                                                      child: DropdownButtonFormField<String>(
                                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                                        isExpanded: true,
                                                                                        decoration: InputDecoration(
                                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                                          border: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          disabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          enabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: controller.displayColor,
                                                                                            ),
                                                                                          ),
                                                                                          labelText: Strings.hours,
                                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        // value: 0.toString(),
                                                                                        hint: Text(
                                                                                          selectedHourValue,
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        alignment: Alignment.bottomCenter,
                                                                                        items: List.generate(24, (index) => index).map((int value) {
                                                                                          return DropdownMenuItem<String>(
                                                                                            value: value.toString(),
                                                                                            child: Text(
                                                                                              value.toString(),
                                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                fontSize: 14,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }).toList(),
                                                                                        onChanged: (hour) {
                                                                                          selectedHourValue = hour;
                                                                                          scheduleHourValue = hour;

                                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                                            monthValidatedSuccessfully = true;
                                                                                          } else {
                                                                                            monthValidatedSuccessfully = false;
                                                                                          }
                                                                                          setState(() {});
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  *//* DropDown Button For Minutes *//*
                                                                                  SizedBox(width: 12),
                                                                                  ButtonTheme(
                                                                                    materialTapTargetSize: MaterialTapTargetSize.padded,
                                                                                    child: Expanded(
                                                                                      flex: 1,
                                                                                      child: DropdownButtonFormField<String>(
                                                                                        icon: Icon(Icons.keyboard_arrow_down),
                                                                                        isExpanded: true,
                                                                                        decoration: InputDecoration(
                                                                                          contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                                                                          border: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          disabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.grey,
                                                                                            ),
                                                                                          ),
                                                                                          enabledBorder: OutlineInputBorder(
                                                                                            borderRadius: BorderRadius.circular(10),
                                                                                            borderSide: BorderSide(
                                                                                              color: controller.displayColor,
                                                                                            ),
                                                                                          ),
                                                                                          labelText: Strings.minutes,
                                                                                          labelStyle: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : controller.displayColor,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),

                                                                                        // value: 0.toString(),
                                                                                        hint: Text(
                                                                                          selectedMinutesValue,
                                                                                          style: Styles.baseTextTheme.headline4.copyWith(
                                                                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                            fontSize: 14,
                                                                                          ),
                                                                                        ),
                                                                                        alignment: Alignment.bottomCenter,
                                                                                        items: List.generate(60, (index) => index).map((int value) {
                                                                                          return DropdownMenuItem<String>(
                                                                                            value: value.toString(),
                                                                                            child: Text(
                                                                                              value.toString(),
                                                                                              style: Styles.baseTextTheme.headline4.copyWith(
                                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                fontSize: 14,
                                                                                              ),
                                                                                            ),
                                                                                          );
                                                                                        }).toList(),
                                                                                        onChanged: (minute) {
                                                                                          selectedMinutesValue = minute;
                                                                                          scheduleMinutesValue = minute;
                                                                                          print("value$minute");
                                                                                          selectedDateTime = "$selectedYearValue-$selectedMonthValue-$selectedDayValue" + " $selectedHourValue:$selectedMinutesValue:00";

                                                                                          if (compareSelectedDatetime(selectedDateTime)) {
                                                                                            monthValidatedSuccessfully = true;
                                                                                          } else {
                                                                                            monthValidatedSuccessfully = false;
                                                                                          }
                                                                                          setState(() {});
                                                                                        },
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                  SizedBox(width: 12),
                                                                                  Expanded(flex: 1, child: SizedBox()),
                                                                                ],
                                                                              ),
                                                                              *//* if (!monthValidatedSuccessfully)
                                                    Text(
                                                      'You cannot schedule a Werf in the past',
                                                      style: TextStyle(
                                                        color:
                                                        Colors.red,
                                                        fontSize: 12,
                                                      ),
                                                    )
                                                  else
                                                    SizedBox(),*//*
                                                                              SizedBox(height: 20),
                                                                              Text(
                                                                                Strings.timeZone,
                                                                                //  style: Theme.of(context).textTheme.headline6,

                                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.w500,
                                                                                ),
                                                                              ),

                                                                              SizedBox(height: 10),
                                                                              Text(
                                                                                DateTime.now().timeZoneName,
                                                                                // style: Theme.of(context).textTheme.headline4.copyWith(height: 1.2)

                                                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                  //fontSize: kIsWeb ? 16 : 14,
                                                                                  fontWeight: FontWeight.bold,
                                                                                ),
                                                                              ),
                                                                              Divider(height: 1),
                                                                              SizedBox(height: 10),
                                                                              GestureDetector(
                                                                                  onTap: () async {


                                                                                    widget.controller.noScheduledPost = true;
                                                                                    showScheduledWerfs = true;
                                                                                    setState(() {});

                                                                                    widget.controller.scheduledPosts = await widget.controller.getScheduledPosts();
                                                                                    widget.controller.noScheduledPost = false;

                                                                                    setState(() {});
                                                                                  },
                                                                                  child: Text(
                                                                                    Strings.scheduledWerfs,
                                                                                    style: Styles.baseTextTheme.headline2.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      fontSize: kIsWeb ? 16 : 14,
                                                                                      fontWeight: FontWeight.w500,
                                                                                    ),
                                                                                  ))
                                                                            ],
                                                                          ),
                                                                  );
                                                                });
                                                              });

                                                      if (val) {
                                                        print(
                                                            "getValueFromSchedule" +
                                                                val.toString());
                                                        setState(() {});
                                                      }
                                                    },
                                          child: Container(
                                            width: 20,
                                            height: 20,
                                            child: SvgPicture.asset(
                                              // _pickedPdfs.length > 0 ||
                                              //     _pickedAudios.length > 0 ||
                                              //     _pickedVideos.length > 0
                                              //     ?
                                              'assets/post_icons/calendar.svg',
                                              fit: BoxFit.cover,
                                              height: 200,
                                              width: 200,
                                              color: controller
                                                              .modelList2[widget
                                                                  .controller
                                                                  .currentIndexText]
                                                              .mediaData2
                                                              .length >
                                                          0 ||
                                                      isFollowers == true ||
                                                      isMentionedPeople ==
                                                          true ||
                                                      threadCreated == true
                                                  //   isMediaUploading
                                                  ? controller.displayColor
                                                      .withOpacity(0.6)
                                                  :
                                                  //  _pickedVideos.isNotEmpty ||
                                                  isMediaAttached ||
                                                          showPolls[controller
                                                              .currentIndexText]
                                                      ? controller.displayColor
                                                          .withOpacity(0.6)
                                                      : controller.displayColor,
                                              // : Colors.purple,
                                            ),
                                          ),
                                        ),*/

                                        /// locationicon
                                        CreatePostIcons(AppImages.uploadLocation, () {
                                          locationController
                                              .locationTextController
                                              .clear();
                                          Get.to(GoogleSearchSuggestion(
                                              index: controller
                                                  .currentIndexText)).then((value) {
                                            setState(() {
                                            });
                                          });
                                        }),
                                       /* InkWell(
                                          onTap: () {
                                            locationController
                                                .locationTextController
                                                .clear();
                                            Get.to(GoogleSearchSuggestion(
                                                index: controller
                                                    .currentIndexText)).then((value) {
                                                      setState(() {
                                                      });
                                            });
                                          },
                                          child: Container(
                                              width: 20,
                                              height: 20,
                                              child: SvgPicture.asset(
                                                'assets/post_icons/location.svg',
                                                color: controller.displayColor,
                                              )),
                                        ),*/

                                        ///smileicon
                                        CreatePostIcons(AppImages.uploadEmojis, () {
                                          //print("hello");
                                          if (isEmojiVisible) {
                                            print("in");

                                            widget.controller.focusNode
                                                .requestFocus();
                                          } else if (!isEmojiVisible) {
                                            // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                            // await Future.delayed(
                                            //     const Duration(milliseconds: 100));
                                            FocusScope.of(context).unfocus();

                                            // widget.controller.focusNode.unfocus();
                                          }
                                          isEmojiVisible = !isEmojiVisible;
                                          if (this.mounted) {
                                            // check whether the state object is in tree
                                            setState(() {
                                              // make changes here
                                            });
                                          }
                                        }),
                                        /*InkWell(
                                          onTap: () {
                                            //print("hello");
                                            if (isEmojiVisible) {
                                              print("in");

                                              widget.controller.focusNode
                                                  .requestFocus();
                                            } else if (!isEmojiVisible) {
                                              // await SystemChannels.textInput.invokeMethod('TextInput.hide');
                                              // await Future.delayed(
                                              //     const Duration(milliseconds: 100));
                                              FocusScope.of(context).unfocus();

                                              // widget.controller.focusNode.unfocus();
                                            }
                                            isEmojiVisible = !isEmojiVisible;
                                            if (this.mounted) {
                                              // check whether the state object is in tree
                                              setState(() {
                                                // make changes here
                                              });
                                            }
                                          },
                                          child: Icon(
                                            Icons.emoji_emotions,
                                            size: 20,
                                            color: controller.displayColor,
                                          ),
                                        ),*/

                                        /// createthreadicon
                                        isEdit != true || widget.isPostScheduled
                                            ? visibility == true
                                                ? InkWell(
                                                    onTap: () async {
                                                      setState(() {
                                                        //  FocusScope.of(context).unfocus();
                                                        threadCreated = true;
                                                        if (controller
                                                            .modelList2
                                                            .isNotEmpty) {
                                                          controller
                                                                  .modelList2[0]
                                                                  .postType =
                                                              "thread";
                                                          controller.modelList2
                                                              .add(ModelClass
                                                                  .fromJson({
                                                            'body': '',
                                                            'poll_ques_first':
                                                                null,
                                                            'poll_ques_first':
                                                                null,
                                                            'poll_ques_third':
                                                                null,
                                                            'poll_ques_fourth':
                                                                null,
                                                            'files': [],
                                                            'link_meta': '',
                                                            'link': '',
                                                            'link_image': '',
                                                            'link_title': '',
                                                            'days': '',
                                                            'minutes': '',
                                                            'hours': '',
                                                            'location': '',
                                                            'lat': '',
                                                            'lng': '',
                                                            'type': "thread",
                                                            'poll_thread': controller
                                                                        .modelList2[
                                                                            controller.currentIndexText]
                                                                        .poll_ques_first ==
                                                                    null
                                                                ? false
                                                                : true
                                                          }));
                                                        } else {
                                                          controller.modelList2
                                                              .add(ModelClass
                                                                  .fromJson({
                                                            'body': '',
                                                            'poll_ques_first':
                                                                null,
                                                            'poll_ques_first':
                                                                null,
                                                            'poll_ques_third':
                                                                null,
                                                            'poll_ques_fourth':
                                                                null,
                                                            'files': [],
                                                            'link_meta': '',
                                                            'link': '',
                                                            'link_image': '',
                                                            'link_title': '',
                                                            'days': '',
                                                            'minutes': '',
                                                            'hours': '',
                                                            'location': '',
                                                            'lat': '',
                                                            'lng': '',
                                                            'type': 'post',
                                                          }));
                                                        }
                                                        print(
                                                            'lenghth of listy:${controller.modelList2.length}');
                                                        print(
                                                            'index of the list: ${controller.currentIndexText}');
                                                        isMediaAttached = false;
                                                        widget.isPostScheduled =
                                                            false;
                                                        // List <FocusScopeNode> currentFocus = FocusScope.of(context) as List<FocusScopeNode>;
                                                        //
                                                        //   if (!currentFocus[controller.currentIndexText].hasPrimaryFocus) {
                                                        //     currentFocus[controller.currentIndexText].unfocus();
                                                        //   }

                                                        controller
                                                                .currentIndexText =
                                                            controller
                                                                    .currentIndexText +
                                                                1;
                                                        //  FocusScope.of(context).requestFocus(nodeFirst[controller.currentIndexText]);
                                                        controller
                                                            .modelList2[controller
                                                                .currentIndexText]
                                                            .poolThread = false;
                                                        //  showPolls[controller.currentIndexText] = false;
                                                        controller.modelList2[widget.controller.currentIndexText].pickedVideos = [];
                                                        _pickedVideosName = [];
                                                        _pickedVideosMemeType = [];
                                                        visibility = false;
                                                        closeIcon = true;
                                                      });
                                                    },
                                                    child: Container(
                                                      height: 20,
                                                      width: 20,
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        // color: controller
                                                        //     .displayColor,
                                                        color: MyColors.werfieNewColor
                                                      ),
                                                      child: const Icon(
                                                        Icons.add,
                                                        color: Colors.white,
                                                        size: 20,
                                                      ),
                                                    ),
                                                  )
                                                : Container(
                                                    height: 20,
                                                    width: 20,
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        color: Colors.grey),
                                                    child: const Icon(
                                                      Icons.add,
                                                      color: Colors.white,
                                                      size: 20,
                                                    ),
                                                  )
                                            : const SizedBox()

                                        // InkWell(
                                        //     onTap: (){
                                        //       Get.to(GoogleSearchSuggestion());
                                        //     },
                                        //     child: Icon(Icons.location_on_rounded))
                                      ],
                                    ),
                              Offstage(
                                  offstage: !isEmojiVisible,
                                  child: Container(
                                      height: 175,
                                      width: double.infinity,
                                      margin: const EdgeInsets.all(5),
                                      padding: const EdgeInsets.all(2),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: Colors.black54, width: .5),
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      child: DefaultTabController(
                                          length: emojis.length,
                                          child: isPortrait
                                              ? Column(children: [
                                                  Container(
                                                      margin: const EdgeInsets
                                                              .symmetric(
                                                          horizontal: 2),
                                                      child: EmojiTabBar(
                                                          tabController:
                                                              _tabController)),
                                                  const Divider(
                                                      color: Colors.black45,
                                                      height: 5,
                                                      thickness: .5),
                                                  EmojisList(
                                                      cross: cross,
                                                      textController:
                                                          _controller[controller
                                                              .currentIndexText],
                                                      emojiSelected: () {
                                                        print("emoji called");

                                                        widget.controller.modelList2[widget.controller.currentIndexText].postBodyLength   = widget.controller.modelList2[widget.controller.currentIndexText].postBodyLength  + 1;


                                                        if(_controller[controller
                                                            .currentIndexText].text.length>5000)
                                                        {

                                                          setState(() {

                                                          });
                                                          widget.controller.postText = false;

                                                          print("widget.controller.postText ${widget.controller.postText}");
                                                          widget.controller.update();
                                                          UtilsMethods.toastMessageShow(
                                                              Colors.red,
                                                              Colors.red,
                                                              Colors.red,
                                                              message: Strings.textLimitExceeded);

                                                        }
                                                        else{
                                                          widget.controller.postText = true;
                                                          widget.controller.update();

                                                        }



                                                        print("widget.controller.modelList2[widget.controller.currentIndexText].postBodyLength ${widget.controller.modelList2[widget.controller.currentIndexText].postBodyLength}");






                                                      },
                                                      tabController:
                                                          _tabController)
                                                ])
                                              : Row(children: [
                                                  emojiSideBar(),
                                                  EmojisList(
                                                      cross: cross,
                                                      textController:
                                                          _controller[controller
                                                              .currentIndexText],
                                                      emojiSelected: () {
                                                        print("emoji called");
                                                        widget.controller
                                                            .postText = true;
                                                        widget.controller
                                                            .update();
                                                        setState(() {});
                                                      },
                                                      tabController:
                                                          _tabController)
                                                ])))),
                            ],
                          ),
                        )
                      ],
                    ),
            ),
          )
          // :SizedBox()
          ),
    );
  }

  uploadImages(int index) async{
    List<_dio.MultipartFile> files = [];
    files = controller.modelList2[index].listFilesMob.map((path) => _dio.MultipartFile.fromFileSync(
      path.path,
      filename: path.name,
    ))
        .toList();
    if (kDebugMode) {
      print(files.length);
    }
    Map<String, dynamic> userData = {};


    // print("filesx ${files[0].contentType}");
    // print("files ${files[0].filename}");
    // print("files ${files[0].headers}");
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }
    // isMediaUploading = true;
    await controller.multiImageSeleted(userData, 1,controller.modelList2[index].listFilesMob, index: index);
  }

  Future<bool> _willPopCallback() async {
    // await showDialog or Show add banners or whatever
    // then
    imageThumbnailsList.clear();
    if (widget.controller.modelList2[controller.currentIndexText]
            .imageDescriptionController.length >
        0) {
      widget.controller.modelList2[controller.currentIndexText]
          .imageDescriptionController
          .forEach((element) {
        element.clear();
      });
    }

    widget.controller.mediaData.clear();
    controller.modelList2[controller.currentIndexText].imagePickCount = 0;
    widget.controller.currentIndexText = 0;
    apiCalled = false;
    checkLocation = true;
    print(checkLocation);
    SingleTone.instance.selectedLocation = null;
    return true; // return true if the route to be popped
  }

  bool compareSelectedDatetime(String selectedDatetime) {
    DateTime parseDate =
         DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDatetime);
    DateTime currentDatetime =
         DateFormat("yyyy-MM-dd HH:mm:ss").parse(DateTime.now().toString());
    bool isValidDate = parseDate.isAfter(currentDatetime);
    print("isValidate" + isValidDate.toString());

    return isValidDate;
  }

  Widget urlFetch() {
    if (widget.controller.scrapUrl.contains('.com') || widget.controller.scrapUrl.contains('http')) {
      print("widget.controller.scrapUrl  ${widget.controller.scrapUrl}");
      return FutureBuilder<ScrappingData>(
        future: widget.controller.urlScraping(widget.controller.scrapUrl),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            link = snapshot.data.link;
            controller.modelList2[controller.currentIndexText].link =
                snapshot.data.link;
            linkTitle = snapshot.data.title;
            controller.modelList2[controller.currentIndexText].linkTitle =
                snapshot.data.title;
            linkMeta = snapshot.data.meta;
            controller.modelList2[controller.currentIndexText].linkMeta =
                snapshot.data.meta;
            if (snapshot.data.images == null || snapshot.data.images.isEmpty) {
              linkImage =
                  "https://www.challengetires.com/assets/img/placeholder.jpg";
            } else {
              linkImage = snapshot.data.images[0];
            }

            controller.modelList2[controller.currentIndexText].linkImage =
                linkImage;

            return cardScrap(context, snapshot.data);
          } else if (snapshot.hasError) {
            print(snapshot.error.toString());
            return Container();
          }
          return const Center(
            child: CircularProgressIndicator(
              color: MyColors.BlueColor,
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }

  bool cardOpen = true;

  Widget cardScrap(BuildContext context, ScrappingData data) {
    print('CARDDDOOPPENENE' + cardOpen.toString());
    // _validURL = true;
    if (data.title != '429 Too Many Requests') {
      return cardOpen
          ? Padding(
              padding: const EdgeInsets.only(bottom: 16.0),
              child: GestureDetector(
                onTap: () {
                  // Get.to(MenuListPage(
                  //   restaurantId: id,
                  // ));
                },
                child: Card(
                  elevation: 4,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(5.0)),
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.all(
                      Radius.circular(5.0),
                    ),
                    child: Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 0),
                          child: Container(
                            height: 80,
                            width: 80,
                            decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(0.0),
                                image: DecorationImage(
                                    image: data.images.isNotEmpty && data.images[0] != null
                                        ? NetworkImage(
                                            data.images[0].toString())
                                        : const AssetImage(
                                            "assets/images/person_placeholder.png"),
                                    fit: BoxFit.contain)),
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                      right: 8.0, top: 8.0),
                                  child: SizedBox(
                                    height: 4,
                                    child: Align(
                                        alignment: Alignment.topRight,
                                        child:
                                            // IconButton(
                                            //   icon: new Icon(Icons.cancel),
                                            //   highlightColor: Color(0xFFedab30),
                                            //   onPressed: (){
                                            //     setState(() {
                                            //     cardOpen = false;
                                            //   });
                                            //     },
                                            // ),
                                            GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    print("cardspen");
                                                    cardOpen = false;
                                                  });
                                                },
                                                child: const Icon(Icons.cancel))),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.00),
                                  child: SizedBox(
                                    // height: 20,
                                    child: data.title != null
                                        ? Text(
                                            data.title.toString(),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            // style: TextStyle(
                                            //   color: Colors.black,
                                            //   fontFamily: 'Cairo',
                                            //   fontSize: 17,
                                            //   fontWeight: FontWeight.w500,
                                            // )

                                            style: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 17,
                                                    fontFamily: 'Cairo',
                                                    fontWeight:
                                                        FontWeight.w500)
                                                : const TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 17,
                                                    fontFamily: 'Cairo',
                                                    fontWeight:
                                                        FontWeight.w500),
                                          )
                                        : const SizedBox(),
                                  ),
                                ),
                                // Padding(
                                //   padding: const EdgeInsets.only(right: 8.00),
                                //   child: SizedBox(
                                //     // height: 18,
                                //     child:
                                //     data.meta!=null?
                                //     Text(
                                //       data.meta.toString(),
                                //       maxLines: 1,
                                //       overflow: TextOverflow.ellipsis,
                                //       // style: TextStyle(
                                //       //   color: Colors.black,
                                //       //   fontFamily: 'Cairo',
                                //       //   fontSize: 16,
                                //       //   fontWeight: FontWeight.w500,
                                //       // ),
                                //
                                //       style: Theme.of(context).brightness == Brightness.dark ?
                                //       TextStyle(color: Colors.white,  fontSize: 16,
                                //           fontFamily: "Cairo",
                                //           fontWeight: FontWeight.w500)
                                //           : TextStyle(color: Colors.black,  fontSize: 16,
                                //           fontFamily: "Cairo",
                                //           fontWeight: FontWeight.w500),
                                //
                                //     ):SizedBox(),
                                //   ),
                                // ),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.00),
                                  child: SizedBox(
                                    // height: 18,
                                    child: data.link != null
                                        ? Text(
                                            data.link.toString(),
                                            textAlign: TextAlign.left,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            // style: TextStyle(
                                            //   color: Colors.grey[700],
                                            //   fontFamily: 'Cairo',
                                            //   fontSize: 14,
                                            //   fontWeight: FontWeight.w400,
                                            // )

                                            style: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? const TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 14,
                                                    fontFamily: "Cairo",
                                                    fontWeight:
                                                        FontWeight.w400)
                                                : TextStyle(
                                                    color: Colors.grey[700],
                                                    fontSize: 14,
                                                    fontFamily: "Cairo",
                                                    fontWeight:
                                                        FontWeight.w400),
                                          )
                                        : const SizedBox(),
                                  ),
                                ),
                                const SizedBox(height: 4),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            )
          : const SizedBox();
    } else {
      return Container();
    }
  }

  SizedBox emojiSideBar() {
    return SizedBox(
        width: 50,
        child: ListView.builder(
            controller: _scrollController,
            itemCount: emojis.length,
            itemBuilder: (context, index) {
              final x = emojis[index].split(' ');
              return GestureDetector(
                  onTap: () {
                    _selectedTab = index;
                    _tabController.animateTo(index);
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(2),
                      margin: const EdgeInsets.all(2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: _selectedTab == index
                              ? Colors.grey.shade300
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(
                        x[0],
                        // style: const TextStyle(fontSize: 25),

                        style: Theme.of(context).brightness == Brightness.dark
                            ? const TextStyle(color: Colors.white, fontSize: 25)
                            : const TextStyle(color: Colors.black, fontSize: 25),
                      )));
            }));
  }
}

class EmojiTabBar extends StatelessWidget {
  const EmojiTabBar({
    Key key,
    this.tabController,
  }) : super(key: key);
  final TabController tabController;

  @override
  Widget build(BuildContext context) {
    return TabBar(
        controller: tabController,
        isScrollable: true,
        labelColor: Colors.black,
        unselectedLabelColor: Colors.blue[700],
        labelStyle: const TextStyle(fontSize: 25),
        unselectedLabelStyle: const TextStyle(fontSize: 20),
        labelPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 1),
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
            color: Colors.grey.withOpacity(.3),
            borderRadius: BorderRadius.circular(10)),
        tabs: emojis.map((e) {
          final x = e.split(' ');
          return Tab(
              child: SizedBox(width: 35, child: Center(child: Text(x[0]))));
        }).toList());
  }
}

class EmojisList extends StatefulWidget {
  EmojisList(
      {Key key,
      this.cross,
      this.emojiSelected,
      TextEditingController textController,
      this.tabController,
      this.controller})
      : _textController = textController,
        super(key: key);

  final int cross;
  final TextEditingController _textController;
  final TabController tabController;
  Function() emojiSelected;

  final NewsfeedController controller;

  @override
  State<EmojisList> createState() => _EmojisListState();
}

class _EmojisListState extends State<EmojisList> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: TabBarView(
            controller: widget.tabController,
            children: emojis.map((e) {
              final x = e.split(' ');
              return GridView.builder(
                  itemCount: x.length,
                  scrollDirection: Axis.vertical,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: widget.cross,
                      mainAxisSpacing: 2,
                      crossAxisSpacing: 2),
                  itemBuilder: (context, index) => GestureDetector(
                      onTap: () {
                             widget._textController.text = widget._textController.text + x[index];
                               widget.emojiSelected();

                      },
                      child: Container(
                          decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              borderRadius: BorderRadius.circular(10)),
                          alignment: Alignment.center,
                          child: FittedBox(
                              child: Text(
                            x[index],
                            //  style: const TextStyle(fontSize: 30)

                            style: Theme.of(context).brightness ==
                                    Brightness.dark
                                ? const TextStyle(color: Colors.white, fontSize: 30)
                                : const TextStyle(color: Colors.black, fontSize: 30),
                          )))));
            }).toList()));
  }
}

// extension Utility on BuildContext {
//   void nextBlankTextFocus(int currentIndexText, List<TextEditingController> controller,) {
//      controller[currentIndexText].text;
//     do {
//       // Set starting text field so we can check if we've come back to where we started
//       if (controller[currentIndexText].text == null) {
//         controller[currentIndexText].text = FocusScope.of(this).focusedChild.context.widget;
//       } else if ( ==
//           FocusScope.of(this).focusedChild.context.widget) {
//         // Back to where we started - stop as there are no more blank text fields
//         break;
//       }
//
//       FocusScope.of(this).nextFocus();
//     } while (FocusScope.of(this).focusedChild.context.widget is EditableText &&
//         (FocusScope.of(this).focusedChild.context.widget as EditableText)
//             .controller
//             .text
//             .trim()
//             .length !=
//             0);
//   }
// }
