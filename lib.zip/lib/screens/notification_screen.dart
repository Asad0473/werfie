import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/all_notifications_widget.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/mentioned_notifications_widget.dart';
import 'package:werfieapp/widgets/verified_notifications_widget.dart';

import '../network/controller/notification_controller.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../web_views/web_guest_user/components/guest_user_tab_button.dart';

class NotificationScreen extends StatefulWidget {
  final bool isMainScreen;

  NotificationScreen({Key key, this.isMainScreen = false});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  void initState() {
    addNotificationsMetaTags();
    super.initState();
    if (Get.isRegistered<NotificationController>()) {
      Get.find<NotificationController>().getNotifications();
    }
  }

  addNotificationsMetaTags(){

    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleNotification,
        metaTagDescription:MetaTagValues.notificationsMetaDescription,
        metaTagKeywords: MetaTagValues.notificationsMetaKeywords,
        ogTitle: MetaTagValues.notificationsOGTitle,
        ogDescription: MetaTagValues.notificationsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Responsive(
        mobile: WillPopScope(
            onWillPop: () async {
              Get.find<NewsfeedController>().isBrowseScreen = false;
              Get.find<NewsfeedController>().isNewsFeedScreen = true;
              Get.find<NewsfeedController>().isTrendsScreen = false;
              Get.find<NewsfeedController>().isWhoToFollowScreen = false;
              Get.find<NewsfeedController>().isNotificationScreen = false;
              Get.find<NewsfeedController>().isChatScreen = false;
              Get.find<NewsfeedController>().isSavedPostScreen = false;
              Get.find<NewsfeedController>().isProfileScreen = false;
              Get.find<NewsfeedController>().isSettingsScreen = false;
              Get.find<NewsfeedController>().update();
              Navigator.pop(context);
              return false;
            },
            child: MobileNotificationScreen(isMainScreen: widget.isMainScreen)),
        tablet: MobileNotificationScreen(isMainScreen: widget.isMainScreen),
        desktop: MobileNotificationScreen(isMainScreen: widget.isMainScreen),
      ),
    );
  }
}

class MobileNotificationScreen extends StatelessWidget {
  final controller = Get.put(NewsfeedController());
  final bool isMainScreen;

  MobileNotificationScreen({Key key, this.isMainScreen = true})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        drawer: isMainScreen
            ? !Responsive.isDesktop(context)
                ? MainDrawer(controller)
                : Container()
            : null,
        drawerEnableOpenDragGesture: isMainScreen
            ? !Responsive.isDesktop(context)
                ? false
                : true
            : null,
        appBar: kIsWeb
            ? AppBar(
                elevation: 0,
                bottom: TabBar(
                  indicatorColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : MyColors.werfieBlue,
                  labelColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : MyColors.werfieBlue,
                  unselectedLabelColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white30
                      : Colors.black38,
                  tabs: [
                    Tab(
                      text: Strings.all,
                    ),
                    Tab(
                      text: Strings.verified,
                    ),
                    Tab(
                      text: Strings.mentions,
                    ),
                  ],
                ),
                centerTitle: false,
                iconTheme: IconThemeData(
                  color: Colors.blueAccent,
                ),
                automaticallyImplyLeading: kIsWeb ? false : true,
                // actions: [
                //   IconButton(
                //     onPressed: () {},
                //     icon: Icon(Icons.settings),
                //     color: Colors.blueAccent,
                //   ),
                // ],
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                title: Text(
                  Strings.notifications,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                  // style: Theme.of(context).textTheme.headline6.copyWith(
                  //     color: Colors.black, fontWeight: FontWeight.bold)
                ),
                // bottom: TabBar(
                //   automaticIndicatorColorAdjustment: true,
                //   labelColor: Colors.blueAccent,
                //   unselectedLabelColor: Colors.black,
                //   tabs: [
                //     Tab(
                //       text: Strings.all,
                //     ),
                //     // Tab(
                //     //   text: Strings.mentions,
                //     // ),
                //   ],
                // ),
              )
            : AppBar(
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                iconTheme: IconThemeData(
                  color: Color(0xFF4f515b),
                ),
          bottom: TabBar(
            indicatorColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : MyColors.werfieBlue,
            labelColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : MyColors.werfieBlue,
            unselectedLabelColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.white30
                : Colors.black38,
            tabs: [
              Tab(
                text: Strings.all,
              ),
              Tab(
                text: Strings.verified,
              ),
              Tab(
                text: Strings.mentions,
              ),
            ],
          ),
                leading: controller.userProfile == null
                    ? Container(
                        width: 24,
                        child: Center(
                          child: SpinKitCircle(
                            color: Colors.grey,
                            size: 40,
                          ),
                        ),
                      )
                    : Builder(
                        builder: (BuildContext context) {
                          return GestureDetector(
                            onTap: () {
                              // Get.back();
                              Scaffold.of(context).openDrawer();
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(40),
                                child: FadeInImage(
                                  fit: BoxFit.cover,
                                  width: 30,
                                  height: 30,
                                  placeholder: AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  image: NetworkImage(controller
                                              .userProfile.profileImage !=
                                          null
                                      ? controller.userProfile.profileImage
                                      : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                title: Container(
                  height: 45,
                  width: MediaQuery.of(context).size.width / 1.8,
                  child: Center(
                    child: Text(
                      Strings.notifications,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      // style: Theme.of(context).textTheme.headline6.copyWith(
                      //       fontSize: 18,
                      //       fontWeight: FontWeight.w700,
                      //       color: Colors.black,
                      //     ),
                    ),
                  ),
                ),
                // bottom: TabBar(
                //   automaticIndicatorColorAdjustment: true,
                //   labelColor: Colors.blueAccent,
                //   unselectedLabelColor: Colors.black,
                //   tabs: [
                //     Tab(
                //       text: Strings.all,
                //     ),
                //     // Tab(
                //     //   text: Strings.mentions,
                //     // ),
                //   ],
                // ),
              ),
        body:TabBarView(children: [
          AllNotificationsWidget(),
          VerifiedNotificationsWidget(),
          MentionedNotificationsWidget(),
        ],),
        // TabBarView(
        //   children: [AllNotificationsWidget()],
        //   // children: [AllNotificationsWidget(), MentionsWidget()],
        // ),
      ),
    );
  }
}
