import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/screens/filter_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../network/controller/news_feed_controller.dart';
import '../utils/font.dart';
import '../widgets/blue_tick.dart';

class SearchScreen extends StatelessWidget {
  final newsFeedController = Get.find<NewsfeedController>();

 SearchScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BrowseController>(
      init: BrowseController(),
      builder: (controller) {
        return WillPopScope(
          onWillPop: () {
            FocusScopeNode currentFocus = FocusScope.of(context);
            if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
              FocusManager.instance.primaryFocus?.unfocus();
            }
            controller.isSearch = false;
            controller.searchResult = [];
            controller.searchResult.clear();
            controller.update();
            Get.back();
            return;
          },
          child: Scaffold(
            appBar: AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: const IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: GestureDetector(
                onTap: () {
                  // print("back clicked");
                  controller.isSearch = false;
                  controller.searchResult = [];
                  controller.searchResult.clear();
                  controller.update();
                },
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        controller.isSearch = false;
                        controller.searchResult = [];
                        controller.searchResult.clear();
                        controller.update();
                        Get.back();
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    const Spacer(),

                    SizedBox(
                      height: 45,
                      width: 250,
                      child: TextField(
                        controller: controller.searchText,
                        style: LightStyles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          //fontWeight: FontWeight.w500,
                          // fontSize: 16,
                        ),
                        cursorColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                        onChanged: (val) {
                          controller.delaySearch.run(() async {

                            var newVal=val;
                            if(val.contains('@')){
                              newVal=val.replaceAll('@', '');
                            }
                            debugPrint('Search Val----->>>> ${val}');
                            controller.isSearchLoading=true;
                            controller.isSearch = true;
                            if (newVal.isEmpty || newVal.length < 1) {
                              controller.isSearch = false;
                              controller.searchResult = [];
                              controller.searchResult.clear();
                              controller.update();

                            }
                            if (newVal.isNotEmpty &&
                                newVal.split(" ").join("") != "" &&
                                newVal.split(" ").join("").length > 0) {

                              controller.searchResult = [];
                              controller.searchResult.clear();
                              controller.onSearchTextChanged(newVal);
                            } else if (newVal.isEmpty &&
                                newVal.split(" ").join("") == "") {
                              controller.isSearchLoading=false;
                              controller.isSearch = false;
                              controller.searchResult = [];
                              controller.searchResult.clear();
                              controller.update();
                            }

                          });

                        },
                        onTap: (){
                          controller.delaySearch.run(() async {

                            var newVal=controller.searchText.text;
                            if(newVal.contains('@')){
                              newVal=newVal.replaceAll('@', '');
                            }
                            debugPrint('Search Val----->>>> ${newVal}');
                            controller.isSearchLoading=true;
                            controller.isSearch = true;
                            if (newVal.isEmpty || newVal.length < 1) {
                              controller.isSearch = false;
                              controller.searchResult = [];
                              controller.searchResult.clear();
                              controller.update();

                            }
                            if (newVal.isNotEmpty &&
                                newVal.split(" ").join("") != "" &&
                                newVal.split(" ").join("").length > 0) {
                              controller.searchResult = [];
                              controller.searchResult.clear();

                              controller.onSearchTextChanged(newVal);
                            } else if (newVal.isEmpty &&
                                newVal.split(" ").join("") == "") {
                              controller.isSearchLoading=false;
                              controller.isSearch = false;
                              controller.searchResult = [];
                              controller.searchResult.clear();
                              controller.update();
                            }

                          });
                        },
                        textAlignVertical: TextAlignVertical.bottom,
                        decoration: InputDecoration(
                          hintText: Strings.search,
                          hintStyle: LightStyles.baseTextTheme.headline3,
                          prefixIcon: Icon(
                            Icons.search,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            size: 20,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(40),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(40),
                            borderSide: const BorderSide(
                              width: 1,
                              color: Colors.grey,
                            ),
                          ),
                          fillColor: Colors.grey[250],
                          filled: true,
                        ),
                      ),
                    ),
                    // Container(
                    //   height: 45,
                    //   width: MediaQuery.of(context).size.width * 0.7,
                    //   child:
                    // ),
                    Spacer(),
                  ],
                ),
              ),
              automaticallyImplyLeading: false,
            ),
            body: SingleChildScrollView(
              child: Column(
                children: [
                  controller.isSearchLoading==true ?
                      const Center(child: CircularProgressIndicator(),)
                 :
                  controller.isSearch == true
                      ?
                  Padding(
                          padding: const EdgeInsets.only(top: 10.0),
                          child: Card(
                            child: Container(
                              height: MediaQuery.of(context).size.height / 1,
                              width: kIsWeb
                                  ? MediaQuery.of(context).size.width / 2.5
                                  : MediaQuery.of(context).size.width / 0.8,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.black
                                  : Colors.white,
                              padding: const EdgeInsets.all(5),
                              child: controller.searchResult == null ||
                                      controller.searchResult.isEmpty
                                  ? Align(
                                      alignment: Alignment.topCenter,
                                      child: Text(
                                        Strings.noSearchResult,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.bold,
                                          // fontSize: kIsWeb ? 16.0 : 14.0,
                                        ),
                                        // style: TextStyle(fontSize: 18),
                                      ))
                                  : SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            Strings.searchResult,
                                            style: const TextStyle(fontSize: 18),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: List.generate(
                                                controller.searchResult.length,
                                                (index) {
                                              if (controller.searchResult[index]
                                                      .username !=
                                                  null) {
                                                return InkWell(
                                                  splashColor: Colors.grey,
                                                  onTap: () async {
                                                    // print("dsfsdfsdfsdf");
                                                    // print("user id" +
                                                    //     controller
                                                    //         .searchResult[index]
                                                    //         .id
                                                    //         .toString());
                                                    controller
                                                            .newsfeedController
                                                            .searchSelected =
                                                        controller.searchResult[
                                                            index];
                                                    controller
                                                            .newsfeedController
                                                            .otherUserName =
                                                        controller
                                                            .searchResult[index]
                                                            .username;
                                                    controller
                                                            .newsfeedController
                                                            .searchSelected
                                                            .type =
                                                        controller
                                                            .searchResult[index]
                                                            .type;
                                                    controller
                                                            .newsfeedController
                                                            .postUserId =
                                                        controller
                                                            .searchResult[index]
                                                            .id;

                                                    controller
                                                            .newsfeedController
                                                            .searchPeopleIndex =
                                                        index;
                                                    controller
                                                            .newsfeedController
                                                            .otherUserName =
                                                        controller
                                                            .searchResult[index]
                                                            .username;
                                                    controller
                                                            .newsfeedController
                                                            .postUserId =
                                                        controller
                                                            .searchResult[index]
                                                            .id;

                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (BuildContext
                                                                    context) =>
                                                                FilteredScreen(
                                                                  newsfeedController:
                                                                      newsFeedController,
                                                                )));

                                                    await controller.newsfeedController.filterUsers(
                                                      id: controller.searchResult[index].id,
                                                      type: controller.searchResult[index].type,
                                                    );
                                                    controller.update();
                                                    newsFeedController.update();
                                                  },
                                                  child: Container(
                                                    width: Get.width,
                                                    margin: const EdgeInsets.only(
                                                        bottom: 5),
                                                    padding:
                                                        const EdgeInsets.all(8.0),
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.black
                                                        : Colors.grey
                                                            .withOpacity(0.05),
                                                    child: Row(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundImage: controller.searchResult[index].profileImage != null
                                                              ? NetworkImage(controller.searchResult[index].profileImage)
                                                              : const AssetImage(
                                                                  "assets/images/person_placeholder.png"),
                                                          radius: 18,
                                                        ),
                                                        const SizedBox(
                                                          width: 20,
                                                        ),
                                                        Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            controller.searchResult[index].firstname == null
                                                                ? const SizedBox()
                                                                : Row(
                                                                    children: [
                                                                      Text(
                                                                        controller.searchResult[index].firstname,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                          fontSize:
                                                                              15,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      ),
                                                                      controller.searchResult[index].accountVerified ==
                                                                              "verified"
                                                                          ? Row(
                                                                              children: [
                                                                                const SizedBox(
                                                                                  width: 5,
                                                                                ),
                                                                                BlueTick(
                                                                                  height: 15,
                                                                                  width: 15,
                                                                                  iconSize: 10,
                                                                                ),
                                                                              ],
                                                                            )
                                                                          : const SizedBox(),
                                                                    ],
                                                                  ),
                                                            Text(
                                                              controller.searchResult[index].username,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline2
                                                                  .copyWith(
                                                                //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                fontSize: kIsWeb
                                                                    ? 14.0
                                                                    : 12.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              }
                                              return InkWell(
                                                splashColor: Colors.grey,
                                                onTap: () async {
                                                  // print("dsfsdfsdfsdf");
                                                  // print("user id" +
                                                  //     controller
                                                  //         .searchResult[index]
                                                  //         .type
                                                  //         .toString());
                                                  controller.newsfeedController
                                                          .searchSelected =
                                                      controller
                                                          .searchResult[index];
                                                  controller.newsfeedController
                                                          .searchSelected.type =
                                                      controller
                                                          .searchResult[index]
                                                          .type;
                                                  controller.newsfeedController
                                                          .postUserId =
                                                      controller
                                                          .searchResult[index]
                                                          .id;

                                                  controller.newsfeedController
                                                          .searchPeopleIndex =
                                                      index;
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                                  context) =>
                                                              FilteredScreen(
                                                                newsfeedController:
                                                                    newsFeedController,
                                                              )));

                                                  await controller.newsfeedController.filterUsers
                                                    (id: controller.searchResult[index].id,
                                                    type: controller.searchResult[index].type,
                                                  );
                                                  controller.update();
                                                  newsFeedController.update();
                                                },
                                                child: Container(
                                                  width: Get.width,
                                                  margin: const EdgeInsets.only(
                                                      bottom: 5),
                                                  padding: const EdgeInsets.all(8.0),
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.black
                                                      : Colors.grey
                                                          .withOpacity(0.05),
                                                  child: Row(
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage: controller
                                                                    .searchResult[
                                                                        index]
                                                                    .profileImage !=
                                                                null
                                                            ? NetworkImage(
                                                                controller
                                                                    .searchResult[
                                                                        index]
                                                                    .profileImage)
                                                            : const AssetImage(
                                                                "assets/images/person_placeholder.png"),
                                                        radius: 18,
                                                      ),
                                                      const SizedBox(
                                                        width: 20,
                                                      ),
                                                      Text(
                                                        controller.searchResult[index].title,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              );
                                            }),
                                          ),
                                        ],
                                      ),
                                    ),
                            ),
                          ),
                        )
                      : const SizedBox(),
                ],
              ),
            ),
            //  Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //   children: [
            //     ActionChip(
            //       elevation: 8.0,
            //       padding: EdgeInsets.all(2.0),
            //       avatar: CircleAvatar(
            //         backgroundColor: Colors.deepPurpleAccent,
            //         child: Icon(
            //           Icons.mode_comment,
            //           color: Colors.white,
            //           size: 20,
            //         ),
            //       ),
            //       label: Text('Posts'),
            //       onPressed: () {
            //         print("btn is pressed");
            //       },
            //       backgroundColor: Colors.grey[200],
            //       shape: StadiumBorder(
            //           side: BorderSide(
            //         width: 1,
            //         color: Colors.deepPurpleAccent,
            //       )),
            //     ),
            //     ActionChip(
            //       elevation: 8.0,
            //       padding: EdgeInsets.all(2.0),
            //       avatar: CircleAvatar(
            //         backgroundColor: Colors.deepPurpleAccent,
            //         child: Icon(
            //           Icons.tag,
            //           color: Colors.white,
            //           size: 20,
            //         ),
            //       ),
            //       label: Text('Hashtags'),
            //       onPressed: () {
            //         print("btn is pressed");
            //       },
            //       backgroundColor: Colors.grey[200],
            //       shape: StadiumBorder(
            //           side: BorderSide(
            //         width: 1,
            //         color: Colors.deepPurpleAccent,
            //       )),
            //     ),
            //     ActionChip(
            //       elevation: 8.0,
            //       padding: EdgeInsets.all(2.0),
            //       avatar: CircleAvatar(
            //         backgroundColor: Colors.deepPurpleAccent,
            //         child: Icon(
            //           Icons.people,
            //           color: Colors.white,
            //           size: 20,
            //         ),
            //       ),
            //       label: Text('People'),
            //       onPressed: () {
            //         print("btn is pressed");
            //       },
            //       backgroundColor: Colors.grey[200],
            //       shape: StadiumBorder(
            //           side: BorderSide(
            //         width: 1,
            //         color: Colors.deepPurpleAccent,
            //       )),
            //     ),
            //   ],
            // ),
          ),
        );
      },
    );
  }
}
