import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:werfieapp/network/apis/send_2FA_code.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/colors.dart';
import '../../network/apis/verify_2FA_code.dart';
import '../../utils/font.dart';
import '../../utils/loading_dialog_builder.dart';
import '../../utils/strings.dart';

class SecurityScreen extends StatefulWidget {
  SecurityScreen();

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  final controller = Get.find<NewsfeedController>();

  bool twoFactorAuthenticationCheckBoxValue = false;

  @override
  void initState() {
    twoFactorAuthenticationCheckBoxValue =
        controller.userProfile.is2FAEnable == 1 ? true : false;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    Strings.twoFactorAuthentication,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: Column(
        children: [
          !kIsWeb
              ? Container()
              : Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 12.0,
                    horizontal: 12,
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            controller.isNotificationsFiltersScreen = false;
                            controller.isNotificationsSettings = false;
                            controller.isSecurity = false;
                            controller.isSecurityAndAccountAccess = true;
                            controller.update();
                          },
                          icon: Icon(Icons.arrow_back),
                        ),
                        Text(
                          Strings.twoFactorAuthentication,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.normal),
                        ),
                      ],
                    ),
                  ),
                ),
          Container(
            height: 1,
            color: Colors.grey[300],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            Strings.manageYourAccountsSecurityKeepTrack,
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
          SizedBox(
            height: 15,
          ),
          ListTile(
            title: Text(
              Strings.twoFactorAuthentication,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            subtitle: Text(
              Strings.helpProtectYourAccountFromUnauthorizedAccess,
              style: TextStyle(fontSize: 12, color: Colors.grey[500]),
            ),
            trailing: Checkbox(
              value: twoFactorAuthenticationCheckBoxValue,
              onChanged: (value) async {
                twoFactorAuthenticationCheckBoxValue = value;
                if(value) {
                  set2Fa(showLoader: true);
                }else{
                  DialogBuilder(context).showLoadingIndicator();
                  Verify2FACodeAPIRes verify2faCodeAPIRes =
                      await Verify2FACodeAPI().verify2FaCode("");
                  Fluttertoast.showToast(msg: verify2faCodeAPIRes.message,toastLength:Toast.LENGTH_LONG,timeInSecForIosWeb: 5);
                  twoFactorAuthenticationCheckBoxValue = false;
                  setState(() {});
                  controller.getUserProfile();
                  DialogBuilder(context).hideOpenDialog();

                }
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
        ],
      ),
    );
  }

  set2Fa({bool showLoader = true}) async {
    if (showLoader) DialogBuilder(context).showLoadingIndicator();
    Send2FACodeAPIRes send2faCodeAPIRes = await Send2FACodeAPI().send2FaCode();


    if (send2faCodeAPIRes.success) {
      if (showLoader) DialogBuilder(context).hideOpenDialog();
      Fluttertoast.showToast(msg: send2faCodeAPIRes.message,toastLength:Toast.LENGTH_LONG,timeInSecForIosWeb: 5);
      showDialog(
        context: context,
        builder: (context) => OtpDialog(
          onSubmit: (otp) async {
            Verify2FACodeAPIRes verify2faCodeAPIRes =
                await Verify2FACodeAPI().verify2FaCode(otp);
            if (verify2faCodeAPIRes.success) {
              Fluttertoast.showToast(msg: verify2faCodeAPIRes.message,toastLength:Toast.LENGTH_LONG,timeInSecForIosWeb: 5);
              twoFactorAuthenticationCheckBoxValue = true;
              setState(() {});
              controller.getUserProfile();
              Navigator.pop(context);
            }else{
              Fluttertoast.showToast(msg: verify2faCodeAPIRes.message,toastLength:Toast.LENGTH_LONG,timeInSecForIosWeb: 5);
            }
          },
        ),
      );
    } else {
      if (showLoader) DialogBuilder(context).hideOpenDialog();
      Fluttertoast.showToast(msg: send2faCodeAPIRes.message,toastLength:Toast.LENGTH_LONG,timeInSecForIosWeb: 5);
    }
  }
}

class OtpDialog extends StatefulWidget {
  final Function(String otp) onSubmit;

  const OtpDialog({Key key, this.onSubmit}) : super(key: key);

  @override
  _OtpDialogState createState() => _OtpDialogState();
}

class _OtpDialogState extends State<OtpDialog> {
  final TextEditingController _otpController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(Strings.twoFactorAuthentication,style: TextStyle(fontSize: 16,fontWeight: FontWeight.w800),),

      content: /*TextField(
        controller: _otpController,
        keyboardType: TextInputType.number,
        maxLength: 6,
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
        ],
        decoration: InputDecoration(hintText: 'Enter OTP'),
      )*/
      Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(Strings.verificationCodeSentToYourRegisteredEmail,style: TextStyle(fontSize: 14,),),
          SizedBox(height: 20,),
          PinCodeTextField(
            controller: _otpController,
            length: 6,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            obscureText: false,
            keyboardType: TextInputType.number,
            appContext: context,
            autoFocus: true,


          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text(Strings.cancel),
        ),
        TextButton(
          onPressed: () {
            widget.onSubmit(_otpController.text);
          },
          child: Text(Strings.submit),
        ),
      ],
    );
  }
}
