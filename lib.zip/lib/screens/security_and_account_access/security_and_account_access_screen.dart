import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/screens/notifications/filters_screen.dart';
import 'package:werfieapp/screens/notifications/notification_prefrences_screen.dart';
import 'package:werfieapp/screens/security_and_account_access/security_screen.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../network/controller/NotificationsSettingsController.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../network/controller/update_daily_digest_api.dart';
import '../../utils/font.dart';

class SecurityAndAccountAccessScreen extends StatefulWidget {
  SecurityAndAccountAccessScreen({Key key}) : super(key: key);

  @override
  State<SecurityAndAccountAccessScreen> createState() => _SecurityAndAccountAccessScreenState();
}

class _SecurityAndAccountAccessScreenState extends State<SecurityAndAccountAccessScreen> {
  final controller = Get.find<NewsfeedController>();
  final storage = GetStorage();

  @override
  void initState() {

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    centerTitle: true,
                    title: Text(
                      Strings.securityAndAccountAccess,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 20,
                      ),
                    ),
                    leading: !kIsWeb
                        ? MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                                onTap: () {
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isTranslations = false;
                                  controller.isLanguageSettings = true;
                                  controller.isLanguageType = false;
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isNotificationsSettings = false;
                                  if (!kIsWeb) {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    Navigator.of(context).pop();
                                  }
                                  controller.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                          )
                        : SizedBox(),
                  )
                : PreferredSize(
                    child: Container(),
                    preferredSize: Size(0, 0),
                  ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 12,
                            ),
                            child: Row(
                              children: [
                                MediaQuery.of(context).size.width >= 1050
                                    ? SizedBox()
                                    : MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () {
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isTranslations = false;
                                            controller.isLanguageSettings =
                                                true;
                                            controller.isSettingDetail = true;
                                            controller.isSettingTypeDetail =
                                                false;
                                            controller.isLanguageType = false;
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isChangeUserName = false;
                                            controller.isYourAccount = false;
                                            controller.isNotificationsSettings =
                                                false;

                                            controller.update();
                                          },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                          ),
                                        ),
                                      ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      Strings.securityAndAccountAccess,
                                      textAlign: TextAlign.left,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    kIsWeb
                        ? Container(
                            height: 1,
                            color: Colors.grey[300],
                          )
                        : SizedBox(),
                    ListTile(
                      leading: Icon(Icons.lock_outline_rounded,size: 30,color: Colors.black,),
                      title: Text(
                        Strings.security,
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.manageYourAccountsSecurity,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      trailing: Icon(Icons.arrow_forward_ios_rounded,
                          color: Colors.black),
                      onTap: () {
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isChangeUserName = false;
                        controller.isYourAccount = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isAccountInformation = false;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isNotificationsSettings = false;
                        controller.isNotificationsFiltersScreen = false;
                        controller.isSecurityAndAccountAccess = false;
                        controller.isSecurity = true;
                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        SecurityScreen()))
                            : Container();
                      },
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    /*ListTile(
                      leading: Icon(
                        Icons.copy,
                        size: 30,
                        color: Theme.of(context).brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                      title: Text(
                        "Apps and sessions",
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        "See information when you logged into your account.",
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      trailing: Icon(Icons.arrow_forward_ios_rounded,
                          color: Colors.black),
                      onTap: (){
                       *//* controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isChangeUserName = false;
                        controller.isYourAccount = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isAccountInformation = false;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isNotificationsSettings = false;
                        controller.isNotificationsFiltersScreen = false;
                        controller.isNotificationPreferencesScreen = false;
                        controller.isSecurityAndAccountAccess = false;
                        controller.isSecurity = false;
                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    NotificationPreferencesScreen()))
                            : Container();*//*
                      },
                    ),*/
                  ],
                ),
              ),
            ));
      },
    );
  }

}
