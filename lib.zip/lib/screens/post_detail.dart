import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:universal_html/html.dart' as html;
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/category.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/mobile_comments_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/network/controller/saved_post_controller.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/widgets/chewie_videoplayer.dart';
import 'package:werfieapp/widgets/comments_screen.dart';
import 'package:werfieapp/widgets/newsfeed_carousel.dart';
import 'package:werfieapp/widgets/polls.dart';
import 'package:werfieapp/widgets/post_text_description.dart';
import 'package:werfieapp/widgets/react_retweet_dialog.dart';

import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import 'other_users_profile.dart';

class PostDetail extends StatelessWidget {
  final NewsfeedController controller;
  final Post post;

  const PostDetail({Key key, this.controller, this.post}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: PostDetailClass(post),
        tablet: PostDetailClass(post),
        desktop: PostDetailClass(post),
      ),
    );
  }
}

class PostDetailClass extends StatelessWidget {
  final Post post;

  PostDetailClass(this.post);

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    // print(post);
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return Scaffold(
        appBar: !kIsWeb
            ? AppBar(
          backgroundColor: Colors.black,
          elevation: 0,
          iconTheme: IconThemeData(
            color: Colors.blue,
          ),
          title: Text(
            Strings.werf,
            // style: TextStyle(color: Colors.black),
            style: Styles.baseTextTheme.headline2.copyWith(
              color: Theme
                  .of(context)
                  .brightness == Brightness.dark ? Colors.white : Colors.black,
              fontWeight: FontWeight.bold,
            ),
          ),
        )
            : PreferredSize(child: Container(), preferredSize: Size(0, 0)),
        body: SingleChildScrollView(
          child:
          kIsWeb ? Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15.0),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      // splashColor: Colors.white,
                      // hoverColor: Colors.grey[100],
                      icon: Icon(
                        Icons.arrow_back,
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.white : Colors
                            .black,
                      ),
                      onPressed: kIsWeb ?
                      controller.fromNotificationsScreen
                          ? () {
                        controller.isPostDetails = false;
                        controller.isNewsFeedScreen = true;
                        controller.fromNotificationsScreen = false;
                        controller.isProfileScreen = false;
                        controller.getCommentsList = [];
                        controller.commentController.clear();
                        controller.update();
                        Navigator.of(context).pop();
                      }
                          : () async {



                        // if(SingleTone.instance.commentId==1){
                        //   Get.back();
                        //
                        // }
                        // Get.back();


                        controller.isPostDetails = false;


                        switch (controller.navRoute) {
                          case "isNewsFeedScreen":
                            {
                              if (Get.isRegistered<MobileCommentsController>()) {
                                Get.delete<MobileCommentsController>();
                              }
                              controller.getCommentsList = [];
                              onHomeChange = true;
                              controller.isNewsFeedScreen = true;
                              controller.isPostDetails = false;
                              controller.isHiddenReplay= false;
                              controller.navRoute = "isNewsFeedScreen";
                              controller.searchText.text = '';
                              controller.isComingBackFromPostDetail = true;
                              // controller.getNewsFeed(reload: false,isLoading:true);
                              // controller.postList = await controller.getNewsFeed(reload: false);


                              controller.postList.forEach((element) {
                                controller.threadNumber = element.thread_no;
                                element.rebuzz.value = element.isRetweeted;
                                element.likeCount.value = element.simpleLikeCount;
                                element.rebuzzCount.value = element.retweetCount;
                                element.commentCount.value = element.commentsCount;
                                element.reactionType.value = element.isLiked;
                                element.reactionType.refresh();

                              });
                              controller.update();
                              // Get.back();
                              // Navigator.of(context).pop();
                            }
                            break;



                          case "isOtherUserScreen":
                            {
                              controller.isPostDetails = false;
                              controller.isOtherUserProfileScreen = true;

                            }
                            break;
                          case "isTrendsScreen":
                            {
                              onTrendsChange = true;
                              controller.isTrendsScreen = true;
                              controller.update();
                            }
                            break;

                          case "isQuestScreen":
                            {
                              onBrowsChange = true;
                              controller.isBrowseScreen = true;
                              controller.update();
                            }
                            break;

                          case "isSavedPostScreen":
                            {
                              controller.isSavedPostScreen = true;
                              controller.update();
                            }
                            break;
                          case "isNotificationScreen":
                            {
                              onTrendsChange = true;
                              controller.isTrendsScreen = true;
                              controller.update();
                            }
                            break;
                          case "isChatScreen":
                            {
                              onChatsChange = true;
                              controller.isNotificationScreen =
                              true;
                              controller.update();
                            }
                            break;


                          default:
                            {
                              controller.isProfileScreen = false;
                              controller.isPostDetails= false;
                              controller.isOtherUserProfileScreen = false;
                              controller.isNewsFeedScreen = true;
                              controller.update();
                              // Get.back();

                              print("Invalid choice");
                            }
                            break;
                        }
                        int counter = controller.detailPageCounter;
                        controller.detailPageCounter = 0;
                        if (counter == 0) {
                          Get.back();
                        } else {
                          for (int i = 0; i < counter; i++) {
                            print("counter: " + i.toString());
                            Get.back();
                          }
                        }


// Get.back();


                        // Get.offNamed(FluroRouters.mainScreen);


                        // Navigator.of(context).pop();
                        //           controller.update();

                      }
                          : () {
                        controller.commentController.clear();
                        controller.update();
                        Navigator.of(context).pop();
                      },
                    ),
                    SizedBox(width: 30),
                    Text(Strings.werf,
                      // style: TextStyle(fontSize: Get.width / 50)
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.white : Colors
                            .black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                controller.threadNumber == null ?
                CommentsScreen(thread_no: null, postId: controller.postId,) :
                CommentsScreen(thread_no: controller.threadNumber, postId: null,)
                //  PostDetailCard(
                //    post: post,
                //    scaffoldKey: _scaffoldKey,
                //    controller: controller,
                //  )
              ],
            ),
          ) : SizedBox(),
        ),
      );
    });
  }

  Future<bool> _onBackPressed(NewsfeedController controller,
      BuildContext context) async {
    kIsWeb ?

    controller.fromNotificationsScreen
        ? () {
      controller.isPostDetails = false;
      controller.isNewsFeedScreen = true;
      controller.fromNotificationsScreen = false;
      controller.isProfileScreen = false;
      controller.getCommentsList = [];
      controller.commentController.clear();
      controller.update();
      Navigator.of(context).pop();
    }
        : () async {
      Get.back();

      Get.back();
      // if(SingleTone.instance.commentId==1){
      //   Get.back();
      //
      // }

      print("back called");
      controller.isPostDetails = false;


      switch (controller.navRoute) {
        case "isNewsFeedScreen":
          {
            controller.getCommentsList = [];

            onHomeChange = true;


            controller.isNewsFeedScreen = true;

            controller.isPostDetails = false;

            controller.navRoute = "isNewsFeedScreen";
            controller.searchText.text = '';
            controller.getNewsFeed(reload: false, isLoading: true);
            // controller.postList = await controller.getNewsFeed(reload: false);


            controller.
            postList.forEach((element) {
              // print('first screen2');
              controller.threadNumber = element.thread_no;


              element.rebuzz.value = element.isRetweeted;
              element.likeCount.value = element.simpleLikeCount;
              element.rebuzzCount.value = element.retweetCount;
              element.commentCount.value = element.commentsCount;
              element.reactionType.value = element.isLiked;

              // element.comments.forEach((element) {
              //   element.reactionType.value = element.isLiked;
              //   element.commentCount.value = element.simpleLikeCount;
              // });

              // controller.getNewsFeed(reload: false,isLoading:true);
              // controller.postList.forEach((element) {
              //   print('first screen2');
              //   controller.threadNumber = element.thread_no;
              //
              //
              //   element.rebuzz.value   = element.isRetweeted;
              //   element.likeCount.value = element.simpleLikeCount;
              //   element.rebuzzCount.value = element.retweetCount;
              //   element.commentCount.value = element.commentsCount;
              //   element.reactionType.value = element.isLiked;
              //
              //   element.comments.forEach((element) {
              //     element.reactionType.value = element.isLiked;
              //     element.commentCount.value = element.simpleLikeCount;
              //   });
              //
              //   element.reactionType.refresh();
              //   // if (element.isLiked == nul) {
              //   //   element.like.value = true;
              //   //
              //   // }
              // });


              element.reactionType.refresh();
              // if (element.isLiked == nul) {
              //   element.like.value = true;
              //
              // }
            });
            print(controller.isPostDetails.toString() + "  postdetailvalue");
            controller.update();

            // Navigator.of(context).pop();
          }
          break;

        case "isTrendsScreen":
          {
            onTrendsChange = true;
            controller.isTrendsScreen = true;
            controller.update();
          }
          break;

        case "isQuestScreen":
          {
            onBrowsChange = true;
            controller.isBrowseScreen = true;
            controller.update();
          }
          break;

        case "isSavedPostScreen":
          {
            controller.isSavedPostScreen = true;
            controller.update();
          }
          break;
        case "isNotificationScreen":
          {
            onTrendsChange = true;
            controller.isTrendsScreen = true;
            controller.update();
          }
          break;
        case "isChatScreen":
          {
            onChatsChange = true;
            controller.isNotificationScreen =
            true;
            controller.update();
          }
          break;

        default:
          {
            controller.isProfileScreen = false;
            controller.isOtherUserProfileScreen = false;
            controller.update();
            print("Invalid choice");
          }
          break;
      }
      // Get.offNamed(FluroRouters.mainScreen);


      // Navigator.of(context).pop();
      //           controller.update();

    }
        : () {
      controller.commentController.clear();
      controller.update();
      Navigator.of(context).pop();
    };
    return Future.value(true);
  }
}

// ignore: must_be_immutable
class PostDetailCard extends StatelessWidget {
  final Post post;
  final NewsfeedController controller;
  final GlobalKey<ScaffoldState> scaffoldKey;
  final SavedPostController savedController;
  final BrowseController browseController;

  PostDetailCard({
    @required this.post,
    this.scaffoldKey,
    @required this.controller,
    this.savedController,
    this.browseController,
  });

  final commentTextController = TextEditingController();

  var isLiked = false;

  // var isCommentField = false;
  // var isRetweetSuccess = false;

  @override
  Widget build(BuildContext context) {
    var dateTime =
    DateFormat("yyyy-MM-dd HH:mm:ss").parse(post.postedOn.toString(), true);

    String dateLocal = dateTime.toLocal().toString();
    dateLocal = dateLocal.toString().split('.')[0].toString();

    print('Date Local  ' + dateLocal.toString());
    print('print post details card run');
    return Container(
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[200]),
          borderRadius: BorderRadius.circular(8.0)),
      margin: EdgeInsets.only(bottom: 20, left: 10, right: 10),
      child: ListTile(
        horizontalTitleGap: 20,
        contentPadding: EdgeInsets.symmetric(
          horizontal: 8,
          vertical: 0,
        ),
        title: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: post != null
                              ? post.profileImage != null
                              ? NetworkImage(post.profileImage)
                              : AssetImage(
                              "assets/images/person_placeholder.png")
                              : AssetImage(
                              "assets/images/person_placeholder.png"),
                          radius: 22,
                        ),
                        SizedBox(width: 15),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                InkWell(
                                  onTap: () {
                                    if (kIsWeb) {
                                      if (GetStorage().read('id') ==
                                          post.authorId) {
                                        controller.isTrendsScreen = false;
                                        controller.isNewsFeedScreen = false;
                                        controller.isBrowseScreen = false;
                                        controller.isNotificationScreen = false;
                                        controller.isChatScreen = false;
                                        controller.isSavedPostScreen = false;
                                        controller.isPostDetails = false;
                                        controller.isProfileScreen = true;
                                        controller.isOtherUserProfileScreen =
                                        false;
                                        controller.update();
                                      } else {
                                        controller.isTrendsScreen = false;
                                        controller.isNewsFeedScreen = false;
                                        controller.isBrowseScreen = false;
                                        controller.isNotificationScreen = false;
                                        controller.isChatScreen = false;
                                        controller.isSavedPostScreen = false;
                                        controller.isPostDetails = false;
                                        controller.isProfileScreen = false;
                                        controller.isOtherUserProfileScreen =
                                        true;
                                        if (Get.isRegistered<
                                            OtherUserController>()) {
                                          Get.delete<OtherUserController>();
                                        }
                                        controller.otherUserName =
                                            post.username;
                                        controller.otherUserId = post.authorId;

                                        controller.update();
                                      }
                                    } else {
                                      if (GetStorage().read('id') ==
                                          post.authorId) {
                                        controller.isTrendsScreen = false;
                                        controller.isNewsFeedScreen = false;
                                        controller.isBrowseScreen = false;
                                        controller.isNotificationScreen = false;
                                        controller.isChatScreen = false;
                                        controller.isSavedPostScreen = false;
                                        controller.isPostDetails = false;
                                        controller.isProfileScreen = true;
                                        controller.isOtherUserProfileScreen =
                                        false;
                                        controller.update();
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                    ProfileScreen(
                                                        controller:
                                                        controller)));
                                      } else {
                                        controller.otherUserName =
                                            post.username;
                                        controller.otherUserId = post.authorId;
                                        controller.update();
                                        if (Get.isRegistered<
                                            OtherUserController>()) {
                                          Get.delete<OtherUserController>();
                                        }
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                    OtherUsersProfile(
                                                      controller:
                                                      controller,
                                                    )));
                                      }
                                    }
                                  },
                                  child: Text(
                                    post.authorName == null
                                        ? ""
                                        : post.authorName,
                                    style: Styles.baseTextTheme.headline2
                                        .copyWith(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 14,
                                    ),
                                    // style: Theme.of(context)
                                    //     .textTheme
                                    //     .bodyText1
                                    //     .copyWith(
                                    //         color: Colors.black,
                                    //         fontWeight: FontWeight.bold),
                                  ),
                                ),
                                // SizedBox(width: 8),
                                // kIsWeb
                                //     ? Text(
                                //         Strings.postedUpdate,
                                //         style: Theme.of(context)
                                //             .textTheme
                                //             .bodyText2
                                //             .copyWith(color: Colors.black),
                                //       )
                                //     : SizedBox(),
                              ],
                            ),
                            Text(
                              post.username != null ? '@${post.username}' : "",
                              // style: Theme.of(context)
                              //     .textTheme
                              //     .bodyText2
                              //     .copyWith(color: Colors.black),
                              style: Styles.baseTextTheme.headline2.copyWith(
                                fontSize: kIsWeb ? 14 : 12,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    VerticalDivider(
                      color: Colors.red,
                      thickness: 12,
                      width: 22,
                    ),
                  ],
                ),
                controller.isNewsFeedScreen == true
                    ? myPopMenu(context, scaffoldKey, post, controller)
                    : controller.isSavedPostScreen == true
                    ? sharePopMenu(context, scaffoldKey, post, controller)
                    : controller.isBrowseScreen == true
                    ? myPopMenu(context, scaffoldKey, post, controller)
                    : SizedBox(),
              ],
            ),
            Padding(
              padding: EdgeInsets.only(


                top: 0.0,
                // left: Get.width / 35,
                left: 50,
                right: Get.width / 4.5,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  post.body != null
                      ? Padding(
                    padding: const EdgeInsets.only(top: 15.0, left: 0),
                    child: Container(
                      child: PostTextDescription(
                        post: post,
                        controller: controller,
                      ),
                    ),
                  )
                      : Container(),
                  post.body != null
                      ? post.link != null
                      ? GestureDetector(
                    onTap: () async {
                      if (await canLaunch(post.link.toString())) {
                        await launch(post.link.toString());
                      } else {
                        await launch(
                            'https://${post.link.toString()}');
                      }
                      // await launch(post.link.toString());
                      // await ifcanLaunch(post.link.toString())
                      //     ? await launch(post.link.toString())
                      //     : ;
                    },
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 2,
                      child: Column(
                        children: [
                          Container(
                            height: kIsWeb
                                ? Get.height / 2.1
                                : Get.height / 4.5,
                            width: Get.width,

                            // color: Colors.black,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                topRight: Radius.circular(15),),
                              color: Colors.black,
                              image: DecorationImage(
                                  image: post.linkImage != null
                                      ? NetworkImage(
                                      post.linkImage.toString())
                                      : AssetImage(
                                      "assets/images/no_image.jpeg"),
                                  fit: BoxFit.contain),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 5,
                              left: 20,
                              right: 20,
                            ),
                            child: Text(
                              post.linkTitle.toString(),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                              // style: TextStyle(
                              //   color: Colors.black,
                              //   fontFamily: 'Cairo',
                              //   fontSize: 17,
                              //   fontWeight: FontWeight.w500,
                              // )
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          post.linkMeta == null
                              ? SizedBox()
                              : Padding(
                            padding: const EdgeInsets.only(
                                top: 0, left: 20, right: 20),
                            child: Text(
                              post.linkMeta.toString(),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              // style: TextStyle(
                              //   color: Colors.black,
                              //   fontFamily: 'Cairo',
                              //   fontSize: 16,
                              //   fontWeight: FontWeight.w500,
                              // ),
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 0,
                                left: 20,
                                right: 20,
                                bottom: 10),
                            child: Text(post.link.toString(),
                              textAlign: TextAlign.left,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              // style: TextStyle(
                              //   color: Colors.grey[700],
                              //   fontFamily: 'Cairo',
                              //   fontSize: 14,
                              //   fontWeight: FontWeight.w400,
                              // )
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                      : SizedBox()
                      : SizedBox(),
                  SizedBox(
                    height: 12,
                  ),
                  post.type == 'poll'
                      ? Polls(post: post, controller: controller)
                      : SizedBox(),

                  post.postType == 'image' && post.postFiles.length > 0
                      ? ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: InkWell(
                      onTap: () {
                        controller.mapToList(post);
                        showDialog(
                          barrierDismissible: false,
                          context: context,
                          builder: (BuildContext context) {
                            return NewsFeedCarousel(
                              imagesListForCarousel: controller
                                  .imagesListForCarousel,
                              mediaIndex: 0,
                            );
                          },
                        );
                      },
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          maxHeight: kIsWeb ? 650 : 500,
                          maxWidth: Get.width,
                          minHeight: kIsWeb ? 284 : 200,
                          minWidth: Get.width,
                        ),
                        child: Image.network(
                          post.postFiles[0]['file_path'],
                          fit: BoxFit.cover,
                          // width: Get.width,
                        ),
                      ),
                    ),
                  )
                      : post.postType == 'gallery' &&
                      post.postFiles.length == 2 &&
                      post.postFiles[0]['file_type'] == 'image'
                      ? StaggeredGridView.countBuilder(
                      crossAxisCount: 2,
                      crossAxisSpacing: 3,
                      mainAxisSpacing: 3,
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: post.postFiles.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            controller.mapToList(post);
                            showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return NewsFeedCarousel(
                                  imagesListForCarousel:
                                  controller.imagesListForCarousel,
                                  mediaIndex: index,
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.all(
                                    Radius.circular(15))),
                            child: ClipRRect(
                              borderRadius:
                              BorderRadius.all(Radius.circular(15)),
                              child: Image.network(
                                post.postFiles[index]['file_path'],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                      staggeredTileBuilder: (index) {
                        return StaggeredTile.count(
                            1, index.isEven ? 0.88 : 0.88);
                      })
                      : post.postType == 'gallery' &&
                      post.postFiles.length == 3 &&
                      post.postFiles[0]['file_type'] == 'image'
                      ? StaggeredGridView.countBuilder(
                      crossAxisCount: 2,
                      crossAxisSpacing: 3,
                      mainAxisSpacing: 3,
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: post.postFiles.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            controller.mapToList(post);
                            showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return NewsFeedCarousel(
                                  imagesListForCarousel: controller
                                      .imagesListForCarousel,
                                  mediaIndex: index,
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.all(
                                    Radius.circular(15))),
                            child: ClipRRect(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(15)),
                              child: Image.network(
                                post.postFiles[index]['file_path'],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                      staggeredTileBuilder: (index) {
                        return StaggeredTile.count(
                            1, index == 0 ? 1 : 0.5);
                      })
                      : post.postType == 'gallery' &&
                      post.postFiles.length == 4 &&
                      post.postFiles[0]['file_type'] == 'image'
                      ? StaggeredGridView.countBuilder(
                      crossAxisCount: 2,
                      crossAxisSpacing: 3,
                      mainAxisSpacing: 3,
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: post.postFiles.length,
                      itemBuilder: (context, index) {
                        return InkWell(
                          onTap: () {
                            controller.mapToList(post);
                            showDialog(
                              barrierDismissible: false,
                              context: context,
                              builder: (BuildContext context) {
                                return NewsFeedCarousel(
                                  imagesListForCarousel:
                                  controller
                                      .imagesListForCarousel,
                                  mediaIndex: index,
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors.transparent,
                                borderRadius: BorderRadius.all(
                                    Radius.circular(15))),
                            child: ClipRRect(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(15)),
                              child: Image.network(
                                post.postFiles[index]
                                ['file_path'],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                      staggeredTileBuilder: (index) {
                        return StaggeredTile.count(
                            1, index.isEven ? 0.6 : 0.6);
                      })
                      : post.postType == 'gallery' &&
                      post.postFiles.length > 4 &&
                      post.postFiles[0]['file_type'] ==
                          'image'
                      ? StaggeredGridView.countBuilder(
                      crossAxisCount: 2,
                      crossAxisSpacing: 3,
                      mainAxisSpacing: 3,
                      shrinkWrap: true,
                      physics: ScrollPhysics(),
                      itemCount: post.postFiles.length >= 5
                          ? 4
                          : post.postFiles.length,
                      itemBuilder: (context, index) {
                        return post.postFiles.length >= 5 &&
                            index == 3
                            ? InkWell(
                          onTap: () {
                            controller
                                .mapToList(post);
                            showDialog(
                              barrierDismissible:
                              false,
                              context: context,
                              builder: (BuildContext
                              context) {
                                return NewsFeedCarousel(
                                  imagesListForCarousel:
                                  controller
                                      .imagesListForCarousel,
                                  mediaIndex: index,
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors
                                    .transparent,
                                borderRadius:
                                BorderRadius.all(
                                    Radius
                                        .circular(
                                        15))),
                            child: ClipRRect(
                              borderRadius:
                              BorderRadius.all(
                                  Radius.circular(
                                      15)),
                              child: Stack(
                                fit: StackFit.expand,
                                children: [
                                  Image.network(
                                    post.postFiles[
                                    index]
                                    ['file_path'],
                                    fit: BoxFit.cover,
                                  ),
                                  if (post.postFiles.length >= 5)
                                    Container(color: Colors.black38,),
                                  if (post.postFiles.length >= 5)
                                    Align(alignment:
                                    Alignment.center,
                                      child: Text(
                                        '+${post.postFiles.length - 4}',
                                        // style: Theme.of(
                                        //         context)
                                        //     .textTheme
                                        //     .headline3
                                        //     .copyWith(
                                        //       color: Colors
                                        //           .white,
                                        //       fontSize:
                                        //           24,
                                        //     ),
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        )
                            : InkWell(
                          onTap: () {
                            controller
                                .mapToList(post);
                            showDialog(
                              barrierDismissible:
                              false,
                              context: context,
                              builder: (BuildContext
                              context) {
                                return NewsFeedCarousel(
                                  imagesListForCarousel:
                                  controller
                                      .imagesListForCarousel,
                                  mediaIndex: index,
                                );
                              },
                            );
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors
                                    .transparent,
                                borderRadius:
                                BorderRadius.all(
                                    Radius
                                        .circular(
                                        15))),
                            child: ClipRRect(
                              borderRadius:
                              BorderRadius.all(
                                  Radius.circular(
                                      8)),
                              child: Image.network(
                                post.postFiles[index]
                                ['file_path'],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                        );
                      },
                      staggeredTileBuilder: (index) {
                        return StaggeredTile.count(
                            1, index.isEven ? 0.6 : 0.6);
                      })
                      : post.postType == 'video' &&
                      post.postFiles.length == 1
                      ? ChewieVideoPlayer(
                    post: post,
                    index: 0,
                    thumbnailUrl: post.postFiles[0]
                    ['thumbnail_path'] !=
                        null
                        ? post.postFiles[0]
                    ['thumbnail_path']
                        : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                  )
                  // ? StaggeredGridView.countBuilder(
                  //     crossAxisCount: 1,
                  //     crossAxisSpacing: 3,
                  //     mainAxisSpacing: 3,
                  //     shrinkWrap: true,
                  //     physics: ScrollPhysics(),
                  //     itemCount: post.postFiles.length,
                  //     itemBuilder: (context, index) {
                  //       return InkWell(
                  //         onTap: () {
                  // mapToList(
                  //     imagesListForCarousel, post);
                  // showDialog(
                  //   context: context,
                  //   builder: (BuildContext context) {
                  //     return NewsFeedCarousel(
                  //       imagesListForCarousel:
                  //           imagesListForCarousel,
                  //       imageIndex: index,
                  //     );
                  //   },
                  // );
                  //     },
                  //     child: Container(
                  //       decoration: BoxDecoration(
                  //           color:
                  //               Colors.transparent,
                  //           borderRadius:
                  //               BorderRadius.all(
                  //                   Radius.circular(
                  //                       8))),
                  //       child: ClipRRect(
                  //         borderRadius:
                  //             BorderRadius.all(
                  //                 Radius.circular(
                  //                     8)),
                  //         child: CustomVideoPlayer(
                  //           videoUrl: post
                  //                   .postFiles[
                  //               index]['file_path'],
                  //         ),
                  //       ),
                  //     ),
                  //   );
                  // },
                  // staggeredTileBuilder: (index) {
                  //   return StaggeredTile.count(
                  //       1, index == 0 ? 1 : 0.5);
                  // })
                  // : post.postType == 'gallery' &&
                  //         post.postFiles.length == 2 &&
                  //         post.postFiles[0]
                  //                 ['file_type'] ==
                  //             'video'
                  //     ? StaggeredGridView.countBuilder(
                  //         crossAxisCount: 2,
                  //         crossAxisSpacing: 3,
                  //         mainAxisSpacing: 3,
                  //         shrinkWrap: true,
                  //         physics: ScrollPhysics(),
                  //         itemCount:
                  //             post.postFiles.length,
                  //         itemBuilder:
                  //             (context, index) {
                  //           return InkWell(
                  //             onTap: () {
                  //               // mapToList(
                  //               //     imagesListForCarousel, post);
                  //               // showDialog(
                  //               //   context: context,
                  //               //   builder: (BuildContext context) {
                  //               //     return NewsFeedCarousel(
                  //               //       imagesListForCarousel:
                  //               //           imagesListForCarousel,
                  //               //       imageIndex: index,
                  //               //     );
                  //               //   },
                  //               // );
                  //             },
                  //             child: ChewieVideoPlayer(
                  //                 post: post,
                  //                 index: index),
                  //           );
                  //         },
                  //         staggeredTileBuilder:
                  //             (index) {
                  //           return StaggeredTile.count(
                  //               1, 1);
                  //         })
                  //     : post.postType == 'gallery' &&
                  //             post.postFiles.length ==
                  //                 3 &&
                  //             post.postFiles[0]
                  //                     ['file_type'] ==
                  //                 'video'
                  //         ? StaggeredGridView
                  //             .countBuilder(
                  //                 crossAxisCount: 2,
                  //                 crossAxisSpacing: 3,
                  //                 mainAxisSpacing: 3,
                  //                 shrinkWrap: true,
                  //                 physics:
                  //                     ScrollPhysics(),
                  //                 itemCount: post
                  //                     .postFiles.length,
                  //                 itemBuilder:
                  //                     (context, index) {
                  //                   return InkWell(
                  //                     onTap: () {
                  //                       // mapToList(
                  //                       //     imagesListForCarousel, post);
                  //                       // showDialog(
                  //                       //   context: context,
                  //                       //   builder: (BuildContext context) {
                  //                       //     return NewsFeedCarousel(
                  //                       //       imagesListForCarousel:
                  //                       //           imagesListForCarousel,
                  //                       //       imageIndex: index,
                  //                       //     );
                  //                       //   },
                  //                       // );
                  //                     },
                  //                     child:
                  //                         ChewieVideoPlayer(
                  //                             post:
                  //                                 post,
                  //                             index:
                  //                                 index),
                  //                   );
                  //                 },
                  //                 staggeredTileBuilder:
                  //                     (index) {
                  //                   return StaggeredTile
                  //                       .count(
                  //                           1,
                  //                           index == 0
                  //                               ? 1
                  //                               : 0.5);
                  //                 })
                  //         : post.postType == 'gallery' &&
                  //                 post.postFiles
                  //                         .length ==
                  //                     4 &&
                  //                 post.postFiles[0][
                  //                         'file_type'] ==
                  //                     'video'
                  //             ? StaggeredGridView.countBuilder(
                  //                 crossAxisCount: 2,
                  //                 crossAxisSpacing: 3,
                  //                 mainAxisSpacing: 3,
                  //                 shrinkWrap: true,
                  //                 physics: ScrollPhysics(),
                  //                 itemCount: post.postFiles.length,
                  //                 itemBuilder: (context, index) {
                  //                   return InkWell(
                  //                     onTap: () {
                  //                       // mapToList(
                  //                       //     imagesListForCarousel, post);
                  //                       // showDialog(
                  //                       //   context: context,
                  //                       //   builder: (BuildContext context) {
                  //                       //     return NewsFeedCarousel(
                  //                       //       imagesListForCarousel:
                  //                       //           imagesListForCarousel,
                  //                       //       imageIndex: index,
                  //                       //     );
                  //                       //   },
                  //                       // );
                  //                     },
                  //                     child:
                  //                         ChewieVideoPlayer(
                  //                             post:
                  //                                 post,
                  //                             index:
                  //                                 index),
                  //                   );
                  //                 },
                  //                 staggeredTileBuilder: (index) {
                  //                   return StaggeredTile
                  //                       .count(1, 1);
                  //                 })
                  //             : post.postType == 'gallery' && post.postFiles.length > 4 && post.postFiles[0]['file_type'] == 'video'
                  //                 ? StaggeredGridView.countBuilder(
                  //                     crossAxisCount: 2,
                  //                     crossAxisSpacing: 3,
                  //                     mainAxisSpacing: 3,
                  //                     shrinkWrap: true,
                  //                     physics: ScrollPhysics(),
                  //                     itemCount: post.postFiles.length >= 5 ? 4 : post.postFiles.length,
                  //                     itemBuilder: (context, index) {
                  //                       return post.postFiles.length >=
                  //                                   5 &&
                  //                               index ==
                  //                                   3
                  //                           ? InkWell(
                  //                               onTap:
                  //                                   () {
                  //                                 controller
                  //                                     .maptoListForVideos(post);
                  //                                 showDialog(
                  //                                   barrierDismissible:
                  //                                       false,
                  //                                   context:
                  //                                       context,
                  //                                   builder:
                  //                                       (BuildContext context) {
                  //                                     return NewsFeedCarousel(
                  //                                       videoListForCarousel: controller.videoListForCarousel,
                  //                                       mediaIndex: index,
                  //                                     );
                  //                                   },
                  //                                 );
                  //                               },
                  //                               child:
                  //                                   Container(
                  //                                 decoration: BoxDecoration(
                  //                                     color: Colors.transparent,
                  //                                     borderRadius: BorderRadius.all(Radius.circular(15))),
                  //                                 child:
                  //                                     ClipRRect(
                  //                                   borderRadius:
                  //                                       BorderRadius.all(Radius.circular(8)),
                  //                                   child:
                  //                                       Stack(
                  //                                     fit: StackFit.expand,
                  //                                     children: [
                  //                                       ChewieVideoPlayer(post: post, index: index),
                  //                                       if (post.postFiles.length >= 5)
                  //                                         Container(
                  //                                           color: Colors.black38,
                  //                                         ),
                  //                                       if (post.postFiles.length >= 5)
                  //                                         Align(
                  //                                           alignment: Alignment.center,
                  //                                           child: Text(
                  //                                             '+${post.postFiles.length - 4}',
                  //                                             style: Theme.of(context).textTheme.headline3.copyWith(
                  //                                                   color: Colors.white,
                  //                                                   fontSize: 24,
                  //                                                 ),
                  //                                           ),
                  //                                         ),
                  //                                     ],
                  //                                   ),
                  //                                 ),
                  //                               ),
                  //                             )
                  //                           : InkWell(
                  //                               onTap:
                  //                                   () {
                  //                                 controller
                  //                                     .maptoListForVideos(post);
                  //                                 showDialog(
                  //                                   barrierDismissible:
                  //                                       false,
                  //                                   context:
                  //                                       context,
                  //                                   builder:
                  //                                       (BuildContext context) {
                  //                                     return NewsFeedCarousel(
                  //                                       videoListForCarousel: controller.videoListForCarousel,
                  //                                       mediaIndex: index,
                  //                                     );
                  //                                   },
                  //                                 );
                  //                               },
                  //                               child:
                  //                                   Container(
                  //                                 decoration: BoxDecoration(
                  //                                     color: Colors.transparent,
                  //                                     borderRadius: BorderRadius.all(Radius.circular(15))),
                  //                                 child:
                  //                                     ClipRRect(
                  //                                   borderRadius:
                  //                                       BorderRadius.all(Radius.circular(8)),
                  //                                   child:
                  //                                       CustomVideoPlayer(
                  //                                     videoUrl: post.postFiles[index]['file_path'],
                  //                                   ),
                  //                                 ),
                  //                               ),
                  //                             );
                  //                     },
                  //                     staggeredTileBuilder: (index) {
                  //                       return StaggeredTile.count(
                  //                           1,
                  //                           index.isEven
                  //                               ? 0.6
                  //                               : 0.6);
                  //                     })
                      : post.postType == 'attachment' &&
                      post.postFiles.length == 1
                      ? ListTile(
                    onTap: () {
                      launch(post.postFiles[0]
                      ['file_path']);
                    },
                    shape: RoundedRectangleBorder(
                        borderRadius:
                        BorderRadius.circular(
                            15)),
                    tileColor: Colors.grey[100],
                    leading: SizedBox(
                      height: 28,
                      width: 28,
                      child: Image.asset(
                          'assets/images/document.png'),
                    ),
                    title: Text(
                      post.postFiles[0]
                      ['original_name'],
                      style: Theme
                          .of(context)
                          .brightness == Brightness.dark ?
                      TextStyle(color: Colors.white,

                      )
                          : TextStyle(color: Colors.black,

                      ),
                    ),
                  )
                      : post.postType == 'gallery' &&
                      post.postFiles.length >
                          1 &&
                      post.postFiles[0]
                      ['file_type'] ==
                          'attachment'
                      ? Column(
                    children: [
                      for (var i = 0;
                      i <
                          post.postFiles
                              .length;
                      i++)
                        ListTile(
                          onTap: () {
                            launch(post
                                .postFiles[0]
                            [
                            'file_path']);
                          },
                          shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius
                                  .circular(
                                  10)),
                          tileColor: Colors
                              .grey[100],
                          leading: SizedBox(
                              height: 28,
                              width: 28,
                              child: Image.asset(
                                  'assets/images/document.png')),
                          title: Text(
                            post.postFiles[i][
                            'original_name'],
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.w500,
                              fontSize: 14,
                            ),
                          ),
                        ),
                    ],
                  )
                      : Container(),
                  SizedBox(
                    height: 8.0,
                  ),
                  Text(
                    dateLocal,
                    // style: Theme.of(context).textTheme.bodyText2.copyWith(
                    //     fontSize: 12,
                    //     color: Colors.black,
                    //     fontWeight: FontWeight.w500),
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.white : Colors
                          .black,
                      fontWeight: FontWeight.bold,
                      // fontSize: 14,
                    ),
                  ),
                  SizedBox(
                    height: 8.0,
                  ),
                  post.type == 'quote' && post.quoteInfo != null
                      ? InkWell(
                    onTap: kIsWeb
                        ? () async {
                      controller.isPostDetails = true;
                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = false;
                      controller.isBrowseScreen = false;
                      controller.isNotificationScreen = false;
                      controller.isChatScreen = false;
                      controller.isSavedPostScreen = false;
                      if (controller.isSavedPostScreen) {
                        savedController.update();
                      }
                      if (controller.isBrowseScreen) {
                        browseController.update();
                      }
                      controller.selectedPost2 =
                      await controller.getSingleNewsFeedItem(
                          post.quoteInfo.postId);
                      controller.update();
                    }
                        : () async {
                      // controller.postDetail =
                      //     await controller.getSingleNewsFeedItem(post.postId);
                      // controller.update();
                      // Get.to(PostDetail(controller: controller, post: post));
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  CommentsScreen(
                                      postId:
                                      post.quoteInfo.postId)));
                      controller.postId = post.postId;
                      // controller.isPostDetails = true;
                      // controller.postDetail =
                      //     await controller.getSingleNewsFeedItem(post.postId);
                    },
                    child: Container(
                      // width: 610,
                      padding: EdgeInsets.symmetric(
                          horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Colors.grey[300],
                        ),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                mainAxisAlignment:
                                MainAxisAlignment.start,
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      //PROFILE IMAGE
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            top: 10.00),
                                        child: CircleAvatar(
                                          backgroundImage: post.quoteInfo
                                              .profileImage !=
                                              null
                                              ? NetworkImage(post
                                              .quoteInfo.profileImage)
                                              : AssetImage(
                                              "assets/images/person_placeholder.png"),
                                          radius: 22,
                                        ),
                                      ),
                                      SizedBox(width: 15),

                                      //USERNAME AND POST TIME
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            top: 6.0),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceBetween,
                                              crossAxisAlignment:
                                              CrossAxisAlignment
                                                  .start,
                                              children: [
                                                Text(
                                                  post.quoteInfo
                                                      .authorName,
                                                  // style: Theme.of(context)
                                                  //     .textTheme
                                                  //     .headline3,
                                                  style: Styles.baseTextTheme
                                                      .headline2.copyWith(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark ? Colors
                                                        .white : Colors.black,
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: 14,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Text(
                                              '@${post.quoteInfo.username}',
                                              // style: Theme.of(context)
                                              //     .textTheme
                                              //     .bodyText2
                                              //     .copyWith(height: 1.2),
                                              style: Styles.baseTextTheme
                                                  .headline2.copyWith(
                                                //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                //fontWeight: FontWeight.w500,
                                                fontSize: kIsWeb ? 14 : 12,
                                              ),
                                            ),
                                            SizedBox(height: 10),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              // POPUP MENU BUTTON
                            ],
                          ),
                          SizedBox(height: 2),
                          post.quoteInfo.body.length > 0
                              ? Padding(
                            padding:
                            MediaQuery
                                .of(context)
                                .size
                                .width >
                                720
                                ? EdgeInsets.only(left: 58)
                                : EdgeInsets.only(left: 10),
                            child: Align(
                                alignment: Alignment.topLeft,
                                child: Text(post.quoteInfo.body)),
                          )
                              : SizedBox(),
                          post.quoteInfo.postType == 'image' &&
                              post.quoteInfo.postFiles.length > 0
                              ? ClipRRect(
                            borderRadius:
                            BorderRadius.only(bottomLeft: Radius.circular(15),
                                bottomRight: Radius.circular(15)),
                            child: kIsWeb
                                ? ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: Get.width,
                                maxHeight: 650,
                                minHeight: 284,
                                minWidth: 384,
                              ),
                              child: Image.network(
                                post.quoteInfo.postFiles[0]['file_path'],
                                // height: kIsWeb ? 480 : 240,
                                fit: BoxFit.cover,
                                // width: Get.width,
                                errorBuilder: (BuildContext context,
                                    Object exception,
                                    StackTrace stackTrace) {
                                  return Icon(Icons.error,
                                      size: 40);
                                },
                              ),
                            )
                            // FutureBuilder<Widget>(
                            //   future: controller.getImage(  post.quoteInfo.postFiles[0]['file_path']),
                            //   builder: (context, snapshot) {
                            //     if (snapshot.hasData) {
                            //       return snapshot.data;
                            //     } else {
                            //       return Container(
                            //         height : kIsWeb ? 240 : 420,
                            //         width : Get.width,
                            //         child: Center(
                            //           child : CircularProgressIndicator(color: controller.displayColor,),
                            //         ),
                            //       );
                            //     }
                            //   },
                            // )
                                : ConstrainedBox(
                              constraints: BoxConstraints(
                                maxHeight: 500,
                                maxWidth: Get.width,
                                minHeight: 200,
                                minWidth: Get.width,
                              ),
                              child: Image.network(
                                post.quoteInfo.postFiles[0]['file_path'],
                                // height: kIsWeb ? 480 : 240,
                                fit: BoxFit.cover,
                                // width: Get.width,
                                errorBuilder: (BuildContext context,
                                    Object exception,
                                    StackTrace stackTrace) {
                                  return Icon(Icons.error,
                                      size: 40);
                                },
                              ),
                            ),
                            // Container(
                            //   height: kIsWeb ? 480 : 240,
                            //   width: Get.width,
                            //   color: Colors.grey[300],
                            //   child: Align(
                            //       alignment: Alignment.center,
                            //       child: Image.network(
                            //           post.quoteInfo.postFiles[0]
                            //               ['file_path'],
                            //           height: kIsWeb ? 480 : 240,
                            //           fit: BoxFit.cover,
                            //           width: Get.width)),
                            // ),
                          )
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length ==
                                  2 &&
                              post.quoteInfo.postFiles[0]
                              ['file_type'] ==
                                  'image'
                              ? StaggeredGridView.countBuilder(
                              crossAxisCount: 2,
                              crossAxisSpacing: 3,
                              mainAxisSpacing: 3,
                              shrinkWrap: true,
                              physics: ScrollPhysics(),
                              itemCount:
                              post.quoteInfo.postFiles.length,
                              itemBuilder: (context, index) {
                                return Container(
                                  height: 480,
                                  decoration: BoxDecoration(
                                      color: Colors.transparent,
                                      borderRadius:
                                      BorderRadius.all(
                                          Radius.circular(
                                              12))),
                                  child: ClipRRect(
                                    borderRadius:
                                    BorderRadius.all(
                                        Radius.circular(0)),
                                    child: Image.network(
                                      post.quoteInfo
                                          .postFiles[index]
                                      ['file_path'],
                                      fit: BoxFit.cover,
                                      height: 480,
                                    ),
                                  ),
                                );
                              },
                              staggeredTileBuilder: (index) {
                                return StaggeredTile.count(
                                    1, index.isEven ? 1 : 1);
                              })
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length ==
                                  3 &&
                              post.quoteInfo.postFiles[0]
                              ['file_type'] ==
                                  'image'
                              ? StaggeredGridView.countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: ScrollPhysics(),
                            itemCount: post
                                .quoteInfo.postFiles.length,
                            itemBuilder: (context, index) {
                              return Container(
                                decoration: BoxDecoration(
                                    color:
                                    Colors.transparent,
                                    borderRadius:
                                    BorderRadius.all(
                                        Radius.circular(
                                            12))),
                                child: ClipRRect(
                                  borderRadius:
                                  BorderRadius.all(
                                      Radius.circular(
                                          12)),
                                  child: Image.network(
                                    post.quoteInfo
                                        .postFiles[
                                    index]['file_path'],
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder: (index) {
                              return StaggeredTile.count(
                                  1, index == 0 ? 1 : 0.5);
                            },
                          )
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length ==
                                  4 &&
                              post.quoteInfo.postFiles[0]['file_type'] ==
                                  'image'
                              ? StaggeredGridView
                              .countBuilder(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3,
                            mainAxisSpacing: 3,
                            shrinkWrap: true,
                            physics: ScrollPhysics(),
                            itemCount: post.quoteInfo
                                .postFiles.length,
                            itemBuilder:
                                (context, index) {
                              return Container(
                                decoration: BoxDecoration(
                                    color: Colors
                                        .transparent,
                                    borderRadius:
                                    BorderRadius
                                        .all(Radius
                                        .circular(
                                        12))),
                                child: ClipRRect(
                                  borderRadius:
                                  BorderRadius.all(
                                      Radius
                                          .circular(
                                          12)),
                                  child: Image.network(
                                    post.quoteInfo
                                        .postFiles[
                                    index]
                                    ['file_path'],
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              );
                            },
                            staggeredTileBuilder:
                                (index) {
                              return StaggeredTile
                                  .count(
                                  1,
                                  index.isEven
                                      ? 0.6
                                      : 0.6);
                            },
                          )
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length >
                                  4 &&
                              post.quoteInfo.postFiles[0]
                              ['file_type'] ==
                                  'image'
                              ? StaggeredGridView
                              .countBuilder(
                              crossAxisCount: 2,
                              crossAxisSpacing: 3,
                              mainAxisSpacing: 3,
                              shrinkWrap: true,
                              physics:
                              ScrollPhysics(),
                              itemCount: post.quoteInfo.postFiles.length >= 5
                                  ? 4
                                  : post
                                  .quoteInfo
                                  .postFiles
                                  .length,
                              itemBuilder: (context, index) {
                                return post.quoteInfo.postFiles
                                    .length >=
                                    5 &&
                                    index == 3
                                    ? Container(
                                  decoration: BoxDecoration(
                                      color: Colors
                                          .transparent,
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(12))),
                                  child:
                                  ClipRRect(
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(12)),
                                    child: Image
                                        .network(
                                      post.quoteInfo.postFiles[index]
                                      [
                                      'file_path'],
                                      fit: BoxFit
                                          .cover,
                                    ),
                                  ),
                                )
                                    : Container(
                                  decoration: BoxDecoration(
                                      color: Colors
                                          .transparent,
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(15))),
                                  child:
                                  ClipRRect(
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(8)),
                                    child: Image
                                        .network(
                                      post.quoteInfo.postFiles[index]
                                      [
                                      'file_path'],
                                      fit: BoxFit
                                          .cover,
                                    ),
                                  ),
                                );
                              },
                              staggeredTileBuilder:
                                  (index) {
                                return StaggeredTile
                                    .count(
                                    1,
                                    index.isEven
                                        ? 0.6
                                        : 0.6);
                              })
                              : post.quoteInfo.postType == 'video' &&
                              post.quoteInfo.postFiles.length == 1
                              ? ChewieVideoPlayer(
                            quoteWerf:
                            post.quoteInfo,
                            isQuoteWerfPlayer:
                            true,
                            index: 0,
                            thumbnailUrl: post
                                .quoteInfo
                                .postFiles[0]
                            [
                            'thumbnail_path'] !=
                                null
                                ? post.quoteInfo
                                .postFiles[0]
                            [
                            'thumbnail_path']
                                : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                          )
                              : post.quoteInfo.postType == 'audio' &&
                              post.quoteInfo.postFiles.length == 1
                              ? ChewieVideoPlayer(
                            quoteWerf: post
                                .quoteInfo,
                            index: 0,
                            isAudio: true,
                          )
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length > 1 &&
                              post.quoteInfo.postFiles[0]['file_type'] ==
                                  'audio'
                              ? Column(
                            children: [
                              for (var i =
                              0;
                              i < post.quoteInfo.postFiles.length;
                              i++)
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(vertical: 4.0),
                                  child:
                                  ChewieVideoPlayer(
                                    quoteWerf:
                                    post.quoteInfo,
                                    index:
                                    i,
                                  ),
                                ),
                            ],
                          )
                              : post.quoteInfo.postType == 'attachment' &&
                              post.quoteInfo.postFiles.length == 1
                              ? ListTile(
                            onTap:
                                () {
                              launch(post
                                  .quoteInfo
                                  .postFiles[0]['file_path']);
                            },
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                BorderRadius.circular(10)),
                            tileColor:
                            Colors.grey[100],
                            leading:
                            SizedBox(
                              height:
                              28,
                              width:
                              28,
                              child:
                              Image.asset('assets/images/document.png'),
                            ),
                            title:
                            Text(
                              "${post.quoteInfo.postFiles[0]['original_name']}",
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontWeight: FontWeight.w500,
                                fontSize: 14,
                              ),
                            ),
                          )
                              : post.quoteInfo.postType == 'gallery' &&
                              post.quoteInfo.postFiles.length > 1 &&
                              post.quoteInfo.postFiles[0]['file_type'] ==
                                  'attachment'
                              ? Column(
                            children: [
                              for (var i = 0; i <
                                  post.quoteInfo.postFiles.length; i++)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 4.0),
                                  child: ListTile(
                                    onTap: () {
                                      launch(post.quoteInfo
                                          .postFiles[i]['file_path']);
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            10)),
                                    tileColor: Colors.grey[100],
                                    leading: SizedBox(height: 28,
                                        width: 28,
                                        child: Image.asset(
                                            'assets/images/document.png')),
                                    title: Text(
                                      "${post.quoteInfo
                                          .postFiles[i]['original_name']}",
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          )
                              : Container(),
                        ],
                      ),
                    ),
                  )
                      : SizedBox(),

                  SizedBox(
                    height: 8.0,
                  ),
                  post.postType == 'video' || post.postType == 'gallery'
                      // post.postFiles[0]['file_type'] ==
                      //     'image'
                      && post.postFiles.length > 0 ?
                  post.postFiles[0] ['mention_users'].isNotEmpty ? SizedBox(
                    width: kIsWeb ? 150 : 80,
                    child: InkWell(onTap: () {
                      // controller.tagList.clear();
                      controller.showTagUserDialog(
                          context, Get.height, Get.width, post
                          .postFiles[0]['mention_users'], () {


                      });
                    }, child: Row(
                      children: [
                        Icon(Icons.person, size: 15, color: Colors.blue,),
                        Text(post.postFiles[0]['mention_users'].isNotEmpty
                            ? "${post.postFiles[0]['mention_users'].length > 1
                            ? post
                            .postFiles[0]['mention_users'][0]["firstname"] +
                            " and ${post.postFiles[0]['mention_users'].length -
                                1} Others" : "${post
                            .postFiles[0]['mention_users'][0]["firstname"]}" } "
                            : "Tag People",
                          style: Styles.baseTextTheme.headline2.copyWith(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.w500,
                            fontSize: 14,
                          ),),
                      ],
                    )),
                  ) : SizedBox() : SizedBox(),
                  SizedBox(
                    height: 8.0,
                  ),
                  buildReactionRow(context, controller),
                  SizedBox(height: 5),
                  // SIMPLE COMMENT
                  kIsWeb
                      ? buildSimpleCommentField(controller, context)
                      : SizedBox(),
                  SizedBox(
                    height: 4,
                  ),
                  kIsWeb
                      ? controller.isLoading
                      ? CircularProgressIndicator(color: MyColors.BlueColor,)
                  // : ListView.separated(
                  //     physics: NeverScrollableScrollPhysics(),
                  //     itemCount: controller.selectedPost.comments.length,
                  //     separatorBuilder: (context, index) {
                  //       return SizedBox(
                  //         height: 12,
                  //       );
                  //     },
                  //     shrinkWrap: true,
                  //     itemBuilder: (context, index) {
                  //       return SingleComment(
                  //         controller.selectedPost,
                  //         index,
                  //         controller,
                  //       );
                  //     },
                  //   )
                  // CommentsListView(widget.post)
                      : Text(Strings.commentsHere)
                      : Container(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  // PDF FILE BUILDER METHOD
  // ignore: missing_return
  Text buildPdfFile(int length) {
    print(length);
    for (var i = 0; i <= length; i++) {
      print('ITERATION' + i.toString());
      return Text(post.postFiles[i]['file_path'],
        style: TextStyle(
          fontWeight: FontWeight.w400,
          fontSize: 14,
        ),
      );
    }
  }

  // REACTION ROW BUILDER METHOD
  dynamic buildReactionRow(BuildContext context,
      NewsfeedController controller) {
    // if (post.isLiked) {
    //   post.like = true;
    //   post.likeCount = post.simpleLikeCount;
    // }
    return Padding(
      padding: EdgeInsets.only(left: Get.width / 40, right: Get.width / 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        // mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [

              ///temperory_comment
              // Tooltip(
              //   message: 'Like',
              //   child: InkWell(
              //     onTap: () async {
              //       // ignore: unused_local_variable
              //       var response = await controller.likePost(post.postId,"");
              //       print(post.isLiked);
              //       if (post.isLiked) {
              //         post.isLiked = false;
              //
              //         post.simpleLikeCount--;
              //         post.likeCount--;
              //         controller.update();
              //       } else {
              //         post.isLiked = true;
              //
              //         post.simpleLikeCount++;
              //         post.likeCount++;
              //         controller.update();
              //       }
              //       controller.update();
              //     },
              //     child: Container(
              //         width: 20,
              //         height: 20,
              //         child: new Image.asset(!post.isLiked
              //             ? 'assets/drawer_icons/not_like.png'
              //             : 'assets/drawer_icons/like_fill.png')),
              //
              //     // Icon(!post.isLiked
              //     //     ? Icons.thumb_up_alt_outlined
              //     //     : Icons.thumb_up),
              //   ),
              // ),

              SizedBox(width: 5),
              GestureDetector(
                onTap: () async {
                  // List<Reaction1> data =
                  await controller.getWhoReacted(post.postId);
                  // print(data);
                  showDialog(
                      context: context,
                      builder: (context) {
                        return ReactRetweetDialog(
                          Strings.peopleWhoReacted,
                          // reactions: data,
                        );
                      });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 1,
                  ),
                  child: Text(
                    "${post.simpleLikeCount}",
                    // style: TextStyle(
                    //   color: Colors.grey[600],
                    //   fontSize: 14,
                    // ),
                    style: Theme
                        .of(context)
                        .brightness == Brightness.dark ?
                    TextStyle(color: Colors.black, fontSize: 14,

                    )
                        : TextStyle(color: Colors.black, fontSize: 14,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Tooltip(
                message: Strings.comments,
                child: InkWell(
                  onTap: () async {
                    if (!kIsWeb) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  CommentsScreen(postId: post.postId)));
                      controller.postId = post.postId;
                      // Get.toNamed(AppRoute.mobileCommentRoute,
                      //     arguments: {"postId": post.postId});
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (BuildContext context) => CommentsScreen(),
                      //   ),
                      // );
                    } else {
                      // controller.postList.forEach((element) {
                      //   element.isComment.value = false;
                      // });
                      controller.isCommentField.value = true;
                      controller.update();
                    }
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    child: new Image.asset('assets/drawer_icons/comments.png',
                        color:
                        // post.isRetweeted
                        //     ? Theme.of(context).iconTheme.color
                        //     :
                        Colors.grey),
                    // Text(
                    //   Strings.comments,
                    //   style: Theme.of(context).textTheme.bodyText2,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () async {},
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 1,
                  ),
                  child: Text(
                    post.commentsCount.toString(),
                    // style: TextStyle(
                    //   color: Colors.grey[600],
                    //   fontSize: 14,
                    // ),
                    style: Theme
                        .of(context)
                        .brightness == Brightness.dark ?
                    TextStyle(color: Colors.white, fontSize: 14,

                    )
                        : TextStyle(color: Colors.grey[600], fontSize: 14,
                    ),
                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              post.isRetweeted == null
                  ? SizedBox()
                  : Tooltip(
                message: Strings.rewerf,
                child: InkWell(
                  onTap: post.isRetweeted
                      ? () async {
                    // ignore: unused_local_variable
                    var response =
                    await controller.undoRetweet(post.postId);
                    // if (response == 'Undo retweeted Successfully')
                    post.isRetweeted = false;
                    post.retweetCount--;
                    controller.update();
                  }
                      : () async {
                    var response =
                    await controller.addRetweet(post.postId);
                    if (response == 'Add retweet Successfully') {
                      post.isRetweeted = true;
                    }
                    post.retweetCount++;
                    controller.update();
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    child: new Image.asset(
                        'assets/drawer_icons/rebuzz.png',
                        color: post.isRetweeted
                            ? Theme
                            .of(context)
                            .iconTheme
                            .color
                            : Colors.grey),
                  ),
                  //   Icon(Icons.repeat,
                  //       color: post.isRetweeted
                  //           ? Theme.of(context).iconTheme.color
                  //           : Colors.grey),
                ),
              ),
              // Text(
              //   'Rebuzz',
              //   style: Theme.of(context).textTheme.bodyText2,
              // ),
              GestureDetector(
                onTap: () async {
                  List<Retweet> data =
                  await controller.getWhoRetweeted(post.postId);
                  print(data);
                  showDialog(
                      context: context,
                      builder: (context) {
                        return ReactRetweetDialog(
                          Strings.peopleWhoRetweeted,
                          retweets: data,
                        );
                      });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 1,
                  ),
                  child: Text(
                    post.retweetCount.toString(),
                    style: Theme
                        .of(context)
                        .brightness == Brightness.dark ?
                    TextStyle(color: Colors.white, fontSize: 14,

                    )
                        : TextStyle(color: Colors.grey[600], fontSize: 14,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Simple Comment BUILDER METHOD
  dynamic buildSimpleCommentField(NewsfeedController controller,
      BuildContext context) {
    return Obx(() {
      return controller.isCommentField.value
          ? ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 0),
        title: Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              controller.userProfile == null
                  ? Container(
                  width: 24,
                  child: Center(
                    child: SpinKitCircle(
                      color: Colors.grey,
                      size: 40,
                    ),
                  ))
                  : controller.userProfile.profileImage == null
                  ? CircleAvatar(
                  radius: 12,
                  backgroundImage: AssetImage(
                      "assets/images/person_placeholder.png"))
                  : ClipRRect(
                borderRadius: BorderRadius.circular(40),
                child: FadeInImage(
                    fit: BoxFit.cover,
                    width: 24,
                    height: 24,
                    placeholder: AssetImage(
                        'assets/images/person_placeholder.png'),
                    image: NetworkImage(controller
                        .userProfile.profileImage !=
                        null
                        ? controller.userProfile.profileImage
                        : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
              ),
              SizedBox(
                width: 12,
              ),
              Expanded(
                child: SizedBox(
                  height: 50,
                  child: TextField(
                    style: LightStyles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.white : Colors
                          .black,
                      // fontWeight: FontWeight.bold,
                    ),
                    cursorColor: Colors.blue,
                    controller: commentTextController,
                    textAlignVertical: TextAlignVertical.bottom,
                    decoration: InputDecoration(
                      hintStyle: LightStyles.baseTextTheme.headline3,
                      hintText: Strings.leaveAComment,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40),
                        borderSide: BorderSide(color: Colors.grey, width: 1),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40),
                        borderSide: BorderSide(color: Colors.grey, width: 1),
                      ),
                      fillColor: Colors.grey[250],
                      filled: true,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 12.0, left: 32, bottom: 4),
          child: Row(
            children: [
              ElevatedButton(
                style: ButtonStyle(
                  padding: MaterialStateProperty.all(
                    EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 10,
                    ),
                  ),
                  shape: MaterialStateProperty.all(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40),
                    ),
                  ),
                  backgroundColor: MaterialStateProperty.all(
                    Theme
                        .of(context)
                        .primaryColor,
                  ),
                ),
                onPressed: () async {
                  if (commentTextController.text.isNotEmpty) {
                    controller.createDeleteComment(
                      post.postId,
                      controller.userProfile == null
                          ? "assets/images/person_placeholder.png"
                          : controller.userProfile.profileImage ?? "assets/images/person_placeholder.png",
                      commentTextController.text,
                      'create',
                      {
                        'audioFileUrl': null,
                        'audioPath': null,
                        'author': {
                          'firstname': controller.userProfile.firstname,
                          'id': GetStorage().read('id'),
                          'lastname': controller.userProfile.lastname,
                          'profileImage': controller.userProfile == null
                              ? "assets/images/person_placeholder.png"
                              : controller.userProfile.profileImage ?? "assets/images/person_placeholder.png",
                          'username': controller.userName,
                        },
                        'body': commentTextController.text,
                        'id': null,
                        'isLiked': false,
                        'postId': post.postId,
                        'replies': [],
                        'repliesCount': 0,
                        'userId': GetStorage().read('id'),
                        'commentedTimeAgo': 'just now',
                        'createdAt': null,
                        'inReplyToId': null,
                        'languageId': null,
                        'link': null,
                        'linkImage': null,
                        'linkMeta': null,
                        'linkTitle': null,
                        'postTypeId': null,
                        'processingStatus': null,
                        'simpleDislikeCount': 0,
                        'simpleLikeCount': 0,
                        'speechToText': null,
                        'status': null,
                        'updatedAt': null,
                      },
                    );
                    // controller.isPostDetails = true;
                    var response = await controller.createComment(
                        commentTextController.text, post);
                    if (response['meta']['code'] == 200 ||
                        controller.isSocketSuccess) {
                      controller.isCommentField.value = false;
                      //
                      controller.selectedPost2 = await controller
                          .getSingleNewsFeedItem(post.postId,
                          isReload: true);

                      commentTextController.clear();
                      // controller.isPostDetails = true;
                      controller.isNewsFeedScreen = false;
                      controller.update();
                      controller.postList =
                      await controller.getNewsFeed(reload: false);

                      // controller.isPostDetails = false;
                      // switch (controller.navRoute) {
                      //   case "isNewsFeedScreen":
                      //     {
                      //       controller.isNewsFeedScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //
                      //   case "isTrendsScreen":
                      //     {
                      //       controller.isTrendsScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //
                      //   case "isQuestScreen":
                      //     {
                      //       controller.isBrowseScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //
                      //   case "isSavedPostScreen":
                      //     {
                      //       controller.isSavedPostScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //   case "isNotificationScreen":
                      //     {
                      //       controller.isTrendsScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //   case "isChatScreen":
                      //     {
                      //       controller.isNotificationScreen = true;
                      //       controller.update();
                      //     }
                      //     break;
                      //
                      //   default:
                      //     {
                      //       print("Invalid choice");
                      //     }
                      //     break;
                      // }
                      // Navigator.pop(context);
                    }
                  }
                },
                child: Text(Strings.post,
                  style: Theme
                      .of(context)
                      .brightness == Brightness.dark ?
                  TextStyle(color: Colors.white,

                  )
                      : TextStyle(color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(width: 12),
              InkWell(
                  onTap: () {
                    controller.isCommentField.value = false;
                    controller.update();
                  },
                  child: Text(Strings.cancel,
                    style: Theme
                        .of(context)
                        .brightness == Brightness.dark ?
                    TextStyle(color: Colors.white, fontSize: 14,

                    )
                        : TextStyle(color: Colors.grey, fontSize: 14,
                    ),)),
            ],
          ),
        ),
      )
          : Container();
    });
  }
}

Widget myPopMenu(BuildContext context, scaffoldKey, Post post,
    NewsfeedController controller) {
  return PopupMenuButton(
      icon: Icon(
        Icons.more_horiz,
        color: Colors.black,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
      ),
      color: Colors.white,
      onSelected: (value) {
        print(value);

        if (value == 1) {
          showDialogBox(context, post.postId, controller);
          controller.update();
        } else if (value == 2) {
          controller.hidePost(post.postId);
          controller.update();
        } else if (value == 3) {
          controller.savePost(post.postId);
          controller.update();
        }
      },
      itemBuilder: (context) =>
      [
        PopupMenuItem(
            value: 3,
            child: Center(
                child: Text(
                    Strings.savePost,
                    style:
                    TextStyle(color: Colors.black,
                        fontSize: 14

                    )
                ))),
        PopupMenuItem(
            value: 1,
            child: Center(
                child: Text(
                    Strings.report,
                    style:
                    TextStyle(color: Colors.black,
                        fontSize: 14

                    )
                ))),
        PopupMenuItem(
            value: 2,
            child: Center(
                child: Text(
                    Strings.hide,
                    style:
                    TextStyle(color: Colors.black,
                        fontSize: 14

                    )
                ))),
      ]);
}

Widget sharePopMenu(BuildContext context,
    scaffoldKey,
    Post post,
    NewsfeedController controller,) {
  return PopupMenuButton(
      icon: Icon(
        Icons.share,
        color: Colors.black,
        size: 16,
      ),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(5),
      ),
      color: Colors.white,
      onSelected: (value) async {
        print(value);

        if (value == 1) {
          Clipboard.setData(ClipboardData(
              text:
              "${Url.baseUrl}/post/get-single-newsfeed-item?post_id=${post
                  .postId}"));
        } else if (value == 2) {
          try {
            await html.window.navigator.share({
              "url":
              "${Url.baseUrl}/post/get-single-newsfeed-item?post_id=${post
                  .postId}"
            });
          } catch (e) {
            print(e);
          }
        }
      },
      itemBuilder: (context) =>
      [
        PopupMenuItem(
            value: 2,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(
                  Icons.share,
                  color: Colors.grey,
                  size: 16,
                ),
                SizedBox(width: 20),
                Text(
                    Strings.shareLinkVia,
                    style:
                    TextStyle(color: Colors.black,
                        fontSize: 14

                    )
                ),
              ],
            )),
        PopupMenuItem(
            value: 1,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Icon(
                  Icons.link,
                  color: Colors.grey,
                  size: 16,
                ),
                SizedBox(width: 20),
                Text(
                    Strings.copyLink,
                    style:
                    TextStyle(color: Colors.black,
                        fontSize: 14

                    )
                ),
              ],
            )),
      ]);
}

showDialogBox(context, postId, NewsfeedController controller) {
  final reportText = TextEditingController();
  bool isCategory = false;
  final _formKey = GlobalKey<FormState>();
  return showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          child: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
                return Container(
                  width: Get.width / 4.5,
                  height: Get.width / 4.5,
                  padding: EdgeInsets.all(10),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: TextFormField(cursorColor: Colors.blue,
                            maxLines: 5,
                            validator: (value) {
                              if (value.isEmpty) return Strings.fieldRequired;
                              return null;
                            },
                            controller: reportText,
                            minLines: 3,
                            onChanged: (val) {
                              val = reportText.text;
                            },
                            keyboardType: TextInputType.multiline,
                            decoration: InputDecoration(
                              hintText: Strings.enterDescription,
                              hintStyle: Theme
                                  .of(context)
                                  .brightness == Brightness.dark ?
                              TextStyle(color: Colors.white,

                              )
                                  : TextStyle(color: Colors.black,
                              ),
                              isDense: true,
                              focusedErrorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey[200],
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey[200],
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.grey[200],

                                ),
                              ),
                              errorBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Colors.red,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.only(
                              left: 10, right: 10, top: 0, bottom: 25),
                          padding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                          decoration: BoxDecoration(
                              border: Border.all(
                                color: isCategory ? Colors.red : Colors
                                    .grey[200],
                              ),
                              borderRadius: BorderRadius.circular(10)),
                          width: Get.width,
                          height: 45,
                          child: DropdownButton<CategoryModel>(
                            isExpanded: true,
                            underline: Container(
                              height: 0.0,
                            ),
                            hint: Text(controller.selectedCategory == null ||
                                controller.selectedCategory == ""
                                ? Strings.selectCategory
                                : controller.selectedCategory,
                              style: Theme
                                  .of(context)
                                  .brightness == Brightness.dark ?
                              TextStyle(color: Colors.white,

                              )
                                  : TextStyle(color: Colors.black,
                              ),
                            ),
                            items:
                            controller.categoryList.map((CategoryModel value) {
                              return DropdownMenuItem<CategoryModel>(
                                value: value,
                                child: new Text(value.name,
                                  style: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ?
                                  TextStyle(color: Colors.white,

                                  )
                                      : TextStyle(color: Colors.black,
                                  ),),
                              );
                            }).toList(),
                            onChanged: (CategoryModel _) {
                              setState(() {
                                controller.selectedCategory = _.name;
                                controller.selectcategoryId = _.id;
                              });
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 20,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              MaterialButton(
                                  color: Colors.grey,
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text(
                                    Strings.cancel,
                                    style: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ?
                                    TextStyle(color: Colors.white, fontSize: 14,

                                    )
                                        : TextStyle(
                                      color: Colors.black, fontSize: 14,
                                    ),
                                  )),
                              MaterialButton(
                                  color: Colors.blueAccent,
                                  onPressed: () {
                                    if (_formKey.currentState.validate()) {
                                      if (controller.selectcategoryId != null) {
                                        setState(() {
                                          isCategory = false;
                                        });
                                        controller.reportPost(
                                            controller.selectcategoryId,
                                            postId,
                                            reportText.text);
                                      } else {
                                        setState(() {
                                          isCategory = true;
                                        });
                                      }
                                    }
                                  },
                                  child: Text(
                                    Strings.report,
                                    style: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ?
                                    TextStyle(color: Colors.white, fontSize: 14,

                                    )
                                        : TextStyle(
                                      color: Colors.black, fontSize: 14,
                                    ),
                                  )),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                );
              }),
        );
      });
}
