import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/list_model.dart';

import '../network/controller/List_controller.dart';
import '../network/singleTone.dart';
import '../utils/font.dart';
import '../utils/strings.dart';

class EditPinnedList extends StatefulWidget {
  const EditPinnedList({Key key}) : super(key: key);

  @override
  State<EditPinnedList> createState() => _EditPinnedListState();
}

class _EditPinnedListState extends State<EditPinnedList> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(
      init: ListController(),
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: false,
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            leading: IconButton(
                onPressed: () {
                  SingleTone.instance.selectedLocation = null;
                  setState(() {});
                  Navigator.of(context).pop();
                },
                icon: Icon(
                  Icons.close,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                )),
            title: Text(
              Strings.editOrder,
              style: Styles.baseTextTheme.headline5.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: kIsWeb ? 18 : 16,
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: MaterialButton(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  color: controller.newsfeedController.displayColor,
                  // background
                  textColor: Colors.white,
                  // foreground
                  onPressed: () {
                    SingleTone.instance.selectedLocation = null;
                    setState(() {});
                    Navigator.of(context).pop();
                  },
                  child: Text(
                    Strings.done,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              )
            ],
          ),
          body: Column(
            children: [
              SingleChildScrollView(
                child: Column(
                  children: [
                    /*List.generate is commented and a new widget ReorderableListView is added because
             we are allowing user to change the order of its pinned list*/
                    // List.generate(
                    //   controller.listModel.data.pinnedLists.length, (index) =>
                    //     ListTile(
                    //       leading: InkWell(
                    //         onTap: () {},
                    //         child: Container(
                    //           height: 40,
                    //           width: 40,
                    //           decoration: BoxDecoration(
                    //               image: DecorationImage(
                    //                   image: NetworkImage(
                    //                       controller
                    //                           .listModel
                    //                           .data
                    //                           .pinnedLists[index]
                    //                           .coverImage ==
                    //                           null
                    //                           ?
                    //                       "https://complete.network/wp-content/uploads/default-avatar-photo-placeholder-profile-picture-vector-21806614.jpg"
                    //                           : controller
                    //                           .listModel
                    //                           .data
                    //                           .pinnedLists[index]
                    //                           .coverImage)),
                    //               color: Colors
                    //                   .grey,
                    //               borderRadius: BorderRadius
                    //                   .circular(
                    //                   10)),
                    //         ),
                    //       ),
                    //       title: Text(
                    //         controller
                    //             .listModel
                    //             .data
                    //             .pinnedLists[index]
                    //             .name,
                    //         style: Styles.baseTextTheme.headline5.copyWith(
                    //           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    //           fontWeight: FontWeight.w500,
                    //         ),
                    //       ),
                    //       subtitle: Row(
                    //         children: [
                    //           Text("@"+
                    //               controller
                    //                   .listModel
                    //                   .data
                    //                   .pinnedLists[index]
                    //                   .authorName,
                    //             style: Styles.baseTextTheme.headline2.copyWith(
                    //               fontSize: 12,
                    //             ),
                    //           ),
                    //         ],
                    //       ),
                    //       trailing: InkWell(
                    //         onTap: () {
                    //           setState(() {
                    //             // pinPostList.remove(dataList[index]);
                    //           });
                    //         },
                    //         child: IconButton(
                    //           onPressed: () {},
                    //           icon: Icon(
                    //             Icons
                    //                 .menu,
                    //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    //           ),
                    //         ),
                    //       ),
                    //     ),
                    // ),
                    GestureDetector(
                      child: ReorderableListView(
                        shrinkWrap: true,
                        children: controller.listModel.data.pinnedLists
                            .map((item) => ReorderableDelayedDragStartListener(
                                  index: controller.listModel.data.pinnedLists
                                      .indexOf(item),
                                  key: UniqueKey(),
                                  child: ListTile(
                                    // key: UniqueKey(),
                                    leading: InkWell(
                                      onTap: () {},
                                      child: Container(
                                        height: 40,
                                        width: 40,
                                        decoration: BoxDecoration(
                                            image: DecorationImage(
                                                image: NetworkImage(item
                                                            .coverImage ==
                                                        null
                                                    ? "https://complete.network/wp-content/uploads/default-avatar-photo-placeholder-profile-picture-vector-21806614.jpg"
                                                    : item.coverImage)),
                                            color: Colors.grey,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                      ),
                                    ),
                                    title: Text(
                                      item.name,
                                      style: Styles.baseTextTheme.headline5
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    subtitle: Row(
                                      children: [
                                        Text(
                                          "@" + item.authorName,
                                          style: Styles.baseTextTheme.headline2
                                              .copyWith(
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                    trailing: !kIsWeb
                                        ? InkWell(
                                            onTap: () {
                                              setState(() {
                                                // pinPostList.remove(dataList[index]);
                                              });
                                            },
                                            child: IconButton(
                                              onPressed: () {},
                                              icon: Icon(
                                                Icons.drag_handle,
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                              ),
                                            ),
                                          )
                                        : SizedBox(),
                                  ),
                                ))
                            .toList(),
                        onReorder: (int oldIndex, int newIndex) {
                          setState(() {
                            if (newIndex > oldIndex) {
                              newIndex -= 1;
                            }
                            final DiscoverListElement item = controller
                                .listModel.data.pinnedLists
                                .removeAt(oldIndex);
                            controller.listModel.data.pinnedLists
                                .insert(newIndex, item);
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
