import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import 'package:werfieapp/network/controller/List_controller.dart';

import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/strings.dart';
import '../web_views/web_main_screen.dart';
import 'dicover_list_post_screen.dart';

class ListAsMemberScreen extends StatefulWidget {


  @override
  State<ListAsMemberScreen> createState() => _ListAsMemberScreenState();
}

class _ListAsMemberScreenState extends State<ListAsMemberScreen> {


  ListController controller =Get.put(ListController());
  final storage = GetStorage();
  @override
  void initState() {

    print('getlistinit');

    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      print("WidgetsBinding");
     getApi();
    });
  }
   getApi() async{
   controller.getMemberListData=await controller.getMemberListDataApi();
   }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        appBar: kIsWeb
            ? PreferredSize(
            child: ListTile(
              leading: IconButton(
                  onPressed: () {
                    onHomeChange =false;
                    onBrowsChange = false;
                    onTrendsChange = false;
                    onBookMarksChange = false;
                    onChatsChange = false;
                    onProfileChange = false;
                    onSettingChange = false;
                    onListChange = true ;
                    onNotificationChange = false;
                    onMoreChange = false;
                    onMomentChange = false;

                    controller.newsfeedController.isTrendsScreen = false;
                    controller.newsfeedController.isNewsFeedScreen = false;
                    controller.newsfeedController.isBrowseScreen = false;
                    controller.newsfeedController.isNotificationScreen = false;
                    controller.newsfeedController.isChatScreen = false;
                    controller.newsfeedController.isSavedPostScreen = false;
                    controller.newsfeedController.isPostDetails = false;
                    controller.newsfeedController.isProfileScreen = false;
                    controller.newsfeedController.isOtherUserProfileScreen = false;
                    controller.newsfeedController.isTopicScreen = false;
                    controller.newsfeedController.isListScreen = true;
                    controller.newsfeedController.isMainTopicScreen = false;
                    controller.newsfeedController.isListDetailScreen=false;
                    controller.newsfeedController.update();

                    Get.back();
                  },
                  icon: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  )),
              title: Text(
                Strings.listYouAre,
                style:
                Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                ),
              ),
              subtitle: Text(
                  "@${controller.storage.read("userName")}",
                  style:
                  Styles.baseTextTheme.headline2.copyWith(
                    fontSize: kIsWeb ? 14 : 12,
                  )
                // TextStyle(
                //     fontSize: kIsWeb ? 18.0 : 14.0,color: Colors.black38
                // ),
              ),

            ),
            preferredSize: Size(double.infinity, 60))
            : AppBar(
          elevation: 0.0,
          backgroundColor: Theme.of(context).brightness ==
              Brightness.dark
              ? Colors.black
              : Colors.white,
          leading: IconButton(
              onPressed: () {

                Get.back();
              },
              icon: Icon(
                Icons.arrow_back,
                color: Theme.of(context).brightness ==
                    Brightness.dark
                    ? Colors.white
                    : Colors.black,
              )),
          title: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                Strings.listYouAre,
                style:
                Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                ),
              ),
              Text(
                  "@${controller.storage.read("userName")}",
                  style: Styles.baseTextTheme.headline2
                      .copyWith(
                    fontSize: kIsWeb ? 14 : 12,
                  )
              ),
            ],
          ),

        ),
body: GetBuilder<ListController>(
  builder: (controller) {
    return
      controller.isListMemberLoading?
     Center(
    child: CircularProgressIndicator(
    color: MyColors.BlueColor,
    ))
      :SingleChildScrollView(

        child:
         controller.getMemberListData==null ?
        Center(
          child: Column(
           children: [
             SizedBox(
               height: 200,
             ),
             Text(
               Strings.listYouHave,
               style:
               Styles.baseTextTheme.headline1.copyWith(
                 color: Theme.of(context).brightness ==
                     Brightness.dark
                     ? Colors.white
                     : Colors.black,
               ),
             ),
             Text(
                 Strings.listAddedSomeOne,
                 style: Styles.baseTextTheme.headline2
                     .copyWith(
                   fontSize: kIsWeb ? 14 : 12,
                 )
             ),
           ],
          ),
        )
        :Column(
        children: List.generate(
          controller.getMemberListData.length,
                (index) => ListTile(
                onTap:
                    () async {
                  if (kIsWeb) {
                    storage.write("pinIndex", controller.getMemberListData[index]);
                    storage.write("clickId", 4);
                    storage.write("pinId", controller.getMemberListData[index].id);
                    controller.newsfeedController.isListDetailScreen = true;
                    controller.newsfeedController.isSearch = false;
                    controller.newsfeedController.isFilter = false;
                    controller.newsfeedController.isFilterScreen = false;
                    controller.newsfeedController.isTrendsScreen = false;
                    controller.newsfeedController.isNewsFeedScreen = false;
                    controller.newsfeedController.isBrowseScreen = false;
                    controller.newsfeedController.isNotificationScreen = false;
                    controller.newsfeedController.isWhoToFollowScreen = false;
                    controller.newsfeedController.isSavedPostScreen = false;
                    controller.newsfeedController.isChatScreen = false;
                    controller.newsfeedController.isPostDetails = false;
                    controller.newsfeedController.isProfileScreen = false;
                    controller.newsfeedController.searchText.text = '';
                    controller.newsfeedController.isListScreen = false;
                    controller.newsfeedController.isFollwerScreen = false;
                    controller.newsfeedController.isSettingsScreen = false;
                    controller.newsfeedController.navRoute = "isChatScreen";
                    controller.newsfeedController.update();
                    print("list iD?>>>>>>>>>>>>>>>>>>>>>" +
                        controller.getMemberListData[index].id.toString());
                    Get.toNamed(FluroRouters.mainScreen +
                        "/listDetail/" + controller.getMemberListData[index].id.toString() );
                  } else {
                    //   controller.list = controller.listModel.data.lists[index];
                    Navigator
                        .push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (BuildContext context) =>
                            DiscoverListScreen(
                              controller: controller.newsfeedController,
                              index: index.toString(),
                              clickId: 4,
                              listId:   controller.getMemberListData[index].id,

                            ),
                      ),
                    );
                    debugPrint('list id 0 ---->>> ${ controller.getMemberListData[index].id}');

                  }
                },
                leading:
                Container(
                  height: 40,
                  width: 40,
                  decoration: BoxDecoration(
                      color: Colors
                          .grey,
                      borderRadius:
                      BorderRadius.circular(
                          10),
                      image: DecorationImage(
                          image: NetworkImage( controller.getMemberListData[index].coverImage == null
                              ? "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQerA4slT8egQop5xe3kcmIPmcxBTP-qo8Bjg&usqp=CAU"
                              :  controller.getMemberListData[index].coverImage),
                          fit: BoxFit.fill)),
                ),
                title: Text( controller.getMemberListData[index].name,
                  style: Styles
                      .baseTextTheme
                      .headline5
                      .copyWith(
                    color: Theme.of(context).brightness ==
                        Brightness
                            .dark
                        ? Colors
                        .white
                        : Colors
                        .black,
                    fontWeight:
                    FontWeight
                        .bold,
                  ),
                ),
                subtitle: Row(
                  children: [

                    Text(
                      "@" +  controller.getMemberListData[index].username,
                      style: Styles
                          .baseTextTheme
                          .headline5
                          .copyWith(
                        fontSize: kIsWeb
                            ? 14
                            : 12,
                        fontWeight:
                        FontWeight.w400,
                      ),
                    ),
                  ],
                ),

        ),
        ),
        )
        );
  }
)
    );
  }
}
