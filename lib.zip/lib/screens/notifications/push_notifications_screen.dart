import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../../network/apis/push_notifications_settings.dart';
import '../../network/controller/NotificationsSettingsController.dart';
import '../../utils/font.dart';

class PushNotificationsScreen extends StatefulWidget {
  PushNotificationsScreen();

  @override
  State<PushNotificationsScreen> createState() =>
      _PushNotificationsScreenState();
}

class _PushNotificationsScreenState extends State<PushNotificationsScreen> {
  final controller = Get.find<NewsfeedController>();
  final notificationsSettingsController =
      Get.find<NotificationSettingsController>();

  bool checkBoxPushNotifications = false;
  bool werfsCheckBoxValue = true;
  bool checkBoxPhotoTags = true;
  bool checkBoxNewFollowers = true;
  bool checkBoxDirectMessages = true;

  bool checkBoxTopics = true;
  bool checkBoxNewsAndSports = true;
  bool checkBoxRecommendation = true;
  bool checkBoxMoments = true;

  int radioGroupTopWerfs = 2;
  String selectedValueTopWerf = 'off';

  int radioGroupRewerfValue = 2;
  String selectedValueRewerf = 'off';

  int radioGroupLikeValue = 2;
  String selectedValueLike = 'off';

  int radioGroupValueMessageReactions = 2;
  String selectedValueMessageReactions = 'off';

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      checkBoxPushNotifications = controller.notificationStatus;
      setState(() {});
      if (notificationsSettingsController.pushNotificationsSettingsResponse ==
          null) {
        await PushNotificationsSettingsAPI().pushNotificationsSettings("read");
        setData();
      } else {
        setData();
      }
    });
    super.initState();
  }

  setData() {
    werfsCheckBoxValue = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.werfsNotification ==
            1
        ? true
        : false;
    checkBoxPhotoTags = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.photoTags ==
            1
        ? true
        : false;
    checkBoxNewFollowers = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.newFollowers ==
            1
        ? true
        : false;
    checkBoxDirectMessages = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.directMesages ==
            1
        ? true
        : false;
    checkBoxTopics = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.topics ==
            1
        ? true
        : false;
    checkBoxNewsAndSports = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.newsOrSports ==
            1
        ? true
        : false;
    checkBoxRecommendation = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.recommendations ==
            1
        ? true
        : false;
    checkBoxMoments = notificationsSettingsController
                .pushNotificationsSettingsResponse.data.moments ==
            1
        ? true
        : false;

    setRadioGroupTopWerfValue(
        notificationsSettingsController
            .pushNotificationsSettingsResponse.data.topWerfs);
    setRadioGroupReWerfValue(
        notificationsSettingsController
            .pushNotificationsSettingsResponse.data.reWerfs);
    setRadioGroupLikeValue(
        notificationsSettingsController
            .pushNotificationsSettingsResponse.data.likes);
    setRadioGroupMessageReactions(
        notificationsSettingsController
            .pushNotificationsSettingsResponse.data.messageReactions);

    setState(() {});
  }

  setRadioGroupTopWerfValue(String value) {
    if(value == null){
      radioGroupTopWerfs = 2;
    }else if(value == "tailored"){
      radioGroupTopWerfs = 0;
    }else if(value == "anyone"){
      radioGroupTopWerfs = 1;
    }else if(value == "off"){
      radioGroupTopWerfs = 2;
    }
    /*switch (value) {
      case "tailored":
        radioGroup = 0;
        break;
      case "anyone":
        radioGroup = 1;
        break;
      case "off":
        radioGroup = 2;
        break;
      default:
        radioGroup = 2;
        break;
    }
    setState(() {

    });*/
  }
  setRadioGroupReWerfValue(String value) {
    if(value == null){
      radioGroupRewerfValue = 2;
    }else if(value == "tailored"){
      radioGroupRewerfValue = 0;
    }else if(value == "anyone"){
      radioGroupRewerfValue = 1;
    }else if(value == "off"){
      radioGroupRewerfValue = 2;
    }
    /*switch (value) {
      case "tailored":
        radioGroup = 0;
        break;
      case "anyone":
        radioGroup = 1;
        break;
      case "off":
        radioGroup = 2;
        break;
      default:
        radioGroup = 2;
        break;
    }
    setState(() {

    });*/
  }
  setRadioGroupLikeValue(String value) {
    if(value == null){
      radioGroupLikeValue = 2;
    }else if(value == "tailored"){
      radioGroupLikeValue = 0;
    }else if(value == "anyone"){
      radioGroupLikeValue = 1;
    }else if(value == "off"){
      radioGroupLikeValue = 2;
    }
    /*switch (value) {
      case "tailored":
        radioGroup = 0;
        break;
      case "anyone":
        radioGroup = 1;
        break;
      case "off":
        radioGroup = 2;
        break;
      default:
        radioGroup = 2;
        break;
    }
    setState(() {

    });*/
  }
  setRadioGroupMessageReactions(String value) {
    if(value == null){
      radioGroupValueMessageReactions = 2;
    }else if(value == "tailored"){
      radioGroupValueMessageReactions = 0;
    }else if(value == "anyone"){
      radioGroupValueMessageReactions = 1;
    }else if(value == "off"){
      radioGroupValueMessageReactions = 2;
    }
    /*switch (value) {
      case "tailored":
        radioGroup = 0;
        break;
      case "anyone":
        radioGroup = 1;
        break;
      case "off":
        radioGroup = 2;
        break;
      default:
        radioGroup = 2;
        break;
    }
    setState(() {

    });*/
  }

  convertBoolToInt(bool value) {
    return value == true ? 1 : 0;
  }

  updateNotificationsSettings() async {
    PushNotificationsSettingsAPI().pushNotificationsSettings("update",
        werfsNotifications: convertBoolToInt(werfsCheckBoxValue),
        topWerfs: selectedValueTopWerf,
        reWerfs: selectedValueRewerf,
        likes: selectedValueLike,
        photoTags: convertBoolToInt(checkBoxPhotoTags),
        newFollowers: convertBoolToInt(checkBoxNewFollowers),
        directMessages: convertBoolToInt(checkBoxDirectMessages),
        messageReactions: selectedValueMessageReactions,
        topics: convertBoolToInt(checkBoxTopics),
        newsAndSports: convertBoolToInt(checkBoxNewsAndSports),
        recommendations: convertBoolToInt(checkBoxRecommendation),
        moments: convertBoolToInt(checkBoxMoments));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    Strings.pushNotifications,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            !kIsWeb
                ? Container(
              child: ListTile(
                title: Text(
                  Strings.pushNotifications,
                  style: TextStyle(
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 14 : 12,
                  ),
                ),
                subtitle: Text(
                  Strings.getPushNotificationsToFindOut,
                  style: TextStyle(
                      fontSize: 12, color: Colors.grey[500]),
                ),
                trailing: Switch(
                    value: checkBoxPushNotifications,
                    activeColor: MyColors.werfieBlue,
                    onChanged: (value) async {
                      LoggingUtils.printValue(
                          "PUSH NOTIFICATIONS Value", value);
                      if (value == true) {
                        setState(() {
                          checkBoxPushNotifications = true;
                        });
                        controller.notificationStatus = true;
                        controller.storage
                            .write("notificationAllowed", 1);
                        //controller.update();
                        await controller.snoozeNotification(1);
                      } else {
                        setState(() {
                          checkBoxPushNotifications = false;
                        });
                        controller.notificationStatus = false;
                        controller.storage
                            .write("notificationAllowed", 0);
                        //controller.update();

                        await controller.snoozeNotification(0);
                      }
                    }),
              ),
            )
                : Padding(
                    padding: const EdgeInsets.symmetric(
                      vertical: 12.0,
                      horizontal: 12,
                    ),
                    child: Column(
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Row(
                            children: [
                              IconButton(
                                onPressed: () {
                                  controller.isNotificationPreferencesScreen =
                                      true;
                                  controller.isPushNotificationScreen = false;
                                  controller.update();
                                },
                                icon: Icon(Icons.arrow_back),
                              ),
                              Text(
                                Strings.pushNotifications,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize:
                                        controller.languageData.appLang.id == 2
                                            ? 22
                                            : 18,
                                    fontWeight:
                                        controller.languageData.appLang.id == 2
                                            ? FontWeight.bold
                                            : FontWeight.normal),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        ListTile(
                          title: Text(
                            Strings.pushNotifications,
                            style: TextStyle(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                          ),
                          subtitle: Text(
                            Strings.getPushNotificationsToFindOut,
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey[500]),
                          ),
                          trailing: Switch(
                              value: checkBoxPushNotifications,
                              activeColor: MyColors.werfieBlue,
                              onChanged: (value) async {
                                LoggingUtils.printValue(
                                    "PUSH NOTIFICATIONS Value", value);
                                if (value == true) {
                                  setState(() {
                                    checkBoxPushNotifications = true;
                                  });
                                  controller.notificationStatus = true;
                                  controller.storage
                                      .write("notificationAllowed", 1);
                                  //controller.update();
                                  await controller.snoozeNotification(1);
                                } else {
                                  setState(() {
                                    checkBoxPushNotifications = false;
                                  });
                                  controller.notificationStatus = false;
                                  controller.storage
                                      .write("notificationAllowed", 0);
                                  //controller.update();

                                  await controller.snoozeNotification(0);
                                }
                              }),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
            Container(
              height: 1,
              color: Colors.grey[300],
            ),
            SizedBox(
              height: 10,
            ),
            checkBoxPushNotifications == false
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      turnOnPushNotifications(),
                    ],
                  )
                : Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0),
                        child: Text(
                          Strings.relatedToYouAndYourWerfs,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.bold),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      ListTile(
                        title: Text(
                          Strings.werf,
                          style: Styles.baseTextTheme.headline1.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontSize: kIsWeb ? 14 : 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                         Strings.whenYouTurnOnWerfNotificationsFromPeopleYouFollow,
                          style:
                              TextStyle(fontSize: 12, color: Colors.grey[500]),
                        ),
                        trailing: Checkbox(
                          value: werfsCheckBoxValue,
                          onChanged: (value) {
                            werfsCheckBoxValue = value;
                            setState(() {});
                            updateNotificationsSettings();

                          },
                          checkColor: Colors.white,
                          activeColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 10, top: 10),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                Strings.topWerfs,
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.tailoredForYou,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  Radio(
                                    value: 0,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupTopWerfs,
                                    onChanged: _handleRadioValueChange,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.fromAnyone,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 1,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupTopWerfs,
                                    onChanged: _handleRadioValueChange,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                   Text(
                                    Strings.off,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 2,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupTopWerfs,
                                    onChanged: _handleRadioValueChange,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 10, top: 15),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${Strings.rewerf}',
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.tailoredForYou,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  Radio(
                                    value: 0,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupRewerfValue,
                                    onChanged: _handleRadioValueChangeRewerf,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.fromAnyone,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 1,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupRewerfValue,
                                    onChanged: _handleRadioValueChangeRewerf,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  new Text(
                                   Strings.off,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 2,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupRewerfValue,
                                    onChanged: _handleRadioValueChangeRewerf,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 10, top: 15),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                Strings.like,
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.tailoredForYou,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  Radio(
                                    value: 0,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupLikeValue,
                                    onChanged: _handleRadioValueChangeLike,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.fromAnyone,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 1,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupLikeValue,
                                    onChanged: _handleRadioValueChangeLike,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                   Text(
                                   Strings.off,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 2,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupLikeValue,
                                    onChanged: _handleRadioValueChangeLike,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      ListTile(
                        title: Text(
                          Strings.photoTags,
                          style: Styles.baseTextTheme.headline2.copyWith(
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        trailing: Checkbox(
                          value: checkBoxPhotoTags,
                          onChanged: (value) {
                            checkBoxPhotoTags = value;
                            setState(() {});
                            updateNotificationsSettings();

                          },
                          checkColor: Colors.white,
                          activeColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                        contentPadding: EdgeInsets.only(right: 10, left: 15),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      ListTile(
                        title: Text(
                          Strings.newFollowers,
                          style: Styles.baseTextTheme.headline2.copyWith(
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        trailing: Checkbox(
                          value: checkBoxNewFollowers,
                          onChanged: (value) {
                            checkBoxNewFollowers = value;
                            setState(() {});
                            updateNotificationsSettings();

                          },
                          checkColor: Colors.white,
                          activeColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                        contentPadding: EdgeInsets.only(right: 10, left: 15),
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      ListTile(
                        title: Text(
                          Strings.directMessages,
                          style: Styles.baseTextTheme.headline2.copyWith(
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        trailing: Checkbox(
                          value: checkBoxDirectMessages,
                          onChanged: (value) {
                            checkBoxDirectMessages = value;
                            setState(() {});
                            updateNotificationsSettings();

                          },
                          checkColor: Colors.white,
                          activeColor: MyColors.werfieBlue,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5)),
                        ),
                        contentPadding: EdgeInsets.only(right: 10, left: 15),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 15.0, right: 10, top: 20),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                               Strings.messageReactions,
                                style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.tailoredForYou,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  Radio(
                                    value: 0,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupValueMessageReactions,
                                    onChanged:
                                        _handleRadioValueChangeMessageReactions,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  Text(
                                    Strings.fromAnyone,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 1,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupValueMessageReactions,
                                    onChanged:
                                        _handleRadioValueChangeMessageReactions,
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                   Text(
                                   Strings.off,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 14,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Spacer(),
                                  new Radio(
                                    value: 2,
                                    activeColor: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : MyColors.werfieBlue,
                                    groupValue: radioGroupValueMessageReactions,
                                    onChanged:
                                        _handleRadioValueChangeMessageReactions,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Container(
                        height: 1,
                        color: Colors.grey[300],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      fromWerfie(),
                      SizedBox(
                        height: 10,
                      )
                    ],
                  )
          ],
        ),
      ),
    );
  }

  fromWerfie() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 15.0),
          child: Text(
            Strings.fromWerfie,
            style: TextStyle(
                fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 15,
        ),
        ListTile(
          title: Text(
            Strings.topics,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxTopics,
            onChanged: (value) {
              setState(() {
                checkBoxTopics = value;
              });
              updateNotificationsSettings();

            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.newsSports,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxNewsAndSports,
            onChanged: (value) {
              setState(() {
                checkBoxNewsAndSports = value;
              });
              updateNotificationsSettings();

            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.recommendations,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxRecommendation,
            onChanged: (value) {
              setState(() {
                checkBoxRecommendation = value;
              });
              updateNotificationsSettings();

            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
           Strings.moments,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxMoments,
            onChanged: (value) {
              setState(() {
                checkBoxMoments = value;
              });
              updateNotificationsSettings();

            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
      ],
    );
  }

  turnOnPushNotifications() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          Strings.turnOnPush,
          style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: 24,
              fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          Strings.toReceiveNotificationsAsTheyHappen,
          style: TextStyle(
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black38,
            fontSize: 12,
          ),
        ),
        SizedBox(
          height: 15,
        ),
        ElevatedButton(
          onPressed: () async {
            if (checkBoxPushNotifications == false) {
              setState(() {
                checkBoxPushNotifications = true;
              });
              controller.notificationStatus = true;
              controller.storage.write("notificationAllowed", 1);
              controller.update();
              await controller.snoozeNotification(1);
            }
          },
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Text(Strings.turnOn),
          ),
          style: ElevatedButton.styleFrom(
              shape: StadiumBorder(), backgroundColor: MyColors.werfieBlue),
        )
      ],
    );
  }

  void _handleRadioValueChange(int value) {
    radioGroupTopWerfs = value;

    switch (radioGroupTopWerfs) {
      case 0:
        selectedValueTopWerf = "tailored";

        break;
      case 1:
        selectedValueTopWerf = "anyone";

        break;
      case 2:
        selectedValueTopWerf = "off";
        break;
    }

    setState(() {});
    updateNotificationsSettings();
  }

  void _handleRadioValueChangeRewerf(int value) {
    radioGroupRewerfValue = value;

    switch (radioGroupRewerfValue) {
      case 0:
        selectedValueRewerf = "tailored";

        break;
      case 1:
        selectedValueRewerf = "anyone";

        break;
      case 2:
        selectedValueRewerf = "off";
        break;
    }

    setState(() {});
    updateNotificationsSettings();

  }

  void _handleRadioValueChangeLike(int value) {
    radioGroupLikeValue = value;

    switch (radioGroupLikeValue) {
      case 0:
        selectedValueLike = "tailored";

        break;
      case 1:
        selectedValueLike = "anyone";

        break;
      case 2:
        selectedValueLike = "off";
        break;
    }

    setState(() {});
    updateNotificationsSettings();

  }

  void _handleRadioValueChangeMessageReactions(int value) {
    radioGroupValueMessageReactions = value;

    switch (radioGroupValueMessageReactions) {
      case 0:
        selectedValueMessageReactions = "tailored";

        break;
      case 1:
        selectedValueMessageReactions = "anyone";

        break;
      case 2:
        selectedValueMessageReactions = "off";
        break;
    }

    setState(() {});
    updateNotificationsSettings();

  }
}
