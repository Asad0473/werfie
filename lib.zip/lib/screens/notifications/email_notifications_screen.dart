import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/colors.dart';

import '../../models/profile.dart';
import '../../network/apis/email_notifications_settings_api.dart';
import '../../network/controller/NotificationsSettingsController.dart';
import '../../network/controller/update_daily_digest_api.dart';
import '../../utils/font.dart';
import 'dart:ui' as ui;

import '../../utils/loading_dialog_builder.dart';
import '../../utils/strings.dart';

class EmailNotificationsScreen extends StatefulWidget {
  EmailNotificationsScreen();

  @override
  State<EmailNotificationsScreen> createState() =>
      _EmailNotificationsScreenState();
}

class _EmailNotificationsScreenState extends State<EmailNotificationsScreen> {
  final controller = Get.find<NewsfeedController>();
  final notificationsSettingsController =
      Get.find<NotificationSettingsController>();
  final storage = GetStorage();

  bool checkBoxEmailNotifications = false;
  bool checkBoxNewNotifications = false;
  bool checkBoxTweetsEmailedToYou = false;
  bool checkBoxDirectMessages = false;

  bool checkBoxNewsAboutWerfie = false;
  bool checkBoxTips = false;
  bool checkBoxThingsYouMissed = false;
  bool checkBoxResearchSurveys = false;
  bool checkBoxSuggestionsForAccounts = false;
  bool checkBoxSuggestionsRecentFollows = false;

  int radioGroupTopWerfs = 2;
  String selectedValueTopWerfs = 'off';

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      checkSelectedDigest();
      if (notificationsSettingsController.pushNotificationsSettingsResponse ==
          null) {
        await EmailNotificationsSettingsAPI()
            .emailNotificationsSettings("read");
        setData();
      } else {
        setData();
      }
    });
    super.initState();
  }

  setData() {
    checkBoxEmailNotifications = notificationsSettingsController
                .emailNotificationsSettingsResponse
                .data
                .emailNotificationSwitch ==
            1
        ? true
        : false ??false;
    checkBoxNewNotifications = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.newNotifications ==
            1
        ? true
        : false;
    checkBoxTweetsEmailedToYou = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.werfsEmailedToYou ==
            1
        ? true
        : false;
    checkBoxDirectMessages = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.directMessages ==
            1
        ? true
        : false;
    checkBoxNewsAboutWerfie = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.newAboutWerfie ==
            1
        ? true
        : false;
    checkBoxTips = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.tipsOnWerfie ==
            1
        ? true
        : false;
    checkBoxThingsYouMissed = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.thingsYouMissed ==
            1
        ? true
        : false;
    checkBoxResearchSurveys = notificationsSettingsController
                .emailNotificationsSettingsResponse
                .data
                .participationInResearch ==
            1
        ? true
        : false;
    checkBoxSuggestionsForAccounts = notificationsSettingsController
                .emailNotificationsSettingsResponse.data.suggestionOnAccounts ==
            1
        ? true
        : false;
    checkBoxSuggestionsRecentFollows = notificationsSettingsController
                .emailNotificationsSettingsResponse
                .data
                .suggestionBasedRecentFollowers ==
            1
        ? true
        : false;

    setState(() {});
  }

  convertBoolToInt(bool value) {
    return value == true ? 1 : 0;
  }

  updateNotificationsSettings() {
    EmailNotificationsSettingsAPI().emailNotificationsSettings("update",
        emailNotificationSwitch: convertBoolToInt(checkBoxEmailNotifications),
        newNotifications: convertBoolToInt(checkBoxTweetsEmailedToYou),
        directMessages: convertBoolToInt(checkBoxDirectMessages),
        werfsEmailedToYou: convertBoolToInt(checkBoxTweetsEmailedToYou),
        newABoutWerfie: convertBoolToInt(checkBoxNewsAboutWerfie),
        tipsOnWerfie: convertBoolToInt(checkBoxTips),
        thingsYouMissed: convertBoolToInt(checkBoxThingsYouMissed),
        participationInResearch: convertBoolToInt(checkBoxResearchSurveys),
        suggestionsOnAccounts: convertBoolToInt(checkBoxSuggestionsForAccounts),
        suggestionBasedRecentFollowers:
            convertBoolToInt(checkBoxSuggestionsRecentFollows));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    Strings.emailNotification,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            !kIsWeb
                ? Container(
                    child: ListTile(
                      title: Text(
                        Strings.emailNotification,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 14 : 12,
                        ),
                      ),
                      subtitle: Text(
                          Strings.getEmailToFindOut,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      trailing: Switch(
                          value: checkBoxEmailNotifications,
                          activeColor: MyColors.werfieBlue,
                          onChanged: (value) {
                            setState(() {
                              checkBoxEmailNotifications = value;
                            });
                            updateNotificationsSettings();
                          }),
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.symmetric(
                      vertical: 12.0,
                      horizontal: 12,
                    ),
                    child: Column(
                      children: [
                        Align(
                          alignment: Alignment.center,
                          child: Row(
                            children: [
                              IconButton(
                                onPressed: () {
                                  controller.isNotificationPreferencesScreen =
                                      true;
                                  controller.isPushNotificationScreen = false;
                                  controller.update();
                                },
                                icon: Icon(Icons.arrow_back),
                              ),
                              Text(
                                Strings.emailNotification,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize:
                                        controller.languageData.appLang.id == 2
                                            ? 22
                                            : 18,
                                    fontWeight:
                                        controller.languageData.appLang.id == 2
                                            ? FontWeight.bold
                                            : FontWeight.normal),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        ListTile(
                          title: Text(
                            Strings.emailNotification,
                            style: TextStyle(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                          ),
                          subtitle: Text(
                            Strings.getEmailToFindOut,
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey[500]),
                          ),
                          trailing: Switch(
                              value: checkBoxEmailNotifications,
                              activeColor: MyColors.werfieBlue,
                              onChanged: (value) {
                                setState(() {
                                  checkBoxEmailNotifications = value;
                                });
                                updateNotificationsSettings();
                              }),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                      ],
                    ),
                  ),
            Container(
              height: 1,
              color: Colors.grey[300],
            ),
            ImageFiltered(
              enabled: !checkBoxEmailNotifications,
              imageFilter: ui.ImageFilter.blur(sigmaX: 1.5, sigmaY: 1.5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 15.0, top: 10),
                    child: Text(
                      Strings.relatedToYouAndYourWerfs,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize:
                              controller.languageData.appLang.id == 2 ? 22 : 18,
                          fontWeight: controller.languageData.appLang.id == 2
                              ? FontWeight.bold
                              : FontWeight.bold),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  ListTile(
                    title: Text(
                      Strings.newNotifications,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    trailing: Checkbox(

                      value: checkBoxNewNotifications,
                      onChanged: !checkBoxEmailNotifications ? null : (value) {
                        checkBoxNewNotifications = value;
                        setState(() {});
                        updateNotificationsSettings();
                      },
                      checkColor: Colors.white,
                      activeColor: MyColors.werfieBlue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                    ),
                    contentPadding: EdgeInsets.only(right: 10, left: 15),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  ListTile(
                    title: Text(
                      Strings.directMessages,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    trailing: Checkbox(
                      value: checkBoxDirectMessages,
                      onChanged: !checkBoxEmailNotifications ? null :(value) {
                        checkBoxDirectMessages = value;
                        setState(() {});
                        updateNotificationsSettings();
                      },
                      checkColor: Colors.white,
                      activeColor: MyColors.werfieBlue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                    ),
                    contentPadding: EdgeInsets.only(right: 10, left: 15),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  ListTile(
                    title: Text(
                      Strings.werfsEmailedToYou,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontWeight: FontWeight.w400,
                        fontSize: 14,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    trailing: Checkbox(
                      value: checkBoxTweetsEmailedToYou,
                      onChanged: !checkBoxEmailNotifications ? null :(value) {
                        checkBoxTweetsEmailedToYou = value;
                        setState(() {});
                        updateNotificationsSettings();
                      },
                      checkColor: Colors.white,
                      activeColor: MyColors.werfieBlue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5)),
                    ),
                    contentPadding: EdgeInsets.only(right: 10, left: 15),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 15.0, right: 10, top: 15),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Strings.topWerfs,
                            style: TextStyle(
                                fontSize: 14,
                                color: Colors.black,
                                fontWeight: FontWeight.w600),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            children: [
                              Text(
                                Strings.daily,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                              Spacer(),
                              Radio(
                                value: 0,
                                activeColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : MyColors.werfieBlue,
                                groupValue: radioGroupTopWerfs,
                                onChanged: !checkBoxEmailNotifications ? null :_handleTopWerfsRadioValueChange,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                Strings.weekly,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                              Spacer(),
                              new Radio(
                                value: 1,
                                activeColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : MyColors.werfieBlue,
                                groupValue: radioGroupTopWerfs,
                                onChanged: !checkBoxEmailNotifications ? null : _handleTopWerfsRadioValueChange,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              new Text(
                                Strings.off,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 14,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                              Spacer(),
                              new Radio(
                                value: 2,
                                activeColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : MyColors.werfieBlue,
                                groupValue: radioGroupTopWerfs,
                                onChanged: !checkBoxEmailNotifications ? null : _handleTopWerfsRadioValueChange,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    height: 1,
                    color: Colors.grey[300],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  fromWerfie(),
                  SizedBox(
                    height: 10,
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  fromWerfie() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 15.0),
          child: Text(
            Strings.fromWerfie,
            style: TextStyle(
                fontSize: 18, color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(
          height: 15,
        ),
        ListTile(
          title: Text(
            Strings.newAboutWerfieProduct,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxNewsAboutWerfie,
            onChanged: !checkBoxEmailNotifications ? null : (value) {
              setState(() {
                checkBoxNewsAboutWerfie = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.tipsOnGettingMoreOut,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxTips,
            onChanged: !checkBoxEmailNotifications ? null :(value) {
              setState(() {
                checkBoxTips = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.thingsYouMissedSinceYou,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value:  checkBoxThingsYouMissed,
            onChanged:!checkBoxEmailNotifications ? null : (value) {
              setState(() {
                checkBoxThingsYouMissed = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.participationInWerfieResearchSurveys,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxResearchSurveys,
            onChanged: !checkBoxEmailNotifications ? null : (value) {
              setState(() {
                checkBoxResearchSurveys = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.suggestionsRorRecommendedAccounts,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxSuggestionsForAccounts,
            onChanged: !checkBoxEmailNotifications ? null : (value) {
              setState(() {
                checkBoxSuggestionsForAccounts = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
        SizedBox(
          height: 10,
        ),
        ListTile(
          title: Text(
            Strings.suggestionsBasedOnYourRecentFollows,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 14 : 12,
            ),
          ),
          trailing: Checkbox(
            value: checkBoxSuggestionsRecentFollows,
            onChanged: !checkBoxEmailNotifications ? null : (value) {
              setState(() {
                checkBoxSuggestionsRecentFollows = value;
              });
              updateNotificationsSettings();
            },
            checkColor: Colors.white,
            activeColor: MyColors.werfieBlue,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          ),
          contentPadding: EdgeInsets.only(right: 10, left: 15),
        ),
      ],
    );
  }

  void _handleTopWerfsRadioValueChange(int value) {
    radioGroupTopWerfs = value;

    switch (radioGroupTopWerfs) {
      case 0:
        selectedValueTopWerfs = "daily";

        break;
      case 1:
        selectedValueTopWerfs = "weekly";

        break;
      case 2:
        selectedValueTopWerfs = "off";
        break;
    }

    updateDailyDigest();
    setState(() {});
  }

  checkSelectedDigest() async {
    if (storage.read("user_profile") == null) {
      DialogBuilder(context).showLoadingIndicator();
      await controller.getUserProfile();
      DialogBuilder(context).hideOpenDialog();
      readDigestFromStorage();
    } else {
      readDigestFromStorage();
    }
  }

  readDigestFromStorage() {
    String userData = storage.read("user_profile");
    UserProfile userProfile = UserProfile.fromJson(jsonDecode(userData));

    //LoggingUtils.printValue("DIGEST TYPE", userProfile.toJson());

    switch (userProfile.digestType ??= "off") {
      case "daily":
        radioGroupTopWerfs = 0;
        break;
      case "weekly":
        radioGroupTopWerfs = 1;

        break;
      case "off":
        radioGroupTopWerfs = 2;
        break;
      default:
        radioGroupTopWerfs = 2;
        break;
    }

    setState(() {});
  }

  updateDailyDigest() async {
    DialogBuilder(context).showLoadingIndicator();
    bool isSuccess = await UpdateDailyDigestAPI()
        .update(selectedValueTopWerfs.toLowerCase());

    DialogBuilder(context).hideOpenDialog();
    controller.getUserProfile();
  }
}
