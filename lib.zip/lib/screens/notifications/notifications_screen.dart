import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/screens/notifications/filters_screen.dart';
import 'package:werfieapp/screens/notifications/notification_prefrences_screen.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../network/controller/NotificationsSettingsController.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../network/controller/update_daily_digest_api.dart';
import '../../utils/font.dart';

class NotificationsScreen extends StatefulWidget {
  NotificationsScreen({Key key}) : super(key: key);

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final controller = Get.find<NewsfeedController>();
  int radioGroupValue = 2;
  String selectedValue = 'off';
  final storage = GetStorage();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.put(NotificationSettingsController());
      //checkSelectedDigest();
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    centerTitle: true,
                    title: Text(
                      Strings.emailNotification,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 20,
                      ),
                    ),
                    leading: !kIsWeb
                        ? MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                                onTap: () {
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isTranslations = false;
                                  controller.isLanguageSettings = true;
                                  controller.isLanguageType = false;
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isNotificationsSettings = false;
                                  if (!kIsWeb) {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    Navigator.of(context).pop();
                                  }
                                  controller.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                          )
                        : SizedBox(),
                  )
                : PreferredSize(
                    child: Container(),
                    preferredSize: Size(0, 0),
                  ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 12,
                            ),
                            child: Row(
                              children: [
                                MediaQuery.of(context).size.width >= 1050
                                    ? SizedBox()
                                    : MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () {
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isTranslations = false;
                                            controller.isLanguageSettings =
                                                true;
                                            controller.isSettingDetail = true;
                                            controller.isSettingTypeDetail =
                                                false;
                                            controller.isLanguageType = false;
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isChangeUserName = false;
                                            controller.isYourAccount = false;
                                            controller.isNotificationsSettings =
                                                false;

                                            controller.update();
                                          },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                          ),
                                        ),
                                      ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      Strings.emailNotification,
                                      textAlign: TextAlign.left,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    kIsWeb
                        ? Container(
                            height: 1,
                            color: Colors.grey[300],
                          )
                        : SizedBox(),
                    ListTile(
                      leading: Image.asset(
                        "assets/settings_icons/filters.png",
                        width: 30,
                        height: 30,
                        color:Theme.of(context).brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black ,
                      ),
                      title: Text(
                        Strings.filters,
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.chooseTheNotification,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      trailing: Icon(Icons.arrow_forward_ios_rounded,
                          color: Colors.black),
                      onTap: () {
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isChangeUserName = false;
                        controller.isYourAccount = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isAccountInformation = false;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isNotificationsSettings = false;
                        controller.isNotificationsFiltersScreen = true;
                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FiltersScreen()))
                            : Container();
                      },
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.phonelink_ring_rounded,
                        size: 30,
                        color: Theme.of(context).brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                      title: Text(
                        Strings.preferences,
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.selectYourPreferencesByNotificationType,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      trailing: Icon(Icons.arrow_forward_ios_rounded,
                          color: Colors.black),
                      onTap: (){
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isChangeUserName = false;
                        controller.isYourAccount = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isAccountInformation = false;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isNotificationsSettings = false;
                        controller.isNotificationsFiltersScreen = false;
                        controller.isNotificationPreferencesScreen = true;
                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    NotificationPreferencesScreen()))
                            : Container();
                      },
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10),
                      child: Column(
                        children: [
                         /* Padding(
                            padding: EdgeInsets.only(
                                right: controller.languageData.appLang.id == 2
                                    ? 15.0
                                    : 0),
                            child: Row(
                              children: [
                                Text(
                                  Strings.pushNotifications,
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize: kIsWeb ? 16 : 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                                Spacer(),
                                Switch(
                                    value: controller.notificationStatus,
                                    activeColor: controller.displayColor,
                                    onChanged: (value) async {
                                      print(value.toString());
                                      if (value == true) {
                                        print("true aya");
                                        controller.notificationStatus = value;
                                        controller.storage
                                            .write("notificationAllowed", 1);
                                        controller.update();
                                        await controller.snoozeNotification(1);
                                      } else if (value == false) {
                                        print("false aya");
                                        controller.notificationStatus = value;
                                        controller.storage
                                            .write("notificationAllowed", 0);
                                        controller.update();

                                        await controller.snoozeNotification(0);
                                      }
                                    }),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 25,
                          ),*/
                         /* Text(
                            "Get emails to find out what’s going on when you’re not on Werfie. You can turn them off anytime.",
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey[500]),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: new Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Top Werfs",
                                  style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      Strings.daily,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                    Spacer(),
                                    Radio(
                                      value: 0,
                                      activeColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                      groupValue: radioGroupValue,
                                      onChanged: _handleRadioValueChange,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      Strings.weekly,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                    Spacer(),
                                    new Radio(
                                      value: 1,
                                      activeColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                      groupValue: radioGroupValue,
                                      onChanged: _handleRadioValueChange,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    new Text(
                                      Strings.off,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                    Spacer(),
                                    new Radio(
                                      value: 2,
                                      activeColor:
                                          Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                      groupValue: radioGroupValue,
                                      onChanged: _handleRadioValueChange,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),*/
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ));
      },
    );
  }

 /* void _handleRadioValueChange(int value) {
    radioGroupValue = value;

    switch (radioGroupValue) {
      case 0:
        selectedValue = "daily";

        break;
      case 1:
        selectedValue = "weekly";

        break;
      case 2:
        selectedValue = "off";
        break;
    }
    updateDailyDigest();
    setState(() {});
  }

  checkSelectedDigest() async {
    if (storage.read("user_profile") == null) {
      DialogBuilder(context).showLoadingIndicator();
      await controller.getUserProfile();
      DialogBuilder(context).hideOpenDialog();
      readDigestFromStorage();
    } else {
      readDigestFromStorage();
    }
  }

  readDigestFromStorage() {
    String userData = storage.read("user_profile");
    UserProfile userProfile = UserProfile.fromJson(jsonDecode(userData));

    LoggingUtils.printValue("DIGEST TYPE", userProfile.toJson());

    *//*if(userProfile.digestType == null){
      radioGroupValue = 2;
    }else if(userProfile.digestType == "daily"){
      radioGroupValue = 0;
    }else if(userProfile.digestType == "weekly"){
      radioGroupValue = 1;
    }else if(userProfile.digestType == "off"){
      radioGroupValue = 2;
    }*//*

    switch (userProfile.digestType ??= "off") {
      case "daily":
        radioGroupValue = 0;
        break;
      case "weekly":
        radioGroupValue = 1;

        break;
      case "off":
        radioGroupValue = 2;
        break;
      default:
        radioGroupValue = 2;
        break;
    }

    setState(() {});
  }

  updateDailyDigest() async {
    DialogBuilder(context).showLoadingIndicator();
    bool isSuccess =
        await UpdateDailyDigestAPI().update(selectedValue.toLowerCase());

    DialogBuilder(context).hideOpenDialog();
    controller.getUserProfile();
  }*/
}
