import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/apis/get_notifications_filters.dart';
import 'package:werfieapp/network/controller/NotificationsSettingsController.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/screens/notifications/muted_notifications.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../../utils/font.dart';
import '../../utils/loading_dialog_builder.dart';

class FiltersScreen extends StatefulWidget {
  FiltersScreen();

  @override
  State<FiltersScreen> createState() => _FiltersScreenState();
}

class _FiltersScreenState extends State<FiltersScreen> {
  final controller = Get.find<NewsfeedController>();


  final notificationSettingsController = Get.find<NotificationSettingsController>();
  bool qualityFilterCheckBoxValue = true;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (notificationSettingsController.notificationsFilterResponse == null) {
        getNotificationsFilter();
      } else {
        qualityFilterCheckBoxValue = notificationSettingsController
                    .notificationsFilterResponse.data.qualityFilter ==
                1
            ? true
            : false ?? false;
        setState(() {});
      }
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    Strings.filters,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: Column(
        children: [
          !kIsWeb
              ? Container()
              : Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 12.0,
                    horizontal: 12,
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            controller.isNotificationsFiltersScreen = false;
                            controller.isNotificationsSettings = true;
                            controller.update();
                          },
                          icon: Icon(Icons.arrow_back),
                        ),
                        Text(
                          Strings.filters,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.normal),
                        ),
                      ],
                    ),
                  ),
                ),
          Container(
            height: 1,
            color: Colors.grey[300],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            Strings.chooseTheNotification ,
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
          SizedBox(
            height: 15,
          ),
          ListTile(
            title: Text(
             Strings.qualityFilters,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            subtitle: Text(
            Strings.chooseToFilterOutContentSuchAsDuplicateAndAutomatedWerfs,
              style: TextStyle(fontSize: 12, color: Colors.grey[500]),
            ),
            trailing: Checkbox(
              value: qualityFilterCheckBoxValue,
              onChanged: (value) {
                qualityFilterCheckBoxValue = value;
                setState(() {});
                getNotificationsFilter(showLoader: false, action: "update",isQualityFilter: true);
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.mutedNotification,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 16 : 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            trailing:
                Icon(Icons.arrow_forward_ios_rounded, color: Colors.black),
            onTap: () {
              controller.isListOfBlockedAccounts = false;
              controller.isTranslations = false;
              controller.isLanguageSettings = false;
              controller.isChangeUserName = false;
              controller.isYourAccount = false;
              controller.isLanguageType = false;
              controller.isAccountPrivacy = false;
              controller.isSettingDetail = false;
              controller.isSettingTypeDetail = true;
              controller.isProfileLanguagetype = false;
              controller.isAccountPrivacySettings = false;
              controller.isAccountInformation = false;
              controller.isChangeUserName = false;
              controller.isChangeEmail = false;
              controller.isChangeCountry = false;
              controller.isSettinggender = false;
              controller.isNotificationsSettings = false;
              controller.isNotificationsFiltersScreen = false;
              controller.isEmailNotificationScreen = false;
              controller.isMutedNotificationsScreen = true;
              controller.update();
              !kIsWeb
                  ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              MutedNotificationsScreen()))
                  : Container();
            },
          ),
        ],
      ),
    );
  }

  getNotificationsFilter(
      {String action = "read",
      bool isQualityFilter = false,
      bool showLoader = true}) async {
    if (showLoader) DialogBuilder(context).showLoadingIndicator();

    await NotificationsFiltersAPI().Filters(action,
        qualityFilter: qualityFilterCheckBoxValue == true ? 1 : 0,
        isQualityFilter: isQualityFilter);
    qualityFilterCheckBoxValue = notificationSettingsController
                .notificationsFilterResponse.data.qualityFilter ==
            1
        ? true
        : false;
    setState(() {});

    if (showLoader) DialogBuilder(context).hideOpenDialog();
  }
}
