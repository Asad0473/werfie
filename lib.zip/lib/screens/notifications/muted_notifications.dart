import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../../network/apis/get_notifications_filters.dart';
import '../../network/controller/NotificationsSettingsController.dart';
import '../../utils/font.dart';
import '../../utils/loading_dialog_builder.dart';

class MutedNotificationsScreen extends StatefulWidget {
  MutedNotificationsScreen();

  @override
  State<MutedNotificationsScreen> createState() =>
      _MutedNotificationsScreenState();
}

class _MutedNotificationsScreenState extends State<MutedNotificationsScreen> {
  final controller = Get.find<NewsfeedController>();
  final notificationSettingsController =
      Get.find<NotificationSettingsController>();

  bool checkBoxYouDontFollow = false;
  bool checkBoxWhoYouDontFollow = false;
  bool checkBoxWithNewAccount = false;
  bool checkBoxDefaultProfile = false;
  bool checkBoxConfirmedEmail = false;
  bool checkBoxConfirmedPhone = false;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (notificationSettingsController.notificationsFilterResponse == null) {
        getNotificationsFilter(action: "read");
      } else {
        setValues();
      }
    });
    super.initState();
  }

  setValues() {
    checkBoxYouDontFollow = notificationSettingsController
                .notificationsFilterResponse.data.youDontFollow ==
            1
        ? true
        : false ?? false;
    checkBoxWhoYouDontFollow = notificationSettingsController
                .notificationsFilterResponse.data.whoDontFollowYou ==
            1
        ? true
        : false ?? false;
    checkBoxWithNewAccount = notificationSettingsController
                .notificationsFilterResponse.data.withNewAccount ==
            1
        ? true
        : false ?? false;
    checkBoxDefaultProfile = notificationSettingsController
                .notificationsFilterResponse.data.defaultPhotoUsers ==
            1
        ? true
        : false ?? false;
    checkBoxConfirmedEmail = notificationSettingsController
                .notificationsFilterResponse.data.emailNotConfirmedUsers ==
            1
        ? true
        : false ?? false;
    checkBoxConfirmedPhone = notificationSettingsController
                .notificationsFilterResponse.data.phoneNotConfirmedUsers ==
            1
        ? true
        : false ?? false;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                  Strings.mutedNotification,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: Column(
        children: [
          !kIsWeb
              ? Container()
              : Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 12.0,
                    horizontal: 12,
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            controller.isNotificationsFiltersScreen = true;
                            controller.isMutedNotificationsScreen = false;
                            controller.update();
                          },
                          icon: Icon(Icons.arrow_back),
                        ),
                        Text(
                          Strings.mutedNotification,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.normal),
                        ),
                      ],
                    ),
                  ),
                ),
          Container(
            height: 1,
            color: Colors.grey[300],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            Strings.muteNotificationsFromPeople,
            style: TextStyle(
                fontSize: 16, color: Colors.black, fontWeight: FontWeight.bold),
          ),
          SizedBox(
            height: 15,
          ),
          ListTile(
            title: Text(
              Strings.youDoNotFollow,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxYouDontFollow,
              onChanged: (value) {
                setState(() {
                  checkBoxYouDontFollow = value;
                  notificationSettingsController.notificationsFilterResponse.data.youDontFollow = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });

              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
             Strings.whoDoNotFollowYou,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxWhoYouDontFollow,
              onChanged: (value) {
                setState(() {
                  checkBoxWhoYouDontFollow = value;
                  notificationSettingsController.notificationsFilterResponse.data.whoDontFollowYou = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.withANewAccount,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxWithNewAccount,
              onChanged: (value) {
                setState(() {
                  checkBoxWithNewAccount = value;
                  notificationSettingsController.notificationsFilterResponse.data.withNewAccount = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.whoHaveDefaultProfilePhoto,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxDefaultProfile,
              onChanged: (value) {
                setState(() {
                  checkBoxDefaultProfile = value;
                  notificationSettingsController.notificationsFilterResponse.data.defaultPhotoUsers = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.whoHaveNotConfirmedTheirEmail,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxConfirmedEmail,
              onChanged: (value) {
                setState(() {
                  checkBoxConfirmedEmail = value;
                  notificationSettingsController.notificationsFilterResponse.data.emailNotConfirmedUsers = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.whoHaveNotConfirmedTheirPhoneNumber,
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            trailing: Checkbox(
              value: checkBoxConfirmedPhone,
              onChanged: (value) {
                setState(() {
                  checkBoxConfirmedPhone = value;
                  notificationSettingsController.notificationsFilterResponse.data.phoneNotConfirmedUsers = value == true ?1 :0;
                  getNotificationsFilter(showLoader: false);
                });
              },
              checkColor: Colors.white,
              activeColor: MyColors.werfieBlue,
            ),
          ),
          SizedBox(
            height: 10,
          ),
        ],
      ),
    );
  }

  getNotificationsFilter(
      {String action = "update", bool showLoader = true}) async {
    if (showLoader) DialogBuilder(context).showLoadingIndicator();

    if (action == "update") {
      await NotificationsFiltersAPI().Filters(action,
          youDontFollow: checkBoxYouDontFollow == true ? 1 : 0,
          whoDontFollowYou: checkBoxWhoYouDontFollow == true ? 1 : 0,
          withNewAccount: checkBoxWithNewAccount == true ? 1 : 0,
          defaultPhotoUsers: checkBoxDefaultProfile == true ? 1 : 0,
          emailNotConfirmedUsers: checkBoxConfirmedEmail == true ? 1 : 0,
          phoneNotConfirmedUsers: checkBoxConfirmedPhone == true ? 1 : 0);
    } else {
      await NotificationsFiltersAPI().Filters(action);
    }
    if (showLoader) DialogBuilder(context).hideOpenDialog();
  }
}
