import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/screens/notifications/email_notifications_screen.dart';
import 'package:werfieapp/screens/notifications/muted_notifications.dart';
import 'package:werfieapp/screens/notifications/push_notifications_screen.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../../utils/font.dart';

class NotificationPreferencesScreen extends StatefulWidget {

  NotificationPreferencesScreen();

  @override
  State<NotificationPreferencesScreen> createState() => _NotificationPreferencesScreenState();
}

class _NotificationPreferencesScreenState extends State<NotificationPreferencesScreen> {
  final controller = Get.find<NewsfeedController>();
  bool qualityFilterCheckBoxValue = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    Strings.preferences,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: Column(
        children: [
          !kIsWeb
              ? Container()
              : Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 12.0,
                    horizontal: 12,
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            controller.isNotificationPreferencesScreen = false;
                            controller.isNotificationsSettings = true;
                            controller.update();
                          },
                          icon: Icon(
                              Icons.arrow_back,
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,

                          ),
                        ),
                        Text(
                          Strings.preferences,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.normal),
                        ),
                      ],
                    ),
                  ),
                ),
          Container(
            height: 1,
            color: Colors.grey[300],
          ),
          SizedBox(
            height: 10,
          ),
          Text(
          Strings.selectYourPreferencesByNotificationType,
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
          SizedBox(
            height: 15,
          ),
          ListTile(
            title: Text(
              Strings.pushNotifications,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 16 : 14,
                fontWeight: FontWeight.w500,
              ),
            ),

            trailing: Icon(Icons.arrow_forward_ios_rounded,
                color: Colors.black),
            onTap: () {
              controller.isListOfBlockedAccounts = false;
              controller.isTranslations = false;
              controller.isLanguageSettings = false;
              controller.isChangeUserName = false;
              controller.isYourAccount = false;
              controller.isLanguageType = false;
              controller.isAccountPrivacy = false;
              controller.isSettingDetail = false;
              controller.isSettingTypeDetail = false;
              controller.isProfileLanguagetype = false;
              controller.isAccountPrivacySettings = false;
              controller.isAccountInformation = false;
              controller.isChangeUserName = false;
              controller.isChangeEmail = false;
              controller.isChangeCountry = false;
              controller.isSettinggender = false;
              controller.isNotificationsSettings = false;
              controller.isNotificationsFiltersScreen = false;
              controller.isMutedNotificationsScreen = false;
              controller.isNotificationPreferencesScreen = false;
              controller.isEmailNotificationScreen = false;
              controller.isPushNotificationScreen = true;
              controller.update();
              !kIsWeb
                  ? Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (BuildContext context) => PushNotificationsScreen()))
                  : Container();
            },
          ),
          SizedBox(
            height: 10,
          ),
          ListTile(
            title: Text(
              Strings.emailNotification,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 16 : 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            trailing:
                Icon(Icons.arrow_forward_ios_rounded, color: Colors.black),
            onTap: () {
              controller.isListOfBlockedAccounts = false;
              controller.isTranslations = false;
              controller.isLanguageSettings = false;
              controller.isChangeUserName = false;
              controller.isYourAccount = false;
              controller.isLanguageType = false;
              controller.isAccountPrivacy = false;
              controller.isSettingDetail = false;
              controller.isSettingTypeDetail = false;
              controller.isProfileLanguagetype = false;
              controller.isAccountPrivacySettings = false;
              controller.isAccountInformation = false;
              controller.isChangeUserName = false;
              controller.isChangeEmail = false;
              controller.isChangeCountry = false;
              controller.isSettinggender = false;
              controller.isNotificationsSettings = false;
              controller.isNotificationsFiltersScreen = false;
              controller.isMutedNotificationsScreen = false;
              controller.isNotificationPreferencesScreen = false;
              controller.isPushNotificationScreen = false;
              controller.isEmailNotificationScreen = true;
              controller.update();
              !kIsWeb
                  ? Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => EmailNotificationsScreen()))
                  : Container();
            },
          ),
        ],
      ),
    );
  }
}
