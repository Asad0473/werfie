
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
// import 'package:image_picker_web/image_picker_web.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/list_model.dart';
import 'package:werfieapp/network/controller/List_controller.dart';
import 'package:werfieapp/screens/dicover_list_post_screen.dart';
import 'package:werfieapp/screens/editpinnedlistscreen.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/screens/suggested_list_screen.dart';
import 'package:werfieapp/utils/metaTags/MetaTags.dart';
import 'package:werfieapp/utils/strings.dart';

import '../constants/responsive.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/loading_dialog_builder.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../web_views/web_main_screen.dart';
import 'creat_newlist_screen_widget.dart';
import 'list_as_member_screen.dart';
import 'main_screen.dart';

class ListScreen extends StatefulWidget {
  const ListScreen({Key key, this.controller}) : super(key: key);

  final NewsfeedController controller;

  @override
  State<ListScreen> createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  Uint8List pickedAudio;
  bool isMediaUploading = false;
  String imageThumbnail = '';
  List imageThumbnailsList = [];
  List<Uint8List> _pickedImage = [];

  bool isMediaAttached = false;
  bool checkLocation = false;
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;
  final DummyData dataController = Get.find();
  String crateId;
  String listId;

  String nameList;

  @override
  Widget build(BuildContext context) {
    NewsfeedController newsfeedController = Get.put((NewsfeedController()));
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
          onWillPop: () async {
            widget.controller.isBrowseScreen = false;
            widget.controller.isNewsFeedScreen = true;
            widget.controller.isTrendsScreen = false;
            widget.controller.isWhoToFollowScreen = false;
            widget.controller.isNotificationScreen = false;
            widget.controller.isChatScreen = false;
            widget.controller.isSavedPostScreen = false;
            widget.controller.isProfileScreen = false;
            widget.controller.isSettingsScreen = false;
            widget.controller.isListScreen = true;

            widget.controller.update();
            Navigator.pop(context);
            return false;
          },
          child: MobileListScreen(
            newsfeedController: widget.controller,
          ),
        ),
        tablet: MobileListScreen(
          newsfeedController: widget.controller,
        ),
        desktop: MobileListScreen(
          newsfeedController: widget.controller,
        ),
      ),
    );
  }
}

class MobileListScreen extends StatefulWidget {
  const MobileListScreen({Key key, this.newsfeedController}) : super(key: key);

  final NewsfeedController newsfeedController;

  @override
  State<MobileListScreen> createState() => _MobileListScreenState();
}

class _MobileListScreenState extends State<MobileListScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey =  GlobalKey<ScaffoldState>();

  final newsController = Get.put(NewsfeedController());
  final DummyData dataController = Get.find();
  final imagePicker = ImagePicker();
  int indexOfList;

  Uint8List profileImage;

  Uint8List imageFile;

  List<DiscoverListElement> dataList = [];
  List pinPostList = [];
  List editPostList = [];
  String _selectedMenu = '';

  // File imageFile;
  String list_Id;
  int list_id;
  bool isFollow = false;

  int followId;
  bool isPin = false;
  bool isHover = false;
  bool percentageButton = false;
  bool allUnitButton = false;

  bool imageAvailable = false;
  String crateId;
  int listId;
  String nameList;
  final storage = GetStorage();
  investTrust(index) {
    switch (index) {
      case 0:
        {
          setState(() {
            percentageButton = true;
            allUnitButton = false;
          });
          break;
        }
      case 1:
        {
          setState(() {
            percentageButton = false;
            allUnitButton = true;
          });
          break;
        }
    }
  }

  Future<Uint8List> callGetImage() async {
    Uint8List image;
    var img = await dataController.getImage();
    image = await img.readAsBytes();
    getFromGallery() async {
      PickedFile pickedFile = await ImagePicker().getImage(
        source: ImageSource.gallery,
        maxWidth: 1800,
        maxHeight: 1800,
      );
      if (pickedFile != null) {
        setState(() {
          // imageFile = File(pickedFile.path);
        });
      }
    }

    return image;
  }

  Color getColor(Set<MaterialState> states) {
    const Set<MaterialState> interactiveStates = <MaterialState>{
      MaterialState.pressed,
      MaterialState.hovered,
      MaterialState.focused,
    };
    if (states.any(interactiveStates.contains)) {
      return Colors.blue;
    }
    return Colors.red;
  }

  @override
  void initState() {
addListMetaTags();
    super.initState();
  }

  addListMetaTags(){

    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleLists,
        metaTagDescription:MetaTagValues.listsMetaDescription,
        metaTagKeywords: MetaTagValues.listsMetaKeywords,
        ogTitle: MetaTagValues.listsOGTitle,
        ogDescription: MetaTagValues.listsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(
        init: ListController(),
        builder: (controller) {
          return controller.isDiscoverLoading
              ? const Center(
                  child: CircularProgressIndicator(
                  color: MyColors.BlueColor,
                ))
              : GestureDetector(
                  onTap: () {
                    controller.isSearch = false;
                    controller.searchResult = [];
                    controller.update();
                  },
                  child: Scaffold(
                    floatingActionButton:!kIsWeb? GestureDetector(
                      onTap: (){
                        Get.to(const CreateNewList());
                      },
                      child: const CircleAvatar(
                        child: Icon(Icons.add),
                      ),
                    ):null,
                      appBar: kIsWeb
                          ? PreferredSize(
                              preferredSize: const Size(double.infinity, 60),
                              child: ListTile(
                               /* leading: IconButton(
                                    onPressed: () {
                                      onHomeChange = true;
                                      onBrowsChange = false;
                                      onTrendsChange = false;
                                      onBookMarksChange = false;
                                      onChatsChange = false;
                                      onProfileChange = false;
                                      onSettingChange = false;
                                      onListChange = false;
                                      onNotificationChange = false;
                                      onMoreChange = false;
                                      onMomentChange = false;

                                      controller.newsfeedController.isTrendsScreen = false;
                                      controller.newsfeedController.isNewsFeedScreen = true;
                                      controller.newsfeedController.isBrowseScreen = false;
                                      controller.newsfeedController.isNotificationScreen = false;
                                      controller.newsfeedController.isChatScreen = false;
                                      controller.newsfeedController.isSavedPostScreen = false;
                                      controller.newsfeedController.isPostDetails = false;
                                      controller.newsfeedController.isProfileScreen = false;
                                      controller.newsfeedController.isOtherUserProfileScreen = false;
                                      controller.newsfeedController.isTopicScreen = false;
                                      controller.newsfeedController.isListScreen = false;
                                      controller.newsfeedController.isMainTopicScreen = false;
                                      controller.newsfeedController.isListDetailScreen=false;
                                      controller.newsfeedController.update();

                                      Get.back();
                                    },
                                    icon: Icon(
                                      Icons.arrow_back,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    )),*/
                                title: Text(
                                  Strings.list,
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                  // Theme.of(context).textTheme.headline6.copyWith(fontSize: 18,
                                  //   // fontWeight: FontWeight.w900,
                                  //   color: Colors.black,
                                  // ),
                                ),
                                subtitle: Text(
                                    "@${controller.storage.read("userName")}",
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontSize: kIsWeb ? 14 : 12,
                                    )
                                    // TextStyle(
                                    //     fontSize: kIsWeb ? 18.0 : 14.0,color: Colors.black38
                                    // ),
                                    ),
                                trailing: Wrap(
                                  spacing: 12, // space between two icons
                                  children: <Widget>[
                                    IconButton(
                                        onPressed: () {
                                          if (kIsWeb) {
                                            showDialog<String>(
                                              context: context,
                                              builder: (BuildContext context) =>
                                                  AlertDialog(
                                                contentPadding:
                                                    const EdgeInsets.fromLTRB(
                                                        0.0, 0.0, 0.0, 0.0),
                                                content: StatefulBuilder(
                                                    builder: (context,
                                                        StateSetter setState) {
                                                  return SizedBox(
                                                    height: Get.height * 0.70,
                                                    width: 600,
                                                    child: const CreateNewList(),
                                                    // Column(
                                                    //   children: [
                                                    //     ListTile(
                                                    //         leading:
                                                    //         IconButton(
                                                    //             onPressed:
                                                    //                 () {
                                                    //               SingleTone
                                                    //                   .instance
                                                    //                   .selectedLocation =
                                                    //               null;
                                                    //               setState(() {});
                                                    //               Navigator.of(
                                                    //                   context)
                                                    //                   .pop();
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //             },
                                                    //             icon:
                                                    //             Icon(
                                                    //               Icons.close,
                                                    //               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //             )),
                                                    //         title: Text(
                                                    //           'Create New List',
                                                    //           style:
                                                    //           Styles.baseTextTheme.headline2.copyWith(
                                                    //             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //             fontWeight: FontWeight.bold,
                                                    //           ),
                                                    //           // TextStyle(
                                                    //           //     fontSize: 14),
                                                    //         ),
                                                    //         trailing:
                                                    //         MaterialButton(
                                                    //           shape: RoundedRectangleBorder(
                                                    //               borderRadius:
                                                    //               BorderRadius.circular(15)),
                                                    //           color:controller.userNameController.text.isNotEmpty?MyColors.werfieBlue: Colors.grey[500],
                                                    //           // background
                                                    //           textColor: Colors.white,
                                                    //           // foreground
                                                    //           onPressed: () async{
                                                    //
                                                    //
                                                    //
                                                    //             print("hello");
                                                    //
                                                    //
                                                    //             if( controller.userNameController.text.isNotEmpty)
                                                    //             {
                                                    //               DataListCreated data= await controller.createList(
                                                    //                   isChecked: controller.isChecked,
                                                    //                   type: "create",
                                                    //                   CoverImageBytes: controller.coverImage
                                                    //               );
                                                    //               if(data != null){
                                                    //                 nameList=data.name;
                                                    //                 crateId=data.id.toString();
                                                    //                 Navigator.pop(context);
                                                    //                 controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
                                                    //               }
                                                    //               showDialog<String>(
                                                    //                 context: context,
                                                    //                 builder: (BuildContext context) =>
                                                    //
                                                    //                     GetBuilder<ListController>(
                                                    //                       assignId: true,
                                                    //                       id: "edit_suggestion",
                                                    //                       builder: (controller) =>
                                                    //                           AlertDialog(
                                                    //                               contentPadding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                                                    //                               content: Container(
                                                    //                                 height: Get.height * 0.70,
                                                    //                                 width: Get.width * 0.45,
                                                    //                                 child: SingleChildScrollView(
                                                    //                                   child: Column(
                                                    //                                     children: [
                                                    //                                       ListTile(
                                                    //                                         // leading: IconButton(
                                                    //                                         //     onPressed: () {
                                                    //                                         //       // SingleTone.instance.selectedLocation = null;
                                                    //                                         //       setState(() {});
                                                    //                                         //       Navigator.of(context).pop();
                                                    //                                         //     },
                                                    //                                         //     icon: Icon(
                                                    //                                         //       Icons.close,
                                                    //                                         //       color: Colors.black87,
                                                    //                                         //     )),
                                                    //                                           title: Text(
                                                    //                                             'Add To Your List',
                                                    //                                             style:
                                                    //                                             Styles.baseTextTheme.headline2.copyWith(
                                                    //                                               color: Theme.of(context).brightness == Brightness.dark
                                                    //                                                   ? Colors.white
                                                    //                                                   : Colors.black,
                                                    //                                               fontWeight: FontWeight.bold,
                                                    //                                             ),
                                                    //                                           ),
                                                    //                                           trailing: MaterialButton(
                                                    //                                             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                                                    //                                             color: Colors.grey[500],
                                                    //                                             // backgroundRtab
                                                    //                                             textColor: Colors.white,
                                                    //                                             // foreground
                                                    //                                             onPressed: () async{
                                                    //                                               print("list create button");
                                                    //                                               controller.selectedList = await controller.listDetail(listId : data.id);
                                                    //                                               // Navigator.pop(context);
                                                    //
                                                    //                                               controller.newsfeedController.isListDetailScreen = true;
                                                    //                                               controller.newsfeedController.isSearch = false;
                                                    //                                               controller.newsfeedController.isFilter = false;
                                                    //                                               controller.newsfeedController.isFilterScreen = false;
                                                    //                                               controller.newsfeedController.isTrendsScreen = false;
                                                    //                                               controller.newsfeedController.isNewsFeedScreen = false;
                                                    //                                               controller.newsfeedController.isBrowseScreen = false;
                                                    //                                               controller.newsfeedController.isNotificationScreen = false;
                                                    //                                               controller.newsfeedController.isWhoToFollowScreen = false;
                                                    //                                               controller.newsfeedController.isSavedPostScreen = false;
                                                    //                                               controller.newsfeedController.isChatScreen = false;
                                                    //                                               controller.newsfeedController.isPostDetails = false;
                                                    //                                               controller.newsfeedController.isProfileScreen = false;
                                                    //                                               controller.newsfeedController.searchText.text = '';
                                                    //                                               controller.newsfeedController.isListScreen = false;
                                                    //                                               controller.newsfeedController.isFollwerScreen = false;
                                                    //                                               controller.newsfeedController.isSettingsScreen = false;
                                                    //                                               controller.newsfeedController.navRoute = "isChatScreen";
                                                    //                                               controller.newsfeedController.update();
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //                                               controller.update();
                                                    //
                                                    //                                               controller.newsfeedController.update();
                                                    //                                               Navigator.pop(context);
                                                    //                                             },
                                                    //                                             child: Text('Done'),
                                                    //                                           )),
                                                    //                                       Container(
                                                    //                                         child: SingleChildScrollView(
                                                    //                                           child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
                                                    //                                             SizedBox(height: 20.0),
                                                    //                                             DefaultTabController(
                                                    //                                                 length: 2, // length of tabs
                                                    //                                                 initialIndex: 1,
                                                    //                                                 child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
                                                    //                                                   Container(
                                                    //                                                     child: TabBar(
                                                    //                                                       labelColor: Colors.blue,
                                                    //                                                       unselectedLabelColor: Colors.black,
                                                    //                                                       tabs: [
                                                    //                                                         Tab(text: 'Members ${controller.addMemberList.length}'),
                                                    //                                                         Tab(text: 'Sugge'
                                                    //                                                             'sted'),
                                                    //                                                       ],
                                                    //                                                     ),
                                                    //                                                   ),
                                                    //                                                   Container(
                                                    //                                                       height: Get.height,
                                                    //                                                       //height of TabBarView
                                                    //                                                       decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey, width: 0.5))),
                                                    //                                                       child: TabBarView(children: <Widget>[
                                                    //                                                         Container(
                                                    //                                                           height: Get.width*0.27,
                                                    //                                                           child:  SingleChildScrollView(
                                                    //                                                             child: Column(
                                                    //                                                               children: List.generate(
                                                    //                                                                   controller.addMemberList.length,
                                                    //                                                                       (index) => ListTile(
                                                    //                                                                     leading: Container(
                                                    //                                                                       height: 40,
                                                    //                                                                       width: 40,
                                                    //                                                                       decoration: BoxDecoration(
                                                    //                                                                         color: Colors.grey,
                                                    //                                                                         borderRadius: BorderRadius.circular(10),
                                                    //                                                                         image: DecorationImage(
                                                    //                                                                           image: NetworkImage(
                                                    //                                                                               controller.addMemberList[index].authorProfileImage == null
                                                    //                                                                                   ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                                    //                                                                                   : controller.addMemberList[index].authorProfileImage),
                                                    //                                                                           fit: BoxFit.fill,
                                                    //                                                                         ),
                                                    //                                                                       ),
                                                    //                                                                     ),
                                                    //                                                                     title: Text(controller.addMemberList[index].authorName,
                                                    //                                                                       style: Styles.baseTextTheme.headline1.copyWith(
                                                    //                                                                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                                                                         fontSize: 14,
                                                    //                                                                       ),
                                                    //                                                                     ),
                                                    //                                                                     subtitle: Row(
                                                    //                                                                       children: [
                                                    //                                                                         Text(
                                                    //                                                                           "@"+controller.addMemberList[index].username,
                                                    //                                                                           style: Styles.baseTextTheme.headline2.copyWith(
                                                    //                                                                             fontSize: 12,
                                                    //                                                                           ),
                                                    //                                                                         ),
                                                    //                                                                         // SizedBox(
                                                    //                                                                         //   width: 4,
                                                    //                                                                         // ),
                                                    //                                                                         // Text(controller.addMemberList[index].username),
                                                    //                                                                       ],
                                                    //                                                                     ),
                                                    //                                                                     // trailing: ElevatedButton(
                                                    //                                                                     //     style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), primary:  Colors.blueAccent ),
                                                    //                                                                     //     onPressed:
                                                    //                                                                     //
                                                    //                                                                     //     //     :
                                                    //                                                                     //         () {
                                                    //                                                                     //       setState(() {
                                                    //                                                                     //         // isFollow = false;
                                                    //                                                                     //
                                                    //                                                                     //         print("index >>>>>>>>>>>>>>>>>>>>>>>>$index");
                                                    //                                                                     //
                                                    //                                                                     //         controller.addMemberList.removeAt(index);
                                                    //                                                                     //
                                                    //                                                                     //         controller.modelSuggestList.forEach((element) {
                                                    //                                                                     //           if(element.id == controller.addMemberList[index].id){
                                                    //                                                                     //             element.isFollow = false;
                                                    //                                                                     //           }
                                                    //                                                                     //         });
                                                    //                                                                     //
                                                    //                                                                     //
                                                    //                                                                     //         controller.update();
                                                    //                                                                     //         controller.update(["edit_suggestion"]);
                                                    //                                                                     //         // controller.deletePost(controller.addMemberList[index].id);
                                                    //                                                                     //         // dataList.remove(
                                                    //                                                                     //         //     controller.  listOfDiscover[index]);
                                                    //                                                                     //       });
                                                    //                                                                     //       controller.update();
                                                    //                                                                     //       controller.update(["edit_suggestion"]);
                                                    //                                                                     //       controller.unFollowRemoveMethod(list_Id:data.id.toString(), member_id:controller.addMemberList[index].id.toString(),type:"member");
                                                    //                                                                     //       // controller.addMemberList.removeAt(i);
                                                    //                                                                     //     },
                                                    //                                                                     //     child:
                                                    //                                                                     //     // isFollow == false
                                                    //                                                                     //     //     ? Text(
                                                    //                                                                     //     //   "Add",
                                                    //                                                                     //     //   style: Theme.of(context).textTheme.headline6.copyWith(
                                                    //                                                                     //     //     fontSize: 14,
                                                    //                                                                     //     //     fontWeight: FontWeight.w700,
                                                    //                                                                     //     //     color: Colors.white,
                                                    //                                                                     //     //   ),
                                                    //                                                                     //     // )
                                                    //                                                                     //     //     :
                                                    //                                                                     //     Text(
                                                    //                                                                     //       "Remove",
                                                    //                                                                     //       style: Theme.of(context).textTheme.headline6.copyWith(
                                                    //                                                                     //         fontSize: 14,
                                                    //                                                                     //         fontWeight: FontWeight.w700,
                                                    //                                                                     //         color: Colors.white,
                                                    //                                                                     //       ),
                                                    //                                                                     //     ))
                                                    //                                                                   )),
                                                    //                                                             ),
                                                    //                                                           ),
                                                    //                                                         ),
                                                    //                                                         Container(
                                                    //                                                           child: SingleChildScrollView(
                                                    //                                                             child: Column(
                                                    //                                                               children: [
                                                    //                                                                 Padding(
                                                    //                                                                   padding: EdgeInsets.only(top: 10, right: 10, bottom: 10, left: 10),
                                                    //                                                                   child: TextField(
                                                    //                                                                     autofocus: true,
                                                    //                                                                     // controller: controller.chatSearchTEC,
                                                    //                                                                     // focusNode: controller.chatSearchTextFocus,
                                                    //                                                                     onChanged: (value) async {
                                                    //                                                                       controller.modelSuggestList = await controller.SuggestedPost(list_Id: data.id.toString(),name:value);
                                                    //                                                                     },
                                                    //                                                                     textAlignVertical: TextAlignVertical.center,
                                                    //                                                                     decoration: InputDecoration(
                                                    //                                                                       hintText: Strings.searchPeople,
                                                    //                                                                       hintStyle: TextStyle(
                                                    //                                                                         fontSize: 16,
                                                    //                                                                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                                                                       ),
                                                    //                                                                       prefixIcon: Icon(Icons.search, size: 16),
                                                    //                                                                       border: OutlineInputBorder(
                                                    //                                                                         borderRadius: BorderRadius.circular(40),
                                                    //                                                                         borderSide: BorderSide(
                                                    //                                                                           width: 2,
                                                    //                                                                           style: BorderStyle.none,
                                                    //                                                                         ),
                                                    //                                                                       ),
                                                    //                                                                       enabledBorder: OutlineInputBorder(
                                                    //                                                                         borderRadius: BorderRadius.circular(40),
                                                    //                                                                         borderSide: BorderSide(
                                                    //                                                                           width: 2,
                                                    //                                                                           style: BorderStyle.none,
                                                    //                                                                         ),
                                                    //                                                                       ),
                                                    //                                                                       fillColor: Colors.grey[250],
                                                    //                                                                     ),
                                                    //                                                                   ),
                                                    //                                                                 ),
                                                    //
                                                    //                                                                 SizedBox(
                                                    //                                                                   height:kIsWeb? MediaQuery
                                                    //                                                                       .of(
                                                    //                                                                       context)
                                                    //                                                                       .size
                                                    //                                                                       .height : MediaQuery
                                                    //                                                                       .of(
                                                    //                                                                       context)
                                                    //                                                                       .size
                                                    //                                                                       .height ,
                                                    //                                                                   width: Get.width ,
                                                    //                                                                   child: controller.modelSuggestList.isEmpty || controller.modelSuggestList == null?Center(child: Padding(
                                                    //                                                                     padding: const EdgeInsets.only(top:20.0),
                                                    //                                                                     child: Text("No results"),
                                                    //                                                                   ),) :SingleChildScrollView(child:Column(
                                                    //                                                                     children: List.generate(
                                                    //                                                                         controller.modelSuggestList.length,
                                                    //                                                                             (index) => ListTile(
                                                    //                                                                             leading: Container(
                                                    //                                                                               height: 40,
                                                    //                                                                               width: 40,
                                                    //                                                                               decoration: BoxDecoration(
                                                    //                                                                                   color: Colors.grey,
                                                    //                                                                                   borderRadius: BorderRadius.circular(10),
                                                    //                                                                                   image: DecorationImage(
                                                    //                                                                                       image: NetworkImage(
                                                    //                                                                                           controller.modelSuggestList[index].authorProfileImage==null?
                                                    //                                                                                           "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                    //                                                                                               : controller.modelSuggestList[index].authorProfileImage
                                                    //                                                                                       ), fit: BoxFit.fill)),
                                                    //                                                                             ),
                                                    //                                                                             title: Text(
                                                    //                                                                               controller.modelSuggestList[index].authorName,
                                                    //                                                                               style: Styles.baseTextTheme.headline1.copyWith(
                                                    //                                                                                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                                                                                 fontSize: 14,
                                                    //                                                                               ),
                                                    //                                                                             ),
                                                    //                                                                             subtitle: Row(
                                                    //                                                                               children: [
                                                    //                                                                                 Text("@"+controller.modelSuggestList[index].username,
                                                    //                                                                                   style: Styles.baseTextTheme.headline2.copyWith(
                                                    //                                                                                     fontSize: 12,
                                                    //                                                                                   ),
                                                    //                                                                                 ),
                                                    //                                                                                 // SizedBox(
                                                    //                                                                                 //   width: 4,
                                                    //                                                                                 // ),
                                                    //                                                                                 // Text(controller.modelSuggestList[index].username),
                                                    //                                                                               ],
                                                    //                                                                             ),
                                                    //                                                                             trailing:
                                                    //                                                                             ElevatedButton(
                                                    //                                                                                 style: ElevatedButton.styleFrom(
                                                    //                                                                                   shape: RoundedRectangleBorder(
                                                    //                                                                                       borderRadius: BorderRadius.circular(30)
                                                    //                                                                                   ),
                                                    //                                                                                   primary: Theme.of(context).brightness == Brightness.dark ?!controller.modelSuggestList[index].isFollow ? Colors.white : Colors.black: !controller.modelSuggestList[index].isFollow ? Colors.black : Colors.white,
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //                                                                                   // controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30),
                                                    //                                                                                 ),
                                                    //                                                                                 onPressed: controller.modelSuggestList[index].isFollow == false ?
                                                    //                                                                                     () async{
                                                    //
                                                    //                                                                                   controller.modelSuggestList[index].isFollow = true;
                                                    //                                                                                   controller.addMemberList.add(controller.modelSuggestList[index]);
                                                    //
                                                    //                                                                                   controller.update(["edit_suggestion"]);
                                                    //                                                                                   controller.update();
                                                    //                                                                                   print("list  fllow suggestion id check ${controller.modelSuggestList[index].id}");
                                                    //                                                                                   print("list  fllow data id check ${data.id}");
                                                    //                                                                                   controller.memberAdd(data.id.toString(), controller.modelSuggestList[index].id,"member");
                                                    //
                                                    //                                                                                 }
                                                    //                                                                                     : () {
                                                    //
                                                    //                                                                                   controller.modelSuggestList[index].isFollow == false;
                                                    //
                                                    //                                                                                   controller.modelSuggestList.forEach((element) {
                                                    //                                                                                     if(element.id == controller.modelSuggestList[index].id ){
                                                    //                                                                                       element.isFollow = false;
                                                    //                                                                                     }
                                                    //                                                                                   });
                                                    //                                                                                   for(int i=0; i< controller.addMemberList.length; i++  ){
                                                    //                                                                                     if(controller.addMemberList[i].id == controller.modelSuggestList[index].id){
                                                    //                                                                                       controller.addMemberList.removeAt(i);
                                                    //                                                                                     }
                                                    //                                                                                   }
                                                    //                                                                                   controller.update(["edit_suggestion"]);
                                                    //                                                                                   controller.update();
                                                    //
                                                    //                                                                                   controller.deletePost(controller.modelSuggestList[index].id);
                                                    //                                                                                   // dataList.remove(
                                                    //                                                                                   //     controller.  listOfDiscover[index]);
                                                    //
                                                    //
                                                    //                                                                                   controller.update(["edit_suggestion"]);
                                                    //                                                                                   controller.update();
                                                    //                                                                                   print("list  unfllow suggestion id check ${controller.modelSuggestList[index].id}");
                                                    //                                                                                   print("list  unfllow data id check ${data.id}");
                                                    //                                                                                   controller.unFollowRemoveMethod( list_Id:data.id.toString(),
                                                    //                                                                                       member_id:controller.modelSuggestList[index].id.toString(),type:"member");
                                                    //                                                                                 },
                                                    //                                                                                 child: controller.modelSuggestList[index].isFollow == false
                                                    //                                                                                     ? Text(
                                                    //                                                                                     "Add",
                                                    //                                                                                     style: Styles.baseTextTheme.headline1.copyWith(
                                                    //                                                                                       fontSize: 14,
                                                    //                                                                                       color: Theme.of(context).brightness == Brightness.dark ?Colors.black:Colors.white,
                                                    //                                                                                     )
                                                    //                                                                                   // Theme.of(context).textTheme.headline6.copyWith(
                                                    //                                                                                   //   fontSize: 14,
                                                    //                                                                                   //   fontWeight: FontWeight.w700,
                                                    //                                                                                   //   color: Colors.white,
                                                    //                                                                                   // ),
                                                    //                                                                                 )
                                                    //                                                                                     : Text(
                                                    //                                                                                   "Remove",
                                                    //                                                                                   style: Styles.baseTextTheme.headline1.copyWith(
                                                    //                                                                                     fontSize: 14,
                                                    //                                                                                     color: Theme.of(context).brightness == Brightness.dark ?Colors.white:Colors.black,
                                                    //                                                                                   ),
                                                    //                                                                                   // Theme.of(context).textTheme.headline6.copyWith(
                                                    //                                                                                   //   fontSize: 14,
                                                    //                                                                                   //   fontWeight: FontWeight.w700,
                                                    //                                                                                   //   color: Colors.white,
                                                    //                                                                                   // ),
                                                    //                                                                                 ))
                                                    //
                                                    //                                                                         )),
                                                    //                                                                   )),
                                                    //                                                                 ),
                                                    //                                                               ],
                                                    //                                                             ),
                                                    //                                                           ),
                                                    //                                                         ),
                                                    //                                                       ]))
                                                    //                                                 ])),
                                                    //                                           ]),
                                                    //                                         ),
                                                    //                                       ),
                                                    //                                     ],
                                                    //                                   ),
                                                    //                                 ),
                                                    //                               )),
                                                    //                     ),
                                                    //               );
                                                    //
                                                    //
                                                    //             }
                                                    //
                                                    //           },
                                                    //           child: Text(
                                                    //               'Next'),
                                                    //         )
                                                    //     ),
                                                    //     SizedBox(
                                                    //       height: Get.height * 0.60,
                                                    //
                                                    //       child: SingleChildScrollView(
                                                    //         child: Column(
                                                    //           children: [
                                                    //             Padding(
                                                    //                 padding:
                                                    //                 const EdgeInsets
                                                    //                     .only(
                                                    //                     left: 2,
                                                    //                     right:
                                                    //                     2),
                                                    //                 child:
                                                    //                 Container(
                                                    //                   width: Get.width,
                                                    //                   height: Get.height * 0.25,
                                                    //                   decoration: BoxDecoration(
                                                    //                       color: Colors.grey[500]
                                                    //                   ),
                                                    //                   child: imageAvailable == false ? Center(
                                                    //                       child:
                                                    //                       CircleAvatar(radius: 30,
                                                    //                         backgroundColor:
                                                    //                         Colors.black54,
                                                    //                         child:
                                                    //                         ///firstcamera fault
                                                    //                         IconButton(
                                                    //
                                                    //
                                                    //                           onPressed: () async {
                                                    //
                                                    //                             controller.coverImage = await controller.callGetImage();
                                                    //
                                                    //                             print("controller.coverImage ${controller.coverImage}");
                                                    //
                                                    //                             controller.update();
                                                    //
                                                    //
                                                    //                             setState(() {
                                                    //                               imageAvailable = true;
                                                    //                               // // imageFile = image as Uint8List;
                                                    //                             });
                                                    //
                                                    //
                                                    //
                                                    //                           },
                                                    //                           icon:
                                                    //                           Icon(
                                                    //                             Icons
                                                    //                                 .camera_alt,
                                                    //                             color: Colors
                                                    //                                 .white,
                                                    //                           ),
                                                    //                           splashColor:
                                                    //                           Colors
                                                    //                               .black,
                                                    //                         ),
                                                    //
                                                    //                       )
                                                    //
                                                    //
                                                    //                   )
                                                    //                       : Stack(
                                                    //                       children: [
                                                    //
                                                    //
                                                    //                         Container(height:Get.height,width:Get.width,
                                                    //                           child: controller.coverImage != null
                                                    //                               ? Image.memory(
                                                    //                             controller.coverImage,
                                                    //                             fit: BoxFit.cover,
                                                    //                           )
                                                    //                               : Image.asset(
                                                    //                             'assets/images/person_placeholder.png',
                                                    //                             fit: BoxFit.cover,
                                                    //                           ),
                                                    //
                                                    //                         ),
                                                    //                         Positioned(
                                                    //                           top: 0,
                                                    //                           right: 0,
                                                    //                           child: Padding(
                                                    //                               padding:  EdgeInsets.all(8.0),
                                                    //                               child: Row(
                                                    //                                 children: [
                                                    //                                   Card(
                                                    //                                       color: Colors.black26,
                                                    //                                       shape: RoundedRectangleBorder(
                                                    //                                         borderRadius: BorderRadius.circular(80),
                                                    //                                       ),
                                                    //                                       child: Center(child: IconButton(onPressed: () async {
                                                    //
                                                    //                                         ///2ndcamera fault
                                                    //
                                                    //                                         controller.coverImage = await controller.callGetImage();
                                                    //
                                                    //
                                                    //                                         setState;
                                                    //                                         setState(() {
                                                    //                                           imageAvailable = true;
                                                    //                                         });
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //                                       }, icon: Icon(Icons.camera_alt,color: Colors.white,size: 25,)))
                                                    //                                   ),
                                                    //                                   SizedBox(width: 10,),
                                                    //                                   Card(
                                                    //                                       color: Colors.black26,
                                                    //                                       shape: RoundedRectangleBorder(
                                                    //                                         borderRadius: BorderRadius.circular(80),
                                                    //                                       ),
                                                    //                                       child: Center(child: IconButton(onPressed: ()  {
                                                    //
                                                    //
                                                    //                                         setState;
                                                    //                                         setState(() {
                                                    //                                           imageAvailable = false;controller.coverImage = null;
                                                    //                                         });
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //
                                                    //                                       }, icon: Icon(Icons.close,color: Colors.white,size: 25,)))
                                                    //                                   ),
                                                    //                                 ],
                                                    //                               )
                                                    //                           ),),
                                                    //                       ] ),
                                                    //                 )
                                                    //
                                                    //             ),
                                                    //
                                                    //             SizedBox(
                                                    //               height: 20,
                                                    //             ),
                                                    //             CustomFormField(
                                                    //               label: "Name",
                                                    //               controller: controller.userNameController,
                                                    //               onChange: (value) {
                                                    //                 // controller.userNameController.text = value;
                                                    //
                                                    //                 setState(() { });
                                                    //                 // if(controller.userNameController.text.length>0)
                                                    //                 //   {
                                                    //                 //
                                                    //                 //
                                                    //                 //   }
                                                    //                 // else if(controller.userNameController.text.length == 0)
                                                    //                 //   {
                                                    //                 //
                                                    //                 //     setState(() { });
                                                    //                 //
                                                    //                 //   }
                                                    //
                                                    //
                                                    //                 controller.update();
                                                    //               },
                                                    //             ),
                                                    //             SizedBox(
                                                    //               height: 20,
                                                    //             ),
                                                    //             Padding(
                                                    //               padding:
                                                    //               const EdgeInsets
                                                    //                   .only(
                                                    //                   left:
                                                    //                   15,
                                                    //                   right:
                                                    //                   15),
                                                    //               child: SizedBox(
                                                    //                 height: 130,
                                                    //                 child:
                                                    //                 TextFormField(
                                                    //                   style: Styles.baseTextTheme.headline2.copyWith(
                                                    //                     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                     fontWeight: FontWeight.w500,
                                                    //                     fontSize: kIsWeb ? 16 : 14,
                                                    //                   ),
                                                    //                   controller:
                                                    //                   controller
                                                    //                       .descriptionController,
                                                    //                   onChanged:
                                                    //                       (value) {
                                                    //                     // value = controller
                                                    //                     // .descriptionController
                                                    //                     // .text  ;
                                                    //                     controller
                                                    //                         .update();
                                                    //                   },
                                                    //                   maxLines: 2,
                                                    //                   maxLength:
                                                    //                   100,
                                                    //                   decoration: InputDecoration(
                                                    //                     border: OutlineInputBorder(
                                                    //                         borderRadius: BorderRadius
                                                    //                             .circular(
                                                    //                             10)),
                                                    //                     contentPadding: const EdgeInsets
                                                    //                         .only(
                                                    //                         bottom: 30,
                                                    //                         top: 10,
                                                    //                         left: 15,
                                                    //                         right: 5),
                                                    //                     focusedBorder: const OutlineInputBorder(
                                                    //                         borderSide: BorderSide(
                                                    //                           color:
                                                    //                           Colors
                                                    //                               .blue,
                                                    //                         )),
                                                    //                     filled: true,
                                                    //                     label: Text(
                                                    //                       "Descriptions",
                                                    //                       style: Styles.baseTextTheme.headline2.copyWith(
                                                    //                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                         fontWeight: FontWeight.w500,
                                                    //                         fontSize: kIsWeb ? 16 : 14,
                                                    //                       ),
                                                    //
                                                    //                     ),
                                                    //                     hintStyle:
                                                    //                     Styles.baseTextTheme.headline2.copyWith(
                                                    //                       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                       fontWeight: FontWeight.w500,
                                                    //                       fontSize: kIsWeb ? 16 : 14,
                                                    //                     ),
                                                    //                     fillColor: Colors.white,
                                                    //                   ),
                                                    //                   cursorColor:
                                                    //                   Colors
                                                    //                       .blue,
                                                    //                 ),
                                                    //               ),
                                                    //             ),
                                                    //             ListTile(
                                                    //               trailing:
                                                    //               CheckBoxList(),
                                                    //               title: Text(
                                                    //                   Strings
                                                    //                       .private,
                                                    //                   style: Styles.baseTextTheme.headline1.copyWith(
                                                    //                     fontSize: 16,
                                                    //                     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                   )
                                                    //                 // Theme.of(context).textTheme.headline6.copyWith(
                                                    //                 //   fontSize: 16,
                                                    //                 //   fontWeight: FontWeight.w800,
                                                    //                 //   color: Colors.black,
                                                    //                 // ),
                                                    //               ),
                                                    //               subtitle: Text(
                                                    //                 "When you make a List private, only you can see it.",
                                                    //                 style: Styles.baseTextTheme.headline2.copyWith(
                                                    //                   fontSize: 14,
                                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    //                 ),
                                                    //                 // Theme
                                                    //                 //     .of(
                                                    //                 //     context)
                                                    //                 //     .textTheme
                                                    //                 //     .headline6
                                                    //                 //     .copyWith(
                                                    //                 //   fontSize:
                                                    //                 //   16,
                                                    //                 //   fontWeight:
                                                    //                 //   FontWeight
                                                    //                 //       .w800,
                                                    //                 //   color: Colors
                                                    //                 //       .black26,
                                                    //                 // ),
                                                    //               ),
                                                    //             ),
                                                    //           ],),
                                                    //       ),
                                                    //     )
                                                    //
                                                    //   ],
                                                    // ),
                                                  );
                                                }),
                                              ),
                                            );
                                          } else {
                                            Get.to(const CreateNewList());
                                          }
                                        },
                                        icon: Icon(
                                          Icons.list_alt,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        )),
                                    PopupMenuButton(
                                      // padding: EdgeInsets.only(top: 35),
                                      child: Icon(
                                        Icons.more_horiz,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        size: 30,
                                      ),
                                      itemBuilder: (BuildContext context) {
                                        return [
                                          PopupMenuItem(
                                            child: GestureDetector(
                                              onTap: (){
                                                {
                                                  {
                                                    print("List membership");
                                                    onHomeChange = false;
                                                    onBrowsChange = false;
                                                    onTrendsChange = false;
                                                    onBookMarksChange = false;
                                                    onChatsChange = false;
                                                    onProfileChange = false;
                                                    onSettingChange = false;
                                                    onListChange = false;
                                                    onNotificationChange = false;
                                                    onMoreChange = false;
                                                    onMomentChange = false;

                                                    controller.newsfeedController.isSearch = false;
                                                    controller.newsfeedController.isFilter = false;
                                                    controller.newsfeedController.isFilterScreen = false;
                                                    controller.newsfeedController.isTrendsScreen = false;
                                                    controller.newsfeedController.isNewsFeedScreen = false;
                                                    controller.newsfeedController.isBrowseScreen = false;
                                                    controller.newsfeedController.isNotificationScreen = false;
                                                    controller.newsfeedController.isWhoToFollowScreen = false;
                                                    controller.newsfeedController.isSavedPostScreen = false;
                                                    controller.newsfeedController.isChatScreen = false;
                                                    controller.newsfeedController.isPostDetails = false;
                                                    controller.newsfeedController.isProfileScreen = false;
                                                    controller.newsfeedController.searchText.text = '';
                                                    controller.newsfeedController.isListScreen = false;
                                                    controller.newsfeedController.isFollwerScreen = false;
                                                    controller.newsfeedController.isSettingsScreen = false;
                                                    controller.newsfeedController.navRoute = "isListMemberships";
                                                    controller.newsfeedController.isListDetailScreen = false;
                                                    controller.newsfeedController.isListMemberShipScreen=true;
                                                    controller.newsfeedController.update();
                                                    Get.toNamed(FluroRouters.mainScreen +'/ListMemberships' );
                                                  }


                                                }
                                              },
                                              child: Row(
                                                children: [
                                                  IconButton(
                                                      onPressed: () {},
                                                      icon: Icon(
                                                        Icons.list_alt,
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )),
                                                  Text(Strings.listYouAreON,
                                                      style: Styles
                                                          .baseTextTheme.headline4
                                                          .copyWith(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )
                                                      // TextStyle(
                                                      //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white :Colors.black,
                                                      // ),
                                                      ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ];
                                      },
                                    ), // icon-2
                                  ],
                                ),
                              ))
                          : AppBar(
                              elevation: 0.0,
                              backgroundColor: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.black
                                  : Colors.white,
                              leading: IconButton(
                                  onPressed: () {
                                   /* onHomeChange = true;
                                    onBrowsChange = false;
                                    onTrendsChange = false;
                                    onBookMarksChange = false;
                                    onChatsChange = false;
                                    onProfileChange = false;
                                    onSettingChange = false;
                                    onListChange = false;
                                    onNotificationChange = false;
                                    onMoreChange = false;
                                    onMomentChange = false;

                                    controller.newsfeedController
                                        .isTrendsScreen = false;
                                    controller.newsfeedController
                                        .isNewsFeedScreen = true;
                                    controller.newsfeedController
                                        .isBrowseScreen = false;
                                    controller.newsfeedController
                                        .isNotificationScreen = false;
                                    controller.newsfeedController.isChatScreen =
                                        false;
                                    controller.newsfeedController
                                        .isSavedPostScreen = false;
                                    controller.newsfeedController
                                        .isPostDetails = false;
                                    controller.newsfeedController
                                        .isProfileScreen = false;
                                    controller.newsfeedController
                                        .isOtherUserProfileScreen = false;
                                    controller.newsfeedController
                                        .isTopicScreen = false;
                                    controller.newsfeedController.isListScreen =
                                        false;
                                    controller.newsfeedController
                                        .isMainTopicScreen = false;
                                    controller.newsfeedController.update();*/

                                    Get.offAll(() => Session());
                                  },
                                  icon: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  )),
                              title: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    Strings.list,
                                    style:
                                        Styles.baseTextTheme.headline1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Text(
                                      "@${controller.storage.read("userName")}",
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontSize: kIsWeb ? 14 : 12,
                                      )
                                    ,
                                      ),
                                ],
                              ),
                              actions: [
                                IconButton(
                                    onPressed: () {
                                      if (kIsWeb) {
                                        showDialog<String>(
                                          context: context,
                                          builder: (BuildContext context) =>
                                              AlertDialog(
                                            contentPadding:
                                                const EdgeInsets.fromLTRB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            content: StatefulBuilder(builder:
                                                (context,
                                                    StateSetter setState) {
                                              return SizedBox(
                                                height: Get.height * 0.70,
                                                width: Get.width * 0.45,
                                                child:  const CreateNewList(),

                                              );
                                            }),
                                          ),
                                        );
                                      } else {
                                        Get.to(const CreateNewList());
                                      }
                                    },
                                    icon: Icon(
                                      Icons.list_alt,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    )),
                                PopupMenuButton(
                                  // padding: EdgeInsets.only(top: 35),
                                  child: Icon(
                                    Icons.more_horiz,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    size: 30,
                                  ),
                                  itemBuilder: (BuildContext context) {
                                    return [
                                      PopupMenuItem(
                                        child: GestureDetector(
                                          onTap: (){
                                            Navigator.push(context,
                                              MaterialPageRoute(
                                                builder: (BuildContext context) =>
                                                    ListAsMemberScreen(),
                                              ),
                                            );
                                          },
                                          child: Row(
                                            children: [
                                              IconButton(
                                                  onPressed: () {

                                                  },
                                                  icon: Icon(
                                                    Icons.list_alt,
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )),
                                              Text(Strings.listYouAreON,
                                                  style: Styles
                                                      .baseTextTheme.headline4
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  )
                                                  // TextStyle(
                                                  //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white :Colors.black,
                                                  // ),
                                                  ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ];
                                  },
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                              ],
                            ),
                      body: CustomScrollView(
                        controller: ScrollController(),
                        slivers:[
                          SliverToBoxAdapter(
                            child:   Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            FittedBox(
                                              child: Text(
                                                Strings.pinnedList,
                                                style: Styles
                                                    .baseTextTheme.headline2
                                                    .copyWith(
                                                  color: Theme.of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontWeight: FontWeight.bold,
                                                ),

                                              ),
                                            ),
                                            FittedBox(
                                              child: controller.listModel.data.pinnedLists.isEmpty
                                                  ? null
                                                  : InkWell(
                                                onTap: () {
                                                  if (kIsWeb) {
                                                    showDialog<String>(
                                                      context: context,

                                                      builder: (BuildContext
                                                      context) =>
                                                          AlertDialog(
                                                              contentPadding:
                                                              const EdgeInsets.fromLTRB(
                                                                  0.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                              content:
                                                              Container(
                                                                height:
                                                                500,
                                                                width:
                                                                500,
                                                                child:
                                                                const EditPinnedList(),
                                                              )),
                                                    );
                                                  } else {
                                                    Get.to(
                                                        const EditPinnedList());
                                                  }
                                                },
                                                child: Text(
                                                  Strings.edit,
                                                  style: Styles
                                                      .baseTextTheme
                                                      .headline2
                                                      .copyWith(
                                                    color: controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    fontWeight:
                                                    FontWeight.bold,
                                                    fontSize:
                                                    kIsWeb ? 16 : 14,
                                                  ),

                                                ),
                                              ),
                                            ),
                                          ]),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      /// pin list
                                      SizedBox(
                                          height: Get.height * .20,
                                          child:
                                          controller.listModel.data.pinnedLists.isEmpty
                                              ? Align(
                                            alignment: Alignment
                                                .bottomCenter,
                                            child: Text(
                                              Strings.nothingToSeeHerePinYour,
                                              style: Styles
                                                  .baseTextTheme
                                                  .headline2
                                                  .copyWith(
                                                color: Theme.of(context)
                                                    .brightness ==
                                                    Brightness
                                                        .dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),

                                            ),
                                          )
                                          /// pined list
                                              : SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Row(
                                              children: List.generate(
                                                  controller.listModel.data.pinnedLists.length,
                                                      (index) => Padding(
                                                    padding: const EdgeInsets
                                                        .only(
                                                        left: 20),
                                                    child:
                                                    InkWell(
                                                      onTap:
                                                          () async {
                                                        if (kIsWeb) {
                                                          // controller.list = controller.listModel.data.pinnedLists[index];
                                                          storage.write("pinIndex",controller.listModel.data.pinnedLists[index]);
                                                          storage.write("clickId", 1);
                                                          // controller.selectedList =
                                                          // await controller.listDetail(listId: controller.listModel.data.pinnedLists[index].id);
                                                          storage.write("pinId",controller.listModel.data.pinnedLists[index].id);
                                                          controller.newsfeedController.isListDetailScreen = true;
                                                          controller.newsfeedController.isSearch = false;
                                                          controller.newsfeedController.isFilter = false;
                                                          controller.newsfeedController.isFilterScreen = false;
                                                          controller.newsfeedController.isTrendsScreen = false;
                                                          controller.newsfeedController.isNewsFeedScreen = false;
                                                          controller.newsfeedController.isBrowseScreen = false;
                                                          controller.newsfeedController.isNotificationScreen = false;
                                                          controller.newsfeedController.isWhoToFollowScreen = false;
                                                          controller.newsfeedController.isSavedPostScreen = false;
                                                          controller.newsfeedController.isChatScreen = false;
                                                          controller.newsfeedController.isPostDetails = false;
                                                          controller.newsfeedController.isProfileScreen = false;
                                                          controller.newsfeedController.searchText.text = '';
                                                          controller.newsfeedController.isListScreen = false;
                                                          controller.newsfeedController.isFollwerScreen = false;
                                                          controller.newsfeedController.isSettingsScreen = false;
                                                          controller.newsfeedController.navRoute = "isDetailScreen";


                                                          controller.newsfeedController.update();
                                                          print("pintIndex1: ${storage.read("pinIndex")}");
                                                          print("printpinId2:${storage.read("pinId")}");
                                                          Get.toNamed(FluroRouters.mainScreen + "/listDetail/" +controller.listModel.data.pinnedLists[index].id.toString());

                                                        } else {

                                                          Navigator.push(context,
                                                            MaterialPageRoute(
                                                              builder: (BuildContext context) =>
                                                                  DiscoverListScreen(
                                                                    controller: controller.newsfeedController,
                                                                    index: index.toString(),
                                                                    clickId: 1,
                                                                    listId:  controller.listModel.data.pinnedLists[index].id,

                                                                  ),
                                                            ),
                                                          );
                                                          // controller.selectedList = await controller.listDetail(listId: controller.listModel.data.lists[index].id);
                                                        }
                                                      },
                                                      child:
                                                      Column(

                                                        children: [
                                                          MouseRegion(
                                                            onHover:
                                                                (f) {
                                                              setState(() {
                                                                isHover = true;
                                                              });
                                                            },
                                                            onExit:
                                                                (f) {
                                                              setState(() {
                                                                isHover = false;
                                                              });
                                                            },
                                                            child:
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Colors.blue,
                                                                  borderRadius: BorderRadius.circular(10),
                                                                  image: DecorationImage(image: NetworkImage(controller.listModel.data.pinnedLists[index].coverImage ??
                                                                      "https://complete.network/wp-content/uploads/default-avatar-photo-placeholder-profile-picture-vector-21806614.jpg"), fit: BoxFit.fill)),
                                                              height: kIsWeb
                                                                  ? Get.height * 0.12
                                                                  : 60,
                                                              width: kIsWeb
                                                                  ? Get.height * 0.12
                                                                  : 60,
                                                            ),
                                                          ),
                                                          Column(
                                                          //  crossAxisAlignment:  CrossAxisAlignment.start,
                                                            children: [
                                                              Text(
                                                                controller.listModel.data.pinnedLists[index].name,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline5
                                                                .copyWith(
                                                              color: Theme.of(context).brightness ==
                                                              Brightness
                                                                  .dark
                                                              ? Colors
                                                              .white
                                                              : Colors
                                                              .black,
                                                              fontWeight:
                                                              FontWeight
                                                              .bold,
                                                            ),
                                                                ),
                                                              const SizedBox(width: 10,),
                                                              Text(
                                                                "@${controller.listModel.data.pinnedLists[index].username}",
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline5
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 14
                                                                      : 12,
                                                                  fontWeight:
                                                                  FontWeight.w400,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  )),
                                            ),
                                          )



                                      ),
                                    ],
                                  )),
                            ),
                          ),
                          SliverToBoxAdapter(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                  height: 40,
                                ),
                                const Divider(
                                  color: Colors.black12,
                                  thickness: 0.9,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 18),
                                  child: Text(
                                    Strings.discoverlist,
                                    style: Styles.baseTextTheme.headline2
                                        .copyWith(
                                      color: Theme.of(context).brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),

                                  ),
                                ),
                                const SizedBox(
                                  height: 30,
                                ),
                                /// discovers list
                                MouseRegion(
                                  cursor: SystemMouseCursors.click,
                                  child: SizedBox(
                                    height: Get.height * .25,
                                    child: controller.listModel == null
                                        ? const Center(
                                        child:
                                        CircularProgressIndicator(
                                          color: MyColors.BlueColor,
                                        ))
                                        : SingleChildScrollView(
                                      child: Column(
                                        children: List.generate(
                                            controller.listModel.data.discoverLists.length > 3
                                                ? 3
                                                : controller.listModel.data.discoverLists.length,
                                                (index) => ListTile(
                                                mouseCursor: MouseCursor.defer,
                                                onTap: () async {
                                                  if (kIsWeb) {
                                                    //  controller.list = controller.listModel.data.discoverLists[index];
                                                    storage.write("pinIndex",controller.listModel.data.discoverLists[index]);
                                                    if (controller.listModel.data.discoverLists[index].makePrivate != 1) {
                                                      // controller.selectedList = await controller.listDetail(
                                                      //     listId: controller.listModel.data.discoverLists[index].id);

                                                      storage.write("clickId", 2);
                                                      storage.write("pinId",controller.listModel.data.discoverLists[index].id);

                                                      controller.newsfeedController.isListDetailScreen = true;
                                                      controller.newsfeedController.isSearch = false;
                                                      controller.newsfeedController.isFilter = false;
                                                      controller.newsfeedController.isFilterScreen = false;
                                                      controller.newsfeedController.isTrendsScreen = false;
                                                      controller.newsfeedController.isNewsFeedScreen = false;
                                                      controller.newsfeedController.isBrowseScreen = false;
                                                      controller.newsfeedController.isNotificationScreen = false;
                                                      controller.newsfeedController.isWhoToFollowScreen = false;
                                                      controller.newsfeedController.isSavedPostScreen = false;
                                                      controller.newsfeedController.isChatScreen = false;
                                                      controller.newsfeedController.isPostDetails = false;
                                                      controller.newsfeedController.isProfileScreen = false;
                                                      controller.newsfeedController.searchText.text = '';
                                                      controller.newsfeedController.isListScreen = false;
                                                      controller.newsfeedController.isFollwerScreen = false;
                                                      controller.newsfeedController.isSettingsScreen = false;
                                                      controller.newsfeedController.navRoute = "isChatScreen";
                                                      controller.newsfeedController.update();
                                                      print("list iD?>>>>>>>>>>>>>>>>>>>>>" +
                                                          controller.listModel.data.discoverLists[index].id.toString());
                                                      Get.toNamed(FluroRouters.mainScreen + "/listDetail/" +
                                                          controller.listModel.data.discoverLists[index].id.toString());
                                                    }
                                                  } else {
                                                    //   controller.list = controller.listModel.data.discoverLists[index];
                                                    Navigator.push(context,
                                                      MaterialPageRoute(
                                                        builder: (BuildContextcontext) =>
                                                            DiscoverListScreen(
                                                              controller: controller.newsfeedController,
                                                              index: index.toString(),
                                                              clickId: 2,
                                                              listId:  controller.listModel.data.discoverLists[index].id,

                                                            ),
                                                      ),
                                                    );

                                                  }


                                                },
                                                leading: Container(
                                                  height: 50,
                                                  width: 50,
                                                  decoration: BoxDecoration(
                                                      color: Colors
                                                          .grey,
                                                      borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                          10),
                                                      image: DecorationImage(
                                                          image: NetworkImage(controller.listModel.data.discoverLists[index].coverImage ??
                                                              "https://www.challengetires.com/assets/img/placeholder.jpg"),
                                                          fit: BoxFit.fill)),
                                                ),
                                                title: Row(
                                                  children: [
                                                    Text(
                                                      controller.listModel.data.discoverLists[index].name,
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline1
                                                          .copyWith(
                                                        color: Theme.of(context)
                                                            .brightness ==
                                                            Brightness
                                                                .dark
                                                            ? Colors
                                                            .white
                                                            : Colors
                                                            .black,
                                                        fontSize: 15,
                                                      ),
                                                    ),
                                                    const SizedBox(width: 5,),
                                                    Text('2 member',
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline2
                                                          .copyWith(
                                                        fontSize:
                                                        kIsWeb
                                                            ? 14
                                                            : 12,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                                subtitle: Padding(
                                                  padding: const EdgeInsets.only(bottom: 4),
                                                  child: Row(
                                                    children: [
                                                      Row(
                                                        children: [
                                                          for (int i=0;i<3;i++)
                                                          Align(
                                                            widthFactor: 0.5,
                                                            child: Container(
                                                              height: 25,
                                                              width: 25,
                                                              decoration:  BoxDecoration(
                                                                color: Colors.white,
                                                                borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                    20),
                                                              ),
                                                              child: Container(
                                                                height: 20,
                                                                width: 20,
                                                                decoration: BoxDecoration(
                                                                    color: Colors
                                                                        .grey,
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        20),
                                                                    image: DecorationImage(
                                                                        image: NetworkImage(controller.listModel.data.discoverLists[index].coverImage ??
                                                                            "https://www.challengetires.com/assets/img/placeholder.jpg"),
                                                                        fit: BoxFit.fill)),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      const SizedBox(width: 10),
                                                      Text('2 followers',
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          fontSize:
                                                          kIsWeb
                                                              ? 14
                                                              : 12,
                                                        ),
                                                      ),
                                                      const SizedBox(width: 10,),
                                                      kIsWeb?
                                                      Text(
                                                        "@${controller.listModel.data.discoverLists[index].username}",
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          fontSize:
                                                          kIsWeb
                                                              ? 14
                                                              : 12,
                                                        ),
                                                      )
                                                      :SizedBox(
                                                        width: 120,
                                                        child:  Text(
                                                          "@${controller.listModel.data.discoverLists[index].username}",
                                                          maxLines: 1,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize:
                                                            kIsWeb
                                                                ? 14
                                                                : 12,
                                                            overflow: TextOverflow.ellipsis,

                                                          ),
                                                        ) ,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                trailing: GestureDetector(
                                                  onTap:
                                                  controller.listModel.data.discoverLists[index].isFollow == false
                                                      ? () async {
                                                    setState(() {
                                                      controller.listModel.data.discoverLists[index].isFollow = true;
                                                      controller.listModel.data.lists.add(
                                                        controller.listModel.data.discoverLists[index],
                                                      );
                                                    });
                                                    controller.update();
                                                    controller.newsfeedController.update();

                                                    controller.OnFollow(
                                                        listId: controller.listModel.data.discoverLists[index].id.toString(),
                                                        type: 'follower');
                                                  }
                                                      : () async {
                                                    setState(() {
                                                      controller.listModel.data.discoverLists[index].isFollow = false;
                                                      controller.unFollowMember(list_Id: controller.listModel.data.discoverLists[index].id.toString(), type: 'follower');
                                                      controller.listModel.data.lists.remove(
                                                        controller.listModel.data.discoverLists[index],
                                                      );
                                                      controller.update();
                                                    });
                                                    controller.update();
                                                  },

                                                  child: CircleAvatar(
                                                               backgroundColor:
                                                               Theme.of(context).brightness ==
                                                                   Brightness.dark? Colors.white
                                                                   : Colors.black,
                                                       radius: kIsWeb?20:12,
                                                      child:
                                                      controller.listModel.data.discoverLists[index].isFollow == false?
                                                       Icon(
                                                        Icons.add,
                                                      color: Theme.of(context).brightness ==
                                                          Brightness.dark? Colors.black
                                                          : Colors.white,
                                                      size: kIsWeb?20:15,
                                                      ): Icon(
                                                        Icons.check,
                                                        size: kIsWeb?20:15,
                                                        color: Theme.of(context).brightness ==
                                                            Brightness.dark? Colors.black
                                                            : Colors.white,
                                                      )

                                                  ),
                                                )

                                                )),
                                      ),
                                    ),
                                  ),
                                ),

                                kIsWeb
                                    ? InkWell(
                                  onTap: () {
                                    Get.toNamed(
                                        FluroRouters.mainScreen +
                                            "/SuggestList");
                                  },
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Padding(
                                      padding: const EdgeInsets.only(left: 18),
                                      child: Text(
                                        Strings.showMore,
                                        style: Styles
                                            .baseTextTheme.headline5
                                            .copyWith(
                                          color: Theme.of(context)
                                              .brightness ==
                                              Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                        ),

                                      ),
                                    ),
                                  ),
                                )
                                    : Padding(
                                      padding: const EdgeInsets.only(left: 18),
                                      child: InkWell(
                                  onTap: () {
                                      Get.to(SuggestedListScreen(
                                        controller: controller
                                            .newsfeedController,
                                      ));
                                      controller.update();
                                      controller.newsfeedController
                                          .update();
                                  },
                                  child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        Strings.showMore,
                                        style: Styles
                                            .baseTextTheme.headline5
                                            .copyWith(
                                          color: Theme.of(context)
                                              .brightness ==
                                              Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                  ),
                                ),
                                    ),
                                const SizedBox(
                                  height: 40,
                                ),
                                const Divider(
                                  color: Colors.black12,
                                  thickness: 0.9,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left:18),
                                  child: Text(
                                    Strings.yourlist,
                                    style: Styles.baseTextTheme.headline2
                                        .copyWith(
                                      color:
                                      Theme.of(context).brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                              ],

                            ) ,
                          ),

                          SliverList(

                              delegate: SliverChildBuilderDelegate(
                                  (BuildContext context, int index){

                                    return  controller.listModel.data.lists.isEmpty
                                        ? Align(
                                      alignment: Alignment
                                          .bottomCenter,
                                      child: Text(
                                        Strings.youHaveNotCreatedOrFollowedAnyLists,
                                        style: Styles
                                            .baseTextTheme
                                            .headline2
                                            .copyWith(
                                          color: Theme.of(context)
                                              .brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                        ),

                                      ),
                                    )
                                        :ListTile(
                                        onTap:
                                            () async {
                                          if (kIsWeb) {
                                            storage.write("pinIndex",controller.listModel.data.lists[index]);
                                            // controller.list = controller.listModel.data.lists[index];
                                            // controller.selectedList = await controller.listDetail(
                                            //     listId: controller.listModel.data.lists[index].id);
                                            storage.write("clickId", 3);
                                            storage.write("pinId",controller.listModel.data.lists[index].id);
                                            controller.newsfeedController.isListDetailScreen = true;
                                            controller.newsfeedController.isSearch = false;
                                            controller.newsfeedController.isFilter = false;
                                            controller.newsfeedController.isFilterScreen = false;
                                            controller.newsfeedController.isTrendsScreen = false;
                                            controller.newsfeedController.isNewsFeedScreen = false;
                                            controller.newsfeedController.isBrowseScreen = false;
                                            controller.newsfeedController.isNotificationScreen = false;
                                            controller.newsfeedController.isWhoToFollowScreen = false;
                                            controller.newsfeedController.isSavedPostScreen = false;
                                            controller.newsfeedController.isChatScreen = false;
                                            controller.newsfeedController.isPostDetails = false;
                                            controller.newsfeedController.isProfileScreen = false;
                                            controller.newsfeedController.searchText.text = '';
                                            controller.newsfeedController.isListScreen = false;
                                            controller.newsfeedController.isFollwerScreen = false;
                                            controller.newsfeedController.isSettingsScreen = false;
                                            controller.newsfeedController.navRoute = "isChatScreen";
                                            controller.newsfeedController.update();
                                            print("list iD?>>>>>>>>>>>>>>>>>>>>>" +
                                                controller.listModel.data.discoverLists[index].id.toString());
                                            Get.toNamed(FluroRouters.mainScreen +
                                                "/listDetail/" +controller.listModel.data.lists[index].id.toString() );
                                          } else {
                                            //   controller.list = controller.listModel.data.lists[index];
                                            Navigator
                                                .push(
                                              context,
                                              MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                    DiscoverListScreen(
                                                      controller: controller.newsfeedController,
                                                      index: index.toString(),
                                                      clickId: 3,
                                                      listId:  controller.listModel.data.lists[index].id,

                                                    ),
                                              ),
                                            );
                                            debugPrint('list id 0 ---->>> ${controller.listModel.data.lists[index].id}');

                                          }
                                        },
                                        leading:
                                        Container(
                                          height: 50,
                                          width: 50,
                                          decoration: BoxDecoration(
                                              color: Colors
                                                  .grey,
                                              borderRadius:
                                              BorderRadius.circular(
                                                  10),
                                              image: DecorationImage(
                                                  image: NetworkImage(controller.listModel.data.lists[index].coverImage ?? "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQerA4slT8egQop5xe3kcmIPmcxBTP-qo8Bjg&usqp=CAU"),
                                                  fit: BoxFit.fill)),
                                        ),
                                        title: Row(
                                          children: [
                                            Text(
                                              controller
                                                  .listModel
                                                  .data
                                                  .lists[
                                              index]
                                                  .name,
                                              style: Styles
                                                  .baseTextTheme
                                                  .headline5
                                                  .copyWith(
                                                color: Theme.of(context).brightness ==
                                                    Brightness
                                                        .dark
                                                    ? Colors
                                                    .white
                                                    : Colors
                                                    .black,
                                                fontWeight:
                                                FontWeight
                                                    .bold,
                                              ),
                                            ),
                                            const SizedBox(width: 5,),
                                            Text('2 member',
                                              style: Styles
                                                  .baseTextTheme
                                                  .headline2
                                                  .copyWith(
                                                fontSize:
                                                kIsWeb
                                                    ? 14
                                                    : 12,
                                              ),
                                            )
                                          ],
                                        ),
                                        subtitle: Padding(
                                          padding: const EdgeInsets.only(bottom: 4),
                                          child: Row(
                                            children: [
                                              Row(
                                                children: [
                                                  for (int i=0;i<3;i++)
                                                    Align(
                                                      widthFactor: 0.5,
                                                      child: Container(
                                                        height: 25,
                                                        width: 25,
                                                        decoration:  BoxDecoration(
                                                          color: Colors.white,
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              20),
                                                        ),
                                                        child: Container(
                                                          height: 20,
                                                          width: 20,
                                                          decoration: BoxDecoration(
                                                              color: Colors
                                                                  .grey,
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  20),
                                                              image: DecorationImage(
                                                                  image: NetworkImage(controller.listModel.data.lists[index].coverImage ??
                                                                      "https://www.challengetires.com/assets/img/placeholder.jpg"),
                                                                  fit: BoxFit.fill)),
                                                        ),
                                                      ),
                                                    ),
                                                ],
                                              ),
                                              const SizedBox(width: 10,),
                                              Text('2 followers',
                                                style: Styles
                                                    .baseTextTheme
                                                    .headline2
                                                    .copyWith(
                                                  fontSize:
                                                  kIsWeb
                                                      ? 14
                                                      : 12,
                                                ),
                                              ),
                                              const SizedBox(width: 10,),
                                              kIsWeb?
                                              Text(
                                                "@${controller
                                                    .listModel
                                                    .data
                                                    .lists[index]
                                                    .username}",
                                                style: Styles
                                                    .baseTextTheme
                                                    .headline5
                                                    .copyWith(
                                                  fontSize: kIsWeb
                                                      ? 14
                                                      : 12,
                                                  fontWeight:
                                                  FontWeight.w400,
                                                ),
                                              )
                                             : SizedBox(
                                                width: 120,
                                                child:  Text(

                                                  "@${controller
                                                      .listModel
                                                      .data
                                                      .lists[index]
                                                      .username}",
                                                  maxLines: 1,

                                                  style: Styles
                                                      .baseTextTheme
                                                      .headline5
                                                      .copyWith(
                                                    fontSize: kIsWeb
                                                        ? 14
                                                        : 12,
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    overflow: TextOverflow.ellipsis
                                                  ),
                                                ),
                                              )
                                              ,
                                            ],
                                          ),
                                        ),
                                        trailing:
                                        InkWell(
                                          onTap:
                                          // !controller.listModel.data.lists[index].isPin
                                          controller.listModel.data.lists[index].isPinRX.value==0
                                              ? () async {
                                            // setState(
                                            //     () {
                                            if (controller.listModel.data.pinnedLists.length <= 4) {
                                              if (controller.listModel.data.pinnedLists.contains(controller.listModel.data.lists[index])) {
                                                //   controller.listModel.data.lists[index].isPin = false;
                                                controller.listModel.data.lists[index].isPinRX.value=0;

                                                for (int i = 0; i < controller.listModel.data.pinnedLists.length; i++) {
                                                  if (controller.listModel.data.lists[index].id == controller.listModel.data.pinnedLists[i].id) {
                                                    list_Id = controller.listModel.data.lists[index].id.toString();
                                                    controller.listModel.data.pinnedLists.removeAt(i);

                                                    controller.PinUnpinPost(
                                                        list_Id: list_Id,
                                                        pin_unpin_list: '0');
                                                    newsController.getLanguages();


                                                  }
                                                }
                                              } else {
                                                // controller.listModel.data.lists[index].isPin = true;
                                                controller.listModel.data.lists[index].isPinRX.value=1;
                                                controller.listModel.data.pinnedLists.add(controller.listModel.data.lists[index]);
                                                list_Id = controller.listModel.data.lists[index].id.toString();

                                              }
                                              isPin = true;
                                              DialogBuilder(context).showLoadingIndicator();
                                              await controller.PinUnpinPost(list_Id: list_Id, pin_unpin_list: '1');


                                              await newsController.getLanguages();
                                              DialogBuilder(context).hideOpenDialog();

                                            } else {
                                              Fluttertoast.showToast(
                                                msg: Strings.userCanPinnedOnly5,
                                                toastLength: Toast.LENGTH_LONG,
                                                fontSize: 20,
                                                backgroundColor: Colors.green,
                                                timeInSecForIosWeb: 1,
                                                textColor: Colors.white,
                                              );
                                            }
                                            // });
                                            controller
                                                .update();
                                          }
                                              : () async {
                                            // setState(
                                            //   () {

                                            // controller.listModel.data.lists[index].isPin = false;
                                            controller.listModel.data.lists[index].isPinRX.value=0;
                                            for (int i = 0; i < controller.listModel.data.pinnedLists.length; i++) {
                                              if (controller.listModel.data.lists[index].id == controller.listModel.data.pinnedLists[i].id) {
                                                list_Id = controller.listModel.data.lists[index].id.toString();
                                                controller.listModel.data.pinnedLists.removeAt(i);
                                              }
                                            }

                                            DialogBuilder(context).showLoadingIndicator();
                                            await controller.PinUnpinPost(
                                                list_Id: list_Id,
                                                pin_unpin_list: '0');
                                            await newsController.getLanguages();
                                            DialogBuilder(context).hideOpenDialog();
                                            // }
                                            // );
                                            controller
                                                .update();
                                          },
                                          splashColor:
                                          controller
                                              .newsfeedController
                                              .displayColor,
                                          child: controller.listModel.data.lists[index].isPinRX.value==0
                                              ? Image(
                                            image:
                                            const AssetImage(
                                              'assets/post_icons/pin-Hollow.png',
                                            ),
                                            height:
                                            20,
                                            width:
                                            20,
                                            color: controller
                                                .newsfeedController
                                                .displayColor,
                                          )
                                              : Image(
                                              image:
                                              const AssetImage(
                                                'assets/post_icons/pin-Filled.png',
                                              ),
                                              height:
                                              30,
                                              width:
                                              30,
                                              color: controller
                                                  .newsfeedController
                                                  .displayColor),
                                        ));

                                  },
                                childCount: controller.listModel.data.lists.isEmpty?
                                0:controller.listModel.data.lists.length
                              )
                          ),
                          const SliverToBoxAdapter(child: SizedBox(height: 40,),)

                        ],

                      )),
                );
        });
  }
}

class CheckBoxList extends StatefulWidget {
  const CheckBoxList({Key key}) : super(key: key);

  @override
  State<CheckBoxList> createState() => _CheckBoxListState();
}

class _CheckBoxListState extends State<CheckBoxList> {
  bool isChecked = false;
  ListController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    Color getColor(Set<MaterialState> states) {
      const Set<MaterialState> interactiveStates = <MaterialState>{
        MaterialState.pressed,
        MaterialState.hovered,
        MaterialState.focused,
      };
      if (states.any(interactiveStates.contains)) {
        return controller.newsfeedController.displayColor;
      }
      return controller.newsfeedController.displayColor;
    }

    return Checkbox(
      checkColor: Colors.white,
      fillColor: MaterialStateProperty.resolveWith(getColor),
      value: isChecked,
      onChanged: (bool value) {
        setState(() {
          isChecked = value;
          if (isChecked == true) {
            controller.isChecked = '1';
          } else {
            controller.isChecked = '0';
          }
        });
      },
    );
  }
}
