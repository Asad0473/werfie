import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/network/controller/List_controller.dart';
import 'package:werfieapp/screens/dicover_list_post_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/main_drawer.dart';

import '../constants/responsive.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';

class SuggestedListScreen extends StatefulWidget {
  SuggestedListScreen({this.controller});

  final NewsfeedController controller;

  @override
  State<SuggestedListScreen> createState() => _SuggestedListScreenState();
}

class _SuggestedListScreenState extends State<SuggestedListScreen> {
  final DummyData dataController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
          onWillPop: () async {
            widget.controller.isBrowseScreen = false;
            widget.controller.isNewsFeedScreen = true;
            widget.controller.isTrendsScreen = false;
            widget.controller.isWhoToFollowScreen = false;
            widget.controller.isNotificationScreen = false;
            widget.controller.isChatScreen = false;
            widget.controller.isSavedPostScreen = false;
            widget.controller.isProfileScreen = false;
            widget.controller.isSettingsScreen = false;
            widget.controller.isListScreen = false;
            widget.controller.isPostListScreen = false;

            widget.controller.update();
            Navigator.pop(context);
            return false;
          },
          child: MobileListPageScreen(
            newsfeedController: widget.controller,
          ),
        ),
        tablet: MobileListPageScreen(
          newsfeedController: widget.controller,
        ),
        desktop: MobileListPageScreen(
          newsfeedController: widget.controller,
        ),
      ),
    );
  }
}

class MobileListPageScreen extends StatefulWidget {
  MobileListPageScreen({this.newsfeedController});

  final NewsfeedController newsfeedController;

  @override
  State<MobileListPageScreen> createState() => _MobileListPageScreenState();
}

class _MobileListPageScreenState extends State<MobileListPageScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final ListController controller = Get.put(ListController());
  final storage = GetStorage();
  bool isFollow = false;
  bool isPin = false;
  bool isHover = false;
  int listId;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(builder: (controller) {
      final DummyData dataController = Get.find<DummyData>();

      return GestureDetector(
          onTap: () {
            controller.isSearch = false;
            controller.searchResult = [];
            controller.update();
          },
          child: Scaffold(
            key: _scaffoldKey,
            appBar: kIsWeb
                ? PreferredSize(
                    child: ListTile(
                      leading: kIsWeb
                          ? IconButton(
                              onPressed: () {
                                Get.toNamed(FluroRouters.mainScreen + '/list');
                                // controller.newsfeedController.isSuggestedListScreen = false;
                                // controller.newsfeedController.isListDetailScreen = false;
                                // controller.newsfeedController.isSearch = false;
                                // controller.newsfeedController.isFilter = false;
                                // controller.newsfeedController.isFilterScreen = false;
                                // controller.newsfeedController.isTrendsScreen = false;
                                // controller.newsfeedController.isNewsFeedScreen = false;
                                // controller.newsfeedController.isBrowseScreen = false;
                                // controller.newsfeedController.isNotificationScreen = false;
                                // controller.newsfeedController.isWhoToFollowScreen = false;
                                // controller.newsfeedController.isSavedPostScreen = false;
                                // controller.newsfeedController.isChatScreen = false;
                                // controller.newsfeedController.isPostDetails = false;
                                // controller.newsfeedController.isProfileScreen = false;
                                // controller.newsfeedController.searchText.text = '';
                                // controller.newsfeedController.isListScreen = true;
                                // controller.newsfeedController.isFollwerScreen = false;
                                // controller.newsfeedController.isSettingsScreen = false;
                                // controller.newsfeedController.navRoute = "isChatScreen";
                                // controller.newsfeedController.update();
                              },
                              icon: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ))
                          : IconButton(
                              onPressed: () {
                                controller.newsfeedController.update();
                                Get.back();
                              },
                              icon: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                      title: Text(
                        "Suggested List",
                        style: Styles.baseTextTheme.headline1.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                        // Theme.of(context).textTheme.headline6.copyWith(
                        //   fontSize: 18,
                        //   // fontWeight: FontWeight.w900,
                        //   color: Colors.black,
                        // ),
                      ),
                    ),
                    preferredSize: Size(double.infinity, 60),
                  )
                : AppBar(
                    leading: widget.newsfeedController.userProfile == null
                        ? Container(
                            width: 24,
                            child: Center(
                              child: SpinKitCircle(
                                color: Colors.grey,
                                size: 40,
                              ),
                            ),
                          )
                        : Builder(
                            builder: (BuildContext context) {
                              return GestureDetector(
                                onTap: () {
                                  print('pressed');
                                  Scaffold.of(context).openDrawer();
                                },
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 10),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(40),
                                    child: FadeInImage(
                                      fit: BoxFit.cover,
                                      width: 30,
                                      height: 30,
                                      placeholder: AssetImage(
                                          'assets/images/person_placeholder.png'),
                                      image: NetworkImage(widget
                                                  .newsfeedController
                                                  .userProfile
                                                  .profileImage !=
                                              null
                                          ? widget.newsfeedController
                                              .userProfile.profileImage
                                          : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    iconTheme: IconThemeData(
                      color: Color(0xFF4f515b),
                    ),
                    title: Text(
                      "Suggested List",
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    automaticallyImplyLeading:
                        !Responsive.isDesktop(context) ? true : false,
                  ),
            // !Responsive.isDesktop(context)
            //     ?
            // kIsWeb
            //     ? AppBar(
            //   backgroundColor: Colors.white,
            //   iconTheme: IconThemeData(
            //     color: Color(0xFF4f515b),
            //   ),
            //   title: Text(
            //       "Lists",
            //     style: Styles.baseTextTheme.headline1.copyWith(
            //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
            //     ),
            //   ),
            //   automaticallyImplyLeading:
            //   !Responsive.isDesktop(context) ? true : false,
            // )
            //     : AppBar(
            //   leading: widget.newsfeedController.userProfile == null
            //       ? Container(
            //     width: 24,
            //     child: Center(
            //       child: SpinKitCircle(
            //         color: Colors.grey,
            //         size: 40,
            //       ),
            //     ),
            //   )
            //       : Builder(
            //     builder: (BuildContext context) {
            //       return GestureDetector(
            //         onTap: () {
            //           print('pressed');
            //           Scaffold.of(context).openDrawer();
            //         },
            //         child: Padding(
            //           padding: EdgeInsets.symmetric(
            //               horizontal: 10, vertical: 10),
            //           child: ClipRRect(
            //             borderRadius: BorderRadius.circular(40),
            //             child: FadeInImage(
            //               fit: BoxFit.cover,
            //               width: 30,
            //               height: 30,
            //               placeholder: AssetImage(
            //                   'assets/images/person_placeholder.png'),
            //               image: NetworkImage(widget
            //                   .newsfeedController
            //                   .userProfile
            //                   .profileImage !=
            //                   null
            //                   ? widget.newsfeedController
            //                   .userProfile.profileImage
            //                   : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
            //             ),
            //           ),
            //         ),
            //       );
            //     },
            //   ),
            //   backgroundColor: Colors.white,
            //   iconTheme: IconThemeData(
            //     color: Color(0xFF4f515b),
            //   ),
            //   title: Text(
            //       "Suggested List",
            //     style: Styles.baseTextTheme.headline1.copyWith(
            //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
            //     ),
            //   ),
            //   automaticallyImplyLeading:
            //   !Responsive.isDesktop(context) ? true : false,
            // )
            //     : PreferredSize(
            //   preferredSize: Size(0.0, 0.0),
            //   child: Container(),
            // ),
            drawer: !Responsive.isDesktop(context)
                ? MainDrawer(widget.newsfeedController)
                : Container(),
            drawerEnableOpenDragGesture:
                !Responsive.isDesktop(context) ? false : true,
            body: CustomScrollView(slivers: <Widget>[
              SliverAppBar(
                expandedHeight: Get.height * .25,
                automaticallyImplyLeading: false,
                floating: true,
                snap: true,
                backgroundColor: Colors.white,
                elevation: 0.0,
                flexibleSpace: FlexibleSpaceBar(
                    background: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    Container(
                      width: Get.width,
                      height: Get.height * .25,
                      decoration: BoxDecoration(
                          color: Colors.brown,
                          image: DecorationImage(
                              image: NetworkImage(
                                  "https://www.challengetires.com/assets/img/placeholder.jpg"),
                              fit: BoxFit.cover)),
                    ),
                  ],
                )),
              ),
              SliverToBoxAdapter(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    height: 30,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0, right: 10),
                    child: Text(
                      Strings.chooseYourLists,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                      // Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 18,
                      //   fontWeight: FontWeight.w900,
                      //   color: Colors.black,
                      // ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 10.0, right: 10),
                    child: Text(
                      Strings.whenYouFollowMsg,
                      textAlign: TextAlign.justify,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 14 : 12,
                      ),
                      // Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 18,
                      //   fontWeight: FontWeight.w900,
                      //   color: Colors.black,
                      // ),
                    ),
                  ),
                  Divider(
                    color: Colors.black12,
                    thickness: 0.9,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                      padding:
                          const EdgeInsets.only(top: 10, left: 10, right: 10),
                      child: Text(
                        Strings.discoverlist,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      )),
                  SizedBox(
                    height: 30,
                  ),
                ],
              )),
              SliverList(
                delegate: SliverChildListDelegate(
                  List.generate(
                      controller.listModel.data.discoverLists.length,
                      (index) => ListTile(
                          onTap: () async {
                            //                                               if(controller
                            //                                                   .listModel
                            //                                                   .data
                            //                                                   .discoverLists[index].makePrivate != 1){
                            // controller.newsfeedController.isListDetailScreen = true;
                            // controller.newsfeedController.isSearch = false;
                            // controller.newsfeedController.isFilter = false;
                            // controller.newsfeedController.isFilterScreen = false;
                            // controller.newsfeedController.isTrendsScreen = false;
                            // controller.newsfeedController.isNewsFeedScreen = false;
                            // controller.newsfeedController.isBrowseScreen = false;
                            // controller.newsfeedController.isNotificationScreen = false;
                            // controller.newsfeedController.isWhoToFollowScreen = false;
                            // controller.newsfeedController.isSavedPostScreen = false;
                            // controller.newsfeedController.isChatScreen = false;
                            // controller.newsfeedController.isPostDetails = false;
                            // controller.newsfeedController.isProfileScreen = false;
                            // controller.newsfeedController.searchText.text = '';
                            // controller.newsfeedController.isListScreen = false;
                            // controller.newsfeedController.isFollwerScreen = false;
                            // controller.newsfeedController.isSettingsScreen = false;
                            // controller.newsfeedController.navRoute = "isChatScreen";
                            // controller.newsfeedController.update();
                            //
                            //
                            // print("list iD?>>>>>>>>>>>>>>>>>>>>>"+controller
                            //
                            //     .listModel
                            //     .data
                            //     .discoverLists[index].id.toString());
                            // controller.selectedList = await controller.listDetail(listId:controller
                            //     .listModel
                            //     .data
                            //     .discoverLists[index].id);
                            // }
                            if (kIsWeb) {
                              //  controller.list = controller.listModel.data.discoverLists[index];
                              storage.write("pinIndex",controller.listModel.data.discoverLists[index]);
                              if (controller.listModel.data.discoverLists[index].makePrivate != 1) {
                                // controller.selectedList = await controller.listDetail(
                                //     listId: controller.listModel.data.discoverLists[index].id);

                                storage.write("clickId", 2);
                                storage.write("pinId",controller.listModel.data.discoverLists[index].id);

                                controller.newsfeedController.isListDetailScreen = true;
                                controller.newsfeedController.isSearch = false;
                                controller.newsfeedController.isFilter = false;
                                controller.newsfeedController.isFilterScreen = false;
                                controller.newsfeedController.isTrendsScreen = false;
                                controller.newsfeedController.isNewsFeedScreen = false;
                                controller.newsfeedController.isBrowseScreen = false;
                                controller.newsfeedController.isNotificationScreen = false;
                                controller.newsfeedController.isWhoToFollowScreen = false;
                                controller.newsfeedController.isSavedPostScreen = false;
                                controller.newsfeedController.isChatScreen = false;
                                controller.newsfeedController.isPostDetails = false;
                                controller.newsfeedController.isProfileScreen = false;
                                controller.newsfeedController.searchText.text = '';
                                controller.newsfeedController.isListScreen = false;
                                controller.newsfeedController.isFollwerScreen = false;
                                controller.newsfeedController.isSettingsScreen = false;
                                controller.newsfeedController.navRoute = "isChatScreen";
                                controller.newsfeedController.update();
                                print("list iD?>>>>>>>>>>>>>>>>>>>>>" +
                                    controller.listModel.data.discoverLists[index].id.toString());
                                Get.toNamed(FluroRouters.mainScreen + "/listDetail/" +
                                    controller.listModel.data.discoverLists[index].id.toString());
                              }
                            } else {

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      DiscoverListScreen(
                                        controller: controller.newsfeedController,
                                        index: index.toString(),
                                        clickId: 2,
                                        listId:  controller.listModel.data.discoverLists[index].id,

                                      ),
                                ),
                              );
                              controller.selectedList =
                                  await controller.listDetail(
                                      listId: controller
                                          .listModel.data.lists[index].id);
                            }
                          },
                          leading: Container(
                            height: 40,
                            width: 40,
                            decoration: BoxDecoration(
                                color: Colors.grey,
                                borderRadius: BorderRadius.circular(10),
                                image: DecorationImage(
                                    image: NetworkImage(controller
                                                .listModel
                                                .data
                                                .discoverLists[index]
                                                .coverImage ==
                                            null
                                        ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                        : controller.listModel.data
                                            .discoverLists[index].coverImage),
                                    fit: BoxFit.fill)),
                          ),
                          title: Text(
                            controller.listModel.data.discoverLists[index].name,
                            style: Styles.baseTextTheme.headline5.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          subtitle: Row(
                            children: [
                              // Text(controller
                              //     .listModel
                              //     .data
                              //     .discoverLists[
                              // index]
                              //     .authorName),
                              // SizedBox(
                              //   width: 4,
                              // ),
                              Text(
                                "@" +
                                    controller.listModel.data
                                        .discoverLists[index].username,
                                style: Styles.baseTextTheme.headline5.copyWith(
                                  fontSize: kIsWeb ? 14 : 12,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ],
                          ),
                          trailing: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30)),

                                // AddFollow
                                primary: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? !controller.listModel.data
                                            .discoverLists[index].isFollow
                                        ? Colors.white
                                        : Colors.black
                                    : !controller.listModel.data
                                            .discoverLists[index].isFollow
                                        ? Colors.black
                                        : Colors.white,

                                // controller.listModel.data.discoverLists[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)
                              ),
                              onPressed: controller.listModel.data
                                          .discoverLists[index].isFollow ==
                                      false
                                  ? () async {
                                      setState(() {
                                        controller
                                            .listModel
                                            .data
                                            .discoverLists[index]
                                            .isFollow = true;
                                        controller.listModel.data.lists.add(
                                          controller.listModel.data
                                              .discoverLists[index],
                                        );
                                      });
                                      controller.update();
                                      controller.newsfeedController.update();

                                      controller.OnFollow(
                                          listId: controller.listModel.data
                                              .discoverLists[index].id
                                              .toString(),
                                          type: 'follower');
                                    }
                                  : () async {
                                      setState(() {
                                        controller
                                            .listModel
                                            .data
                                            .discoverLists[index]
                                            .isFollow = false;
                                        controller.unFollowMember(
                                            list_Id: controller.listModel.data
                                                .discoverLists[index].id
                                                .toString(),
                                            type: 'follower');
                                        controller.listModel.data.lists.remove(
                                          controller.listModel.data
                                              .discoverLists[index],
                                        );
                                        controller.update();
                                      });
                                      controller.update();
                                    },
                              child: controller.listModel.data
                                          .discoverLists[index].isFollow ==
                                      false
                                  ? Text(
                                      Strings.follow,
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.black
                                              : Colors.white),
                                      // Theme
                                      //     .of(context)
                                      //     .textTheme
                                      //     .headline6
                                      //     .copyWith(
                                      //   fontSize: 14,
                                      //   fontWeight: FontWeight
                                      //       .w700,
                                      //   color: Colors.white,
                                      // ),
                                    )
                                  : Text(
                                      "Unfollow",
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    )))),
                ),
              )
            ]),
          ));
    });
  }
}
