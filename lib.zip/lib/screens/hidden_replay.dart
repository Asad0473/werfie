import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/network/controller/mobile_comments_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/rich_text.dart';

import '../network/controller/hidden_reply_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../widgets/post_card.dart';

class HiddenReplay extends StatefulWidget {
  int postId;

  HiddenReplay({this.postId});

  @override
  State<HiddenReplay> createState() => _HiddenReplayState();
}

class _HiddenReplayState extends State<HiddenReplay> {



  @override
  void initState(){




    if (Get.isRegistered<HiddenReplayController>()) {

      Get.find<HiddenReplayController>().hiddenReplyList = [];
       Get.find<HiddenReplayController>().hiddenReplyPostList(postId: Get.find<HiddenReplayController>().newsfeedController.postId,pageNO: 1);
    } else {
     var controller = Get.put(HiddenReplayController());

     controller.hiddenReplyList = [];

     controller.hiddenReplyPostList(postId: controller.newsfeedController.postId,pageNO: 1);
    }


    super.initState();
  }


  @override
  Widget build(BuildContext context) {



    return GetBuilder<HiddenReplayController>(builder: (controller) {

      return Scaffold(
        appBar: kIsWeb
            ? PreferredSize(
                child: ListTile(
                  leading: IconButton(
                    //splashColor: Colors.white,
                    // hoverColor: Colors.grey[100],
                    icon: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                    onPressed: () async {
                      if (controller.newsfeedController.navRoute == "isPostDetail") {
                        Get.offNamed(FluroRouters.mainScreen + "/postDetail/" +
                            controller.newsfeedController.postId.toString());
                      } else {
                        Get.offNamed(FluroRouters.mainScreen + "/postDetail/" +
                            controller.newsfeedController.postId.toString());
                      }
                      Get.find<MobileCommentsController>().getCommentsPostLists(postId: controller.newsfeedController.postId );

                    },
                  ),
                  title: SizedBox(
                    height: 29,
                    child: Text(
                      "Hidden Replies",
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                preferredSize: Size(double.infinity, 60),
              )
            : AppBar(
                backgroundColor: Colors.white,
                automaticallyImplyLeading: false,
                leading: IconButton(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  icon: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                  onPressed: () async {
                    MobileCommentsController mobileCommentsController =
                        Get.put(MobileCommentsController());

                    // print("hello");

                    Navigator.of(context).pop();
                    Get.find<MobileCommentsController>().getCommentsPostLists(postId: controller.newsfeedController.postId );
                    // controller.selectedPost2 = await controller
                    //     .getSingleNewsFeedItem(postId, isReload: true);
                    controller.update();
                    mobileCommentsController.update();
                    // mobileCommentsController.update();
                  },
                ),
                title: Text(
                  "Hidden Replies",
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
        body:

        controller.isLoading?
            Center(child: CircularProgressIndicator()):
        controller.hiddenReplyList.isEmpty?
        Center(
          child: Text(
            Strings.noPosts,
            style: TextStyle(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 16 : 14,
            ),
          ),
        ):
        PagedL(


          itemBuilder: _itemRow,
          padding: EdgeInsets.only(top: 10, bottom: 30),
          loadingIndicator: Padding(
            padding: EdgeInsets.all(16.00),
            child: Center(
              child: CircularProgressIndicator(
                color: MyColors.BlueColor,
              ),
            ),
          ),
          itemDataProvider: _fetchData,
          list: controller.hiddenReplyList,
          listSize: _checkPage(controller.hiddenReplyList.length),
        ),

        // controller.allCommentLoading == true
        //     ? Center(
        //         child: CircularProgressIndicator(
        //           color: MyColors.BlueColor,
        //         ),
        //       )
        //     : controller.commentList.length == 0 &&
        //             controller.commentList.isEmpty
        //         ? Center(
        //             child: Text(
        //               Strings.nothingToSeeHere,
        //               style: Styles.baseTextTheme.headline4.copyWith(
        //                 color: Theme.of(context).brightness == Brightness.dark
        //                     ? Colors.white
        //                     : Colors.black,
        //                 fontSize: kIsWeb ? 14 : 12,
        //               ),
        //             ),
        //           )
        //         :

        // ListView.builder(
        //             itemCount: controller.postList.length > 0
        //                 ? controller.postList.length
        //                 : 0,
        //             itemBuilder: (BuildContext context, int index) {
        //               return PostCard(
        //                 postList: controller.postList,
        //                 index: index,
        //                 post: controller.postList[index],
        //                 // scaffoldKey: _scaffoldKey,
        //                 controller: controller,
        //                 deletePostId: 11,
        //               );
        //             }),
      );
    });
  }



  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    // print("fetchdata");

    return await Get.find<HiddenReplayController>().hiddenReplyPostListPagged(postId: Get.find<HiddenReplayController>().newsfeedController.postId,pageNO: page);
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = Get.find<HiddenReplayController>().hiddenReplyList.indexWhere((element) {
      return element.postId == post.postId;
    });

    // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        VisibilityDetector(
          key: Key('postCard-widget-key'),
          onVisibilityChanged: (visibilityInfo) {
            double visiblePercentage = visibilityInfo.visibleFraction * 100;
            // debugPrint(
            //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
            if (visiblePercentage > 20 &&
                post.authorId != Get.find<HiddenReplayController>().newsfeedController.userId) {
              Get.find<HiddenReplayController>().newsfeedController.emitImpressionsSocket(post.postId);
            }
          },
          child: PostCard(
            postList: Get.find<HiddenReplayController>().hiddenReplyList,
            index: index,
            post: Get.find<HiddenReplayController>().hiddenReplyList[index],

            controller: Get.find<HiddenReplayController>().newsfeedController,
            deletePostId: 11,
          ),
        ),
      ],
    );
  }
}

