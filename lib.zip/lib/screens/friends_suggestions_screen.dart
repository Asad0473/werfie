// import 'package:werfieapp/constants/responsive.dart';
// import 'package:werfieapp/network/controller/news_feed_controller.dart';
// import 'package:werfieapp/widgets/custom_appbar.dart';
// import 'package:werfieapp/widgets/main_drawer.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
//
// class FriendsSuggestionsScreen extends StatelessWidget {
//   final NewsfeedController controller;
//   FriendsSuggestionsScreen({this.controller});
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Responsive(
//         mobile: FriendsSuggestionScreen(controller:controller),
//         tablet: FriendsSuggestionScreen(controller:controller),
//         desktop: FriendsSuggestionScreen(controller:controller),
//       ),
//     );
//   }
// }
//
// class FriendsSuggestionScreen extends StatelessWidget {
//   final NewsfeedController controller;
//   const FriendsSuggestionScreen({
//     Key key,
//     this.controller
//   }) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: !Responsive.isDesktop(context)
//           ? kIsWeb
//               ? CustomAppBarWidget()
//               : CustomAppBarWidget()
//           : SizedBox(
//               height: 0,
//               width: 0,
//             ),
//       drawer: !Responsive.isDesktop(context) ? MainDrawer(controller:controller) : Container(),
//       drawerEnableOpenDragGesture:
//           !Responsive.isDesktop(context) ? false : true,
//       body: Padding(
//         padding: EdgeInsets.only(
//           top: 10,
//           left: 8,
//           right: 8,
//           bottom: 2,
//         ),
//         child: GridView.builder(
//           itemCount: 20,
//           gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//             crossAxisCount: 2,
//             childAspectRatio: 0.8,
//             mainAxisSpacing: 12,
//           ),
//           itemBuilder: (context, index) {
//             return Card(
//               child: Padding(
//                 padding: EdgeInsets.only(
//                   top: 12,
//                   bottom: 10,
//                 ),
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     CircleAvatar(
//                       backgroundImage: AssetImage('assets/images/image.jpg'),
//                       radius: 28,
//                     ),
//                     Text(
//                       'Active 20 minutes ago',
//                       style: Theme.of(context).textTheme.bodyText2,
//                     ),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Column(
//                           children: [
//                             Text('23'),
//                             Text(
//                               'Friends',
//                               style: Theme.of(context).textTheme.bodyText2,
//                             ),
//                           ],
//                         ),
//                         SizedBox(width: 12),
//                         Column(
//                           children: [
//                             Text('3'),
//                             Text(
//                               'Groups',
//                               style: Theme.of(context).textTheme.bodyText2,
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                     OutlinedButton(
//                       onPressed: () {},
//                       child: Text(
//                         'Add Friend',
//                         style: Theme.of(context).textTheme.bodyText1.copyWith(
//                               color: Theme.of(context).primaryColor,
//                               fontWeight: FontWeight.w600,
//                             ),
//                       ),
//                       style: OutlinedButton.styleFrom(
//                         side: BorderSide(
//                           color: Color(0xFF9c51e9),
//                           width: 2,
//                           style: BorderStyle.solid,
//                         ),
//                         shape: StadiumBorder(
//                           side: BorderSide(
//                             color: Color(0xFF9c51e9),
//                             width: 0,
//                             style: BorderStyle.solid,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
