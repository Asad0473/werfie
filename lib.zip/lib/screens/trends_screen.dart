import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/seach_suggestion_model.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/web_views/web_main_screen.dart';

import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import 'hash_taga_werfs_screen.dart';

// ignore: must_be_immutable
class TrendsScreen extends StatelessWidget {
  var controller = NewsfeedController();

  TrendsScreen({this.controller});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
            onWillPop: () async {
              controller.isBrowseScreen = false;
              controller.isNewsFeedScreen = true;
              controller.isTrendsScreen = false;
              controller.isWhoToFollowScreen = false;
              controller.isNotificationScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;
              controller.isProfileScreen = false;
              controller.isSettingsScreen = false;
              controller.update();
              Navigator.pop(context);
              return false;
            },
            child: MobileTrendsScreen(controller: controller)),
        tablet: MobileTrendsScreen(controller: controller),
        desktop: WebMainScreen(),
      ),
    );
  }
}

class MobileTrendsScreen extends StatefulWidget {
  const MobileTrendsScreen({this.controller});

  final NewsfeedController controller;

  @override
  State<MobileTrendsScreen> createState() => _MobileTrendsScreenState();
}

class _MobileTrendsScreenState extends State<MobileTrendsScreen> {

  @override
  void initState() {
    addTrendsMetaTags();
    super.initState();
  }

  addTrendsMetaTags(){
    MetaTags().addMetaTag(
      pageTitle:MetaTagValues.pageTitleTrending ,
        metaTagDescription: MetaTagValues.trendsMetaDescription,
        metaTagKeywords: MetaTagValues.trendsMetaKeywords,
        ogTitle: MetaTagValues.trendsOGTitle,
        ogDescription: MetaTagValues.trendsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      // backgroundColor: Colors.white,
      appBar: !Responsive.isDesktop(context)
          ? kIsWeb
              ? MediaQuery.of(context).size.width >= 500
                  ? PreferredSize(
                      preferredSize: Size(0.0, 0.0),
                      child: Container(),
                    )
                  : AppBar(
                      backgroundColor:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.black
                              : Colors.white,
                      iconTheme: IconThemeData(
                        color: Color(0xFF4f515b),
                      ),
                      title: Container(
                        height: 45,
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: TextField(
                          style: LightStyles.baseTextTheme.headline2.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            //fontWeight: FontWeight.w500,
                            // fontSize: 14,
                          ),
                          cursorColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                          textAlignVertical: TextAlignVertical.bottom,
                          decoration: InputDecoration(
                            hintText: Strings.search,
                            hintStyle: LightStyles.baseTextTheme.headline3,
                            prefixIcon: Icon(
                              Icons.search,
                              size: 20,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40),
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40),
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1),
                              // style: BorderStyle.none,
                            ),
                            fillColor: Colors.grey[250],
                            filled: true,
                          ),
                        ),
                      ),
                      automaticallyImplyLeading:
                          !Responsive.isDesktop(context) ? true : false,
                    )
              : AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  iconTheme: IconThemeData(
                    color: Color(0xFF4f515b),
                  ),
                  title: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Get.back();

                          onHomeChange = true;
                          onBrowsChange = false;
                          onTrendsChange = false;
                          onBookMarksChange = false;
                          onChatsChange = false;
                          onProfileChange = false;
                          onSettingChange = false;
                          onListChange = false;
                          onNotificationChange = false;
                          onMoreChange = false;

                          widget.controller.isTrendsScreen = false;
                          // controller.isNewsFeedScreen = true;
                          // controller.isBrowseScreen = false;
                          // controller.isNotificationScreen = false;
                          // controller.isChatScreen = false;
                          // controller.isSavedPostScreen = false;
                          // controller.isPostDetails = false;
                          // controller.isProfileScreen = false;
                          // controller.isOtherUserProfileScreen = false;

                          widget.controller.update();
                        },
                        child: Icon(
                          Icons.arrow_back,
                          size: 25,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      Spacer(),
                      Container(
                        height: 45,
                        width: MediaQuery.of(context).size.width * 0.7,
                        child: TextField(
                          style: LightStyles.baseTextTheme.headline2.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            //fontWeight: FontWeight.w500,
                            // fontSize: 14,
                          ),
                          cursorColor:
                              Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    SearchScreen(),
                              ),
                            );
                          },
                          textAlignVertical: TextAlignVertical.bottom,
                          decoration: InputDecoration(
                            hintText: Strings.search,
                            hintStyle: LightStyles.baseTextTheme.headline3,
                            prefixIcon: Icon(
                              Icons.search,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 20,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40),
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(40),
                              borderSide:
                                  BorderSide(color: Colors.grey, width: 1),
                            ),
                            fillColor: Colors.grey[250],
                            filled: true,
                          ),
                        ),
                      ),
                      Spacer(),
                    ],
                  ),
                  automaticallyImplyLeading: false,
                )
          : PreferredSize(
              preferredSize: Size(0.0, 0.0),
              child: Container(),
            ),
      // drawer: !Responsive.isDesktop(context) ? MainDrawer(controller) : Container(),
      // drawerEnableOpenDragGesture:
      //     !Responsive.isDesktop(context) ? false : true,
      body: Container(
        margin: EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            kIsWeb
                ? Row(
                    children: [
                      /*Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: IconButton(
                          onPressed: () {
                            Get.back();

                            onHomeChange = true;
                            onBrowsChange = false;
                            onTrendsChange = false;
                            onBookMarksChange = false;
                            onChatsChange = false;
                            onProfileChange = false;
                            onSettingChange = false;
                            onListChange = false;
                            onNotificationChange = false;
                            onMoreChange = false;

                            controller.isTrendsScreen = false;
                            // controller.isNewsFeedScreen = true;
                            // controller.isBrowseScreen = false;
                            // controller.isNotificationScreen = false;
                            // controller.isChatScreen = false;
                            // controller.isSavedPostScreen = false;
                            // controller.isPostDetails = false;
                            // controller.isProfileScreen = false;
                            // controller.isOtherUserProfileScreen = false;

                            controller.update();
                          },
                          icon: Icon(
                            Icons.arrow_back,
                            size: 25,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                      ),*/
                      SizedBox(width: 10,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              Strings.hotTrends,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              // style: Theme.of(context).textTheme.headline6.copyWith(
                              //    fontSize: 18,
                              //       fontWeight: FontWeight.w700,
                              //       color: Colors.black,
                              //     ),
                            )),
                      ),
                    ],
                  )
                : SizedBox(),
            // Container(
            //   height: 0.3,
            //   width: MediaQuery.of(context).size.width,
            //   color: Colors.grey.withOpacity(0.3),
            // ),
            widget.controller.isTrendingLoading == true
                ? Center(
                    child: CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    ),
                  )
                : widget.controller.trendingList == null ||
                        widget.controller.trendingList.trends.isEmpty
                    ? Center(
                        child: Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: Text(
                          Strings.noTrending,
                          style: Styles.baseTextTheme.headline4.copyWith(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                          ),
                        ),
                      ))
                    : Column(
                        children: List.generate(
                            widget.controller.trendingList.trends.length, (index) {
                          return InkWell(
                            hoverColor: Colors.grey.withOpacity(0.1),
                            onTap: () async {
                              SearchSuggestion sugge = SearchSuggestion();

                              if (kIsWeb) {
                                Get.toNamed(
                                    FluroRouters.mainScreen +
                                        "/tagWerfs/" +
                                        widget.controller.trendingList.trends[index].title.toString());
                              } else {
                                Get.to(HashTagWerfsScreen(
                                  tag: widget.controller.trendingList.trends[index].title,
                                  controller: widget.controller,
                                ));
                                //LoggingUtils.printValue("tag value", tag);
                              }
                              /*    sugge.id =
                                  controller.trendingList.trends[index].tagId;
                              sugge.type = "tag";
                              controller.postUserId = controller.trendingList.trends[index].tagId;


                              controller.searchSelected = sugge;
                              controller.isProfileScreen = false;
                              controller.isFilterScreen = true;
                              controller.searchText.text =
                                  controller.trendingList.trends[index].title;
                              controller.isProfileScreen = false;
                              controller.isSettingsScreen = false;
                              controller.isSavedPostScreen = false;
                              controller.isNewsFeedScreen = false;
                              controller.isOtherUserProfileScreen = false;
                              controller.isChatScreen = false;
                              controller.isChatScreenWeb = false;
                              controller.isBrowseScreen = false;
                              controller.isClickWhoToFollow = false;
                              controller.isFollwerScreen = false;
                              controller.isPostDetails = false;
                              controller.isTrendsScreen = false;

                              // Future.delayed(Duration(seconds: 3), () {
                                kIsWeb
                                    ? controller.update()
                                    :  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            FilteredScreen(
                                              newsfeedController:
                                              Get.find<NewsfeedController>(),
                                            )));
                              // });
                              await controller.filterUsers(
                                id: controller.trendingList.trends[index].tagId,
                                type: "tag",
                              );*/

                              /*       SingleTone.instance.searchId=controller.trendingList.trends[index].tagId.toString();
                              SingleTone.instance.searchType="tag";
                              SingleTone.instance.searchTag="";
                              SingleTone.instance.searchTab=controller.seletedTab;
                              Get.offNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}");
*/
                            },
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 2),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(width: 12),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            Strings.trendingIn +
                                                ' ${widget.controller.trendingList.trends[index].region}',
                                            style: Styles
                                                .baseTextTheme.headline4
                                                .copyWith(
                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                              fontSize: kIsWeb ? 14 : 12,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          SizedBox(height: 2),
                                          Text(
                                              '${widget.controller.trendingList.trends[index].title}',
                                              style: Styles
                                                  .baseTextTheme.headline4
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              )),
                                          Text(
                                            '${widget.controller.trendingList.trends[index].trendingCount} ' +
                                                Strings.werfs,
                                            style: Styles
                                                .baseTextTheme.headline4
                                                .copyWith(
                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                              fontSize: kIsWeb ? 14 : 12,
                                              fontWeight: FontWeight.w400,
                                            ),
                                            // style: TextStyle(fontSize: 12),
                                          ),
                                        ],
                                      ),
                                      Spacer(),
                                      // InkWell(
                                      //     onTap: () {
                                      //       print("trendsssssssss");
                                      //       print(
                                      //           controller.trendingList[index]);
                                      //       print("trendsssssssss");
                                      //     },
                                      //     child: Icon(
                                      //       Icons.more_horiz,
                                      //       color: Colors.grey,
                                      //       size: 20,
                                      //     )),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ),
          ],
        ),
      ),
    );
  }
}
