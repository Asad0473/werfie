import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';

import '../network/controller/profile_controller.dart';
import '../utils/strings.dart';
import '../utils/utils_methods.dart';

class EditProfileWidget extends StatelessWidget {
  final controller = Get.find<ProfileController>();
  final width = Get.width;
  final height = Get.height;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileController>(builder: (controller) {
      return Scaffold(
        appBar: /*controller.isUpdateProfile == true
            ? AppBar(
                backgroundColor: Colors.grey.withOpacity(0.5),
                automaticallyImplyLeading: false,
                elevation: 0.0,
              )
            : */AppBar(
                //backgroundColor: Colors.white,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                centerTitle: false,
                title: Text(
                  Strings.editProfile,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                actions: [
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        elevation: 0.5,
                        primary: controller.newsFeedControler.displayColor,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20)),
                      ),
                      onPressed: () async {
                        var fullName = controller.usernameText.text;

                        // final splitFullName  = fullName.split(" ");
                        //
                        // String FirstName = splitFullName[0];
                        // String LastName = "";
                        // if(splitFullName.length>=2)
                        //   {
                        //
                        //     LastName = splitFullName[1];
                        //   }
                        // else{
                        //   LastName = "";
                        // }

                        //
                        // print("fullname ${FirstName}" );
                        //
                        //
                        // print("fullnames ${LastName}" );

                        // print(" VVVVVVVVVVVVVVVVV ${controller.selectedMonth}");

                        if (controller.selectedMonth.isNotEmpty &&
                            controller.selectedYear.isNotEmpty &&
                            controller.selectedDay.isNotEmpty) {
                          DateTime noDate = DateTime.now();
                          int newYear = noDate.year;
                          int selectedYear = int.parse(controller.selectedYear);
                          int difference = newYear - selectedYear;
                          // print('dateDifference:${difference}');
                          if (difference >= 13) {
                            DialogBuilder(context).showLoadingIndicator();
                            await controller.createData(
                              Bio: controller.bioText.text,
                              // userName: controller.usernameText.text,
                              profileImageBytes: controller.profileImage,
                              coverImageBytes: controller.coverImage,
                              firstName: fullName,
                              lastName: "",

                              // dob: controller.dobSelected,
                              dob: controller.functionstoreDate(),
                              delete_cover_picture:
                                  controller.coverImageDelete ? true : false,
                              delete_profile_picture:
                                  controller.profileImageDelete ? true : false,
                            );
                            controller.isUpdateProfile = false;
                            DialogBuilder(context).hideOpenDialog();
                            controller.update();
                            Navigator.pop(context);
                          } else {
                            UtilsMethods.toastMessageShow(
                              controller.newsFeedControler.displayColor,
                              controller.newsFeedControler.displayColor,
                              controller.newsFeedControler.displayColor,
                              message: Strings.youShouldBeAtLeast14YearsOld,
                            );
                          }
                        } else {
                          // UtilsMethods.toastMessageShow(
                          //   controller.newsFeedControler.displayColor,
                          //   controller.newsFeedControler.displayColor,
                          //   controller.newsFeedControler.displayColor,
                          //   message: Strings.pleaseEnterYourBirthDate,
                          // );
                          // // print("gggg");
                          // controller.visible = false;
                          // controller.changeText = false;
                          // controller.update();

                          DialogBuilder(context).showLoadingIndicator();
                          await controller.createData(
                            Bio: controller.bioText.text,
                            // userName: controller.usernameText.text,
                            profileImageBytes: controller.profileImage,
                            coverImageBytes: controller.coverImage,
                            firstName: fullName,
                            lastName: "",

                            // dob: controller.dobSelected,
                            // dob: controller.functionstoreDate(),
                            delete_cover_picture:
                                controller.coverImageDelete ? true : false,
                            delete_profile_picture:
                                controller.profileImageDelete ? true : false,
                          );
                          controller.isUpdateProfile = false;
                          DialogBuilder(context).hideOpenDialog();
                          controller.update();
                          Navigator.pop(context);

                          if (controller.formKey.currentState.validate()) {}
                        }
                      },
                      child: Text(
                        Strings.save,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ],
                leading: IconButton(
                  // highlightColor: Colors.transparent,
                  // hoverColor: Colors.transparent,
                  // focusColor: Colors.transparent,
                  onPressed: () {
                    // controller.isProfile = false;
                    // controller.isCover = false;
                    // controller.isBio = false;
                    // controller.isUsername = false;
                    // controller.selectedView = "";
                    // controller.update();

                    if (controller.coverImageDelete == true ||
                        controller.profileImageDelete == true) {
                      showDialog(
                          context: context,
                          builder: (BuildContext con) {
                            return AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                backgroundColor: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? MyColors.liteDark
                                    : Colors.white,
                                contentPadding: EdgeInsets.zero,
                                content: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 20, right: 20, top: 20),
                                  child: Container(
                                    height: 200,
                                    width: 250,
                                    child: SingleChildScrollView(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                          Strings.discardChanges,
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          Text(
                                            Strings.removeWerfAlert,
                                            style: TextStyle(
                                              height: 1.2,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? MyColors.grey
                                                  : Colors.black,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 20,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    controller
                                                            .coverImageDelete =
                                                        false;
                                                    controller
                                                            .profileImageDelete =
                                                        false;
                                                    controller.changeText =
                                                        true;
                                                    controller.visible = true;
                                                    controller.update();
                                                    Navigator.pop(context);
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                    Strings.discard,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Colors.white,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary: Colors.red,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: kIsWeb
                                                                ? 20
                                                                : 10,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: ElevatedButton(
                                                  // key: LoginController.formKey,
                                                  onPressed: () async {
                                                    // controller.coverImageDelete = false;
                                                    // controller.profileImageDelete = false;
                                                    // controller.update();
                                                    Navigator.pop(context);
                                                  },
                                                  child: Text(
                                                   Strings.cancel,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                  style:
                                                      ElevatedButton.styleFrom(
                                                    shadowColor:
                                                        Colors.transparent,
                                                    primary: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.black
                                                        : Colors.white,
                                                    padding:
                                                        EdgeInsets.symmetric(
                                                            vertical: kIsWeb
                                                                ? 20
                                                                : 10,
                                                            horizontal: 25),
                                                    elevation: 0.0,
                                                    shape: StadiumBorder(),
                                                    side: BorderSide(
                                                      width: 1,
                                                      color: MyColors.grey,
                                                    ),
                                                    // minimumSize: Size(100, 40),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )

                                //     Deactivation(
                                //   context2: context,
                                // ),
                                );
                          });
                      controller.update();
                    } else {
                      controller.changeText = true;
                      controller.visible = true;
                      Navigator.pop(context);
                    }
                  },
                  icon: Actions(
                    actions: {
                      EscEditProfileIntent:
                          CallbackAction<EscEditProfileIntent>(
                              onInvoke: (Intent) =>
                                  Navigator.of(context).pop()),
                    },
                    child: Focus(
                      autofocus: true,
                      child: Icon(
                        Icons.close,
                        size: 20,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                  ),
                ),
              ),
        body: /*controller.isUpdateProfile == true
            ? Center(
                child: CircularProgressIndicator())
            : */RawScrollbar(
                thumbColor: Colors.grey,
                isAlwaysShown: true,
                radius: Radius.circular(16),
                thickness: 7,
                child: SingleChildScrollView(
                  primary: true,
                  scrollDirection: Axis.vertical,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Stack(
                        clipBehavior: Clip.antiAlias,
                        alignment: Alignment.bottomLeft,
                        children: [
                          Container(
                            width: width,
                            height: height / 4.5,
                            color: Colors.grey[200],
                            margin: EdgeInsets.only(bottom: height / 15),
                            child: InkWell(
                                onTap: () async {
                                  controller.coverImage = await controller
                                      .callGetImage(imageType: "cover");
                                  controller.update();
                                },
                                child: controller.coverImage != null
                                    ? Image.memory(
                                        controller.coverImage,
                                        fit: BoxFit.cover,
                                      )
                                    : controller.userProfile == null
                                        ? SizedBox()
                                        :
                                        // controller.userProfile
                                        //             .coverImage ==
                                        //         null
                                        //     ?
                                        //     :
                                        ClipRRect(
                                            borderRadius:
                                                BorderRadius.circular(0),
                                            child: FadeInImage(
                                                fit: BoxFit.cover,
                                                width: 24,
                                                height: 24,
                                                placeholder: AssetImage(
                                                    'assets/images/person_placeholder.png'),
                                                image: NetworkImage(controller
                                                            .userProfile
                                                            .coverImage !=
                                                        null
                                                    ? controller
                                                            .coverImageDelete
                                                        ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                        : controller.userProfile
                                                            .coverImage
                                                    : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                          )),
                          ),
                          Positioned(
                            top: 60,
                            right: 0,
                            left: 0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Tooltip(
                                  message: Strings.addPhoto,
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                  ),
                                  child: Container(
                                    height: 42,
                                    width: 42,
                                    alignment: Alignment.center,
                                    // padding: const EdgeInsets.all(13),
                                    decoration: BoxDecoration(
                                      color: Colors.black54,
                                      shape: BoxShape.circle,
                                    ),
                                    child: IconButton(
                                      icon: Icon(
                                        Icons.camera_alt_outlined,
                                        size: 22,
                                        color: Colors.white,
                                      ),
                                      onPressed: () async {
                                        // print("heelo");
                                        controller.coverImage = await controller
                                            .callGetImage(imageType: "cover");
                                        controller.coverImageDelete = false;
                                        // print(
                                        //     "controller.coverImage ${controller.coverImage}");
                                        controller.update();
                                      },
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                Tooltip(
                                  message: Strings.removePhoto,
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                  ),
                                  child: Container(
                                    height: 42,
                                    width: 42,
                                    alignment: Alignment.center,
                                    // padding: const EdgeInsets.all(13),
                                    decoration: BoxDecoration(
                                      color: Colors.black54,
                                      shape: BoxShape.circle,
                                    ),
                                    child: IconButton(
                                      icon: Icon(
                                        Icons.close,
                                        size: 22,
                                        color: Colors.white,
                                      ),
                                      onPressed: () async {
                                        controller.coverImage = null;
                                        controller.coverImageDelete = true;
                                        controller.update();
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Stack(
                              children: [
                                CircleAvatar(
                                    radius: 65,
                                    backgroundColor: Colors.white,
                                    child: controller.profileImage != null
                                        ? CircleAvatar(
                                            radius: 60,
                                            backgroundImage: MemoryImage(
                                                controller.profileImage),
                                            backgroundColor: Colors.white,
                                          )
                                        : controller.userProfile == null
                                            ? CircularProgressIndicator(
                                                color: MyColors.BlueColor,
                                              )
                                            : ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(60),
                                                child: FadeInImage(
                                                    fit: BoxFit.cover,
                                                    width: 120,
                                                    height: 120,
                                                    placeholder: AssetImage(
                                                        'assets/images/person_placeholder.png'),
                                                    image: NetworkImage(controller
                                                                .userProfile
                                                                .profileImage !=
                                                            null
                                                        ? controller
                                                                .profileImageDelete
                                                            ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                            : controller
                                                                .userProfile
                                                                .profileImage
                                                        : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                              )),
                                Positioned(
                                  bottom: 2,
                                  right: 2,
                                  // top: 70,
                                  // right: 0,
                                  // left: 80,
                                  child: PopupMenuButton(
                                    constraints: BoxConstraints.expand(
                                        height: 100, width: 170),
                                    position: PopupMenuPosition.under,
                                    onSelected: (value) async {
                                      if (value == 1) {
                                        controller.profileImage =
                                            await controller.callGetImage();
                                        controller.profileImageDelete = false;
                                        controller.update();
                                      } else if (value == 2) {
                                        controller.profileImage = null;
                                        controller.profileImageDelete = true;
                                        controller.update();
                                      }
                                    },
                                    offset: Offset(10, 8),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(15),
                                    ),
                                    itemBuilder: (BuildContext context) => [
                                      PopupMenuItem(
                                          value: 1,
                                          child: Row(
                                            children: [
                                              Icon(Icons.add),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                "${Strings.addPhoto}${controller.userName}",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                            ],
                                          )),
                                      PopupMenuItem(
                                          value: 2,
                                          child: Row(
                                            children: [
                                              Icon(
                                                Icons.delete,
                                                color: Colors.red,
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                "${Strings.deletePhoto}${controller.userName}",
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ),
                                              ),
                                            ],
                                          )),
                                    ],
                                    child: Tooltip(
                                      message: Strings.addPhoto,
                                      decoration:
                                          BoxDecoration(color: Colors.black54),
                                      child: Container(
                                        height: 40,
                                        width: 40,
                                        alignment: Alignment.center,
                                        // padding: const EdgeInsets.all(13),
                                        decoration: BoxDecoration(
                                          color: Colors.black54,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(
                                          Icons.camera_alt_outlined,
                                          color: Colors.white,
                                          size: 20,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // Tooltip(
                                  //   message : "Add photo",
                                  //   decoration: BoxDecoration(
                                  //       color: Colors.black54
                                  //   ),
                                  //   child: Container(
                                  //     height: 40,
                                  //     width: 40,
                                  //     alignment: Alignment.center,
                                  //     // padding: const EdgeInsets.all(13),
                                  //     decoration: BoxDecoration(
                                  //       color: Colors.black54,
                                  //       shape: BoxShape.circle,
                                  //     ),
                                  //     child: IconButton(
                                  //       icon: Icon(
                                  //         Icons.camera_alt_outlined,
                                  //         color: Colors.white,
                                  //         size: 20,
                                  //       ),
                                  //       onPressed: () async {
                                  //         controller.profileImage = await controller.callGetImage();
                                  //         controller.update();
                                  //       },
                                  //     ),
                                  //   ),
                                  // ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      // Align(
                      //   alignment: Alignment.topLeft,
                      //   child: Row(
                      //     crossAxisAlignment: CrossAxisAlignment.center,
                      //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //     children: [
                      //      Row(
                      //        children: [
                      //          IconButton(
                      //            // highlightColor: Colors.transparent,
                      //            // hoverColor: Colors.transparent,
                      //            // focusColor: Colors.transparent,
                      //            onPressed: () {
                      //              // controller.isProfile = false;
                      //              // controller.isCover = false;
                      //              // controller.isBio = false;
                      //              // controller.isUsername = false;
                      //              // controller.selectedView = "";
                      //              // controller.update();
                      //              Navigator.of(context).pop();
                      //            },
                      //            icon: Icon(Icons.close, size: MediaQuery.of(context).size.width >= 1200 ? 36 : 24,color: Colors.black,),
                      //          ),
                      //          SizedBox(width: width / 20),
                      //          Text("Edit profile",style: Get.textTheme.headline3.copyWith(
                      //            color: Colors.black,
                      //          )),
                      //        ],
                      //      ),
                      //       ElevatedButton(
                      //         style: ElevatedButton.styleFrom(
                      //           elevation: 0.5,
                      //           backgroundColor: Colors.black,
                      //           shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      //         ),
                      //           onPressed: (){},
                      //           child: Text("Save",style: Get.textTheme.headline3.copyWith(color: Colors.white),)
                      //       ),
                      //
                      //       // SvgPicture.asset(
                      //       //   AppImages.logo,
                      //       //   width: kIsWeb ? width / 10 : 120,
                      //       //   // height: 150,
                      //       //   // color: Color((0xFF47b867)),
                      //       // ),
                      //       // // Image(
                      //       // //   image:
                      //       // //   AssetImage("assets/images/Logo_werfie.png"),
                      //       // //   // height: kIsWeb ? width / 10 : 80,
                      //       // //   width: kIsWeb ? width / 10 : 120,
                      //       // //   fit: BoxFit.contain,
                      //       // // )
                      //     ],
                      //   ),
                      // ),
                      //   Stack(
                      //     clipBehavior: Clip.none,
                      //     alignment: Alignment.bottomLeft,
                      //     children: [
                      //       // COVER PHOTO
                      //       Container(
                      //           width: width,
                      //           height: height /4.5,
                      //           color: Colors.grey,
                      //           // margin: EdgeInsets.only(bottom: height / 15),
                      //           child:
                      //           controller.coverImage != null?
                      //           Center(
                      //             child: InkWell(
                      //               onTap: () async{
                      //                 controller.coverImage =
                      //                 await controller.callGetImage();
                      //                 controller.update();
                      //               },
                      //               child: Container(
                      //                 height: 50,
                      //                 width: 50,
                      //                 alignment: Alignment.center,
                      //                 padding: const EdgeInsets.all(13),
                      //                 decoration: BoxDecoration(
                      //                   color: Colors.grey[600],
                      //                   shape: BoxShape.circle,
                      //                 ),
                      //                 child: Icon(Icons.camera_alt_outlined,size: 25,color: Colors.white,),
                      //               ),
                      //
                      //             ),
                      //           ):
                      //           Stack(
                      //             children: [
                      //               Container(
                      //                 width: width,
                      //                 height: Get.height ,
                      //                 color: Colors.grey,
                      //                 // margin: EdgeInsets.only(bottom: height / 15),
                      //                 child: controller.coverImage !=
                      //                     null?
                      //                 Image.memory(
                      //                   controller.coverImage,
                      //                   fit: BoxFit.cover,
                      //                 )
                      //                     : controller.userProfile ==
                      //                     null
                      //                     ? SizedBox()
                      //                     : // controller.userProfile
                      // //             .coverImage ==
                      // //         null
                      // //     ?
                      // //     :
                      //                   ClipRRect(borderRadius: BorderRadius.circular(0),
                      //                     child: FadeInImage(
                      //                         fit: BoxFit
                      //                             .cover,
                      //                         // width: 24,
                      //                         // height: 24,
                      //                         placeholder:
                      //                         AssetImage(
                      //                             'assets/images/person_placeholder.png'),
                      //                         image: NetworkImage(controller
                      //                             .userProfile
                      //                             .coverImage !=
                      //                             null
                      //                             ? controller
                      //                             .userProfile
                      //                             .coverImage
                      //                             : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                      //                   ),
                      //               ),
                      //               Positioned(
                      //                   left: 185,
                      //                   top: 40,
                      //                   child: InkWell(
                      //                     onTap: () async{
                      //                       controller.coverImage =
                      //                           await controller.callGetImage();
                      //                       controller.update();
                      //                     },
                      //                     child: Container(
                      //                          height: 50,
                      //                         width: 50,
                      //                         alignment: Alignment.center,
                      //                         padding: const EdgeInsets.all(13),
                      //                           decoration: BoxDecoration(
                      //                             color: Colors.grey[600],
                      //                             shape: BoxShape.circle,
                      //                           ),
                      //                         child: Icon(Icons.camera_alt_outlined,size: 25,color: Colors.white,),
                      //
                      //                       ),
                      //
                      //               )),
                      //             ],
                      //           ),
                      //           // child: controller.userProfile == null
                      //           //     ? SizedBox()
                      //           //     : ClipRRect(
                      //           //   borderRadius: BorderRadius.circular(0),
                      //           //   child: FadeInImage(
                      //           //     placeholderErrorBuilder:
                      //           //         (context, _, __) {
                      //           //       return Image.asset(
                      //           //           'assets/images/person_placeholder.png');
                      //           //     },
                      //           //     imageErrorBuilder: (context, _, __) {
                      //           //       return Image.asset(
                      //           //           'assets/images/person_placeholder.png');
                      //           //     },
                      //           //     fit: BoxFit.cover,
                      //           //     width: 24,
                      //           //     height: 24,
                      //           //     placeholder: AssetImage(
                      //           //         'assets/images/person_placeholder.png'),
                      //           //     image: NetworkImage(controller
                      //           //         .userProfile.coverImage !=
                      //           //         null
                      //           //         ? controller.userProfile.coverImage
                      //           //         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                      //           //   ),
                      //           // ),
                      //         ),
                      //       Positioned(
                      //         left: 20,
                      //         top: 120,
                      //         child: CircleAvatar(
                      //                   radius: 65,
                      //                   // backgroundColor: Theme.of(context).colorScheme.secondary,
                      //                   backgroundColor: Colors.white,
                      //                   child: CircleAvatar(
                      //                     radius:60,
                      //                     backgroundColor: Colors.grey,
                      //                     child: Container(
                      //                       alignment: Alignment.center,
                      //                       decoration: BoxDecoration(
                      //                         color: Colors.grey,
                      //                         borderRadius: BorderRadius.circular( 60 ),
                      //                       ),
                      //                       child: Stack(
                      //                         children: [
                      //                           Center(
                      //                             child: Container(
                      //                               decoration: BoxDecoration(
                      //                                 color: Colors.grey,
                      //                                 borderRadius: BorderRadius.circular(60),
                      //                               ),
                      //                               child: controller.profileImage != null
                      //                                   ? CircleAvatar(
                      //                                 radius: 60,
                      //                                 backgroundImage: MemoryImage(
                      //                                     controller.profileImage),
                      //                                 backgroundColor: Colors.grey,
                      //                               )
                      //                                   : controller.userProfile == null
                      //                                   ? CircularProgressIndicator()
                      //                                   : ClipRRect(
                      //                                 borderRadius:
                      //                                 BorderRadius.circular(
                      //                                     60 ),
                      //                                 child: FadeInImage(
                      //                                     fit: BoxFit.cover,
                      //                                     width: 190,
                      //                                     height: 190,
                      //                                     placeholder: AssetImage(
                      //                                         'assets/images/person_placeholder.png'),
                      //                                     image: NetworkImage(controller.userProfile.profileImage != null
                      //                                         ? controller.userProfile.profileImage
                      //                                         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                      //                               ),
                      //                             ),
                      //                           ),
                      //                           Positioned(
                      //                                left: 42,
                      //                                 top: 45,
                      //                               child: InkWell(
                      //                                 onTap: () async{
                      //                                   controller.profileImage = await controller.callGetImage();
                      //                                   controller.update();
                      //                                 },
                      //                                 child: Container(
                      //
                      //                                   alignment: Alignment.center,
                      //                                   padding: const EdgeInsets.all(8),
                      //                                   decoration: BoxDecoration(
                      //                                     color: Colors.grey[600],
                      //                                     shape: BoxShape.circle,
                      //                                   ),
                      //                                   child: Icon(
                      //                                     Icons.camera_alt_outlined,
                      //                                     size: 20,
                      //                                     color: Colors.white,
                      //                                   ),
                      //                                 ),
                      //                               ),
                      //                           ),
                      //
                      //                         ],
                      //                       ),
                      //                     ),
                      //                     // child: controller.userProfile == null
                      //                     //     ? CircularProgressIndicator()
                      //                     //     : ClipRRect(
                      //                     //   borderRadius:
                      //                     //   BorderRadius.circular(60),
                      //                     //   child: FadeInImage(
                      //                     //     placeholderErrorBuilder:
                      //                     //         (context, _, __) {
                      //                     //       return Image.asset(
                      //                     //           'assets/images/person_placeholder.png');
                      //                     //     },
                      //                     //     imageErrorBuilder:
                      //                     //         (context, _, __) {
                      //                     //       return Image.asset(
                      //                     //           'assets/images/person_placeholder.png');
                      //                     //     },
                      //                     //     fit: BoxFit.cover,
                      //                     //     width: 150,
                      //                     //     height: 150,
                      //                     //     placeholder: AssetImage(
                      //                     //         'assets/images/person_placeholder.png'),
                      //                     //     image: NetworkImage(controller
                      //                     //         .userProfile
                      //                     //         .profileImage !=
                      //                     //         null
                      //                     //         ? controller.userProfile
                      //                     //         .profileImage
                      //                     //         : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                      //                     //   ),
                      //                     // ),
                      //                   ),
                      //                 ),
                      //       ),
                      //     ],
                      //   ),
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                Strings.name,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontSize: kIsWeb ? 16 : 14,
                                  fontWeight: FontWeight.w400,
                                ),
                                // TextStyle(
                                //   color: Color(0xFF586976),
                                //   fontSize: kIsWeb ? 18 : 16,
                                //   fontWeight: FontWeight.w400,
                                // ),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            ProfileDialogTextField(
                              controller: controller.usernameText,
                              text: Strings.name,
                              maxLength: 25,
                              maxLines: 2,
                              inputFormatters: [
                                LengthLimitingTextInputFormatter(25),
                                FilteringTextInputFormatter.allow(
                                    RegExp('[a-zA-Z]+[ a-zA-Z]*')),
                                FilteringTextInputFormatter.deny('  '),
                                FilteringTextInputFormatter.deny('@'),

                                // FilteringTextInputFormatter.deny(' '),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                Strings.bio,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontSize: kIsWeb ? 16 : 14,
                                  fontWeight: FontWeight.w400,
                                ),
                                // TextStyle(
                                //   color: Color(0xFF586976),
                                //   fontSize: kIsWeb ? 18 : 16,
                                //   fontWeight: FontWeight.w400,
                                // ),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            ProfileDialogTextField(
                              controller: controller.bioText,
                              text: Strings.bio,
                              maxLines: 3,
                              maxLength: 160,
                              inputFormatters: null,
                              // [
                              //   LengthLimitingTextInputFormatter(20),
                              //   FilteringTextInputFormatter.allow(RegExp('[a-zA-Z]+[ a-zA-Z]*')),
                              //   FilteringTextInputFormatter.deny('@'),
                              //   // FilteringTextInputFormatter.allow(RegExp('[0-9]')),
                              //  // FilteringTextInputFormatter.deny(' '),
                              // ],
                            ),

                            /// location and website commit pending
                            // const SizedBox(height: 10,),
                            // ProfileDialogTextField(
                            //   controller: controller.locationController,
                            //   text: "Location",
                            //   maxLength: 30,
                            //   maxLines: 1,
                            //
                            // ),
                            // const SizedBox(height: 10,),
                            // ProfileDialogTextField(
                            //   controller: controller.websiteController,
                            //   text: "Website",
                            //   maxLength: 100,
                            //   maxLines: 2,
                            //
                            // ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Text(Strings.birthDate,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontSize: kIsWeb ? 16 : 14,
                                      fontWeight: FontWeight.w400,
                                    )
                                    // TextStyle(
                                    //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                                    //   fontSize: kIsWeb ? 16 : 14,
                                    //   fontWeight: FontWeight.w400,
                                    // ),
                                    ),
                                const SizedBox(
                                  width: 5,
                                ),
                                controller.changeText == true
                                    ? InkWell(
                                        onTap: () {
                                          showDialog(
                                            useSafeArea: false,
                                            context: context,
                                            builder: (BuildContext context) =>
                                                AlertDialog(
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(20),
                                              ),
                                              contentPadding:
                                                  const EdgeInsets.all(0.0),
                                              insetPadding:
                                                  const EdgeInsets.all(0.0),
                                              content: Container(
                                                height: kIsWeb
                                                    ? 300
                                                    : Get.height * 0.40,
                                                width: kIsWeb
                                                    ? 200
                                                    : Get.width * 0.8,
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.all(20),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                      Text(
                                                          Strings.editDateOfBirth,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 18
                                                                : 16,
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          )
                                                          // TextStyle(
                                                          //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          //     fontWeight: FontWeight.bold,
                                                          //     fontSize: kIsWeb ? 18 : 16,
                                                          // ),
                                                          ),
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                      Text(
                                                       Strings.thisCanBeOnlyChangedAFewTimes,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                                FontWeight.w400,
                                                            fontSize: 14,
                                                          )
                                                          // TextStyle(
                                                          //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          //   fontWeight: FontWeight.w500,
                                                          //   fontSize:  14,
                                                          // ),
                                                          ),
                                                      SizedBox(
                                                        height: 20,
                                                      ),
                                                      AlertElevatedBtnWidget(
                                                        onPressed: () {
                                                          controller.visible =
                                                              false;
                                                          controller
                                                                  .changeText =
                                                              false;
                                                          controller.update();
                                                          Navigator.pop(
                                                              context);
                                                        },
                                                        tittle: Strings.edit,
                                                        color: Colors.black,
                                                        textColor: Colors.white,
                                                      ),
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                      AlertElevatedBtnWidget(
                                                        onPressed: () {
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .changeText =
                                                              true;
                                                          controller.update();
                                                        },
                                                        tittle: Strings.cancel,
                                                        color: Colors.white,
                                                        textColor: Colors.black,
                                                      ),
                                                      SizedBox(
                                                        height: 10,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          );
                                          controller.dob = false;
                                        },
                                        child: Text(Strings.edit,
                                            style: Styles
                                                .baseTextTheme.headline1
                                                .copyWith(
                                              color: controller
                                                  .newsFeedControler
                                                  .displayColor,
                                              fontSize: kIsWeb ? 16 : 14,
                                            )
                                            // TextStyle(
                                            //   color: Colors.blue,
                                            //   fontWeight: FontWeight.bold,
                                            //   fontSize: kIsWeb ? 16 : 14,
                                            // ),
                                            ),
                                      )
                                    : InkWell(
                                        onTap: () {
                                          controller.visible = true;
                                          controller.changeText = true;
                                          controller.dob = true;
                                          controller.update();
                                        },
                                        child: Text(
                                          Strings.cancel,
                                          style: Styles.baseTextTheme.headline1
                                              .copyWith(
                                            color: controller
                                                .newsFeedControler.displayColor,
                                            fontSize: kIsWeb ? 16 : 14,
                                          ),
                                          // TextStyle(
                                          //     color:Theme.of(context).brightness == Brightness.dark ? Colors.blue : Colors.blue,
                                          //     fontWeight: FontWeight.bold,
                                          //     fontSize: kIsWeb ? 16 : 14,
                                          // ),
                                        ),
                                      ),
                              ],
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            controller.visible == false
                                ? Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        Strings.thisShouldBeTheDateOfBirthOfThePersonUsingTheAccount,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w300,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 30,
                                      ),
                                      Form(
                                        key: controller.formKey,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            // Drop Down Button for Month
                                            ButtonTheme(
                                              materialTapTargetSize:
                                                  MaterialTapTargetSize.padded,
                                              child: Expanded(
                                                flex: 2,
                                                child: DropdownButtonFormField<
                                                    String>(
                                                  icon: Icon(Icons
                                                      .keyboard_arrow_down),
                                                  isExpanded: true,
                                                  validator: (value) =>
                                                      value == null
                                                          ? Strings.fieldRequired
                                                          : null,

                                                  decoration: InputDecoration(
                                                    contentPadding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 8,
                                                            horizontal: 16),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    disabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(),
                                                    labelText: Strings.month,
                                                    labelStyle: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                    ),
                                                  ),
                                                  // value: 0.toString(),
                                                  hint: Text(
                                                    controller.selectedMonth,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                  ),

                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  items: controller.months
                                                      .map((String value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value,
                                                      child: Text(
                                                        value.toString(),
                                                        style: TextStyle(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (month) {
                                                    controller.selectedMonth =
                                                        month;
                                                    controller.update();
                                                  },
                                                ),
                                              ),
                                            ),
                                            SizedBox(width: 5),
                                            // Drop Down Button for Day
                                            ButtonTheme(
                                              materialTapTargetSize:
                                                  MaterialTapTargetSize.padded,
                                              child: Expanded(
                                                flex: 2,
                                                child: DropdownButtonFormField<
                                                    String>(
                                                  icon: Icon(Icons
                                                      .keyboard_arrow_down),
                                                  isExpanded: true,
                                                  validator: (value) =>
                                                      value == null
                                                          ? Strings.fieldRequired
                                                          : null,
                                                  decoration: InputDecoration(
                                                    contentPadding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 8,
                                                            horizontal: 16),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    disabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    labelText: Strings.day,
                                                    labelStyle: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                    ),
                                                  ),
                                                  // value: 0.toString(),
                                                  hint: Text(
                                                    controller.selectedDay,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    // DateTime.now().day.toString(),
                                                    // controller.selectedDay.isEmpty ? controller.DayDob() : " ",
                                                  ),
                                                  //hint: Text(controller.selectedDay),
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  items: List.generate(31,
                                                          (index) => index + 1)
                                                      .map((int value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value.toString(),
                                                      child: Text(
                                                        value.toString(),
                                                        style: TextStyle(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (day) {
                                                    controller.selectedDay =
                                                        day;

                                                    controller.update();
                                                    // }
                                                    // }
                                                  },
                                                ),
                                              ),
                                            ),

                                            SizedBox(width: 5),

                                            // Drop Down Button for Year

                                            ButtonTheme(
                                              materialTapTargetSize:
                                                  MaterialTapTargetSize.padded,
                                              child: Expanded(
                                                flex: 2,
                                                child: DropdownButtonFormField<
                                                    String>(
                                                  icon: Icon(Icons
                                                      .keyboard_arrow_down),
                                                  isExpanded: true,
                                                  validator: (value) =>
                                                      value == null
                                                          ? Strings.fieldRequired
                                                          : null,
                                                  decoration: InputDecoration(
                                                    contentPadding:
                                                        EdgeInsets.symmetric(
                                                            vertical: 8,
                                                            horizontal: 12),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    disabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      borderSide: BorderSide(
                                                          color: Colors.grey),
                                                    ),
                                                    labelText: Strings.year,
                                                    labelStyle: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                    ),
                                                  ),
                                                  // value: 0.toString(),
                                                  hint: Text(
                                                    controller.selectedYear,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 16 : 14,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                    ),
                                                    // DateTime.now().year.toString(),
                                                    //  ""
                                                    // controller.selectedYear.isEmpty ?  controller.YearDob() : " ",
                                                  ),
                                                  //hint: Text(controller.selectedYear),
                                                  alignment:
                                                      Alignment.bottomCenter,
                                                  items: controller.years
                                                      .map((int value) {
                                                    return DropdownMenuItem<
                                                        String>(
                                                      value: value.toString(),
                                                      child: Text(
                                                        value.toString(),
                                                        style: TextStyle(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                        ),
                                                      ),
                                                    );
                                                  }).toList(),
                                                  onChanged: (year) {
                                                    // controller.selectedYearValue = year;
                                                    // controller.scheduleYearValue = year;
                                                    // controller.selectedDateTime = "$controller.selectedYearValue-$controller.selectedMonthValue-$controller.selectedDayValue" + " $controller.selectedHourValue:$controller.selectedMinutesValue:00";
                                                    //
                                                    // print('Scheduled Year ' +       controller.scheduleYearValue.toString());
                                                    controller.selectedYear =
                                                        year;
                                                    controller.update();
                                                    // pollDays = days;
                                                    // setState(() {});
                                                  },
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      ///  Dropdown Mont,Day&Year commit
                                      // const SizedBox(height: 30,),
                                      // Text("Who sees this?",style: Get.textTheme.headline3.copyWith(color: Colors.black),),
                                      // const SizedBox(height: 30,),
                                      // Container(
                                      //   padding: const EdgeInsets.only(left: 10,right: 10),
                                      //   decoration: BoxDecoration(
                                      //     color: Colors.grey.withOpacity(0.2),
                                      //    border: Border.all(color: Colors.grey),
                                      //     borderRadius: BorderRadius.circular(10),
                                      //   ),
                                      //   width: double.infinity,
                                      //
                                      //   child: DropdownButton<String>(
                                      //
                                      //     isExpanded: true,
                                      //     borderRadius: BorderRadius.circular(10),
                                      //     // value: controller.dropdownValue,
                                      //     hint: Text("${controller.dropdownValue == null ? "Month and day" : controller.dropdownValue}"),
                                      //     icon: const Icon(Icons.keyboard_arrow_down),
                                      //     elevation: 16,
                                      //     style: const TextStyle(color: Colors.black),
                                      //     underline: Container(
                                      //       width: double.infinity,
                                      //       height: 0.0,
                                      //       color: Colors.black,
                                      //     ),
                                      //     onChanged: (String value) {
                                      //       // This is called when the user selects an item.
                                      //       controller.dropdownValue = value;
                                      //       controller.update;
                                      //     },
                                      //     items: controller.list.map<DropdownMenuItem<String>>((String value) {
                                      //       return DropdownMenuItem<String>(
                                      //         value: value,
                                      //         child: Text(value),
                                      //       );
                                      //     }).toList(),
                                      //   ),
                                      //
                                      // ),
                                      // const SizedBox(height: 30,),
                                      // Container(
                                      //   padding: const EdgeInsets.only(left: 10,right: 10),
                                      //   decoration: BoxDecoration(
                                      //     color: Colors.grey.withOpacity(0.2),
                                      //     border: Border.all(color: Colors.grey),
                                      //     borderRadius: BorderRadius.circular(10),
                                      //   ),
                                      //   width: double.infinity,
                                      //   child: DropdownButton<String>(
                                      //     isExpanded: true,
                                      //     borderRadius: BorderRadius.circular(10),
                                      //     value: controller.dropdownValueYear,
                                      //     icon: const Icon(Icons.keyboard_arrow_down),
                                      //     elevation: 16,
                                      //     style: const TextStyle(color: Colors.black),
                                      //     underline: Container(
                                      //       width: double.infinity,
                                      //       height: 0.0,
                                      //       color: Colors.black,
                                      //     ),
                                      //     onChanged: (String value) {
                                      //       // This is called when the user selects an item.
                                      //       controller.dropdownValueYear = value;
                                      //       controller.update;
                                      //     },
                                      //     items: controller.list.map<DropdownMenuItem<String>>((String value) {
                                      //       return DropdownMenuItem<String>(
                                      //         value: value,
                                      //         child: Text(value),
                                      //       );
                                      //     }).toList(),
                                      //   ),
                                      //
                                      // ),
                                    ],
                                  )
                                : SizedBox(),
                            const SizedBox(
                              height: 10,
                            ),
                            controller.dob == true
                                ? Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Text(
                                          // controller.months[DateTime.now().month - 1] + " " + DateTime.now().day.toString() + "," + " " + DateTime.now().year.toString(),
                                          "${controller.userProfile.dob != null ? controller.userProfile.dob.replaceAll(RegExp(r"\s+"), " ") : ''}",
                                          style: Styles.baseTextTheme.headline1
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 18 : 16,
                                            fontWeight: FontWeight.w600,
                                          )
                                          // TextStyle(
                                          //     color:Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          //     fontWeight: FontWeight.bold,
                                          //     fontSize: kIsWeb ? 18 : 16,
                                          // ),
                                          ),
                                    ],
                                  )
                                : SizedBox(),
                            // Row(
                            //   children: [
                            //     Text("Birth Date",style: Get.textTheme.headline3.copyWith(color: Colors.black)),
                            //     const SizedBox(width: 5,),
                            //     controller.visible == true ?InkWell(
                            //       onTap: (){
                            //         controller.visible = false;
                            //         controller.update();
                            //       },
                            //       child: Text('Edit',style: Get.textTheme.headline3.copyWith(color: Colors.blue)),
                            //     ):InkWell(
                            //       onTap: (){
                            //         controller.visible = true;
                            //         controller.update();
                            //       },
                            //       child: Text("Cancel",style: Get.textTheme.headline3.copyWith(color: Colors.blue)),
                            //     ),
                            //   ],
                            // ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )),
      );
    });
  }
}

class AlertElevatedBtnWidget extends StatelessWidget {
  const AlertElevatedBtnWidget({
    Key key,
    this.tittle,
    this.onPressed,
    this.color,
    this.textColor,
  }) : super(key: key);
  final String tittle;
  final Function() onPressed;
  final Color color;
  final Color textColor;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        minimumSize: Size(Get.width, 40),
        primary: color,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      onPressed: onPressed,
      child: Text(
        tittle,
        style: TextStyle(
          color: textColor,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class ProfileDialogTextField extends StatefulWidget {
  const ProfileDialogTextField({
    Key key,
    this.text,
    this.maxLength,
    this.maxLines,
    this.controller,
    this.inputFormatters,
  }) : super(key: key);
  final String text;
  final int maxLength;
  final int maxLines;
  final List<TextInputFormatter> inputFormatters;

  final TextEditingController controller;

  @override
  State<ProfileDialogTextField> createState() => _ProfileDialogTextFieldState();
}

class _ProfileDialogTextFieldState extends State<ProfileDialogTextField> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      inputFormatters: widget.inputFormatters,
      // [
      //   LengthLimitingTextInputFormatter(20),
      //   FilteringTextInputFormatter.allow(RegExp('[a-zA-Z]+[ a-zA-Z]*')),
      //   FilteringTextInputFormatter.deny('@'),
      //  // FilteringTextInputFormatter.deny(' '),
      // ],
      maxLength: widget.maxLength,
      style: LightStyles.baseTextTheme.headline2.copyWith(
        color: Theme.of(context).brightness == Brightness.dark
            ? Colors.white
            : Colors.black,
        // fontWeight: FontWeight.w500,
        fontSize: kIsWeb ? 16 : 14,
      ),
      // TextStyle(
      //
      //   fontWeight: FontWeight.w500,
      //   fontSize: kIsWeb ? 20 : 18,
      // ),
      maxLines: widget.maxLines,
      controller: widget.controller,
      keyboardType: TextInputType.emailAddress,

      decoration: InputDecoration(
        fillColor: Colors.grey[250],
        filled: true,
        hintText: widget.text,
        hintStyle: LightStyles.baseTextTheme.headline3.copyWith(
          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
          // fontWeight: FontWeight.w500,
          fontSize: kIsWeb ? 16 : 14,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            color: Colors.grey,
            width: 1,
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(
            color: Colors.grey,
            width: 1,
          ),
        ),
      ),
    );
  }
}
