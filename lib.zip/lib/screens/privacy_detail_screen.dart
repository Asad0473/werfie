import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PrivacyDetailScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
