import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/firebase_deeplinking.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/routes.dart';

import '../helper/world_noor_helper/MethodChannelWorldNoor.dart';

// ignore: must_be_immutable
class Session extends StatefulWidget {
  String postId;
  String profileId;

  Session({this.postId, this.profileId});

  @override
  State<Session> createState() => _SessionState();
}

class _SessionState extends State<Session> {
  final storage = GetStorage();
  SharedPreferences shared;

  @override
  void initState() {
    // print('CALL SHARED INIT');
    // initDynamicLinks();
    // FirebaseDeepLink().initDynamicLinks(context);

    call(context);


    super.initState();
  }

  Future<void> call(BuildContext context) async {
    /* if (widget.initialLink != null) {
      final Uri deepLink = widget.initialLink.link;
      Fluttertoast.showToast(
          msg: deepLink.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.TOP,
          timeInSecForIosWeb: 5);
          timeInSecForIosWeb: 5);
      FirebaseDynamicLinks.instance.onLink.listen((dynamicLinkData) {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => ProfileScreen(
                controller: Get.isRegistered<NewsfeedController>()
                    ? Get.put(NewsfeedController())
                    : Get.find<NewsfeedController>(),
                profileId: "429")));
        // Navigator.pushNamed(context, dynamicLinkData.link.path);
      }).onError((error) {
        // Handle errors
      });
      // Example of using the dynamic link to push the user to a different screen
      // Navigator.pushNamed(context, ProfileScreen());
      Get.to(() =>  ProfileScreen(
          controller: Get.isRegistered<NewsfeedController>()
              ? Get.put(NewsfeedController())
              : Get.find<NewsfeedController>(),
          profileId: "429"));
      // Navigator.of(context).push(MaterialPageRoute(
      //     builder: (context) => ProfileScreen(
      //         controller: Get.isRegistered<NewsfeedController>()
      //             ? Get.put(NewsfeedController())
      //             : Get.find<NewsfeedController>(),
      //         profileId: "429")));
    }*/
    shared = await SharedPreferences.getInstance();
    // print("yes token print");
    Future.delayed(Duration(milliseconds: 1500), () async {
      if (shared.getString("token") != null) {
        // print("put start");

        // Future.delayed(Duration(seconds: 2), () async {
        // Get.offAllNamed(AppRoute.mainScreen,arguments: {
        //   "userName": shared.getString("userName"),
        //   "postId": postId != null ? postId : null,
        //   "profileId": profileId != null ? profileId : null,
        // });
        // Future.delayed(Duration(seconds: 3), () {
        // if (Get.isRegistered<NewsfeedController>()) {
        // print('i am here in if session controller');
        if (kIsWeb) {
          print("changeeeee");
          // Get.offAllNamed(FluroRouters.mainScreen);
          context.go(AppRoute.mainScreen);
        } else {
          //  if (!kIsWeb) {
          // FirebaseDeepLink().initDynamicLinks(context);
          FirebaseDeepLink().handleInitialUri(false);
          FirebaseDeepLink().handleIncomingLinks(true);
          // }
          // if(widget.profileId!=null){
          //   print('HERE IN ELSE CONDITION'+widget.profileId.toString());
          //   // Go to profile route with ID
          //   Get.to(MobileProfileScreen(),arguments: {
          //     "userName": shared.getString("userName"),
          //     "profileId": widget.profileId != null ? widget.profileId : null
          //   });
          //
          // }
          // else{
          Get.offAll(MainScreen(), arguments: {
            "userName": shared.getString("userName"),
            "postId": widget.postId != null ? widget.postId : null,
            "profileId": widget.profileId != null ? widget.profileId : null
          });
        }
        // }
        // }
        // else {
        //   // print('i am here in else session controller');
        //   // Get.put(NewsfeedController(
        //   //   linkId: postId != null ? postId : null,
        //   //   profileId: profileId != null ? profileId : null,
        //   // ));
        //   if (kIsWeb) {
        //     Routemaster.of(context)
        //         .replace(AppRoute.mainScreen, queryParameters: {
        //       "userName": shared.getString("userName"),
        //       "postId": widget.postId != null ? widget.postId : null,
        //       "profileId": widget.profileId != null ? widget.profileId : null
        //     });
        //   } else {
        //
        //     if(widget.profileId!=null){
        //       // Go to profile route with ID
        //       Get.to(MobileProfileScreen(),arguments: {
        //         "userName": shared.getString("userName"),
        //         "profileId": widget.profileId != null ? widget.profileId : null
        //       });
        //
        //     }else{
        //     Get.offAll(MainScreen(), arguments: {
        //       "userName": shared.getString("userName"),
        //       "postId": widget.postId != null ? widget.postId : null,
        //       "profileId": widget.profileId != null ? widget.profileId : null
        //     });}
        //   }
        //   // Get.offAll(MainScreen(
        //   //   userName: shared.getString("userName"),
        //   //   postId: widget.postId != null ? widget.postId : null,
        //   //   profileId: widget.profileId != null ? widget.profileId : null,
        //   // ));
        // }
        Get.put(NewsfeedController(
          linkId: widget.postId != null ? widget.postId : null,
          profileId: widget.profileId != null ? widget.profileId : null,
        ));
        // print("put end");
        String userData = storage.read("user_profile");
        print(storage.read('token'));
        Get.find<NewsfeedController>().userProfile =
            UserProfile.fromJson(jsonDecode(userData));
        Get.find<NewsfeedController>().userProfile.username =
            storage.read("user_name");
        Get.find<NewsfeedController>().userProfile.notificationAllowed =
            storage.read("notificationAllowed");
        if (Get.find<NewsfeedController>().userProfile.notificationAllowed ==
            1) {
          Get.find<NewsfeedController>().notificationStatus = true;
        } else {
          Get.find<NewsfeedController>().notificationStatus = false;
        }
        Get.find<NewsfeedController>().update();

        Get.find<NewsfeedController>().languageData =
            await Get.find<NewsfeedController>().getLanguages();

        // Get.find<NewsfeedController>(). languagesList[0].name =     Get.find<NewsfeedController>(). languageData.appLang.name;
        // Get.find<NewsfeedController>().languagesList[0].id =       Get.find<NewsfeedController>().languageData.appLang.id;
        // Get.find<NewsfeedController>(). languagesList[0].code =    Get.find<NewsfeedController>().  languageData.appLang.code;

        int index =
            Get.find<NewsfeedController>().languagesList.indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.appLang.id ==
              element.id;
        });

        int index2 = Get.find<NewsfeedController>()
            .translationLanguage
            .indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.myLang.id ==
              element.id;
        });

        Get.find<NewsfeedController>().dropdownValue =
            Get.find<NewsfeedController>().languagesList[index];

        Get.find<NewsfeedController>().dropdownValue1 =
            Get.find<NewsfeedController>().translationLanguage[index2];

        // int length =    Get.find<NewsfeedController>(). languagesList.length;
        // for(int i =1;i<length;i++)
        // {
        //
        //   if(Get.find<NewsfeedController>().languagesList[0].name == Get.find<NewsfeedController>().languagesList[i].name)
        //   {
        //
        //
        //     print("i     $i");
        //     Get.find<NewsfeedController>().languagesList.remove(Get.find<NewsfeedController>().languagesList[i]);
        //   }
        // }

        // print(
        //     "language idhr ayie ${Get.find<NewsfeedController>().languageData.appLang.name} ");

        // Get.find<NewsfeedController>().storage.write(,)

        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);

        // Get.find<NewsfeedController>().update();
        if (Get.find<NewsfeedController>().languageData != null) {
          Get.find<NewsfeedController>().isAutoTranslate =
              Get.find<NewsfeedController>()
                          .languageData
                          .autoTranslateSettings
                          .autoTranslate ==
                      1
                  ? true
                  : false;
          Get.find<NewsfeedController>().selectedLanguage =
              Get.find<NewsfeedController>().languageData.myLang;
        }
        // print('CALL SHARED INIT WITH ID');
        // });

        // Get.delete<SessionController>();
        // });
      } else {
        if (kIsWeb) {
          // Get.offAllNamed(FluroRouters.loginScreen);
          context.go(AppRoute.loginScreen);
        } else {
          Get.offAll(LoginScreen(), arguments: {
            "postId": widget.postId != null ? widget.postId : null,
            "profileId": widget.profileId != null ? widget.profileId : null
          });
        }
        // Get.offAll(LoginScreen(
        //   postId: widget.postId != null ? widget.postId : null,
        //   profileId: widget.profileId != null ? widget.profileId : null,
        // ));
        // Get.delete<SessionController>();
      }
      if(!kIsWeb) {
        if (Platform.isIOS)
          MethodChannelWorldNoor.instance.configureChannel();
      }

    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.postId != null) {
      // print('POST ID I HA SESSION' + widget.postId);
    } else if (widget.profileId != null) {
      // print('PROFILE ID I HA SESSION' + widget.profileId);
    } else {
      // print('KXH BHI NI AAYYYAAA SESSION');
    }

    // return
    //   GetBuilder(
    //     init: SessionController(
    //         postId: widget.postId != null ? widget.postId : null,
    //         profileId: widget.profileId != null ? widget.profileId : null),
    //     builder: (_) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(child: SizedBox.shrink()),
    );
    // });
  }
}

class SessionController extends GetxController {
  String postId;
  String profileId;

  SessionController({this.postId, this.profileId});

  final storage = GetStorage();
  SharedPreferences shared;

  @override
  void onInit() async {
    // print('CALL SHARED INIT');
    shared = await SharedPreferences.getInstance();
    Future.delayed(Duration(seconds: 1), () async {
      if (shared.getString("token") != null) {
        // print("put start");

        // Future.delayed(Duration(seconds: 2), () async {
        // Get.offAllNamed(AppRoute.mainScreen,arguments: {
        //   "userName": shared.getString("userName"),
        //   "postId": postId != null ? postId : null,
        //   "profileId": profileId != null ? profileId : null,
        // });
        // Future.delayed(Duration(seconds: 3), () {
        if (Get.isRegistered<NewsfeedController>()) {
          // print('i am here in if session controller');
          // Routemaster.of(context).
          // Routemaster.of(context).push('profile/1');
          // Get.offAll(MainScreen(
          //   userName: shared.getString("userName"),
          //   postId: postId != null ? postId : null,
          //   profileId: profileId != null ? profileId : null,
          // ));
        } else {
          // print('i am here in else session controller');
          // Get.put(NewsfeedController(
          //   linkId: postId != null ? postId : null,
          //   profileId: profileId != null ? profileId : null,
          // ));
          // Get.offAll(MainScreen(
          //   userName: shared.getString("userName"),
          //   postId: postId != null ? postId : null,
          //   profileId: profileId != null ? profileId : null,
          // ));
        }
        Get.put(NewsfeedController(
          linkId: postId != null ? postId : null,
          profileId: profileId != null ? profileId : null,
        ));
        // print("put end");
        String userData = storage.read("user_profile");

        Get.find<NewsfeedController>().userProfile =
            UserProfile.fromJson(jsonDecode(userData));
        Get.find<NewsfeedController>().userProfile.username =
            storage.read("user_name");
        Get.find<NewsfeedController>().userProfile.notificationAllowed =
            storage.read("notificationAllowed");
        if (Get.find<NewsfeedController>().userProfile.notificationAllowed ==
            1) {
          Get.find<NewsfeedController>().notificationStatus = true;
        } else {
          Get.find<NewsfeedController>().notificationStatus = false;
        }
        Get.find<NewsfeedController>().update();
        Get.find<NewsfeedController>().languageData =
            await Get.find<NewsfeedController>().getLanguages();

        int index =
            Get.find<NewsfeedController>().languagesList.indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.appLang.id ==
              element.id;
        });

        int index2 = Get.find<NewsfeedController>()
            .translationLanguage
            .indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.myLang.id ==
              element.id;
        });

        Get.find<NewsfeedController>().dropdownValue =
            Get.find<NewsfeedController>().languagesList[index];

        Get.find<NewsfeedController>().dropdownValue1 =
            Get.find<NewsfeedController>().translationLanguage[index2];

        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);

        // Get.find<NewsfeedController>().update();
        if (Get.find<NewsfeedController>().languageData != null) {
          Get.find<NewsfeedController>().isAutoTranslate =
              Get.find<NewsfeedController>()
                          .languageData
                          .autoTranslateSettings
                          .autoTranslate ==
                      1
                  ? true
                  : false;
          Get.find<NewsfeedController>().selectedLanguage =
              Get.find<NewsfeedController>().languageData.myLang;
        }
        // print('CALL SHARED INIT WITH ID');
        // });

        // Get.delete<SessionController>();
        // });
      } else {
        Get.offAll(LoginScreen(
          postId: postId != null ? postId : null,
          profileId: profileId != null ? profileId : null,
        ));
        Get.delete<SessionController>();
      }
    });
    super.onInit();
  }

// @override
// void onClose() {
//   super.onClose();
// }
}
