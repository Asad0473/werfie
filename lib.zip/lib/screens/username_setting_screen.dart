import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/profile_controller.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class UserNameSettingScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  ProfileController profileController = Get.put(ProfileController());

  TextEditingController username = TextEditingController();

//  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.ChangeUsernameSettings,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                    // TextStyle(
                    //     color: Colors.white,
                    //     fontSize: 18,
                    //     fontWeight: FontWeight.w700
                    // ),
                    // style: Theme.of(context).textTheme.headline6.copyWith(
                    //   fontSize: 18,
                    //   fontWeight: FontWeight.w700,
                    //   color: Colors.black,
                    // ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = true;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                if (!kIsWeb) {
                                  FocusManager.instance.primaryFocus?.unfocus();
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Column(
            children: [
              kIsWeb
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 16.0,
                        horizontal: 12,
                      ),
                      child: Row(
                        children: [
                          // MediaQuery.of(context).size.width >= 1050
                          //     ? SizedBox()
                          //     :
                          MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = false;
                                controller.isSettingDetail = false;
                                controller.isSettingTypeDetail = false;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                controller.isChangeUserName = false;
                                controller.isAccountInformation = true;

                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.ChangeUsernameSettings,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                                // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                //     fontSize: 18,fontWeight: FontWeight.w700
                                // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                //),
                                // style: Theme.of(context)
                                //     .textTheme
                                //     .headline6
                                //     .copyWith(
                                //       fontSize: 18,
                                //       fontWeight: FontWeight.w700,
                                //       color: Colors.black,
                                //     ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : Container(),
              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              SizedBox(height: 20),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  // key: formKey,
                  child: Container(
                    // height: 55,
                    child: InputField(
                      formatter: [
                        LengthLimitingTextInputFormatter(20),
                        // FilteringTextInputFormatter.allow(
                        //     RegExp('[a-zA-Z]+[ a-zA-Z]*')),
                        FilteringTextInputFormatter.deny('@'),
                        FilteringTextInputFormatter.deny(' '),
                      ],
                      onChanged: (_) {},
                      hint: Strings.enterYourWerfieHandle,
                      controller: username,
                      validator: (value) {
                        // print("validator $value");
                        return UtilsMethods.validateField(value, username.text);
                      },
                      textInputType: TextInputType.name,
                      fieldIcon: FontAwesomeIcons.userTag,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 20),
              RoundedButton(
                Strings.save,
                () async {
                  String user = username.text;

                  int isSuccess = await controller.saveUsername(user);

                  //  if (formKey.currentState.validate()) {
                  username.clear();
                  if (isSuccess == 1) {
                    UtilsMethods.toastMessageShow(controller.displayColor,
                        controller.displayColor, controller.displayColor,
                        message: Strings.userNameSavedSuccessfully);
                  }
                  if (isSuccess == 3) {
                    UtilsMethods.toastMessageShow(controller.displayColor,
                        controller.displayColor, controller.displayColor,
                        message: Strings.thereWasAnErrorInSavingThisUsername);
                  }
                  if (isSuccess == 2) {
                    UtilsMethods.toastMessageShow(controller.displayColor,
                        controller.displayColor, controller.displayColor,
                        message: Strings.theUsernameHasAlreadyBeenTaken);

                    // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    //   content: Text('There was an error in saving this werf!',
                    //     style: TextStyle(
                    //       color: Theme
                    //           .of(context)
                    //           .brightness == Brightness.dark
                    //           ? Colors.white
                    //           : Colors.black,
                    //     ),
                    //   ),
                    // ),
                    // );
                    // }
                  }

                  controller.update();

                  if (Get.isRegistered<ProfileController>()) {
                    Get.find<ProfileController>().userProfile =
                        await controller.getUserProfile();
                    profileController.update();
                    controller.isAccountInformation = true;
                    controller.isChangeUserName = false;

                    controller.update();
                  } else {
                    profileController.userProfile =
                        await controller.getUserProfile();
                    controller.isAccountInformation = true;
                    controller.isChangeUserName = false;
                    profileController.update();
                    controller.update();
                  }
                },
                horizontalPadding: 20.0,
                verticalPadding: 10.00,
                roundedButtonColor: controller.displayColor,
              ),
            ],
          ),
        );
      },
    );
  }
}
