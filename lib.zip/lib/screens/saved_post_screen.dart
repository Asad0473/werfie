import 'package:flutter/material.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/web_views/web_main_screen.dart';
import 'package:werfieapp/widgets/saved_post_mobile.dart';

class SavedPostScreen extends StatelessWidget {
  final NewsfeedController newsFeedController;

  SavedPostScreen({@required this.newsFeedController});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: MobileSavedPost(newsFeedController: newsFeedController),
        tablet: MobileSavedPost(newsFeedController: newsFeedController),
        desktop: WebMainScreen(),
      ),
    );
  }
}
