import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/utils/font.dart';

import '../../network/controller/add_moment_controller.dart';
import '../../utils/fluro_router.dart';
import '../../utils/strings.dart';
import 'add_moments_screen.dart';
import 'get_moments_list.dart';

class MomentsCreateScreen extends StatelessWidget {
  // const MomentsCreateScreen({Key key}) : super(key: key);
  final controller = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: kIsWeb
          ? PreferredSize(
              preferredSize: Size.fromHeight(100.0),
              child: SizedBox(),
            )
          : PreferredSize(
              preferredSize: Size.fromHeight(100.0),
              child: Container(
                height: 100,
                // color: Colors.amberAccent,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          size: 25,
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        Strings.moments,
                        // style: TextStyle(
                        //     fontSize: 20,
                        //     fontWeight: FontWeight.w700,
                        //     color: Colors.black
                        //
                        // ),
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
      body: SingleChildScrollView(
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 100,
            ),
            Center(
              child: Text(
                Strings.seizeTheMoment,
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
                // style: Get.textTheme.headline3.copyWith(
                //   color: Colors.black,
                //   fontSize: 30,
                //   fontSize: 30,
                //   fontWeight: FontWeight.bold
                // ),
              ),
            ),
            const SizedBox(
              height: 15,
            ),
            Text(
              Strings.chooseAnExistingMomentOrCreateNew,
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: kIsWeb ? 14 : 12,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            !kIsWeb
                ? GestureDetector(
                    onTap: () {
                      Get.to(() => MomentListScreen());
                    },
                    child: Container(
                      height: 50,
                      width: 150,
                      decoration: BoxDecoration(
                          color: controller.displayColor,
                          borderRadius: BorderRadius.circular(30)),
                      child: Center(
                        child: Text(
                          Strings.getMoments,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  )
                : SizedBox(),
            !kIsWeb
                ? SizedBox(
                    height: 50,
                  )
                : SizedBox(),
            kIsWeb
                ? GestureDetector(
                    onTap: () {
                      if (Get.isRegistered<AddMomentsController>()) {
                        Get.delete<AddMomentsController>();

                        final addMomentController =
                            Get.put(AddMomentsController());
                        addMomentController.addId = [];
                        addMomentController.momentEdit = false;
                        addMomentController.update();
                        SingleTone.instance.momentId = null;
                      } else {
                        final addMomentController =
                            Get.put(AddMomentsController());
                        addMomentController.addId = [];
                        addMomentController.momentEdit = false;
                        addMomentController.update();
                        SingleTone.instance.momentId = null;
                      }
                      SingleTone.instance.momentId = null;
                      //  controller.navRoute = "isQuestScreen";
                      controller.update();

                      Get.toNamed(FluroRouters.mainScreen + "/CreateMoment");
                    },
                    child: Container(
                      height: 50,
                      width: 150,
                      decoration: BoxDecoration(
                          color: controller.displayColor,
                          borderRadius: BorderRadius.circular(30)),
                      child: Center(
                        child: Text(
                          Strings.createNew,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  )
                : InkWell(
                    onTap: () {
                      if (Get.isRegistered<AddMomentsController>()) {
                        Get.delete<AddMomentsController>();

                        final addMomentController =
                            Get.put(AddMomentsController());
                        addMomentController.addId = [];
                        addMomentController.momentEdit = false;
                        SingleTone.instance.momentId = null;

                        addMomentController.update();
                        Get.to(AddMomentsScreen());
                      } else {
                        final addMomentController =
                            Get.put(AddMomentsController());
                        addMomentController.addId = [];
                        addMomentController.momentEdit = false;
                        SingleTone.instance.momentId = null;

                        addMomentController.update();
                        Get.to(AddMomentsScreen());
                      }
                    },
                    child: Container(
                      height: 50,
                      width: 150,
                      decoration: BoxDecoration(
                          color: controller.displayColor,
                          borderRadius: BorderRadius.circular(30)),
                      child: Center(
                        child: Text(
                          Strings.createNew,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  )
          ],
        ),
      ),
    );
  }
}
