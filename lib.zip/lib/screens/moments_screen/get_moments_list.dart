import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/add_moment_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/moments_screen/edit_moments_screen.dart';
import 'package:werfieapp/utils/colors.dart';

import '../../network/controller/get_moment_list_controller.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import 'add_moments_screen.dart';

class MomentListScreen extends StatefulWidget {
  @override
  State<MomentListScreen> createState() => _MomentListScreenState();
}

class _MomentListScreenState extends State<MomentListScreen> {
  // MomentsListController getListMomentController = Get.put((MomentsListController()));

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    //

    if (kIsWeb) {
      if (Get.isRegistered<MomentsListController>()) {
        Get.delete<MomentsListController>();
        final momentListController = Get.put(MomentsListController());
        SingleTone.instance.momentId = null;
        // momentListController.update();
      } else {
        final momentListController = Get.put(MomentsListController());
        SingleTone.instance.momentId = null;
        // momentListController.update();
      }
      if (Get.isRegistered<AddMomentsController>()) {
        Get.delete<AddMomentsController>();
      }
    } else {
      Get.put(MomentsListController());
    }

    // if (Get.isRegistered<MomentsListController>()) {
    //   Get.find<MomentsListController>().getMomentsList(isFromRoute: true);
    // } else {
    //   // Get.put(MomentsListController());
    //   // Get.put(AddMomentsController());
    // }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MomentsListController>(builder: (controller) {
      return Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(100.0),
            child: Container(
              height: 100,
              // color: Colors.amberAccent,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Row(
                  children: [
                    kIsWeb
                        ? GestureDetector(
                            onTap: () async {
                              // print("idhr  aya moment");

                              Navigator.pop(context);
                              //   print("moment back called");
                              //   Get.back();
                              //   onHomeChange = true;
                              //   onBookMarksChange = false;
                              //   onTrendsChange = false;
                              //   onBrowsChange = false;
                              //   onMoreChange = false;
                              //   onNotificationChange = false;
                              //   onListChange = false;
                              //   onSettingChange = false;
                              //   onProfileChange = false;
                              //   onChatsChange = false;
                              //
                              // await controller.arrowBackFunction();
                            },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            ),
                          )
                        : GestureDetector(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            ),
                          ),
                    SizedBox(
                      width: 20,
                    ),
                    Text(
                      Strings.moments,
                      // style: TextStyle(
                      //     fontSize: 20,
                      //     fontWeight: FontWeight.w700,
                      //     color: Colors.black
                      //
                      // ),
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          body:
              controller.getMomentListLoading == true ||
                      controller.deleteLoading == true
                  ? Center(
                      child: CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    ))
                  : controller.momentsDataList.length > 0
                      ? SingleChildScrollView(
                          child: Column(
                              children: List.generate(
                                  controller.momentsDataList.length, (index) {
                            return kIsWeb
                                ? InkWell(
                                    onTap: () {



                                      // print(
                                      //     'index of moment Id:${controller.momentsDataList[index].id}');
                                      // SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                      // print(
                                      //     'Singletone momentId:${SingleTone.instance.momentId}');
                                      //
                                      // if (Get.isRegistered<AddMomentsController>()) {
                                      //   Get.find<AddMomentsController>()
                                      //       .momentsDetailsApi(
                                      //       pageNo: 1,
                                      //       momentId: controller
                                      //           .momentsDataList[index].id
                                      //   );
                                      //   Get.find<AddMomentsController>().momentEdit=true;
                                      //   Get.find<AddMomentsController>().update();
                                      // }

                                      SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                      Get.toNamed(FluroRouters.mainScreen +
                                          "/moment/" + SingleTone.instance.momentId.toString());
                                      if (Get.isRegistered<AddMomentsController>()) {
                                        Get.find<AddMomentsController>().momentsDetailsApi(
                                            pageNo: 1,
                                            momentId: controller.momentsDataList[index].id
                                        );
                                        Get.find<AddMomentsController>().momentEdit=true;
                                         Get.find<AddMomentsController>().update();
                                      }
                                      else{
                                        // print("print moment");
                                        SingleTone.instance.momentId=controller.momentsDataList[index].id;
                                        // print('Singletone momentId:${SingleTone.instance.momentId}');
                                        final addMomentController=Get.put(AddMomentsController());
                                        addMomentController.momentsDetailsApi(pageNo: 1,
                                            momentId: controller.momentsDataList[index].id
                                        );


                                        // print("  controller.momentsData.coverImage ${ addMomentController.momentsListDetailsPosts.length}");
                                        addMomentController.momentEdit=true;
                                         addMomentController.update();
                                      }



                                      //
                                      // controller.update();
                                    },
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding:
                                                const EdgeInsets.only(left: 15),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                    width: 100,
                                                    child: Text(
                                                      controller.momentsDataList[index].title == null
                                                          ? 'title not show'
                                                          : controller.momentsDataList[index].title,

                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                      // style: Get.textTheme.headline3.copyWith(
                                                      //     color: Colors.black,
                                                      //     fontWeight: FontWeight.bold
                                                      // ),
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline5
                                                          .copyWith(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize:
                                                            kIsWeb ? 20 : 18,
                                                      ),
                                                    )),
                                                SizedBox(
                                                    width: 150,
                                                    child: Text(
                                                      controller.momentsDataList[index].privacyType == null
                                                          ? 'no Privacy'
                                                          : controller.momentsDataList[index].privacyType,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline2
                                                          .copyWith(
                                                        color:
                                                            Color(0xFFf61880),
                                                        fontSize:
                                                            kIsWeb ? 16 : 14,
                                                        height: 1.5,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ))
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                right: 15),
                                            child: Column(
                                              children: [
                                                Container(
                                                  height: 50,
                                                  width: 50,
                                                  decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: Colors.grey,
                                                        width: 1),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                  ),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            15),
                                                    child: Image(
                                                      image: AssetImage(
                                                          'assets/images/Blank.png'),
                                                      color: MyColors.yellow,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(
                                                  height: 10,
                                                ),
                                                Row(
                                                  children: [
                                                    GestureDetector(
                                                      onTap: () {
                                                        // print('index of moment Id:${controller.momentsDataList[index].id}');
                                                        // SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                                        // print('Singletone momentId:${SingleTone.instance.momentId}');
                                                        // if (Get.isRegistered<AddMomentsController>()) {
                                                        //   Get.find<AddMomentsController>().momentsDetailsApi(pageNo: 1,
                                                        //           momentId: controller.momentsDataList[index].id);
                                                        //   Get.find<AddMomentsController>().momentEdit = true;
                                                        //   Get.find<AddMomentsController>().update();
                                                        // } else {SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                                        //   print('Singletone momentId:${SingleTone.instance.momentId}');
                                                        //   final addMomentController = Get.put(AddMomentsController());
                                                        //   addMomentController.momentsDetailsApi(pageNo: 1,
                                                        //       momentId: controller.momentsDataList[index].id);
                                                        //   addMomentController.momentEdit = true;
                                                        //   addMomentController.update();
                                                        // }
                                                        //
                                                        // controller.newsFeedController.drawerLeftMoment = true;
                                                        // controller.newsFeedController.isSearch = false;
                                                        // controller.newsFeedController.isFilter = false;
                                                        // controller.newsFeedController.isFilterScreen = false;
                                                        // controller.newsFeedController.isTrendsScreen = false;
                                                        // controller.newsFeedController.isNewsFeedScreen = false;
                                                        // controller.newsFeedController.addMomentsScreen = true;
                                                        // controller.newsFeedController.getListMomentScreen = false;
                                                        // controller.newsFeedController.showMomentsScreen = false;
                                                        // controller.newsFeedController.editMomentScreen = true;
                                                        // controller.newsFeedController.isWhoToFollowScreen = false;
                                                        // controller.newsFeedController.isNotificationScreen = false;
                                                        // controller.newsFeedController.isChatScreen = false;
                                                        // controller.newsFeedController.isSavedPostScreen = false;
                                                        // controller.newsFeedController.isPostDetails = false;
                                                        // controller.newsFeedController.isProfileScreen = false;
                                                        // controller.newsFeedController.isFollwerScreen = false;
                                                        // controller.newsFeedController.isSettingsScreen = false;
                                                        // controller.newsFeedController.searchText.text = '';
                                                        // controller.newsFeedController.isListScreen = false;
                                                        // controller.newsFeedController.isListDetailScreen = false;
                                                        // controller.newsFeedController.update();
                                                        // controller.update();
                                                        // print(
                                                        //     'index of moment Id:${controller.momentsDataList[index].id}');
                                                        SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                                        // print('Singletone momentId:${SingleTone.instance.momentId}');

                                                        // if (Get.isRegistered<AddMomentsController>()) {
                                                        //   Get.find<AddMomentsController>().momentsDetailsApi(
                                                        //       pageNo: 1,
                                                        //       momentId: controller.momentsDataList[index].id
                                                        //   );
                                                        //   Get.find<AddMomentsController>().momentEdit=true;
                                                        //    Get.find<AddMomentsController>().update();
                                                        // }
                                                        // else{
                                                        //   print("print moment");
                                                        //   SingleTone.instance.momentId=controller.momentsDataList[index].id;
                                                        //   print('Singletone momentId:${SingleTone.instance.momentId}');
                                                        //   final addMomentController=Get.put(AddMomentsController());
                                                        //   addMomentController.momentsDetailsApi(pageNo: 1,
                                                        //       momentId: controller.momentsDataList[index].id
                                                        //   );
                                                        //
                                                        //
                                                        //   print("  controller.momentsData.coverImage ${ addMomentController.momentsListDetailsPosts.length}");
                                                        //   addMomentController.momentEdit=true;
                                                        //    addMomentController.update();
                                                        // }

                                                        Get.toNamed(FluroRouters.mainScreen +
                                                            "/moment/" + SingleTone.instance.momentId.toString());
                                                      },
                                                      child: Icon(
                                                        Icons.edit,
                                                        size: 20,
                                                        color: controller
                                                            .newsFeedController
                                                            .displayColor,
                                                      ),
                                                    ),
                                                    InkWell(
                                                      onTap: () {
                                                        showDialog(
                                                            useSafeArea: false,
                                                            context: context,
                                                            builder: (context) {
                                                              return AlertDialog(
                                                                insetPadding:
                                                                    EdgeInsets
                                                                        .zero,
                                                                contentPadding:
                                                                    EdgeInsets
                                                                        .zero,
                                                                shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                        BorderRadius.all(
                                                                            Radius.circular(32.0))),
                                                                content:
                                                                    Container(
                                                                  height: kIsWeb
                                                                      ? 350
                                                                      : 300,
                                                                  width: kIsWeb
                                                                      ? 400
                                                                      : 300,
                                                                  child: Column(
                                                                    children: [
                                                                      SizedBox(
                                                                        height:
                                                                            50,
                                                                      ),
                                                                      Text(
                                                                        Strings.momentsDelete,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        height:
                                                                            20,
                                                                      ),
                                                                      Text(
                                                                        Strings.removeMomentAlertMsg,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme.of(context).brightness == Brightness.dark
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                          fontSize: kIsWeb
                                                                              ? 14
                                                                              : 12,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                          height:
                                                                              30),
                                                                      InkWell(
                                                                        onTap:
                                                                            () async {
                                                                          await controller
                                                                              .deleteMomentApi(momentId: controller.momentsDataList[index].id)
                                                                              .then((value) => Navigator.pop(context));
                                                                        },
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              50,
                                                                          width:
                                                                              150,
                                                                          decoration: BoxDecoration(
                                                                              color: Colors.red,
                                                                              borderRadius: BorderRadius.circular(30)),
                                                                          child:
                                                                              Center(
                                                                            child: Text(Strings.delete,
                                                                                style: TextStyle(
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.bold,
                                                                                  color: Colors.black,
                                                                                )),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                          height:
                                                                              30),
                                                                      InkWell(
                                                                        onTap:
                                                                            () {
                                                                          Navigator.pop(
                                                                              context);
                                                                        },
                                                                        child:
                                                                            Container(
                                                                          height:
                                                                              50,
                                                                          width:
                                                                              150,
                                                                          decoration: BoxDecoration(
                                                                              border: Border.all(
                                                                                color: Colors.grey,
                                                                                width: 1,
                                                                              ),
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                                                                              borderRadius: BorderRadius.circular(30)),
                                                                          child:
                                                                              Center(
                                                                            child: Text(Strings.cancel,
                                                                                style: TextStyle(
                                                                                  fontWeight: FontWeight.bold,
                                                                                  fontSize: 14,
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                )),
                                                                          ),
                                                                        ),
                                                                      )
                                                                    ],
                                                                  ),
                                                                ),
                                                              );
                                                            });
                                                      },
                                                      child: Icon(
                                                        Icons.delete,
                                                        size: 20,
                                                        color: Colors.red,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  )
                                : InkWell(
                                    onTap: () {
                                      // print('index of moment Id:${controller.momentsDataList[index].id}');
                                      SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                      // print('Singletone momentId:${SingleTone.instance.momentId}');
                                      if (Get.isRegistered<AddMomentsController>()) {
                                        Get.find<AddMomentsController>().addId = [];
                                        Get.find<AddMomentsController>().momentsDetailsApi(pageNo: 1,
                                                momentId: controller.momentsDataList[index].id);
                                        Get.find<AddMomentsController>().momentEdit = true;
                                        Get.find<AddMomentsController>().update();
                                        Get.to(() => EditMomentsScreen());
                                      } else {
                                        SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                        // print('Singletone momentId:${SingleTone.instance.momentId}');
                                        final addMomentController = Get.put(AddMomentsController());
                                        addMomentController.addId = [];
                                        addMomentController.momentsDetailsApi(pageNo: 1, momentId: controller
                                                .momentsDataList[index].id);
                                        addMomentController.momentEdit = true;
                                        addMomentController.update();
                                        Get.to(() => EditMomentsScreen());
                                      }
                                    },
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 15),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    SizedBox(
                                                        width: 150,
                                                        child: Text(
                                                          controller.momentsDataList[index]
                                                                      .title == null
                                                              ? 'tittle not show'
                                                              : controller.momentsDataList[index].title,

                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 1,
                                                          // style: Get.textTheme.headline3.copyWith(
                                                          //     color: Colors.black,
                                                          //     fontWeight: FontWeight.bold
                                                          // ),
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline5
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: kIsWeb
                                                                ? 20
                                                                : 18,
                                                          ),
                                                        )),
                                                    SizedBox(
                                                        width: 150,
                                                        child: Text(
                                                          controller.momentsDataList[index].privacyType == null
                                                              ? 'no Privacy'
                                                              : controller.momentsDataList[index].privacyType,
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 1,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Color(
                                                                0xFFf61880),
                                                            fontSize: kIsWeb
                                                                ? 16
                                                                : 14,
                                                            height: 1.5,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ))
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    right: 15),
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      height: 70,
                                                      width: 70,
                                                      decoration: BoxDecoration(
                                                        border: Border.all(
                                                            color: Colors.grey,
                                                            width: 1),
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),

                                                        // image: DecorationImage(
                                                        //     image: AssetImage('assets/images/Blank.png')
                                                        // )
                                                      ),
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(15),
                                                        child: Image(
                                                          image: AssetImage(
                                                            'assets/images/Blank.png',
                                                          ),
                                                          color:
                                                              MyColors.yellow,
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 10,
                                                    ),
                                                    Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: [
                                                        InkWell(
                                                          onTap: () {
                                                            // print('index of moment Id:${controller.momentsDataList[index].id}');
                                                            SingleTone.instance.momentId = controller.momentsDataList[index].id;
                                                            // print('Singletone momentId:${SingleTone.instance.momentId}');
                                                            if (Get.isRegistered<AddMomentsController>()) {
                                                              Get.find<AddMomentsController>().addId = [];
                                                              Get.find<AddMomentsController>()
                                                                  .momentsDetailsApi(pageNo: 1,
                                                                  momentId: controller.momentsDataList[index].id);
                                                              Get.find<AddMomentsController>().momentEdit = true;
                                                              Get.find<AddMomentsController>().update();
                                                              Get.to(() => AddMomentsScreen());
                                                            } else {
                                                              SingleTone.instance.momentId =
                                                                  controller.momentsDataList[index].id;
                                                              // print('Singletone momentId:${SingleTone.instance.momentId}');

                                                              final addMomentController = Get.put(AddMomentsController());
                                                              addMomentController.addId = [];
                                                              addMomentController.momentsDetailsApi(pageNo: 1,
                                                                      momentId: controller.momentsDataList[index].id);
                                                              addMomentController.momentEdit = true;
                                                              addMomentController.update();
                                                              Get.to(() => AddMomentsScreen());
                                                            }
                                                          },
                                                          child: Icon(
                                                            Icons.edit,
                                                            size: 30,
                                                            color: controller.newsFeedController.displayColor,
                                                          ),
                                                        ),
                                                        InkWell(
                                                          onTap: () {
                                                            showDialog(
                                                                useSafeArea:
                                                                    false,
                                                                context:
                                                                    context,
                                                                builder:
                                                                    (context) {
                                                                  return AlertDialog(
                                                                    insetPadding:
                                                                        EdgeInsets
                                                                            .zero,
                                                                    contentPadding:
                                                                        EdgeInsets
                                                                            .zero,
                                                                    shape: RoundedRectangleBorder(
                                                                        borderRadius:
                                                                            BorderRadius.all(Radius.circular(32.0))),
                                                                    content:
                                                                        Container(
                                                                      height: kIsWeb
                                                                          ? Get.height *
                                                                              0.5
                                                                          : Get.height *
                                                                              0.4,
                                                                      width: kIsWeb
                                                                          ? Get.width *
                                                                              0.4
                                                                          : Get.width *
                                                                              0.8,
                                                                      child:
                                                                          Column(
                                                                        children: [
                                                                          SizedBox(
                                                                            height: kIsWeb
                                                                                ? 50
                                                                                : 40,
                                                                          ),
                                                                          Text(
                                                                            Strings.momentsDelete,
                                                                            style:
                                                                                Styles.baseTextTheme.headline2.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontWeight: FontWeight.bold,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            height:
                                                                                20,
                                                                          ),
                                                                          Text(
                                                                            Strings.removeMomentAlertMsg,
                                                                            style:
                                                                                Styles.baseTextTheme.headline4.copyWith(
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontSize: kIsWeb ? 14 : 12,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: 30),
                                                                          InkWell(
                                                                            onTap:
                                                                                () async {
                                                                              Navigator.pop(context);
                                                                              await controller.deleteMomentApi(momentId: controller.momentsDataList[index].id);
                                                                            },
                                                                            child:
                                                                                Container(
                                                                              height: 50,
                                                                              width: 150,
                                                                              decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(30)),
                                                                              child: Center(
                                                                                child: Text(Strings.delete,
                                                                                    style: TextStyle(
                                                                                      fontSize: 14,
                                                                                      fontWeight: FontWeight.bold,
                                                                                      color: Colors.black,
                                                                                    )),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                              height: 30),
                                                                          InkWell(
                                                                            onTap:
                                                                                () {
                                                                              Navigator.pop(context);
                                                                            },
                                                                            child:
                                                                                Container(
                                                                              height: 50,
                                                                              width: 150,
                                                                              decoration: BoxDecoration(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                                                                                borderRadius: BorderRadius.circular(30),
                                                                                border: Border.all(color: Colors.grey, width: 1),
                                                                              ),
                                                                              child: Center(
                                                                                child: Text(Strings.cancel,
                                                                                    style: TextStyle(
                                                                                      fontSize: 14,
                                                                                      fontWeight: FontWeight.bold,
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                    )),
                                                                              ),
                                                                            ),
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  );
                                                                });
                                                          },
                                                          child: Icon(
                                                            Icons.delete,
                                                            size: 20,
                                                            color: Colors.red,
                                                          ),
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                        Divider()
                                      ],
                                    ),
                                  );
                          })),
                        )
                      : Center(
                          child: Text(
                            Strings.noMomentsList,
                            style: Styles.baseTextTheme.headline4.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 14 : 12,
                            ),
                          ),
                        ));
    });
  }
}
