import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/moments_screen/edit_moments_screen.dart';
import 'package:werfieapp/screens/moments_screen/show_moments_screen.dart';

import '../../models/post.dart';
import '../../network/controller/add_moment_controller.dart';
import '../../utils/colors.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../widgets/blue_tick.dart';
import '../../widgets/pagged_list_view.dart';
import '../../widgets/post_card.dart';
import '../filter_screen.dart';

class AddMomentsScreen extends StatelessWidget {
  final String momentid;
  var addMomentController;

  AddMomentsScreen({this.momentid, this.addMomentController}) {
    addMomentController =
        Get.put(AddMomentsController(momentid: this.momentid));
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddMomentsController>(builder: (controller) {
      return Scaffold(
        body: NestedScrollView(
          // controller: controller.scrollController,
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              SliverAppBar(
                elevation: 0,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                automaticallyImplyLeading: false,
                pinned: true,
                expandedHeight: 260,
                flexibleSpace: FlexibleSpaceBar(
                  collapseMode: CollapseMode.parallax,
                  title: controller.isShrink ? SizedBox() : null,
                  background: SafeArea(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 15,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15),
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: kIsWeb
                                    ? () {
                                        Navigator.pop(context);

                                        // controller.arrowBackFunction();
                                      }
                                    : () {
                                        // print("back giya hai");
                                        Navigator.pop(context);
                                      },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 25,
                                ),
                              ),
                              SizedBox(
                                width: 50,
                              ),
                              Text(
                                Strings.addWerfs,
                                // style: TextStyle(
                                //     fontSize: 20,
                                //     fontWeight: FontWeight.w700,
                                //     color: Colors.black
                                //
                                // ),
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          height: 40,
                          // color: Colors.amber,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              TabButton(
                                title: Strings.werfsILiked,
                                onTap: () {
                                  controller.LikedWerfs();
                                  controller.update();
                                },
                                isSelected: controller.isLikedWerfs,
                              ),
                              TabButton(
                                title: Strings.werfsByAccount,
                                onTap: () {
                                  controller.WerfsByAccount();

                                  controller.update();
                                },
                                isSelected: controller.isWerfsByAccount,
                              ),
                              TabButton(
                                title: Strings.werfSearch,
                                onTap: () {
                                  controller.SerachWerfs();
                                  controller.update();
                                },
                                isSelected: controller.isWerfSearch,
                              ),
                            ],
                          ),
                        ),
                        Divider(),
                        Container(
                          height: 70,
                          //  color: Colors.amber,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 15),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                // Container(
                                //   height: 50,
                                //   width: kIsWeb ? Get.width * 0.18 : Get
                                //       .width * 0.6,
                                //   decoration: BoxDecoration(
                                //     //      color: Colors.red,
                                //       borderRadius: BorderRadius.circular(
                                //           15),
                                //       border: Border.all(width: 2,
                                //           color: Colors.grey
                                //       )
                                //   ),
                                //   child: Padding(
                                //     padding: const EdgeInsets.symmetric(
                                //         horizontal: 15),
                                //     child: Row(
                                //       mainAxisAlignment: MainAxisAlignment
                                //           .spaceBetween,
                                //       children: [
                                //         Text('position',
                                //           style: Theme.of(context).brightness == Brightness.dark ?
                                //           TextStyle(color: Colors.white,
                                //             fontWeight: FontWeight.w700,
                                //
                                //           )
                                //               : TextStyle(color: Colors.black,
                                //             fontWeight: FontWeight.w700,
                                //
                                //           ),),
                                //         DropdownButton<String>(
                                //           value: controller.dropdownValue,
                                //           icon: const Icon(
                                //               Icons.keyboard_arrow_down),
                                //           dropdownColor: Colors.grey,
                                //           elevation: 16,
                                //           underline: SizedBox(),
                                //           onChanged: (String value) {
                                //             // This is called when the user selects an item.
                                //             {
                                //               controller.dropdownValue =
                                //                   value;
                                //               controller.update();
                                //             }
                                //           },
                                //           items: controller.list.map<
                                //               DropdownMenuItem<String>>((
                                //               String value) {
                                //             return DropdownMenuItem<
                                //                 String>(
                                //               value: value,
                                //               child: Text(value,
                                //                 style: Theme.of(context).brightness == Brightness.dark ?
                                //                 TextStyle(color: Colors.white,
                                //                   fontWeight: FontWeight.w700,
                                //
                                //                 )
                                //                     : TextStyle(color: Colors.black,
                                //                   fontWeight: FontWeight.w700,
                                //
                                //                 ),),
                                //             );
                                //           }).toList(),
                                //         ),
                                //
                                //
                                //       ],
                                //     ),
                                //   ),
                                //
                                // ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Column(
                                    children: [
                                      !kIsWeb && controller.momentEdit == true
                                          ? GestureDetector(
                                              onTap: () async {
                                                if (SingleTone.instance
                                                            .momentId !=
                                                        null &&
                                                    controller.addId.length !=
                                                        0) {
                                                  await controller.addPostApi(
                                                      momentId: SingleTone
                                                          .instance.momentId,
                                                      postIds:
                                                          controller.addId);
                                                } else {
                                                  Get.to(EditMomentsScreen());
                                                }
                                              },
                                              child: Container(
                                                height: 30,
                                                width: 80,
                                                decoration: BoxDecoration(
                                                    // color: Colors.grey,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                    border: Border.all(
                                                      width: 2,
                                                      color: Colors.blue,
                                                    )),
                                                child: Center(
                                                  child: Text(
                                                    Strings.add,
                                                    // style: Get.textTheme
                                                    //     .headline3.copyWith(
                                                    //     color: Colors.blue
                                                    // ),
                                                    textAlign: TextAlign.center,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize:
                                                          kIsWeb ? 12 : 12,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )
                                          : !kIsWeb &&
                                                  controller.momentEdit == false
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    Get.to(ShowMomentsScreen());
                                                  },
                                                  child: Container(
                                                    height: 30,
                                                    width: 80,
                                                    decoration: BoxDecoration(
                                                        // color: Colors.grey,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                        border: Border.all(
                                                          width: 2,
                                                          color: Colors.blue,
                                                        )),
                                                    child: Center(
                                                      child: Text(
                                                        Strings.add,
                                                        // style: Get.textTheme
                                                        //     .headline3.copyWith(
                                                        //     color: Colors.blue
                                                        // ),
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize:
                                                              kIsWeb ? 12 : 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                )
                                              : kIsWeb &&
                                                      controller.momentEdit ==
                                                          true
                                                  ? GestureDetector(
                                                      onTap: () async {
                                                        if (SingleTone.instance
                                                                    .momentId !=
                                                                null &&
                                                            controller.addId
                                                                    .length !=
                                                                0) {
                                                          await controller.addPostApi(
                                                              momentId:
                                                                  SingleTone
                                                                      .instance
                                                                      .momentId,
                                                              postIds:
                                                                  controller
                                                                      .addId);
                                                          controller
                                                              .newsfeedController
                                                              .momentCreateScreen = true;
                                                          // controller.newsfeedController.editMomentScreen = true;
                                                          controller
                                                              .newsfeedController
                                                              .update();
                                                        } else {
                                                          UtilsMethods
                                                              .toastMessageShow(
                                                            controller
                                                                .newsfeedController
                                                                .displayColor,
                                                            controller
                                                                .newsfeedController
                                                                .displayColor,
                                                            controller
                                                                .newsfeedController
                                                                .displayColor,
                                                            message:
                                                                'Please Add Post',
                                                          );
                                                        }
                                                      },
                                                      child: Container(
                                                        height: 30,
                                                        width: 80,
                                                        decoration:
                                                            BoxDecoration(
                                                                // color: Colors.grey,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            20),
                                                                border:
                                                                    Border.all(
                                                                  width: 2,
                                                                  color: Colors
                                                                      .blue,
                                                                )),
                                                        child: Center(
                                                          child: Text(
                                                            Strings.add,
                                                            // style: Get.textTheme
                                                            //     .headline3.copyWith(
                                                            //     color: Colors.blue
                                                            // ),
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                  : kIsWeb &&
                                                          controller
                                                                  .momentEdit ==
                                                              false
                                                      ? MediaQuery.of(context)
                                                                  .size
                                                                  .width >=
                                                              1000
                                                          ? SizedBox()
                                                          : GestureDetector(
                                                              onTap: () async {
                                                                // print(
                                                                //     "Hassan Raze ");
                                                                controller
                                                                    .newsfeedController
                                                                    .momentCreateScreen = true;
                                                                controller
                                                                    .newsfeedController
                                                                    .showMomentsScreen = true;
                                                                controller
                                                                    .newsfeedController
                                                                    .editMomentScreen = false;
                                                                controller
                                                                    .newsfeedController
                                                                    .update();
                                                              },
                                                              child: Container(
                                                                height: 30,
                                                                width: 80,
                                                                decoration:
                                                                    BoxDecoration(
                                                                        // color: Colors.grey,
                                                                        borderRadius:
                                                                            BorderRadius.circular(
                                                                                20),
                                                                        border:
                                                                            Border.all(
                                                                          width:
                                                                              2,
                                                                          color:
                                                                              Colors.blue,
                                                                        )),
                                                                child: Center(
                                                                  child: Text(
                                                                    Strings.add,
                                                                    // style: Get.textTheme
                                                                    //     .headline3.copyWith(
                                                                    //     color: Colors.blue
                                                                    // ),
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      color: Theme.of(context).brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                          ? Colors
                                                                              .white
                                                                          : Colors
                                                                              .black,
                                                                      fontSize:
                                                                          kIsWeb
                                                                              ? 14
                                                                              : 14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .bold,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            )
                                                      : SizedBox(),
                                      Text(
                                        '${controller.addId.length} ${Strings.werfs}',
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: kIsWeb ? 16 : 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Divider(),

                        /// liked by
                        controller.isLikedWerfs == true
                            ? Container(
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            Strings.likedBy,
                                            style: Styles
                                                .baseTextTheme.headline5
                                                .copyWith(
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                          controller.userProfile == null
                                              ? Container(
                                                  height: 40,
                                                  width: 40,
                                                  child:
                                                      CircularProgressIndicator(
                                                    color: MyColors.BlueColor,
                                                  ))
                                              : Container(
                                                  height: 40,
                                                  width: 40,
                                                  decoration: BoxDecoration(
                                                    color: Colors.grey,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ),
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                    child: FadeInImage(
                                                      placeholderErrorBuilder:
                                                          (context, _, __) {
                                                        return Image.asset(
                                                            'assets/images/person_placeholder.png');
                                                      },
                                                      imageErrorBuilder:
                                                          (context, _, __) {
                                                        return Image.asset(
                                                            'assets/images/person_placeholder.png');
                                                      },
                                                      fit: BoxFit.fill,
                                                      height: 40,
                                                      width: 40,
                                                      placeholder: AssetImage(
                                                          'assets/images/person_placeholder.png'),
                                                      image: NetworkImage(
                                                        controller.userProfile
                                                                    .profileImage ==
                                                                null
                                                            ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                            : controller
                                                                .userProfile
                                                                .profileImage,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          SizedBox(
                                            width: 70,
                                            child: Text(
                                              controller.userName != null
                                                  ? controller.userName
                                                  : '',
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              // style: Get.textTheme.bodyText2
                                              //     .copyWith(
                                              //     fontWeight: FontWeight.bold,
                                              //     color: Colors.black
                                              // ),
                                              style: Styles
                                                  .baseTextTheme.headline5
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 60,
                                            child: Text(
                                              controller.userName != null
                                                  ? "@${controller.userName}"
                                                  : '',
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: Styles
                                                  .baseTextTheme.headline5
                                                  .copyWith(
                                                fontWeight: FontWeight.w400,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      //   myPopMenu()
                                    ],
                                  ),
                                ),
                              )
                            : controller.isWerfsByAccount == true
                                ? Container(
                                    child: TextFieldWidget(
                                      textController:
                                          controller.searchByAccount,
                                      hintTextField: 'Search by account',
                                      onChanged: (value) async {
                                        value = controller.searchByAccount.text;

                                        controller.isSearch = true;
                                        if (value.isEmpty || value.length < 1) {
                                          controller.searchResult.clear();
                                          controller.update();
                                        }
                                        if (value.isNotEmpty &&
                                            value.split(" ").join("") != "" &&
                                            value.split(" ").join("").length >
                                                0) {
                                          controller.searchResult =
                                              await controller
                                                  .onSearchTextChanged(
                                                      controller.searchByAccount
                                                          .text);
                                          controller.update();
                                        } else if (value.isEmpty &&
                                            value.split(" ").join("") == "") {
                                          controller.searchResult.clear();
                                          // controller.searchResult.
                                          controller.update();
                                        }
                                      },
                                      context: context,
                                    ),
                                  )
                                : controller.isWerfSearch == true
                                    ? Container(
                                        child: TextFieldWidget(
                                            textController:
                                                controller.searchByWerfs,
                                            hintTextField: 'Search by werfs',
                                            context: context),
                                      )
                                    : SizedBox(),
                        Divider()
                      ],
                    ),
                  ),
                ),
                actions: controller.isShrink
                    ? [
                        Row(
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  height: 50,
                                  //  color: Colors.amber,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        GestureDetector(
                                          onTap: kIsWeb
                                              ? () {
                                                  controller
                                                      .arrowBackFunction();
                                                }
                                              : () {
                                                  Navigator.pop(context);
                                                },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            size: 25,
                                          ),
                                        ),
                                        Column(
                                          children: [
                                            !kIsWeb &&
                                                    controller.momentEdit ==
                                                        true
                                                ? GestureDetector(
                                                    onTap: () async {
                                                      if (SingleTone.instance
                                                                  .momentId !=
                                                              null &&
                                                          controller.addId
                                                                  .length !=
                                                              0) {
                                                        await controller
                                                            .addPostApi(
                                                                momentId:
                                                                    SingleTone
                                                                        .instance
                                                                        .momentId,
                                                                postIds:
                                                                    controller
                                                                        .addId);
                                                      } else {
                                                        UtilsMethods
                                                            .toastMessageShow(
                                                          controller
                                                              .newsfeedController
                                                              .displayColor,
                                                          controller
                                                              .newsfeedController
                                                              .displayColor,
                                                          controller
                                                              .newsfeedController
                                                              .displayColor,
                                                          message:
                                                              'Please Add Post',
                                                        );
                                                        Get.to(
                                                            EditMomentsScreen());
                                                      }
                                                    },
                                                    child: Container(
                                                      height: 25,
                                                      width: 80,
                                                      decoration: BoxDecoration(
                                                          // color: Colors.grey,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(20),
                                                          border: Border.all(
                                                            width: 2,
                                                            color: Colors.blue,
                                                          )),
                                                      child: Center(
                                                        child: Text(
                                                          Strings.add,
                                                          // style: Get.textTheme
                                                          //     .headline3.copyWith(
                                                          //     color: Colors.blue
                                                          // ),
                                                          style: TextStyle(
                                                            fontSize: kIsWeb
                                                                ? 14
                                                                : 14,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                : !kIsWeb &&
                                                        controller.momentEdit ==
                                                            false
                                                    ? GestureDetector(
                                                        onTap: () async {
                                                          Get.to(
                                                              ShowMomentsScreen());
                                                        },
                                                        child: Container(
                                                          height: 25,
                                                          width: 80,
                                                          decoration:
                                                              BoxDecoration(
                                                                  // color: Colors.grey,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              20),
                                                                  border: Border
                                                                      .all(
                                                                    width: 2,
                                                                    color: Colors
                                                                        .blue,
                                                                  )),
                                                          child: Center(
                                                            child: Text(
                                                              Strings.add,
                                                              // style: Get.textTheme
                                                              //     .headline3.copyWith(
                                                              //     color: Colors.blue
                                                              // ),
                                                              style: TextStyle(
                                                                fontSize: kIsWeb
                                                                    ? 14
                                                                    : 14,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .bold,
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      )
                                                    : kIsWeb &&
                                                            controller
                                                                    .momentEdit ==
                                                                true
                                                        ? GestureDetector(
                                                            onTap: () async {
                                                              if (SingleTone
                                                                          .instance
                                                                          .momentId !=
                                                                      null &&
                                                                  controller
                                                                          .addId
                                                                          .length !=
                                                                      0) {
                                                                await controller.addPostApi(
                                                                    momentId: SingleTone
                                                                        .instance
                                                                        .momentId,
                                                                    postIds:
                                                                        controller
                                                                            .addId);
                                                              } else {
                                                                Fluttertoast.showToast(
                                                                    msg:
                                                                        'Please Add Post',
                                                                    toastLength:
                                                                        Toast
                                                                            .LENGTH_SHORT,
                                                                    gravity: ToastGravity
                                                                        .CENTER,
                                                                    timeInSecForIosWeb:
                                                                        1,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .red,
                                                                    textColor:
                                                                        Colors
                                                                            .white,
                                                                    fontSize:
                                                                        16.0);
                                                              }
                                                            },
                                                            child: Container(
                                                              height: 25,
                                                              width: 80,
                                                              decoration:
                                                                  BoxDecoration(
                                                                      // color: Colors.grey,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              20),
                                                                      border:
                                                                          Border
                                                                              .all(
                                                                        width:
                                                                            2,
                                                                        color: Colors
                                                                            .blue,
                                                                      )),
                                                              child: Center(
                                                                child: Text(
                                                                  Strings.add,
                                                                  // style: Get.textTheme
                                                                  //     .headline3.copyWith(
                                                                  //     color: Colors.blue
                                                                  // ),
                                                                  style:
                                                                      TextStyle(
                                                                    fontSize:
                                                                        kIsWeb
                                                                            ? 14
                                                                            : 14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          )
                                                        : SizedBox(),
                                            Text(
                                              '${controller.addId.length} Werfs',
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                fontSize: kIsWeb ? 16 : 14,
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ]
                    : null,
              ),
            ];
          },
          body: controller.isLoading == true
              ? Center(
                  child: CircularProgressIndicator(color: MyColors.BlueColor))
              :

              /*  CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child:*/
              controller.isSearch == true
                  ? Stack(
                      children: [
                        controller.searchResult == null
                            ? SizedBox()
                            : Container(
                                width: Get.width * 0.5,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: List.generate(
                                      controller.searchResult.length, (index) {
                                    if (controller
                                            .searchResult[index].username !=
                                        null)
                                      return InkWell(
                                        splashColor: Colors.grey,
                                        onTap: () async {
                                          // print("first print ");
                                          // print("user id" +
                                          //     controller.searchResult[index].id
                                          //         .toString());
                                          controller.userId =
                                              controller.searchResult[index].id;
                                          // print(
                                          //     'save UserId:${controller.userId}');
                                          await controller.momentSearchPost(
                                              tab: 'by_account',
                                              pageNo: 1,
                                              user_id: controller
                                                  .searchResult[index].id);
                                          controller.searchResult = [];
                                          controller.isSearch = false;
                                          controller.searchByAccount.clear();
                                          controller.update();
                                        },
                                        child: Container(
                                          width: Get.width,
                                          margin: EdgeInsets.only(bottom: 5),
                                          padding: EdgeInsets.all(8.0),
                                          color: Colors.grey.withOpacity(0.05),
                                          child: Row(
                                            children: [
                                              CircleAvatar(
                                                backgroundImage: controller
                                                            .searchResult[index]
                                                            .profileImage !=
                                                        null
                                                    ? NetworkImage(controller
                                                        .searchResult[index]
                                                        .profileImage)
                                                    : AssetImage(
                                                        "assets/images/person_placeholder.png"),
                                                radius: 18,
                                              ),
                                              SizedBox(
                                                width: 20,
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  controller.searchResult[index]
                                                              .firstname ==
                                                          null
                                                      ? SizedBox()
                                                      : Row(
                                                          children: [
                                                            Text(
                                                              "${controller.searchResult[index].firstname}",
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline5
                                                                  .copyWith(
                                                                color: Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? Colors
                                                                        .white
                                                                    : Colors
                                                                        .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                              ),
                                                            ),
                                                            controller
                                                                        .searchResult[
                                                                            index]
                                                                        .accountVerified ==
                                                                    "verified"
                                                                ? Row(
                                                                    children: [
                                                                      SizedBox(
                                                                        width:
                                                                            5,
                                                                      ),
                                                                      BlueTick(
                                                                        height:
                                                                            15,
                                                                        width:
                                                                            15,
                                                                        iconSize:
                                                                            10,
                                                                      ),
                                                                    ],
                                                                  )
                                                                : SizedBox(),
                                                          ],
                                                        ),
                                                  Text(
                                                    "${controller.searchResult[index].username}",
                                                    style: Styles
                                                        .baseTextTheme.headline5
                                                        .copyWith(
                                                      fontSize:
                                                          kIsWeb ? 14 : 12,
                                                      fontWeight:
                                                          FontWeight.w400,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    return InkWell(
                                      splashColor: Colors.grey,
                                      onTap: () async {
                                        // print("last print");
                                        // print("user id" +
                                        //     controller.searchResult[index].id
                                        //         .toString());

                                        controller.update();
                                      },
                                      child: Container(
                                        width: Get.width * 0.5,
                                        margin: EdgeInsets.only(bottom: 5),
                                        padding: EdgeInsets.all(8.0),
                                        color: Colors.grey.withOpacity(0.05),
                                        child: Row(
                                          children: [
                                            CircleAvatar(
                                              backgroundImage: controller
                                                          .searchResult[index]
                                                          .profileImage !=
                                                      null
                                                  ? NetworkImage(controller
                                                      .searchResult[index]
                                                      .profileImage)
                                                  : AssetImage(
                                                      "assets/images/person_placeholder.png"),
                                              radius: 18,
                                            ),
                                            SizedBox(
                                              width: 20,
                                            ),
                                            Text(
                                              "${controller.searchResult[index].title}",
                                              style: Styles
                                                  .baseTextTheme.headline5
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontWeight: FontWeight.w500,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }),
                                ),
                              )
                      ],
                    )
                  : Padding(
                      padding: EdgeInsets.only(top: 10, bottom: 30),
                      child: controller.searchMomentsList == null ||
                              controller.searchMomentsList.isEmpty
                          ? Center(child: Text(Strings.noPosts))
                          :
                          // Text('')
                          PagedL(
                              emptyStateWidget: Text(
                                Strings.noPosts,
                                style: Styles.baseTextTheme.headline5.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 14 : 12,
                                ),
                              ),
                              itemBuilder: _itemRow,
                              padding: EdgeInsets.only(top: 10, bottom: 30),
                              loadingIndicator: Padding(
                                padding: EdgeInsets.all(16.00),
                                child: Center(
                                  child: CircularProgressIndicator(
                                      color: MyColors.BlueColor),
                                ),
                              ),
                              itemDataProvider: controller.fetchData,
                              list: controller.searchMomentsList,
                              listSize: controller.checkPage(
                                  controller.searchMomentsList.length),
                            ),
                    ),

          //],
        ),
      );
    });
  }

  TextFieldWidget(
      {TextEditingController textController,
      String hintTextField,
      Function onChanged,
      BuildContext context}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            height: 45,
            width: kIsWeb ? Get.width * 0.2 : Get.width * 0.7,
            decoration: BoxDecoration(
                border: Border.all(width: 2, color: Colors.grey),
                borderRadius: BorderRadius.circular(25)),
            child: Padding(
              padding: EdgeInsets.only(left: 10),
              child: Row(
                children: [
                  Icon(
                    Icons.search,
                    size: 25,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                  Expanded(
                    child: TextField(
                      style: LightStyles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        // fontWeight: FontWeight.bold,
                      ),
                      controller: textController,
                      onChanged: onChanged,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.grey[250],
                        contentPadding: const EdgeInsets.only(
                            left: 12,
                            bottom: kIsWeb ? 18 : 12,
                            top: 12,
                            right: 12),
                        border: InputBorder.none,
                        hintText: hintTextField,
                        hintStyle: LightStyles.baseTextTheme.headline3,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          //  myPopMenu()
        ],
      ),
    );
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = addMomentController.searchMomentsList.indexWhere((element) {
      return element.postId == post.postId;
    });

    // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");

    if (index != -1) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PostCard(
              index: index,
              post: addMomentController.searchMomentsList[index],
              scaffoldKey: _scaffoldKey,
              controller: addMomentController.newsfeedController,
              momentScreen: true,
              addMomentsController: addMomentController),
        ],
      );
    }
  }
}
