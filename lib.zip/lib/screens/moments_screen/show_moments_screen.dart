import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:werfieapp/widgets/post_card.dart';

import '../../network/controller/add_moment_controller.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';

class ShowMomentsScreen extends StatelessWidget {
  // const ShowMomentsScreen({Key key}) : super(key: key);
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AddMomentsController>(builder: (controller) {
      controller.newsfeedController.momentCreateScreen = false;
      return controller.createApiCall == true && !kIsWeb
          ? Container(
              color: Colors.white,
              child: Center(
                child: CircularProgressIndicator(),
              ),
            )
          : Scaffold(
              appBar: PreferredSize(
                preferredSize: Size.fromHeight(100.0),
                child: Container(
                  height: 100,
                  // color: Colors.amberAccent,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(top: 15, left: 15, right: 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            !kIsWeb
                                ? GestureDetector(
                                    onTap: () {
                                      Get.back();
                                    },
                                    child: Icon(
                                      Icons.arrow_back,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  )
                                : SizedBox(),
                            SizedBox(),
                            Switch(
                              value: controller.isSwitchButton,
                              onChanged: (value) {
                                // print('button value ${value}');
                                controller.isSwitchButton = value;
                                controller.update();
                              },
                              activeTrackColor: Colors.blue.shade200,
                              activeColor:
                                  controller.newsfeedController.displayColor,
                            ),
                          ],
                        ),
                        MaterialButton(
                            enableFeedback: true,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            elevation: 5.0,
                            minWidth: 100,
                            height: 35,
                            color: controller.newsfeedController.displayColor,
                            child: new Text(
                              Strings.publish,
                              style: TextStyle(
                                color: Colors.white,
                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            onPressed: controller.publishButton == false
                                ? () async {
                                    if (controller.tittleMoments == null) {
                                      Fluttertoast.showToast(
                                          msg:
                                              'Please Enter the Tittle of Moments',
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: Colors.red,
                                          textColor: Colors.white,
                                          fontSize: 16.0);
                                    } else {
                                      controller.publishButton = true;
                                      controller.update();
                                      await controller.createMomentsApi(
                                          tittle: controller.tittleMoments,
                                          description:
                                              controller.descrptionMoments,
                                          coverImage: controller.image != null
                                              ? controller.image
                                              : null,
                                          postIds: controller.addId,
                                          privacyType: 'public');
                                    }
                                    controller.newsfeedController
                                        .momentCreateScreen = false;

                                    controller.publishButton = false;
                                    controller.update();
                                    controller.newsfeedController.update();
                                  }
                                : () {}),
                      ],
                    ),
                  ),
                ),
              ),
              body: SingleChildScrollView(
                child: Column(
                  children: [
                    controller.isSwitchButton == false
                        ? Container(
                            height: 200,
                            width: Get.width,
                            color: Colors.grey,
                            child: controller.image == null
                                ? Center(
                                    child: InkWell(
                                      onTap: () {
                                        controller.callGetImage();
                                        controller.update();
                                      },
                                      child: CircleAvatar(
                                          backgroundColor: Colors.grey.shade600,
                                          radius: 30,
                                          child: Icon(
                                            Icons.camera_alt_outlined,
                                            color: Colors.white,
                                          )),
                                    ),
                                  )
                                : Stack(
                                    children: [
                                      Container(
                                        height: 200,
                                        width: Get.width,
                                        color: Colors.blueAccent,
                                        child: Image.memory(
                                          controller.image,
                                        ),
                                      ),
                                      Positioned(
                                        top: 60,
                                        left: Get.width / 2,
                                        child: InkWell(
                                          onTap: () {
                                            controller.callGetImage();
                                            controller.update();
                                          },
                                          child: CircleAvatar(
                                              backgroundColor:
                                                  Colors.grey.shade600,
                                              radius: 30,
                                              child: Icon(
                                                Icons.camera_alt_outlined,
                                                color: Colors.white,
                                              )),
                                        ),
                                      )
                                    ],
                                  ))
                        : SizedBox(),
                    // controller.isSwitchButton==false?
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              controller.tittleMoments == null
                                  ? Text(
                                     Strings.addATitle,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: kIsWeb ? 25 : 20,
                                              fontWeight: FontWeight.bold),
                                    )
                                  : SizedBox(
                                      width: kIsWeb ? 200 : Get.width * 0.6,
                                      child: Text(
                                        controller.tittleMoments,
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: Styles.baseTextTheme.headline1
                                            .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 25 : 20,
                                                fontWeight: FontWeight.bold),
                                      ),
                                    ),
                              controller.descrptionMoments == null
                                  ? Text(
                                      Strings.writeAShortDesc,
                                      style: Styles.baseTextTheme.headline5
                                          .copyWith(
                                        fontSize: kIsWeb ? 14 : 12,
                                      ),
                                    )
                                  : SizedBox(
                                      width: kIsWeb ? 200 : Get.width * 0.6,
                                      child: Text(
                                        controller.descrptionMoments,
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: Styles.baseTextTheme.headline5
                                            .copyWith(
                                          fontSize: kIsWeb ? 14 : 12,
                                        ),
                                      )),
                            ],
                          ),
                          InkWell(
                            onTap: () {
                              showDialog(
                                  useSafeArea: false,
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      insetPadding: EdgeInsets.zero,
                                      contentPadding: EdgeInsets.zero,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(32.0))),
                                      content: Container(
                                        height: 400,
                                        width: kIsWeb ? 500 : 350,
                                        child: Column(
                                          children: [
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.all(10),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      GestureDetector(
                                                        onTap:

                                                            /// web on tab
                                                            kIsWeb
                                                                ? () {
                                                                    Navigator.pop(
                                                                        context);
                                                                  }
                                                                :

                                                                /// mobile on tab
                                                                () {
                                                                    Get.back();
                                                                  },
                                                        child: Icon(
                                                          Icons.close,
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          size:
                                                              kIsWeb ? 25 : 20,
                                                        ),
                                                      ),
                                                      SizedBox(
                                                        width: kIsWeb ? 20 : 10,
                                                      ),
                                                      Text(
                                                        'Edit title and description',
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize:
                                                              kIsWeb ? 18 : 12,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 0.0),
                                                    child: MaterialButton(
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.all(
                                                                    Radius.circular(
                                                                        20.0))),
                                                        elevation: 5.0,
                                                        minWidth:
                                                            kIsWeb ? 100 : 80,
                                                        height: 35,
                                                        color: controller
                                                            .newsfeedController
                                                            .displayColor,
                                                        child: new Text(Strings.save,
                                                            style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                            )),
                                                        onPressed: () {
                                                          if (controller
                                                                  .tittleFiled
                                                                  .text ==
                                                              null) {
                                                            Fluttertoast.showToast(
                                                                msg:
                                                                    'Please Enter the Tittle of Moments',
                                                                toastLength: Toast
                                                                    .LENGTH_SHORT,
                                                                gravity:
                                                                    ToastGravity
                                                                        .CENTER,
                                                                timeInSecForIosWeb:
                                                                    1,
                                                                backgroundColor:
                                                                    Colors.red,
                                                                textColor:
                                                                    Colors
                                                                        .white,
                                                                fontSize: 16.0);
                                                          } else {
                                                            // print(
                                                            //     'Singletone instance tittle${controller.tittleMoments}');
                                                            controller
                                                                    .publishButton ==
                                                                true;
                                                            controller.update();
                                                            Navigator.pop(
                                                                context);
                                                          }
                                                        }),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            TextFieldWidget(
                                                hintTextField: "Title",
                                                textController:
                                                    controller.tittleFiled,
                                                onChanged: (value) {
                                                  //  controller.tittleFiled.text=value;
                                                  controller.tittleMoments =
                                                      value;
                                                  controller.update();
                                                },
                                                context: context),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            TextFieldWidget(
                                                hintTextField: "Description",
                                                textController:
                                                    controller.descriptionFiled,
                                                onChanged: (value) {
                                                  // controller.descriptionFiled.text=value;
                                                  controller.descrptionMoments =
                                                      value;
                                                  controller.update();
                                                },
                                                context: context)
                                          ],
                                        ),
                                      ),
                                    );
                                  });
                            },
                            child: CircleAvatar(
                              backgroundColor:
                                  controller.newsfeedController.displayColor,
                              radius: 20,
                              child: Icon(
                                Icons.edit,
                                color: Colors.white,
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //  :SizedBox(),
                    Divider(),

                    controller.tempMomentsList.length != 0
                        ? Column(
                            children: List.generate(
                                controller.tempMomentsList.length, (index) {
                              return Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                      border: Border.all(
                                          color: Colors.grey, width: 1)),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: PostCard(
                                        index: index,
                                        post: controller.tempMomentsList[index],
                                        scaffoldKey: _scaffoldKey,
                                        controller:
                                            controller.newsfeedController,
                                        showMomentScreen: true,
                                        addMomentsController: controller),
                                  ),
                                ),
                              );
                            }),
                          )
                        : Container()
                  ],
                ),
              ),
            );
    });
  }

  TextFieldWidget({
    TextEditingController textController,
    String hintTextField,
    Function onChanged,
    BuildContext context,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Container(
        height: hintTextField == 'Description' ? 100 : 50,
        decoration: BoxDecoration(
            border: Border.all(width: 2, color: Colors.grey),
            borderRadius: BorderRadius.circular(10)),
        child: Padding(
          padding: const EdgeInsets.only(left: 10),
          child: TextField(
            style: LightStyles.baseTextTheme.headline2.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              // fontWeight: FontWeight.bold,
            ),
            controller: textController,
            onChanged: onChanged,
            maxLines: hintTextField == 'Description' ? 4 : 1,
            decoration: InputDecoration(
              border: InputBorder.none,
              hintText: hintTextField,
              hintStyle: LightStyles.baseTextTheme.headline3,
              fillColor: Colors.grey[250],
            ),
          ),
        ),
      ),
    );
  }
}
