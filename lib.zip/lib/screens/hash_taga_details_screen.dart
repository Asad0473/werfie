import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/hash_taga_werfs_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../network/apis/hashtag_detail_api.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';

class HashTagDetailsScreen extends StatelessWidget {
  final NewsfeedController controller;
  final String tag;

  const HashTagDetailsScreen({Key key, this.controller, this.tag})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: HashTagClass(tag),
        tablet: HashTagClass(tag),
        desktop: HashTagClass(tag),
      ),
    );
  }
}

class HashTagClass extends StatefulWidget {
  String tag;

  HashTagClass(this.tag);

  @override
  State<HashTagClass> createState() => _HashTagClassState();
}

class _HashTagClassState extends State<HashTagClass> {
  NewsfeedController controller = Get.find<NewsfeedController>();
  Future<HashtagDetailAPIRes> hashtagDetail;
  bool isDataFetched = false;

  @override
  void initState() {
    // Remove special characters and spaces (except #)
    widget.tag = widget.tag.replaceAll(RegExp(r'[^\w\s#]'), '');

    // hashtagDetail = HashtagDetailAPI().hashtagDetail("ذهب");
    hashtagDetail = HashtagDetailAPI().hashtagDetail(widget.tag);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: IconThemeData(
                color: Colors.black,
              ),
              title: Text(
                Strings.aboutHashTag,
                // style: TextStyle(color: Colors.black),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )
          : PreferredSize(child: Container(), preferredSize: Size(0, 0)),
      body: SingleChildScrollView(
        child: kIsWeb
            ? Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                          icon: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                          onPressed: () {
                            controller.isPostDetails = false;
                            controller.isTagInfoScreen = false;
                            controller.fromNotificationsScreen = false;
                            controller.isProfileScreen = false;
                            controller.isTagInfoScreen = false;
                            controller.isTagWerfsScreen = false;

                            controller.isNewsFeedScreen = true;

                            controller.update();
                            Navigator.of(context).pop();
                          }),
                      SizedBox(width: 30),
                      Text(
                        Strings.aboutHashTag,
                        // style: TextStyle(fontSize: Get.width / 50)
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  FutureBuilder<HashtagDetailAPIRes>(
                      future: hashtagDetail,
                      builder: (context, dataSnapshot) {
                        if (dataSnapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        } else {
                          if (dataSnapshot.error != null) {
                            return Center(
                              child: Text(
                                  'Oops…Something went wrong! Please try again'),
                            );
                          } else {
                            HashtagDetailAPIRes model = dataSnapshot.data;
                            print(dataSnapshot.data);
                            if (dataSnapshot.data.data==null ) {
                              return Center(
                                child: Text(dataSnapshot.data.message),
                              );
                            } else if (dataSnapshot.hasData) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    SizedBox(height: 40.0),
                                    Text(
                                      model.data.title ?? "",
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 20.0,
                                      ),
                                    ),
                                    SizedBox(height: 30.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text('Total post:',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14.0,
                                                  )),
                                              Text(
                                                model.data.postCount.toString(),
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text('Total contributors:',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14.0,
                                                  )),
                                              Text(
                                                model.data.contributers
                                                    .toString(),
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 30.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text('Created on:',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14.0,
                                                  )),
                                              Text(
                                                DateFormat('MMM dd, yyyy')
                                                    .format(DateTime.parse(
                                                        model.data.createdAt)),
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text('Started trending on:',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 14.0,
                                                  )),
                                              Text(
                                                DateFormat(
                                                        'MMM dd, yyyy HH:mm a')
                                                    .format(DateTime.parse(
                                                        model.data.createdAt)),
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 30.0),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Country:',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                              Text(
                                                model.data.country,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 14.0,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10),
                                          child: ElevatedButton(
                                            onPressed: () {
                                              Get.toNamed(
                                                  FluroRouters.mainScreen +
                                                      "/tagWerfs/" +
                                                      widget.tag.toString());
                                            },
                                            child: Text(
                                              Strings.viewWerfs,
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                            style: ElevatedButton.styleFrom(
                                              primary: MyColors.werfieBlue,
                                              // padding: EdgeInsets.symmetric(vertical: 16),
                                              minimumSize: Size(250, 40),
                                              shape: StadiumBorder(),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            } else {
                              return Center(
                                child: Text(dataSnapshot.data.message),
                              );
                            }
                          }
                        }
                      })
                ],
              )
            : Column(
                children: [
                  FutureBuilder(
                      future: hashtagDetail,
                      builder: (context, dataSnapshot) {
                        if (dataSnapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        } else {
                          if (dataSnapshot.error != null) {
                            return Center(
                              child: Text(
                                  'Oops... Something went wrong! Please try again'),
                            );
                          } else {
                            HashtagDetailAPIRes model = dataSnapshot.data;
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 20.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SizedBox(height: 40.0),
                                  Text(
                                    model.data.title,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 20.0,
                                    ),
                                  ),
                                  SizedBox(height: 30.0),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text('Total post:',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.0,
                                                )),
                                            Text(
                                              model.data.postCount.toString(),
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text('Total contributors:',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.0,
                                                )),
                                            Text(
                                              model.data.contributers
                                                  .toString(),
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 30.0),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text('Created on:',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.0,
                                                )),
                                            Text(
                                              DateFormat('MMM dd, yyyy').format(
                                                  DateTime.parse(
                                                      model.data.createdAt)),
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text('Started trending on:',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 14.0,
                                                )),
                                            Text(
                                              DateFormat('MMM dd, yyyy HH:mm a')
                                                  .format(DateTime.parse(
                                                      model.data.createdAt)),
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 30.0),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Country:',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                            Text(
                                              model.data.country,
                                              style: TextStyle(
                                                fontWeight: FontWeight.w500,
                                                fontSize: 14.0,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 10),
                                        child: ElevatedButton(
                                          onPressed: () {
                                            if (kIsWeb) {
                                              Get.toNamed(
                                                  FluroRouters.mainScreen +
                                                      "/tagWerfs/" +
                                                      widget.tag.toString());
                                            } else {
                                              Get.to(HashTagWerfsScreen(
                                                tag: widget.tag,
                                                controller: controller,
                                              ));
                                              //LoggingUtils.printValue("tag value", tag);
                                            }
                                          },
                                          child: Text(
                                            Strings.viewWerfs,
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 16,
                                            ),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            primary: MyColors.werfieBlue,
                                            // padding: EdgeInsets.symmetric(vertical: 16),
                                            minimumSize: Size(200, 40),
                                            shape: StadiumBorder(),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          }
                        }
                      })
                ],
              ),
      ),
    );
  }
}
