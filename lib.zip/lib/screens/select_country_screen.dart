import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/GetCountriesResponse.dart' as cr;
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/rounded_button.dart';
import '../network/controller/login_controller.dart';
import '../network/controller/profile_controller.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class selectCountrySettingScreen extends StatefulWidget {
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  State<selectCountrySettingScreen> createState() =>
      _selectCountrySettingScreenState();
}

class _selectCountrySettingScreenState
    extends State<selectCountrySettingScreen> {
  TextEditingController textControllor = TextEditingController();
  final controller = Get.find<NewsfeedController>();
  LoginController logincontroller;

  ProfileController profileController = Get.put(ProfileController());

  TextEditingController username = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  // centerTitle: true,
                  title: Text(
                    Strings.selectACountry,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 20,
                    ),
                    // TextStyle(
                    //     color: Colors.white,
                    //     fontSize: 18,
                    //     fontWeight: FontWeight.w700
                    // ),
                    // style: Theme.of(context).textTheme.headline6.copyWith(
                    //   fontSize: 18,
                    //   fontWeight: FontWeight.w700,
                    //   color: Colors.black,
                    // ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = true;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                if (!kIsWeb) {
                                  FocusManager.instance.primaryFocus?.unfocus();
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Padding(
            padding: const EdgeInsets.all(kIsWeb ? 20 : 0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  kIsWeb
                      ? Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 10,
                            horizontal: 0,
                          ),
                          child: Row(
                            children: [
                              // MediaQuery.of(context).size.width >= 1050
                              //     ? SizedBox()
                              //     :
                              MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: GestureDetector(
                                  onTap: () {
                                    controller.isListOfBlockedAccounts = false;
                                    controller.isTranslations = false;
                                    controller.isLanguageSettings = false;
                                    controller.isSettingDetail = false;
                                    controller.isSettingTypeDetail = false;
                                    controller.isLanguageType = false;
                                    controller.isListOfBlockedAccounts = false;
                                    controller.isChangeUserName = false;
                                    controller.isChangeCountry = false;
                                    controller.isAccountInformation = true;

                                    controller.update();
                                  },
                                  child: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                ),
                              ),
                              Expanded(
                                child: Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    Strings.changeCountrySettings,
                                    textAlign: TextAlign.left,
                                    style:
                                        Styles.baseTextTheme.headline1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                    //     fontSize: 18,fontWeight: FontWeight.w700
                                    // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                    //),
                                    // style: Theme.of(context)
                                    //     .textTheme
                                    //     .headline6
                                    //     .copyWith(
                                    //       fontSize: 18,
                                    //       fontWeight: FontWeight.w700,
                                    //       color: Colors.black,
                                    //     ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : Container(),
                  Container(
                    height: 1,
                    color: Colors.grey[300],
                  ),
                  SizedBox(height: 20),

                  CountryDropDown(
                      Get.find<LoginController>().list,
                      Get.find<LoginController>().countryId,
                      context,
                      Get.find<LoginController>(),
                      (p0) => null,
                      textControllor),

                  SizedBox(
                    height: 20,
                  ),

                  RoundedButton(
                    Strings.change,
                    () async {
                      // print("Scontroller.userId ${controller.userId}");
                      int isSuccess = await controller.changeCountry(
                          controller.userId,
                          Get.find<LoginController>().countryId);

                      username.clear();
                      if (isSuccess == 1) {
                        UtilsMethods.toastMessageShow(controller.displayColor,
                            controller.displayColor, controller.displayColor,
                            message: Strings.changedTheCountryName);
                      }
                      if (isSuccess == 2) {
                        UtilsMethods.toastMessageShow(controller.displayColor,
                            controller.displayColor, controller.displayColor,
                            message: 'error while changing the name.');

                        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        //   content: Text('There was an error in saving this werf!',
                        //     style: TextStyle(
                        //       color: Theme
                        //           .of(context)
                        //           .brightness == Brightness.dark
                        //           ? Colors.white
                        //           : Colors.black,
                        //     ),
                        //   ),
                        // ),
                        // );
                      }

                      if (Get.isRegistered<ProfileController>()) {
                        Get.find<ProfileController>().userProfile =
                            await controller.getUserProfile();
                        controller.isAccountInformation = true;
                        controller.isChangeCountry = false;
                      } else {
                        profileController.userProfile =
                            await controller.getUserProfile();
                        controller.isAccountInformation = true;
                        controller.isChangeCountry = false;
                      }
                    },
                    horizontalPadding: 30.0,
                    roundedButtonColor: controller.displayColor,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  CountryDropDown(
      List<cr.Data> list,
      int countryId,
      BuildContext context,
      LoginController controller,
      String Function(dynamic) onValidate,
      TextEditingController textControllor) {
    return list == null
        ? Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  Strings.pleaseChooseACountry,
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w500),
                  // TextStyle(
                  //
                  //     fontSize: 14,
                  //     fontWeight: FontWeight.w500),
                ),
                Icon(
                  Icons.arrow_drop_down,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                )
              ],
            ),
          )
        : Container(
            child: DropdownButtonHideUnderline(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(40),
                  color: Colors.grey[300].withOpacity(0.3),
                ),
                child: Row(
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12),
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        child: SvgPicture.asset(
                          "assets/images/world.svg",
                          height: 25.0,
                          width: 25.0,
                          allowDrawingOutsideViewBox: true,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      width: MediaQuery.of(context).size.width >= 1050
                          ? 360
                          : MediaQuery.of(context).size.width >= 720
                              ? 480
                              : Get.width / 1.7,
                      child: DropdownButton2<cr.Data>(
                        isExpanded: true,
                        hint: Text(Strings.pleaseChooseACountry,
                            style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w500)),
                        items: list
                            .map((item) => DropdownMenuItem<cr.Data>(
                                  value: item,
                                  child: Text(
                                    item.name,
                                    style: TextStyle(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ))
                            .toList(),
                        value: controller.chosenValue,
                        onChanged: (value) {
                          setState(() {
                            controller.chosenValue = value;
                            controller.countryId = value.id;
                          });
                        },
                        buttonStyleData: ButtonStyleData(
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                          ),
                          height: 50,
                          width: MediaQuery.of(context).size.width * 0.28,
                        ),
                        dropdownStyleData: const DropdownStyleData(
                          maxHeight: 200,
                        ),
                        menuItemStyleData: const MenuItemStyleData(
                          height: 40,
                        ),
                        dropdownSearchData: DropdownSearchData(
                          searchController: textControllor,
                          searchInnerWidgetHeight: 50,
                          searchInnerWidget: Container(
                            height: 50,
                            padding: const EdgeInsets.only(
                              top: 8,
                              bottom: 4,
                              right: 8,
                              left: 8,
                            ),
                            child: TextFormField(
                              expands: true,
                              maxLines: null,
                              controller: textControllor,
                              decoration: InputDecoration(
                                isDense: true,
                                hoverColor: Colors.transparent,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                hintText: Strings.searchForAnItem,
                                hintStyle: const TextStyle(fontSize: 12),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                              ),
                            ),
                          ),
                          searchMatchFn: (item, searchValue) {
                            return (item.value.name
                                .toLowerCase()
                                .toString()
                                .contains(searchValue.toLowerCase()));
                          },
                        ),
                        //This to clear the search value when you close the menu
                        onMenuStateChange: (isOpen) {
                          if (!isOpen) {
                            textControllor.clear();
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
            //  height: 55,
          );
  }

// countriesDropDown(List<dynamic> listt, int countryId, BuildContext context,
//  // String Function(dynamic) onValidate
//
//     /*,FocusNode focusNode*/) {
//   return listt == null
//       ? Padding(
//     padding: const EdgeInsets.symmetric(vertical: 12),
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           "${Get.find<ProfileController>().userProfile.region}",
//           style: Styles.baseTextTheme.headline2.copyWith(
//               color: Theme
//                   .of(context)
//                   .brightness == Brightness.dark ? Colors.white : Colors
//                   .black,
//               fontSize: 14,
//               fontWeight: FontWeight.w500
//           ),
//           // TextStyle(
//           //
//           //     fontSize: 14,
//           //     fontWeight: FontWeight.w500),
//         ),
//         Icon(
//           Icons.arrow_drop_down,
//           color: Theme
//               .of(context)
//               .brightness == Brightness.dark ? Colors.white : Colors.black,
//         )
//       ],
//     ),
//   )
//       : Container(
//     //  height: 55,
//     child: DropdownButtonHideUnderline(
//       child: DropdownButtonFormField(
//        // focusNode: focusNode,
//         decoration: InputDecoration(
//           prefixIcon: Padding(
//             padding: EdgeInsets.symmetric(horizontal: 12),
//             child: CircleAvatar(
//               backgroundColor: Colors.white,
//               child: SvgPicture.asset(
//                 "assets/images/world.svg",
//                 height: 25.0,
//                 width: 25.0,
//                 allowDrawingOutsideViewBox: true,
//                 color: Colors.black,
//               ),
//             ),
//           ),
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(40),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(40),
//             borderSide: BorderSide(
//               width: 0,
//               style: BorderStyle.none,
//             ),
//           ),
//           fillColor: Colors.grey[250],
//           filled: true,
//           contentPadding: EdgeInsets.fromLTRB(15, 15, 15, 15),
//         ),
//         isExpanded: true,
//        // validator: onValidate,
//         focusColor: Colors.grey.withOpacity(0.1),
//         // value: controller.chosenValue,
//         //elevation: 5,
//         style: TextStyle(
//           color: Theme
//               .of(context)
//               .brightness == Brightness.dark ? Colors.white : Colors.black,
//           fontWeight: FontWeight.w500,
//           fontSize: 14,
//         ),
//         iconEnabledColor: Colors.black,
//         items: listt.map((item) {
//           return DropdownMenuItem(
//             value: item['id'],
//             child: Text(
//               item['name'],
//               style: TextStyle(
//                 color: Theme
//                     .of(context)
//                     .brightness == Brightness.dark ? Colors.white : Colors
//                     .black,
//
//               ),
//             ),
//           );
//         }).toList(),
//         hint: Text(
//          "${Get.find<ProfileController>().userProfile.region}",
//           style: Styles.baseTextTheme.headline4.copyWith(
//             color: Theme
//                 .of(context)
//                 .brightness == Brightness.dark ? Colors.white : MyColors
//                 .lightColor,
//             fontWeight: FontWeight.w500,
//             fontSize: 14,
//           ),
//         ),
//
//         onChanged: (value) {
//
//           print('asdasdads');
//           Get.find<LoginController>().countryId = value;
//           Get.find<LoginController>().chosenValue = value;
//           Get.find<LoginController>().update();
//         },
//       ),
//     ),
//   );
// }
}
