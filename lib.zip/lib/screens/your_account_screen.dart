import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/screens/reset_password_screen.dart';
import 'package:werfieapp/screens/session.dart';

import '../components/input_password_field.dart';
import '../network/controller/login_controller.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/strings.dart';
import '../utils/utils_methods.dart';
import '../widgets/deactivation.dart';
import '../widgets/listtile_settings.dart';
import 'account_info_setting_screen.dart';
import 'change_password_screen.dart';
import 'login_screen.dart';

class YourAccount extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();
  final loginController = Get.put(LoginController());

  YourAccount({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    centerTitle: true,
                    title: Text(
                      Strings.YourAccount,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 20,
                      ),
                      // TextStyle(
                      //     color: Colors.white,
                      //     fontSize: 18,
                      //     fontWeight: FontWeight.w700
                      // ),
                      // style: Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 18,
                      //   fontWeight: FontWeight.w700,
                      //   color: Colors.black,
                      // ),
                    ),
                    leading: !kIsWeb
                        ? MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                                onTap: () {
                                  controller.isListOfBlockedAccounts = false;
                                  controller.isTranslations = false;
                                  controller.isLanguageSettings = true;
                                  controller.isLanguageType = false;
                                  controller.isListOfBlockedAccounts = false;
                                  if (!kIsWeb) {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    Navigator.of(context).pop();
                                  }
                                  controller.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                          )
                        : SizedBox(),
                  )
                : PreferredSize(
                    child: Container(),
                    preferredSize: Size(0, 0),
                  ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 12,
                            ),
                            child: Row(
                              children: [
                                MediaQuery.of(context).size.width >= 1050
                                    ? SizedBox()
                                    : MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () {
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isTranslations = false;
                                            controller.isLanguageSettings =
                                                true;
                                            controller.isSettingDetail = true;
                                            controller.isSettingTypeDetail =
                                                false;
                                            controller.isLanguageType = false;
                                            controller.isListOfBlockedAccounts =
                                                false;
                                            controller.isChangeUserName = false;
                                            controller.isYourAccount = false;

                                            controller.update();
                                          },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                          ),
                                        ),
                                      ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      Strings.YourAccount,
                                      textAlign: TextAlign.left,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                      //     fontSize: 18,fontWeight: FontWeight.w700
                                      // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                      //),
                                      // style: Theme.of(context)
                                      //     .textTheme
                                      //     .headline6
                                      //     .copyWith(
                                      //       fontSize: 18,
                                      //       fontWeight: FontWeight.w700,
                                      //       color: Colors.black,
                                      //     ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    kIsWeb
                        ? Container(
                            height: 1,
                            color: Colors.grey[300],
                          )
                        : SizedBox(),
                    ListTileSettings(
                      Strings.accountInformation,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isChangeUserName = false;
                        controller.isSettingDetail = false;
                        controller.isAccountInformation = true;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isYourAccount = false;

                        // controller.isSettingTypeDetail = true;

                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        accountInformationSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.ChangeYourPassword,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = false;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacy = false;
                        controller.isProfileLanguagetype = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isChangeUserName = false;
                        controller.isSettingDetail = false;
                        controller.isAccountInformation = false;
                        controller.isChangeUserName = false;
                        controller.isChangeEmail = false;
                        controller.isChangeCountry = false;
                        controller.isSettinggender = false;
                        controller.isChangePassword = true;
                        controller.isYourAccount = false;

                        // controller.isSettingTypeDetail = true;

                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        ChangePassword()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onHover: (bool value) {
                              if (Get.find<NewsfeedController>()
                                      .deactivateColor ==
                                  false) {
                                Get.find<NewsfeedController>().deactivateColor =
                                    true;
                                Get.find<NewsfeedController>().update();
                              } else {
                                Get.find<NewsfeedController>().deactivateColor =
                                    false;
                                Get.find<NewsfeedController>().update();
                              }
                            },
                            onPressed: () async {
                              if (kIsWeb) {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext con) {
                                      return Shortcuts(
                                        shortcuts: {
                                          LogicalKeySet(
                                                  LogicalKeyboardKey.escape):
                                              EscIntent()
                                        },
                                        child: AlertDialog(
                                            backgroundColor:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? MyColors.liteDark
                                                    : Colors.white,
                                            insetPadding: EdgeInsets.symmetric(
                                                horizontal: 0, vertical: 0),
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                                    horizontal: 12),
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(25.0))),
                                            content: SingleChildScrollView(
                                              child: Padding(
                                                padding: const EdgeInsets.only(
                                                    left: 15,
                                                    right: 15,
                                                    top: 15),
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? MyColors.liteDark
                                                        : Colors.white,
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                50)),
                                                  ),
                                                  height: 400,
                                                  width: 500,
                                                  child: Form(
                                                    key:
                                                        LoginController.formKey,
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: [
                                                        GestureDetector(
                                                          onTap: () {
                                                            Navigator.pop(
                                                                context);
                                                          },
                                                          child: Actions(
                                                            actions: {
                                                              EscIntent: CallbackAction<
                                                                      EscIntent>(
                                                                  onInvoke: (Intent) =>
                                                                      Navigator.of(
                                                                              context)
                                                                          .pop())
                                                            },
                                                            child: Focus(
                                                              autofocus: true,
                                                              focusNode:
                                                                  FocusNode(),
                                                              child:
                                                                  MouseRegion(
                                                                cursor:
                                                                    SystemMouseCursors
                                                                        .click,
                                                                child: Icon(
                                                                  Icons
                                                                      .cancel_outlined,
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(height: 30),
                                                        Text(
                                                          Strings
                                                              .confirmYourPasswords,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                        ),
                                                        SizedBox(height: 20),
                                                        Container(
                                                          // height: 55,
                                                          child:
                                                              InputPasswordField(
                                                            // formKey: LoginController.formKey,
                                                            TextInputAction:
                                                                TextInputAction
                                                                    .next,
                                                            // onPasswordEntered: (value) {
                                                            //   value = password.text;
                                                            // },
                                                            text: Strings
                                                                .enterYourPassword,
                                                            controller:
                                                                loginController
                                                                    .password,
                                                            validator: (value) {
                                                              return UtilsMethods
                                                                  .validatePassword(
                                                                      value);
                                                            },
                                                          ),
                                                        ),
                                                        SizedBox(height: 10),
                                                        Align(
                                                          alignment: Alignment
                                                              .centerRight,
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    right:
                                                                        15.0),
                                                            child: TextButton(
                                                              onPressed:
                                                                  () async {
                                                                // print("hello");
                                                                if (!kIsWeb) {
                                                                  Get.to(
                                                                    // MaterialPageRoute(
                                                                    //   builder: (context) =>
                                                                    ResetPasswordScreen(),
                                                                    // ),
                                                                  );
                                                                } else {
                                                                  // Get.to(ResetPasswordScreen());
                                                                  // Get.toNamed(FluroRouters.resetPasswordScreen);
                                                                  Get.toNamed(
                                                                      FluroRouters
                                                                          .resetPasswordScreen);
                                                                  // context.push(AppRoute.resetPasswordScreen);
                                                                }
                                                              },
                                                              child: Text(
                                                                Strings
                                                                    .lostPassword,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline1
                                                                    .copyWith(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontSize:
                                                                      kIsWeb
                                                                          ? 16
                                                                          : 14,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          height: 40,
                                                        ),
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              child:
                                                                  ElevatedButton(
                                                                // key: LoginController.formKey,
                                                                onPressed:
                                                                    () async {
                                                                  if (LoginController
                                                                      .formKey
                                                                      .currentState
                                                                      .validate()) {
                                                                    // print(
                                                                    //     "agiya login pr");

                                                                    int code;
                                                                    code = await Get.find<
                                                                            NewsfeedController>()
                                                                        .deactivateProfile(
                                                                            Password:
                                                                                loginController.password.text);
                                                                    loginController
                                                                        .password
                                                                        .clear();

                                                                    // print(
                                                                    //     "code $code");

                                                                    if (code !=
                                                                        null) {
                                                                      // Navigator.of(context,rootNavigator: true).pop();

                                                                      Navigator.pop(
                                                                          context);
                                                                      final snackBar =
                                                                          SnackBar(
                                                                        backgroundColor:
                                                                            Colors.blue,
                                                                        elevation:
                                                                            0.0,
                                                                        content: Container(
                                                                            height: 100,
                                                                            color: Colors.blue,
                                                                            padding: EdgeInsets.symmetric(
                                                                              horizontal: 100,
                                                                            ),
                                                                            child: Center(
                                                                                child: const Text(
                                                                              "You're about to permanently delete your account.you have 30 days to reactivate your account.After 30 days, the deletion process will begin and you won't be able to retrieve any of the content or information you have added.",
                                                                              textAlign: TextAlign.center,
                                                                            ))),
                                                                        duration:
                                                                            const Duration(seconds: 8),
                                                                        behavior:
                                                                            SnackBarBehavior.floating,
                                                                      );
                                                                      ScaffoldMessenger.of(
                                                                              context)
                                                                          .showSnackBar(
                                                                              snackBar);

                                                                      Future.delayed(
                                                                          const Duration(
                                                                              seconds: 5),
                                                                          () async {
                                                                        SharedPreferences
                                                                            preferences =
                                                                            await SharedPreferences.getInstance();
                                                                        await preferences
                                                                            .clear();
                                                                        await Get.find<NewsfeedController>()
                                                                            .storage
                                                                            .erase();
                                                                        Get.delete<
                                                                            SessionController>();
                                                                        Get.delete<
                                                                            NewsfeedController>();
                                                                        if (kIsWeb) {
                                                                          // Navigator.pop(context);
                                                                          Get.offNamed(
                                                                              FluroRouters.loginScreen);
                                                                          // context.pushReplacement(AppRoute.loginScreen);
                                                                        } else {
                                                                          Navigator.pop(
                                                                              context);
                                                                          Get.offUntil(
                                                                              MaterialPageRoute(builder: (context) => LoginScreen()),
                                                                              (route) => false);
                                                                        }
                                                                      });
                                                                    }
                                                                  }
                                                                },
                                                                child: Text(
                                                                  Strings
                                                                      .deactivateAccount,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline2
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .white,
                                                                    fontSize:
                                                                        14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                                style: ElevatedButton
                                                                    .styleFrom(
                                                                  shadowColor:
                                                                      Colors
                                                                          .transparent,
                                                                  primary:
                                                                      controller
                                                                          .displayColor,
                                                                  padding: EdgeInsets.symmetric(
                                                                      vertical:
                                                                          17,
                                                                      horizontal:
                                                                          25),
                                                                  elevation:
                                                                      0.0,
                                                                  shape:
                                                                      StadiumBorder(),
                                                                  // minimumSize: Size(100, 40),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          height: 20,
                                                        ),

                                                        Center(
                                                          child: Text(
                                                            Strings.or,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              color: Theme.of(context)
                                                                          .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                      .black,
                                                              fontSize: kIsWeb
                                                                  ? 16
                                                                  : 14,
                                                            ),
                                                            textAlign: TextAlign
                                                                .center,
                                                          ),
                                                        ),

                                                        SizedBox(
                                                          height: 20,
                                                        ),

                                                        ///delete account
                                                        Row(
                                                          children: [
                                                            Expanded(
                                                              child:
                                                                  ElevatedButton(
                                                                // key: LoginController.formKey,
                                                                onPressed:
                                                                    () async {
                                                                  if (LoginController
                                                                      .formKey
                                                                      .currentState
                                                                      .validate()) {
                                                                    showDialog<
                                                                        String>(
                                                                      context:
                                                                          con,
                                                                      builder: (BuildContext
                                                                              context) =>
                                                                          AlertDialog(
                                                                        title:
                                                                            Text(
                                                                          Strings
                                                                              .permanentlyDeleteAccount,
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline2
                                                                              .copyWith(
                                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                                ? Colors.white
                                                                                : Colors.black,
                                                                            fontSize:
                                                                                16,
                                                                            fontWeight:
                                                                                FontWeight.bold,
                                                                          ),
                                                                        ),
                                                                        content: Container(
                                                                            width: 90,
                                                                            child: Text(
                                                                              Strings.IfYouWontToWerfieAccountDelteOnOneClickOKButtontoDeleteThePermanentDeleteAccount,
                                                                              textAlign: TextAlign.justify,
                                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                fontSize: kIsWeb ? 14 : 12,
                                                                              ),
                                                                            )),
                                                                        actions: <
                                                                            Widget>[
                                                                          ElevatedButton(
                                                                            onPressed: () =>
                                                                                Navigator.pop(context, 'Cancel'),
                                                                            child:
                                                                                Text(
                                                                                  Strings.cancel,
                                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.white,
                                                                                fontSize: 14,
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                            ),
                                                                            style:
                                                                                ElevatedButton.styleFrom(
                                                                              shadowColor: Colors.transparent,
                                                                              primary: controller.displayColor,
                                                                              elevation: 0.0,
                                                                              // minimumSize: Size(100, 40),
                                                                            ),
                                                                          ),
                                                                          ElevatedButton(
                                                                            onPressed:
                                                                                () async {
                                                                              /// idhr ann

                                                                              // print("agiya login pr");
                                                                              int code;
                                                                              code = await Get.find<NewsfeedController>().deletedProfile(Password: loginController.password.text);
                                                                              loginController.password.clear();

                                                                              // print("code $code");

                                                                              if (code != null) {
                                                                                // Navigator.of(context,rootNavigator: true).pop();

                                                                                // Navigator.pop(context);

                                                                                Fluttertoast.showToast(msg: "Your account has been permanently deleted.", toastLength: Toast.LENGTH_SHORT, gravity: ToastGravity.CENTER, timeInSecForIosWeb: 1, backgroundColor: Colors.red, textColor: Colors.white, fontSize: 16.0);

                                                                                SharedPreferences preferences = await SharedPreferences.getInstance();
                                                                                await preferences.clear();
                                                                                await Get.find<NewsfeedController>().storage.erase();
                                                                                Get.delete<SessionController>();
                                                                                Get.delete<NewsfeedController>();

                                                                                // Navigator.pop(context);
                                                                                Get.offNamed(FluroRouters.loginScreen);
                                                                                // context.pushReplacement(AppRoute.loginScreen);

                                                                                Navigator.pop(context);
                                                                                Navigator.pop(context);
                                                                                Navigator.pop(context);
                                                                              }
                                                                            },
                                                                            child:
                                                                                Text(
                                                                              'OK',
                                                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                                                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.white,
                                                                                fontSize: 14,
                                                                                fontWeight: FontWeight.bold,
                                                                              ),
                                                                            ),
                                                                            style:
                                                                                ElevatedButton.styleFrom(
                                                                              shadowColor: Colors.transparent,
                                                                              primary: Colors.red,
                                                                              elevation: 0.0,
                                                                              // minimumSize: Size(100, 40),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  }
                                                                },
                                                                child: Text(
                                                                  Strings
                                                                      .deleteAccount,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline2
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .white,
                                                                    fontSize:
                                                                        14,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                                style: ElevatedButton
                                                                    .styleFrom(
                                                                  shadowColor:
                                                                      Colors
                                                                          .transparent,
                                                                  primary:
                                                                      Colors
                                                                          .red,
                                                                  padding: EdgeInsets.symmetric(
                                                                      vertical:
                                                                          17,
                                                                      horizontal:
                                                                          25),
                                                                  elevation:
                                                                      0.0,
                                                                  shape:
                                                                      StadiumBorder(),
                                                                  // minimumSize: Size(100, 40),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            )

                                            //     Deactivation(
                                            //   context2: context,
                                            // ),
                                            ),
                                      );
                                    });
                              } else {
                                Get.to(Deactivation(
                                  context2: context,
                                ));
                              }
                            },
                            child: Text(
                              Strings.deactivationAndDeletion,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                      color: Colors.red,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18),
                            ),





                            style: ElevatedButton.styleFrom(
                              shadowColor: Colors.transparent,
                              // primary: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                              primary: Get.find<NewsfeedController>()
                                          .deactivateColor ==
                                      false
                                  ? Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.black
                                      : Colors.grey[200]
                                  : Colors.red.withOpacity(0.3),
                              padding: EdgeInsets.symmetric(vertical: 20),
                              elevation: 0.0,

                              // shape: StadiumBorder(),
                              minimumSize: Size(100, 40),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
