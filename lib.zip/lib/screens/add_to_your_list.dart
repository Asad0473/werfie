import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/list_get_member_model.dart';
import '../network/controller/List_controller.dart';
import '../network/singleTone.dart';
import '../utils/font.dart';
import '../utils/strings.dart';

class AddToYourList extends StatefulWidget {
  final List<MemberGetModel> list;

  AddToYourList({Key key, this.list}) : super(key: key);

  @override
  State<AddToYourList> createState() => _AddToYourListState();
}

class _AddToYourListState extends State<AddToYourList> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(builder: (controller) {
      return Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                ListTile(
                    leading: IconButton(
                        onPressed: () {
                          SingleTone.instance.selectedLocation = null;
                          setState(() {});
                          Navigator.of(context).pop();
                        },
                        icon: Icon(
                          Icons.close,
                          color: Colors.black87,
                        )),
                    title: Text(
                      Strings.addToYourList,
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.w800),
                    ),
                    trailing: MaterialButton(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      color: Colors.grey[500],
                      // backgroundRtab
                      textColor: Colors.white,
                      // foreground
                      onPressed: () async {
                        // print("list create button");
                        controller.selectedList = await controller.listDetail(
                            listId: controller.selectedList.listDetail.id);
                        // Navigator.pop(context);

                        controller.newsfeedController.isListDetailScreen = true;
                        controller.newsfeedController.isSearch = false;
                        controller.newsfeedController.isFilter = false;
                        controller.newsfeedController.isFilterScreen = false;
                        controller.newsfeedController.isTrendsScreen = false;
                        controller.newsfeedController.isNewsFeedScreen = false;
                        controller.newsfeedController.isBrowseScreen = false;
                        controller.newsfeedController.isNotificationScreen =
                            false;
                        controller.newsfeedController.isWhoToFollowScreen =
                            false;
                        controller.newsfeedController.isSavedPostScreen = false;
                        controller.newsfeedController.isChatScreen = false;
                        controller.newsfeedController.isPostDetails = false;
                        controller.newsfeedController.isProfileScreen = false;
                        controller.newsfeedController.searchText.text = '';
                        controller.newsfeedController.isListScreen = false;
                        controller.newsfeedController.isFollwerScreen = false;
                        controller.newsfeedController.isSettingsScreen = false;
                        controller.newsfeedController.navRoute = "isChatScreen";
                        controller.newsfeedController.update();

                        controller.update();

                        controller.newsfeedController.update();
                        Navigator.pop(context);
                      },
                      child: Text(Strings.done),
                    )),
                Container(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        SizedBox(height: 20.0),
                        DefaultTabController(
                            length: 2, // length of tabs
                            initialIndex: 1,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: <Widget>[
                                  Container(
                                    child: TabBar(
                                      labelColor: Colors.blue,
                                      unselectedLabelColor: Colors.black,
                                      tabs: [
                                        Tab(
                                            text:
                                                'Members ${widget.list.length}'),
                                        Tab(text: Strings.suggested),
                                      ],
                                    ),
                                  ),
                                  Container(
                                      height: Get.height,

                                      //height of TabBarView
                                      decoration: BoxDecoration(
                                          border: Border(
                                              top: BorderSide(
                                                  color: Colors.grey,
                                                  width: 0.5))),
                                      child: TabBarView(children: <Widget>[
                                        Column(
                                          children: List.generate(
                                              widget.list.length,
                                              (index) => ListTile(
                                                  leading: Container(
                                                    height: 40,
                                                    width: 40,
                                                    decoration: BoxDecoration(
                                                        color: Colors.grey,
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(10),
                                                        image: DecorationImage(
                                                            image: NetworkImage(widget
                                                                        .list[
                                                                            index]
                                                                        .profileImage ==
                                                                    null
                                                                ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                                                : widget
                                                                    .list[index]
                                                                    .profileImage),
                                                            fit: BoxFit.fill)),
                                                  ),
                                                  title: Text(widget
                                                      .list[index].firstname),
                                                  subtitle: Row(
                                                    children: [
                                                      Expanded(
                                                        child: Text("@" +
                                                            widget.list[index]
                                                                .username),
                                                      ),
                                                      SizedBox(
                                                        width: 4,
                                                      ),
                                                      // Text(controller
                                                      //     .addMemberList[index]
                                                      //     .username),
                                                    ],
                                                  ),
                                                  trailing: ElevatedButton(
                                                      style: ElevatedButton.styleFrom(
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          30)),
                                                          primary: Colors
                                                              .blueAccent),
                                                      onPressed:

                                                          //     :
                                                          () {
                                                        // setState(() {
                                                        // isFollow = false;

                                                        // print(
                                                        //     "index >>>>>>>>>>>>>>>>>>>>>>>>$index");

                                                        if (controller
                                                            .modelSuggestList
                                                            .isNotEmpty) {
                                                          controller
                                                              .modelSuggestList
                                                              .forEach(
                                                                  (element) {
                                                            if (element.id ==
                                                                widget
                                                                    .list[index]
                                                                    .memberFollowerId) {
                                                              element.isFollow =
                                                                  false;
                                                            }
                                                          });
                                                        }

                                                        // controller
                                                        //     .update();
                                                        // controller
                                                        //     .update([
                                                        //   "edit_suggestion"
                                                        // ]);
                                                        // controller.deletePost(controller.addMemberList[index].id);
                                                        // dataList.remove(
                                                        //     controller.  listOfDiscover[index]);
                                                        // });
                                                        controller.update();
                                                        controller.update([
                                                          "edit_suggestion"
                                                        ]);
                                                        controller.unFollowRemoveMethod(
                                                            list_Id: controller
                                                                .selectedList
                                                                .listDetail
                                                                .id
                                                                .toString(),
                                                            member_id: widget
                                                                .list[index]
                                                                .memberFollowerId
                                                                .toString(),
                                                            type: "member");
                                                        widget.list
                                                            .removeAt(index);
                                                        setState(() {});
                                                        // print("List Length : " +
                                                        //     'Members ${widget.list.length}');
                                                        // controller.addMemberList.removeAt(i);
                                                      },
                                                      child:
                                                          // isFollow == false
                                                          //     ? Text(
                                                          //   "Add",
                                                          //   style: Theme.of(context).textTheme.headline6.copyWith(
                                                          //     fontSize: 14,
                                                          //     fontWeight: FontWeight.w700,
                                                          //     color: Colors.white,
                                                          //   ),
                                                          // )
                                                          //     :
                                                          Text(
                                                            Strings.remove,
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .headline6
                                                            .copyWith(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                              color:
                                                                  Colors.white,
                                                            ),
                                                      )))),
                                        ),
                                        SingleChildScrollView(
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    top: 10,
                                                    right: 10,
                                                    bottom: 10,
                                                    left: 10),
                                                child: TextField(
                                                  style: LightStyles
                                                      .baseTextTheme.headline2
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    // fontWeight: FontWeight.bold,
                                                  ),
                                                  autofocus: true,
                                                  // controller: controller.chatSearchTEC,
                                                  // focusNode: controller.chatSearchTextFocus,
                                                  onChanged: (value) async {

                                                    controller
                                                            .modelSuggestList =
                                                        await controller
                                                            .SuggestedPost(
                                                                list_Id: controller
                                                                    .selectedList
                                                                    .listDetail
                                                                    .id
                                                                    .toString(),
                                                                name: value);
                                                    setState(() {});
                                                  },
                                                  textAlignVertical:
                                                      TextAlignVertical.center,
                                                  decoration: InputDecoration(
                                                    hintText:
                                                        Strings.searchPeople,
                                                    hintStyle: LightStyles
                                                        .baseTextTheme
                                                        .headline2,
                                                    prefixIcon: Icon(
                                                      Icons.search,
                                                      size: 20,
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    ),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40),
                                                      borderSide: BorderSide(
                                                        width: 1,
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40),
                                                      borderSide: BorderSide(
                                                        width: 1,
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                    fillColor: Colors.grey[250],
                                                  ),
                                                ),
                                              ),
                                              controller.modelSuggestList
                                                          .isEmpty ||
                                                      controller
                                                              .modelSuggestList ==
                                                          null
                                                  ? Center(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .only(
                                                                top: 20.0),
                                                        child:
                                                            Text("No results"),
                                                      ),
                                                    )
                                                  : Container(
                                                      // height: 200,
                                                      // color: Colors.deepOrange,
                                                      child: Column(
                                                        children: List.generate(
                                                            controller
                                                                .modelSuggestList
                                                                .length,
                                                            (index) => ListTile(
                                                                leading:
                                                                    Container(
                                                                  height: 40,
                                                                  width: 40,
                                                                  decoration: BoxDecoration(
                                                                      color: Colors
                                                                          .grey,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      image: DecorationImage(
                                                                          image: NetworkImage(controller.modelSuggestList[index].authorProfileImage == null
                                                                              ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                                              : controller.modelSuggestList[index].authorProfileImage),
                                                                          fit: BoxFit.fill)),
                                                                ),
                                                                title: Text(controller
                                                                    .modelSuggestList[
                                                                        index]
                                                                    .authorName),
                                                                subtitle: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child: Text(controller
                                                                          .modelSuggestList[
                                                                              index]
                                                                          .username),
                                                                    ),
                                                                  ],
                                                                ),

                                                                ///idhr kerna kam
                                                                trailing: ElevatedButton(
                                                                    style: ElevatedButton.styleFrom(
                                                                      shape: RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30)),
                                                                      primary: Theme.of(context).brightness ==
                                                                              Brightness.dark
                                                                          ? !controller.modelSuggestList[index].isFollow
                                                                              ? Colors.white
                                                                              : Colors.black
                                                                          : !controller.modelSuggestList[index].isFollow
                                                                              ? Colors.black
                                                                              : Colors.white,

                                                                      //  controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)
                                                                    ),
                                                                    onPressed: controller.modelSuggestList[index].isFollow == false
                                                                        ? () async {
                                                                            controller.modelSuggestList[index].isFollow =
                                                                                true;
                                                                            setState(() {});

                                                                            MemberGetModel
                                                                                member =
                                                                                MemberGetModel();
                                                                            member.username =
                                                                                controller.modelSuggestList[index].username;
                                                                            // member
                                                                            //     .id =
                                                                            //     controller
                                                                            //         .modelSuggestList[index]
                                                                            //         .id;
                                                                            member.memberFollowerId =
                                                                                controller.modelSuggestList[index].id;
                                                                            member.firstname =
                                                                                controller.modelSuggestList[index].authorName;
                                                                            member.listId =
                                                                                controller.selectedList.listDetail.id;
                                                                            member.profileImage =
                                                                                controller.modelSuggestList[index].authorProfileImage;
                                                                            widget.list.add(member);

                                                                            controller.update([
                                                                              "edit_suggestion"
                                                                            ]);
                                                                            controller.update();

                                                                            controller.memberAdd(
                                                                                controller.selectedList.listDetail.id.toString(),
                                                                                controller.modelSuggestList[index].id,
                                                                                "member");
                                                                            setState(() {});
                                                                          }
                                                                        : () {
                                                                            controller.modelSuggestList[index].isFollow ==
                                                                                false;
                                                                            setState(() {});
                                                                            controller.modelSuggestList.forEach((element) {
                                                                              if (element.id == controller.modelSuggestList[index].id) {
                                                                                element.isFollow = false;
                                                                              }
                                                                            });

                                                                            widget.list.removeWhere((item) =>
                                                                                item.memberFollowerId ==
                                                                                controller.modelSuggestList[index].id);
                                                                            // for (int i = 0; i <
                                                                            //
                                                                            //     widget. list
                                                                            //         .length; i++) {
                                                                            //   if ( widget.list[i]
                                                                            //       .id ==
                                                                            //       controller
                                                                            //           .modelSuggestList[index]
                                                                            //           .id) {
                                                                            //     widget.list
                                                                            //         .removeAt(
                                                                            //         i);
                                                                            //   }
                                                                            // }
                                                                            controller.update([
                                                                              "edit_suggestion"
                                                                            ]);
                                                                            controller.update();
                                                                            // controller
                                                                            //     .deletePost(
                                                                            //     controller
                                                                            //         .modelSuggestList[index]
                                                                            //         .id);
                                                                            // dataList.remove(
                                                                            //     controller.  listOfDiscover[index]);

                                                                            // controller
                                                                            //     .update(
                                                                            //     [
                                                                            //       "edit_suggestion"
                                                                            //     ]);
                                                                            // controller
                                                                            //     .update();
                                                                            controller.unFollowRemoveMethod(
                                                                                list_Id: controller.selectedList.listDetail.id.toString(),
                                                                                member_id: controller.modelSuggestList[index].id.toString(),
                                                                                type: "member");
                                                                            setState(() {});
                                                                          },
                                                                    child: controller.modelSuggestList[index].isFollow == false
                                                                        ? Text(
                                                                            Strings.add,
                                                                            style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.w700,
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                                                                                ),
                                                                          )
                                                                        : Text(
                                                                      Strings.remove,
                                                                            style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight.w700,
                                                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                ),
                                                                          )))),
                                                      ),
                                                    ),
                                            ],
                                          ),
                                        ),
                                      ]))
                                ])),
                      ]),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}
