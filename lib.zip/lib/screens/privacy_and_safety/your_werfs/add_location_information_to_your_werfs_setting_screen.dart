import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';

import '../../../network/controller/news_feed_controller.dart';
import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';

class AddLocationInformationToYourWerfsSettingScreen extends StatelessWidget {
  AddLocationInformationToYourWerfsSettingScreen({Key key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
              backgroundColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              centerTitle: true,
              title: Text(
                Strings.addLocationInformationToYourWerfs,
                style: Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 20,
                ),
              ),
              leading: !kIsWeb
                  ? MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                    onTap: () {
                      controller.newsfeedController.isListOfBlockedAccounts = false;
                      controller.newsfeedController.isTranslations = false;
                      controller.newsfeedController.isLanguageSettings = true;
                      controller.newsfeedController.isLanguageType = false;
                      controller.newsfeedController.isListOfBlockedAccounts = false;
                      if (!kIsWeb) {
                        FocusManager.instance.primaryFocus
                            ?.unfocus();
                        Navigator.of(context).pop();
                      }
                      controller.update();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
              )
                  : SizedBox(),
            )
                : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.newsfeedController
                                .isListOfBlockedAccounts = false;
                            controller.newsfeedController.isTranslations =
                            false;
                            controller.newsfeedController
                                .isLanguageSettings = true;
                            controller.newsfeedController
                                .isSettingDetail = false;
                            controller.newsfeedController
                                .isSettingTypeDetail = false;
                            controller.newsfeedController.isLanguageType =
                            false;
                            controller.newsfeedController.isListOfBlockedAccounts = false;
                            controller.newsfeedController.isChangeUserName = false;
                            controller.newsfeedController.isYourAccount = false;
                            controller.newsfeedController.isYourWerfs = false;
                            controller.newsfeedController.isAddLocationInformationToYourWerfs = false;

                            if( controller.newsfeedController.isComingFromlocationScreen == true)
                              {
                                controller.newsfeedController.isLocationInformation =true;
                              }
                            else{
                              controller.newsfeedController.isYourWerfs = true;
                            }


                            controller.newsfeedController.update();
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              Strings.addLocationInformationToYourWerfs,
                              textAlign: TextAlign.left,
                              style:
                              Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),

                            ),
                          ),
                        ),
                      ],
                    )
                        : Container(),
                    SizedBox(
                      height: 12,
                    ),
                    Text(
                      Strings.ifEnabledYouWillBeAbleToAttachLocationToYourWerfs,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.subtitle1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white.withOpacity(0.5)
                            : Colors.black.withOpacity(0.5),
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),

                    ListTile(
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.addLocationInformationToYourWerfs,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            value:controller.isAddLocationInformationToYourWerfs,
                            onChanged: (value) {
                              controller.isAddLocationInformationToYourWerfs = value;
                              controller.update();

                              if(value==true)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.isAddLocationInformationToYourWerfs==true?1:0,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );
                                controller.update();


                              }
                              else if(value==false)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.isAddLocationInformationToYourWerfs==true?1:0,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );
                                controller.update();

                              }


                            })
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onHover: (bool value) {
                              if (Get.find<NewsfeedController>()
                                  .deactivateColor ==
                                  false) {
                                Get.find<NewsfeedController>().deactivateColor =
                                true;
                                Get.find<NewsfeedController>().update();
                              } else {
                                Get.find<NewsfeedController>().deactivateColor =
                                false;
                                Get.find<NewsfeedController>().update();
                              }
                            },
                            onPressed: () async {
                              showDialog(
                                  context: context,
                                  builder: (BuildContext con) {
                                    return AlertDialog(


                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(15),
                                        ),
                                        backgroundColor: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? MyColors.liteDark
                                            : Colors.white,
                                        contentPadding: EdgeInsets.zero,
                                        content: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 20, right: 20, top: 20),
                                          child: Container(
                                            height: 250,
                                            width: 250,
                                            child: SingleChildScrollView(
                                              child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    "${Strings.removeAllLocationInformationAttachedToYourWerfs}?",
                                                    style: TextStyle(
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness == Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                    ),
                                                  ),
                                                  Text(Strings.locationLabelsYouHaveAddedToYourWerfsWillNoLongerBeVisibleOnWerfieComWerfieForIOSAndWerfieForAndroidTheseUpdatesMayTakeSomeTimeToGoIntoEffect,
                                                    style: TextStyle(
                                                      height: 1.2,
                                                      fontSize: 14,
                                                      color: Theme
                                                          .of(context)
                                                          .brightness == Brightness.dark
                                                          ? MyColors.grey
                                                          : Colors.black,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    height: 20,
                                                  ),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: ElevatedButton(
                                                          // key: LoginController.formKey,
                                                          onPressed: () async {
                                                            controller.removeLocationApi();
                                                            Navigator.pop(context);

                                                            controller.update();
                                                          },
                                                          child: Text(
                                                            Strings.delete,
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              color: Colors.white,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                          style: ElevatedButton.styleFrom(
                                                            shadowColor:
                                                            Colors.transparent,
                                                            primary: Colors.red,
                                                            padding: EdgeInsets.symmetric(

                                                                vertical: 20,
                                                                horizontal: 25),
                                                            elevation: 0.0,
                                                            shape: StadiumBorder(),
                                                            // minimumSize: Size(100, 40),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(
                                                    height: 10,
                                                  ),
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: ElevatedButton(
                                                          // key: LoginController.formKey,
                                                          onPressed: () async {
                                                            Navigator.pop(context);
                                                          },
                                                          child: Text(
                                                            Strings.cancel,
                                                            style: Styles.baseTextTheme
                                                                .headline2.copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness.dark ? Colors
                                                                  .white : Colors.black,
                                                              fontSize: 14,
                                                              fontWeight: FontWeight.bold,
                                                            ),
                                                          ),
                                                          style: ElevatedButton.styleFrom(
                                                            shadowColor:
                                                            Colors.transparent,
                                                            primary: Theme
                                                                .of(context)
                                                                .brightness == Brightness.dark
                                                                ? Colors.black
                                                                : Colors.white,
                                                            padding: EdgeInsets.symmetric(

                                                                vertical: 20,
                                                                horizontal: 25),
                                                            elevation: 0.0,
                                                            shape: StadiumBorder(

                                                            ),
                                                            side: BorderSide(
                                                              width: 1,
                                                              color: MyColors.grey,
                                                            ),
                                                            // minimumSize: Size(100, 40),
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),


                                                ],
                                              ),
                                            ),


                                          ),
                                        )

                                      //     Deactivation(
                                      //   context2: context,
                                      // ),
                                    );
                                  });
                             },
                            child: Text(
                              Strings.removeAllLocationInformationAttachedToYourWerfs,
                              style: Theme.of(context)
                                  .textTheme
                                  .headline6
                                  .copyWith(
                                  color: Colors.red,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14),
                            ),





                            style: ElevatedButton.styleFrom(
                              shadowColor: Colors.transparent,
                              // primary: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                              primary: Get.find<NewsfeedController>()
                                  .deactivateColor ==
                                  false
                                  ? Theme.of(context).brightness ==
                                  Brightness.dark
                                  ? Colors.black
                                  : Colors.grey[200]
                                  : Colors.red.withOpacity(0.3),
                              padding: EdgeInsets.symmetric(vertical: 20),
                              elevation: 0.0,

                              // shape: StadiumBorder(),
                              minimumSize: Size(100, 40),
                            ),
                          ),
                        ),
                      ],
                    ),



                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
