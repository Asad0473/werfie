import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';

import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';

class DirectMessageSettingScreen extends StatelessWidget {
  DirectMessageSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
              backgroundColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              centerTitle: true,
              title: Text(
                Strings.directMessages,
                style: Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 20,
                ),
              ),
              leading: !kIsWeb
                  ? MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                    onTap: () {
                      controller.newsfeedController
                          .isListOfBlockedAccounts = false;
                      controller.newsfeedController.isTranslations =
                      false;
                      controller.newsfeedController
                          .isLanguageSettings = true;
                      controller.newsfeedController.isLanguageType =
                      false;
                      controller.newsfeedController
                          .isListOfBlockedAccounts = false;
                      if (!kIsWeb) {
                        FocusManager.instance.primaryFocus
                            ?.unfocus();
                        Navigator.of(context).pop();
                      }
                      controller.update();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
              )
                  : SizedBox(),
            )
                : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.newsfeedController
                                .isListOfBlockedAccounts = false;
                            controller.newsfeedController.isTranslations =
                            false;
                            controller.newsfeedController
                                .isLanguageSettings = false;
                            controller.newsfeedController
                                .isSettingDetail = false;
                            controller.newsfeedController
                                .isSettingTypeDetail = false;
                            controller.newsfeedController.isLanguageType =
                            false;
                            controller.newsfeedController
                                .isListOfBlockedAccounts = false;
                            controller.newsfeedController.isChangeUserName = false;
                            controller.newsfeedController.isYourAccount = false;
                            controller.newsfeedController.isAccountPrivacy = true;

                            controller.newsfeedController.update();
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              Strings.directMessages,
                              textAlign: TextAlign.left,
                              style:
                              Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                              // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                              //     fontSize: 18,fontWeight: FontWeight.w700
                              // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                              //),
                              // style: Theme.of(context)
                              //     .textTheme
                              //     .headline6
                              //     .copyWith(
                              //       fontSize: 18,
                              //       fontWeight: FontWeight.w700,
                              //       color: Colors.black,
                              //     ),
                            ),
                          ),
                        ),
                      ],
                    )
                        : Container(),

                    SizedBox(
                      height: 10,
                    ),
                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),

                    ListTile(
                       contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.controlWhoCanMessageYou,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          Strings.dependingOnTheSettingYouSelectDifferentPeopleCanSendYouADirectMessage,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                    ),


                    ListTile(
                        contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {


                        },
                        title: Text(
                          Strings.allowMessagesOnlyFromPeopleYouFollow,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.youWontReceiveAnyMessageRequests,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),


                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100),
                            ),
                            value:controller.isAllowMessagesOnlyFromPeopleYouFollow,
                            onChanged: (value) {

                              if(value ==true )
                              {
                                controller.isAllowMessagesOnlyFromPeopleYouFollow = value;
                                controller.isAllowMessageRequestsOnlyFromVerifiedUsers = false;
                                controller.isAllowMessagesRequestsFromEveryone = false;
                                controller.update();
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:"people_you_follow",
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                                controller.update();
                              }

                            })
                    ),


                    ListTile(
                        contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.allowMessageRequestsOnlyFromVerifiedUsers,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.peopleYouFollowWillStillBeAbleToMessageYou,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),

                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100),
                            ),
                            value: controller.isAllowMessageRequestsOnlyFromVerifiedUsers,
                            onChanged: (value) {
                              if(value ==true )
                              {
                                controller.isAllowMessagesOnlyFromPeopleYouFollow = false;
                                controller.isAllowMessageRequestsOnlyFromVerifiedUsers = value;
                                controller.isAllowMessagesRequestsFromEveryone = false;
                                controller.update();
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:"message_requests_from_verified",
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                                controller.update();
                              }



                            })
                    ),
                    ListTile(
                        contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {


                        },
                        title: Text(
                          Strings.allowMessagesRequestsFromEveryone,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.peopleYouFollowWillStillBeAbleToMessageYou,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),

                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100),
                            ),
                            value:controller.isAllowMessagesRequestsFromEveryone,
                            onChanged: (value) {
                              if(value ==true )
                              {
                                controller.isAllowMessagesOnlyFromPeopleYouFollow = false;
                                controller.isAllowMessageRequestsOnlyFromVerifiedUsers = false;
                                controller.isAllowMessagesRequestsFromEveryone = value;
                                controller.update();
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:"from_everyone",
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                                controller.update();
                              }


                            })
                    ),
                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      Strings.otherControls,
                      style: TextStyle(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    ListTile(
                       contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.filterLowQualityMessages,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.hideMessageRequestsThatHaveBeenDetectedAsBeingPotentiallySpanOrLowQualityTheseWillBeSentToASeparateInboxAtTheBottomOfYourMessageRequestsYouCanStillAccessThemIfYouWant,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            value:controller.   isFilterLowQualityMessages,
                            onChanged: (value) {

                              controller.isFilterLowQualityMessages= value;
                              controller.update();


                              if(value == true)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.isFilterLowQualityMessages==true?1:0,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                              }
                              else  if(value == false)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.isFilterLowQualityMessages==true?1:0,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                              }
                              controller.update();

                            })
                    ),

                    ListTile(
                        contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.showReadReceipts,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.letPeopleYouAreMessagingWithKnowWhenYouVeSeenTheirMessagesReadReceiptsAreNotShownOnMessageRequests,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            value:controller.   isShowReadReceipts,
                            onChanged: (value) {

                              controller. isShowReadReceipts= value;
                              controller.update();


                              if(value == true)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data.filterLowQualityMessages,
                                    showReadReceipts:controller.isShowReadReceipts==true?1:0,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                              }
                              else  if(value == false)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data.searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data.filterLowQualityMessages,
                                    showReadReceipts:controller.isShowReadReceipts==true?1:0,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                              }
                              controller.update();

                            })
                    ),



                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
