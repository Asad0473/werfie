import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/reset_password_screen.dart';
import 'package:werfieapp/screens/verification_Password_Screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/models/GetCountriesResponse.dart' as cr;
import '../../../network/controller/login_controller.dart';
import '../../../network/controller/profile_controller.dart';
import '../../../network/controller/settings_controller.dart';
import '../../../utils/colors.dart';
import '../../../utils/font.dart';



class ExploreSettingScreen extends StatefulWidget {
  ExploreSettingScreen({Key key}) : super(key: key);

  @override
  State<ExploreSettingScreen> createState() => _ExploreSettingScreenState();
}

class _ExploreSettingScreenState extends State<ExploreSettingScreen> {


  TextEditingController textControllor = TextEditingController();

  // LoginController logincontroller;

  ProfileController profileController = Get.put(ProfileController());

  TextEditingController username = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return kIsWeb
            ? SingleChildScrollView(
          child: Container(
            height: 500,
            width: 450,
            child: Padding(
              padding: const EdgeInsets.all(15),
              child:

             controller.isCountryScreen ==false?
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      InkWell(
                        onTap: (){
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.clear,
                        ),
                      ),
                      SizedBox(width: 30),
                      Text(
                        Strings.exploreSettings,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height:30,
                  ),
                  Text(
                    Strings.location,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                  ListTile(
                     contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.showContentInThisLocation,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isShowContentInThisLocation,
                          onChanged: (value) {
                            controller.isShowContentInThisLocation = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:   controller.isShowContentInThisLocation==true?1:0,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:   controller.isShowContentInThisLocation==true?1:0,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();



                          })
                  ),

                  controller.isShowContentInThisLocation ==false?
                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {

                        controller.isCountryScreen =true;
                        controller.update();
                      },
                      title: Text(
                        Strings.exploreLocation,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        controller.countryName ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 20,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : MyColors.black,
                      ),
                  ):SizedBox(),




                  kIsWeb
                      ? Container(
                    height: 1,
                    color: Colors.grey[300],
                  )
                      : SizedBox(),
                  SizedBox(
                    height:10,
                  ),
                  Text(
                    Strings.personalization,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.trendsForYou,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isExploreSettingPersonalization,
                          onChanged: (value) {
                            controller.isExploreSettingPersonalization = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.isExploreSettingPersonalization==true?1:0,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.isExploreSettingPersonalization==true?1:0,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();

                          })
                  ),

                ],
              ):Column(
               crossAxisAlignment: CrossAxisAlignment.start,
               children: [
                 Row(
                   mainAxisAlignment: MainAxisAlignment.start,
                   children: [
                     InkWell(
                       onTap: (){
                         controller.isCountryScreen = false;
                         controller.update();
                       },
                       child: Icon(
                         Icons.arrow_back,
                       ),
                     ),
                     SizedBox(width: 30),
                     Text(
                       Strings.location,
                       style: TextStyle(
                         fontSize: 17,
                         fontWeight: FontWeight.bold,
                         color:
                         Theme.of(context).brightness == Brightness.dark
                             ? Colors.white
                             : Colors.black,
                       ),
                     ),
                   ],
                 ),
                 SizedBox(height: 10),
                 CountryDropDown(
                     Get.find<LoginController>().list,
                     Get.find<LoginController>().countryId,
                     context,
                     Get.find<LoginController>(),
                     controller,
                         (p0) => null,
                     textControllor),


               ],
             ),
            ),
          ),
        )
            : Scaffold(
          appBar: AppBar(
            backgroundColor:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            centerTitle: true,
            title: Text(
              Strings.exploreSettings,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 20,
              ),
            ),
            leading: !kIsWeb
                ? MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                  onTap: () {
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    controller.newsfeedController.isTranslations = false;
                    controller.newsfeedController.isLanguageSettings = true;
                    controller.newsfeedController.isLanguageType = false;
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    if (!kIsWeb) {
                      FocusManager.instance.primaryFocus
                          ?.unfocus();
                      Navigator.of(context).pop();
                    }
                    controller.update();
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  )),
            )
                : SizedBox(),
          ),
          body: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
            child: SafeArea(
              child:   controller.isCountryScreen ==false?
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Text(
                    Strings.location,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.showContentInThisLocation,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.WhenThisIsOnYouWillSeeWhatIsHappeningAroundYouRightNow ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isShowContentInThisLocation,
                          onChanged: (value) {
                            controller.isShowContentInThisLocation = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:   controller.isShowContentInThisLocation==true?1:0,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:   controller.isShowContentInThisLocation==true?1:0,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();



                          })
                  ),

                  controller.isShowContentInThisLocation ==false?
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    selected: true,
                    onTap: () {

                      controller.isCountryScreen =true;
                      controller.update();
                    },
                    title: Text(
                      Strings.exploreLocation,
                      style: TextStyle(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    subtitle: Text(
                      controller.countryName ,
                      style: TextStyle(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black.withOpacity(0.5),
                        fontSize: 14,
                      ),
                    ),
                    trailing: Icon(
                      Icons.arrow_forward_ios,
                      size: 20,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : MyColors.black,
                    ),
                  ):SizedBox(),




                  kIsWeb
                      ? Container(
                    height: 1,
                    color: Colors.grey[300],
                  )
                      : SizedBox(),
                  SizedBox(
                    height:10,
                  ),
                  Text(
                    Strings.personalization,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                  ),
                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.trendsForYou,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.youCanPersonalizeTrendsBasedOnYourLocationAndWhoYouFollow ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isExploreSettingPersonalization,
                          onChanged: (value) {
                            controller.isExploreSettingPersonalization = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.isExploreSettingPersonalization==true?1:0,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.isExploreSettingPersonalization==true?1:0,
                                  searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();

                          })
                  ),

                ],
              ):Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      kIsWeb?
                      InkWell(
                        onTap: (){
                          controller.isCountryScreen = false;
                          controller.update();
                        },
                        child: Icon(
                          Icons.arrow_back,
                        ),
                      ):SizedBox(),
                      kIsWeb?
                      SizedBox(width: 30):SizedBox(),
                      Text(
                        Strings.location,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  CountryDropDown(
                      Get.find<LoginController>().list,
                      Get.find<LoginController>().countryId,
                      context,
                      Get.find<LoginController>(),
                      controller,
                          (p0) => null,
                      textControllor),


                ],
              ),
            ),
          ),
        );
      },
    );
  }

  CountryDropDown(
      List<cr.Data> list,
      int countryId,
      BuildContext context,
      LoginController Controller,
      SettingController settingController,
      String Function(dynamic) onValidate,
      TextEditingController textControllor) {
    return list == null
        ? Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            Strings.pleaseChooseACountry,
            style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 14,
                fontWeight: FontWeight.w500),
            // TextStyle(
            //
            //     fontSize: 14,
            //     fontWeight: FontWeight.w500),
          ),
          Icon(
            Icons.arrow_drop_down,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : Colors.black,
          )
        ],
      ),
    )
        : Container(
      child: DropdownButtonHideUnderline(
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(40),
            color: Colors.grey[300].withOpacity(0.3),
          ),
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: SvgPicture.asset(
                    "assets/images/world.svg",
                    height: 25.0,
                    width: 25.0,
                    allowDrawingOutsideViewBox: true,
                    color: Colors.black,
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  
                  child: DropdownButton2<cr.Data>(
                    isExpanded: true,
                    hint: Text(Strings.pleaseChooseACountry,
                        style: Styles.baseTextTheme.headline2.copyWith(
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w500)),
                    items: list
                        .map((item) => DropdownMenuItem<cr.Data>(
                      value: item,
                      child: Text(
                        item.name,
                        style: TextStyle(
                          color: Theme.of(context).brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ))
                        .toList(),
                    value: Controller.chosenValue,
                    onChanged: (value) {
                      setState(() {
                        Controller.chosenValue = value;
                        settingController.countryName = value.name;
                        settingController.update();
                        Controller.countryId = value.id;
                      });
                    },
                    buttonStyleData: ButtonStyleData(
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                      ),
                      height: 50,
                      width: MediaQuery.of(context).size.width * 0.28,
                    ),
                    dropdownStyleData: const DropdownStyleData(
                      maxHeight: 200,
                    ),
                    menuItemStyleData: const MenuItemStyleData(
                      height: 40,
                    ),
                    dropdownSearchData: DropdownSearchData(
                      searchController: textControllor,
                      searchInnerWidgetHeight: 50,
                      searchInnerWidget: Container(
                        height: 50,
                        padding: const EdgeInsets.only(
                          top: 8,
                          bottom: 4,
                          right: 8,
                          left: 8,
                        ),
                        child: TextFormField(
                          expands: true,
                          maxLines: null,
                          controller: textControllor,
                          decoration: InputDecoration(
                            isDense: true,
                            hoverColor: Colors.transparent,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 8,
                            ),
                            hintText: Strings.searchForAnItem,
                            hintStyle: const TextStyle(fontSize: 12),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ),
                      searchMatchFn: (item, searchValue) {
                        return (item.value.name
                            .toLowerCase()
                            .toString()
                            .contains(searchValue.toLowerCase()));
                      },
                    ),
                    //This to clear the search value when you close the menu
                    onMenuStateChange: (isOpen) {
                      if (!isOpen) {
                        textControllor.clear();
                      }
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      //  height: 55,
    );
  }
}
