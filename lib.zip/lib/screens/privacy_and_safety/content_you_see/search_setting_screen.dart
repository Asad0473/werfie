import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/explore_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/your_werfs/add_location_information_to_your_werfs_setting_screen.dart';

import '../../../utils/colors.dart';
import '../../../utils/fluro_router.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';
import '../../topic_screens/topic_tab_screen.dart';



class SearchSettingScreen extends StatelessWidget {
  SearchSettingScreen({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return kIsWeb
            ? SingleChildScrollView(
          child: Container(
            height: 500,
            width: 450,
            child: Padding(
              padding: const EdgeInsets.all(15),
              child:
              Column (
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      InkWell(
                        onTap: (){
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.clear,
                        ),
                      ),
                      SizedBox(width: 30),
                      Text(
                        Strings.searchSettings,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                          color:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height:30,
                  ),

                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.hideSensitiveContent,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isSearchSettingHideSensitiveContent,
                          onChanged: (value) {
                            controller.isSearchSettingHideSensitiveContent = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:   controller.isSearchSettingHideSensitiveContent==true?1:0,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:   controller.isSearchSettingHideSensitiveContent==true?1:0,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();

                          })
                  ),

                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.removeBlockedAndMutedAccounts,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isSearchSettingRemoveBlockedAccounts,
                          onChanged: (value) {
                            controller.isSearchSettingRemoveBlockedAccounts = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.isSearchSettingRemoveBlockedAccounts==true?1:0,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.isSearchSettingRemoveBlockedAccounts==true?1:0,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();


                          })
                  ),
                ],
              )

            ),
          ),
        )
            : Scaffold(
          appBar: AppBar(
            backgroundColor:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            centerTitle: true,
            title: Text(
              Strings.searchSettings,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 20,
              ),
            ),
            leading: !kIsWeb
                ? MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                  onTap: () {
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    controller.newsfeedController.isTranslations = false;
                    controller.newsfeedController.isLanguageSettings = true;
                    controller.newsfeedController.isLanguageType = false;
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    if (!kIsWeb) {
                      FocusManager.instance.primaryFocus
                          ?.unfocus();
                      Navigator.of(context).pop();
                    }
                    controller.update();
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  )),
            )
                : SizedBox(),
          ),
          body: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
            child: SafeArea(
              child:   Column (
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [


                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.hideSensitiveContent,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.thisPreventsWerfsWithPotentiallySensitiveContentDisplayingInYourSearchResults ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isSearchSettingHideSensitiveContent,
                          onChanged: (value) {
                            controller.isSearchSettingHideSensitiveContent = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:   controller.isSearchSettingHideSensitiveContent==true?1:0,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent:   controller.isSearchSettingHideSensitiveContent==true?1:0,
                                  searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();

                          })
                  ),

                  ListTile(
                      contentPadding: EdgeInsets.zero,
                      selected: true,
                      onTap: () {},
                      title: Text(
                        Strings.removeBlockedAndMutedAccounts,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      subtitle: Text(
                        Strings.useThisToEliminateSearchResultsFromAccountYouHaveBlockedOrMuted ,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black.withOpacity(0.5),
                          fontSize: 14,
                        ),
                      ),
                      trailing: Checkbox(
                          activeColor: controller.newsfeedController.displayColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5),
                          ),
                          value:controller.isSearchSettingRemoveBlockedAccounts,
                          onChanged: (value) {
                            controller.isSearchSettingRemoveBlockedAccounts = value;
                            controller.update();
                            if(value==true)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.isSearchSettingRemoveBlockedAccounts==true?1:0,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            else if(value==false)
                            {
                              controller.privacyAndSafetyApi(action: "update",
                                  protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                  allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                  whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                  markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                  addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                  displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                  exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                  exploreSettingsPersonalization:controller.privacyAndSafety.data.exploreSettingsPersonalization,
                                  searchSettingsHideSensitiveContent: controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                  searchSettingsRemoveBlockedAccounts:controller.isSearchSettingRemoveBlockedAccounts==true?1:0,
                                  directMessages:controller.privacyAndSafety.data.   directMessages,
                                  filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                  showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                  spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                  discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                  discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                  personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                  inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                  shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                  locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                              );
                              controller.update();


                            }
                            controller.update();


                          })
                  ),








                ],
              )
            ),
          ),
        );
      },
    );
  }
}
