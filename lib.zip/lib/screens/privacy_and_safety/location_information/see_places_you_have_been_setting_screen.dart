import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/explore_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/search_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/your_werfs/add_location_information_to_your_werfs_setting_screen.dart';

import '../../../utils/colors.dart';
import '../../../utils/fluro_router.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';
import '../../topic_screens/topic_tab_screen.dart';

class  SeePlacesYouHaveBeenSettingScreen extends StatelessWidget {
  SeePlacesYouHaveBeenSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
            backgroundColor:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            centerTitle: true,
            title: Text(
              Strings.seePlacesYouHaveBeen,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 16,
              ),

            ),
            leading: !kIsWeb
                ? MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                  onTap: () {
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    controller.newsfeedController.isTranslations = false;
                    controller.newsfeedController.isLanguageSettings = true;
                    controller.newsfeedController.isLanguageType = false;
                    controller.newsfeedController.isMutedAccounts = false;
                    controller.newsfeedController.isMuteAndBlock = true;

                    if (!kIsWeb) {
                      Navigator.of(context).pop();
                    }
                    controller.update();
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  )),
            )
                : SizedBox(),
          )
              : PreferredSize(
            child: Container(),
            preferredSize: Size(0, 0),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              kIsWeb
                  ? Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 16.0,
                  horizontal: 12,
                ),
                child: Row(
                  children: [

                    GestureDetector(
                      onTap: () {
                        controller.newsfeedController.isListOfBlockedAccounts = false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings = false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isMutedAccounts = false;
                        controller.newsfeedController.isMuteWords = false;
                        controller.newsfeedController.isMuteAndBlock = false;
                        controller.newsfeedController.isSeePlacesYouHaveBeen = false;
                        controller.newsfeedController.isLocationInformation = true;

                        controller.newsfeedController.update();
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          Strings.seePlacesYouHaveBeen,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),

                        ),
                      ),
                    ),

                  ],
                ),
              )
                  : Container(),
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text(
                  Strings.theseAreThePlacesWerfieUsesToShowYouMoreRelevantContentYouWontSeePlacesListedHereIfYouTurnedOffPersonalizeBasedOnPlacesYouHaveBeen,
                  textAlign: TextAlign.left,
                  style: Styles.baseTextTheme.subtitle1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.5)
                        : Colors.black.withOpacity(0.5),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),

              Container(
                height: 1,
                color: Colors.grey[300],
              ),
              SizedBox(height: 20),
              controller.newsfeedController.isBlockedUsersLoading
                  ? CircularProgressIndicator(
                color: MyColors.BlueColor,
              )
                  : controller.newsfeedController.blockedUser == null
                  ? Center(
                child: Text(Strings.youHaveNotMutedAnyPersonYet,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 14,
                    )),

              )
                  : Expanded(
                child: ListView.builder(
                  itemCount: controller.newsfeedController.blockedUser.length,
                  itemBuilder: (context, index) {
                    return  Padding(
                      padding: const EdgeInsets.only(left: 10,right: 10),
                      child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {},
                          leading:Container(
                            height: 35,
                            width: 35,
                            decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border:Border.all(
                                    color: Colors.grey.withOpacity(0.5)
                                )

                            ),
                            child: Icon(
                              Icons.location_on,
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 20,
                            ),
                          ) ,
                          title: Text(
                            "Lahore,Pakistan",
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
  // Widget build(BuildContext context) {
  //   return GetBuilder<SettingController>(
  //     builder: (controller) {
  //       return Scaffold(
  //           appBar: !kIsWeb
  //               ? AppBar(
  //             backgroundColor:
  //             Theme.of(context).brightness == Brightness.dark
  //                 ? Colors.black
  //                 : Colors.white,
  //             centerTitle: true,
  //             title: Text(
  //               Strings.seePlacesYouHaveBeen,
  //               style: Styles.baseTextTheme.headline1.copyWith(
  //                 color: Theme.of(context).brightness == Brightness.dark
  //                     ? Colors.white
  //                     : Colors.black,
  //                 fontSize: 20,
  //               ),
  //             ),
  //             leading: !kIsWeb
  //                 ? MouseRegion(
  //               cursor: SystemMouseCursors.click,
  //               child: GestureDetector(
  //                   onTap: () {
  //                     controller.newsfeedController.isListOfBlockedAccounts = false;
  //                     controller.newsfeedController.isTranslations = false;
  //                     controller.newsfeedController.isLanguageSettings = true;
  //                     controller.newsfeedController.isLanguageType = false;
  //                     controller.newsfeedController.isListOfBlockedAccounts = false;
  //                     if (!kIsWeb) {
  //                       FocusManager.instance.primaryFocus
  //                           ?.unfocus();
  //                       Navigator.of(context).pop();
  //                     }
  //                     controller.update();
  //                   },
  //                   child: Icon(
  //                     Icons.arrow_back,
  //                     color: Theme.of(context).brightness ==
  //                         Brightness.dark
  //                         ? Colors.white
  //                         : Colors.black,
  //                   )),
  //             )
  //                 : SizedBox(),
  //           )
  //               : PreferredSize(
  //             child: Container(),
  //             preferredSize: Size(0, 0),
  //           ),
  //           body: Padding(
  //             padding: const EdgeInsets.only(left: 10, top: 20),
  //             child: SingleChildScrollView(
  //               child: Column(
  //                 crossAxisAlignment: CrossAxisAlignment.start,
  //                 children: [
  //                   kIsWeb
  //                       ? Row(
  //                     children: [
  //                       GestureDetector(
  //                         onTap: () {
  //                           controller.newsfeedController
  //                               .isListOfBlockedAccounts = false;
  //                           controller.newsfeedController.isTranslations = false;
  //                           controller.newsfeedController.isLanguageSettings = true;
  //                           controller.newsfeedController
  //                               .isSettingDetail = false;
  //                           controller.newsfeedController
  //                               .isSettingTypeDetail = false;
  //                           controller.newsfeedController.isLanguageType =
  //                           false;
  //                           controller.newsfeedController.isListOfBlockedAccounts = false;
  //                           controller.newsfeedController.isChangeUserName = false;
  //                           controller.newsfeedController.isYourAccount = false;
  //                           controller.newsfeedController.isYourWerfs = false;
  //                           controller.newsfeedController.isContentYouSee = false;
  //                           controller.newsfeedController. isSeePlacesYouHaveBeen = false;
  //
  //                           controller.newsfeedController.isLocationInformation = true;
  //
  //                           controller.newsfeedController.update();
  //                         },
  //                         child: Icon(
  //                           Icons.arrow_back,
  //                           color: Theme.of(context).brightness ==
  //                               Brightness.dark
  //                               ? Colors.white
  //                               : Colors.black,
  //                         ),
  //                       ),
  //                       Expanded(
  //                         child: Align(
  //                           alignment: Alignment.center,
  //                           child: Text(
  //                             Strings.seePlacesYouHaveBeen,
  //                             textAlign: TextAlign.left,
  //                             style:
  //                             Styles.baseTextTheme.headline1.copyWith(
  //                               color: Theme.of(context).brightness ==
  //                                   Brightness.dark
  //                                   ? Colors.white
  //                                   : Colors.black,
  //                             ),
  //
  //                           ),
  //                         ),
  //                       ),
  //                     ],
  //                   )
  //                       : Container(),
  //                   SizedBox(
  //                     height: 12,
  //                   ),
  //                   Text(
  //                     Strings.theseAreThePlacesWerfieUsesToShowYouMoreRelevantContentYouWontSeePlacesListedHereIfYouTurnedOffPersonalizeBasedOnPlacesYouHaveBeen,
  //                     textAlign: TextAlign.left,
  //                     style: Styles.baseTextTheme.subtitle1.copyWith(
  //                       color: Theme.of(context).brightness == Brightness.dark
  //                           ? Colors.white.withOpacity(0.5)
  //                           : Colors.black.withOpacity(0.5),
  //                     ),
  //                   ),
  //                   SizedBox(
  //                     height: 5,
  //                   ),
  //                   kIsWeb
  //                       ? Container(
  //                     height: 1,
  //                     color: Colors.grey[300],
  //                   )
  //                       : SizedBox(),
  //                   SizedBox(
  //                     height: 10,
  //                   ),
  //
  //                   // controller.newsfeedController.isBlockedUsersLoading
  //                   //     ? CircularProgressIndicator(
  //                   //   color: MyColors.BlueColor,
  //                   // )
  //                   //     : controller.newsfeedController.blockedUser == null
  //                   //     ? Center(
  //                   //   child: Text(Strings.youHaveNotMutedAnyPersonYet,
  //                   //       style: Styles.baseTextTheme.headline2.copyWith(
  //                   //         color: Theme.of(context).brightness ==
  //                   //             Brightness.dark
  //                   //             ? Colors.white
  //                   //             : Colors.black,
  //                   //         fontSize: 14,
  //                   //       )),
  //                   //
  //                   // )
  //                   //     :
  //
  //                   Expanded(
  //                     child: ListView.builder(
  //                       itemCount: controller.newsfeedController.blockedUser.length,
  //                       itemBuilder: (context, index) {
  //                         return  Padding(
  //                           padding: const EdgeInsets.only(left: 10,right: 10),
  //                           child: ListTile(
  //                               contentPadding: EdgeInsets.zero,
  //                               selected: true,
  //                               onTap: () {},
  //                           //     leading:Container(
  //                           //   height: 40,
  //                           //   width: 40,
  //                           //   decoration: BoxDecoration(
  //                           //       shape: BoxShape.circle,
  //                           //       border:Border.all(
  //                           //           color: Colors.grey.withOpacity(0.5)
  //                           //       )
  //                           //
  //                           //   ),
  //                           //   child: Icon(
  //                           //     Icons.location_on,
  //                           //     color:Theme.of(context).brightness == Brightness.dark
  //                           //         ? Colors.white
  //                           //         : Colors.black,
  //                           //     size: 20,
  //                           //   ),
  //                           // ) ,
  //                               title: Text(
  //                                 Strings.showContentInThisLocation,
  //                                 style: TextStyle(
  //                                   color: Theme.of(context).brightness == Brightness.dark
  //                                       ? Colors.white
  //                                       : Colors.black,
  //                                   fontSize: kIsWeb ? 16 : 14,
  //                                   fontWeight: FontWeight.w500,
  //                                 ),
  //                               ),
  //
  //
  //                           ),
  //                         );
  //                       },
  //                     ),
  //                   ),
  //
  //
  //
  //
  //                 ],
  //               ),
  //             ),
  //           ));
  //     },
  //   );
  // }
}

class EscIntent extends Intent {}
