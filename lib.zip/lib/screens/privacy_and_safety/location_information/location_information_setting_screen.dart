import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/explore_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/content_you_see/search_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/location_information/see_places_you_have_been_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/your_werfs/add_location_information_to_your_werfs_setting_screen.dart';

import '../../../utils/colors.dart';
import '../../../utils/fluro_router.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';
import '../../topic_screens/topic_tab_screen.dart';

class  LocationInformationSettingScreen extends StatelessWidget {
  LocationInformationSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
              backgroundColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              centerTitle: true,
              title: Text(
                Strings.locationInformation,
                style: Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 20,
                ),
              ),
              leading: !kIsWeb
                  ? MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                    onTap: () {
                      controller.newsfeedController.isListOfBlockedAccounts = false;
                      controller.newsfeedController.isTranslations = false;
                      controller.newsfeedController.isLanguageSettings = true;
                      controller.newsfeedController.isLanguageType = false;
                      controller.newsfeedController.isListOfBlockedAccounts = false;
                      if (!kIsWeb) {
                        FocusManager.instance.primaryFocus
                            ?.unfocus();
                        Navigator.of(context).pop();
                      }
                      controller.update();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
              )
                  : SizedBox(),
            )
                : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top:kIsWeb? 20:0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.newsfeedController
                                .isListOfBlockedAccounts = false;
                            controller.newsfeedController.isTranslations = false;
                            controller.newsfeedController.isLanguageSettings = true;
                            controller.newsfeedController
                                .isSettingDetail = false;
                            controller.newsfeedController
                                .isSettingTypeDetail = false;
                            controller.newsfeedController.isLanguageType =
                            false;
                            controller.newsfeedController.isListOfBlockedAccounts = false;
                            controller.newsfeedController.isChangeUserName = false;
                            controller.newsfeedController.isYourAccount = false;
                            controller.newsfeedController.isYourWerfs = false;
                            controller.newsfeedController.isContentYouSee = false;
                            controller.newsfeedController.isAccountPrivacy = true;

                            controller.newsfeedController.update();
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              Strings.locationInformation,
                              textAlign: TextAlign.left,
                              style:
                              Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),

                            ),
                          ),
                        ),
                      ],
                    )
                        : Container(),
                    SizedBox(
                      height: 12,
                    ),
                    Text(
                      Strings.manageTheLocationInformationWerfieUsesToPersonalizeYourExperience,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.subtitle1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white.withOpacity(0.5)
                            : Colors.black.withOpacity(0.5),
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),

                    ListTile(
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.personalizeBasedOnPlacesYouHaveBeen,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.werfieAlwaysUsesSomeInformationLikeWhereYouSignedUpAndYourCurrentLocationToHelpShowYouMoreRelevantContentWhenThisSettingIsEnabledWerfieMayAlsoPersonalizeYourExperienceBasedOnOtherPlacesYouHaveBeen,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                        trailing: Checkbox(
                            activeColor: controller.newsfeedController.displayColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5),
                            ),
                            value:controller.isAddLocationInformationToYourWerfs,
                            onChanged: (value) {
                              controller.isAddLocationInformationToYourWerfs = value;
                              controller.update();

                              if(value==true)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.isAddLocationInformationToYourWerfs==true?1:0,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );
                                controller.update();


                              }
                              else if(value==false)
                              {
                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                    whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.isAddLocationInformationToYourWerfs==true?1:0,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );
                                controller.update();

                              }


                            })
                    ),

                    // ListTile(
                    //   selected: true,
                    //   onTap: () {
                    //     controller.newsfeedController.isListOfBlockedAccounts = false;
                    //     controller.newsfeedController.isTranslations = false;
                    //     controller.newsfeedController.isLanguageSettings = false;
                    //     controller.newsfeedController.isLanguageType = false;
                    //     controller.newsfeedController.isAccountPrivacy = false;
                    //     controller.newsfeedController.isProfileLanguagetype = false;
                    //     controller.newsfeedController.isAccountPrivacySettings = false;
                    //     controller.newsfeedController.isChangeUserName = false;
                    //     controller.newsfeedController.isSettingDetail = false;
                    //     controller.newsfeedController.isAccountInformation = false;
                    //     controller.newsfeedController.isChangeUserName = false;
                    //     controller.newsfeedController.isChangeEmail = false;
                    //     controller.newsfeedController.isChangeCountry = false;
                    //     controller.newsfeedController.isSettinggender = false;
                    //     controller.newsfeedController.isYourAccount = false;
                    //     controller.newsfeedController.isAccountPrivacy = false;
                    //     controller.newsfeedController.isAudienceTagging= false;
                    //     controller.newsfeedController.isPhotoTagging = false;
                    //     controller.newsfeedController.isYourWerfs = false;
                    //     controller.newsfeedController.isAddLocationInformationToYourWerfs = false;
                    //
                    //     controller.newsfeedController.isSeePlacesYouHaveBeen = true;
                    //
                    //
                    //
                    //     // controller.isSettingTypeDetail = true;
                    //
                    //     controller.newsfeedController.update();
                    //     !kIsWeb
                    //         ? Navigator.push(
                    //         context,
                    //         MaterialPageRoute(
                    //             builder: (BuildContext context) =>
                    //                 SeePlacesYouHaveBeenSettingScreen()))
                    //         : Container();
                    //   },
                    //   title: Text(
                    //     Strings.seePlacesYouHaveBeen,
                    //     style: TextStyle(
                    //       color: Theme.of(context).brightness == Brightness.dark
                    //           ? Colors.white
                    //           : Colors.black,
                    //       fontSize: kIsWeb ? 16 : 14,
                    //       fontWeight: FontWeight.w500,
                    //     ),
                    //   ),
                    //   trailing: Icon(
                    //     Icons.arrow_forward_ios,
                    //     size: 20,
                    //     color: Theme.of(context).brightness == Brightness.dark
                    //         ? Colors.white
                    //         : MyColors.black,
                    //   ),
                    // ),

                    kIsWeb?
                    ListTile(
                      selected: true,
                      onTap: () {
                        controller.newsfeedController.isListOfBlockedAccounts = false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings = false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype = false;
                        controller.newsfeedController.isAccountPrivacySettings = false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation = false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isAudienceTagging= false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isYourWerfs = false;
                        controller.newsfeedController.isAddLocationInformationToYourWerfs = true;
                        controller.newsfeedController.isComingFromlocationScreen = true;



                        // controller.isSettingTypeDetail = true;

                        controller.newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    AddLocationInformationToYourWerfsSettingScreen()))
                            : Container();
                      },
                      title: Text(
                        Strings.addLocationInformationToYourWerfs,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 20,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : MyColors.black,
                      ),
                    ):SizedBox(),

                    ListTile(
                      selected: true,
                      onTap: () {

                        if(kIsWeb)
                          {

                            controller.isCountryScreen = false;
                            controller.update();
                            showDialog<String>(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10.0))),
                                    contentPadding: EdgeInsets.zero,
                                    content: ExploreSettingScreen(),
                                  );
                                });
                          }
                        else{
                          controller.isCountryScreen = false;
                          controller.update();
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      ExploreSettingScreen()));
                        }

                      },
                      title: Text(
                        Strings.exploreSettings,
                        style: TextStyle(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 20,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : MyColors.black,
                      ),
                    ),

                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
