import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import 'package:werfieapp/network/controller/settings_controller.dart';

import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/strings.dart';
import '../../../widgets/listtile_settings.dart';
import '../../account_info_setting_screen.dart';

class PhotoTaggingSettingScreen extends StatelessWidget {
  PhotoTaggingSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
              backgroundColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              centerTitle: true,
              title: Text(
                Strings.photoTagging,
                style: Styles.baseTextTheme.headline1.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontSize: 20,
                ),
              ),
              leading: !kIsWeb
                  ? MouseRegion(
                cursor: SystemMouseCursors.click,
                child: GestureDetector(
                    onTap: () {
                      controller.newsfeedController
                          .isListOfBlockedAccounts = false;
                      controller.newsfeedController.isTranslations =
                      false;
                      controller.newsfeedController
                          .isLanguageSettings = true;
                      controller.newsfeedController.isLanguageType =
                      false;
                      controller.newsfeedController
                          .isListOfBlockedAccounts = false;
                      if (!kIsWeb) {
                        FocusManager.instance.primaryFocus
                            ?.unfocus();
                        Navigator.of(context).pop();
                      }
                      controller.update();
                    },
                    child: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
              )
                  : SizedBox(),
            )
                : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
            body: Padding(
              padding: const EdgeInsets.only(left: 10, top: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.newsfeedController.isListOfBlockedAccounts = false;
                            controller.newsfeedController.isTranslations = false;
                            controller.newsfeedController.isLanguageSettings = false;
                            controller.newsfeedController.isLanguageType = false;
                            controller.newsfeedController.isAccountPrivacy = false;
                            controller.newsfeedController.isProfileLanguagetype = false;
                            controller.newsfeedController.isAccountPrivacySettings = false;
                            controller.newsfeedController.isChangeUserName = false;
                            controller.newsfeedController.isSettingDetail = false;
                            controller.newsfeedController.isAccountInformation = false;
                            controller.newsfeedController.isChangeUserName = false;
                            controller.newsfeedController.isChangeEmail = false;
                            controller.newsfeedController.isChangeCountry = false;
                            controller.newsfeedController.isSettinggender = false;
                            controller.newsfeedController.isYourAccount = false;
                            controller.newsfeedController.isAccountPrivacy = false;
                            controller.newsfeedController.isAudienceTagging= true;
                            controller.newsfeedController.isPhotoTagging = false;



                            // controller.isSettingTypeDetail = true;

                            controller..newsfeedController.update();
                            !kIsWeb
                                ? Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        accountInformationSettingScreen()))
                                : Container();
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        Expanded(
                          child: Align(
                            alignment: Alignment.center,
                            child: Text(
                              Strings.photoTagging,
                              textAlign: TextAlign.left,
                              style:
                              Styles.baseTextTheme.headline1.copyWith(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                              // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                              //     fontSize: 18,fontWeight: FontWeight.w700
                              // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                              //),
                              // style: Theme.of(context)
                              //     .textTheme
                              //     .headline6
                              //     .copyWith(
                              //       fontSize: 18,
                              //       fontWeight: FontWeight.w700,
                              //       color: Colors.black,
                              //     ),
                            ),
                          ),
                        ),
                      ],
                    )
                        : Container(),
                    SizedBox(
                      height: 10,
                    ),

                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),

                    ListTile(
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.photoTagging,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        subtitle: Text(
                          Strings.allowPeopleToTagYouIntheirPhotosAndReceiveNotificationWhenTheyDoSo,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black.withOpacity(0.5),
                            fontSize: 14,
                          ),
                        ),
                        trailing:   Switch(
                            value: controller.isPhotoTagging,
                            activeColor: controller.newsfeedController.displayColor,
                            onChanged: (value) async {
                              if(value==true)
                                {
                                  controller.isPhotoTagging=value;
                                  controller.isAnyoneCanTagYou=value;
                                  controller.update();

                                  controller.privacyAndSafetyApi(action: "update",
                                      protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                      allowPhotoTagging:controller.isPhotoTagging==true?1:0,
                                      whoCanPhotoTagYou:controller.privacyAndSafety.data.whoCanPhotoTagYou,
                                      markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                      addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                      displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                      exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                      exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                      searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                      searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                      directMessages:controller.privacyAndSafety.data.   directMessages,
                                      filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                      showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                      spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                      discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                      discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                      personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                      inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                      shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                      locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                  );


                                  controller.update();



                                }
                              else if(value==false)
                              {
                                controller.isPhotoTagging=value;
                                controller.isOnlyPeopleYouFollowCanTagYou=value;

                                controller.privacyAndSafetyApi(action: "update",
                                    protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                    allowPhotoTagging:controller.isPhotoTagging==true?1:0,
                                    whoCanPhotoTagYou:"anyone",
                                    markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                    addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                    displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                    exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                    exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                    searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                    searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                    directMessages:controller.privacyAndSafety.data.   directMessages,
                                    filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                    showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                    spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                    discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                    discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                    personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                    inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                    shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                    locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                );

                                controller.update();


                              }


                            }),
                    ),
                    kIsWeb
                        ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                        : SizedBox(),
                    SizedBox(
                      height: 5,
                    ),
                    controller.isPhotoTagging==true?
                    Column(
                      children: [
                        ListTile(
                            selected: true,
                            onTap: () {


                            },
                            title: Text(
                              Strings.AnyoneCanTagYou,
                              style: TextStyle(
                                color: Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: kIsWeb ? 16 : 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),

                            trailing: Checkbox(
                                activeColor: controller.newsfeedController.displayColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                value:controller.isAnyoneCanTagYou,
                                onChanged: (value) {

                                  if(value ==true )
                                    {
                                      controller.isAnyoneCanTagYou = value;
                                      controller.isOnlyPeopleYouFollowCanTagYou = false;
                                      controller.update();

                                      controller.privacyAndSafetyApi(action: "update",
                                          protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                          allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                          whoCanPhotoTagYou:"anyone",
                                          markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                          addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                          displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                          exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                          exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                          searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                          searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                          directMessages:controller.privacyAndSafety.data.   directMessages,
                                          filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                          showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                          spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                          discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                          discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                          personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                          inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                          shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                          locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                      );





                                    }
                                  controller.update();

                                })
                        ),
                        ListTile(
                            selected: true,
                            onTap: () {},
                            title: Text(
                              Strings.onlyPeopleYouFollowCanTagYou,
                              style: TextStyle(
                                color: Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: kIsWeb ? 16 : 14,
                                fontWeight: FontWeight.w500,
                              ),
                            ),

                            trailing: Checkbox(
                                activeColor: controller.newsfeedController.displayColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(100),
                                ),
                                value:controller.isOnlyPeopleYouFollowCanTagYou,
                                onChanged: (value) {


                                  if(value ==true )
                                  {
                                    controller.isAnyoneCanTagYou = false;
                                    controller.isOnlyPeopleYouFollowCanTagYou = value;
                                    controller.update();

                                    controller.privacyAndSafetyApi(action: "update",
                                        protectWerfs: controller.privacyAndSafety.data.protectWerfs,
                                        allowPhotoTagging:controller.privacyAndSafety.data.allowPhotoTagging,
                                        whoCanPhotoTagYou:"who_follows_you",
                                        markMediaSensitive:controller.privacyAndSafety.data.markMediaSensitive,
                                        addLocationToWerfs:controller.privacyAndSafety.data.addLocationToWerfs,
                                        displaySensitiveContentMedia:controller.privacyAndSafety.data.displaySensitiveContentMedia,
                                        exploreSettingsLocation:controller.privacyAndSafety.data.exploreSettingsLocation,
                                        exploreSettingsPersonalization:controller.privacyAndSafety.data. exploreSettingsPersonalization,
                                        searchSettingsHideSensitiveContent:controller.privacyAndSafety.data.searchSettingsHideSensitiveContent,
                                        searchSettingsRemoveBlockedAccounts:controller.privacyAndSafety.data. searchSettingsRemoveBlockedAccounts,
                                        directMessages:controller.privacyAndSafety.data.   directMessages,
                                        filterLowQualityMessages:controller.privacyAndSafety.data. filterLowQualityMessages,
                                        showReadReceipts:controller.privacyAndSafety.data.    showReadReceipts,
                                        spacesSettingAllowFollowers:controller.privacyAndSafety.data.  spacesSettingAllowFollowers,
                                        discoverSettingsEmail:controller.privacyAndSafety.data.discoverSettingsEmail,
                                        discoverSettingsPhone:controller.privacyAndSafety.data.discoverSettingsPhone,
                                        personalizedAdsSwitch:controller.privacyAndSafety.data.personalizedAdsSwitch,
                                        inferredIdentitySwitch:controller.privacyAndSafety.data.inferredIdentitySwitch,
                                        shareDataWithBusinessPartners:controller.privacyAndSafety.data.shareDataWithBusinessPartners,
                                        locationInfoYouHaveBeen:controller.privacyAndSafety.data.locationInfoYouHaveBeen
                                    );



                                  }
                                  controller.update();

                                })
                        ),
                      ],
                    ):SizedBox(),



                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
