import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/screens/privacy_and_safety/audience_and_tagging/audience_and_tagging_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/direct_messages/direct_messages_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/location_information/location_information_setting_screen.dart';
import 'package:werfieapp/screens/privacy_and_safety/your_werfs/your_werfs_setting_screen.dart';
import 'package:werfieapp/screens/reset_password_screen.dart';
import 'package:werfieapp/screens/session.dart';

import '../../components/input_password_field.dart';
import '../../network/controller/login_controller.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../utils/colors.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../widgets/deactivation.dart';
import '../../widgets/listtile_settings.dart';
import '../account_info_setting_screen.dart';
import '../change_password_screen.dart';
import '../login_screen.dart';
import 'content_you_see/content_you_see_setting_screen.dart';
import 'mute_and_block/mute_and_block_setting_screen.dart';

class PrivacyAndSafety extends StatelessWidget {
  PrivacyAndSafety({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
            appBar: !kIsWeb
                ? AppBar(
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    centerTitle: true,
                    title: Text(
                      Strings.privacyAndSafety,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 20,
                      ),
                      // TextStyle(
                      //     color: Colors.white,
                      //     fontSize: 18,
                      //     fontWeight: FontWeight.w700
                      // ),
                      // style: Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 18,
                      //   fontWeight: FontWeight.w700,
                      //   color: Colors.black,
                      // ),
                    ),
                    leading: !kIsWeb
                        ? MouseRegion(
                            cursor: SystemMouseCursors.click,
                            child: GestureDetector(
                                onTap: () {
                                  controller.newsfeedController
                                      .isListOfBlockedAccounts = false;
                                  controller.newsfeedController.isTranslations =
                                      false;
                                  controller.newsfeedController
                                      .isLanguageSettings = true;
                                  controller.newsfeedController.isLanguageType =
                                      false;
                                  controller.newsfeedController
                                      .isListOfBlockedAccounts = false;
                                  if (!kIsWeb) {
                                    FocusManager.instance.primaryFocus
                                        ?.unfocus();
                                    Navigator.of(context).pop();
                                  }
                                  controller.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                          )
                        : SizedBox(),
                  )
                : PreferredSize(
                    child: Container(),
                    preferredSize: Size(0, 0),
                  ),
            body:
            controller.isLoading ==true?
                Center(
                  child: CircularProgressIndicator(),
                ):
            Padding(
              padding: const EdgeInsets.only(left: 10, top:kIsWeb? 20:0),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 8.0,
                              horizontal: 12,
                            ),
                            child: Row(
                              children: [
                                MediaQuery.of(context).size.width >= 1050
                                    ? SizedBox()
                                    : MouseRegion(
                                        cursor: SystemMouseCursors.click,
                                        child: GestureDetector(
                                          onTap: () {
                                            controller.newsfeedController
                                                    .isListOfBlockedAccounts =
                                                false;
                                            controller.newsfeedController
                                                .isTranslations = false;
                                            controller.newsfeedController
                                                .isLanguageSettings = true;
                                            controller.newsfeedController
                                                .isSettingDetail = true;
                                            controller.newsfeedController
                                                .isSettingTypeDetail = false;
                                            controller.newsfeedController
                                                .isLanguageType = false;
                                            controller.newsfeedController
                                                    .isListOfBlockedAccounts =
                                                false;
                                            controller.newsfeedController
                                                .isChangeUserName = false;
                                            controller.newsfeedController
                                                .isYourAccount = false;

                                            controller.update();
                                          },
                                          child: Icon(
                                            Icons.arrow_back,
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                          ),
                                        ),
                                      ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      Strings.privacyAndSafety,
                                      textAlign: TextAlign.left,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                      //     fontSize: 18,fontWeight: FontWeight.w700
                                      // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                      //),
                                      // style: Theme.of(context)
                                      //     .textTheme
                                      //     .headline6
                                      //     .copyWith(
                                      //       fontSize: 18,
                                      //       fontWeight: FontWeight.w700,
                                      //       color: Colors.black,
                                      //     ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    kIsWeb?
                    Text(
                      Strings.manageWhatInformationYouSeeAndShareOnWerfie,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.subtitle1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white.withOpacity(0.5)
                            : Colors.black.withOpacity(0.5),
                      ),
                    ):SizedBox(),
                    SizedBox(
                      height: 5,
                    ),
                    kIsWeb
                        ? Container(
                            height: 1,
                            color: Colors.grey[300],
                          )
                        : SizedBox(),
                    SizedBox(
                      height: 10,
                    ),
                    Text(
                      Strings.yourWerfieActivity,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    ListTileSettings(
                      Strings.audienceAndTagging,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts =
                            false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings =
                            false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isAudienceTagging = true;
                        controller..newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        AudienceAndTaggingSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.yourWerfs,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts =
                            false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings =
                            false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isAudienceTagging = false;
                        controller.newsfeedController.isYourWerfs = true;

                        controller.newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        YourWerfsSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.contentYouSee,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts =
                            false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings =
                            false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isAudienceTagging = false;
                        controller.newsfeedController.isYourWerfs = false;
                        controller.newsfeedController.isContentYouSee = true;

                        // controller.isSettingTypeDetail = true;

                        controller.newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        ContentYouSeeSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.muteAndBlock,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts =
                            false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings =
                            false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isAudienceTagging = false;
                        controller.newsfeedController.isYourWerfs = false;
                        controller.newsfeedController.isContentYouSee = false;
                        controller.newsfeedController.isMuteAndBlock = true;



                        // controller.isSettingTypeDetail = true;

                        controller.newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        MuteAndBlockSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.directMessages,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts =
                            false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings =
                            false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isAudienceTagging = false;
                        controller.newsfeedController.isYourWerfs = false;
                        controller.newsfeedController.isContentYouSee = false;
                        controller.newsfeedController.isMuteAndBlock = false;
                        controller.newsfeedController.isDirectMessage = true;
                        controller.newsfeedController.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        DirectMessageSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    Container(
                            height: 1,
                            color: Colors.grey[300],
                          ),


                   !kIsWeb ?SizedBox(
                      height: 5,
                    ):SizedBox(),

                    Text(
                      Strings.dataSharingAndPersonalization,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    ListTileSettings(
                      Strings.locationInformation,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.newsfeedController.isComingFromlocationScreen = false;
                        controller.newsfeedController.isListOfBlockedAccounts = false;
                        controller.newsfeedController.isTranslations = false;
                        controller.newsfeedController.isLanguageSettings = false;
                        controller.newsfeedController.isLanguageType = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isProfileLanguagetype =
                            false;
                        controller.newsfeedController.isAccountPrivacySettings =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isSettingDetail = false;
                        controller.newsfeedController.isAccountInformation =
                            false;
                        controller.newsfeedController.isChangeUserName = false;
                        controller.newsfeedController.isChangeEmail = false;
                        controller.newsfeedController.isChangeCountry = false;
                        controller.newsfeedController.isSettinggender = false;
                        controller.newsfeedController.isYourAccount = false;
                        controller.newsfeedController.isAccountPrivacy = false;
                        controller.newsfeedController.isPhotoTagging = false;
                        controller.newsfeedController.isAudienceTagging = false;
                        controller.newsfeedController.isYourWerfs = false;
                        controller.newsfeedController.isContentYouSee = false;
                        controller.newsfeedController.isMuteAndBlock = false;
                        controller.newsfeedController.isDirectMessage = false;
                        controller.newsfeedController.isLocationInformation = true;
                        controller.newsfeedController.update();

                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        LocationInformationSettingScreen()))
                            : Container();
                      },
                      true,
                      FontWeight.w500,
                    ),
                    Container(
                            height: 1,
                            color: Colors.grey[300],
                          ),
                    !kIsWeb ?SizedBox(
          height: 5,
        ):SizedBox(),

                    Text(
                      Strings.LearnMoreAboutPrivacyOnWerfie,
                      textAlign: TextAlign.left,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    // ListTileSettings(
                    //   Strings.privacyCenter,
                    //     Icons.north_east,
                    //   () async {},
                    //   true,
                    //   FontWeight.w500,
                    // ),
                    ListTileSettings(
                      Strings.privacyPolicy,
                        Icons.north_east,
                      () async {
                        try {
                          var url = "https://api.werfie.com/privacy";
                          // if (await canLaunch(url))
                          await launch(url);
                          // else
                          // can't launch url, there is some error
                          // throw "Could not launch $url";
                          Navigator.pop(context);
                        } catch (e) {
                          // print(e.toString());
                        }
                      },
                      true,
                      FontWeight.w500,
                    ),
                    // ListTileSettings(
                    //   Strings.contactUs,
                    //   Icons.north_east,
                    //   () async {},
                    //   true,
                    //   FontWeight.w500,
                    // ),
                  ],
                ),
              ),
            ));
      },
    );
  }
}

class EscIntent extends Intent {}
