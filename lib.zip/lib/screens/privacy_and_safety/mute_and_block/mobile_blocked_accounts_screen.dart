import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/blocked_user.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../utils/colors.dart';
import '../../../utils/font.dart';

// ignore: must_be_immutable
class MobileBlockedAccountsScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();
  List<BlockedUser> _blockedUsers = [];

  // ignore: unused_element
  _fetchBlockedUsers() async {
    _blockedUsers = await controller.getBlockedUsersList();
    return _blockedUsers;
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.blockedAccountsSettings,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),

                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.isListOfBlockedAccounts = false;
                                controller.isTranslations = false;
                                controller.isLanguageSettings = true;
                                controller.isLanguageType = false;
                                controller.isListOfBlockedAccounts = false;
                                if (!kIsWeb) {
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Column(
            children: [
              kIsWeb
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 16.0,
                        horizontal: 12,
                      ),
                      child: Row(
                        children: [
                               GestureDetector(
                                 onTap: () {
                                   controller.isListOfBlockedAccounts = false;
                                   controller.isTranslations = false;
                                   controller.isLanguageSettings = false;
                                   controller.isSettingDetail = false;
                                   controller.isSettingTypeDetail = false;
                                   controller.isLanguageType = false;
                                   controller.isListOfBlockedAccounts = false;
                                   controller.isMuteAndBlock = true;
                                   controller.update();
                                 },
                                 child: Icon(
                                   Icons.arrow_back,
                                   color: Theme.of(context).brightness ==
                                           Brightness.dark
                                       ? Colors.white
                                       : Colors.black,
                                 ),
                               ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.blockedAccountsSettings,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                                // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                //     fontSize: 18,fontWeight: FontWeight.w700
                                // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                //),
                                // style: Theme.of(context)
                                //     .textTheme
                                //     .headline6
                                //     .copyWith(
                                //       fontSize: 18,
                                //       fontWeight: FontWeight.w700,
                                //       color: Colors.black,
                                //     ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : Container(),
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text(
                  Strings.whenYouBlockSomeoneThatPersonWontBeAbleToFollowOrMessageYouAndYouWontSeeNotificationFromThem,
                  textAlign: TextAlign.left,
                  style: Styles.baseTextTheme.subtitle1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.5)
                        : Colors.black.withOpacity(0.5),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),

              kIsWeb?
              Container(
                height: 1,
                color: Colors.grey[300],
              ):SizedBox(),
              SizedBox(height: 20),
              controller.isBlockedUsersLoading
                  ? CircularProgressIndicator(
                      color: MyColors.BlueColor,
                    )
                  : controller.blockedUser == null
                      ? Center(
                          child: Text(Strings.youHaveNotBlockedAnyPersonYet,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                              )),

                        )
                      : Expanded(
                          child: ListView.builder(
                            itemCount: controller.blockedUser.length,
                            itemBuilder: (context, index) {
                              return ListTile(
                                leading: CircleAvatar(
                                  backgroundImage: controller.blockedUser[index]
                                              .profileImage !=
                                          null
                                      ? NetworkImage(controller
                                          .blockedUser[index].profileImage)
                                      : AssetImage(
                                          "assets/images/person_placeholder.png"),
                                  radius: 22,
                                ),
                                title: Text(
                                  controller.blockedUser[index].username,
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),

                                ),
                                trailing: MaterialButton(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  padding: EdgeInsets.all(4),
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  onPressed: () async {
                                    controller.isBlockedUsersLoading = true;

                                    await controller.blockUser(
                                        controller.blockedUser[index].id);
                                    controller.fetchBlockedUsers();

                                    controller.update();
                                  },
                                  child: Text(
                                    Strings.unBlock,
                                    style:
                                        Styles.baseTextTheme.headline1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      fontSize: 14,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                    //     fontSize: 14,fontWeight: FontWeight.w700
                                    // ) : TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w700,
                                    //
                                    //
                                    // ),
                                    // style: TextStyle(
                                    //   fontSize: 14,
                                    //   color: Colors.white,
                                    // ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
            ],
          ),
        );
      },
    );
  }
}
