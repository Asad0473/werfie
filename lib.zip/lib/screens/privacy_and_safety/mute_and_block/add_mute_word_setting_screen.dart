import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/blocked_user.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../components/rounded_button.dart';
import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/utils_methods.dart';
import '../../../widgets/textformfield_screen.dart';

// ignore: must_be_immutable
class AddMutedWordsSettingScreen extends StatelessWidget {

  AddMutedWordsSettingScreen({Key key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
            backgroundColor:
            Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            centerTitle: true,
            title: Text(
              Strings. addMutedWords,
              style: Styles.baseTextTheme.headline1.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontSize: 16,
              ),

            ),
            leading: !kIsWeb
                ? MouseRegion(
              cursor: SystemMouseCursors.click,
              child: GestureDetector(
                  onTap: () {
                    controller.newsfeedController.isListOfBlockedAccounts = false;
                    controller.newsfeedController.isTranslations = false;
                    controller.newsfeedController.isLanguageSettings = true;
                    controller.newsfeedController.isLanguageType = false;
                    controller.newsfeedController.isMutedAccounts = false;
                    controller.newsfeedController.isMuteAndBlock = true;

                    if (!kIsWeb) {
                      Navigator.of(context).pop();
                    }
                    controller.update();
                  },
                  child: Icon(
                    Icons.arrow_back,
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  )),
            )
                : SizedBox(),
          )
              : PreferredSize(
            child: Container(),
            preferredSize: Size(0, 0),
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                kIsWeb
                    ? Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 16.0,
                    horizontal: 12,
                  ),
                  child: Row(
                    children: [

                      GestureDetector(
                        onTap: () {
                          controller.newsfeedController.isListOfBlockedAccounts = false;
                          controller.newsfeedController.isTranslations = false;
                          controller.newsfeedController.isLanguageSettings = false;
                          controller.newsfeedController.isLanguageType = false;
                          controller.newsfeedController.isMutedAccounts = false;
                          controller.newsfeedController.isMuteAndBlock = false;
                          controller.newsfeedController.isAddMuteWords = false;
                          controller.newsfeedController.isMuteWords = true;


                          controller.newsfeedController.update();
                        },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      Expanded(
                        child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            Strings.addMutedWords,
                            textAlign: TextAlign.left,
                            style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                  Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),

                          ),
                        ),
                      ),

                    ],
                  ),
                )
                    : Container(),

                !kIsWeb?
                SizedBox(
                  height: 10,
                ):SizedBox(),

                controller.action=="update"?
                Padding(
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  child: Container(
                    height: 50,
                    width: Get.width,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.black
                        : Color(0xffeff3f4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(Strings.mutedWord,
                            style: Styles.baseTextTheme.bodyText1.copyWith(
                              color: Theme.of(context).brightness ==
                                  Brightness.dark
                                  ? Colors.white
                                  : kIsWeb
                                  ? Colors.black.withOpacity(0.5)
                                  : Colors.black,
                            )),
                        Text(
                          "${controller.addMuteWordController.text}",
                          style:
                          Styles.baseTextTheme.bodyText1.copyWith(
                            color: Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.white
                                : kIsWeb
                                ? Colors.black.withOpacity(0.5)
                                : Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ):
                CustomFormField(
                  label: Strings.enterWordOrPhrase,
                  hintText: Strings.enterWordOrPhrase,
                  focusBorderColor: controller.newsfeedController.displayColor,
                  labelStyle: Styles.baseTextTheme.headline2.copyWith(
                    color: controller.newsfeedController.displayColor,
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                  ),
                  controller: controller.addMuteWordController,
                  maxline: 1,
                  minLine: 1,

                  onChange: (value) {
                    controller.update();
                  },

                ),


                SizedBox(
                  height: 12,
                ),


                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Text(
                    Strings.youCanMuteOneWordUsernameOrHashtagAtATime,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.subtitle1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white.withOpacity(0.5)
                          : Colors.black.withOpacity(0.5),
                    ),
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                Container(
                  height: 1,
                  color: Colors.grey[300],
                ),

                Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10,top:10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        Strings.muteFrom,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {},
                          title: Text(
                            Strings.homeTimeline,
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          trailing: Checkbox(
                              activeColor: controller.newsfeedController.displayColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(5),
                              ),
                              value:controller.isHomeTimeLine,
                              onChanged: (value) {
                                controller.isHomeTimeLine = value;
                                controller.update();
                              })
                      ),

                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        selected: true,
                        onTap: () {},
                        title: Text(
                          Strings.notifications,
                          style: TextStyle(
                            color: Theme.of(context).brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontSize: kIsWeb ? 16 : 14,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        trailing:   Switch(
                            value: controller.wordNotification,
                            activeColor: controller.newsfeedController.displayColor,
                            onChanged: (value) async {
                              if(value==true)
                              {
                                controller.wordNotification=value;
                                controller.isFromAnyone=value;

                                controller.update();



                              }
                              else if(value==false)
                              {
                                controller.wordNotification=value;
                                controller.isFromPeopleYouDontFollow=value;
                                controller.update();


                              }


                            }),
                      ),
                      kIsWeb
                          ? Container(
                        height: 1,
                        color: Colors.grey[300],
                      )
                          : SizedBox(),
                      SizedBox(
                        height: 5,
                      ),
                      controller.wordNotification==true?
                      Column(
                        children: [
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                              selected: true,
                              onTap: () {


                              },
                              title: Text(
                                Strings.fromAnyone,
                                style: TextStyle(
                                  color: Theme.of(context).brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 16 : 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),

                              trailing: Checkbox(
                                  activeColor: controller.newsfeedController.displayColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(100),
                                  ),
                                  value:controller.isFromAnyone,
                                  onChanged: (value) {

                                    if(value ==true )
                                    {
                                      controller.isFromAnyone= value;
                                      controller.isFromPeopleYouDontFollow = false;
                                      controller.update();
                                    }

                                  })
                          ),
                          ListTile(
                              contentPadding: EdgeInsets.zero,
                              selected: true,
                              onTap: () {},
                              title: Text(
                                Strings.fromPeopleYouDontFollow,
                                style: TextStyle(
                                  color: Theme.of(context).brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 16 : 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),

                              trailing: Checkbox(
                                  activeColor: controller.newsfeedController.displayColor,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(100),
                                  ),
                                  value:controller.isFromPeopleYouDontFollow,
                                  onChanged: (value) {


                                    if(value ==true )
                                    {
                                      controller.isFromAnyone = false;
                                      controller.isFromPeopleYouDontFollow = value;
                                      controller.update();
                                    }

                                  })
                          ),
                        ],
                      ):SizedBox(),
                      kIsWeb && controller.isPhotoTagging==true
                          ? Container(
                        height: 1,
                        color: Colors.grey[300],
                      )
                          : SizedBox(),

                      kIsWeb
                          ? Container(
                        height: 1,
                        color: Colors.grey[300],
                      )
                          : SizedBox(),

                      Text(
                        Strings.duration,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color:
                          Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {


                          },
                          title: Text(
                            Strings.untilYouUnmuteTheWord,
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          trailing: Checkbox(
                              activeColor: controller.newsfeedController.displayColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              ),
                              value:controller.isForever,
                              onChanged: (value) {

                                if(value ==true )
                                {
                                  controller.isForever = value;
                                  controller.is7days = false;
                                  controller.is30days = false;
                                  controller.is24Hours= false;
                                  controller.update();
                                }

                              })
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {},
                          title: Text(
                            Strings.hours24,
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          trailing: Checkbox(
                              activeColor: controller.newsfeedController.displayColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              ),
                              value: controller.is24Hours,
                              onChanged: (value) {


                                if(value ==true )
                                {
                                  controller.isForever = false;
                                  controller.is7days = false;
                                  controller.is30days = false;
                                  controller.is24Hours= value;
                                  controller.update();
                                }

                              })
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {


                          },
                          title: Text(
                            Strings.days7,
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          trailing: Checkbox(
                              activeColor: controller.newsfeedController.displayColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              ),
                              value:controller.is7days,
                              onChanged: (value) {

                                if(value ==true )
                                {
                                  controller.isForever = false;
                                  controller.is7days = value;
                                  controller.is30days = false;
                                  controller.is24Hours= false;
                                  controller.update();
                                }

                              })
                      ),
                      ListTile(
                          contentPadding: EdgeInsets.zero,
                          selected: true,
                          onTap: () {


                          },
                          title: Text(
                            Strings.days30,
                            style: TextStyle(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 16 : 14,
                              fontWeight: FontWeight.w500,
                            ),
                          ),

                          trailing: Checkbox(
                              activeColor: controller.newsfeedController.displayColor,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100),
                              ),
                              value:controller.is30days,
                              onChanged: (value) {

                                if(value ==true )
                                {
                                  controller.isForever = false;
                                  controller.is7days = false;
                                  controller.is30days = value;
                                  controller.is24Hours= false;
                                  controller.update();
                                }

                              })
                      ),
                      kIsWeb
                          ? Container(
                        height: 1,
                        color: Colors.grey[300],
                      )
                          : SizedBox(),

                      SizedBox(
                        height: 10,
                      ),

                      controller.action=="update"?
                      Align(
                        alignment: Alignment.centerRight,
                        child: RoundedButton(
                          Strings.save,
                              () async
                          {
                            if(controller.isHomeTimeLine==true)
                            {


                              controller.createAndMuteWordApi(
                                id:controller.muteWordId,
                                action:controller.action,
                                word:controller.addMuteWordController.text,
                                muteFromHome:controller.isHomeTimeLine==true?"1":"0",
                                notificationSwitch:controller.wordNotification==true?"1":"0",
                                notificationValue:controller.isFromAnyone==true?"anyone":controller.isFromPeopleYouDontFollow?"you_dont_follow":"anyone",
                                muteDuration:controller.isForever==true?"untillUnMute":controller.is30days==true?"30days":controller.is7days?"7days":controller.is24Hours==true?"24hours":"UntillUnMute",

                              ).whenComplete(() => {


                                UtilsMethods.toastMessageShow(
                                    controller.newsfeedController.displayColor,
                                    controller.newsfeedController.displayColor,
                                    controller.newsfeedController.displayColor,
                                    message: 'Updated ${controller.addMuteWordController.text}'),


                                controller.getMuteWordsList(),
                                controller.addMuteWordController.clear(),
                                controller.isHomeTimeLine = true,
                                controller.wordNotification=true,
                                controller.isForever=true,
                                if(kIsWeb)
                                  {
                                    controller.newsfeedController.isListOfBlockedAccounts = false,
                                    controller.newsfeedController.isTranslations = false,
                                    controller.newsfeedController.isLanguageSettings = false,
                                    controller.newsfeedController.isLanguageType = false,
                                    controller.newsfeedController.isMutedAccounts = false,
                                    controller.newsfeedController.isMuteAndBlock = false,
                                    controller.newsfeedController.isAddMuteWords = false,
                                    controller.newsfeedController.isMuteWords = true,


                                    controller.newsfeedController.update(),
                                  }
                                else{
                                  Navigator.pop(context),
                                }





                              });


                            }

                          },
                          horizontalPadding: 20.0,
                          verticalPadding: 10.00,
                          roundedButtonColor:controller.addMuteWordController.text.isNotEmpty && controller.isHomeTimeLine==true? controller.newsfeedController.displayColor:controller.newsfeedController.displayColor.withOpacity(0.5),
                        ),
                      ):
                      Align(
                        alignment: Alignment.centerRight,
                        child: RoundedButton(
                          Strings.save,
                              () async
                              {
                                if(controller.addMuteWordController.text.isNotEmpty && controller.isHomeTimeLine==true)
                                {


                                    controller.createAndMuteWordApi(
                                      action:controller.action,
                                      word:controller.addMuteWordController.text,
                                      muteFromHome:controller.isHomeTimeLine==true?"1":"0",
                                      notificationSwitch:controller.wordNotification==true?"1":"0",
                                      notificationValue:controller.isFromAnyone==true?"anyone":controller.isFromPeopleYouDontFollow?"you_dont_follow":"anyone",
                                      muteDuration:controller.isForever==true?"untillUnMute":controller.is30days==true?"30days":controller.is7days?"7days":controller.is24Hours==true?"24hours":"UntillUnMute",

                                    ).whenComplete(() => {


                                    UtilsMethods.toastMessageShow(
                                    controller.newsfeedController.displayColor,
                                    controller.newsfeedController.displayColor,
                                    controller.newsfeedController.displayColor,
                                    message: 'Muted Word ${controller.addMuteWordController.text} successfully!'),


                                      controller.getMuteWordsList(),
                                    controller.addMuteWordController.clear(),
                                    controller.isHomeTimeLine = true,
                                    controller.wordNotification=true,
                                    controller.isForever=true,
                                      if(kIsWeb)
                                        {
                                        controller.newsfeedController.isListOfBlockedAccounts = false,
                                        controller.newsfeedController.isTranslations = false,
                                        controller.newsfeedController.isLanguageSettings = false,
                                        controller.newsfeedController.isLanguageType = false,
                                        controller.newsfeedController.isMutedAccounts = false,
                                        controller.newsfeedController.isMuteAndBlock = false,
                                        controller.newsfeedController.isAddMuteWords = false,
                                        controller.newsfeedController.isMuteWords = true,


                                        controller.newsfeedController.update(),
                                        }
                                      else{
                                        Navigator.pop(context),
                                          }





                                    });


                                }

                              },
                          horizontalPadding: 20.0,
                          verticalPadding: 10.00,
                          roundedButtonColor:controller.addMuteWordController.text.isNotEmpty && controller.isHomeTimeLine==true? controller.newsfeedController.displayColor:controller.newsfeedController.displayColor.withOpacity(0.5),
                        ),
                      ),



                    ],
                  ),
                ),



                SizedBox(height: 20),

              ],
            ),
          ),
        );
      },
    );
  }
}