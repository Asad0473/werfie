import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/blocked_user.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/utils_methods.dart';

// ignore: must_be_immutable
class MuteAccountsSettingScreen extends StatelessWidget {
  MuteAccountsSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.mutedAccounts,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.newsfeedController
                                    .isListOfBlockedAccounts = false;
                                controller.newsfeedController.isTranslations =
                                    false;
                                controller.newsfeedController
                                    .isLanguageSettings = true;
                                controller.newsfeedController.isLanguageType =
                                    false;
                                controller.newsfeedController.isMutedAccounts =
                                    false;
                                controller.newsfeedController.isMuteAndBlock =
                                    true;

                                if (!kIsWeb) {
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              kIsWeb
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 16.0,
                        horizontal: 12,
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              controller.newsfeedController
                                  .isListOfBlockedAccounts = false;
                              controller.newsfeedController.isTranslations =
                                  false;
                              controller.newsfeedController.isLanguageSettings =
                                  true;
                              controller.newsfeedController.isLanguageType =
                                  false;
                              controller.newsfeedController.isMutedAccounts =
                                  false;
                              controller.newsfeedController.isMuteAndBlock =
                                  true;
                              controller.newsfeedController.update();
                            },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.mutedAccounts,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    )
                  : Container(),
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text(
                  Strings.HereEveryoneYouMutedYouCanAddRemoveThemFromThisList,
                  textAlign: TextAlign.left,
                  style: Styles.baseTextTheme.subtitle1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.5)
                        : Colors.black.withOpacity(0.5),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              kIsWeb
                  ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                  : SizedBox(),
              SizedBox(height: 20),
              controller.isLoading == true
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: MyColors.BlueColor,
                      ),
                    )
                  : controller.muteUserList == null
                      ? Center(
                          child: Text(Strings.youHaveNotMutedAnyPersonYet,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                              )),
                        )
                      : Expanded(
                          child: ListView.builder(
                            itemCount: controller.muteUserList.data.length,
                            itemBuilder: (context, index) {
                              //debugPrint('Muted User List ---->>> ${controller.muteUserList.data[index].username}');
                              //debugPrint('Muted User List Len---->>> ${controller.muteUserList.data.length}');
                              return ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage: controller.muteUserList
                                                .data[index].profileImage !=
                                            null
                                        ? NetworkImage(controller.muteUserList
                                            .data[index].profileImage)
                                        : const AssetImage(
                                            "assets/images/person_placeholder.png"),
                                    radius: 22,
                                  ),
                                  title: Text(
                                    controller
                                        .muteUserList.data[index].username,
                                    style:
                                        Styles.baseTextTheme.headline1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                    //     fontWeight: FontWeight.bold
                                    // ) : TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                    //
                                    //
                                    // ),
                                  ),
                                  trailing: InkWell(
                                    onTap: () {
                                      controller.newsfeedController
                                          .muteUnMute(
                                              postType: "post",
                                              userID: controller
                                                  .muteUserList.data[index].id)
                                          .whenComplete(() => {
                                                UtilsMethods.toastMessageShow(
                                                    controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    message:
                                                        "User Unmuted successfully"),
                                                controller.getMuteUsersList(),
                                              });
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 40,
                                      decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(
                                              color: Colors.grey
                                                  .withOpacity(0.5))),
                                      child: const Icon(
                                        Icons.volume_off,
                                        color: Colors.red,
                                        size: 20,
                                      ),
                                    ),
                                  ));
                            },
                          ),
                        ),
            ],
          ),
        );
      },
    );
  }
}
