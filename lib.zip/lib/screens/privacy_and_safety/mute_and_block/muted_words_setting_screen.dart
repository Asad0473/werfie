import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/blocked_user.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/settings_controller.dart';
import 'package:werfieapp/screens/privacy_and_safety/mute_and_block/add_mute_word_setting_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../../utils/colors.dart';
import '../../../utils/font.dart';
import '../../../utils/utils_methods.dart';

// ignore: must_be_immutable
class MutedWordsSettingScreen extends StatelessWidget {
  MutedWordsSettingScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.mutedWords,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.newsfeedController
                                    .isListOfBlockedAccounts = false;
                                controller.newsfeedController.isTranslations =
                                    false;
                                controller.newsfeedController
                                    .isLanguageSettings = true;
                                controller.newsfeedController.isLanguageType =
                                    false;
                                controller.newsfeedController.isMutedAccounts =
                                    false;
                                controller.newsfeedController.isMuteAndBlock =
                                    true;

                                if (!kIsWeb) {
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              kIsWeb
                  ? Padding(
                      padding: const EdgeInsets.symmetric(
                        vertical: 16.0,
                        horizontal: 12,
                      ),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              controller.newsfeedController
                                  .isListOfBlockedAccounts = false;
                              controller.newsfeedController.isTranslations =
                                  false;
                              controller.newsfeedController.isLanguageSettings =
                                  false;
                              controller.newsfeedController.isLanguageType =
                                  false;
                              controller.newsfeedController.isMutedAccounts =
                                  false;
                              controller.newsfeedController.isMuteWords = false;
                              controller.newsfeedController.isMuteAndBlock =
                                  true;
                              controller.newsfeedController.update();
                            },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                          Expanded(
                            child: Align(
                              alignment: Alignment.center,
                              child: Text(
                                Strings.mutedWords,
                                textAlign: TextAlign.left,
                                style: Styles.baseTextTheme.headline1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              controller.newsfeedController
                                  .isListOfBlockedAccounts = false;
                              controller.newsfeedController.isTranslations =
                                  false;
                              controller.newsfeedController.isLanguageSettings =
                                  false;
                              controller.newsfeedController.isLanguageType =
                                  false;
                              controller.newsfeedController.isMutedAccounts =
                                  false;
                              controller.newsfeedController.isMuteWords = false;
                              controller.newsfeedController.isMuteAndBlock =
                                  false;
                              controller.newsfeedController.isAddMuteWords =
                                  true;


                              controller.action ="insert";
                              controller.addMuteWordController.clear();
                              controller.isHomeTimeLine = true;
                              controller.wordNotification=true;
                              controller.isFromAnyone =false;
                              controller.isFromPeopleYouDontFollow=true;
                              controller.isForever=true;
                              controller.update();

                              controller.newsfeedController.update();
                            },
                            child: Icon(
                              Icons.add,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            ),
                          ),
                        ],
                      ),
                    )
                  : Container(),
              SizedBox(
                height: 12,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Text(
                  Strings
                      .whenYouMuteWordsYouWontGetAnyNewNotificationForWerfsThatIncludeThemOrSeeWerfsWithThoseWordsInYourHomeTimeline,
                  textAlign: TextAlign.left,
                  style: Styles.baseTextTheme.subtitle1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white.withOpacity(0.5)
                        : Colors.black.withOpacity(0.5),
                  ),
                ),
              ),
              SizedBox(
                height: 5,
              ),
              kIsWeb
                  ? Container(
                      height: 1,
                      color: Colors.grey[300],
                    )
                  : SizedBox(),
              SizedBox(height: 20),
              controller.isLoading
                  ? Center(
                    child: CircularProgressIndicator(
                        color: MyColors.BlueColor,
                      ),
                  )
                  : controller.muteWordList == null
                      ? Center(
                          child: Text(Strings.youHaveNotMutedAnyWordYet,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontSize: 14,
                              )),
                        )
                      : Expanded(
                          child: ListView.builder(
                            itemCount: controller.muteWordList.data.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding:
                                    const EdgeInsets.only(left: 10, right: 10),
                                child: ListTile(
                                    contentPadding: EdgeInsets.zero,
                                    selected: true,
                                    onTap: () {


                                      if(kIsWeb)
                                        {
                                          controller.newsfeedController.isListOfBlockedAccounts = false;
                                          controller.newsfeedController.isTranslations = false;
                                          controller.newsfeedController.isLanguageSettings =
                                          false;
                                          controller.newsfeedController.isLanguageType =
                                          false;
                                          controller.newsfeedController.isMutedAccounts =
                                          false;
                                          controller.newsfeedController.isMuteWords = false;
                                          controller.newsfeedController.isMuteAndBlock =
                                          false;
                                          controller.newsfeedController.isAddMuteWords =
                                          true;


                                          controller.action ="update";
                                          controller.addMuteWordController.text=controller.muteWordList.data[index].word;
                                          controller.isHomeTimeLine = true;
                                          controller.wordNotification=true;
                                         controller.isFromAnyone = controller.muteWordList.data[index].notificationValue=="anyone"?true:false;
                                         controller.isFromPeopleYouDontFollow= controller.muteWordList.data[index].notificationValue=="you_dont_follow"?true:false;
                                          controller.isForever= controller.muteWordList.data[index].muteDuration =="untillUnMute"?true:false;
                                      controller.is30days= controller.muteWordList.data[index].muteDuration =="30days"?true:false;
                                      controller.is7days= controller.muteWordList.data[index].muteDuration =="7days"?true:false;
                                      controller.is24Hours= controller.muteWordList.data[index].muteDuration =="24hours"?true:false;
                                      controller.muteWordId= controller.muteWordList.data[index].id;

                                          controller.update();

                                          controller.newsfeedController.update();
                                        }
                                      else{
                                        controller.action ="update";
                                        controller.addMuteWordController.text=controller.muteWordList.data[index].word;
                                        controller.isHomeTimeLine = true;
                                        controller.wordNotification=true;
                                        controller.isFromAnyone = controller.muteWordList.data[index].notificationValue=="anyone"?true:false;
                                        controller.isFromPeopleYouDontFollow= controller.muteWordList.data[index].notificationValue=="you_dont_follow"?true:false;
                                        controller.isForever= controller.muteWordList.data[index].muteDuration =="untillUnMute"?true:false;
                                        controller.is30days= controller.muteWordList.data[index].muteDuration =="30days"?true:false;
                                        controller.is7days= controller.muteWordList.data[index].muteDuration =="7days"?true:false;
                                        controller.is24Hours= controller.muteWordList.data[index].muteDuration =="24hours"?true:false;
                                        controller.muteWordId= controller.muteWordList.data[index].id;
                                        controller.update();
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                AddMutedWordsSettingScreen(),
                                          ),
                                        );

                                      }


                                    },
                                    title: Text(
                                      controller.muteWordList.data[index].word,
                                      style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb ? 16 : 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    subtitle:
                                    controller.muteWordList.data[index].muteDuration=="untillUnMute"?
                                    Text(
                                      "Forever",
                                      style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black.withOpacity(0.5),
                                        fontSize: 14,
                                      ),
                                    ):
                                    Text(
                                      controller.muteWordList.data[index].muteDuration,
                                      style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black.withOpacity(0.5),
                                        fontSize: 14,
                                      ),
                                    ),
                                    trailing: InkWell(
                                      onTap: (){

                                        UtilsMethods.toastMessageShow(
                                            controller.newsfeedController.displayColor,
                                            controller.newsfeedController.displayColor,
                                            controller.newsfeedController.displayColor,
                                            message: 'Unmuted Word ${controller.muteWordList.data[index].word} successfully!');
                                        controller.unMuteWord(muteWordID: controller.muteWordList.data[index].id).whenComplete(() => {
                                          controller.getMuteWordsList(),
                                        });



                                      },
                                      child: Container(
                                        height: 40,
                                        width: 40,
                                        decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                                color: Colors.grey
                                                    .withOpacity(0.5))),
                                        child: Icon(
                                          Icons.volume_off,
                                          color: Colors.red,
                                          size: 20,
                                        ),
                                      ),
                                    )

                                ),
                              );
                            },
                          ),
                        ),
            ],
          ),
          floatingActionButton: kIsWeb
              ? SizedBox()
              : FloatingActionButton(
                  heroTag: UniqueKey(),
                  onPressed: () {
                    controller.action ="insert";
                    controller.addMuteWordController.clear();
                    controller.isHomeTimeLine = true;
                    controller.wordNotification=true;
                    controller.isForever=true;
                    controller.isFromAnyone =false;
                    controller.isFromPeopleYouDontFollow=true;
                    controller.update();
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (BuildContext context) =>
                            AddMutedWordsSettingScreen(),
                      ),
                    );
                  },
                  backgroundColor: controller.newsfeedController.displayColor,
                  child: Icon(
                    Icons.add,
                    color: Colors.white,
                  ),
                ),
        );
      },
    );
  }
}
