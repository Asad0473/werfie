import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/search_filters_dialog.dart';

import '../models/profile.dart';
import '../network/controller/other_users_controller.dart';
import '../network/singleTone.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../widgets/thread_post_card.dart';

class FilteredScreen extends StatefulWidget {
  final NewsfeedController newsfeedController;

  FilteredScreen({this.newsfeedController});

  @override
  State<FilteredScreen> createState() => _FilteredScreenState();
}

class _FilteredScreenState extends State<FilteredScreen> {
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  Future<void> searchData() async {
    // widget.newsfeedController.isFilter=true;

    /* await widget.newsfeedController.filterUsers(
       id: 0.toString(),
       type: "tag",
       tag: widget.newsfeedController.tagText,
       isFromRoute: true
     // id: id,
     // type: controller.searchResult[0].type,
   );*/
// if(SingleTone.instance.searchTag!=null && SingleTone.instance.searchTag.isNotEmpty && SingleTone.instance.searchTag !="null") {
    if (SingleTone.instance.isSearch == "true") {
      print("if true");

      await widget.newsfeedController.onSearchTextChanged(
          SingleTone.instance.searchTag ?? "",
          isSearchBar: false,
          isFromRoute: true);
      widget.newsfeedController.searchSelected =
          widget.newsfeedController.searchResult[0];
      widget.newsfeedController.searchSelected.id = 0;
      widget.newsfeedController.searchSelected.type = "tag";
    }
    print("filters screen " + SingleTone.instance.searchId.toString());
    print("filters screen " + SingleTone.instance.searchType.toString());
    print("filters screen " + SingleTone.instance.searchTag.toString());
    print("filters screen " + SingleTone.instance.isSearch.toString());

    await widget.newsfeedController.filterUsers(
        id: SingleTone.instance.searchId,
        type: SingleTone.instance.searchType,
        tag: SingleTone.instance.searchTag,
        isFromRoute: true
        // id: id,
        // type: controller.searchResult[0].type,
        );

    widget.newsfeedController.update();
    // widget.newsfeedController.wait = true;
    // widget.newsfeedController.isSearch = false;
    // widget.newsfeedController.searchResult = [];
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    debugPrint("filtered screen");
    // WidgetsBinding.instance.addPostFrameCallback((_) {

    searchData();
    // });

    // searchData();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        debugPrint("filter back called");

        widget.newsfeedController.update();

        return true;
      },
      child: Scaffold(
        key: scaffoldKey,
        body: Responsive(
          mobile: FilterScreen(
              // controller: controller,
              ),
          tablet: FilterScreen(
              // controller: controller,
              ),
          desktop: FilterScreen(
              // controller: controller,
              ),
        ),
      ),
    );
  }
}

class FilterScreen extends StatelessWidget {
  // NewsfeedController controller;
  // FilterScreen({this.controller});
  final controller = Get.find<NewsfeedController>();
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return Scaffold(
        appBar: !kIsWeb
            ? AppBar(
                backgroundColor: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                iconTheme: const IconThemeData(
                  color: Colors.black, //change your color here
                ),
                title: Text(
                  Strings.trendingUpdates,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                actions: [
                  IconButton(
                    onPressed: () {
                      showDialog(
                          context: context,
                          builder: (context) {
                            return Dialog(
                              child: SearchFilterDialog(controller),
                            );
                          });
                    },
                    icon: const Icon(
                      Icons.filter_alt_sharp,
                      color: Color(0xFFedab30),
                    ),
                  ),
                ],
              )
            : PreferredSize(
                preferredSize: Size(0.0, 0.0),
                child: Container(),
              ),
        body: controller.wait
            ? const Center(
                child: CircularProgressIndicator(
                color: MyColors.BlueColor,
              ))
            : Stack(
                alignment: Alignment.topCenter,
                children: [
                  Column(
                    children: [
                      kIsWeb
                          ? Row(
                              children: [
                                IconButton(
                                  // splashColor: Colors.white,
                                  // hoverColor: Colors.grey[100],
                                  icon: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                  onPressed: kIsWeb
                                      ? () {
                                          Get.back();

                                          controller.searchText.text = '';
                                          controller.searchResult = [];
                                          controller.isFilterScreen = false;
                                          controller.isFilter = false;

                                          switch (controller.navRoute) {
                                            case "isPostDetails":
                                              {
                                                controller.isPostDetails = true;
                                                controller.update();
                                              }
                                              break;
                                            case "isProfileScreen":
                                              {
                                                controller.isProfileScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;
                                            case "isNewsFeedScreen":
                                              {
                                                controller.isFilterScreen =
                                                    false;
                                                controller.isNewsFeedScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;

                                            case "isTrendsScreen":
                                              {
                                                controller.isTrendsScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;

                                            case "isQuestScreen":
                                              {
                                                controller.isBrowseScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;

                                            case "isSavedPostScreen":
                                              {
                                                controller.isSavedPostScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;
                                            case "isNotificationScreen":
                                              {
                                                controller.isTrendsScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;
                                            case "isChatScreen":
                                              {
                                                controller
                                                        .isNotificationScreen =
                                                    true;
                                                controller.update();
                                              }
                                              break;

                                            default:
                                              {
                                                print("Invalid choice");
                                              }
                                              break;
                                          }
                                          controller.update();
                                        }
                                      : () {
                                          Navigator.of(context).pop();
                                        },
                                ),
                                const SizedBox(width: 30),
                                Text(
                                  Strings.filteredResult,
                                  style:
                                      Styles.baseTextTheme.headline2.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            )
                          : Container(),
                      const SizedBox(
                        height: 30,
                      ),
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: ListView(
                          shrinkWrap: true,
                          scrollDirection: Axis.horizontal,
                          physics: kIsWeb
                              ? const NeverScrollableScrollPhysics()
                              : const ScrollPhysics(),
                          children: [
                            TabButton(
                              title: Strings.top,
                              onTap: () {
                                controller.topTab = true;
                                controller.peopleTab = false;
                                controller.photosTab = false;
                                controller.lattestTab = false;
                                controller.videosTab = false;
                                controller.filesTab = false;
                                controller.seletedTab = "top";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();
                                SingleTone.instance.searchType = "user";
                                SingleTone.instance.searchTab =
                                    controller.seletedTab;
                                SingleTone.instance.searchTag =
                                    controller.tagText;

                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                controller.filterUsers(
                                  id: SingleTone.instance.searchId,
                                  type: "user",
                                  tag: SingleTone.instance.searchTag,
                                );
                                controller.update();
                              },
                              isSelected: controller.topTab,
                            ),
                            TabButton(
                              title: Strings.latest,
                              onTap: () {
                                controller.topTab = false;
                                controller.peopleTab = false;
                                controller.photosTab = false;
                                controller.lattestTab = true;
                                controller.videosTab = false;
                                controller.filesTab = false;
                                controller.seletedTab = "latest";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();
                                SingleTone.instance.searchType = "user";
                                SingleTone.instance.searchTag =
                                    controller.tagText;
                                SingleTone.instance.searchTab =
                                    controller.seletedTab;
                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                controller.filterUsers(
                                    id: SingleTone.instance.searchId,
                                    type: "user",
                                    tag: SingleTone.instance.searchTag);
                                controller.update();
                              },
                              isSelected: controller.lattestTab,
                            ),
                            TabButton(
                              title: Strings.people,
                              onTap: () {
                                controller.topTab = false;
                                controller.peopleTab = true;
                                controller.photosTab = false;
                                controller.lattestTab = false;
                                controller.videosTab = false;
                                controller.filesTab = false;
                                controller.seletedTab = "people";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();

                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                print(
                                    "SingleTone.instance.searchId ${SingleTone.instance.searchId}");
                                print(
                                    "SingleTone.instance.searchId ${SingleTone.instance.searchType}");
                                print(
                                    "SingleTone.instance.searchId ${controller.seletedTab}");

                                controller.filterUsers(
                                  id: SingleTone.instance.searchId,
                                  type: "user",
                                );
                                controller.update();
                              },
                              isSelected: controller.peopleTab,
                            ),
                            TabButton(
                              title: Strings.photos,
                              onTap: () {
                                controller.topTab = false;
                                controller.peopleTab = false;
                                controller.photosTab = true;
                                controller.lattestTab = false;
                                controller.videosTab = false;
                                controller.filesTab = false;
                                controller.seletedTab = "photos";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();
                                SingleTone.instance.searchType = "user";
                                SingleTone.instance.searchTag =
                                    controller.tagText;
                                SingleTone.instance.searchTab =
                                    controller.seletedTab;
                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                controller.filterUsers(
                                    id: SingleTone.instance.searchId,
                                    type: SingleTone.instance.searchType,
                                    tag: SingleTone.instance.searchTag);
                                controller.update();
                              },
                              isSelected: controller.photosTab,
                            ),
                            TabButton(
                              title: Strings.videos,
                              onTap: () {
                                controller.topTab = false;
                                controller.peopleTab = false;
                                controller.photosTab = false;
                                controller.lattestTab = false;
                                controller.videosTab = true;
                                controller.filesTab = false;
                                controller.seletedTab = "videos";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();
                                SingleTone.instance.searchType = "user";
                                SingleTone.instance.searchTag =
                                    controller.tagText;
                                SingleTone.instance.searchTab =
                                    controller.seletedTab;
                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                controller.filterUsers(
                                    id: SingleTone.instance.searchId,
                                    type: "user",
                                    tag: SingleTone.instance.searchTag);
                                controller.update();
                              },
                              isSelected: controller.videosTab,
                            ),
                            TabButton(
                              title: Strings.files,
                              onTap: () {
                                controller.topTab = false;
                                controller.peopleTab = false;
                                controller.photosTab = false;
                                controller.lattestTab = false;
                                controller.videosTab = false;
                                controller.filesTab = true;
                                controller.seletedTab = "files";
                                controller.update();

                                SingleTone.instance.searchId =
                                    controller.postUserId.toString();
                                SingleTone.instance.searchType = "user";
                                SingleTone.instance.searchTag =
                                    controller.tagText;
                                SingleTone.instance.searchTab =
                                    controller.seletedTab;
                                // Get.offNamed(FluroRouters.mainScreen +
                                //     "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");

                                controller.filterUsers(
                                    id: SingleTone.instance.searchId,
                                    type: "user",
                                    tag: SingleTone.instance.searchTag);
                                controller.update();
                              },
                              isSelected: controller.filesTab,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      Expanded(
                        child:

                        Container(
                          // height: Get.height/1.3,
                          child: !controller.peopleTab == true &&
                                  !controller.isFilter &&
                                  controller.filteredPost.isNotEmpty
                              ? PagedL(
                                  emptyStateWidget:
                                  const Center(
                                      child: CircularProgressIndicator(
                                        color: MyColors.BlueColor,
                                      )),
                                  // Text(Strings.noPosts),
                                  itemBuilder: _itemRow,
                                  padding: const EdgeInsets.only(
                                      top: 16.00, left: 0.00, right: 0.00),
                                  loadingIndicator: const Padding(
                                    padding: EdgeInsets.all(10.00),
                                    child: Center(
                                        child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                        MyColors.BlueColor,
                                      ),
                                    )
                                        // Container(
                                        //     color: Colors.grey[200],
                                        //     // margin: EdgeInsets.all(10),
                                        //     height: 320,
                                        //     child: buildPostShimmer(
                                        //         context)),
                                        ),
                                  ),
                                  itemDataProvider: _fetchData,
                                  list: controller.filteredPost,
                                  listSize: _checkPage(
                                      controller.filteredPost.length),
                                )
                         : controller?.isFilter == true
                              ? const Center(
                              child: CircularProgressIndicator(
                                color: MyColors.BlueColor,
                              ))
                              :  kIsWeb && controller.filteredPost.isEmpty && controller.filesTab == true
                              ? Center(
                              child: Text(
                                Strings.nothingFound,
                                style: Styles.baseTextTheme.headline4
                                    .copyWith(
                                  color:
                                  Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 14 : 12,
                                ),
                              ))
                              :  kIsWeb && controller.filteredPost.isEmpty && !controller.peopleTab == true
                              ? const Center(
                              child: CircularProgressIndicator(
                                color: MyColors.BlueColor,
                              ))
                              :  controller.filteredPost.isEmpty && !controller.peopleTab == true
                              ? Center(
                              child: Text(
                                Strings.nothingFound,
                                style: Styles.baseTextTheme.headline4
                                    .copyWith(
                                  color:
                                  Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontSize: kIsWeb ? 14 : 12,
                                ),
                              ))
                              :  kIsWeb && controller.filteredPeople.isEmpty&& controller.peopleTab == true
                              ? const Center(
                              child: CircularProgressIndicator(
                                color: MyColors.BlueColor,
                              ))
                                  :  controller.filteredPeople.isEmpty && controller.peopleTab == true
                                      ? Center(
                                          child: Text(
                                          Strings.nothingFound,
                                          style: Styles.baseTextTheme.headline4
                                              .copyWith(
                                            color:
                                                Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                            fontSize: kIsWeb ? 14 : 12,
                                          ),
                                        ))

                                      : SingleChildScrollView(
                                          child: Column(
                                            ///peopleTab
                                            children: List.generate(
                                                controller.filteredPeople
                                                    .length, (index) {
                                              return InkWell(
                                                onTap: kIsWeb
                                                    ? () async {
                                                        controller
                                                                .isTrendsScreen =
                                                            false;
                                                        controller
                                                                .isNewsFeedScreen =
                                                            false;
                                                        controller
                                                                .isBrowseScreen =
                                                            false;
                                                        controller
                                                                .isNotificationScreen =
                                                            false;
                                                        controller
                                                                .isChatScreen =
                                                            false;
                                                        controller
                                                                .isSavedPostScreen =
                                                            false;
                                                        controller
                                                                .isPostDetails =
                                                            false;
                                                        controller
                                                                .isProfileScreen =
                                                            false;
                                                        controller
                                                                .isOtherUserProfileScreen =
                                                            true;
                                                        controller
                                                                .isFilterScreen =
                                                            false;
                                                        controller
                                                                .otherUserName =
                                                            controller
                                                                .filteredPeople[
                                                                    index]
                                                                .authorName;
                                                        controller.otherUserId =
                                                            controller
                                                                .filteredPeople[
                                                                    index]
                                                                .userId;

                                                        Get.toNamed(FluroRouters
                                                                .mainScreen +
                                                            "/profile/" +
                                                            controller
                                                                .filteredPeople[
                                                                    index]
                                                                .userId
                                                                .toString());
                                                        Get.put(
                                                            OtherUserController());
                                                        Get.find<NewsfeedController>()
                                                                .userInfo =
                                                            UserProfile();
                                                        Get.find<NewsfeedController>()
                                                                .userInfo =
                                                            await controller
                                                                .getOtherUserProfile(
                                                                    controller
                                                                        .filteredPeople[
                                                                            index]
                                                                        .userId);
                                                        await Get.find<
                                                                OtherUserController>()
                                                            .filterUsersPostPagged(
                                                                "posts",
                                                                page: 1);
                                                        Get.find<
                                                                OtherUserController>()
                                                            .userPosts[0]
                                                            .mute = Get.find<
                                                                NewsfeedController>()
                                                            .userInfo
                                                            .muted;
                                                        Get.find<
                                                                OtherUserController>()
                                                            .userPosts
                                                            .forEach((element) {
                                                          element
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;
                                                          print(
                                                              "element.mute  ${element.mute}");
                                                        });

                                                        controller.update();
                                                      }
                                                    : () async {
                                                        controller.otherUserId =
                                                            controller
                                                                .filteredPeople[
                                                                    index]
                                                                .userId;
                                                        Get.find<NewsfeedController>()
                                                                .userInfo =
                                                            UserProfile();
                                                        print(
                                                            "controller.filteredPeople[index].userId ${controller.filteredPeople[index].userId}");

                                                        controller.update();

                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                                builder:
                                                                    (BuildContextcontext) =>
                                                                        OtherUsersProfile(
                                                                          controller:
                                                                              controller,
                                                                        )));

                                                        Get.find<NewsfeedController>()
                                                                .userInfo =
                                                            await controller
                                                                .getOtherUserProfile(
                                                                    controller
                                                                        .filteredPeople[
                                                                            index]
                                                                        .userId);

                                                        await Get.find<
                                                                OtherUserController>()
                                                            .filterUsersPostPagged(
                                                                "posts",
                                                                page: 1);
                                                        Get.find<
                                                                OtherUserController>()
                                                            .userPosts
                                                            .forEach((element) {
                                                          element
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;
                                                        });
                                                        Get.find<
                                                                OtherUserController>()
                                                            .update();

                                                        controller.update();
                                                      },
                                                child: Container(
                                                  width: Get.width,
                                                  margin: const EdgeInsets.only(
                                                      bottom: 5,
                                                      left: 10,
                                                      right: 10),
                                                  padding: const EdgeInsets.all(8.0),
                                                  color: Colors.grey
                                                      .withOpacity(0.05),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage: controller
                                                                    .filteredPeople[
                                                                        index]
                                                                    .profileImage !=
                                                                null
                                                            ? NetworkImage(controller
                                                                .filteredPeople[
                                                                    index]
                                                                .profileImage)
                                                            : const AssetImage(
                                                                "assets/images/person_placeholder.png"),
                                                        radius: 18,
                                                      ),
                                                      const SizedBox(
                                                        width: 20,
                                                      ),
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Row(
                                                            children: [
                                                               Text(
                                                                controller.filteredPeople[index].authorName,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  color: Theme.of(context)
                                                                              .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                      ? Colors
                                                                          .white
                                                                      : Colors
                                                                          .black,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                  fontSize: 14,
                                                                ),
                                                              ),
                                                              controller.filteredPeople[index]
                                                                          .accountVerified ==
                                                                      "verified"
                                                                  ? Wrap(
                                                                      children: [
                                                                        const SizedBox(
                                                                          width:
                                                                              5,
                                                                        ),
                                                                        BlueTick(
                                                                          height:
                                                                              15,
                                                                          width:
                                                                              15,
                                                                          iconSize:
                                                                              12,
                                                                        ),
                                                                      ],
                                                                    )
                                                                  : SizedBox()
                                                            ],
                                                          ),
                                                          Text(
                                                            "@${controller.filteredPeople[index].username}",
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      // Spacer(),
                                                      // MaterialButton(
                                                      //     color: controller
                                                      //                 .filteredPeople[
                                                      //                     index]
                                                      //                 .following !=
                                                      //             null
                                                      //         ? controller
                                                      //                 .filteredPeople[
                                                      //                     index]
                                                      //                 .following
                                                      //             ? Colors.blueAccent
                                                      //             : Colors.white
                                                      //         : Colors.white,
                                                      //     onPressed: () {},
                                                      //     child: Text(
                                                      //       controller
                                                      //                   .filteredPeople[
                                                      //                       index]
                                                      //                   .following !=
                                                      //               null
                                                      //           ? controller
                                                      //                   .filteredPeople[
                                                      //                       index]
                                                      //                   .following
                                                      //               ? Strings.following
                                                      //               : Strings.follow
                                                      //           : Strings.follow,
                                                      //       style: TextStyle(
                                                      //         color: controller
                                                      //                     .filteredPeople[
                                                      //                         index]
                                                      //                     .following !=
                                                      //                 null
                                                      //             ? controller
                                                      //                     .filteredPeople[
                                                      //                         index]
                                                      //                     .following
                                                      //                 ? Colors.white
                                                      //                 : Colors
                                                      //                     .blueAccent
                                                      //             : Colors.blueAccent,
                                                      //       ),
                                                      //     ),
                                                      //     shape: RoundedRectangleBorder(
                                                      //         borderRadius:
                                                      //             BorderRadius.circular(
                                                      //                 20),
                                                      //         side: BorderSide(
                                                      //           color: controller
                                                      //                       .filteredPeople[
                                                      //                           index]
                                                      //                       .following !=
                                                      //                   null
                                                      //               ? controller
                                                      //                       .filteredPeople[
                                                      //                           index]
                                                      //                       .following
                                                      //                   ? Colors.white
                                                      //                   : Colors
                                                      //                       .blueAccent
                                                      //               : Colors.blueAccent,
                                                      //         ))),
                                                    ],
                                                  ),
                                                ),
                                              );
                                            }),
                                          ),
                                        ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
      );
    });
  }

  Widget _itemRow(BuildContext context, Post post) {
    int index = controller.filteredPost.indexWhere((element) {
      return element.postId == post.postId;
    });
    return controller.filteredPost[index].type == 'thread'
        ? ThreadPostCard(
            postList: controller.filteredPost,
            index: index,
            post: controller.filteredPost[index],
            scaffoldKey: _scaffoldKey,
            controller: controller,
            // deletePostId: 5,
          )
        : PostCard(
            postList: controller.filteredPost,
            post: controller?.filteredPost[index],
            scaffoldKey: _scaffoldKey,
            index: index,
            controller: controller,
            deletePostId: 5,
          );
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    // printInfo(info: 'ghfgfhhj' + page.toString());
    return await controller.filterUsersPagged(
      pageNo: page,
      id: controller.searchSelected.id,
      type: controller.searchSelected.type,
      tag: controller.searchText.text.isNotEmpty
          ? controller.searchText.text
          : null,
    );
  }

// Widget buildPostShimmer(BuildContext context) => ListTile(
//       //Shimmer for Profile Photo
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           //Shimmer for username
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 20),
//           //Shimmer for post text
//           CustomShimmerWidget.rectangular(
//             height: 210,
//           ),
//           SizedBox(height: 20),
//           //Shimmer for reaction row
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               //  SizedBox(width: 16),
//             ],
//           ),
//           SizedBox(height: 16),
//         ],
//       ),
//       // trailing: SizedBox(),
//       // subtitle: CustomShimmerWidget.rectangular(
//       //     height: 14, width: MediaQuery.of(context).size.width * 0.3),
//     );
}

class TabButton extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  TabButton({this.title, this.isSelected, this.onTap});

  final controller = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onTap,
      child: Column(
        children: [
          // Text(
          //   title,
          //   style: TextStyle(
          //       fontWeight: FontWeight.bold,
          //       color: isSelected ? Color(0xFFedab30) : Theme.of(context).brightness == Brightness.dark ?Colors.white: Colors.black),
          // ),
          // SizedBox(
          //   height: 5,
          // ),
          isSelected
              ? FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 18 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    //   fontWeight: FontWeight.bold,
                    //   fontSize: kIsWeb ? 18 : 16,
                    // ),
                    maxLines: 1,
                  ),
                )
              : FittedBox(
                  child: Text(
                    title,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      fontWeight: FontWeight.w500,
                      fontSize: kIsWeb ? 18 : 14,
                    ),
                    // TextStyle(
                    //   color: Theme.of(context).brightness == Brightness.dark ? Color(0xFF586976) : Color(0xFF586976),
                    //   fontSize: kIsWeb ? 18 : 16,
                    //   fontWeight: FontWeight.bold,
                    // ),
                    maxLines: 1,
                  ),
                ),
          isSelected
              ? Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: controller.displayColor,
                  ),
                  height: 5,
                  width: title.removeAllWhitespace.length * 10.toDouble(),
                )
              : SizedBox(),
          // Container(
          //   height: 5,
          //   width: 100,
          //   color: isSelected ? controller.displayColor :Theme.of(context).brightness == Brightness.dark ?Colors.white: Colors.black,
          // )
        ],
      ),
    );
  }
}
