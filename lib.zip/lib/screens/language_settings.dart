import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/utils/app_languages.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../network/controller/login_controller.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/routes.dart';
import '../utils/utils_methods.dart';
import '../web_views/web_main_screen.dart';

class LanguageSettings extends StatelessWidget {
  final bool fromLoginPage;
  LanguageSettings({this.fromLoginPage});

  final controller = Get.isRegistered<NewsfeedController>() ? Get.find<NewsfeedController>() : Get.put(NewsfeedController());

  @override
  Widget build(BuildContext context) {
    if (fromLoginPage != null && fromLoginPage){
      controller.isBlockedAccounts = false;
      controller.isTranslations = false;
      controller.isProfileLanguagetype = false;
      controller.isListOfBlockedAccounts = false;
      controller.isLanguageSettings = true;
      controller.isSettingDetail = false;
      controller.isSettingTypeDetail = true;
      controller.isLanguageType = true;
    }
    return Scaffold(
        appBar: !kIsWeb
            ? AppBar(
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                iconTheme: const IconThemeData(
                  color: Color(0xFF4f515b),
                ),
                title: Center(
                  child: Text(
                    controller.isAccountPrivacy
                        ? Strings.privacySettings
                        : Strings.languageSettings,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                    ),

                  ),
                ),
                leading: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: InkWell(
                      onTap: () {
                        controller.isBlockedAccounts = false;
                        controller.isListOfBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isLanguageSettings = true;
                        controller.isLanguageType = false;
                        controller.isAccountPrivacySettings
                            ? controller.isAccountPrivacy = true
                            : controller.isAccountPrivacy = false;
                        controller.isAccountPrivacySettings = false;
                        controller.isProfileLanguagetype = false;
                        if (!kIsWeb) {
                          Navigator.of(context).pop();
                        }
                        controller.update();
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )),
                ),
                // actions: [
                //   controller.isAccountPrivacySettings
                //       ? SizedBox()
                //       : Switch(
                //           value: controller.isAutoTranslate,
                //           onChanged: (value) async {
                //             controller.isAutoTranslate = value;
                //
                //             await controller.languagesRequest(languageId: controller.selectedLanguage != null ? controller.selectedLanguage.id.toString() : 1.toString(), autoTranslate: value == true ? 1.toString() : 0.toString());
                //             controller.update();
                //             // controller.postList =await controller.getNewsFeed(reload: true);
                //             // controller.languageData =await controller.getLanguages();
                //             // controller.isLanguageSettings =false;
                //             // controller.isProfileLanguagetype = false;
                //             // controller.isNewsFeedScreen =true;
                //             // controller.isSettingsScreen =false;
                //             // MyApp.rebirth(context);
                //             // controller.update();
                //             // Get.delete<NewsfeedController>();
                //             // Future.delayed(Duration(seconds: 2), () {
                //
                //             // Get.delete<NewsfeedController>();
                //             if (kIsWeb) {
                //               Routemaster.of(context).replace(
                //                   AppRoute.postScreen,
                //                   queryParameters: {
                //                     "postId": null,
                //                     "profileId": null
                //                   });
                //             } else {
                //               Get.offUntil(
                //                   MaterialPageRoute(
                //                     builder: (context) => Session(),
                //                   ),
                //                   (route) => false);
                //               // Navigator.pushAndRemoveUntil(
                //               //     context,
                //               //     MaterialPageRoute(builder: (BuildContext context) => Session()),
                //               //     ModalRoute.withName(AppRoute.postScreen)
                //               // );
                //               // Navigator.of(context)
                //               //     .pushNamedAndRemoveUntil(AppRoute.postScreen, (Route<dynamic> route) => false);
                //             }
                //
                //             // Navigator.of(context).pushAndRemoveUntil(
                //             //     MaterialPageRoute(
                //             //         builder: (context) => Session()),
                //             //     (Route<dynamic> route) => false);
                //             // });
                //
                //             // Phoenix.rebirth(context);
                //           })
                // ],
              )
            : PreferredSize(
                preferredSize: const Size(0, 0),
                child: Container(),
              ),
        body: GetBuilder<NewsfeedController>(
          builder: (_) {
            return Column(
              children: [
                kIsWeb
                    ? Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 16.0,
                          horizontal: 12,
                        ),
                        child: Row(
                          children: [
                            MouseRegion(
                              cursor: SystemMouseCursors.click,
                              child: InkWell(
                                  onTap: () {
                                    controller.isBlockedAccounts = false;
                                    controller.isListOfBlockedAccounts = false;
                                    controller.isTranslations = false;
                                    controller.isLanguageSettings = true;
                                    controller.isLanguageType = false;
                                    controller.isAccountPrivacySettings
                                        ? controller.isAccountPrivacy = true
                                        : controller.isAccountPrivacy = false;
                                    controller.isAccountPrivacySettings = false;
                                    controller.isProfileLanguagetype = false;
                                    controller.update();
                                  },
                                  child: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  )),
                            ),
                            Expanded(
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(
                                  controller.isAccountPrivacySettings
                                      ? Strings.privacySettings
                                      : Strings.languageSettings,
                                  textAlign: TextAlign.left,
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                    //   fontWeight: FontWeight.bold,
                                  ),
                                  // Theme.of(context).brightness == Brightness.dark ?
                                  // TextStyle(color: Colors.white,fontSize: 15,fontWeight: FontWeight.bold
                                  // )
                                  //     : TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold
                                  // ),
                                ),
                              ),
                            ),
                            /*
                            controller.isLanguageSettings &&
                                    controller.isProfileLanguagetype
                                ? Switch(
                                    value: controller.isAutoTranslate,
                                    onChanged: (value) async {
                                      controller.isAutoTranslate = value;
                                      controller.languagesRequest(
                                          languageId: controller
                                                      .selectedLanguage !=
                                                  null
                                              ? controller.selectedLanguage.id
                                                  .toString()
                                              : 1.toString(),
                                          autoTranslate: value == true
                                              ? 1.toString()
                                              : 0.toString());
                                      // controller.postList =await controller.getNewsFeed(reload: true);
                                      // controller.languageData =await controller.getLanguages();
                                      // controller.isLanguageSettings =false;
                                      // controller.isProfileLanguagetype = false;
                                      // controller.isNewsFeedScreen =true;
                                      // controller.isSettingsScreen =false;
                                      // MyApp.rebirth(context);
                                      // controller.update();
                                      // Get.delete<NewsfeedController>();
                                      // Future.delayed(Duration(seconds: 2), () {
                                      print(
                                          'HEHHEEHHHEHEE translation language');
                                      Get.delete<NewsfeedController>();
                                      if (kIsWeb) {
                                        onHomeChange = true;
                                        onBrowsChange = false;
                                        onTrendsChange = false;
                                        onBookMarksChange = false;
                                        onChatsChange = false;
                                        onProfileChange = false;
                                        onSettingChange = false;
                                        onListChange = false;
                                        onNotificationChange = false;
                                        onMoreChange = false;
                                        onMomentChange = false;

                                        Get.offNamed(FluroRouters.mainScreen);
                                        // context.pushReplacement(AppRoute.routeMain);
                                      } else {
                                        Get.offUntil(
                                            MaterialPageRoute(
                                              builder: (context) => Session(),
                                            ),
                                            (route) => false);
                                      }
                                      // Navigator.of(context)
                                      //     .pushAndRemoveUntil(
                                      //         MaterialPageRoute(
                                      //             builder: (context) =>
                                      //                 Session()),
                                      //         (Route<dynamic> route) =>
                                      //             false);
                                      // });
                                      // Phoenix.rebirth(context);

                                      // Get.delete<NewsfeedController>();
                                    })
                                : SizedBox() */
                          ],
                        ),
                      )
                    : Container(),
                Container(
                  height: 1,
                  color: Colors.grey[300],
                ),
                const SizedBox(
                  height: 10,
                ),
                controller.isLanguageSettings && controller.isLanguageType
                    ? SizedBox(
                        height: Get.height / 1.3,
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  top: 10,
                                ),
                                child: Text(
                                  Strings.selectYourPreferredLanguage,
                                  maxLines: 2,
                                  textAlign: TextAlign.center,
                                  style:
                                      Styles.baseTextTheme.headline2.copyWith(
                                    fontSize: kIsWeb ? 14 : 12,
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: Get.height / 1.4,
                                child: controller.isLang
                                    ? const Center(
                                        child: CircularProgressIndicator(
                                          color: MyColors.BlueColor,
                                        ),
                                      )
                                    : SingleChildScrollView(
                                        child: Column(
                                          children: List.generate(
                                              AppLanguage()
                                                  .languagesList
                                                  .length, (indexx) {
                                            return Container(
                                              color: controller
                                                          .selectedAppLanguageInfoId !=
                                                      null
                                                  ?
                                                  controller.selectedAppLanguageInfoId ==
                                                          AppLanguage()
                                                                  .languagesList[
                                                              indexx]["id"]
                                                      ? Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.black
                                                          : Colors.grey[200]
                                                      : Colors.transparent
                                                  : Colors.transparent,
                                              child: ListTileSettings(
                                                AppLanguage().languagesList[indexx]["name"],
                                                controller.selectedAppLanguageInfoId != null
                                                    ? controller.selectedAppLanguageInfoId == AppLanguage().languagesList[indexx]["id"] ||
                                                            controller.languageData.appLang.id == AppLanguage().languagesList[indexx]["id"]
                                                        ? Icons.check
                                                        : null
                                                    : null,
                                                () async {
                                                  if (fromLoginPage != null && fromLoginPage){
                                                    String code = AppLanguage().languagesList[indexx]["code"];
                                                    final loginController = Get.find<LoginController>();
                                                    loginController.updateLanguage(code);
                                                    Navigator.pop(context);
                                                    return;
                                                  }

                                                  controller
                                                      .languageData
                                                      .appLang
                                                      .id = AppLanguage()
                                                          .languagesList[indexx]
                                                      ["id"];
                                                  controller
                                                          .selectedAppLanguageInfoId =
                                                      AppLanguage()
                                                              .languagesList[
                                                          indexx]["id"];
                                                  controller.languagesRequest(
                                                      languageId: controller
                                                                  .selectedLanguage !=
                                                              null
                                                          ? controller
                                                              .selectedLanguage
                                                              .id
                                                              .toString()
                                                          : 1.toString(),
                                                      autoTranslate:
                                                          1.toString(),
                                                      appLanguageId: AppLanguage()
                                                              .languagesList[indexx]
                                                          ["id"],
                                                      appLanguage: AppLanguage()
                                                              .languagesList[indexx]
                                                          ["name"],
                                                      appLanguageCode: AppLanguage()
                                                              .languagesList[indexx]
                                                          ["code"]);

                                                  print(AppLanguage()
                                                          .languagesList[indexx]
                                                      ["id"]);
                                                  print(AppLanguage()
                                                          .languagesList[indexx]
                                                      ["name"]);
                                                  print(AppLanguage()
                                                          .languagesList[indexx]
                                                      ["code"]);

                                                  await Get.delete<
                                                      NewsfeedController>();
                                                  if (kIsWeb) {

                                                    onHomeChange = true;
                                                    onBrowsChange = false;
                                                    onTrendsChange = false;
                                                    onBookMarksChange = false;
                                                    onChatsChange = false;
                                                    onProfileChange = false;
                                                    onSettingChange = false;
                                                    onListChange = false;
                                                    onNotificationChange =
                                                        false;
                                                    onMoreChange = false;
                                                    onMomentChange = false;

                                                    Get.offNamed(FluroRouters
                                                        .mainScreen);
                                                    context.pushReplacement(AppRoute.routeMain);
                                                  } else {
                                                    Get.offUntil(
                                                        MaterialPageRoute(
                                                          builder: (context) =>
                                                              Session(),
                                                        ),
                                                        (route) => false);
                                                  }
                                                  // Navigator.of(context)
                                                  //     .pushAndRemoveUntil(
                                                  //     MaterialPageRoute(
                                                  //         builder:
                                                  //             (context) =>
                                                  //             Session()),
                                                  //         (Route<dynamic>
                                                  //     route) =>
                                                  //     false);
                                                  // });
                                                  // Phoenix.rebirth(context);

//                                          }
                                                  // controller.update();
                                                  // controller.upDateLocale('فارسی');
                                                },
                                                false,
                                                FontWeight.w400,
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                              )
//                              ListTileSettings(
//                                  Strings.english, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('English');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.arabic, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('عربي');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.french, Icons.arrow_forward_ios, () {
//
//                                controller.upDateLocale('Français');
//                                controller.languagesRequest(languageId: ,appLanguageId: ,);
//                              }, false),
//                              ListTileSettings(
//                                  Strings.german, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('Deutsche');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.spanish, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('Española');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.hindi, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('हिंदी');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.indonesia, Icons.arrow_forward_ios,
//                                  () {
//                                controller.upDateLocale('Bahasa_Indonesia');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.portuguese, Icons.arrow_forward_ios,
//                                  () {
//                                controller.upDateLocale('Português');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.turkish, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('Turca');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.somali, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('Shoomaali');
//                              }, false),
//                              ListTileSettings(
//                                  Strings.persian, Icons.arrow_forward_ios, () {
//                                controller.upDateLocale('فارسی');
//                              }, false
                            ],
                          ),
                        ))

                ///idhr kud comment kia hai
                    // : controller.isAccountPrivacy &&
                    //         controller.isAccountPrivacySettings
                    //     ? Container(
                    //         height: Get.height / 1.3,
                    //         child: SingleChildScrollView(
                    //             child: Column(
                    //                 crossAxisAlignment:
                    //                     CrossAxisAlignment.center,
                    //                 mainAxisAlignment: MainAxisAlignment.start,
                    //                 children: [
                    //               Padding(
                    //                 padding: const EdgeInsets.only(
                    //                   top: 10,
                    //                 ),
                    //                 child: Text(
                    //                   Strings.setYourPrivacySettings,
                    //                   maxLines: 2,
                    //                   textAlign: TextAlign.center,
                    //                   style: Styles.baseTextTheme.headline2
                    //                       .copyWith(
                    //                     fontSize: kIsWeb ? 14 : 12,
                    //                   ),
                    //                 ),
                    //               ),
                    //               SizedBox(
                    //                 height: 10,
                    //               ),
                    //               Padding(
                    //                 padding: const EdgeInsets.only(left: 30.0),
                    //                 child: Align(
                    //                     alignment: Alignment.centerLeft,
                    //                     child: Text(
                    //                       Strings.messageSettings,
                    //                       style: Styles.baseTextTheme.headline2
                    //                           .copyWith(
                    //                         color:
                    //                             Theme.of(context).brightness ==
                    //                                     Brightness.dark
                    //                                 ? Colors.white
                    //                                 : Colors.black,
                    //                         fontSize: 14,
                    //                         fontWeight: FontWeight.w600,
                    //                       ),
                    //                     )),
                    //               ),
                    //               Padding(
                    //                 padding: const EdgeInsets.only(
                    //                     left: 30.0, right: 30),
                    //                 child: Align(
                    //                   alignment: Alignment.centerLeft,
                    //                   child: new Column(
                    //                     mainAxisAlignment:
                    //                         MainAxisAlignment.start,
                    //                     crossAxisAlignment:
                    //                         CrossAxisAlignment.start,
                    //                     children: [
                    //                       Row(
                    //                         children: [
                    //                           Text(
                    //                             Strings.noOne,
                    //                             style: Styles
                    //                                 .baseTextTheme.headline2
                    //                                 .copyWith(
                    //                               fontWeight: FontWeight.w400,
                    //                               fontSize: 14,
                    //                               color: Theme.of(context)
                    //                                           .brightness ==
                    //                                       Brightness.dark
                    //                                   ? Colors.white
                    //                                   : Colors.black,
                    //                             ),
                    //                           ),
                    //                           Spacer(),
                    //                           Radio(
                    //                             value: 0,
                    //                             activeColor: Theme.of(context)
                    //                                         .brightness ==
                    //                                     Brightness.dark
                    //                                 ? Colors.white
                    //                                 : Colors.black,
                    //                             groupValue: controller
                    //                                 .radioValueAccount,
                    //                             onChanged:
                    //                                 _handleRadioValueChange,
                    //                           ),
                    //                         ],
                    //                       ),
                    //                       Row(
                    //                         children: [
                    //                           Text(
                    //                             Strings.followers,
                    //                             style: Styles
                    //                                 .baseTextTheme.headline2
                    //                                 .copyWith(
                    //                               fontWeight: FontWeight.w400,
                    //                               fontSize: 14,
                    //                               color: Theme.of(context)
                    //                                           .brightness ==
                    //                                       Brightness.dark
                    //                                   ? Colors.white
                    //                                   : Colors.black,
                    //                             ),
                    //                           ),
                    //                           Spacer(),
                    //                           new Radio(
                    //                             value: 1,
                    //                             activeColor: Theme.of(context)
                    //                                         .brightness ==
                    //                                     Brightness.dark
                    //                                 ? Colors.white
                    //                                 : Colors.black,
                    //                             groupValue: controller
                    //                                 .radioValueAccount,
                    //                             onChanged:
                    //                                 _handleRadioValueChange,
                    //                           ),
                    //                         ],
                    //                       ),
                    //                       Row(
                    //                         children: [
                    //                           new Text(
                    //                             Strings.everyOne,
                    //                             style: Styles
                    //                                 .baseTextTheme.headline2
                    //                                 .copyWith(
                    //                               fontWeight: FontWeight.w400,
                    //                               fontSize: 14,
                    //                               color: Theme.of(context)
                    //                                           .brightness ==
                    //                                       Brightness.dark
                    //                                   ? Colors.white
                    //                                   : Colors.black,
                    //                             ),
                    //                           ),
                    //                           Spacer(),
                    //                           new Radio(
                    //                             value: 2,
                    //                             activeColor: Theme.of(context)
                    //                                         .brightness ==
                    //                                     Brightness.dark
                    //                                 ? Colors.white
                    //                                 : Colors.black,
                    //                             groupValue: controller
                    //                                 .radioValueAccount,
                    //                             onChanged:
                    //                                 _handleRadioValueChange,
                    //                           ),
                    //                         ],
                    //                       ),
                    //                     ],
                    //                   ),
                    //                 ),
                    //               ),
                    //               SizedBox(
                    //                 height: 40,
                    //               ),
                    //               Align(
                    //                 alignment: Alignment.center,
                    //                 child: SizedBox(
                    //                   width: kIsWeb ? 200 : 100,
                    //                   height: 35,
                    //                   child: OutlinedButton(
                    //                     style: ButtonStyle(
                    //                       backgroundColor: MaterialStateProperty
                    //                           .resolveWith<Color>((states) {
                    //                         if (states.contains(
                    //                             MaterialState.disabled)) {
                    //                           return controller.displayColor;
                    //                         }
                    //                         return controller.displayColor;
                    //                       }),
                    //                     ),
                    //                     child: Text(
                    //                       Strings.upDate,
                    //                       style: TextStyle(
                    //                         color: Colors.white,
                    //                         fontSize: 14,
                    //                       ),
                    //                     ),
                    //                     onPressed: () async {
                    //                       DialogBuilder(context)
                    //                           .showLoadingIndicator();
                    //                       await controller.privacyRequest(
                    //                           privacy: controller.userPrivacy);
                    //                       DialogBuilder(context)
                    //                           .hideOpenDialog();
                    //
                    //                       UtilsMethods.toastMessageShow(
                    //                           controller.displayColor,
                    //                           controller.displayColor,
                    //                           controller.displayColor,
                    //                           message:
                    //                               'Message setting updated successfully.');
                    //                     },
                    //                   ),
                    //                 ),
                    //               ),
                    //             ])))
                ///idhr kud comment kia hai
                    : controller.isAccountPrivacy &&
                    controller.isAccountPrivacySettings
                    ? SizedBox(
                    height: Get.height / 1.3,
                    child: SingleChildScrollView(
                        child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  top: 10,
                                ),
                                child: Text(
                                  Strings.setYourPrivacySettings,
                                  maxLines: 2,
                                  textAlign: TextAlign.center,
                                  style: Styles.baseTextTheme.headline2
                                      .copyWith(
                                    fontSize: kIsWeb ? 14 : 12,
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 30.0),
                                child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      Strings.messageSettings,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color:
                                        Theme.of(context).brightness ==
                                            Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    )),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(
                                    left: 30.0, right: 30),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child:  Column(
                                    mainAxisAlignment:
                                    MainAxisAlignment.start,
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            Strings.noOne,
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .brightness ==
                                                  Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          const Spacer(),
                                          Radio(
                                            value: 0,
                                            activeColor: Theme.of(context)
                                                .brightness ==
                                                Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                            groupValue: controller
                                                .radioValueAccount,
                                            onChanged:
                                            _handleRadioValueChange,
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            Strings.followers,
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .brightness ==
                                                  Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          const Spacer(),
                                        Radio(
                                            value: 1,
                                            activeColor: Theme.of(context)
                                                .brightness ==
                                                Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                            groupValue: controller
                                                .radioValueAccount,
                                            onChanged:
                                            _handleRadioValueChange,
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                           Text(
                                            Strings.everyOne,
                                            style: Styles
                                                .baseTextTheme.headline2
                                                .copyWith(
                                              fontWeight: FontWeight.w400,
                                              fontSize: 14,
                                              color: Theme.of(context)
                                                  .brightness ==
                                                  Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          const Spacer(),
                                          Radio(
                                            value: 2,
                                            activeColor: Theme.of(context)
                                                .brightness ==
                                                Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                            groupValue: controller
                                                .radioValueAccount,
                                            onChanged:
                                            _handleRadioValueChange,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(
                                height: 40,
                              ),
                              Align(
                                alignment: Alignment.center,
                                child: SizedBox(
                                  width: kIsWeb ? 200 : 100,
                                  height: 35,
                                  child: OutlinedButton(
                                    style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty
                                          .resolveWith<Color>((states) {
                                        if (states.contains(
                                            MaterialState.disabled)) {
                                          return controller.displayColor;
                                        }
                                        return controller.displayColor;
                                      }),
                                    ),
                                    child: Text(
                                      Strings.upDate,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                      ),
                                    ),
                                    onPressed: () async {
                                      DialogBuilder(context)
                                          .showLoadingIndicator();
                                      await controller.privacyRequest(
                                          privacy: controller.userPrivacy);
                                      DialogBuilder(context)
                                          .hideOpenDialog();


                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor,
                                              controller.displayColor,
                                              controller.displayColor,
                                              message:
                                                  Strings.messageSettings);
                                        },
                                      ),
                                    ),
                                  ),
                                ])))
                        : controller.isLanguageSettings &&
                                controller.isProfileLanguagetype
                            ? SizedBox(
                                height: Get.height / 1.4,
                                child: controller.isLang
                                    ? const Center(
                                        child: CircularProgressIndicator(
                                          color: MyColors.BlueColor,
                                        ),
                                      )

                                    ///language yahan sy change hoti hai
                                    : SingleChildScrollView(
                                        child: Column(
                                          children: List.generate(
                                              controller.languageData.allLangs
                                                  .length, (index) {
                                            return Container(
                                              color: controller
                                                          .selectedLanguage !=
                                                      null
                                                  ? controller.selectedLanguage
                                                                  .id ==
                                                              controller
                                                                  .languageData
                                                                  .allLangs[
                                                                      index]
                                                                  .id ||
                                                          controller
                                                                  .languageData
                                                                  .autoTranslateSettings
                                                                  .id ==
                                                              controller
                                                                  .languageData
                                                                  .allLangs[
                                                                      index]
                                                                  .id
                                                      ? Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.black
                                                          : Colors.grey[200]
                                                      : Colors.transparent
                                                  : Colors.transparent,
                                              child: ListTileSettings(
                                                controller.languageData
                                                    .allLangs[index].name,
                                                controller.selectedLanguage !=
                                                        null
                                                    ? controller.selectedLanguage
                                                                    .id ==
                                                                controller
                                                                    .languageData
                                                                    .allLangs[
                                                                        index]
                                                                    .id ||
                                                            controller
                                                                    .languageData
                                                                    .autoTranslateSettings
                                                                    .id ==
                                                                controller
                                                                    .languageData
                                                                    .allLangs[
                                                                        index]
                                                                    .id
                                                        ? Icons.check
                                                        : null
                                                    : null,
                                                () async {
                                                  controller.selectedLanguage =
                                                      controller.languageData
                                                          .allLangs[index];

                                                  controller.update();

                                                  if(!controller.isAutoTranslate){
                                                    // Removed language Switch off button.
                                                    // So, we switch it on in the backend whenever it's off and there is change in language.
                                                    await controller.languagesRequest(
                                                        languageId: controller
                                                            .selectedLanguage !=
                                                            null
                                                            ? controller.selectedLanguage.id
                                                            .toString()
                                                            : 1.toString(),
                                                        autoTranslate: 1.toString());
                                                    controller.isAutoTranslate = true;
                                                  }


                                                  if (controller
                                                      .isAutoTranslate) {
                                                    await controller.languagesRequest(
                                                        languageId: controller
                                                                    .selectedLanguage !=
                                                                null
                                                            ? controller
                                                                .selectedLanguage
                                                                .id
                                                                .toString()
                                                            : 1.toString(),
                                                        autoTranslate:
                                                            1.toString());
                                                    // controller.postList =await controller.getNewsFeed(reload: true);
                                                    // controller.languageData =await controller.getLanguages();
                                                    // // await controller.get
                                                    // controller.isLanguageSettings =false;
                                                    //     controller.isProfileLanguagetype = false;
                                                    //     controller.isNewsFeedScreen =true;
                                                    //     controller.isSettingsScreen =false;

                                                    // MyApp.rebirth(context);
                                                    // controller.update();

                                                    // Future.delayed(
                                                    //     Duration(seconds: 2), () {

                                                    print("translation bbb");

                                                    Get.delete<
                                                        NewsfeedController>();
                                                    if (kIsWeb) {
                                                      onHomeChange = true;
                                                      onBrowsChange = false;
                                                      onTrendsChange = false;
                                                      onBookMarksChange = false;
                                                      onChatsChange = false;
                                                      onProfileChange = false;
                                                      onSettingChange = false;
                                                      onListChange = false;
                                                      onNotificationChange =
                                                          false;
                                                      onMoreChange = false;
                                                      onMomentChange = false;

                                                      Get.offNamed(FluroRouters
                                                          .mainScreen);
                                                      // context.pushReplacement(AppRoute.routeMain);
                                                    } else {
                                                      Get.offUntil(
                                                          MaterialPageRoute(
                                                            builder:
                                                                (context) =>
                                                                    Session(),
                                                          ),
                                                          (route) => false);
                                                    }
                                                    // Navigator.of(context)
                                                    //     .pushAndRemoveUntil(
                                                    //         MaterialPageRoute(
                                                    //             builder:
                                                    //                 (context) =>
                                                    //                     Session()),
                                                    //         (Route<dynamic>
                                                    //                 route) =>
                                                    //             false);
                                                    // });
                                                    // Phoenix.rebirth(context);
                                                  }
                                                  // controller.update();
                                                  // controller.upDateLocale('فارسی');
                                                },
                                                false,
                                                FontWeight.w400,
                                              ),
                                            );
                                          }),
                                        ),
                                      ),
                              )
                            : Container()
                // : Container()
              ],
            );
          },
        ));
  }

  void _handleRadioValueChange(int value) {
    controller.radioValueAccount = value;

    switch (controller.radioValueAccount) {
      case 0:
        controller.userPrivacy = "no_one";

        break;
      case 1:
        controller.userPrivacy = "followers";

        break;
      case 2:
        controller.userPrivacy = "ever_one";
        break;
    }
    controller.update();
  }
}
