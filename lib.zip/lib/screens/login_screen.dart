import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/screens/registration_successful.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_one.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/web_views/web_login.dart';
//import 'package:werfieapp/widgets/login_form.dart' as loginForm;
import 'package:werfieapp/widgets/sign_up_dialog.dart';
import 'package:werfieapp/widgets/sign_up_form.dart';

import '../network/controller/news_feed_controller.dart';
import '../utils/app_languages.dart';
import '../utils/colors.dart';
import '../widgets/sign_in_sign_up_widget/new_login_form.dart'as loginForm;
import 'language_settings.dart';

// ignore: must_be_immutable
class LoginScreen extends StatefulWidget {
  String postId;
  String profileId;
  int isFromWorldNoorApp;
  bool isAutoLogin = false;

  LoginScreen({Key key, this.postId, this.profileId,this.isFromWorldNoorApp = 0,this.isAutoLogin = false}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  GlobalKey<ScaffoldState> sKey = GlobalKey<ScaffoldState>();

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  // final newsFeedController = Get.put(NewsfeedController());
  // final loginController = Get.put(LoginController());



  @override
  Widget build(BuildContext context) {
    return GetBuilder<LoginController>(
        init: LoginController(
          postId: widget.postId != null ? widget.postId : null,
          profileId: widget.profileId != null ? widget.profileId : null,
        ),
        builder: (controller) {
          // controller.formKey = controller.mountRoute == ModalRoute.of(context) ? controller.formKey : new GlobalKey<FormState>();

          return Scaffold(
            backgroundColor: Colors.grey.shade100,
              key: sKey,
              // appBar:!controller.showSignUpForm? AppBar(
              //   elevation: 0.0,
              //   backgroundColor: Colors.white,
              //   actions: [
              //     // Padding(
              //     //   padding: const EdgeInsets.symmetric(horizontal: 8.0),
              //     //   child: Row(
              //     //     mainAxisAlignment: MainAxisAlignment.end,
              //     //     children: [
              //     //       DropdownButton<AppLanguage>(
              //     //           value: controller.selectedLanguage,
              //     //           hint: Text('Change Language'),
              //     //           onChanged: (AppLanguage value) async {
              //     //             debugPrint('language value----->>> ${value.code}');
              //     //             Get.updateLocale(Locale(value.code));
              //     //             final SharedPreferences prefs = await SharedPreferences.getInstance();
              //     //             prefs.setString('languageCode', value.code);
              //     //             setState(() {});
              //     //
              //     //            //  debugPrint('value ------>>>> ${value.id}');
              //     //            // controller.changeLanguageLogin(value);
              //     //           },
              //     //           items: controller.languageList
              //     //               .map((AppLanguage language) {
              //     //                 debugPrint('lanuages--->>> ${language.id}');
              //     //             return DropdownMenuItem<AppLanguage>(
              //     //               value: language,
              //     //               child: Text(language.name),
              //     //             );
              //     //           }).toList()),
              //     //     ],
              //     //   ),
              //     // ),
              //   ],
              // )
              //     :PreferredSize(
              //     preferredSize: const Size.fromHeight(0.0), // here the desired height
              //     child: AppBar(
              //       backgroundColor: Colors.white,
              //       elevation: 0,
              //     )
              // ),

              body: Responsive(
                mobile: kIsWeb
                    ? SingleChildScrollView(
                        child: Align(
                          alignment: Alignment.center,
                          child: Container(
                           // width: 400,
                            child: controller.showSignUpForm
                                ? SignUpDialog(
                                    controller: controller,
                                  )
                                : controller.showRegistrationSuccessful
                                    ? RegistrationSuccessful()
                                  //  : NewSignInForm(loginController: controller,),
                           : loginForm .NewLoginForm(context, controller, formKey, 1,loginController: controller,)
                         // :   loginForm.loginForm(
                         //                context, controller, formKey, 1),
                          ),
                        ),
                      )
                    : SingleChildScrollView(
                       // child: Padding(
                       //   padding: EdgeInsets.only(
                           // top: controller.showSignUpForm
                              //  ? MediaQuery.of(context).size.height * 0.0
                              //  : MediaQuery.of(context).size.height * 0.0,
                           // bottom: MediaQuery.of(context).size.height * 0.0,
                          //  left: 20.0,
                          //  right: 20.0,
                        //  ),
                          child: Column(
                            children: [
                              controller.showSignUpForm
                                  ? SignUpDialog(
                                      controller: controller,
                                    )
                                  : controller.showRegistrationSuccessful
                                      ? RegistrationSuccessful()
                                     :
                             // NewSignInForm(loginController: controller,),

                              loginForm.NewLoginForm(
                                          context, controller, formKey, 1,isFromWorldNoorApp: widget.isFromWorldNoorApp,isAutoLogin:widget.isAutoLogin,loginController: controller,),
                              const SizedBox(height: 10),
                              /// other things
                              // controller.showRegistrationSuccessful
                              //     ? Container()
                              //     : !controller.showSignUpForm
                              //         ? Row(
                              //             crossAxisAlignment:
                              //                 CrossAxisAlignment.center,
                              //             mainAxisAlignment:
                              //                 MainAxisAlignment.center,
                              //             children: [
                              //               Text(
                              //                 Strings.doNotHaveAnAccount,
                              //                 style: TextStyle(
                              //                   color: Theme.of(context)
                              //                               .brightness ==
                              //                           Brightness.dark
                              //                       ? Colors.white
                              //                       : MyColors.black,
                              //                   fontSize: 16,
                              //                   fontWeight: FontWeight.w500,
                              //                 ),
                              //               ),
                              //               TextButton(
                              //                 child: Text(
                              //                   Strings.register,
                              //                   style: TextStyle(
                              //                     color: MyColors.werfieBlue,
                              //                     // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : MyColors.werfieBlue,
                              //                     fontSize: 18,
                              //                     fontWeight: FontWeight.bold,
                              //                   ),
                              //                   // style: TextStyle(
                              //                   //   color: Color(0xffedab30),
                              //                   //   fontSize: 16,
                              //                   // ),
                              //                 ),
                              //                 onPressed: () {
                              //                   // controller.formKey.currentState
                              //                   //     .save();
                              //                   // controller.formKey.currentState
                              //                   //     .reset();
                              //                   // controller.formKey.currentState
                              //                   //     .reset();
                              //                   if(!kIsWeb){
                              //                     Navigator.push(
                              //                       context,
                              //                       MaterialPageRoute(
                              //                           builder: (context) =>
                              //                               SignUpStepOne(controller: controller,)),
                              //                     );                                                }
                              //                   else {
                              //                     controller.email.clear();
                              //                     controller.password.clear();
                              //                     controller.showSignUpForm =
                              //                     true;
                              //                     controller
                              //                         .showRegistrationSuccessful =
                              //                     false;
                              //                     controller.update();
                              //                   }
                              //                 },
                              //               ),
                              //             ],
                              //           )
                              //         : Row(
                              //             crossAxisAlignment:
                              //                 CrossAxisAlignment.center,
                              //             mainAxisAlignment:
                              //                 MainAxisAlignment.center,
                              //             children: [
                              //               Text(
                              //                 Strings.haveAnAccount,
                              //                 style: TextStyle(
                              //                     color: Theme.of(context)
                              //                                 .brightness ==
                              //                             Brightness.dark
                              //                         ? Colors.white
                              //                         : MyColors.black,
                              //                     //color:  MyColors.werfieBlue,
                              //                     fontSize: 16,
                              //                     fontWeight: FontWeight.w500),
                              //               ),
                              //               TextButton(
                              //                 child: Text(
                              //                   Strings.login,
                              //                   style: TextStyle(
                              //                       color: MyColors.werfieBlue,
                              //                       // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : MyColors.werfieBlue,
                              //                       fontSize: 18,
                              //                       fontWeight:
                              //                           FontWeight.bold),
                              //                   // style: TextStyle(
                              //                   //   color: Color(0xFFedab30),
                              //                   //   fontSize: 16,
                              //                   // ),
                              //                 ),
                              //                 onPressed: () {
                              //                   debugPrint("login pressed 001");
                              //                   // controller.formKey.currentState
                              //                   //     .reset();
                              //                   // controller.formKey.currentState
                              //                   //     .reset();
                              //                   // controller.formKey.currentState
                              //                   //     .save();
                              //                   controller.signupEmail.clear();
                              //                   controller.signupPassword
                              //                       .clear();
                              //                   controller.firstName.clear();
                              //                   controller.lastName.clear();
                              //                   controller.signupPassword
                              //                       .clear();
                              //                   controller.signupPasswordCon
                              //                       .clear();
                              //                   controller.username.clear();
                              //
                              //                   controller.showSignUpForm =
                              //                       false;
                              //                   controller
                              //                           .showRegistrationSuccessful =
                              //                       false;
                              //
                              //                   controller.update();
                              //                 },
                              //               ),
                              //             ],
                              //           ),
                              // SizedBox(height: 10.0,),
                              // InkWell(
                              //   onTap: (){
                              //     Navigator.push(
                              //         context,
                              //         MaterialPageRoute(
                              //             builder: (BuildContext context) =>
                              //                 LanguageSettings(fromLoginPage: true,)));
                              //   },
                              //   child: Row(
                              //     mainAxisAlignment: MainAxisAlignment.center,
                              //     children: [
                              //       Text(
                              //         "${Strings.language}: ",
                              //         style: TextStyle(
                              //           color: Theme.of(context)
                              //               .brightness ==
                              //               Brightness.dark
                              //               ? Colors.white
                              //               : MyColors.black,
                              //           fontSize: 14,
                              //           fontWeight: FontWeight.w500,
                              //         ),
                              //       ),
                              //       Text(
                              //         controller.selectedLanguage != null ? controller.selectedLanguage.name : "English",
                              //         style: TextStyle(
                              //           color: Theme.of(context)
                              //               .brightness ==
                              //               Brightness.dark
                              //               ? Colors.white
                              //               : MyColors.blue,
                              //           fontSize: 14,
                              //           fontWeight: FontWeight.w700,
                              //         ),
                              //       ),
                              //     ],
                              //   ),
                              // ),
                              // SizedBox(height: 50.0,),
                            ],
                          ),
                       // ),
                      ),
                desktop: WebLoginView(controller: controller, formKey: formKey),
                tablet: WebLoginView(controller: controller, formKey: formKey),
              ));
        });
  }
}
