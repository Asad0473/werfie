import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/login_controller.dart';
import '../network/controller/profile_controller.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class verificationEmailScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  final String email;

  verificationEmailScreen({this.email});

  TextEditingController verification = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return kIsWeb
            ? Container(
                height: 500,
                width: 450,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "We sent you a code",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        Text(
                          "Enter it below to verify your email",
                          style: TextStyle(
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        Form(
                          key: formKey,
                          child: InputField(
                            // focusNode: controller.focus1,

                            TextInputAction: TextInputAction.next,
                            onChanged: (_) {},
                            hint: Strings.verificationCode,

                            onValueEntered: (_) {},
                            // onValueEntered: (value) {
                            //   print('value will be' + value);
                            //   value = email.text;
                            // },
                            controller: verification,
                            validator: FormBuilderValidators.compose([
                              FormBuilderValidators.required(context,
                                  errorText:
                                      Strings.verificationCodeCannotBeEmpty),
                            ]),
                            textInputType: TextInputType.emailAddress,
                            // fieldIcon: Icons.email,
                          ),
                        ),
                        PopupMenuButton(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                            position: PopupMenuPosition.under,
                            padding: EdgeInsets.zero,
                            child: Text(
                              Strings.DidNoTReceiveCode,
                              style: Styles.baseTextTheme.bodyText1.copyWith(
                                color: Colors.blue,
                                fontSize: 14,
                              ),
                            ),

                            // color: Theme.of(context).brightness == Brightness.dark?Colors.black: Colors.white,
                            // Callback that sets the selected popup menu item.
                            onSelected: (value) async {
                              if (value == 1) {
                                int isSuccess =
                                    await controller.sendEmailVerification(
                                        Get.find<LoginController>().email.text);
                                if (isSuccess == 1) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'We sent you a code ');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'error occur while sending you code');
                                }
                              }
                            },
                            itemBuilder: (BuildContext context) => [
                                  PopupMenuItem(
                                    padding: EdgeInsets.all(0),
                                    value: 1,
                                    child: Container(
                                      height: 80,
                                      width: 150,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Strings.DidNoTReceiveCode,
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Text(
                                              Strings.resend,
                                              style: Styles
                                                  .baseTextTheme.headline1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),

                        Spacer(),

                        Align(
                          alignment: Alignment.bottomRight,
                          child: RoundedButton(
                            Strings.verify,
                            () async {
                              if (formKey.currentState.validate()) {
                                Navigator.pop(context);
                                var code = int.parse(verification.text);
                                int isSuccess = await controller
                                    .sendCodeResetEmail(code, email);
                                Get.find<LoginController>().email.clear();
                                if (isSuccess == 1) {
                                  controller.storage
                                      .write("CurrentEmail", email);

                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'Code is valid and email updated successfully');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'Code is not valid');
                                }
                                if (Get.isRegistered<ProfileController>()) {
                                  Get.find<ProfileController>().userProfile =
                                      await controller.getUserProfile();
                                  Get.find<ProfileController>().update();
                                  controller.isAccountInformation = true;
                                  controller.isChangeUserName = false;

                                  controller.update();
                                }
                              }
                            },
                            horizontalPadding: 30.0,
                            roundedButtonColor: controller.displayColor,
                          ),
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              )
            : Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      Spacer(),
                      Image.asset(
                        "assets/drawer_icons/WerfieLogoWIcon.png",
                        alignment: Alignment.centerLeft,
                        width: 60,
                        height: 60,
                      ),
                      Spacer(),
                    ],
                  ),
                  centerTitle: true,
                  elevation: 0.0,
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                ),
                body: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "We sent you a code",
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        Text(
                          "Enter it below to verify your email",
                          style: TextStyle(
                            fontSize: 14,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 20),
                        InputField(
                          // focusNode: controller.focus1,

                          TextInputAction: TextInputAction.next,
                          onChanged: (_) {},
                          hint: Strings.verificationCode,

                          onValueEntered: (_) {},
                          // onValueEntered: (value) {
                          //   print('value will be' + value);
                          //   value = email.text;
                          // },
                          controller: verification,
                          validator: FormBuilderValidators.compose([
                            FormBuilderValidators.required(context,
                                errorText:
                                    Strings.verificationCodeCannotBeEmpty),
                          ]),
                          textInputType: TextInputType.emailAddress,
                          // fieldIcon: Icons.email,
                        ),
                        PopupMenuButton(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(10.0),
                              ),
                            ),
                            position: PopupMenuPosition.under,
                            padding: EdgeInsets.zero,
                            child: Text(
                              Strings.DidNoTReceiveCode,
                              style: Styles.baseTextTheme.bodyText1.copyWith(
                                color: Colors.blue,
                                fontSize: 14,
                              ),
                            ),

                            // color: Theme.of(context).brightness == Brightness.dark?Colors.black: Colors.white,
                            // Callback that sets the selected popup menu item.
                            onSelected: (value) async {
                              if (value == 1) {
                                int isSuccess =
                                    await controller.sendEmailVerification(
                                        Get.find<LoginController>().email.text);
                                if (isSuccess == 1) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message: 'We sent you a code ');
                                } else if (isSuccess == 2) {
                                  UtilsMethods.toastMessageShow(
                                      controller.displayColor,
                                      controller.displayColor,
                                      controller.displayColor,
                                      message:
                                          'error occur while sending you code');
                                }
                              }
                            },
                            itemBuilder: (BuildContext context) => [
                                  PopupMenuItem(
                                    padding: EdgeInsets.all(0),
                                    value: 1,
                                    child: Container(
                                      height: 80,
                                      width: 150,
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              Strings.DidNoTReceiveCode,
                                              style: Styles
                                                  .baseTextTheme.bodyText1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Text(
                                              Strings.resend,
                                              style: Styles
                                                  .baseTextTheme.headline1
                                                  .copyWith(
                                                fontSize: 14,
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ]),

                        Spacer(),

                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),
                        Row(
                          children: [
                            Spacer(),
                            RoundedButton(
                              Strings.verify,
                              () async {
                                if (formKey.currentState.validate()) {
                                  Navigator.pop(context);

                                  var code = int.parse(verification.text);
                                  int isSuccess = await controller
                                      .sendCodeResetEmail(code, email);
                                  Get.find<LoginController>().email.clear();
                                  if (isSuccess == 1) {
                                    UtilsMethods.toastMessageShow(
                                        controller.displayColor,
                                        controller.displayColor,
                                        controller.displayColor,
                                        message:
                                            'Code is valid and email updated successfully');
                                  } else if (isSuccess == 2) {
                                    UtilsMethods.toastMessageShow(
                                        controller.displayColor,
                                        controller.displayColor,
                                        controller.displayColor,
                                        message: 'Code is not valid');
                                  }
                                  if (Get.isRegistered<ProfileController>()) {
                                    Get.find<ProfileController>().userProfile =
                                        await controller.getUserProfile();
                                    Get.find<ProfileController>().update();
                                    controller.isAccountInformation = true;
                                    controller.isChangeUserName = false;

                                    controller.update();
                                  }
                                }
                              },
                              horizontalPadding: 30.0,
                              roundedButtonColor: controller.displayColor,
                            ),
                          ],
                        ),

                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              );
      },
    );
  }
}
