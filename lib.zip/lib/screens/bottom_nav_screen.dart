 import 'dart:io';

import 'package:custom_navigation_bar/custom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/models/list_detail_model.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/news_feed/newsfeed.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/utils/constants.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/newsfeed_mobile.dart';

import '../main.dart';
import 'browse_screen.dart';
import 'mobile_message_screen.dart';
import 'notification_screen.dart';

class BottomNavScreen extends StatelessWidget {
  BottomNavScreen({Key key, this.postId, this.profileId}) : super(key: key);
  final String postId;
  final String profileId;

//
//   @override
//   State<BottomNavScreen> createState() => _BottomNavScreenState();
// }
//
// class _BottomNavScreenState extends State<BottomNavScreen> {
  var context;

  @override
  Widget build(BuildContext context) {
    this.context = context;
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return WillPopScope(
        onWillPop: _onWillPop,
        child: Scaffold(
          drawer: MainDrawer(controller),
          body: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height - 56,
            child: Obx(() {
              return IndexedStack(
                index: controller.bottomNavIndex.value,
                children: <Widget>[
                  NewsFeed(
                    controller: controller,
                    postId: postId != null ? postId : null,
                    profileId: profileId != null ? profileId : null,
                  ),
                  BrowseScreen(
                    controller: controller,
                  ),
                  MobileMessageScreen(),
                  NotificationScreen(isMainScreen: true),
                  // Center(child: Text('News'))
                ],
              );
            }),
          ),
          bottomNavigationBar: Obx(() {
            return Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Color(0xFF303030)
                        : Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: CustomNavigationBar(
                iconSize: 28.0,
                selectedColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                unSelectedColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Color(0xFF303030)
                    : Colors.white,
                items: [
                  customNavBar(
                      "assets/svg_drawer_icons/HomeFill.svg",
                      AppImages.home,
                      Strings.home,
                      Constants.homeScreenId,
                      controller.bottomNavIndex.value),
                  customNavBar(
                      "assets/svg_drawer_icons/browseFill.svg",
                      AppImages.explore,
                      'Explore',
                      Constants.browseScreenId,
                      controller.bottomNavIndex.value),
                  customNavBar(
                      "assets/svg_drawer_icons/messageFill.svg",
                      AppImages.chat,
                      Strings.chat,
                      Constants.chatsScreenId,
                      controller.bottomNavIndex.value,
                      hasIcon: true,
                      badgeCount: messageNotifications.value,
                      controller: controller),
                  customNavBar(
                      "assets/svg_drawer_icons/notificationsFill.svg",
                      AppImages.notification,
                      Strings.notifications,
                      Constants.notificationsScreenId,
                      controller.bottomNavIndex.value,
                      hasIcon: true,
                      badgeCount: notifi.value),
                  // CustomNavigationBarItem(
                  //     icon: SvgPicture.asset(
                  //       AppImages.news,
                  //       color: controller.bottomNavIndex.value ==
                  //               Constants.newsScreenId
                  //           ? Colorss.yellow
                  //           : Colors.white,
                  //     ),
                  //     title: Text(
                  //       'News',
                  //       style: TextStyle(
                  //           color: controller.bottomNavIndex.value ==
                  //                   Constants.newsScreenId
                  //               ? Colorss.yellow
                  //               : Colors.white,
                  //           fontSize: 13),
                  //     ))
                  // customNavBar(AppImages.home, 'News', Constants.newsScreenId,
                  //     controller.bottomNavIndex.value),
                ],
                currentIndex: controller.bottomNavIndex.value,
                onTap: (index) async {
                  if (index == 0) {

                    controller.getNewsFeed(
                      shouldUpdate: false,
                      reload: true,
                      newsFeedMobile: true,
                    );
                  }
                  // setState(() {
                  if (index == 2) {
                    final sharedPrefs = await SharedPreferences.getInstance();
                    sharedPrefs.setInt('messageCount', 0);
                    messageNotifications.value = 0;
                    messageNotifications.refresh();
                    controller.newMessageCount = 0;
                  }
                  controller.bottomNavIndex.value = index;
                  controller.update();
                  // });
                },
              ),
            );
          }),
        ),
      );
    });
  }

  CustomNavigationBarItem customNavBar(
      String icon, String fillIcon, String title, int index, int selectedIndex,
      {bool hasIcon = false, int badgeCount, var controller}) {
    return CustomNavigationBarItem(
      // badgeCount: badgeCount,
      //   showBadge: hasIcon,
      icon: hasIcon
          ? Stack(
              clipBehavior: Clip.none,
              children: [
                // ImageIcon(
                //      AssetImage(icon)
                // ),
                selectedIndex == index
                    ? Container(
                        width: 30,
                        height: 30,
                        child: SvgPicture.asset(
                          icon,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      )
                    : Container(
                        width: 30,
                        height: 30,
                        child: SvgPicture.asset(
                          fillIcon,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                if (title == Strings.chat)
                badgeCount > 0 || (controller != null && controller.newMessageCount > 0) ?
                  Positioned(
                      top: -4,
                      right: -7,
                      child: CircleAvatar(
                        radius: 7,
                        backgroundColor: MyColors.blue,
                        child: Text(
                          badgeCount > 99 || controller.newMessageCount > 99 ? '+99' : badgeCount > 0 ? '$badgeCount' : controller.newMessageCount > 0 ? "${controller.newMessageCount}" : "",
                          // style: TextStyle(fontSize: 8, color: Colors.white),
                          style: TextStyle(color: Colors.white, fontSize: 8),
                          // Theme.of(context).brightness == Brightness.dark
                          //     ? TextStyle(color: Colors.white, fontSize: 8)
                          //     : TextStyle(color: Colors.black, fontSize: 8),
                        ),
                      )) : SizedBox(),

                if (title == Strings.notifications)
                  badgeCount > 0 ?
                  Positioned(
                      top: -4,
                      right: -7,
                      child: CircleAvatar(
                        radius: 7,
                        backgroundColor: MyColors.blue,
                        child: Text(
                          badgeCount > 99 ? '+99' : badgeCount.toString(),
                          // style: TextStyle(fontSize: 8, color: Colors.white),
                          style: TextStyle(color: Colors.white, fontSize: 8),
                          // Theme.of(context).brightness == Brightness.dark
                          //     ? TextStyle(color: Colors.white, fontSize: 8)
                          //     : TextStyle(color: Colors.black, fontSize: 8),
                        ),
                      )) : SizedBox(),

              ],
            )
          : selectedIndex == index
              ? Container(
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    icon,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                )
              : Container(
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    fillIcon,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),
      // ImageIcon(AssetImage(icon)),
      //  title: Text(
      //    title,
      //    style: TextStyle(
      //        color: selectedIndex == index ? MyColors.yellow : Colors.white,
      //        fontSize: 12),
      //  )
    );
  }

  Future<bool> _onWillPop() async {
    return (await showDialog(
          context: this.context,
          builder: (context) => AlertDialog(
            title:  Text(Strings.areYouSure),
            content:  Text(Strings.doYouWantToExit),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child:  Text(Strings.no),
              ),
              TextButton(
                onPressed: () {
                  if (Platform.isAndroid) {
                    SystemNavigator.pop();
                  } else if (Platform.isIOS) {
                    exit(0);
                  }
                },
                child: Text(Strings.yes),
              ),
            ],
          ),
        )) ??
        false;
  }
}
