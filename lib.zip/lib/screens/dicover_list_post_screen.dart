import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';

// import 'package:image_picker_web/image_picker_web.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/models/list_create_model.dart';
import 'package:werfieapp/models/list_get_member_model.dart';
import 'package:werfieapp/network/controller/List_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/browse_screen.dart';
import 'package:werfieapp/screens/list_screen.dart';
import 'package:werfieapp/utils/constants.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/check_box.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/textformfield_screen.dart';

import '../constants/responsive.dart';
import '../network/controller/browse_controller.dart';
import '../network/controller/news_feed_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import 'edit_list_screen.dart';

class DiscoverListScreen extends StatefulWidget {
  DiscoverListScreen({this.controller, this.index,this.clickId,this.listId});

  final NewsfeedController controller;
  String index;
  int clickId;
  int listId;

  @override
  State<DiscoverListScreen> createState() => _DiscoverListScreenState();
}

class _DiscoverListScreenState extends State<DiscoverListScreen> {
  Uint8List pickedAudio;
  bool isMediaUploading = false;
  String imageThumbnail = '';
  List imageThumbnailsList = [];
  List<Uint8List> _pickedImage = [];

  bool isMediaAttached = false;
  bool checkLocation = false;
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;
  Uint8List imageFile;
  bool imageAvailable = false;
  final DummyData dataController = Get.find();
  Uint8List imageBytes, videoBytes, pdfBytes;

  callGetImage() async {
    PickedFile pickedFile = await dataController.getImage();
    imageBytes = await pickedFile.readAsBytes();
    // pickedMedia = await dataController.getImageWeb();

    if (isEditCheckForImage == 1) {
      isEditCheckForImage = 0;
      setState(() {});
    }

    if (imageBytes != null) {
      _pickedImage.insert(0, imageBytes);

      print("edit check $isEditCheckForImage");
      if (isEditCheckForImage == 0) {
        isEditCheckForImage = null;
        //print("hello  ${isEditCheckForImage}");
        setState(() {});
      } else {
        isMediaUploading = true;
        setState(() {});
      }

      print('NAHI ATA IDHAR');
      imageThumbnail =
      await Get.find<NewsfeedController>().uploadMedia(_pickedImage[0], 1);
      imageThumbnailsList.add(imageThumbnail);

      imageThumbnail = '';
      imageBytes.toList().clear();
      print('I D H A R A J A T A H A I');
      print("pick image ${imageThumbnailsList}");
      isMediaAttached = true;
      isMediaUploading = false;
      setState(() {});

      if (isEditCheckForImage == null) {
        setState(() {
          isEditCheckForImage = 0;
        });
      }
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: WillPopScope(
          onWillPop: () async {
            print("onbackPressed called discoverList");

            widget.controller.isListDetailScreen = false;
            widget.controller.isSearch = false;
            widget.controller.isFilter = false;
            widget.controller.isFilterScreen = false;
            widget.controller.isTrendsScreen = false;
            widget.controller.isNewsFeedScreen = false;
            widget.controller.isBrowseScreen = false;
            widget.controller.isNotificationScreen = false;
            widget.controller.isWhoToFollowScreen = false;
            widget.controller.isSavedPostScreen = false;
            widget.controller.isChatScreen = false;
            widget.controller.isPostDetails = false;
            widget.controller.isProfileScreen = false;
            widget.controller.searchText.text = '';
            widget.controller.isListScreen = true;
            widget.controller.isFollwerScreen = false;
            widget.controller.isSettingsScreen = false;
            widget.controller.navRoute = "isChatScreen";
            widget.controller.update();
            return false;
          },
          child: MobileListPageScreen(
            newsfeedController: widget.controller,
            index: widget.index,
            clickId:widget.clickId,
            listId:widget.listId,
          ),
        ),
        tablet: MobileListPageScreen(
          newsfeedController: widget.controller,
          index: widget.index,
          clickId:widget.clickId,
          listId:widget.listId,

        ),
        desktop: MobileListPageScreen(
          newsfeedController: widget.controller,
          index: widget.index,

        ),
      ),
    );
  }
}

class MobileListPageScreen extends StatefulWidget {
  String index;

  MobileListPageScreen({this.newsfeedController, this.index,this.clickId,this.listId});

  final NewsfeedController newsfeedController;
  int clickId;
  int listId;

  @override
  State<MobileListPageScreen> createState() => _MobileListPageScreenState();
}

class _MobileListPageScreenState extends State<MobileListPageScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  final ListController controller = Get.put(ListController());
  List dataList = [];
  List pinPostList = [];
  List editPostList = [];
  String _selectedMenu = '';
  String createListId;
  String userName;
  String description;
  Uint8List imageFile;
  bool imageAvailable = false;
  final dummyList = List.generate(2, (index) {
    return {
      "id": index,
      "title": "title  $index",
      "subtitle": "subtitle $index"
    };
  });

  bool isFollow = false;
  bool isPin = false;
  bool isHover = false;
  int listId;
  String crateId;
  String nameList;

  final storage = GetStorage();
  @override
  void initState() {

    // TODO: implement initState
    super.initState();


      WidgetsBinding.instance.addPostFrameCallback((_) {
           print("WidgetsBinding");
           getApiData();
         });



  }

  getApiData() async{
    if(kIsWeb){
      print("printpinId:${storage.read("pinId")}");
      print("click id :${storage.read("clickId")}");
      // controller.list=storage.read("pinIndex");

      controller.selectedList=  await controller.listDetail(listId: storage.read("pinId"),isFromRoute: true,clickId:storage.read("clickId") );
      print('selected list Data${ controller.selectedList}');

  }
   else{
      controller.selectedList=  await controller.listDetail(
          listId: widget.listId,isFromRoute: true,
          clickId: widget.clickId );
      print('selected list Data${ controller.selectedList}');
    }

  }


  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(builder: (controller) {
      bool isLoading = false;
      return GestureDetector(
        onTap: () {
          controller.isSearch = false;
          controller.searchResult = [];
          controller.update();
        },
        child: Scaffold(
            key: _scaffoldKey,
            appBar: !Responsive.isDesktop(context)
                ? kIsWeb
                ? AppBar(
              backgroundColor: Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Text(
                Strings.lists,
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme
                      .of(context)
                      .brightness == Brightness.dark ? Colors.white : Colors
                      .black,
                  fontWeight: FontWeight.bold,
                  // fontSize: kIsWeb ? 14 : 12,
                ),
              ),
              automaticallyImplyLeading:
              !Responsive.isDesktop(context) ? true : false,
            )
                :
            PreferredSize(
              preferredSize: Size(0.0, 0.0),
              child: Container(),
            )
                : PreferredSize(
              preferredSize: Size(0.0, 0.0),
              child: Container(),
            ),
            drawer: !Responsive.isDesktop(context)
                ? MainDrawer(widget.newsfeedController)
                : Container(),
            drawerEnableOpenDragGesture:
            !Responsive.isDesktop(context) ? false : true,
            body: SingleChildScrollView(
              child:
              controller.selectedList == null ||
              //    controller.list == null ||
                  controller.listDetailsLoading == true
                  ? Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 200, left: 10.0, right: 10.0, bottom: 10.0),
                  child: CircularProgressIndicator(color: MyColors.BlueColor,),
                ),
              )
                  : Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 10.0, right: 10, top: 8.0, bottom: 8.0),
                    child: ListTile(
                      leading: kIsWeb ? IconButton(
                          onPressed: () {
                            print("Backbutton press");

                            //  Get.toNamed(FluroRouters.mainScreen + '/list');


                          /*  widget.newsfeedController.isListDetailScreen = false;
                            widget.newsfeedController.isSearch = false;
                            widget.newsfeedController.isFilter = false;
                            widget.newsfeedController.isFilterScreen = false;
                            widget.newsfeedController.isTrendsScreen = false;
                            widget.newsfeedController.isNewsFeedScreen = false;
                            widget.newsfeedController.isBrowseScreen = false;
                            widget.newsfeedController.isNotificationScreen = false;
                            widget.newsfeedController.isWhoToFollowScreen = false;
                            widget.newsfeedController.isSavedPostScreen = false;
                            widget.newsfeedController.isChatScreen = false;
                            widget.newsfeedController.isPostDetails = false;
                            widget.newsfeedController.isProfileScreen = false;
                            widget.newsfeedController.searchText.text = '';
                            widget.newsfeedController.isListScreen = true;
                            widget.newsfeedController.isFollwerScreen = false;
                            widget.newsfeedController.isSettingsScreen = false;
                            widget.newsfeedController.navRoute = "isChatScreen";
                            widget.newsfeedController.update();*/

                            onListChange = true;
                            onSettingChange = false;
                            onProfileChange = false;
                            onChatsChange = false;
                            onBookMarksChange = false;
                            onTrendsChange = false;
                            onHomeChange = false;

                            onBrowsChange = false;
                            onMoreChange = false;
                            onNotificationChange = false;

                            // controller.isSearch = false;
                            controller.isFilter = false;
                            controller.isFilterScreen = false;
                            controller.isTrendsScreen = false;
                            controller.isNewsFeedScreen = false;
                            controller.isBrowseScreen = false;
                            controller.isNotificationScreen = false;
                            controller.isWhoToFollowScreen = false;
                            controller.isSavedPostScreen = false;
                            controller.isChatScreen = false;
                            controller.isPostDetails = false;
                            controller.isFollwerScreen = false;
                            controller.isProfileScreen = false;
                            controller.isListScreen = true;
                            controller.isListDetailScreen = false;
                            controller.isSettingsScreen = false;
                            controller.navRoute = "isListScreen";
                            widget.newsfeedController.update();
                            Navigator.pop(context);
                          },
                          icon: Icon(
                            Icons.arrow_back,
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          )) :
                      IconButton(
                          onPressed: () {
                            print("backbutton here");
                            widget.newsfeedController.update();
                            Navigator.pop(context);
                          },
                          icon: Icon(
                            Icons.arrow_back,
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          )),
                      title: Text(
                        controller.list.name,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                          // fontSize: 14,
                        ),
                      ),
                      subtitle: Text(
                        "@${controller.list.authorName}",
                        style: Styles.baseTextTheme.headline2.copyWith(
                          //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: kIsWeb ? 14 : 12,
                        ),
                      ),
                      // trailing: Wrap(
                      //   spacing: 12, // space between two icons
                      //   children: <Widget>[
                      //     PopupMenuButton(padding: EdgeInsets.only(top: 30),
                      //       child: const Icon(
                      //         Icons.login,color: Colors.black,size: 30,
                      //       ),
                      //       itemBuilder: (BuildContext context){
                      //         return
                      //           [
                      //             PopupMenuItem(
                      //               child: ListTile(
                      //
                      //                 leading: IconButton(onPressed: (){}, icon: Icon(Icons.add_photo_alternate)),
                      //                 title: Text("Tweet this",style: TextStyle(color: Colors.black),),
                      //
                      //               ),
                      //             ),
                      //             PopupMenuItem(
                      //               child: InkWell(onTap: (){
                      //
                      //
                      //
                      //                 showDialog<String>(
                      //                 context: context,
                      //                 builder: (BuildContext
                      //                 context) =>
                      //                     AlertDialog(
                      //                         contentPadding:
                      //                         const EdgeInsets
                      //                             .fromLTRB(
                      //                             0.0,
                      //                             0.0,
                      //                             0.0,
                      //                             0.0),
                      //                         content: Container(
                      //                           height:
                      //                           Get.height *
                      //                               0.70,
                      //                           width: Get.width *
                      //                               0.45,
                      //                           child: Wrap(
                      //                               children: [
                      //                                 Column(
                      //                                   children: [
                      //                                     ListTile(
                      //                                         leading: IconButton(
                      //                                             onPressed: () {
                      //                                               SingleTone.instance.selectedLocation = null;
                      //                                               setState(() {});
                      //                                               Navigator.of(context).pop();
                      //                                             },
                      //                                             icon: Icon(
                      //                                               Icons.close,
                      //                                               color: Colors.black87,
                      //                                             )),
                      //                                         title: Text('Send via Direct Message',style: TextStyle(color: Colors.black,fontWeight: FontWeight.w900),),
                      //                                     ),
                      //                                     Padding(
                      //                                         padding:
                      //                                         const EdgeInsets.only(left: 10, right: 10),
                      //                                         child: Expanded(
                      //                                           child: SizedBox(
                      //                                              height: Get.height * .63,
                      //                                             child: Column(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
                      //                                               TextField(
                      //                                                 autofocus: true,
                      //                                                 // controller: controller.chatSearchTEC,
                      //                                                 // focusNode: controller.chatSearchTextFocus,
                      //                                                 onChanged: (value) async {
                      //                                                   // if (value[0] == '@') {
                      //                                                   //   controller.usersList = await controller
                      //                                                   //       .searchChatUser(value.substring(1));
                      //                                                   //
                      //                                                   //   controller.update();
                      //                                                   // } else {
                      //                                                   //   controller.usersList =
                      //                                                   //   await controller.searchChatUser(value);
                      //                                                   //
                      //                                                   //   controller.update();
                      //                                                   // }
                      //
                      //                                                   // print(value);
                      //                                                   // LoginController signupController = LoginController();
                      //                                                   // var resBody =
                      //                                                   //     await signupController.searchUsers(queryParameters: {
                      //                                                   //   "search_text": value,
                      //                                                   // }, token: {
                      //                                                   //   "Authorization": " Bearer ${Url.webAPIKey}",
                      //                                                   //   "Token":
                      //                                                   //       "4be7185a7d4038949d14153402e31545600ef1a22efc34a6d208ba9ab45bfe23621ea1bb3940524d1edb14191b2005e5c7965a8213d69bcdf19e0c3b",
                      //                                                   //   "X-Requested-With": "XMLHttpRequest"
                      //                                                   // });
                      //                                                   // usersList = resBody;
                      //                                                   // print(resBody);
                      //                                                   // setState(() {
                      //                                                   //   print("my list");
                      //                                                   // });
                      //                                                 },
                      //                                                 textAlignVertical: TextAlignVertical.center,
                      //                                                 decoration: InputDecoration(
                      //                                                   hintText: Strings.searchPeople,
                      //                                                   hintStyle: TextStyle(fontSize: 16),
                      //                                                   prefixIcon: Icon(Icons.search, size: 16),
                      //
                      //
                      //
                      //                                                   fillColor: Colors.grey[250],
                      //                                                 ),
                      //                                               ),
                      //                                               TextField(
                      //                                                 autofocus: true,
                      //                                                 // controller: controller.chatSearchTEC,
                      //                                                 // focusNode: controller.chatSearchTextFocus,
                      //                                                 onChanged: (value) async {
                      //                                                   // if (value[0] == '@') {
                      //                                                   //   controller.usersList = await controller
                      //                                                   //       .searchChatUser(value.substring(1));
                      //                                                   //
                      //                                                   //   controller.update();
                      //                                                   // } else {
                      //                                                   //   controller.usersList =
                      //                                                   //   await controller.searchChatUser(value);
                      //                                                   //
                      //                                                   //   controller.update();
                      //                                                   // }
                      //
                      //                                                   // print(value);
                      //                                                   // LoginController signupController = LoginController();
                      //                                                   // var resBody =
                      //                                                   //     await signupController.searchUsers(queryParameters: {
                      //                                                   //   "search_text": value,
                      //                                                   // }, token: {
                      //                                                   //   "Authorization": " Bearer ${Url.webAPIKey}",
                      //                                                   //   "Token":
                      //                                                   //       "4be7185a7d4038949d14153402e31545600ef1a22efc34a6d208ba9ab45bfe23621ea1bb3940524d1edb14191b2005e5c7965a8213d69bcdf19e0c3b",
                      //                                                   //   "X-Requested-With": "XMLHttpRequest"
                      //                                                   // });
                      //                                                   // usersList = resBody;
                      //                                                   // print(resBody);
                      //                                                   // setState(() {
                      //                                                   //   print("my list");
                      //                                                   // });
                      //                                                 },
                      //                                                 textAlignVertical: TextAlignVertical.center,
                      //                                                 decoration: InputDecoration(
                      //
                      //                                                   hintStyle: TextStyle(fontSize: 16),
                      //                                                   // prefixIcon: Icon(Icons.search, size: 16),
                      //                                                   suffixIcon: IconButton(onPressed: (){},icon: Icon(Icons.send,size: 16,)),
                      //                                                   border: OutlineInputBorder(
                      //                                                     borderRadius: BorderRadius.circular(40),
                      //                                                     borderSide: BorderSide(
                      //                                                       width: 2,
                      //                                                       style: BorderStyle.none,
                      //                                                     ),
                      //                                                   ),
                      //                                                   enabledBorder: OutlineInputBorder(
                      //                                                     borderRadius: BorderRadius.circular(40),
                      //                                                     borderSide: BorderSide(
                      //                                                       width: 2,color: Colors.black26
                      //                                                     ),
                      //                                                   ),
                      //                                                   fillColor: Colors.grey[250],
                      //                                                 ),
                      //                                               ),
                      //
                      //
                      //                                             ],),
                      //                                           ),
                      //                                         )),
                      //                                   ],
                      //                                 ),
                      //                               ]),
                      //                         )),
                      //               );},
                      //                 child: ListTile(
                      //
                      //                   leading: IconButton(onPressed: (){
                      //
                      //                   }, icon: Icon(Icons.email)),
                      //                   title: Text("Send viva Direct Message",style: TextStyle(color: Colors.black),),
                      //
                      //
                      //                 ),
                      //               ),
                      //             ),
                      //             PopupMenuItem(
                      //               child: ListTile(
                      //
                      //                 leading: IconButton(onPressed: (){}, icon: Icon(Icons.link)),
                      //                 title: Text("Copy link to list",style: TextStyle(color: Colors.black),),
                      //
                      //
                      //               ),
                      //             ),
                      //
                      //           ];
                      //       },
                      //     ),
                      //     PopupMenuButton(padding: EdgeInsets.only(top: 30),
                      //       child: const Icon(
                      //         Icons.more_horiz,color: Colors.black,size: 30,
                      //       ),
                      //       itemBuilder: (BuildContext context){
                      //         return
                      //           [
                      //             PopupMenuItem(
                      //               child: ListTile(
                      //
                      //                 leading: IconButton(onPressed: (){}, icon: Icon(Icons.flag)),
                      //                 title: Text("Reports List",style: TextStyle(color: Colors.black),),
                      //
                      //               ),
                      //             ),
                      //             PopupMenuItem(
                      //               child: ListTile(
                      //
                      //                 leading: IconButton(onPressed: (){}, icon: Icon(Icons.block)),
                      //                 title: Text("Block",style: TextStyle(color: Colors.black),),
                      //                 subtitle: Text("Lists you’re on",style: TextStyle(color: Colors.black),),
                      //
                      //               ),
                      //             ),
                      //             PopupMenuItem(
                      //               child: ListTile(
                      //
                      //                 leading: IconButton(onPressed: (){}, icon: Icon(Icons.compare_arrows_sharp)),
                      //                 title: Text("See Top Tweets",style: TextStyle(color: Colors.black),),
                      //                 subtitle: Text("You are seeing the Top Tweets first.Latest Tweets will show\nup as they happen",style: TextStyle(color: Colors.black),),
                      //
                      //               ),
                      //             ),
                      //
                      //           ];
                      //       },
                      //     ), // icon-2
                      //   ],
                      // ),
                    ),
                  ),
                  Container(
                    width: Get.width,
                    height: Get.height * .25,
                    decoration: BoxDecoration(
                        color: Colors.brown,
                        image: DecorationImage(
                            image: NetworkImage(controller.selectedList
                                .listDetail.coverImage ==
                                null
                                ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                : controller
                                .selectedList.listDetail.coverImage),
                            fit: BoxFit.cover)),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    controller.list.name,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.white : Colors
                          .black,
                      fontWeight: FontWeight.bold,
                      // fontSize: kIsWeb ? 14 : 12,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "${controller.selectedList.listDetail.description == null
                        ? "" : controller.selectedList.listDetail.description}",
                    style: Styles.baseTextTheme.headline2.copyWith(
                      // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.red,
                        radius: 15,
                        backgroundImage: NetworkImage(controller.list.authorProfileImage ?? "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQerA4slT8egQop5xe3kcmIPmcxBTP-qo8Bjg&usqp=CAU"),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Text(
                        controller.list.authorName,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.w500,
                          fontSize: 14,
                        ),
                      ),
                      Text(
                        "@${
                            controller.list.username}",
                        style: Styles.baseTextTheme.headline2.copyWith(
                          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,
                          fontSize: kIsWeb ? 14 : 12,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () async {
                          List<MemberGetModel> list = await controller
                              .getAlreadyFollower(
                              list_Id: controller.selectedList.listDetail.id
                                  .toString());
                          showDialog<String>(
                            context: context,
                            builder: (BuildContext context) =>
                                AlertDialog(
                                    contentPadding:
                                    const EdgeInsets.fromLTRB(
                                        0.0, 0.0, 0.0, 0.0),
                                    content: StatefulBuilder(
                                      builder: (context,
                                          StateSetter setState) {
                                        return Container(
                                          height: Get.height * 0.70,
                                          width: Get.width * 0.45,
                                          child: Wrap(children: [
                                            Column(
                                              children: [
                                                ListTile(
                                                  leading: IconButton(
                                                      onPressed: () {
                                                        SingleTone.instance
                                                            .selectedLocation =
                                                        null;
                                                        setState(() {});
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                      icon: Icon(
                                                        Icons.close,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )),
                                                  title: Text(
                                                    Strings.listFollowers,
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight: FontWeight
                                                          .bold,
                                                      //fontSize: kIsWeb ? 14 : 12,
                                                    ),
                                                  ),
                                                ),
                                                Padding(
                                                    padding:
                                                    const EdgeInsets.only(
                                                        left: 2,
                                                        right: 2),
                                                    child: SizedBox(
                                                      height:
                                                      Get.height * .50,
                                                      child: list.isEmpty
                                                          ? Center(
                                                        child: Text(
                                                          Strings.noFollower,
                                                        ),
                                                      )
                                                          : ListView.builder(
                                                          itemCount:
                                                          list
                                                              .length,
                                                          itemBuilder:
                                                              (context,
                                                              index) {
                                                            list[index]
                                                                .isFollow =
                                                            true;
                                                            return
                                                              MouseRegion(
                                                                cursor: SystemMouseCursors
                                                                    .click,
                                                                child: Padding(
                                                                  padding:
                                                                  const EdgeInsets
                                                                      .only(
                                                                      top: 20),
                                                                  child: ListTile(
                                                                      mouseCursor: MouseCursor
                                                                          .defer,
                                                                      leading:
                                                                      InkWell(
                                                                        onTap:
                                                                            () {},
                                                                        child:
                                                                        MouseRegion(
                                                                          onHover: (
                                                                              f) {
                                                                            setState(
                                                                                    () {
                                                                                  isHover =
                                                                                  true;
                                                                                });
                                                                          },
                                                                          onExit:
                                                                              (
                                                                              f) {
                                                                            setState(
                                                                                    () {
                                                                                  isHover =
                                                                                  false;
                                                                                });
                                                                          },
                                                                          child:
                                                                          Container(
                                                                            height:
                                                                            40,
                                                                            width:
                                                                            40,
                                                                            decoration: BoxDecoration(
                                                                                image:
                                                                                DecorationImage(
                                                                                    image: NetworkImage(
                                                                                        list[index]
                                                                                            .profileImage ==
                                                                                            null
                                                                                            ? "https://complete.network/wp-content/uploads/default-avatar-photo-placeholder-profile-picture-vector-21806614.jpg"
                                                                                            : list[index]
                                                                                            .profileImage)),
                                                                                color: Colors
                                                                                    .grey,
                                                                                borderRadius: BorderRadius
                                                                                    .circular(
                                                                                    10)),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      title: Text(
                                                                        list[index]
                                                                            .firstname,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontWeight: FontWeight
                                                                              .w500,
                                                                          // fontSize: kIsWeb ? 14 : 12,
                                                                        ),
                                                                      ),
                                                                      subtitle: Row(
                                                                        children: [
                                                                          Text(
                                                                            "@" +
                                                                                list[index]
                                                                                    .username,
                                                                            style:
                                                                            Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                              fontWeight: FontWeight
                                                                                  .w400,
                                                                              fontSize: kIsWeb
                                                                                  ? 14
                                                                                  : 12,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            width:
                                                                            4,
                                                                          ),
                                                                          // Text(controller
                                                                          //     .listModel
                                                                          //     .data
                                                                          //     .pinnedLists[
                                                                          //         index]
                                                                          //     .username),
                                                                        ],
                                                                      ),
                                                                      trailing: ElevatedButton(
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                              shape: RoundedRectangleBorder(
                                                                                  borderRadius: BorderRadius
                                                                                      .circular(
                                                                                      30)),
                                                                              primary: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? !list[index]
                                                                                  .isFollow
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black
                                                                                  : !list[index]
                                                                                  .isFollow
                                                                                  ? Colors
                                                                                  .black
                                                                                  : Colors
                                                                                  .white

                                                                            // list[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)
                                                                          ),
                                                                          onPressed: list[index]
                                                                              .isFollow ==
                                                                              false
                                                                              ? () {
                                                                            setState(() {
                                                                              list[index]
                                                                                  .isFollow =
                                                                              true;
                                                                            });
                                                                            controller
                                                                                .unFollowRemoveMethod(
                                                                                member_id: list[index]
                                                                                    .id
                                                                                    .toString(),
                                                                                list_Id: controller
                                                                                    .selectedList
                                                                                    .listDetail
                                                                                    .id
                                                                                    .toString(),
                                                                                type: list[index]
                                                                                    .type);
                                                                          }
                                                                              : () {
                                                                            setState(() {
                                                                              list[index]
                                                                                  .isFollow =
                                                                              false;
                                                                            });
                                                                            controller
                                                                                .unFollowRemoveMethod(
                                                                                member_id: list[index]
                                                                                    .id
                                                                                    .toString(),
                                                                                list_Id: controller
                                                                                    .selectedList
                                                                                    .listDetail
                                                                                    .id
                                                                                    .toString(),
                                                                                type: list[index]
                                                                                    .type);
                                                                          },
                                                                          child: list[index]
                                                                              .isFollow ==
                                                                              false
                                                                              ? Text(
                                                                            Strings.follow,
                                                                            style: Theme
                                                                                .of(
                                                                                context)
                                                                                .textTheme
                                                                                .headline6
                                                                                .copyWith(
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .w700,
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .black
                                                                                  : Colors
                                                                                  .white,
                                                                            ),
                                                                          )
                                                                              : Text(
                                                                            Strings.unFollow,
                                                                            style: Theme
                                                                                .of(
                                                                                context)
                                                                                .textTheme
                                                                                .headline6
                                                                                .copyWith(
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .w700,
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                            ),
                                                                          ))),
                                                                ),
                                                              );
                                                          }
                                                      ),
                                                    )),
                                              ],
                                            ),
                                          ]),
                                        );
                                      },


                                    )),
                          );
                        },
                        child: Row(
                          children: [
                            Text(
                              "${controller.selectedList.listDetail
                                  .followersCount} ",
                              style: Styles.baseTextTheme.headline1.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontSize: kIsWeb ? 16.0 : 14.0,
                              ),
                            ),
                            Text(
                              Strings.followers,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                fontSize: kIsWeb ? 16.0 : 14.0,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      InkWell(
                        onTap: () async {
                          List<MemberGetModel> list = await controller
                              .getAlreadyMembers(
                              list_Id: controller.selectedList.listDetail.id
                                  .toString());

                          showDialog<String>(
                            context: context,
                            builder: (BuildContext context) =>
                                StatefulBuilder(
                                    builder: (BuildContext context,
                                        StateSetter setState) {
                                      return AlertDialog(
                                          contentPadding:
                                          const EdgeInsets.fromLTRB(
                                              0.0, 0.0, 0.0, 0.0),
                                          content: Container(
                                            height: Get.height * 0.70,
                                            width: Get.width * 0.45,
                                            child: Wrap(children: [
                                              MouseRegion(
                                                cursor: SystemMouseCursors
                                                    .click,
                                                child: Column(
                                                  children: [
                                                    ListTile(
                                                      mouseCursor: MouseCursor
                                                          .defer,
                                                      leading: IconButton(
                                                          onPressed: () {
                                                            SingleTone.instance
                                                                .selectedLocation =
                                                            null;
                                                            setState(() {});
                                                            Navigator.of(
                                                                context)
                                                                .pop();
                                                          },
                                                          icon: Icon(
                                                            Icons.close,
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          )),
                                                      title: Text(
                                                        Strings.listMembers,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2.copyWith(
                                                          color: Theme
                                                              .of(context)
                                                              .brightness ==
                                                              Brightness.dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontWeight: FontWeight
                                                              .bold,
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                        padding:
                                                        const EdgeInsets.only(
                                                            left: 2,
                                                            right: 2),
                                                        child: SizedBox(
                                                          height: Get.height *
                                                              .60,
                                                          child: list.isEmpty ?
                                                          Center(
                                                            child: Text(
                                                              Strings.noMembers,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline4
                                                                  .copyWith(
                                                                color: Theme
                                                                    .of(context)
                                                                    .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                    ? Colors
                                                                    .black
                                                                    : Colors
                                                                    .white,
                                                                fontSize: kIsWeb
                                                                    ? 14.0
                                                                    : 12,
                                                                //fontWeight: FontWeight.w500,
                                                              ),
                                                            ),)
                                                              : ListView
                                                              .builder(
                                                            itemCount:
                                                            list
                                                                .length,
                                                            itemBuilder:
                                                                (context,
                                                                index) =>
                                                                Padding(
                                                                  padding:
                                                                  const EdgeInsets
                                                                      .only(
                                                                      top: 20),
                                                                  child: ListTile(
                                                                      leading:
                                                                      InkWell(
                                                                        onTap:
                                                                            () {},
                                                                        child:
                                                                        MouseRegion(
                                                                          onHover:
                                                                              (
                                                                              f) {
                                                                            setState(
                                                                                    () {
                                                                                  isHover =
                                                                                  true;
                                                                                });
                                                                          },
                                                                          onExit:
                                                                              (
                                                                              f) {
                                                                            setState(
                                                                                    () {
                                                                                  isHover =
                                                                                  false;
                                                                                });
                                                                          },
                                                                          child:
                                                                          Container(
                                                                            height:
                                                                            40,
                                                                            width:
                                                                            40,
                                                                            decoration: BoxDecoration(
                                                                                image:
                                                                                DecorationImage(
                                                                                    image: NetworkImage(
                                                                                        list[index]
                                                                                            .profileImage ==
                                                                                            null
                                                                                            ? "https://complete.network/wp-content/uploads/default-avatar-photo-placeholder-profile-picture-vector-21806614.jpg"
                                                                                            : list[index]
                                                                                            .profileImage)),
                                                                                color: Colors
                                                                                    .grey,
                                                                                borderRadius: BorderRadius
                                                                                    .circular(
                                                                                    10)),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      title: Text(
                                                                        list[index]
                                                                            .firstname,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14.0,
                                                                          fontWeight: FontWeight
                                                                              .w500,
                                                                        ),
                                                                      ),
                                                                      subtitle: Row(
                                                                        children: [
                                                                          Expanded(
                                                                            child: Text(
                                                                              "@" +
                                                                                  list[index]
                                                                                      .username,
                                                                              style: Styles
                                                                                  .baseTextTheme
                                                                                  .headline2
                                                                                  .copyWith(
                                                                                // color: Theme.of(context).brightness == Brightness.dark
                                                                                //   ? Colors.black : Colors.white,
                                                                                fontSize: kIsWeb
                                                                                    ? 14.0
                                                                                    : 12,
                                                                                fontWeight: FontWeight
                                                                                    .w400,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            width:
                                                                            4,
                                                                          ),
                                                                          // Text(controller
                                                                          //     .listModel
                                                                          //     .data
                                                                          //     .pinnedLists[
                                                                          //         index]
                                                                          //     .username),
                                                                        ],
                                                                      ),
                                                                      trailing: ElevatedButton(
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                            shape: RoundedRectangleBorder(
                                                                                borderRadius: BorderRadius
                                                                                    .circular(
                                                                                    30)),
                                                                            primary: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? !list[index]
                                                                                .isFollow
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black
                                                                                : !list[index]
                                                                                .isFollow
                                                                                ? Colors
                                                                                .black
                                                                                : Colors
                                                                                .white,
                                                                            //   list[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)


                                                                          ),
                                                                          onPressed: list[index]
                                                                              .isFollow ==
                                                                              false
                                                                              ? () {
                                                                            setState(() {
                                                                              list[index]
                                                                                  .isFollow =
                                                                              true;
                                                                            });
                                                                            controller
                                                                                .unFollowRemoveMethod(
                                                                                member_id: list[index]
                                                                                    .id
                                                                                    .toString(),
                                                                                list_Id: controller
                                                                                    .selectedList
                                                                                    .listDetail
                                                                                    .id
                                                                                    .toString(),
                                                                                type: list[index]
                                                                                    .type);
                                                                          }
                                                                              : () {
                                                                            setState(() {
                                                                              list[index]
                                                                                  .isFollow =
                                                                              false;
                                                                            });
                                                                            controller
                                                                                .unFollowRemoveMethod(
                                                                                member_id: list[index]
                                                                                    .id
                                                                                    .toString(),
                                                                                list_Id: controller
                                                                                    .selectedList
                                                                                    .listDetail
                                                                                    .id
                                                                                    .toString(),
                                                                                type: list[index]
                                                                                    .type);
                                                                          },
                                                                          child: list[index]
                                                                              .isFollow ==
                                                                              false
                                                                              ? Text(
                                                                            Strings.follow,
                                                                            style: Theme
                                                                                .of(
                                                                                context)
                                                                                .textTheme
                                                                                .headline6
                                                                                .copyWith(
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .w700,
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .black
                                                                                  : Colors
                                                                                  .white,
                                                                            ),
                                                                          )
                                                                              : Text(
                                                                            Strings.unFollow,
                                                                            style: Theme
                                                                                .of(
                                                                                context)
                                                                                .textTheme
                                                                                .headline6
                                                                                .copyWith(
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .w700,
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                            ),
                                                                          ))),
                                                                ),
                                                          ),
                                                        )),
                                                  ],
                                                ),
                                              ),
                                            ]),
                                          ));
                                    }),

                          );
                        },
                        child: Row(
                          children: [
                            Text(
                              "${controller.selectedList.listDetail
                                  .membersCount} ",
                              style: Styles.baseTextTheme.headline1.copyWith(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? Colors
                                    .white : Colors.black,
                                fontSize: kIsWeb ? 16.0 : 14.0,
                              ),
                            ),
                            Text(
                              Strings.members,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                fontSize: kIsWeb ? 16.0 : 14.0,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),

                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  // ElevatedButton(
                  //     style: ElevatedButton.styleFrom(
                  //         shape: RoundedRectangleBorder(
                  //             borderRadius: BorderRadius.circular(30)),
                  //         primary:
                  //             isFollow ? Colors.blueAccent : Color(0xFFedab30)),
                  //     onPressed: isFollow == false
                  //         ? () {
                  //             setState(() {
                  //               isFollow = true;
                  //             });
                  //           }
                  //         : () {
                  //             setState(() {
                  //               isFollow = false;
                  //             });
                  //           },
                  //     child: isFollow == false
                  //         ? Text(
                  //             "follow",
                  //             style: Theme.of(context)
                  //                 .textTheme
                  //                 .headline6
                  //                 .copyWith(
                  //                   fontSize: 14,
                  //                   fontWeight: FontWeight.w700,
                  //                   color: Colors.white,
                  //                 ),
                  //           )
                  //         : Text(
                  //             "unfollow",
                  //             style: Theme.of(context)
                  //                 .textTheme
                  //                 .headline6
                  //                 .copyWith(
                  //                   fontSize: 14,
                  //                   fontWeight: FontWeight.w700,
                  //                   color: Colors.white,
                  //                 ),
                  //           )),
                 controller.selectedList.listDetail.userId==GetStorage().read('id') ?ElevatedButton(
                    onPressed: () async {
                      controller.userNameController.text =
                          controller.selectedList.listDetail.name;
                      controller.descriptionController.text =
                          controller.selectedList.listDetail.description;
                      kIsWeb ?

                      showDialog<String>(
                        context: context,
                        builder: (BuildContext context) =>
                            AlertDialog(
                              actions: <Widget>[
                                Container(
                                    height: Get.height * 0.70,
                                    width: Get.width * 0.45,
                                    child: StatefulBuilder(
                                        builder: (BuildContext cont,
                                            StateSetter setState) =>
                                        //  EditListScreen()
                                        ///origin code
                                        SingleChildScrollView(
                                          child: Column(
                                            children: [
                                              ListTile(
                                                  leading: IconButton(
                                                      onPressed: () {
                                                        SingleTone.instance
                                                            .selectedLocation =
                                                        null;

                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                      icon: Icon(
                                                        Icons.close,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                      )),
                                                  title: Text(
                                                    Strings.editList,
                                                    style: Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      // fontSize: 14.0,
                                                      fontWeight: FontWeight
                                                          .bold,
                                                    ),
                                                  ),
                                                  trailing:
                                                  MaterialButton(
                                                    shape: RoundedRectangleBorder(
                                                        borderRadius:
                                                        BorderRadius.circular(
                                                            15)),
                                                    color: controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    // background
                                                    textColor: Colors.white,
                                                    // foreground
                                                    onPressed: () async {
                                                      setState(() {
                                                        isLoading = true;
                                                      });
                                                      /*DataListCreated data=*/
                                                      await controller
                                                          .createList(
                                                        isChecked:
                                                        controller.isChecked,
                                                        type: "update",
                                                        listId: controller
                                                            .selectedList
                                                            .listDetail.id
                                                            .toString(),
                                                        CoverImageBytes: controller
                                                            .coverImage,
                                                        //  nameList: controller.descriptionList,
                                                        //  description: controller.descriptionList,
                                                      ).then((value) async {
                                                        controller
                                                            .selectedList =
                                                        await controller
                                                            .listDetail(
                                                            listId: value.id);
                                                        // Navigator.pop(context);

                                                        controller
                                                            .newsfeedController
                                                            .isListDetailScreen =
                                                        true;
                                                        controller
                                                            .newsfeedController
                                                            .isSearch = false;
                                                        controller
                                                            .newsfeedController
                                                            .isFilter = false;
                                                        controller
                                                            .newsfeedController
                                                            .isFilterScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isTrendsScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isNewsFeedScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isBrowseScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isNotificationScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isWhoToFollowScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isSavedPostScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isChatScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isPostDetails =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isProfileScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .searchText.text =
                                                        '';
                                                        controller
                                                            .newsfeedController
                                                            .isListScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isFollwerScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .isSettingsScreen =
                                                        false;
                                                        controller
                                                            .newsfeedController
                                                            .navRoute =
                                                        "isChatScreen";
                                                        controller
                                                            .newsfeedController
                                                            .update();


                                                        controller.update();

                                                        controller
                                                            .newsfeedController
                                                            .update();
                                                        if (value != null) {
                                                          nameList = value.name;
                                                          crateId = value.id
                                                              .toString();
                                                          controller.update();
                                                          Navigator.pop(
                                                              context);
                                                          // controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
                                                        }
                                                        setState(() {
                                                          isLoading = false;
                                                        });
                                                      });
                                                    },
                                                    child: Text(Strings.next),
                                                  )

                                              ),
                                              SizedBox(
                                                child: Column(
                                                  children: [
                                                    Container(
                                                      decoration: BoxDecoration(
                                                          image: DecorationImage(
                                                              image: controller
                                                                  .coverImage !=
                                                                  null
                                                                  ? MemoryImage(
                                                                  controller
                                                                      .coverImage)
                                                                  : NetworkImage(
                                                                  controller
                                                                      .selectedList
                                                                      .listDetail
                                                                      .coverImage ==
                                                                      null
                                                                      ? "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQMhv9rfp7W3VRIytMEiJKsXMdBtifhbYBCK14qF5q&s"
                                                                      : controller
                                                                      .selectedList
                                                                      .listDetail
                                                                      .coverImage))),
                                                      child: imageAvailable ==
                                                          false ?
                                                      Center(
                                                        child: CircleAvatar(
                                                          radius: 30,
                                                          backgroundColor: Colors
                                                              .black54,
                                                          child: IconButton(
                                                            onPressed: () async {
                                                              var image;
                                                              /* if(kIsWeb)

                                                              {
                                                                // image = await ImagePickerWeb
                                                                //    .getImageAsBytes();
                                                              }*/
                                                              controller
                                                                  .coverImage =
                                                              await controller
                                                                  .callGetImage();

                                                              print(
                                                                  "controller.coverImage ${controller
                                                                      .coverImage}");

                                                              controller
                                                                  .update();


                                                              setState(() {
                                                                imageAvailable =
                                                                true;
                                                                // // imageFile = image as Uint8List;
                                                              });
                                                              /* setState;
                                                              setState(() {
                                                                imageAvailable = true;
                                                            image  = ;

                                                                imageFile = image as Uint8List;
                                                               // controller.coverImage=imageFile;
                                                              });*/


                                                              print(
                                                                  "image agiye hai");
                                                              print(
                                                                  "controller.imageSelected ${image}");
                                                            },
                                                            icon:
                                                            Icon(
                                                              Icons
                                                                  .camera_alt,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                            splashColor:
                                                            Colors
                                                                .black,
                                                          ),

                                                        ),
                                                      ) : Stack(
                                                          children: [


                                                            Container(


                                                              // child:  Image.memory(controller.coverImage,fit: BoxFit.cover,),


                                                            ),
                                                            Positioned(
                                                              top: 0,
                                                              right: 0,
                                                              child: Padding(
                                                                  padding: EdgeInsets
                                                                      .all(8.0),
                                                                  child: Row(
                                                                    children: [
                                                                      Card(
                                                                          color: Colors
                                                                              .black26,
                                                                          shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius
                                                                                .circular(
                                                                                80),
                                                                          ),
                                                                          child: Center(
                                                                              child: IconButton(
                                                                                  onPressed: () async {
                                                                                    var image;
                                                                                    if (kIsWeb) {
                                                                                      // image = await ImagePickerWeb.getImageAsBytes();
                                                                                    }
                                                                                    controller
                                                                                        .coverImage =
                                                                                    await controller
                                                                                        .callGetImage();


                                                                                    setState;
                                                                                    setState(() {
                                                                                      imageAvailable =
                                                                                      true;
                                                                                    });

                                                                                    /* setState;
                                                                            setState(() {
                                                                              imageAvailable = true;
                                                                              controller.coverImage = image as Uint8List;
                                                                            });*/


                                                                                  },
                                                                                  icon: Icon(
                                                                                    Icons
                                                                                        .camera_alt,
                                                                                    color: Colors
                                                                                        .white,
                                                                                    size: 25,)))
                                                                      ),
                                                                      SizedBox(
                                                                        width: 10,),
                                                                      Card(
                                                                          color: Colors
                                                                              .black26,
                                                                          shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius
                                                                                .circular(
                                                                                80),
                                                                          ),
                                                                          child: Center(
                                                                              child: IconButton(
                                                                                  onPressed: () {
                                                                                    setState;
                                                                                    setState(() {
                                                                                      imageAvailable =
                                                                                      false;
                                                                                      controller
                                                                                          .coverImage =
                                                                                      null;
                                                                                    });
                                                                                  },
                                                                                  icon: Icon(
                                                                                    Icons
                                                                                        .close,
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .white
                                                                                        : Colors
                                                                                        .black,
                                                                                    size: 25,
                                                                                  )))
                                                                      ),
                                                                    ],
                                                                  )
                                                              ),),
                                                          ]),
                                                      height: Get.height * 0.20,
                                                      width: Get.width,
                                                    ),
                                                    SizedBox(
                                                      height: 20,
                                                    ),
                                                    CustomFormField(
                                                      label: Strings.name,
                                                      hintText: Strings.name,
                                                      focusBorderColor: controller
                                                          .newsfeedController
                                                          .displayColor,
                                                      labelStyle: Styles
                                                          .baseTextTheme
                                                          .headline2.copyWith(
                                                        color: controller
                                                            .newsfeedController
                                                            .displayColor,
                                                        fontWeight: FontWeight
                                                            .w400,
                                                        fontSize: kIsWeb
                                                            ? 16
                                                            : 14,
                                                      ),
                                                      controller: controller
                                                          .userNameController,
                                                      onChange: (value) {
                                                        controller.nameList =
                                                            value;
                                                        // controller.userNameController.text = value;
                                                        controller.update();
                                                        setState(() {});
                                                      },
                                                      maxLength: 25,
                                                    ),
                                                    SizedBox(
                                                      height: 20,
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets.only(
                                                          left: 15,
                                                          right: 15),
                                                      child: TextFormField(
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline2.copyWith(
                                                          color: Theme
                                                              .of(context)
                                                              .brightness ==
                                                              Brightness.dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          fontSize: kIsWeb
                                                              ? 16
                                                              : 14,

                                                        ),
                                                        controller: controller
                                                            .descriptionController,
                                                        onChanged: (value) {
                                                          controller
                                                              .descriptionList =
                                                              value;
                                                          //controller.descriptionController.text =value ;
                                                          controller.update();
                                                          setState(() {});
                                                        },
                                                        maxLines: 2,
                                                        maxLength: 100,
                                                        decoration:
                                                        InputDecoration(
                                                            border: OutlineInputBorder(
                                                                borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                    10)),
                                                            // contentPadding: const EdgeInsets.only(bottom: 30, top: 10, left: 15, right: 5),
                                                            focusedBorder: OutlineInputBorder(
                                                                borderRadius: BorderRadius
                                                                    .circular(
                                                                    10),
                                                                borderSide: BorderSide(
                                                                  color: controller
                                                                      .newsfeedController
                                                                      .displayColor,
                                                                  width: 1,
                                                                )),
                                                            filled: true,
                                                            hintText: Strings.enterDescription,
                                                            hintStyle: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(

                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontWeight: FontWeight
                                                                  .w400,

                                                              fontSize: kIsWeb
                                                                  ? 16
                                                                  : 14,

                                                            ),
                                                            fillColor: Colors
                                                                .grey[250]),
                                                        cursorColor: Colors
                                                            .blue,
                                                      ),
                                                    ),
                                                    isLoading
                                                        ? Center(
                                                      child: CircularProgressIndicator(),)
                                                        : SizedBox(),
                                                    SizedBox(
                                                      height: 30,
                                                    ),
                                                    Divider(),
                                                    SizedBox(
                                                      height: 20,
                                                    ),
                                                    InkWell(onTap: ()
                                                    // async
                                                    async {
                                                      List<
                                                          MemberGetModel> list = await controller
                                                          .getAlreadyMembers(
                                                          list_Id: controller
                                                              .selectedList
                                                              .listDetail.id
                                                              .toString());
                                                      // DataListCreated data= await controller.createList(
                                                      //     isChecked:
                                                      //     controller.isChecked,type: "update", listId:controller.selectedList.listDetail.id.toString());
                                                      // if(data != null){
                                                      //   nameList=data.name;
                                                      //   crateId=data.id.toString();
                                                      //   Navigator.pop(context);
                                                      //   controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
                                                      // }
                                                      // if (data != null) {
                                                      //   userName = controller.selectedList.listDetail.name.toString();
                                                      //   crateId =controller.selectedList.listDetail.id.toString();
                                                      //   description=controller.selectedList.listDetail.description.toString();
                                                      //   print("username......................");
                                                      //   print(userName);
                                                      //   print("id..................");
                                                      //   print(crateId);
                                                      //   print('usernmae conroller');
                                                      //   print( controller.userName);
                                                      //   print("description...........");
                                                      //   print(description);
                                                      //   controller.userName=userName;
                                                      //   controller.update();
                                                      //   controller.crateId=crateId;
                                                      //   controller.update();
                                                      //   Navigator.pop(context);
                                                      //   print('list id used in ${controller.selectedList.listDetail.id.toString()}');
                                                      //   controller.modelSuggestList=await controller.SuggestedPost(list_Id: controller.selectedList.listDetail.id.toString(), name: controller.userNameController.text);
                                                      //   controller.update();
                                                      //      }
                                                      showDialog<String>(
                                                        context: context,
                                                        builder: (
                                                            BuildContext context) =>
                                                            StatefulBuilder(
                                                                builder: (
                                                                    BuildContext context,
                                                                    StateSetter setState) {
                                                                  return
                                                                    AlertDialog(
                                                                        contentPadding: const EdgeInsets
                                                                            .fromLTRB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                        content: Container(
                                                                          height: Get
                                                                              .height *
                                                                              0.70,
                                                                          width: Get
                                                                              .width *
                                                                              0.45,
                                                                          child: SingleChildScrollView(
                                                                            child: Column(
                                                                              children: [
                                                                                ListTile(
                                                                                    leading: IconButton(
                                                                                        onPressed: () {
                                                                                          SingleTone
                                                                                              .instance
                                                                                              .selectedLocation =
                                                                                          null;
                                                                                          setState(() {});
                                                                                          Navigator
                                                                                              .of(
                                                                                              context)
                                                                                              .pop();
                                                                                        },
                                                                                        icon: Icon(
                                                                                          Icons
                                                                                              .close,
                                                                                          color: Colors
                                                                                              .black87,
                                                                                        )),
                                                                                    title: Text(
                                                                                      Strings.addToYourList,
                                                                                      style: TextStyle(
                                                                                          color: Colors
                                                                                              .black,
                                                                                          fontWeight: FontWeight
                                                                                              .w800),
                                                                                    ),
                                                                                    trailing: MaterialButton(
                                                                                      shape: RoundedRectangleBorder(
                                                                                          borderRadius: BorderRadius
                                                                                              .circular(
                                                                                              15)),
                                                                                      color: Colors
                                                                                          .grey[500],
                                                                                      // backgroundRtab
                                                                                      textColor: Colors
                                                                                          .white,
                                                                                      // foreground
                                                                                      onPressed: () async {
                                                                                        print(
                                                                                            "list create button");
                                                                                        controller
                                                                                            .selectedList =
                                                                                        await controller
                                                                                            .listDetail(
                                                                                            listId: controller
                                                                                                .selectedList
                                                                                                .listDetail
                                                                                                .id);
                                                                                        // Navigator.pop(context);

                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isListDetailScreen =
                                                                                        true;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isSearch =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isFilter =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isFilterScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isTrendsScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isNewsFeedScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isBrowseScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isNotificationScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isWhoToFollowScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isSavedPostScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isChatScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isPostDetails =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isProfileScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .searchText
                                                                                            .text =
                                                                                        '';
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isListScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isFollwerScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .isSettingsScreen =
                                                                                        false;
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .navRoute =
                                                                                        "isChatScreen";
                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .update();


                                                                                        controller
                                                                                            .update();

                                                                                        controller
                                                                                            .newsfeedController
                                                                                            .update();
                                                                                        Navigator
                                                                                            .pop(
                                                                                            context);
                                                                                      },
                                                                                      child: Text(Strings.done),
                                                                                    )),
                                                                                Container(
                                                                                  child: SingleChildScrollView(
                                                                                    child: Column(
                                                                                        crossAxisAlignment: CrossAxisAlignment
                                                                                            .stretch,
                                                                                        children: <
                                                                                            Widget>[
                                                                                          SizedBox(
                                                                                              height: 20.0),
                                                                                          DefaultTabController(
                                                                                              length: 2,
                                                                                              // length of tabs
                                                                                              initialIndex: 1,
                                                                                              child: Column(
                                                                                                  crossAxisAlignment: CrossAxisAlignment
                                                                                                      .stretch,
                                                                                                  children: <
                                                                                                      Widget>[
                                                                                                    Container(
                                                                                                      child: TabBar(
                                                                                                        labelColor: Colors
                                                                                                            .blue,
                                                                                                        unselectedLabelColor: Colors
                                                                                                            .black,
                                                                                                        tabs: [
                                                                                                          Tab(text: '${Strings.members} ${list
                                                                                                              .length}'),
                                                                                                          Tab(text: Strings.suggested),
                                                                                                        ],
                                                                                                      ),
                                                                                                    ),
                                                                                                    Container(
                                                                                                        height: Get
                                                                                                            .width *
                                                                                                            0.3,
                                                                                                        //height of TabBarView
                                                                                                        decoration: BoxDecoration(
                                                                                                            border: Border(
                                                                                                                top: BorderSide(
                                                                                                                    color: Colors
                                                                                                                        .grey,
                                                                                                                    width: 0.5))),
                                                                                                        child: TabBarView(
                                                                                                            children: <
                                                                                                                Widget>[
                                                                                                              Container(
                                                                                                                height: Get
                                                                                                                    .width *
                                                                                                                    0.27,
                                                                                                                child: SingleChildScrollView(
                                                                                                                  child: Column(
                                                                                                                    children: List
                                                                                                                        .generate(
                                                                                                                        list
                                                                                                                            .length,
                                                                                                                            (
                                                                                                                            index) =>
                                                                                                                            ListTile(
                                                                                                                                leading: Container(
                                                                                                                                  height: 40,
                                                                                                                                  width: 40,
                                                                                                                                  decoration: BoxDecoration(
                                                                                                                                      color: Colors
                                                                                                                                          .grey,
                                                                                                                                      borderRadius: BorderRadius
                                                                                                                                          .circular(
                                                                                                                                          10),
                                                                                                                                      image: DecorationImage(
                                                                                                                                          image: NetworkImage(
                                                                                                                                              list[
                                                                                                                                              index]
                                                                                                                                                  .profileImage ==
                                                                                                                                                  null
                                                                                                                                                  ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                                                                                                                                  : list[
                                                                                                                                              index]
                                                                                                                                                  .profileImage),
                                                                                                                                          fit: BoxFit
                                                                                                                                              .fill)),
                                                                                                                                ),
                                                                                                                                title: Text(
                                                                                                                                    list[index]
                                                                                                                                        .firstname),
                                                                                                                                subtitle: Row(
                                                                                                                                  children: [
                                                                                                                                    Text(
                                                                                                                                        "@" +
                                                                                                                                            list[index]
                                                                                                                                                .username),
                                                                                                                                    SizedBox(
                                                                                                                                      width: 4,
                                                                                                                                    ),
                                                                                                                                    // Text(controller
                                                                                                                                    //     .addMemberList[index]
                                                                                                                                    //     .username),
                                                                                                                                  ],
                                                                                                                                ),
                                                                                                                                trailing: ElevatedButton(
                                                                                                                                    style: ElevatedButton
                                                                                                                                        .styleFrom(
                                                                                                                                        shape: RoundedRectangleBorder(
                                                                                                                                            borderRadius: BorderRadius
                                                                                                                                                .circular(
                                                                                                                                                30)),
                                                                                                                                        primary: Colors
                                                                                                                                            .blueAccent),
                                                                                                                                    onPressed:

                                                                                                                                    //     :
                                                                                                                                        () {
                                                                                                                                      setState(() {
                                                                                                                                        // isFollow = false;

                                                                                                                                        print(
                                                                                                                                            "index >>>>>>>>>>>>>>>>>>>>>>>>$index");


                                                                                                                                        if (controller
                                                                                                                                            .modelSuggestList
                                                                                                                                            .isNotEmpty) {
                                                                                                                                          controller
                                                                                                                                              .modelSuggestList
                                                                                                                                              .forEach((
                                                                                                                                              element) {
                                                                                                                                            if (element
                                                                                                                                                .id ==
                                                                                                                                                list[index]
                                                                                                                                                    .memberFollowerId) {
                                                                                                                                              element
                                                                                                                                                  .isFollow =
                                                                                                                                              false;
                                                                                                                                            }
                                                                                                                                          });
                                                                                                                                        }


                                                                                                                                        // controller
                                                                                                                                        //     .update();
                                                                                                                                        // controller
                                                                                                                                        //     .update([
                                                                                                                                        //   "edit_suggestion"
                                                                                                                                        // ]);
                                                                                                                                        // controller.deletePost(controller.addMemberList[index].id);
                                                                                                                                        // dataList.remove(
                                                                                                                                        //     controller.  listOfDiscover[index]);
                                                                                                                                      });
                                                                                                                                      controller
                                                                                                                                          .update();
                                                                                                                                      controller
                                                                                                                                          .update(
                                                                                                                                          [
                                                                                                                                            "edit_suggestion"
                                                                                                                                          ]);
                                                                                                                                      controller
                                                                                                                                          .unFollowRemoveMethod(
                                                                                                                                          list_Id: controller
                                                                                                                                              .selectedList
                                                                                                                                              .listDetail
                                                                                                                                              .id
                                                                                                                                              .toString(),
                                                                                                                                          member_id: list[index]
                                                                                                                                              .memberFollowerId
                                                                                                                                              .toString(),
                                                                                                                                          type: "member");
                                                                                                                                      list
                                                                                                                                          .removeAt(
                                                                                                                                          index);
                                                                                                                                      setState(() {});
                                                                                                                                      // controller.addMemberList.removeAt(i);
                                                                                                                                    },
                                                                                                                                    child:
                                                                                                                                    // isFollow == false
                                                                                                                                    //     ? Text(
                                                                                                                                    //   "Add",
                                                                                                                                    //   style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                                                                    //     fontSize: 14,
                                                                                                                                    //     fontWeight: FontWeight.w700,
                                                                                                                                    //     color: Colors.white,
                                                                                                                                    //   ),
                                                                                                                                    // )
                                                                                                                                    //     :
                                                                                                                                    Text(
                                                                                                                                      Strings.remove,
                                                                                                                                      style: Theme
                                                                                                                                          .of(
                                                                                                                                          context)
                                                                                                                                          .textTheme
                                                                                                                                          .headline6
                                                                                                                                          .copyWith(
                                                                                                                                        fontSize: 14,
                                                                                                                                        fontWeight: FontWeight
                                                                                                                                            .w700,
                                                                                                                                        color: Colors
                                                                                                                                            .white,
                                                                                                                                      ),
                                                                                                                                    )))),
                                                                                                                  ),
                                                                                                                ),
                                                                                                              ),
                                                                                                              Container(
                                                                                                                child: SingleChildScrollView(
                                                                                                                  child: Column(
                                                                                                                    children: [
                                                                                                                      Padding(
                                                                                                                        padding: EdgeInsets
                                                                                                                            .only(
                                                                                                                            top: 10,
                                                                                                                            right: 10,
                                                                                                                            bottom: 10,
                                                                                                                            left: 10),
                                                                                                                        child: TextField(
                                                                                                                          style: LightStyles
                                                                                                                              .baseTextTheme
                                                                                                                              .headline2
                                                                                                                              .copyWith(
                                                                                                                            color: Theme
                                                                                                                                .of(
                                                                                                                                context)
                                                                                                                                .brightness ==
                                                                                                                                Brightness
                                                                                                                                    .dark
                                                                                                                                ? Colors
                                                                                                                                .white
                                                                                                                                : Colors
                                                                                                                                .black,
                                                                                                                            // fontWeight: FontWeight.bold,
                                                                                                                          ),
                                                                                                                          autofocus: true,
                                                                                                                          // controller: controller.chatSearchTEC,
                                                                                                                          // focusNode: controller.chatSearchTextFocus,
                                                                                                                          onChanged: (
                                                                                                                              value) async {
                                                                                                                            controller
                                                                                                                                .modelSuggestList =
                                                                                                                            await controller
                                                                                                                                .SuggestedPost(
                                                                                                                                list_Id: controller
                                                                                                                                    .selectedList
                                                                                                                                    .listDetail
                                                                                                                                    .id
                                                                                                                                    .toString(),
                                                                                                                                name: value);
                                                                                                                            setState(() {});
                                                                                                                          },
                                                                                                                          textAlignVertical: TextAlignVertical
                                                                                                                              .center,
                                                                                                                          decoration: InputDecoration(
                                                                                                                            hintText: Strings
                                                                                                                                .searchPeople,
                                                                                                                            hintStyle: LightStyles
                                                                                                                                .baseTextTheme
                                                                                                                                .headline2,
                                                                                                                            prefixIcon: Icon(
                                                                                                                              Icons
                                                                                                                                  .search,
                                                                                                                              size: 20,
                                                                                                                              color: Theme
                                                                                                                                  .of(
                                                                                                                                  context)
                                                                                                                                  .brightness ==
                                                                                                                                  Brightness
                                                                                                                                      .dark
                                                                                                                                  ? Colors
                                                                                                                                  .white
                                                                                                                                  : Colors
                                                                                                                                  .black,
                                                                                                                            ),
                                                                                                                            border: OutlineInputBorder(
                                                                                                                              borderRadius: BorderRadius
                                                                                                                                  .circular(
                                                                                                                                  40),
                                                                                                                              borderSide: BorderSide(
                                                                                                                                width: 1,
                                                                                                                                color: Colors
                                                                                                                                    .grey,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                            enabledBorder: OutlineInputBorder(
                                                                                                                              borderRadius: BorderRadius
                                                                                                                                  .circular(
                                                                                                                                  40),
                                                                                                                              borderSide: BorderSide(
                                                                                                                                width: 1,
                                                                                                                                color: Colors
                                                                                                                                    .grey,
                                                                                                                              ),
                                                                                                                            ),
                                                                                                                            fillColor: Colors
                                                                                                                                .grey[250],
                                                                                                                          ),
                                                                                                                        ),
                                                                                                                      ),

                                                                                                                      SizedBox(
                                                                                                                        height: Get
                                                                                                                            .width *
                                                                                                                            0.25,
                                                                                                                        child: controller
                                                                                                                            .modelSuggestList
                                                                                                                            .isEmpty ||
                                                                                                                            controller
                                                                                                                                .modelSuggestList ==
                                                                                                                                null
                                                                                                                            ? Center(
                                                                                                                          child: Padding(
                                                                                                                            padding: const EdgeInsets
                                                                                                                                .only(
                                                                                                                                top: 20.0),
                                                                                                                            child: Text(
                                                                                                                                Strings.noResults),
                                                                                                                          ),)
                                                                                                                            : SingleChildScrollView(
                                                                                                                            child: Column(
                                                                                                                              children: List
                                                                                                                                  .generate(
                                                                                                                                  controller
                                                                                                                                      .modelSuggestList
                                                                                                                                      .length,
                                                                                                                                      (
                                                                                                                                      index) =>
                                                                                                                                      ListTile(
                                                                                                                                          leading: Container(
                                                                                                                                            height: 40,
                                                                                                                                            width: 40,
                                                                                                                                            decoration: BoxDecoration(
                                                                                                                                                color: Colors
                                                                                                                                                    .grey,
                                                                                                                                                borderRadius: BorderRadius
                                                                                                                                                    .circular(
                                                                                                                                                    10),
                                                                                                                                                image: DecorationImage(
                                                                                                                                                    image: NetworkImage(
                                                                                                                                                        controller
                                                                                                                                                            .modelSuggestList[index]
                                                                                                                                                            .authorProfileImage ==
                                                                                                                                                            null
                                                                                                                                                            ?
                                                                                                                                                        "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                                                                                                                            : controller
                                                                                                                                                            .modelSuggestList[index]
                                                                                                                                                            .authorProfileImage
                                                                                                                                                    ),
                                                                                                                                                    fit: BoxFit
                                                                                                                                                        .fill)),
                                                                                                                                          ),
                                                                                                                                          title: Text(
                                                                                                                                              controller
                                                                                                                                                  .modelSuggestList[index]
                                                                                                                                                  .username),
                                                                                                                                          subtitle: Row(
                                                                                                                                            children: [
                                                                                                                                              Text(
                                                                                                                                                  controller
                                                                                                                                                      .modelSuggestList[index]
                                                                                                                                                      .authorName),
                                                                                                                                              SizedBox(
                                                                                                                                                width: 4,
                                                                                                                                              ),
                                                                                                                                              Text(
                                                                                                                                                  controller
                                                                                                                                                      .modelSuggestList[index]
                                                                                                                                                      .username),
                                                                                                                                            ],
                                                                                                                                          ),

                                                                                                                                          ///idhr kerna kam
                                                                                                                                          trailing:
                                                                                                                                          ElevatedButton(
                                                                                                                                              style: ElevatedButton
                                                                                                                                                  .styleFrom(
                                                                                                                                                shape: RoundedRectangleBorder(
                                                                                                                                                    borderRadius: BorderRadius
                                                                                                                                                        .circular(
                                                                                                                                                        30)),
                                                                                                                                                primary: Theme
                                                                                                                                                    .of(
                                                                                                                                                    context)
                                                                                                                                                    .brightness ==
                                                                                                                                                    Brightness
                                                                                                                                                        .dark
                                                                                                                                                    ? !controller
                                                                                                                                                    .modelSuggestList[index]
                                                                                                                                                    .isFollow
                                                                                                                                                    ? Colors
                                                                                                                                                    .white
                                                                                                                                                    : Colors
                                                                                                                                                    .black
                                                                                                                                                    : !controller
                                                                                                                                                    .modelSuggestList[index]
                                                                                                                                                    .isFollow
                                                                                                                                                    ? Colors
                                                                                                                                                    .black
                                                                                                                                                    : Colors
                                                                                                                                                    .white,


                                                                                                                                                //  controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)


                                                                                                                                              ),
                                                                                                                                              onPressed: controller
                                                                                                                                                  .modelSuggestList[index]
                                                                                                                                                  .isFollow ==
                                                                                                                                                  false
                                                                                                                                                  ? () async {
                                                                                                                                                controller
                                                                                                                                                    .modelSuggestList[index]
                                                                                                                                                    .isFollow =
                                                                                                                                                true;
                                                                                                                                                setState(() {});

                                                                                                                                                MemberGetModel member = MemberGetModel();
                                                                                                                                                member
                                                                                                                                                    .username =
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .username;
                                                                                                                                                member
                                                                                                                                                    .id =
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .id;
                                                                                                                                                member
                                                                                                                                                    .firstname =
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .authorName;
                                                                                                                                                member
                                                                                                                                                    .listId =
                                                                                                                                                    controller
                                                                                                                                                        .selectedList
                                                                                                                                                        .listDetail
                                                                                                                                                        .id;
                                                                                                                                                member
                                                                                                                                                    .profileImage =
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .authorProfileImage;
                                                                                                                                                list
                                                                                                                                                    .add(
                                                                                                                                                    member);

                                                                                                                                                controller
                                                                                                                                                    .update(
                                                                                                                                                    [
                                                                                                                                                      "edit_suggestion"
                                                                                                                                                    ]);
                                                                                                                                                controller
                                                                                                                                                    .update();


                                                                                                                                                controller
                                                                                                                                                    .memberAdd(
                                                                                                                                                    controller
                                                                                                                                                        .selectedList
                                                                                                                                                        .listDetail
                                                                                                                                                        .id
                                                                                                                                                        .toString(),
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .id,
                                                                                                                                                    "member");
                                                                                                                                              }
                                                                                                                                                  : () {
                                                                                                                                                controller
                                                                                                                                                    .modelSuggestList[index]
                                                                                                                                                    .isFollow ==
                                                                                                                                                    false;

                                                                                                                                                controller
                                                                                                                                                    .modelSuggestList
                                                                                                                                                    .forEach((
                                                                                                                                                    element) {
                                                                                                                                                  if (element
                                                                                                                                                      .id ==
                                                                                                                                                      controller
                                                                                                                                                          .modelSuggestList[index]
                                                                                                                                                          .id) {
                                                                                                                                                    element
                                                                                                                                                        .isFollow =
                                                                                                                                                    false;
                                                                                                                                                  }
                                                                                                                                                });
                                                                                                                                                for (int i = 0; i <

                                                                                                                                                    list
                                                                                                                                                        .length; i++) {
                                                                                                                                                  if (list[i]
                                                                                                                                                      .id ==
                                                                                                                                                      controller
                                                                                                                                                          .modelSuggestList[index]
                                                                                                                                                          .id) {
                                                                                                                                                    list
                                                                                                                                                        .removeAt(
                                                                                                                                                        i);
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                                controller
                                                                                                                                                    .update(
                                                                                                                                                    [
                                                                                                                                                      "edit_suggestion"
                                                                                                                                                    ]);
                                                                                                                                                controller
                                                                                                                                                    .update();

                                                                                                                                                controller
                                                                                                                                                    .deletePost(
                                                                                                                                                    controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .id);
                                                                                                                                                // dataList.remove(
                                                                                                                                                //     controller.  listOfDiscover[index]);


                                                                                                                                                controller
                                                                                                                                                    .update(
                                                                                                                                                    [
                                                                                                                                                      "edit_suggestion"
                                                                                                                                                    ]);
                                                                                                                                                controller
                                                                                                                                                    .update();
                                                                                                                                                controller
                                                                                                                                                    .unFollowRemoveMethod(
                                                                                                                                                    list_Id: controller
                                                                                                                                                        .selectedList
                                                                                                                                                        .listDetail
                                                                                                                                                        .id
                                                                                                                                                        .toString(),
                                                                                                                                                    member_id: controller
                                                                                                                                                        .modelSuggestList[index]
                                                                                                                                                        .id
                                                                                                                                                        .toString(),
                                                                                                                                                    type: "member");
                                                                                                                                              },
                                                                                                                                              child: controller
                                                                                                                                                  .modelSuggestList[index]
                                                                                                                                                  .isFollow ==
                                                                                                                                                  false
                                                                                                                                                  ? Text(
                                                                                                                                                Strings.add,
                                                                                                                                                style: Theme
                                                                                                                                                    .of(
                                                                                                                                                    context)
                                                                                                                                                    .textTheme
                                                                                                                                                    .headline6
                                                                                                                                                    .copyWith(
                                                                                                                                                  fontSize: 14,
                                                                                                                                                  fontWeight: FontWeight
                                                                                                                                                      .w700,
                                                                                                                                                  color: Theme
                                                                                                                                                      .of(
                                                                                                                                                      context)
                                                                                                                                                      .brightness ==
                                                                                                                                                      Brightness
                                                                                                                                                          .dark
                                                                                                                                                      ? Colors
                                                                                                                                                      .black
                                                                                                                                                      : Colors
                                                                                                                                                      .white,
                                                                                                                                                ),
                                                                                                                                              )
                                                                                                                                                  : Text(
                                                                                                                                                Strings.remove,
                                                                                                                                                style: Theme
                                                                                                                                                    .of(
                                                                                                                                                    context)
                                                                                                                                                    .textTheme
                                                                                                                                                    .headline6
                                                                                                                                                    .copyWith(
                                                                                                                                                  fontSize: 14,
                                                                                                                                                  fontWeight: FontWeight
                                                                                                                                                      .w700,
                                                                                                                                                  color: Theme
                                                                                                                                                      .of(
                                                                                                                                                      context)
                                                                                                                                                      .brightness ==
                                                                                                                                                      Brightness
                                                                                                                                                          .dark
                                                                                                                                                      ? Colors
                                                                                                                                                      .white
                                                                                                                                                      : Colors
                                                                                                                                                      .black,
                                                                                                                                                ),
                                                                                                                                              )))),
                                                                                                                            )),
                                                                                                                      ),
                                                                                                                    ],
                                                                                                                  ),
                                                                                                                ),
                                                                                                              ),
                                                                                                            ]))
                                                                                                  ])),
                                                                                        ]),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ))
                                                                  ;
                                                                }),

                                                      );
                                                    },
                                                      child
                                                          : Padding(
                                                        padding: const EdgeInsets
                                                            .only(left: 20,
                                                            right: 20),
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment
                                                              .spaceBetween,
                                                          children: [
                                                            Text(
                                                              Strings.manageMembers,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline2
                                                                  .copyWith(
                                                                color: Theme
                                                                    .of(context)
                                                                    .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                    ? Colors
                                                                    .white
                                                                    : Colors
                                                                    .black,
                                                                fontWeight: FontWeight
                                                                    .w500,
                                                                fontSize: 16,
                                                              ),

                                                            ),
                                                            Icon(
                                                              Icons
                                                                  .arrow_forward_ios_outlined,
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness
                                                                      .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                  .black,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      height: 30,
                                                    ),
                                                    controller.isDelete
                                                        ? Center(
                                                      child:
                                                      CircularProgressIndicator(
                                                          color: MyColors
                                                              .BlueColor),
                                                    )
                                                        : ElevatedButton(
                                                      onPressed: () async {
                                                        // setState(() {
                                                        controller
                                                            .isDelete =
                                                        true;
                                                        // });
                                                        print(
                                                            "delete post ......>>>>>>>>>>>>>>>>${controller
                                                                .selectedList
                                                                .listDetail
                                                                .id}");
                                                        controller.deletePost(
                                                            controller
                                                                .selectedList
                                                                .listDetail.id);
                                                        // setState(()  {
                                                        controller.isDelete =
                                                        false;
                                                        // });
                                                        controller.listModel
                                                            .data.lists
                                                            .removeAt(int.parse(
                                                            widget.index));
                                                        // controller.selectedList = await controller.listDetail(listId : controller.selectedList.listDetail.id);
                                                        widget
                                                            .newsfeedController
                                                            .update();
                                                        controller.update();
                                                        Navigator.pop(context);
                                                        Navigator.pop(context);

                                                        // await controller.getListData();
                                                        // controller.update();
                                                        print(
                                                            "delete  ......>>>>>>>>>>>>>>>>");
                                                      },
                                                      child: Text(Strings.delete),
                                                      style: ElevatedButton
                                                          .styleFrom(
                                                        padding: EdgeInsets
                                                            .symmetric(
                                                            horizontal: 25,
                                                            vertical: 10),
                                                        backgroundColor: controller
                                                            .newsfeedController
                                                            .displayColor,
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius
                                                              .all(
                                                              Radius.circular(
                                                                  8)),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        )

                                      /// origin code
                                    )

                                )
                              ],
                            ),
                      ) : Get.to(EditListScreen());
                      ;
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.only(
                          left: 40, right: 40, bottom: 5, top: 5),
                      primary: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.black : Colors
                          .white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                          side: BorderSide(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.grey,
                            width: 0.5,
                          )
                      ),
                    ),
                    child: Text(
                      Strings.edit,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ):const SizedBox(),
                  SizedBox(
                    height: 10,
                  ),
                  Divider(
                    color: Colors.black12,
                    thickness: 0.9,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  controller.selectedList.newsfeed.isEmpty
                      ? Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 30.0),
                        child: Text(
                         Strings.noWerfs,
                          style: Styles.baseTextTheme.headline4.copyWith(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: kIsWeb ? 14 : 12
                          ),
                        ),
                      ))
                      : Column(
                    children: List.generate(
                      controller.selectedList.newsfeed.length,
                          (index) =>
                          PostCard(
                            postList: controller.selectedList.newsfeed,
                            post: controller.selectedList.newsfeed[index],
                            scaffoldKey: _scaffoldKey,
                            index: index,
                            controller: controller.newsfeedController,
                            postChangeStatus: (bool value) async {
                              if(value){
                                debugPrint('updating list status');
                                await controller.listDetail(listId: controller
                                    .listModel
                                    .data
                                    .lists[int.parse(widget.index)]
                                    .id, isFromRoute: false);
                              }
                             }
                          ),
                    ),
                  )
                ],
              ),
            )),
      );
    });
  }
}

