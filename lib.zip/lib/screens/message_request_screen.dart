import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/privacy_and_safety/direct_messages/direct_messages_setting_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../network/controller/news_feed_controller.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import '../widgets/chat_screen_mobile.dart';

class MessageRequestScreen extends StatelessWidget {

  final bool isFromMessagePopup;

  const MessageRequestScreen({Key key, this.isFromMessagePopup = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
        builder: (controller){
        return Scaffold(
          appBar: !isFromMessagePopup ? AppBar(
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: Icon(Icons.arrow_back),
              color: Colors.black,
              onPressed: () async {
                if(kIsWeb){
                  //Get.toNamed(FluroRouters.mainScreen + '/chats');
                  controller.chatUserList = await controller.getChat();

                  controller.isRequestScreen = false;
                  controller.isChatScreenWeb = false;
                  Get.back();
                  controller.update();
                  // controller.navRoute = "isChatScreen";

                  //Get.toNamed(FluroRouters.mainScreen + '/chats');
                  controller.update();

                }else{
                  Get.back();
                }

              },
            ),
            title: Text(Strings.messageRequests,
              style: TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
            elevation: kIsWeb?0:5,
            actions: [
              IconButton(
                icon: Icon(Icons.settings,
                color: Colors.black,),
                onPressed: ()async {
                  controller.isComingFromlocationScreen = false;
                  controller.isListOfBlockedAccounts =
                  false;
                  controller.isTranslations = false;
                  controller.isLanguageSettings =
                  false;
                  controller.isLanguageType = false;
                  controller.isAccountPrivacy = false;
                  controller.isProfileLanguagetype =
                  false;
                  controller.isAccountPrivacySettings =
                  false;
                  controller.isChangeUserName = false;
                  controller.isSettingDetail = false;
                  controller.isAccountInformation =
                  false;
                  controller.isChangeUserName = false;
                  controller.isChangeEmail = false;
                  controller.isChangeCountry = false;
                  controller.isSettinggender = false;
                  controller.isYourAccount = false;
                  controller.isAccountPrivacy = false;
                  controller.isPhotoTagging = false;
                  controller.isAudienceTagging = false;
                  controller.isYourWerfs = false;
                  controller.isContentYouSee = false;
                  controller.isMuteAndBlock = false;
                  controller.isDirectMessage = true;
                  controller.update();
                  !kIsWeb
                      ?
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) =>
                              DirectMessageSettingScreen()))
                      : Container();},
              ),
            ],
          ) : null,
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(Strings.messageRequestsFallHere,
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.black54
                  ),
                ),
              ),
              controller == null || controller.chatRequestUserList ==null?
                  Center(
                    child: Text(Strings.noMessageRequestAvailable,
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black54
                      ),
                    ),
                  ):
              ListView.separated(
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemCount:
                controller.chatRequestUserList.length,
                itemBuilder: (context, index) {
                  String getChatDate;
                  getChatDate = controller
                      .chatRequestUserList[index]
                      .latestMessageTime ==
                      null
                      ? ""
                      : UtilsMethods.getChatDate(
                      controller
                          .chatRequestUserList[index]
                          .latestMessageTime);

                  String ChatUserName = controller
                      .chatRequestUserList[index].username;
                  //   String ChatUserName = controller.chatRequestUserList[index].username;
                  String chatAuthorName = controller
                      .chatRequestUserList[index].name;
                  return Slidable(
                    endActionPane: ActionPane(
                      extentRatio: 0.3,
                      closeThreshold: 0.5,
                      motion: ScrollMotion(),
                      children: [
                        SlidableAction(
                          onPressed:
                              (context) async {
                            await controller
                                .leaveConversation(
                                controller
                                    .chatRequestUserList[
                                index]
                                    .conversationId);
                            controller
                                .chatRequestUserList =
                            await controller
                                .getMessageRequest();
                            controller.update();
                          },
                          backgroundColor:
                          Color(0xFFFE4A49),
                          foregroundColor:
                          Colors.white,
                          icon: Icons.delete,
                          label: Strings.delete,
                        ),
                      ],
                    ),
                    child: Padding(
                      padding:
                      const EdgeInsets.only(
                          top: 0.0,
                          left: 0,
                          right: 0,
                          bottom: 0),
                      child: InkWell(
                        onTap: () async{
                          if(kIsWeb){
                            controller
                                .isImagePickedChat =
                            false;
                            controller
                                .isVideoPickedChat =
                            false;
                            controller
                                .isDocumentPickedChat =
                            false;
                            controller
                                .messageController
                                .clear();
                            controller.showOverlay =
                            false;
                            controller.chatName =
                            controller
                                .chatRequestUserList[
                            index];
                            controller
                                .groupName = controller
                                .chatName
                                .conversationType ==
                                "group"
                                ? "${controller.chatName.name}"
                                : "${controller.chatName.name}";

                            // controller.update();
                            print("pressed");
                            controller.getMessagesOfAConversation(
                                controller.chatName
                                    .conversationId);
                            controller
                                .isVideoThumbnail =
                            false;
                            controller
                                .videoThumbnail =
                            null;
                            controller.chatIndex =
                                index;

                            controller.tempGroupName =
                            "";
                            controller
                                .tempProfileImageGroupChat =
                            null;
                            controller.infoChatInfo = false;
                            if(isFromMessagePopup) controller.isMessagePopupRequestChatSelected = true;
                            controller.isChatScreenWeb=true;
                            controller.chatUserList =await controller.getChat();

                            controller.update();

                            controller.update();
                          }
                          else{
                            controller
                                .isImagePickedChat =
                            false;
                            controller
                                .isVideoPickedChat =
                            false;
                            controller
                                .isDocumentPickedChat =
                            false;
                            controller
                                .messageController
                                .clear();
                            controller.showOverlay =
                            false;
                            controller.chatName =
                            controller
                                .chatRequestUserList[
                            index];
                            controller
                                .groupName = controller
                                .chatName
                                .conversationType ==
                                "group"
                                ? "${controller.chatName.name}"
                                : "${controller.chatName.name}";

                            // controller.update();
                            print("pressed");
                            controller.getMessagesOfAConversation(
                                controller.chatName
                                    .conversationId);
                            controller
                                .isVideoThumbnail =
                            false;
                            controller
                                .videoThumbnail =
                            null;
                            controller.chatIndex =
                                index;

                            controller.tempGroupName =
                            "";
                            controller
                                .tempProfileImageGroupChat =
                            null;

                            controller.update();

                            controller.update();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    ChatScreenMobile(
                                        controller, true),
                              ),
                            );
                          }

                        },
                        child: Card(
                          elevation: 0,
                          margin:
                          EdgeInsets.symmetric(
                              horizontal: 0),
                          child: Padding(
                            padding:
                            const EdgeInsets
                                .symmetric(
                                horizontal:
                                14.0,
                                vertical: 12),
                            child: Row(
                              children: [
                                controller
                                    .chatRequestUserList[
                                index]
                                    .conversationType !=
                                    "group"
                                    ? CircleAvatar(
                                  backgroundImage: controller.chatRequestUserList[index].profileImage !=
                                      null
                                      ? NetworkImage(controller
                                      .chatRequestUserList[
                                  index]
                                      .profileImage)
                                      : AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  radius: 22,
                                )
                                    : CircleAvatar(
                                  backgroundImage: controller.chatRequestUserList[index].groupImage !=
                                      null
                                      ? NetworkImage(controller
                                      .chatRequestUserList[
                                  index]
                                      .groupImage)
                                      : AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  radius: 22,
                                ),
                                SizedBox(
                                  width: 20,
                                ),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,
                                    mainAxisAlignment:
                                    MainAxisAlignment
                                        .spaceEvenly,
                                    children: [
                                      FittedBox(
                                        child: Row(
                                          children: [
                                            controller.chatRequestUserList[index].conversationType ==
                                                "group"
                                                ? controller.chatRequestUserList[index].name != null
                                                ? Container(
                                              width: chatAuthorName.length > 10 ? 85 : null,
                                              child: Text(
                                                "${chatAuthorName}",
                                                overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4.copyWith(
                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            )
                                                : controller.chatRequestUserList[index].members.length == 1
                                                ? FittedBox(
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                      child: Text(
                                                        "${controller.chatRequestUserList[index].members[0].firstname}",
                                                        overflow: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                        maxLines: 1,
                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ))
                                                : controller.chatRequestUserList[index].members.length == 2
                                                ? FittedBox(
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                      child: Text(
                                                        "${controller.chatRequestUserList[index].members[0].firstname}, ",
                                                        overflow: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                        maxLines: 1,
                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: controller.chatRequestUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                      child: Text(
                                                        "${controller.chatRequestUserList[index].members[1].firstname}",
                                                        overflow: controller.chatRequestUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                        maxLines: 1,
                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ))
                                                : controller.chatRequestUserList[index].members.length == 3
                                                ? FittedBox(
                                              child: Row(
                                                children: [
                                                  Container(
                                                    width: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                    child: Text(
                                                      "${controller.chatRequestUserList[index].members[0].firstname}, ",
                                                      overflow: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                      maxLines: 1,
                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                        fontSize: 15,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    "${controller.chatRequestUserList[index].members.length - 1} ${Strings.otherChat}",
                                                    style: Styles.baseTextTheme.headline4.copyWith(
                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )
                                                : controller.chatRequestUserList[index].members.length >= 4
                                                ? FittedBox(
                                                child: Row(
                                                  children: [
                                                    Container(
                                                      width: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                                      child: Text(
                                                        "${controller.chatRequestUserList[index].members[0].firstname}, ",
                                                        overflow: controller.chatRequestUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                        maxLines: 1,
                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: controller.chatRequestUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                                      child: Text(
                                                        "${controller.chatRequestUserList[index].members[1].firstname}, ",
                                                        overflow: controller.chatRequestUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                                        maxLines: 1,
                                                        style: Styles.baseTextTheme.headline4.copyWith(
                                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          fontSize: 15,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      "${controller.chatRequestUserList[index].members.length - 2} ${Strings.otherChat}",
                                                      style: Styles.baseTextTheme.headline4.copyWith(
                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                        fontSize: 15,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ],
                                                ))
                                                : SizedBox()
                                                : SizedBox(),

                                            controller.chatRequestUserList[index].conversationType ==
                                                "single"
                                                ? Container(
                                              width: chatAuthorName.length > 10 ? 85 : null,
                                              child: Text(
                                                "${chatAuthorName}",
                                                overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline4.copyWith(
                                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            )
                                                : SizedBox(),

                                            // controller.chatRequestUserList[index].accountVerified =="verified"?
                                            // Row(children: [
                                            //   SizedBox(
                                            //     width: 5,
                                            //   ),
                                            //   BlueTick(
                                            //     height: 15,
                                            //     width: 15,
                                            //     iconSize:10,
                                            //   ),
                                            // ],):SizedBox()
                                            controller.chatRequestUserList[index].conversationType ==
                                                "group"
                                                ? Text(
                                              Strings.groupsTabChat,
                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                fontWeight: FontWeight.w400,
                                                fontSize: 15,
                                              ),
                                            )
                                                : controller.chatRequestUserList[index].conversationType == "single"
                                                ? Container(
                                              width: ChatUserName.length > 15 ? 100 : null,
                                              child: Text(
                                                "@${ChatUserName}",
                                                overflow: ChatUserName.length > 15 ? TextOverflow.ellipsis : null,
                                                softWrap: false,
                                                maxLines: 1,
                                                style: Styles.baseTextTheme.headline2.copyWith(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 15,
                                                ),
                                              ),
                                            )
                                                : SizedBox(),
                                            controller.chatRequestUserList[index].latestMessageTime ==
                                                null
                                                ? SizedBox()
                                                : Row(
                                              children: [
                                                SizedBox(
                                                  width: 2,
                                                ),
                                                Text(
                                                  ".",
                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 2,
                                                ),
                                                Text(
                                                  getChatDate == null ? "" : getChatDate,
                                                  overflow: TextOverflow.ellipsis,
                                                  maxLines: 1,
                                                  style: Styles.baseTextTheme.headline2.copyWith(
                                                    fontSize: 15,
                                                    fontWeight: FontWeight.w400,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),

                                      Text(
                                        controller.chatRequestUserList[index].latest_message_type ==
                                            1
                                            ? controller
                                            .chatRequestUserList[
                                        index]
                                            .latestMessage
                                            : controller.chatRequestUserList[index].latest_message_type ==
                                            2
                                            ? Strings.photoChat
                                            : controller.chatRequestUserList[index].latest_message_type == 3
                                            ? Strings.videoChat
                                            : controller.chatRequestUserList[index].latest_message_type == 9
                                            ? Strings.fileChat
                                            : '',
                                        overflow:
                                        TextOverflow
                                            .ellipsis,
                                        maxLines: 1,
                                        style: Styles
                                            .baseTextTheme
                                            .headline2
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors
                                              .white
                                              : Colors
                                              .black,
                                          fontSize:
                                          15,
                                          fontWeight:
                                          FontWeight
                                              .w400,
                                        ),
                                      ),
                                      // SizedBox(
                                      //   width: kIsWeb
                                      //       ? 150
                                      //       : MediaQuery.of(context)
                                      //               .size
                                      //               .width *
                                      //           0.65,
                                      //   child: Text(
                                      //     controller.chatRequestUserList[index].latestMessage == null
                                      //         ? ""
                                      //         : controller
                                      //             .chatRequestUserList[index]
                                      //             .latestMessage,
                                      //     overflow:
                                      //         TextOverflow
                                      //             .ellipsis,
                                      //     maxLines: 1,
                                      //     style: Styles.baseTextTheme.headline4.copyWith(
                                      //       color: Theme.of(context).brightness == Brightness.dark ? Colors.white: Colors.black,
                                      //       fontSize: 14,
                                      //     ),
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                        onPressed: () {
                                          controller.AcceptRejectMessageRequest(
                                              controller
                                                  .chatName.conversationId,
                                              0.toString());
                                        },
                                        icon: Icon(Icons.cancel_outlined),
                                        color: Colors.black,
                                      )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
                separatorBuilder: (_, __) {
                  return Container(
                    height: 0.5,
                    color: Colors.grey[300],
                  );
                },
              ),
            ],
          ),
        );
        }
    );
  }
}
