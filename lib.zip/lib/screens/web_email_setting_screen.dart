import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/password_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/custom_text_button_with_icon.dart';
import '../network/controller/profile_controller.dart';
import '../utils/font.dart';

// ignore: must_be_immutable
class WebEmailSettingScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  TextEditingController username = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return Scaffold(
          appBar: kIsWeb
              ? PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                )
              : AppBar(
                  automaticallyImplyLeading: false,
                  title: Image.asset(
                    "assets/drawer_icons/WerfieLogoWIcon.png",
                    alignment: Alignment.centerLeft,
                    width: 60,
                    height: 60,
                  ),
                  centerTitle: true,
                  elevation: 0.0,
                  backgroundColor: Colors.white,
                ),
          body: Padding(
            padding: const EdgeInsets.only(left: 0, right: 0),
            child: SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 16.0,
                              horizontal: 12,
                            ),
                            child: Row(
                              children: [
                                // MediaQuery.of(context).size.width >= 1050
                                //     ? SizedBox()
                                //     :
                                MouseRegion(
                                  cursor: SystemMouseCursors.click,
                                  child: GestureDetector(
                                    onTap: () {
                                      controller.isListOfBlockedAccounts =
                                          false;
                                      controller.isTranslations = false;
                                      controller.isLanguageSettings = false;
                                      controller.isSettingDetail = false;
                                      controller.isSettingTypeDetail = false;
                                      controller.isLanguageType = false;
                                      controller.isListOfBlockedAccounts =
                                          false;
                                      controller.isChangeUserName = false;
                                      controller.isChangeEmail = false;
                                      controller.isAccountInformation = true;

                                      controller.update();
                                    },
                                    child: Icon(
                                      Icons.arrow_back,
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                      Strings.changeEmailSetting,
                                      textAlign: TextAlign.left,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                      // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                      //     fontSize: 18,fontWeight: FontWeight.w700
                                      // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,

                                      //),
                                      // style: Theme.of(context)
                                      //     .textTheme
                                      //     .headline6
                                      //     .copyWith(
                                      //       fontSize: 18,
                                      //       fontWeight: FontWeight.w700,
                                      //       color: Colors.black,
                                      //     ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    Container(
                      height: 1,
                      color: Colors.grey[300],
                    ),

                    ///Color(0xffeff3f4)
                    Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Container(
                        height: 50,
                        width: Get.width,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Color(0xffeff3f4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(Strings.current,
                                style: Styles.baseTextTheme.bodyText1.copyWith(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : kIsWeb
                                          ? Colors.black.withOpacity(0.5)
                                          : Colors.black,
                                )),
                            Get.isRegistered<ProfileController>()
                                ? Text(
                                    "${Get.find<ProfileController>().userProfile.email}",
                                    style:
                                        Styles.baseTextTheme.bodyText1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : kIsWeb
                                              ? Colors.black.withOpacity(0.5)
                                              : Colors.black,
                                    ),
                                  )
                                : Text(
                                    "${controller.email}",
                                    style:
                                        Styles.baseTextTheme.bodyText1.copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : kIsWeb
                                              ? Colors.black.withOpacity(0.5)
                                              : Colors.black,
                                    ),
                                  ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      height: 1,
                      color: Colors.grey[300],
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: CustomTextButtonWIthIcon(
                        null,
                       Strings.updateEmailAddress,
                        () {
                          showDialog<String>(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0))),
                                  contentPadding: EdgeInsets.zero,
                                  content: passwordScreen(),
                                );
                              });
                        },
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
