import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/list_get_member_model.dart';
import '../network/controller/List_controller.dart';
import '../network/singleTone.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/strings.dart';
import '../widgets/textformfield_screen.dart';
import 'add_to_your_list.dart';

class EditListScreen extends StatefulWidget {
  const EditListScreen({Key key}) : super(key: key);

  @override
  State<EditListScreen> createState() => _EditListScreenState();
}

class _EditListScreenState extends State<EditListScreen> {
  bool isFollow = false;
  bool isPin = false;
  bool isHover = false;
  bool isLoading = false;
  String crateId;
  String nameList;
  Uint8List imageFile;
  bool imageAvailable = false;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(
      //assignId: true,
      builder: (controller) {
        return Scaffold(
          body: SingleChildScrollView(
            child: Column(
              children: [
                //  SizedBox(height: 30,),
                Padding(
                  padding: const EdgeInsets.only(top: 30),
                  child: ListTile(
                      leading: IconButton(
                          onPressed: () {
                            SingleTone.instance.selectedLocation = null;

                            Navigator.of(context).pop();
                          },
                          icon: Icon(
                            Icons.close,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          )),
                      title: Text(
                        Strings.editList,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          // fontSize: 14.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      trailing: MaterialButton(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        color: Colors.grey[500],
                        // background
                        textColor: Colors.white,
                        // foreground
                        onPressed: () async {
                          /*DataListCreated data=*/
                          setState(() {
                            isLoading = true;
                          });

                          await controller
                              .createList(
                            isChecked: controller.isChecked, type: "update",
                            listId: controller.selectedList.listDetail.id
                                .toString(),
                            CoverImageBytes: controller.coverImage,
                            //  nameList: controller.descriptionList,
                            //  description: controller.descriptionList,
                          )
                              .then((value) async {
                            controller.selectedList =
                                await controller.listDetail(listId: value.id);
                            // Navigator.pop(context);
                            controller.newsfeedController.update();
                            controller.update();
                            controller.newsfeedController.update();
                            if (value != null) {
                              nameList = value.name;
                              crateId = value.id.toString();
                              controller.update();
                              Navigator.pop(context);
                              // controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
                            }
                            setState(() {
                              isLoading = false;
                            });
                          });
                        },
                        child: Text(Strings.next),
                      )),
                ),
                SizedBox(
                  child: Stack(children: [
                    Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: controller.coverImage != null
                                      ? MemoryImage(controller.coverImage)
                                      : NetworkImage(controller.selectedList ==
                                                  null ||
                                              controller.selectedList.listDetail
                                                      .coverImage ==
                                                  null
                                          ? "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQMhv9rfp7W3VRIytMEiJKsXMdBtifhbYBCK14qF5q&s"
                                          : controller.selectedList.listDetail
                                              .coverImage))),
                          child: imageAvailable == false
                              ? Center(
                                  child: CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.black54,
                                    child: IconButton(
                                      onPressed: () async {
                                        var image;
                                        /* if(kIsWeb)

                                                                {
                                                                  // image = await ImagePickerWeb
                                                                  //    .getImageAsBytes();
                                                                }*/
                                        controller.coverImage =
                                            await controller.callGetImage();

                                        // print(
                                        //     "controller.coverImage ${controller.coverImage}");

                                        controller.update();

                                        setState(() {
                                          imageAvailable = true;
                                          // // imageFile = image as Uint8List;
                                        });
                                        /* setState;
                                                                setState(() {
                                                                  imageAvailable = true;
                                                              image  = ;

                                                                  imageFile = image as Uint8List;
                                                                 // controller.coverImage=imageFile;
                                                                });*/

                                        // print("image agiye hai");
                                        // print(
                                        //     "controller.imageSelected ${image}");
                                      },
                                      icon: Icon(
                                        Icons.camera_alt,
                                        color: Colors.white,
                                      ),
                                      splashColor: Colors.black,
                                    ),
                                  ),
                                )
                              : Stack(children: [
                                  Container(
                                    height: Get.height,
                                    width: Get.width,
                                    child: Image.memory(
                                      controller.coverImage,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Positioned(
                                    top: 0,
                                    right: 0,
                                    child: Padding(
                                        padding: EdgeInsets.all(8.0),
                                        child: Row(
                                          children: [
                                            Card(
                                                color: Colors.black26,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(80),
                                                ),
                                                child: Center(
                                                    child: IconButton(
                                                        onPressed: () async {
                                                          var image;
                                                          if (kIsWeb) {
                                                            // image = await ImagePickerWeb.getImageAsBytes();
                                                          }
                                                          controller
                                                                  .coverImage =
                                                              await controller
                                                                  .callGetImage();

                                                          setState;
                                                          setState(() {
                                                            imageAvailable =
                                                                true;
                                                          });

                                                          /* setState;
                                                                              setState(() {
                                                                                imageAvailable = true;
                                                                                controller.coverImage = image as Uint8List;
                                                                              });*/
                                                        },
                                                        icon: Icon(
                                                          Icons.camera_alt,
                                                          color: Colors.white,
                                                          size: 25,
                                                        )))),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Card(
                                                color: Colors.black26,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(80),
                                                ),
                                                child: Center(
                                                    child: IconButton(
                                                        onPressed: () {
                                                          setState;
                                                          setState(() {
                                                            imageAvailable =
                                                                false;
                                                            controller
                                                                    .coverImage =
                                                                null;
                                                          });
                                                        },
                                                        icon: Icon(
                                                          Icons.close,
                                                          color: Colors.white,
                                                          size: 25,
                                                        )))),
                                          ],
                                        )),
                                  ),
                                ]),
                          height: Get.height * 0.20,
                          width: Get.width,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        CustomFormField(
                          label: "Name",
                          hintText: "Name",
                          focusBorderColor:
                              controller.newsfeedController.displayColor,
                          labelStyle: Styles.baseTextTheme.headline2.copyWith(
                            color: controller.newsfeedController.displayColor,
                            fontWeight: FontWeight.w400,
                            fontSize: kIsWeb ? 16 : 14,
                          ),
                          controller: controller.userNameController,
                          onChange: (value) {
                            // controller.nameList=value;
                            // controller.userNameController.text = value;
                            controller.update();
                            setState(() {});
                          },
                          maxLength: 25,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15),
                          child: TextFormField(
                            style: Styles.baseTextTheme.headline2.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.w500,
                              fontSize: kIsWeb ? 16 : 14,
                            ),
                            controller: controller.descriptionController,
                            onChanged: (value) {
                              controller.descriptionList = value;
//controller.descriptionController.text =value ;

                              controller.update();
                              setState(() {});
                            },
                            maxLines: 2,
                            maxLength: 100,
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10)),
// contentPadding: const EdgeInsets.only(bottom: 30, top: 10, left: 15, right: 5),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                      color: controller
                                          .newsfeedController.displayColor,
                                      width: 1,
                                    )),
                                filled: true,
                                hintText: "Descriptions",
                                hintStyle:
                                    Styles.baseTextTheme.headline2.copyWith(
                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                  fontWeight: FontWeight.w400,

                                  fontSize: kIsWeb ? 16 : 14,
                                ),
                                fillColor: Colors.grey[250]),
                            cursorColor: Colors.blue,
                          ),
                        ),
                        isLoading
                            ? Center(
                                child: CircularProgressIndicator(),
                              )
                            : SizedBox(),
                        SizedBox(
                          height: 30,
                        ),
                        Divider(),

                        /// yahan bug hai
                        InkWell(
                          onTap: ()
                              // async
                              async {
                            List<MemberGetModel> list =
                                await controller.getAlreadyMembers(
                                    list_Id: controller
                                        .selectedList.listDetail.id
                                        .toString());
                            // DataListCreated data= await controller.createList(
                            //     isChecked:
                            //     controller.isChecked,type: "update", listId:controller.selectedList.listDetail.id.toString());
                            // if(data != null){
                            //   nameList=data.name;
                            //   crateId=data.id.toString();
                            //   Navigator.pop(context);
                            //   controller.SuggestedPost(list_Id: data.id.toString(),name: data.name);
                            // }
                            // if (data != null) {
                            //   userName = controller.selectedList.listDetail.name.toString();
                            //   crateId =controller.selectedList.listDetail.id.toString();
                            //   description=controller.selectedList.listDetail.description.toString();
                            //   print("username......................");
                            //   print(userName);
                            //   print("id..................");
                            //   print(crateId);
                            //   print('usernmae conroller');
                            //   print( controller.userName);
                            //   print("description...........");
                            //   print(description);
                            //   controller.userName=userName;
                            //   controller.update();
                            //   controller.crateId=crateId;
                            //   controller.update();
                            //   Navigator.pop(context);
                            //   print('list id used in ${controller.selectedList.listDetail.id.toString()}');
                            //   controller.modelSuggestList=await controller.SuggestedPost(list_Id: controller.selectedList.listDetail.id.toString(), name: controller.userNameController.text);
                            //   controller.update();
                            //      }

                            if (!kIsWeb) {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        AddToYourList(list: list)),
                              );
                            } else {
                              showDialog<String>(
                                context: context,
                                builder: (BuildContext context) =>
                                    StatefulBuilder(builder:
                                        (BuildContext context,
                                            StateSetter setState) {
                                  return AlertDialog(
                                      contentPadding: const EdgeInsets.fromLTRB(
                                          0.0, 0.0, 0.0, 0.0),
                                      content: Container(
                                        height: Get.height * 0.70,
                                        width: Get.width * 0.45,
                                        child: SingleChildScrollView(
                                          child: Column(
                                            children: [
                                              ListTile(
                                                  leading: IconButton(
                                                      onPressed: () {
                                                        SingleTone.instance
                                                                .selectedLocation =
                                                            null;
                                                        setState(() {});
                                                        Navigator.of(context)
                                                            .pop();
                                                      },
                                                      icon: Icon(
                                                        Icons.close,
                                                        color: Colors.black87,
                                                      )),
                                                  title: Text(
                                                    Strings.addToYourList,
                                                    style: TextStyle(
                                                        color: Colors.black,
                                                        fontWeight:
                                                            FontWeight.w800),
                                                  ),
                                                  trailing: MaterialButton(
                                                    shape:
                                                        RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        15)),
                                                    color: Colors.grey[500],
                                                    // backgroundRtab
                                                    textColor: Colors.white,
                                                    // foreground
                                                    onPressed: () async {
                                                      // print(
                                                      //     "list create button");
                                                      controller.selectedList =
                                                          await controller.listDetail(
                                                              listId: controller
                                                                  .selectedList
                                                                  .listDetail
                                                                  .id);
                                                      // Navigator.pop(context);

                                                      controller
                                                              .newsfeedController
                                                              .isListDetailScreen =
                                                          true;
                                                      controller
                                                          .newsfeedController
                                                          .isSearch = false;
                                                      controller
                                                          .newsfeedController
                                                          .isFilter = false;
                                                      controller
                                                              .newsfeedController
                                                              .isFilterScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isTrendsScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isNewsFeedScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isBrowseScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isNotificationScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isWhoToFollowScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isSavedPostScreen =
                                                          false;
                                                      controller
                                                          .newsfeedController
                                                          .isChatScreen = false;
                                                      controller
                                                          .newsfeedController
                                                          .isPostDetails = false;
                                                      controller
                                                              .newsfeedController
                                                              .isProfileScreen =
                                                          false;
                                                      controller
                                                          .newsfeedController
                                                          .searchText
                                                          .text = '';
                                                      controller
                                                          .newsfeedController
                                                          .isListScreen = false;
                                                      controller
                                                              .newsfeedController
                                                              .isFollwerScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .isSettingsScreen =
                                                          false;
                                                      controller
                                                              .newsfeedController
                                                              .navRoute =
                                                          "isChatScreen";
                                                      controller
                                                          .newsfeedController
                                                          .update();

                                                      controller.update();

                                                      controller
                                                          .newsfeedController
                                                          .update();
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text(Strings.done),
                                                  )),
                                              Container(
                                                child: SingleChildScrollView(
                                                  child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .stretch,
                                                      children: <Widget>[
                                                        SizedBox(height: 20.0),
                                                        DefaultTabController(
                                                            length: 2,
                                                            // length of tabs
                                                            initialIndex: 1,
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .stretch,
                                                                children: <
                                                                    Widget>[
                                                                  Container(
                                                                    child:
                                                                        TabBar(
                                                                      labelColor:
                                                                          Colors
                                                                              .blue,
                                                                      unselectedLabelColor:
                                                                          Colors
                                                                              .black,
                                                                      tabs: [
                                                                        Tab(
                                                                            text:
                                                                                'Members ${list.length}'),
                                                                        Tab(
                                                                            text:Strings.suggested),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                      height:
                                                                          Get.width *
                                                                              0.3,
                                                                      //height of TabBarView
                                                                      decoration:
                                                                          BoxDecoration(
                                                                              border: Border(top: BorderSide(color: Colors.grey, width: 0.5))),
                                                                      child: TabBarView(children: <Widget>[
                                                                        Container(
                                                                          height:
                                                                              Get.width * 0.27,
                                                                          child:
                                                                              SingleChildScrollView(
                                                                            child:
                                                                                Column(
                                                                              children: List.generate(
                                                                                  list.length,
                                                                                  (index) => ListTile(
                                                                                      leading: Container(
                                                                                        height: 40,
                                                                                        width: 40,
                                                                                        decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(10), image: DecorationImage(image: NetworkImage(list[index].profileImage == null ? "https://www.challengetires.com/assets/img/placeholder.jpg" : list[index].profileImage), fit: BoxFit.fill)),
                                                                                      ),
                                                                                      title: Text(list[index].firstname),
                                                                                      subtitle: Row(
                                                                                        children: [
                                                                                          Text("@" + list[index].username),
                                                                                          SizedBox(
                                                                                            width: 4,
                                                                                          ),
                                                                                          // Text(controller
                                                                                          //     .addMemberList[index]
                                                                                          //     .username),
                                                                                        ],
                                                                                      ),
                                                                                      trailing: ElevatedButton(
                                                                                          style: ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)), primary: Colors.blueAccent),
                                                                                          onPressed:

                                                                                              //     :
                                                                                              () {
                                                                                            // setState(() {
                                                                                            // isFollow = false;

                                                                                            // print("index >>>>>>>>>>>>>>>>>>>>>>>>$index");

                                                                                            if (controller.modelSuggestList.isNotEmpty) {
                                                                                              controller.modelSuggestList.forEach((element) {
                                                                                                if (element.id == list[index].memberFollowerId) {
                                                                                                  element.isFollow = false;
                                                                                                }
                                                                                              });
                                                                                            }

                                                                                            // controller
                                                                                            //     .update();
                                                                                            // controller
                                                                                            //     .update([
                                                                                            //   "edit_suggestion"
                                                                                            // ]);
                                                                                            // controller.deletePost(controller.addMemberList[index].id);
                                                                                            // dataList.remove(
                                                                                            //     controller.  listOfDiscover[index]);
                                                                                            // });
                                                                                            controller.update();
                                                                                            controller.update([
                                                                                              "edit_suggestion"
                                                                                            ]);
                                                                                            controller.unFollowRemoveMethod(list_Id: controller.selectedList.listDetail.id.toString(), member_id: list[index].memberFollowerId.toString(), type: "member");
                                                                                            list.removeAt(index);
                                                                                            setState(() {});
                                                                                            // controller.addMemberList.removeAt(i);
                                                                                          },
                                                                                          child:
                                                                                              // isFollow == false
                                                                                              //     ? Text(
                                                                                              //   "Add",
                                                                                              //   style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                              //     fontSize: 14,
                                                                                              //     fontWeight: FontWeight.w700,
                                                                                              //     color: Colors.white,
                                                                                              //   ),
                                                                                              // )
                                                                                              //     :
                                                                                              Text(
                                                                                                Strings.remove,
                                                                                            style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                                  fontSize: 14,
                                                                                                  fontWeight: FontWeight.w700,
                                                                                                  color: Colors.white,
                                                                                                ),
                                                                                          )))),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Container(
                                                                          child:
                                                                              SingleChildScrollView(
                                                                            child:
                                                                                Column(
                                                                              children: [
                                                                                Padding(
                                                                                  padding: EdgeInsets.only(top: 10, right: 10, bottom: 10, left: 10),
                                                                                  child: TextField(
                                                                                    style: LightStyles.baseTextTheme.headline2.copyWith(
                                                                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      // fontWeight: FontWeight.bold,
                                                                                    ),
                                                                                    autofocus: true,
                                                                                    // controller: controller.chatSearchTEC,
                                                                                    // focusNode: controller.chatSearchTextFocus,
                                                                                    onChanged: (value) async {
                                                                                      controller.modelSuggestList = await controller.SuggestedPost(list_Id: controller.selectedList.listDetail.id.toString(), name: value);
                                                                                      setState(() {});
                                                                                    },
                                                                                    textAlignVertical: TextAlignVertical.center,
                                                                                    decoration: InputDecoration(
                                                                                      hintText: Strings.searchPeople,
                                                                                      hintStyle: LightStyles.baseTextTheme.headline2,
                                                                                      prefixIcon: Icon(
                                                                                        Icons.search,
                                                                                        size: 20,
                                                                                        color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                      ),
                                                                                      border: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(40),
                                                                                        borderSide: BorderSide(
                                                                                          width: 1,
                                                                                          color: Colors.grey,
                                                                                        ),
                                                                                      ),
                                                                                      enabledBorder: OutlineInputBorder(
                                                                                        borderRadius: BorderRadius.circular(40),
                                                                                        borderSide: BorderSide(
                                                                                          width: 1,
                                                                                          color: Colors.grey,
                                                                                        ),
                                                                                      ),
                                                                                      fillColor: Colors.grey[250],
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                                SizedBox(
                                                                                  height: Get.width * 0.25,
                                                                                  child: controller.modelSuggestList.isEmpty || controller.modelSuggestList == null
                                                                                      ? Center(
                                                                                          child: Padding(
                                                                                            padding: const EdgeInsets.only(top: 20.0),
                                                                                            child: Text("No results"),
                                                                                          ),
                                                                                        )
                                                                                      : SingleChildScrollView(
                                                                                          child: Column(
                                                                                          children: List.generate(
                                                                                              controller.modelSuggestList.length,
                                                                                              (index) => ListTile(
                                                                                                  leading: Container(
                                                                                                    height: 40,
                                                                                                    width: 40,
                                                                                                    decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(10), image: DecorationImage(image: NetworkImage(controller.modelSuggestList[index].authorProfileImage == null ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png" : controller.modelSuggestList[index].authorProfileImage), fit: BoxFit.fill)),
                                                                                                  ),
                                                                                                  title: Text(controller.modelSuggestList[index].username),
                                                                                                  subtitle: Row(
                                                                                                    children: [
                                                                                                      Text(controller.modelSuggestList[index].authorName),
                                                                                                      SizedBox(
                                                                                                        width: 4,
                                                                                                      ),
                                                                                                      Text(controller.modelSuggestList[index].username),
                                                                                                    ],
                                                                                                  ),

                                                                                                  ///idhr kerna kam
                                                                                                  trailing: ElevatedButton(
                                                                                                      style: ElevatedButton.styleFrom(
                                                                                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                                                                                        primary: Theme.of(context).brightness == Brightness.dark
                                                                                                            ? !controller.modelSuggestList[index].isFollow
                                                                                                                ? Colors.white
                                                                                                                : Colors.black
                                                                                                            : !controller.modelSuggestList[index].isFollow
                                                                                                                ? Colors.black
                                                                                                                : Colors.white,

                                                                                                        //  controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30)
                                                                                                      ),
                                                                                                      onPressed: controller.modelSuggestList[index].isFollow == false
                                                                                                          ? () async {
                                                                                                              controller.modelSuggestList[index].isFollow = true;
                                                                                                              setState(() {});

                                                                                                              MemberGetModel member = MemberGetModel();
                                                                                                              member.username = controller.modelSuggestList[index].username;
                                                                                                              // member.id = controller
                                                                                                              //     .modelSuggestList[index].id;
                                                                                                              member.memberFollowerId = controller.modelSuggestList[index].id;
                                                                                                              member.firstname = controller.modelSuggestList[index].authorName;
                                                                                                              member.listId = controller.selectedList.listDetail.id;
                                                                                                              member.profileImage = controller.modelSuggestList[index].authorProfileImage;
                                                                                                              list.add(member);

                                                                                                              controller.update(["edit_suggestion"]);
                                                                                                              controller.update();

                                                                                                              controller.memberAdd(controller.selectedList.listDetail.id.toString(), controller.modelSuggestList[index].id, "member");
                                                                                                              setState(() {});
                                                                                                            }
                                                                                                          : () {
                                                                                                              controller.modelSuggestList[index].isFollow == false;

                                                                                                              controller.modelSuggestList.forEach((element) {
                                                                                                                if (element.id == controller.modelSuggestList[index].id) {
                                                                                                                  element.isFollow = false;
                                                                                                                }
                                                                                                              });
                                                                                                              list.removeWhere((item) => item.memberFollowerId == controller.modelSuggestList[index].id);
                                                                                                              // for (int i = 0; i <
                                                                                                              //
                                                                                                              //     list
                                                                                                              //         .length; i++) {
                                                                                                              //   if (list[i]
                                                                                                              //       .id ==
                                                                                                              //       controller
                                                                                                              //           .modelSuggestList[index]
                                                                                                              //           .id) {
                                                                                                              //
                                                                                                              //     list
                                                                                                              //         .removeAt(
                                                                                                              //         i);
                                                                                                              //   }
                                                                                                              // }
                                                                                                              controller.update(["edit_suggestion"]);
                                                                                                              controller.update();

                                                                                                              // controller
                                                                                                              //     .deletePost(
                                                                                                              //     controller
                                                                                                              //         .modelSuggestList[index]
                                                                                                              //         .id);
                                                                                                              // dataList.remove(
                                                                                                              //     controller.  listOfDiscover[index]);

                                                                                                              // controller
                                                                                                              //     .update(
                                                                                                              //     [
                                                                                                              //       "edit_suggestion"
                                                                                                              //     ]);
                                                                                                              // controller
                                                                                                              //     .update();
                                                                                                              controller.unFollowRemoveMethod(list_Id: controller.selectedList.listDetail.id.toString(), member_id: controller.modelSuggestList[index].id.toString(), type: "member");
                                                                                                              setState(() {});
                                                                                                            },
                                                                                                      child: controller.modelSuggestList[index].isFollow == false
                                                                                                          ? Text(
                                                                                                              Strings.add,
                                                                                                              style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                                                    fontSize: 14,
                                                                                                                    fontWeight: FontWeight.w700,
                                                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                                                                                                                  ),
                                                                                                            )
                                                                                                          : Text(
                                                                                                        Strings.remove,
                                                                                                              style: Theme.of(context).textTheme.headline6.copyWith(
                                                                                                                    fontSize: 14,
                                                                                                                    fontWeight: FontWeight.w700,
                                                                                                                    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                                                                  ),
                                                                                                            )))),
                                                                                        )),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ]))
                                                                ])),
                                                      ]),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ));
                                }),
                              );
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(left: 20, right: 20),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  Strings.manageMembers,
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 14),
                                ),
                                Icon(
                                  Icons.arrow_forward_ios_outlined,
                                  color: Colors.black,
                                )
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        controller.isDelete
                            ? Center(
                                child: CircularProgressIndicator(
                                    color: MyColors.BlueColor),
                              )
                            : ElevatedButton(
                                onPressed: () async {
                                  // setState(() {
                                  controller.isDelete = true;
                                  // });
                                  // print(
                                  //     "delete post ......>>>>>>>>>>>>>>>>${controller.selectedList.listDetail.id}");
                                  controller.deletePost(
                                      controller.selectedList.listDetail.id);

                                  // setState(() {
                                  controller.isDelete = false;
                                  int listIndex = controller
                                      .listModel.data.lists
                                      .indexWhere((element) =>
                                          element.id ==
                                          controller
                                              .selectedList.listDetail.id);
                                  // print("listIndex : " + listIndex.toString());
                                  controller.listModel.data.lists
                                      .removeAt(listIndex);
                                  // controller.listModel.data.lists[index]
                                  //   controller.selectedList = await controller.listDetail(listId : controller.selectedList.listDetail.id);
                                  controller.newsfeedController.update();
                                  controller.update();
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                  // });
                                  // print("delete  ......>>>>>>>>>>>>>>>>");
                                },
                                child: Text("Delete"))
                      ],
                    ),
                  ]),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
