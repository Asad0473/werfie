import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_password_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/login_controller.dart';
import '../utils/utils_methods.dart';
import 'change_email_screen.dart';

// ignore: must_be_immutable
class passwordScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  TextEditingController username = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return kIsWeb
            ? SingleChildScrollView(
                child: Container(
                  height: 500,
                  width: 450,
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.confirmPassMsg,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          // height: 55,
                          child: InputPasswordField(
                            // formKey: LoginController.formKey,
                            TextInputAction: TextInputAction.next,
                            // onPasswordEntered: (value) {
                            //   value = password.text;
                            // },
                            text: Strings.enterYourPassword,
                            controller: Get.find<LoginController>().password,
                            validator: (value) {
                              return UtilsMethods.validatePassword(value);
                            },
                          ),
                        ),
                        Spacer(),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RoundedButton(
                              Strings.cancel,
                              () {
                                Navigator.pop(context);
                              },
                              horizontalPadding: 30.0,
                              roundedButtonColor: Colors.red,
                            ),
                            RoundedButton(
                              Strings.next,
                              controller.buttonCheck == false
                                  ? () async {
                                      controller.buttonCheck = true;
                                      controller.update();
                                      int isSuccess =
                                          await controller.verifyPassword(
                                              controller.userId,
                                              Get.find<LoginController>()
                                                  .password
                                                  .text);

                                      // print("isSuccess ${isSuccess}");

                                      Get.find<LoginController>()
                                          .password
                                          .clear();
                                      if (isSuccess == 1) {
                                        Navigator.pop(context);
                                        showDialog<String>(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                10.0))),
                                                contentPadding: EdgeInsets.zero,
                                                content: changeEmailScreen(),
                                              );
                                            });
                                      } else if (isSuccess == 2) {
                                        UtilsMethods.toastMessageShow(
                                            controller.displayColor,
                                            controller.displayColor,
                                            controller.displayColor,
                                            message: Strings.wrongPasswordMsg);
                                      }

                                      Future.delayed(const Duration(seconds: 3),
                                          () {
                                        controller.buttonCheck = false;
                                        controller
                                            .update(); // Prints after 1 second.
                                      });
                                    }
                                  : () {},
                              horizontalPadding: 30.0,
                              roundedButtonColor: controller.displayColor,
                            ),
                          ],
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              )
            : Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  title: Image.asset(
                    "assets/drawer_icons/WerfieLogoWIcon.png",
                    alignment: Alignment.centerLeft,
                    width: 60,
                    height: 60,
                  ),
                  centerTitle: true,
                  elevation: 0.0,
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                ),
                body: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.confirmPassMsg,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(height: 20),
                        Container(
                          // height: 55,
                          child: InputPasswordField(
                            // formKey: LoginController.formKey,
                            TextInputAction: TextInputAction.next,
                            // onPasswordEntered: (value) {
                            //   value = password.text;
                            // },
                            text: Strings.enterYourPassword,
                            controller: Get.find<LoginController>().password,
                            validator: (value) {
                              return UtilsMethods.validatePassword(value);
                            },
                          ),
                        ),
                        Spacer(),

                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RoundedButton(
                              Strings.cancel,
                              () {
                                Navigator.pop(context);
                              },
                              horizontalPadding: 30.0,
                              roundedButtonColor: Colors.red,
                            ),
                            RoundedButton(
                              Strings.next,
                              controller.buttonCheck == false
                                  ? () async {
                                      controller.buttonCheck = true;
                                      controller.update();
                                      int isSuccess =
                                          await controller.verifyPassword(
                                              controller.userId,
                                              Get.find<LoginController>()
                                                  .password
                                                  .text);

                                      // print("isSuccess ${isSuccess}");

                                      Get.find<LoginController>()
                                          .password
                                          .clear();
                                      if (isSuccess == 1) {
                                        Navigator.pushReplacement(
                                            context,
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        changeEmailScreen()));
                                      } else if (isSuccess == 2) {
                                        UtilsMethods.toastMessageShow(
                                            controller.displayColor,
                                            controller.displayColor,
                                            controller.displayColor,
                                            message: Strings.wrongPasswordMsg);
                                      }

                                      Future.delayed(const Duration(seconds: 3),
                                          () {
                                        controller.buttonCheck = false;
                                        controller
                                            .update(); // Prints after 1 second.
                                      });
                                    }
                                  : () {},
                              horizontalPadding: 30.0,
                              roundedButtonColor: controller.displayColor,
                            ),
                          ],
                        ),

                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),

                        // RoundedButton(
                        //     buttonText:Text("asd"),
                        //     onPressed:(){}
                        // );
                      ],
                    ),
                  ),
                ),
              );
      },
    );
  }
}
