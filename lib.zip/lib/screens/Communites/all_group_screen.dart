import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../network/controller/communities_controller.dart';

class AllGroupScreen extends StatelessWidget {
  AllGroupScreen({Key key}) : super(key: key);

  final communitiesController = Get.find<CommunitiesController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: PreferredSize(
      //   preferredSize: Size.fromHeight(510.0),
      //   child: Container(
      //     color: Theme.of(context).brightness == Brightness.dark
      //         ? Color(0xFF121212)
      //         : Colors.white,
      //     child: SingleChildScrollView(
      //       child: Column(
      //         mainAxisAlignment: MainAxisAlignment.start,
      //         crossAxisAlignment: CrossAxisAlignment.start,
      //         children: [
      //           kIsWeb
      //               ? SizedBox(
      //             height: 20,
      //           )
      //               : SizedBox(height: 49),
      //           Padding(
      //             padding: const EdgeInsets.symmetric(horizontal: 15),
      //             child: GestureDetector(
      //               onTap: kIsWeb
      //                   ? () {
      //                 // controller.newsfeedController.isTrendsScreen =
      //                 // false;
      //                 // controller.newsfeedController.isNewsFeedScreen =
      //                 // true;
      //                 // controller.newsfeedController.isBrowseScreen =
      //                 // false;
      //                 // controller.newsfeedController
      //                 //     .isNotificationScreen = false;
      //                 // controller.newsfeedController.isChatScreen =
      //                 // false;
      //                 // controller.newsfeedController
      //                 //     .isSavedPostScreen = false;
      //                 // controller.newsfeedController.isPostDetails =
      //                 // false;
      //                 // controller.newsfeedController.isProfileScreen =
      //                 // false;
      //                 // controller.newsfeedController
      //                 //     .isOtherUserProfileScreen = false;
      //                 // controller.newsfeedController.isTopicScreen =
      //                 // false;
      //                 // controller.newsfeedController.isListScreen =
      //                 // false;
      //                 // controller.newsfeedController
      //                 //     .isMainTopicScreen = false;
      //                 // controller.newsfeedController.update();
      //               }
      //                   : () {
      //                 Navigator.pop(context);
      //               },
      //               child: Icon(
      //                 Icons.arrow_back,
      //                 color: Theme.of(context).brightness ==
      //                     Brightness.dark
      //                     ? Colors.white
      //                     : Colors.black,
      //                 size: 25,
      //               ),
      //             ),
      //           ),
      //           SizedBox(
      //             height: 20,
      //           ),
      //           Container(
      //             height: 200,
      //             width: Get.width,
      //             color: Colors.cyanAccent,
      //             child: controller.coverImage != null
      //                 ? Image.memory(
      //               controller.coverImage,
      //               fit: BoxFit.cover,
      //             )
      //                 : Image.asset(
      //               'assets/images/person_placeholder.png',
      //               fit: BoxFit.cover,
      //             ),
      //
      //
      //           ),
      //
      //         ],
      //       ),
      //     ),
      //   ),
      // ),
      body: kIsWeb
          ? SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 10),
                    child: GestureDetector(
                      onTap: kIsWeb
                          ? () {
                              // controller.newsfeedController.isTrendsScreen =
                              // false;
                              // controller.newsfeedController.isNewsFeedScreen =
                              // true;
                              // controller.newsfeedController.isBrowseScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isNotificationScreen = false;
                              // controller.newsfeedController.isChatScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isSavedPostScreen = false;
                              // controller.newsfeedController.isPostDetails =
                              // false;
                              // controller.newsfeedController.isProfileScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isOtherUserProfileScreen = false;
                              // controller.newsfeedController.isTopicScreen =
                              // false;
                              // controller.newsfeedController.isListScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isMainTopicScreen = false;
                              // controller.newsfeedController.update();
                            }
                          : () {
                              Navigator.pop(context);
                            },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        size: 25,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Stack(
                    children: [
                      Container(
                        height: 300,
                        width: Get.width,
                        color: Colors.cyanAccent,
                        child: Image.asset(
                          'assets/images/person_placeholder.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                      Positioned(
                          bottom: 10,
                          left: 10,
                          child: Text(
                            communitiesController.CategoryName,
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          )),
                    ],
                  ),
                  Container(
                    height: Get.height,
                    width: Get.width,
                    // color: Colors.redAccent,
                    child: GridView.builder(
                        scrollDirection: Axis.horizontal,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3,
                          mainAxisExtent: 300,
                          // mainAxisSpacing:kIsWeb? 50.0:0,
                          // crossAxisSpacing:kIsWeb? 50.0:0,
                        ),
                        itemCount: 5,
                        itemBuilder: (BuildContext ctx, index) {
                          return Padding(
                            padding: const EdgeInsets.only(
                                left: 10, top: 10, right: 10),
                            child: Communities_Card(
                              cardType: "joinCommunity",
                              communitiesController: communitiesController,
                            ),
                          );
                        }),
                  ),
                ],
              ),
            )
          : SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 10),
                    child: GestureDetector(
                      onTap: kIsWeb
                          ? () {
                              // controller.newsfeedController.isTrendsScreen =
                              // false;
                              // controller.newsfeedController.isNewsFeedScreen =
                              // true;
                              // controller.newsfeedController.isBrowseScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isNotificationScreen = false;
                              // controller.newsfeedController.isChatScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isSavedPostScreen = false;
                              // controller.newsfeedController.isPostDetails =
                              // false;
                              // controller.newsfeedController.isProfileScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isOtherUserProfileScreen = false;
                              // controller.newsfeedController.isTopicScreen =
                              // false;
                              // controller.newsfeedController.isListScreen =
                              // false;
                              // controller.newsfeedController
                              //     .isMainTopicScreen = false;
                              // controller.newsfeedController.update();
                            }
                          : () {
                              Navigator.pop(context);
                            },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        size: 25,
                      ),
                    ),
                  ),
                  Stack(
                    children: [
                      Container(
                        height: 250,
                        width: Get.width,
                        color: Colors.cyanAccent,
                        child: Image.asset(
                          'assets/images/person_placeholder.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                      Positioned(
                          bottom: 10,
                          left: 10,
                          child: Text(
                            communitiesController.CategoryName,
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          )),
                    ],
                  ),
                  Expanded(
                    child: GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 1,
                          mainAxisExtent: 300,
                          mainAxisSpacing: 0,
                          crossAxisSpacing: 0,
                        ),
                        itemCount: 5,
                        itemBuilder: (BuildContext ctx, index) {
                          return Padding(
                            padding: const EdgeInsets.only(
                                left: 10, top: 10, right: 10),
                            child: Communities_Card(
                              cardType: "joinCommunity",
                              communitiesController: communitiesController,
                            ),
                          );
                        }),
                  ),
                ],
              ),
            ),
    );
  }
}

// class CommunitiesCard extends StatelessWidget {
//   CommunitiesCard({Key key,this.cardType}) : super(key: key);
//
//   String cardType;
//
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       color: Theme.of(context).brightness == Brightness.dark ?Color(0xFF252526):  Color(0xFFfafafa),
//       shape: RoundedRectangleBorder(
//           borderRadius: BorderRadius.circular(10)
//       ),
//       shadowColor: Colors.grey,
//       elevation: 1.0,
//       child: Container(
//         // width: 300,
//         // height: 200,
//
//         decoration: BoxDecoration(
//             color: Theme.of(context).brightness == Brightness.dark ?Color(0xFF252526):  Color(0xFFfafafa),
//             borderRadius: BorderRadius.circular(10)
//         ),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Container(
//               height: 150,
//               width: 300,
//
//
//               decoration: BoxDecoration(
//                   borderRadius: BorderRadius.only(
//                       topRight: Radius.circular(10),
//                       topLeft: Radius.circular(10)
//
//                   ),
//                   image: new DecorationImage(
//                     image: new NetworkImage(
//                         "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif"),
//                     fit: BoxFit.fill,
//                   )
//               ),
//
//             ),
//
//             Padding(
//               padding: const EdgeInsets.only(left: 10),
//               child: Row(
//                 children: [
//                   CircleAvatar(
//                     minRadius: 25,
//
//                     backgroundImage:     NetworkImage(
//                       "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif",
//
//                     ),
//
//                   ),
//                   SizedBox(
//                     width: 20,
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.start,
//
//                         children: [
//                           Text(
//                             "new group",
//                             style: TextStyle(
//                                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black
//                             ),
//                           ),
//                           Text("(Public)",
//                             style: TextStyle(
//                                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black
//                             ),
//                           ),
//
//                         ],
//                       ),
//                       Text("1 member",
//                         style: TextStyle(
//                             color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black
//                         ),
//                       ),
//
//                     ],
//                   )
//                 ],
//               ),
//             ),
//
//
//             Padding(
//               padding: const EdgeInsets.only(left: 10, right: 10),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Obx(() {
//                     return Expanded(
//                       child: MaterialButton(
//                         color:Theme.of(context).brightness == Brightness.dark ?Color(0xFF252526): Colors.white,
//                         elevation: 0.0,
//
//                         onHighlightChanged: (bool value) {
//
//
//                         },
//                         // hoverColor: Color(0xFF0157d3),
//                         // borderSide: const BorderSide(
//                         //   color: Colors.white,
//                         //   style: BorderStyle.solid,
//                         //   width: 1,
//                         // ),
//                         shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(100.0),
//                             side: BorderSide(
//                                 color: Colors.grey.withOpacity(0.5))
//                         ),
//
//
//                         onPressed: () {
//
//
//                         },
//                         child: Padding(
//                           padding: const EdgeInsets.only(top: 10, bottom: 10),
//                           child: Text(
//
//                             "Join",
//
//                             style: TextStyle(
//                                 color:    Colors.white,
//                                 fontWeight: FontWeight.bold
//                             ),
//                           ),
//                         ),
//
//                       ),
//                     );
//                   }),
//                 ],
//               ),
//             ),
//
//
//
//             SizedBox(
//               height: 10,
//             ),
//
//
//
//           ],
//         ),
//
//       ),
//
//     );
//   }
// }

class Communities_Card extends StatelessWidget {
  Communities_Card({Key key, this.communitiesController, this.cardType})
      : super(key: key);
  final CommunitiesController communitiesController;

  String cardType;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).brightness == Brightness.dark
          ? Color(0xFF252526)
          : Color(0xFFfafafa),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      shadowColor: Colors.grey,
      elevation: 1.0,
      child: Container(
        // width: 300,
        // height: 200,

        decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark
                ? Color(0xFF252526)
                : Color(0xFFfafafa),
            borderRadius: BorderRadius.circular(10)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 150,
              width: kIsWeb ? 300 : Get.width,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10),
                      topLeft: Radius.circular(10)),
                  image: new DecorationImage(
                    image: new NetworkImage(
                        "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif"),
                    fit: BoxFit.fill,
                  )),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Row(
                children: [
                  CircleAvatar(
                    minRadius: 25,
                    backgroundImage: NetworkImage(
                      "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif",
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "new group",
                            style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                          ),
                          Text(
                            "(Public)",
                            style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                          ),
                        ],
                      ),
                      Text(
                        "1 member",
                        style: TextStyle(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  kIsWeb
                      ? Obx(() {
                          return Expanded(
                              child: MouseRegion(
                            onHover: (value) {
                              communitiesController.hoverCheck.value = true;
                            },
                            onExit: (value) {
                              communitiesController.hoverCheck.value = false;
                            },
                            child: MaterialButton(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Color(0xFF252526)
                                  : Colors.white,
                              elevation: 0.0,

                              onHighlightChanged: (bool value) {},
                              hoverColor: Color(0xFF0157d3),
                              // borderSide: const BorderSide(
                              //   color: Colors.white,
                              //   style: BorderStyle.solid,
                              //   width: 1,
                              // ),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(100.0),
                                  side: BorderSide(
                                      color: Colors.grey.withOpacity(0.5))),

                              onPressed: () {},
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 10, bottom: 10),
                                child: Text(
                                  "Join",
                                  style: TextStyle(
                                      color: communitiesController
                                                  .hoverCheck.value ==
                                              false
                                          ? Color(0xFF0157d3)
                                          : Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ));
                        })
                      : Expanded(
                          child: MaterialButton(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Color(0xFF252526)
                                    : Colors.white,
                            elevation: 0.0,

                            onHighlightChanged: (bool value) {},
                            // borderSide: const BorderSide(
                            //   color: Colors.white,
                            //   style: BorderStyle.solid,
                            //   width: 1,
                            // ),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(100.0),
                                side: BorderSide(
                                    color: Colors.grey.withOpacity(0.5))),

                            onPressed: () {},
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: Text(
                                "Join",
                                style: TextStyle(
                                  color: Color(0xFF0157d3),
                                  fontWeight: FontWeight.bold,
                                  // fontSize: 10,
                                ),
                              ),
                            ),
                          ),
                        ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
