import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/network/controller/communities_controller.dart';
import 'package:werfieapp/screens/create_post_mobile.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/widgets/custom_adwidget.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';

import '../../models/create_post_model/create_post_model.dart';
import '../../models/post.dart';
import '../../network/controller/news_feed_controller.dart';
import '../../utils/strings.dart';
import '../../widgets/community_members_list.dart';
import '../../widgets/community_request.dart';
import '../../widgets/create_community.dart';
import '../../widgets/post_card.dart';
import '../../widgets/thread_post_card.dart';

class CommunityScreen extends StatelessWidget {
  CommunityScreen({Key key}) : super(key: key);
  final communitiesController = Get.put(CommunitiesController());

  final newsfeedController = Get.put(NewsfeedController());

  // final scrollController = ScrollController();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CommunitiesController>(builder: (controller) {
      return Scaffold(
        // appBar: PreferredSize(
        //   preferredSize: Size.fromHeight(510.0),
        //   child: Container(
        //     color: Theme.of(context).brightness == Brightness.dark
        //         ? Color(0xFF121212)
        //         : Colors.white,
        //     child: SingleChildScrollView(
        //             child: Column(
        //               mainAxisAlignment: MainAxisAlignment.start,
        //               crossAxisAlignment: CrossAxisAlignment.start,
        //               children: [
        //                 SizedBox(
        //                         height: 20,
        //                       ),
        //                 Padding(
        //                   padding: const EdgeInsets.symmetric(horizontal: 10),
        //                   child: Row(
        //                     children: [
        //                       GestureDetector(
        //                         onTap: kIsWeb
        //                             ? () {
        //                           // communitiesController.timer.;
        //                           // communitiesController.timer3?.cancel();
        //                           // communitiesController.timer2?.cancel();
        //                           // communitiesController.timer4?.cancel();
        //                           // communitiesController.update();
        //                           // ///idhr ana
        //
        //
        //                           communitiesController.newsfeedController.isSearch = false;
        //                           communitiesController.newsfeedController.isFilter = false;
        //                           communitiesController.newsfeedController.isFilterScreen = false;
        //                           communitiesController.newsfeedController.isTrendsScreen = false;
        //                           communitiesController.newsfeedController.isNewsFeedScreen = false;
        //                           communitiesController.newsfeedController.isBrowseScreen = false;
        //                           communitiesController.newsfeedController.isNotificationScreen = false;
        //                           communitiesController.newsfeedController.isSavedPostScreen = false;
        //                           communitiesController.newsfeedController.isWhoToFollowScreen = false;
        //                           communitiesController.newsfeedController.isChatScreen = false;
        //                           communitiesController.newsfeedController.isPostDetails = false;
        //                           communitiesController.newsfeedController.searchText.text = '';
        //                           communitiesController.newsfeedController.isListScreen = false;
        //                           communitiesController.newsfeedController.isListDetailScreen = false;
        //                           communitiesController.newsfeedController.isProfileScreen = false;
        //                           communitiesController.newsfeedController.isFollwerScreen = false;
        //                           communitiesController.newsfeedController.isSettingsScreen = false;
        //                           communitiesController.newsfeedController.isTopicScreen = false;
        //                           communitiesController.newsfeedController.isCommunitesScreen = false;
        //                           communitiesController.newsfeedController.isCommunityScreen = true;
        //                           communitiesController.newsfeedController.update();
        //
        //
        //
        //                               }
        //                             : () {
        //                                 Navigator.pop(context);
        //                               },
        //                         child: Icon(
        //                           Icons.arrow_back,
        //                           color: Theme.of(context).brightness ==
        //                                   Brightness.dark
        //                               ? Colors.white
        //                               : Colors.black,
        //                           size: 25,
        //                         ),
        //                       ),
        //                       kIsWeb
        //                           ? SizedBox(
        //                               width: 50,
        //                             )
        //                           : SizedBox(width: 20),
        //                       Text(
        //                         'Community Name : Softech',
        //                         style: Theme.of(context).brightness ==
        //                                 Brightness.dark
        //                             ? TextStyle(
        //                                 fontSize: 15,
        //                                 fontWeight: FontWeight.w700,
        //                                 color: Colors.white)
        //                             : TextStyle(
        //                                 fontSize: 15,
        //                                 fontWeight: FontWeight.w700,
        //                                 color: Colors.black),
        //                       ),
        //                       Spacer(),
        //                       GestureDetector(
        //                         ///
        //                         onTap: kIsWeb
        //                             ? () {
        //                                 showDialog(
        //                                     context: context,
        //                                     builder: (BuildContext con) {
        //                                       return AlertDialog(
        //                                         contentPadding: EdgeInsets.zero,
        //                                         content: StatefulBuilder(
        //                                             builder: (BuildContext
        //                                                     context,
        //                                                 StateSetter setState) {
        //                                           return CommunityMembersList(
        //
        //                                               // communitiesController: communitiesController,
        //                                               );
        //                                         }),
        //                                       );
        //                                     });
        //                               }
        //                             : () {
        //                                 Navigator.push(
        //                                   context,
        //                                   MaterialPageRoute(
        //                                       builder: (context) =>
        //                                           CommunityMembersList()),
        //                                 );
        //                               },
        //
        //                         child: Text(
        //                           'Members : 1',
        //                           style: Theme.of(context).brightness ==
        //                                   Brightness.dark
        //                               ? TextStyle(
        //                                   fontSize: 15,
        //                                   fontWeight: FontWeight.w700,
        //                                   color: Color(0xFF0157d3),
        //                                 )
        //                               : TextStyle(
        //                                   fontSize: 15,
        //                                   fontWeight: FontWeight.w700,
        //                                   color: Color(0xFF0157d3),
        //                                 ),
        //                         ),
        //                       ),
        //                     ],
        //                   ),
        //                 ),
        //                 SizedBox(
        //                   height: 20,
        //                 ),
        //                 Stack(
        //                   children: [
        //                     SizedBox(
        //                       height: 10,
        //                     ),
        //                     Container(
        //                       height: 200,
        //                       width: Get.width,
        //                       color: Colors.cyanAccent,
        //                       child: controller.coverImage != null
        //                           ? Image.memory(
        //                               controller.coverImage,
        //                               fit: BoxFit.cover,
        //                             )
        //                           : Image.asset(
        //                               'assets/images/person_placeholder.png',
        //                               fit: BoxFit.cover,
        //                             ),
        //                     ),
        //                     Positioned(
        //                       top: 10,
        //                       right: 10,
        //                       child: Container(
        //                         height: 50,
        //                         width: 50,
        //                         alignment: Alignment.center,
        //                         // padding: const EdgeInsets.all(13),
        //                         decoration: BoxDecoration(
        //                           color: Colors.grey[600],
        //                           shape: BoxShape.circle,
        //                         ),
        //                         child: IconButton(
        //                           icon: Icon(
        //                             Icons.camera_alt_outlined,
        //                             size: 25,
        //                             color: Colors.white,
        //                           ),
        //                           onPressed: () async {
        //                             controller.coverImage = await controller.callGetImage();
        //
        //                             print(
        //                                 "controller.coverImage ${controller.coverImage}");
        //
        //                             controller.update();
        //                           },
        //                         ),
        //                       ),
        //                     ),
        //                   ],
        //                 ),
        //                 Padding(
        //                   padding: const EdgeInsets.all(10),
        //                   child: Card(
        //                     color:
        //                         Theme.of(context).brightness == Brightness.dark
        //                             ? Color(0xFF252526)
        //                             : Color(0xFFfafafa),
        //                     elevation: 1.0,
        //                     shape: RoundedRectangleBorder(
        //                         borderRadius: BorderRadius.circular(10)),
        //                     child: Container(
        //                       child: Padding(
        //                         padding: const EdgeInsets.only(
        //                             left: 10, top: 10, bottom: 10, right: 10),
        //                         child: Column(
        //                           crossAxisAlignment: CrossAxisAlignment.start,
        //                           children: [
        //                             Row(
        //                               children: [
        //                                 Text(
        //                                   "About this Group",
        //                                   style: TextStyle(
        //                                       color: Theme.of(context)
        //                                                   .brightness ==
        //                                               Brightness.dark
        //                                           ? Colors.white
        //                                           : Colors.black,
        //                                       fontSize: 20,
        //                                       fontWeight: FontWeight.bold),
        //                                 ),
        //                                 Spacer(),
        //                                 myPopMenu(context: context),
        //                                 MaterialButton(
        //                                   color:Color(0xFF0157d3),
        //                                   elevation: 0.0,
        //
        //                                   onHighlightChanged: (bool value) {
        //
        //
        //                                   },
        //                                   // hoverColor: Color(0xFF0157d3),
        //                                   // borderSide: const BorderSide(
        //                                   //   color: Colors.white,
        //                                   //   style: BorderStyle.solid,
        //                                   //   width: 1,
        //                                   // ),
        //                                   shape: RoundedRectangleBorder(
        //                                     borderRadius: BorderRadius.circular(5.0),
        //
        //                                   ),
        //
        //
        //                                   onPressed: () {
        //
        //
        //                                   },
        //                                   child: Padding(
        //                                     padding: const EdgeInsets.only(top: 10, bottom: 10),
        //                                     child:
        //
        //                                     Text(
        //
        //                                       "Join Group",
        //
        //                                       style: TextStyle(
        //                                           color:  Colors.white,
        //                                           fontWeight: FontWeight.bold
        //                                       ),
        //                                     ),
        //                                   ),
        //
        //                                 ),
        //                               ],
        //                             ),
        //                             Divider(
        //                               thickness: 1,
        //                             ),
        //                             kIsWeb
        //                                 ? Row(
        //                                     mainAxisAlignment:
        //                                         MainAxisAlignment.spaceBetween,
        //                                     children: [
        //                                       Icon(
        //                                         Icons.category,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 15,
        //                                       ),
        //                                       // SizedBox(
        //                                       //   width: 5,
        //                                       // ),
        //                                       Text(
        //                                         "Category:",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "General",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //
        //                                       Icon(
        //                                         Icons.group,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 15,
        //                                       ),
        //                                       Text(
        //                                         "Members:  ",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "1",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //
        //                                       Icon(
        //                                         Icons.remove_red_eye_rounded,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 15,
        //                                       ),
        //                                       // SizedBox(
        //                                       //   width: 5,
        //                                       // ),
        //                                       Text(
        //                                         "Pubic",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       // SizedBox(
        //                                       //   width: 5,
        //                                       // ),
        //                                       Tooltip(
        //                                         message:
        //                                             "Anyone can join this group",
        //                                         child: Icon(
        //                                           Icons.info,
        //                                           color: Color(0xFF0157d3),
        //                                           size: 15,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //
        //                                       Icon(
        //                                         Icons.remove_red_eye_rounded,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 15,
        //                                       ),
        //                                       // SizedBox(
        //                                       //   width: 5,
        //                                       // ),
        //                                       Text(
        //                                         "Visibility:  ",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "Visible Publicly",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 12,
        //                                         ),
        //                                       ),
        //                                       // SizedBox(
        //                                       //   width: 5,
        //                                       // ),
        //                                       Tooltip(
        //                                         message:
        //                                             "Anyone can search for your group",
        //                                         child: Icon(
        //                                           Icons.info,
        //                                           color: Color(0xFF0157d3),
        //                                           size: 15,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //
        //                                       GestureDetector(
        //                                         onTap: kIsWeb
        //                                             ? () {
        //                                                 showDialog(
        //                                                     context: context,
        //                                                     builder:
        //                                                         (BuildContext
        //                                                             con) {
        //                                                       return AlertDialog(
        //                                                         contentPadding:
        //                                                             EdgeInsets
        //                                                                 .zero,
        //                                                         content: StatefulBuilder(builder:
        //                                                             (BuildContext
        //                                                                     context,
        //                                                                 StateSetter
        //                                                                     setState) {
        //                                                           return CommunityRequests(
        //
        //                                                               // communitiesController: communitiesController,
        //                                                               );
        //                                                         }),
        //                                                       );
        //                                                     });
        //                                               }
        //                                             : () {
        //                                                 Navigator.push(
        //                                                   context,
        //                                                   MaterialPageRoute(
        //                                                       builder: (context) =>
        //                                                           CommunityRequests()),
        //                                                 );
        //                                               },
        //                                         child: Row(
        //                                           children: [
        //                                             Icon(
        //                                               Icons.group,
        //                                               color: Color(0xFF0157d3),
        //                                               size: 15,
        //                                             ),
        //
        //                                             Text(
        //                                               "Join Request:  ",
        //                                               style: TextStyle(
        //                                                 color: Theme.of(context)
        //                                                             .brightness ==
        //                                                         Brightness.dark
        //                                                     ? Colors.white
        //                                                     : Colors.black,
        //                                                 fontSize: 12,
        //                                               ),
        //                                             ),
        //                                             Text(
        //                                               "1",
        //                                               style: TextStyle(
        //                                                 color: Theme.of(context)
        //                                                             .brightness ==
        //                                                         Brightness.dark
        //                                                     ? Colors.white
        //                                                     : Colors.black,
        //                                                 fontSize: 12,
        //                                               ),
        //                                             ),
        //                                             Tooltip(
        //                                               message:
        //                                                   "Admin will Approved all the request to join private group",
        //                                               child: Icon(
        //                                                 Icons.info,
        //                                                 color:
        //                                                     Color(0xFF0157d3),
        //                                                 size: 15,
        //                                               ),
        //                                             ),
        //                                           ],
        //                                         ),
        //                                       ),
        //                                     ],
        //                                   )
        //                                 : Row(
        //                                     mainAxisAlignment:
        //                                         MainAxisAlignment.spaceBetween,
        //                                     children: [
        //                                       Icon(
        //                                         Icons.category,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 18,
        //                                       ),
        //                                       Text(
        //                                         "Category:",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "General",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //                                       Icon(
        //                                         Icons.group,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 18,
        //                                       ),
        //                                       Text(
        //                                         "Members:  ",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "1",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //                                       Icon(
        //                                         Icons.remove_red_eye_rounded,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 18,
        //                                       ),
        //                                       Text(
        //                                         "Pubic",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Tooltip(
        //                                         message:
        //                                             "Anyone can join this group",
        //                                         child: Icon(
        //                                           Icons.info,
        //                                           color: Color(0xFF0157d3),
        //                                           size: 18,
        //                                         ),
        //                                       ),
        //                                     ],
        //                                   ),
        //                             !kIsWeb
        //                                 ? Divider(
        //                                     thickness: 1,
        //                                   )
        //                                 : SizedBox(),
        //                             !kIsWeb
        //                                 ? Row(
        //                                     mainAxisAlignment:
        //                                         MainAxisAlignment.spaceBetween,
        //                                     children: [
        //                                       Icon(
        //                                         Icons.remove_red_eye_rounded,
        //                                         color: Color(0xFF0157d3),
        //                                         size: 18,
        //                                       ),
        //                                       Text(
        //                                         "Visibility:  ",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Text(
        //                                         "Visible Publicly",
        //                                         style: TextStyle(
        //                                           color: Theme.of(context)
        //                                                       .brightness ==
        //                                                   Brightness.dark
        //                                               ? Colors.white
        //                                               : Colors.black,
        //                                           fontSize: 14,
        //                                         ),
        //                                       ),
        //                                       Tooltip(
        //                                         message:
        //                                             "Anyone can search for your group",
        //                                         child: Icon(
        //                                           Icons.info,
        //                                           color: Color(0xFF0157d3),
        //                                           size: 18,
        //                                         ),
        //                                       ),
        //                                       Container(
        //                                         height: 50,
        //                                         width: 1,
        //                                         color: Colors.grey,
        //                                       ),
        //                                       GestureDetector(
        //                                         onTap: kIsWeb
        //                                             ? () {
        //                                                 showDialog(
        //                                                     context: context,
        //                                                     builder:
        //                                                         (BuildContext
        //                                                             con) {
        //                                                       return AlertDialog(
        //                                                         contentPadding:
        //                                                             EdgeInsets
        //                                                                 .zero,
        //                                                         content: StatefulBuilder(builder:
        //                                                             (BuildContext
        //                                                                     context,
        //                                                                 StateSetter
        //                                                                     setState) {
        //                                                           return CommunityRequests(
        //
        //                                                               // communitiesController: communitiesController,
        //                                                               );
        //                                                         }),
        //                                                       );
        //                                                     });
        //                                               }
        //                                             : () {
        //                                                 Navigator.push(
        //                                                   context,
        //                                                   MaterialPageRoute(
        //                                                       builder: (context) =>
        //                                                           CommunityRequests()),
        //                                                 );
        //                                               },
        //                                         child: Row(
        //                                           children: [
        //                                             Icon(
        //                                               Icons.group,
        //                                               color: Color(0xFF0157d3),
        //                                               size: 18,
        //                                             ),
        //                                             Text(
        //                                               "Join Request:  ",
        //                                               style: TextStyle(
        //                                                 color: Theme.of(context)
        //                                                             .brightness ==
        //                                                         Brightness.dark
        //                                                     ? Colors.white
        //                                                     : Colors.black,
        //                                                 fontSize: 14,
        //                                               ),
        //                                             ),
        //                                             Text(
        //                                               "1",
        //                                               style: TextStyle(
        //                                                 color: Theme.of(context)
        //                                                             .brightness ==
        //                                                         Brightness.dark
        //                                                     ? Colors.white
        //                                                     : Colors.black,
        //                                                 fontSize: 14,
        //                                               ),
        //                                             ),
        //                                             Tooltip(
        //                                               message:
        //                                                   "Admin will Approved all the request to join private group",
        //                                               child: Icon(
        //                                                 Icons.info,
        //                                                 color:
        //                                                     Color(0xFF0157d3),
        //                                                 size: 15,
        //                                               ),
        //                                             ),
        //                                           ],
        //                                         ),
        //                                       ),
        //                                     ],
        //                                   )
        //                                 : SizedBox(),
        //                             Divider(
        //                               thickness: 1,
        //                             ),
        //                             Row(
        //                               mainAxisAlignment:
        //                                   MainAxisAlignment.spaceBetween,
        //                               children: [
        //                                 Tab(
        //                                   title: 'Home',
        //                                   onTap: () {
        //                                     controller.HomeTab();
        //                                     controller.update();
        //                                   },
        //                                   isSelected: controller.isHome,
        //                                 ),
        //                                 Tab(
        //                                   title: 'Photos',
        //                                   onTap: () {
        //                                     controller.PhotosTab();
        //                                     controller.update();
        //                                   },
        //                                   isSelected: controller.isPhotos,
        //                                 ),
        //                                 Tab(
        //                                   title: 'Videos',
        //                                   onTap: () {
        //                                     controller.VideosTab();
        //                                     controller.update();
        //                                   },
        //                                   isSelected: controller.isVideos,
        //                                 ),
        //                               ],
        //                             ),
        //                           ],
        //                         ),
        //                       ),
        //                     ),
        //                   ),
        //                 ),
        //                 controller.isHome == true
        //                     ? kIsWeb
        //                         ? ListTile(
        //                             contentPadding: EdgeInsets.only(
        //                                 left: 8, right: 8, top: 12, bottom: 0),
        //                             leading: CircleAvatar(
        //                                 radius: 30,
        //                                 backgroundImage: AssetImage(
        //                                     "assets/images/person_placeholder.png")),
        //                             title: GestureDetector(
        //                               onTap: () {
        //                                 kIsWeb
        //                                     ? showDialog(
        //                                         context: context,
        //                                         builder:
        //                                             (BuildContext context) {
        //                                           return AlertDialog(
        //                                               shape: RoundedRectangleBorder(
        //                                                   borderRadius:
        //                                                       BorderRadius.all(
        //                                                           Radius.circular(
        //                                                               10.0))),
        //                                               insetPadding:
        //                                                   EdgeInsets.symmetric(
        //                                                       horizontal: 0,
        //                                                       vertical: 0),
        //                                               contentPadding:
        //                                                   EdgeInsets.symmetric(
        //                                                       horizontal: 12),
        //                                               content: DialogboxWeb(
        //                                                   controller
        //                                                       .newsfeedController,
        //                                                   null)
        //                                               // :
        //
        //                                               // DialogboxMobile(
        //                                               //     _scaffoldKey, controller),
        //                                               );
        //                                         },
        //                                         barrierDismissible: false,
        //                                       )
        //                                     : Navigator.push(
        //                                         context,
        //                                         MaterialPageRoute(
        //                                           builder: (BuildContext
        //                                                   context) =>
        //                                               CreatePostMobile(controller
        //                                                   .newsfeedController),
        //                                         ),
        //                                       );
        //                               },
        //                               child: Container(
        //                                 padding: EdgeInsets.only(
        //                                   left: 20,
        //                                 ),
        //                                 height: 50,
        //                                 decoration: BoxDecoration(
        //                                   borderRadius:
        //                                       BorderRadius.circular(40),
        //                                   border: Border.all(
        //                                     color: Colors.grey,
        //                                     width: 0.5,
        //                                   ),
        //                                   color: Theme.of(context)
        //                                       .scaffoldBackgroundColor,
        //                                 ),
        //                                 child: Align(
        //                                   alignment: Alignment.centerLeft,
        //                                   child: Text(
        //                                     // postId != null ? postId :
        //                                     Strings.saySomething,
        //                                     // style: TextStyle(
        //                                     //   color: Color(0xFF626c72),
        //                                     // ),
        //                                     style: Theme.of(context)
        //                                                 .brightness ==
        //                                             Brightness.dark
        //                                         ? TextStyle(
        //                                             color: Colors.white,
        //                                           )
        //                                         : TextStyle(
        //                                             color: Color(0xFF626c72),
        //                                           ),
        //                                   ),
        //                                 ),
        //                               ),
        //                             ),
        //                           )
        //                         : SizedBox()
        //                     : SizedBox(),
        //               ],
        //             ),
        //           )
        //
        //         // : Column(
        //         //     mainAxisAlignment: MainAxisAlignment.start,
        //         //     crossAxisAlignment: CrossAxisAlignment.start,
        //         //     children: [
        //         //       kIsWeb
        //         //           ? SizedBox(
        //         //               height: 20,
        //         //             )
        //         //           : SizedBox(height: 49),
        //         //       Padding(
        //         //         padding: const EdgeInsets.only(left: 10,right:
        //         //         10,bottom: 10),
        //         //         child: Row(
        //         //           children: [
        //         //             GestureDetector(
        //         //               onTap: kIsWeb
        //         //                   ? () {
        //         //                       // controller.newsfeedController.isTrendsScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController.isNewsFeedScreen =
        //         //                       // true;
        //         //                       // controller.newsfeedController.isBrowseScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController
        //         //                       //     .isNotificationScreen = false;
        //         //                       // controller.newsfeedController.isChatScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController
        //         //                       //     .isSavedPostScreen = false;
        //         //                       // controller.newsfeedController.isPostDetails =
        //         //                       // false;
        //         //                       // controller.newsfeedController.isProfileScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController
        //         //                       //     .isOtherUserProfileScreen = false;
        //         //                       // controller.newsfeedController.isTopicScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController.isListScreen =
        //         //                       // false;
        //         //                       // controller.newsfeedController
        //         //                       //     .isMainTopicScreen = false;
        //         //                       // controller.newsfeedController.update();
        //         //                     }
        //         //                   : () {
        //         //                       Navigator.pop(context);
        //         //                     },
        //         //               child: Icon(
        //         //                 Icons.arrow_back,
        //         //                 color: Theme.of(context).brightness ==
        //         //                         Brightness.dark
        //         //                     ? Colors.white
        //         //                     : Colors.black,
        //         //                 size: 25,
        //         //               ),
        //         //             ),
        //         //             kIsWeb
        //         //                 ? SizedBox(
        //         //                     width: 50,
        //         //                   )
        //         //                 : SizedBox(width: 20),
        //         //             Text(
        //         //               'Community Name : Softech',
        //         //               style: Theme.of(context).brightness ==
        //         //                       Brightness.dark
        //         //                   ? TextStyle(
        //         //                       fontSize: 15,
        //         //                       fontWeight: FontWeight.w700,
        //         //                       color: Colors.white)
        //         //                   : TextStyle(
        //         //                       fontSize: 15,
        //         //                       fontWeight: FontWeight.w700,
        //         //                       color: Colors.black),
        //         //             ),
        //         //             Spacer(),
        //         //             GestureDetector(
        //         //               ///
        //         //               onTap: kIsWeb
        //         //                   ? () {
        //         //                       showDialog(
        //         //                           context: context,
        //         //                           builder: (BuildContext con) {
        //         //                             return AlertDialog(
        //         //                               contentPadding: EdgeInsets.zero,
        //         //                               content: StatefulBuilder(builder:
        //         //                                   (BuildContext context,
        //         //                                       StateSetter setState) {
        //         //                                 return CommunityMembersList(
        //         //
        //         //                                     // communitiesController: communitiesController,
        //         //                                     );
        //         //                               }),
        //         //                             );
        //         //                           });
        //         //                     }
        //         //                   : () {
        //         //                       Navigator.push(
        //         //                         context,
        //         //                         MaterialPageRoute(
        //         //                             builder: (context) =>
        //         //                                 CommunityMembersList()),
        //         //                       );
        //         //                     },
        //         //
        //         //               child: Text(
        //         //                 'Members : 1',
        //         //                 style: Theme.of(context).brightness ==
        //         //                         Brightness.dark
        //         //                     ? TextStyle(
        //         //                         fontSize: 15,
        //         //                         fontWeight: FontWeight.w700,
        //         //                         color: Color(0xFF0157d3),
        //         //                       )
        //         //                     : TextStyle(
        //         //                         fontSize: 15,
        //         //                         fontWeight: FontWeight.w700,
        //         //                         color: Color(0xFF0157d3),
        //         //                       ),
        //         //               ),
        //         //             ),
        //         //           ],
        //         //         ),
        //         //       ),
        //         //       Stack(
        //         //         children: [
        //         //           SizedBox(
        //         //             height: 10,
        //         //           ),
        //         //           Container(
        //         //             height: 150,
        //         //             width: Get.width,
        //         //             color: Colors.cyanAccent,
        //         //             child: controller.coverImage != null
        //         //                 ? Image.memory(
        //         //                     controller.coverImage,
        //         //                     fit: BoxFit.cover,
        //         //                   )
        //         //                 : Image.asset(
        //         //                     'assets/images/person_placeholder.png',
        //         //                     fit: BoxFit.cover,
        //         //                   ),
        //         //           ),
        //         //           Positioned(
        //         //             top: 10,
        //         //             right: 10,
        //         //             child: Container(
        //         //               height: 50,
        //         //               width: 50,
        //         //               alignment: Alignment.center,
        //         //               // padding: const EdgeInsets.all(13),
        //         //               decoration: BoxDecoration(
        //         //                 color: Colors.grey[600],
        //         //                 shape: BoxShape.circle,
        //         //               ),
        //         //               child: IconButton(
        //         //                 icon: Icon(
        //         //                   Icons.camera_alt_outlined,
        //         //                   size: 25,
        //         //                   color: Colors.white,
        //         //                 ),
        //         //                 onPressed: () async {
        //         //                   controller.coverImage =
        //         //                       await controller.callGetImage();
        //         //
        //         //                   print(
        //         //                       "controller.coverImage ${controller.coverImage}");
        //         //
        //         //                   controller.update();
        //         //                 },
        //         //               ),
        //         //             ),
        //         //           ),
        //         //         ],
        //         //       ),
        //         //       Padding(
        //         //         padding: const EdgeInsets.only(top: 10),
        //         //         child: Card(
        //         //           color: Theme.of(context).brightness == Brightness.dark
        //         //               ? Color(0xFF252526)
        //         //               : Color(0xFFfafafa),
        //         //           elevation: 1.0,
        //         //           shape: RoundedRectangleBorder(
        //         //               borderRadius: BorderRadius.circular(10)),
        //         //           child: Container(
        //         //             child: Padding(
        //         //               padding: const EdgeInsets.only(
        //         //                   left: 10, top: 10, bottom: 10, right: 10),
        //         //               child: Column(
        //         //                 crossAxisAlignment: CrossAxisAlignment.start,
        //         //                 children: [
        //         //                   Row(
        //         //                     children: [
        //         //                       Text(
        //         //                         "About this Group",
        //         //                         style: TextStyle(
        //         //                             color:
        //         //                                 Theme.of(context).brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                             fontSize: 20,
        //         //                             fontWeight: FontWeight.bold),
        //         //                       ),
        //         //                       Spacer(),
        //         //
        //         //                       myPopMenu(context: context),
        //         //                       MaterialButton(
        //         //                         color:Color(0xFF0157d3),
        //         //                         elevation: 0.0,
        //         //
        //         //                         onHighlightChanged: (bool value) {
        //         //
        //         //
        //         //                         },
        //         //                         // hoverColor: Color(0xFF0157d3),
        //         //                         // borderSide: const BorderSide(
        //         //                         //   color: Colors.white,
        //         //                         //   style: BorderStyle.solid,
        //         //                         //   width: 1,
        //         //                         // ),
        //         //                         shape: RoundedRectangleBorder(
        //         //                           borderRadius: BorderRadius.circular(5.0),
        //         //
        //         //                         ),
        //         //
        //         //
        //         //                         onPressed: () {
        //         //
        //         //
        //         //                         },
        //         //                         child: Padding(
        //         //                           padding: const EdgeInsets.only(top: 10, bottom: 10),
        //         //                           child:
        //         //
        //         //                           Text(
        //         //
        //         //                             "Join Group",
        //         //
        //         //                             style: TextStyle(
        //         //                                 color:  Colors.white,
        //         //                                 fontWeight: FontWeight.bold
        //         //                             ),
        //         //                           ),
        //         //                         ),
        //         //
        //         //                       ),
        //         //                     ],
        //         //                   ),
        //         //                   Divider(
        //         //                     thickness: 1,
        //         //                   ),
        //         //                   kIsWeb
        //         //                       ? Row(
        //         //                           mainAxisAlignment:
        //         //                               MainAxisAlignment.spaceBetween,
        //         //                           children: [
        //         //                             Icon(
        //         //                               Icons.category,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 15,
        //         //                             ),
        //         //                             // SizedBox(
        //         //                             //   width: 5,
        //         //                             // ),
        //         //                             Text(
        //         //                               "Category:",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "General",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //
        //         //                             Icon(
        //         //                               Icons.group,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 15,
        //         //                             ),
        //         //                             Text(
        //         //                               "Members:  ",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "1",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //
        //         //                             Icon(
        //         //                               Icons.remove_red_eye_rounded,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 15,
        //         //                             ),
        //         //                             // SizedBox(
        //         //                             //   width: 5,
        //         //                             // ),
        //         //                             Text(
        //         //                               "Pubic",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             // SizedBox(
        //         //                             //   width: 5,
        //         //                             // ),
        //         //                             Tooltip(
        //         //                               message:
        //         //                                   "Anyone can join this group",
        //         //                               child: Icon(
        //         //                                 Icons.info,
        //         //                                 color: Color(0xFF0157d3),
        //         //                                 size: 15,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //
        //         //                             Icon(
        //         //                               Icons.remove_red_eye_rounded,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 15,
        //         //                             ),
        //         //                             // SizedBox(
        //         //                             //   width: 5,
        //         //                             // ),
        //         //                             Text(
        //         //                               "Visibility:  ",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "Visible Publicly",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 12,
        //         //                               ),
        //         //                             ),
        //         //                             // SizedBox(
        //         //                             //   width: 5,
        //         //                             // ),
        //         //                             Tooltip(
        //         //                               message:
        //         //                                   "Anyone can search for your group",
        //         //                               child: Icon(
        //         //                                 Icons.info,
        //         //                                 color: Color(0xFF0157d3),
        //         //                                 size: 15,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //
        //         //                             GestureDetector(
        //         //                               onTap: kIsWeb
        //         //                                   ? () {
        //         //                                       showDialog(
        //         //                                           context: context,
        //         //                                           builder: (BuildContext
        //         //                                               con) {
        //         //                                             return AlertDialog(
        //         //                                               contentPadding:
        //         //                                                   EdgeInsets
        //         //                                                       .zero,
        //         //                                               content: StatefulBuilder(builder:
        //         //                                                   (BuildContext
        //         //                                                           context,
        //         //                                                       StateSetter
        //         //                                                           setState) {
        //         //                                                 return CommunityRequests(
        //         //
        //         //                                                     // communitiesController: communitiesController,
        //         //                                                     );
        //         //                                               }),
        //         //                                             );
        //         //                                           });
        //         //                                     }
        //         //                                   : () {
        //         //                                       Navigator.push(
        //         //                                         context,
        //         //                                         MaterialPageRoute(
        //         //                                             builder: (context) =>
        //         //                                                 CommunityRequests()),
        //         //                                       );
        //         //                                     },
        //         //                               child: Row(
        //         //                                 children: [
        //         //                                   Icon(
        //         //                                     Icons.group,
        //         //                                     color: Color(0xFF0157d3),
        //         //                                     size: 15,
        //         //                                   ),
        //         //                                   SizedBox(
        //         //                                     width: 20,
        //         //                                   ),
        //         //                                   Text(
        //         //                                     "Join Request:  ",
        //         //                                     style: TextStyle(
        //         //                                       color: Theme.of(context)
        //         //                                                   .brightness ==
        //         //                                               Brightness.dark
        //         //                                           ? Colors.white
        //         //                                           : Colors.black,
        //         //                                       fontSize: 12,
        //         //                                     ),
        //         //                                   ),
        //         //                                   Text(
        //         //                                     "1",
        //         //                                     style: TextStyle(
        //         //                                       color: Theme.of(context)
        //         //                                                   .brightness ==
        //         //                                               Brightness.dark
        //         //                                           ? Colors.white
        //         //                                           : Colors.black,
        //         //                                       fontSize: 12,
        //         //                                     ),
        //         //                                   ),
        //         //                                   SizedBox(
        //         //                                     width: 20,
        //         //                                   ),
        //         //                                   Tooltip(
        //         //                                     message:
        //         //                                         "Admin will Approved all the request to join private group",
        //         //                                     child: Icon(
        //         //                                       Icons.info,
        //         //                                       color: Color(0xFF0157d3),
        //         //                                       size: 15,
        //         //                                     ),
        //         //                                   ),
        //         //                                 ],
        //         //                               ),
        //         //                             ),
        //         //                           ],
        //         //                         )
        //         //                       : Row(
        //         //                           mainAxisAlignment:
        //         //                               MainAxisAlignment.spaceBetween,
        //         //                           children: [
        //         //                             Icon(
        //         //                               Icons.category,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 18,
        //         //                             ),
        //         //                             Text(
        //         //                               "Category:",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "General",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //                             Icon(
        //         //                               Icons.group,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 18,
        //         //                             ),
        //         //                             Text(
        //         //                               "Members:  ",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "1",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //                             Icon(
        //         //                               Icons.remove_red_eye_rounded,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 18,
        //         //                             ),
        //         //                             Text(
        //         //                               "Pubic",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Tooltip(
        //         //                               message:
        //         //                                   "Anyone can join this group",
        //         //                               child: Icon(
        //         //                                 Icons.info,
        //         //                                 color: Color(0xFF0157d3),
        //         //                                 size: 18,
        //         //                               ),
        //         //                             ),
        //         //                           ],
        //         //                         ),
        //         //                   !kIsWeb
        //         //                       ? Divider(
        //         //                           thickness: 1,
        //         //                         )
        //         //                       : SizedBox(),
        //         //                   !kIsWeb
        //         //                       ? Row(
        //         //                           mainAxisAlignment:
        //         //                               MainAxisAlignment.spaceBetween,
        //         //                           children: [
        //         //                             Icon(
        //         //                               Icons.remove_red_eye_rounded,
        //         //                               color: Color(0xFF0157d3),
        //         //                               size: 18,
        //         //                             ),
        //         //                             Text(
        //         //                               "Visibility:  ",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Text(
        //         //                               "Visible Publicly",
        //         //                               style: TextStyle(
        //         //                                 color: Theme.of(context)
        //         //                                             .brightness ==
        //         //                                         Brightness.dark
        //         //                                     ? Colors.white
        //         //                                     : Colors.black,
        //         //                                 fontSize: 14,
        //         //                               ),
        //         //                             ),
        //         //                             Tooltip(
        //         //                               message:
        //         //                                   "Anyone can search for your group",
        //         //                               child: Icon(
        //         //                                 Icons.info,
        //         //                                 color: Color(0xFF0157d3),
        //         //                                 size: 18,
        //         //                               ),
        //         //                             ),
        //         //                             Container(
        //         //                               height: 50,
        //         //                               width: 1,
        //         //                               color: Colors.grey,
        //         //                             ),
        //         //                             GestureDetector(
        //         //                               onTap: kIsWeb
        //         //                                   ? () {
        //         //                                       showDialog(
        //         //                                           context: context,
        //         //                                           builder: (BuildContext
        //         //                                               con) {
        //         //                                             return AlertDialog(
        //         //                                               contentPadding:
        //         //                                                   EdgeInsets
        //         //                                                       .zero,
        //         //                                               content: StatefulBuilder(builder:
        //         //                                                   (BuildContext
        //         //                                                           context,
        //         //                                                       StateSetter
        //         //                                                           setState) {
        //         //                                                 return CommunityRequests(
        //         //
        //         //                                                     // communitiesController: communitiesController,
        //         //                                                     );
        //         //                                               }),
        //         //                                             );
        //         //                                           });
        //         //                                     }
        //         //                                   : () {
        //         //                                       Navigator.push(
        //         //                                         context,
        //         //                                         MaterialPageRoute(
        //         //                                             builder: (context) =>
        //         //                                                 CommunityRequests()),
        //         //                                       );
        //         //                                     },
        //         //                               child: Row(
        //         //                                 children: [
        //         //                                   Icon(
        //         //                                     Icons.group,
        //         //                                     color: Color(0xFF0157d3),
        //         //                                     size: 18,
        //         //                                   ),
        //         //                                   SizedBox(
        //         //                                     width: 20,
        //         //                                   ),
        //         //                                   Text(
        //         //                                     "Join Request:  ",
        //         //                                     style: TextStyle(
        //         //                                       color: Theme.of(context)
        //         //                                                   .brightness ==
        //         //                                               Brightness.dark
        //         //                                           ? Colors.white
        //         //                                           : Colors.black,
        //         //                                       fontSize: 14,
        //         //                                     ),
        //         //                                   ),
        //         //                                   Text(
        //         //                                     "1",
        //         //                                     style: TextStyle(
        //         //                                       color: Theme.of(context)
        //         //                                                   .brightness ==
        //         //                                               Brightness.dark
        //         //                                           ? Colors.white
        //         //                                           : Colors.black,
        //         //                                       fontSize: 14,
        //         //                                     ),
        //         //                                   ),
        //         //                                   SizedBox(
        //         //                                     width: 20,
        //         //                                   ),
        //         //                                   Tooltip(
        //         //                                     message:
        //         //                                         "Admin will Approved all the request to join private group",
        //         //                                     child: Icon(
        //         //                                       Icons.info,
        //         //                                       color: Color(0xFF0157d3),
        //         //                                       size: 15,
        //         //                                     ),
        //         //                                   ),
        //         //                                 ],
        //         //                               ),
        //         //                             ),
        //         //                           ],
        //         //                         )
        //         //                       : SizedBox(),
        //         //                   Divider(
        //         //                     thickness: 1,
        //         //                   ),
        //         //                   Row(
        //         //                     mainAxisAlignment:
        //         //                         MainAxisAlignment.spaceBetween,
        //         //                     children: [
        //         //                       Tab(
        //         //                         title: 'Home',
        //         //                         onTap: () {
        //         //                           controller.HomeTab();
        //         //                           controller.update();
        //         //                         },
        //         //                         isSelected: controller.isHome,
        //         //                       ),
        //         //                       Tab(
        //         //                         title: 'Photos',
        //         //                         onTap: () {
        //         //                           controller.PhotosTab();
        //         //                           controller.update();
        //         //                         },
        //         //                         isSelected: controller.isPhotos,
        //         //                       ),
        //         //                       Tab(
        //         //                         title: 'Videos',
        //         //                         onTap: () {
        //         //                           controller.VideosTab();
        //         //                           controller.update();
        //         //                         },
        //         //                         isSelected: controller.isVideos,
        //         //                       ),
        //         //                     ],
        //         //                   ),
        //         //                 ],
        //         //               ),
        //         //             ),
        //         //           ),
        //         //         ),
        //         //       ),
        //         //       controller.isHome == true
        //         //           ? kIsWeb
        //         //               ? ListTile(
        //         //                   contentPadding: EdgeInsets.only(
        //         //                       left: 8, right: 8, top: 12, bottom: 0),
        //         //                   leading: CircleAvatar(
        //         //                       radius: 30,
        //         //                       backgroundImage: AssetImage(
        //         //                           "assets/images/person_placeholder.png")),
        //         //                   title: GestureDetector(
        //         //                     onTap: () {
        //         //                       kIsWeb
        //         //                           ? showDialog(
        //         //                               context: context,
        //         //                               builder: (BuildContext context) {
        //         //                                 return AlertDialog(
        //         //                                     shape: RoundedRectangleBorder(
        //         //                                         borderRadius:
        //         //                                             BorderRadius.all(
        //         //                                                 Radius.circular(
        //         //                                                     10.0))),
        //         //                                     insetPadding:
        //         //                                         EdgeInsets.symmetric(
        //         //                                             horizontal: 0,
        //         //                                             vertical: 0),
        //         //                                     contentPadding:
        //         //                                         EdgeInsets.symmetric(
        //         //                                             horizontal: 12),
        //         //                                     content: DialogboxWeb(
        //         //                                         controller
        //         //                                             .newsfeedController,
        //         //                                         null)
        //         //                                     // :
        //         //
        //         //                                     // DialogboxMobile(
        //         //                                     //     _scaffoldKey, controller),
        //         //                                     );
        //         //                               },
        //         //                               barrierDismissible: false,
        //         //                             )
        //         //                           : Navigator.push(
        //         //                               context,
        //         //                               MaterialPageRoute(
        //         //                                 builder: (BuildContext
        //         //                                         context) =>
        //         //                                     CreatePostMobile(controller
        //         //                                         .newsfeedController),
        //         //                               ),
        //         //                             );
        //         //                     },
        //         //                     child: Container(
        //         //                       padding: EdgeInsets.only(
        //         //                         left: 20,
        //         //                       ),
        //         //                       height: 50,
        //         //                       decoration: BoxDecoration(
        //         //                         borderRadius: BorderRadius.circular(40),
        //         //                         border: Border.all(
        //         //                           color: Colors.grey,
        //         //                           width: 0.5,
        //         //                         ),
        //         //                         color: Theme.of(context)
        //         //                             .scaffoldBackgroundColor,
        //         //                       ),
        //         //                       child: Align(
        //         //                         alignment: Alignment.centerLeft,
        //         //                         child: Text(
        //         //                           // postId != null ? postId :
        //         //                           Strings.saySomething,
        //         //                           // style: TextStyle(
        //         //                           //   color: Color(0xFF626c72),
        //         //                           // ),
        //         //                           style: Theme.of(context).brightness ==
        //         //                                   Brightness.dark
        //         //                               ? TextStyle(
        //         //                                   color: Colors.white,
        //         //                                 )
        //         //                               : TextStyle(
        //         //                                   color: Color(0xFF626c72),
        //         //                                 ),
        //         //                         ),
        //         //                       ),
        //         //                     ),
        //         //                   ),
        //         //                 )
        //         //               : SizedBox()
        //         //           : SizedBox(),
        //         //
        //         //
        //         //     ],
        //         //   ),
        //   ),
        // ),
        body: NestedScrollView(
          physics: controller.isPhotos || controller.isAbout
              ? NeverScrollableScrollPhysics()
              : AlwaysScrollableScrollPhysics(),
          controller: controller.scrollController,
          floatHeaderSlivers: true,
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              SliverAppBar(
                elevation: 0,
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                automaticallyImplyLeading: false,
                pinned: false,
                expandedHeight: 370,
                flexibleSpace: FlexibleSpaceBar(
                  collapseMode: CollapseMode.parallax,
                  title: controller.isShrink
                      ? Text(
                          'Community Name : Softech',
                          style: Theme.of(context).brightness == Brightness.dark
                              ? TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white)
                              : TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                        )
                      : null,
                  background: SafeArea(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: kIsWeb ? 20 : 10,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: kIsWeb
                                    ? () {
                                        // communitiesController.timer.;
                                        // communitiesController.timer3?.cancel();
                                        // communitiesController.timer2?.cancel();
                                        // communitiesController.timer4?.cancel();
                                        // communitiesController.update();
                                        // ///idhr ana

                                        communitiesController.newsfeedController
                                            .isSearch = false;
                                        communitiesController.newsfeedController
                                            .isFilter = false;
                                        communitiesController.newsfeedController
                                            .isFilterScreen = false;
                                        communitiesController.newsfeedController
                                            .isTrendsScreen = false;
                                        communitiesController.newsfeedController
                                            .isNewsFeedScreen = false;
                                        communitiesController.newsfeedController
                                            .isBrowseScreen = false;
                                        communitiesController.newsfeedController
                                            .isNotificationScreen = false;
                                        communitiesController.newsfeedController
                                            .isSavedPostScreen = false;
                                        communitiesController.newsfeedController
                                            .isWhoToFollowScreen = false;
                                        communitiesController.newsfeedController
                                            .isChatScreen = false;
                                        communitiesController.newsfeedController
                                            .isPostDetails = false;
                                        communitiesController.newsfeedController
                                            .searchText.text = '';
                                        communitiesController.newsfeedController
                                            .isListScreen = false;
                                        communitiesController.newsfeedController
                                            .isListDetailScreen = false;
                                        communitiesController.newsfeedController
                                            .isProfileScreen = false;
                                        communitiesController.newsfeedController
                                            .isFollwerScreen = false;
                                        communitiesController.newsfeedController
                                            .isSettingsScreen = false;
                                        communitiesController.newsfeedController
                                            .isTopicScreen = false;
                                        communitiesController.newsfeedController
                                            .isCommunitesScreen = false;
                                        communitiesController.newsfeedController
                                            .isCommunityScreen = true;
                                        communitiesController.newsfeedController
                                            .update();
                                      }
                                    : () {
                                        Navigator.pop(context);
                                      },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 25,
                                ),
                              ),
                              kIsWeb
                                  ? SizedBox(
                                      width: 50,
                                    )
                                  : SizedBox(width: 20),
                              Text(
                                'Community Name : Softech',
                                style: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white)
                                    : TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.black),
                              ),
                              Spacer(),
                              GestureDetector(
                                ///
                                onTap: kIsWeb
                                    ? () {
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext con) {
                                              return AlertDialog(
                                                contentPadding: EdgeInsets.zero,
                                                content: StatefulBuilder(
                                                    builder: (BuildContext
                                                            context,
                                                        StateSetter setState) {
                                                  return CommunityMembersList(

                                                      // communitiesController: communitiesController,
                                                      );
                                                }),
                                              );
                                            });
                                      }
                                    : () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  CommunityMembersList()),
                                        );
                                      },

                                child: Text(
                                  'Members : 1',
                                  style: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: Color(0xFF0157d3),
                                        )
                                      : TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w700,
                                          color: Color(0xFF0157d3),
                                        ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Stack(
                          children: [
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              height: kIsWeb ? 180 : 160,
                              width: Get.width,
                              color: Colors.cyanAccent,
                              child: controller.coverImage != null
                                  ? Image.memory(
                                      controller.coverImage,
                                      fit: BoxFit.cover,
                                    )
                                  : Image.asset(
                                      'assets/images/person_placeholder.png',
                                      fit: BoxFit.cover,
                                    ),
                            ),
                            Positioned(
                              top: 10,
                              right: 10,
                              child: Container(
                                height: 50,
                                width: 50,
                                alignment: Alignment.center,
                                // padding: const EdgeInsets.all(13),
                                decoration: BoxDecoration(
                                  color: Colors.grey[600],
                                  shape: BoxShape.circle,
                                ),
                                child: IconButton(
                                  icon: Icon(
                                    Icons.camera_alt_outlined,
                                    size: 25,
                                    color: Colors.white,
                                  ),
                                  onPressed: () async {
                                    controller.coverImage =
                                        await controller.callGetImage();

                                    // print(
                                    //     "controller.coverImage ${controller.coverImage}");

                                    controller.update();
                                  },
                                ),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: Card(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Color(0xFF252526)
                                    : Color(0xFFfafafa),
                            elevation: 1.0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                            child: Container(
                              child: Padding(
                                padding: const EdgeInsets.only(
                                    left: 10, top: 10, bottom: 10, right: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          "About this Group",
                                          style: TextStyle(
                                              color: Theme.of(context)
                                                          .brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Spacer(),
                                        myPopMenu(context: context),
                                        MaterialButton(
                                          color: Color(0xFF0157d3),
                                          elevation: 0.0,

                                          onHighlightChanged: (bool value) {},
                                          // hoverColor: Color(0xFF0157d3),
                                          // borderSide: const BorderSide(
                                          //   color: Colors.white,
                                          //   style: BorderStyle.solid,
                                          //   width: 1,
                                          // ),
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                          ),

                                          onPressed: () {},
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                top: 10, bottom: 10),
                                            child: Text(
                                              "Join Group",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Divider(
                                      thickness: 1,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Tab(
                                          title: 'Home',
                                          onTap: () {
                                            controller.HomeTab();
                                            controller.update();
                                          },
                                          isSelected: controller.isHome,
                                        ),
                                        Tab(
                                          title: 'About',
                                          onTap: () {
                                            controller.AboutTab();
                                            controller.update();
                                          },
                                          isSelected: controller.isAbout,
                                        ),
                                        Tab(
                                          title: 'Photos',
                                          onTap: () {
                                            controller.PhotosTab();
                                            controller.update();
                                          },
                                          isSelected: controller.isPhotos,
                                        ),
                                        Tab(
                                          title: 'Videos',
                                          onTap: () {
                                            controller.VideosTab();
                                            controller.update();
                                          },
                                          isSelected: controller.isVideos,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                leading: controller.isShrink
                    ? GestureDetector(
                        onTap: kIsWeb
                            ? () {
                                // communitiesController.timer.;
                                // communitiesController.timer3?.cancel();
                                // communitiesController.timer2?.cancel();
                                // communitiesController.timer4?.cancel();
                                // communitiesController.update();
                                // ///idhr ana

                                communitiesController
                                    .newsfeedController.isSearch = false;
                                communitiesController
                                    .newsfeedController.isFilter = false;
                                communitiesController
                                    .newsfeedController.isFilterScreen = false;
                                communitiesController
                                    .newsfeedController.isTrendsScreen = false;
                                communitiesController.newsfeedController
                                    .isNewsFeedScreen = false;
                                communitiesController
                                    .newsfeedController.isBrowseScreen = false;
                                communitiesController.newsfeedController
                                    .isNotificationScreen = false;
                                communitiesController.newsfeedController
                                    .isSavedPostScreen = false;
                                communitiesController.newsfeedController
                                    .isWhoToFollowScreen = false;
                                communitiesController
                                    .newsfeedController.isChatScreen = false;
                                communitiesController
                                    .newsfeedController.isPostDetails = false;
                                communitiesController
                                    .newsfeedController.searchText.text = '';
                                communitiesController
                                    .newsfeedController.isListScreen = false;
                                communitiesController.newsfeedController
                                    .isListDetailScreen = false;
                                communitiesController
                                    .newsfeedController.isProfileScreen = false;
                                communitiesController
                                    .newsfeedController.isFollwerScreen = false;
                                communitiesController.newsfeedController
                                    .isSettingsScreen = false;
                                communitiesController
                                    .newsfeedController.isTopicScreen = false;
                                communitiesController.newsfeedController
                                    .isCommunitesScreen = false;
                                communitiesController.newsfeedController
                                    .isCommunityScreen = true;
                                communitiesController.newsfeedController
                                    .update();
                              }
                            : () {
                                Navigator.pop(context);
                              },
                        child: Icon(
                          Icons.arrow_back,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          size: 25,
                        ),
                      )
                    : null,
                actions: controller.isShrink
                    ? [
                        Center(
                          child: Padding(
                            padding: EdgeInsets.only(right: 10),
                            child: GestureDetector(
                              ///
                              onTap: kIsWeb
                                  ? () {
                                      showDialog(
                                          context: context,
                                          builder: (BuildContext con) {
                                            return AlertDialog(
                                              contentPadding: EdgeInsets.zero,
                                              content: StatefulBuilder(builder:
                                                  (BuildContext context,
                                                      StateSetter setState) {
                                                return CommunityMembersList(

                                                    // communitiesController: communitiesController,
                                                    );
                                              }),
                                            );
                                          });
                                    }
                                  : () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                CommunityMembersList()),
                                      );
                                    },

                              child: Text(
                                'Members : 1',
                                style: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFF0157d3),
                                      )
                                    : TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w700,
                                        color: Color(0xFF0157d3),
                                      ),
                              ),
                            ),
                          ),
                        ),
                      ]
                    : null,
              ),
            ];
          },
          body: controller.isPhotos == true
              ? SingleChildScrollView(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: Get.width,
                          height: 230,
                          decoration: BoxDecoration(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Color(0xFF252526)
                                    : Color(0xFFfafafa),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 10, top: 10),
                                child: Text("Photos",
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w700,
                                          )
                                        : TextStyle(
                                            color: Colors.black,
                                            fontSize: 20,
                                          )),
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 10, right: 10),
                                child: Row(
                                  children: [
                                    SizedBox(
                                      height: 20,
                                    ),
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {
                                          controller.isSelectedTimelinePhotos =
                                              true;
                                          controller.isSelectedCoverPhotos =
                                              false;
                                          controller.isSelectedAdminPhotos =
                                              false;
                                          controller.update();
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: 100,
                                              decoration: BoxDecoration(
                                                  // color: Color(0xFF252526),
                                                  image: DecorationImage(
                                                      image: NetworkImage(
                                                          "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                      fit: BoxFit.cover)),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text("Timeline Pictures",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 20 : 13,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 20 : 13,
                                                      )),
                                            Text("2 Photos",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      ))
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 20,
                                    ),
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {
                                          controller.isSelectedTimelinePhotos =
                                              false;
                                          controller.isSelectedCoverPhotos =
                                              true;
                                          controller.isSelectedAdminPhotos =
                                              false;
                                          controller.update();
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: 100,
                                              decoration: BoxDecoration(
                                                  // color: Color(0xFF252526),
                                                  image: DecorationImage(
                                                      image: NetworkImage(
                                                          "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                      fit: BoxFit.cover)),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text("Admin pictures",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 20 : 15,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 20 : 15,
                                                      )),
                                            Text("2 Photos",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      ))
                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 20,
                                    ),
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: () {
                                          controller.isSelectedTimelinePhotos =
                                              false;
                                          controller.isSelectedCoverPhotos =
                                              false;
                                          controller.isSelectedAdminPhotos =
                                              true;
                                          controller.update();
                                        },
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              height: 100,
                                              decoration: BoxDecoration(

                                                  // color: Color(0xFF252526),
                                                  image: DecorationImage(
                                                      image: NetworkImage(
                                                          "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                      fit: BoxFit.cover)),
                                            ),
                                            SizedBox(
                                              height: 10,
                                            ),
                                            Text("Cover Pictures",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 20 : 15,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 20 : 15,
                                                      )),
                                            Text("2 Photos",
                                                style: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                        fontSize:
                                                            kIsWeb ? 14 : 10,
                                                      ))
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Container(
                          width: Get.width,
                          height: 230,
                          decoration: BoxDecoration(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Color(0xFF252526)
                                    : Color(0xFFfafafa),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 10, top: 10),
                                child: Text(
                                    controller.isSelectedTimelinePhotos == true
                                        ? "All Photos"
                                        : controller.isSelectedCoverPhotos ==
                                                true
                                            ? "Covers Pictures"
                                            : controller.isSelectedAdminPhotos ==
                                                    true
                                                ? "Admin Pictures"
                                                : '',
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            color: Colors.white,
                                            fontSize: 20,
                                            fontWeight: FontWeight.w700,
                                          )
                                        : TextStyle(
                                            color: Colors.black,
                                            fontSize: 20,
                                          )),
                              ),
                              Expanded(
                                child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: 10,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: Container(
                                          width: 200,
                                          decoration: BoxDecoration(

                                              // color: Color(0xFF252526),
                                              image: DecorationImage(
                                                  image: NetworkImage(
                                                      "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                                  fit: BoxFit.cover)),
                                        ),
                                      );
                                    }),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : controller.isHome == true
                  ? Column(
                      children: [
                        ListTile(
                          contentPadding: EdgeInsets.only(
                              left: 8, right: 8, top: 0, bottom: 0),
                          leading: CircleAvatar(
                              radius: 30,
                              backgroundImage: AssetImage(
                                  "assets/images/person_placeholder.png")),
                          title: GestureDetector(
                            onTap: () {
                              kIsWeb
                                  ? showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10.0))),
                                          insetPadding: EdgeInsets.symmetric(
                                              horizontal: 0, vertical: 0),
                                          contentPadding: EdgeInsets.symmetric(
                                              horizontal: 12),
                                          // content: DialogboxWeb(
                                          //     controller
                                          //         .newsfeedController,
                                          //
                                          //     null,
                                          //    false,
                                          //   true,)
                                          // :

                                          // DialogboxMobile(
                                          //     _scaffoldKey, controller),
                                        );
                                      },
                                      barrierDismissible: false,
                                    )
                                  : Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            CreatePostMobile(
                                                controller.newsfeedController),
                                      ),
                                    );
                            },
                            child: Container(
                              padding: EdgeInsets.only(
                                left: 20,
                              ),
                              height: 50,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(40),
                                border: Border.all(
                                  color: Colors.grey,
                                  width: 0.5,
                                ),
                                color:
                                    Theme.of(context).scaffoldBackgroundColor,
                              ),
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  // postId != null ? postId :
                                  Strings.saySomething,
                                  // style: TextStyle(
                                  //   color: Color(0xFF626c72),
                                  // ),
                                  style: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? TextStyle(
                                          color: Colors.white,
                                        )
                                      : TextStyle(
                                          color: Color(0xFF626c72),
                                        ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        // controller.isHome == true
                        //     ? kIsWeb
                        //     ?
                        //     : SizedBox()
                        //     : SizedBox(),
                        SizedBox(height: 10),
                        Expanded(
                          child: RefreshIndicator(
                            triggerMode: RefreshIndicatorTriggerMode.anywhere,
                            color: Color(0xFFedab30),
                            onRefresh: () async {
                              // widget.controller.postList = await widget.controller.getNewsFeed(
                              //     shouldUpdate: true, reload: true);
                              // widget.controller.update();
                              return await newsfeedController.getNewsFeed(
                                  shouldUpdate: true, reload: false);
                            },
                            child: newsfeedController.postList.isEmpty
                                ? SizedBox()

                                //     :PagedL(
                                //   emptyStateWidget: Text(Strings.noPosts,
                                //     style: Theme.of(context).brightness == Brightness.dark ?
                                //     TextStyle(color: Colors.white,
                                //
                                //     )
                                //         : TextStyle( color: Colors.black,
                                //     ),),
                                //   itemBuilder: _itemRow,
                                //   // PostCard(
                                //   //   post: controller?.userPosts[index],
                                //   //   scaffoldKey: _scaffoldKey,
                                //   //   controller:
                                //   //   controller.newsFeedControloler,
                                //   //   // browseController: controller,
                                //   // ),
                                //   padding:
                                //   EdgeInsets.only(top: 10, bottom: 30),
                                //   loadingIndicator: Padding(
                                //     padding: EdgeInsets.all(16.00),
                                //     child: Center(
                                //       child: CircularProgressIndicator(),
                                //     ),
                                //   ),
                                //   itemDataProvider: _fetchData,
                                //   list: newsfeedController.postList,
                                //   listSize: _checkPage(newsfeedController.postList.length),
                                // ),

                                : PagedL(
                                    emptyStateWidget: CircularProgressIndicator(
                                      color: MyColors.BlueColor,
                                    ),
                                    // Text(Strings.noPosts),
                                    itemBuilder: _itemRow,
                                    padding: EdgeInsets.only(
                                        top: 0.00, left: 4.00, right: 4.00),
                                    loadingIndicator: Padding(
                                      padding: EdgeInsets.all(10.00),
                                      child: Center(
                                          child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                          MyColors.BlueColor,
                                        ),
                                      )
                                          // Container(
                                          //     color: Colors.grey[200],
                                          //     // margin: EdgeInsets.all(10),
                                          //     height: 320,
                                          //     child: buildPostShimmer(
                                          //         context)),
                                          ),
                                    ),
                                    itemDataProvider: _fetchData,
                                    list: newsfeedController.postList,
                                    listSize: newsfeedController.isAdLoaded
                                        ? _checkPage(newsfeedController
                                                .postList.length) +
                                            1
                                        : _checkPage(
                                            newsfeedController.postList.length),
                                  ),
                          ),
                        ),
                      ],
                    )
                  : controller.isVideos == true
                      ? SingleChildScrollView(
                          child: Column(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Container(
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Color(0xFF252526)
                                        : Color(0xFFfafafa),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 10, top: 10),
                                        child: Text("All Videos",
                                            style: Theme.of(context)
                                                        .brightness ==
                                                    Brightness.dark
                                                ? TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.w700,
                                                  )
                                                : TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 20,
                                                  )),
                                      ),
                                      ListView.builder(
                                          shrinkWrap: true,
                                          // scrollDirection: Axis.vertical,
                                          primary: false,
                                          itemCount: 30,
                                          itemBuilder: (BuildContext context,
                                              int index) {
                                            return Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 10, right: 10, top: 20),
                                              child: Container(
                                                height: 400,
                                                width: Get.width,
                                                color: Colors.black,
                                                child: Text(
                                                  "Container ${[index]}",
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                                // decoration: BoxDecoration(
                                                //
                                                //   // color: Color(0xFF252526),
                                                //     image: DecorationImage(
                                                //         image: NetworkImage(
                                                //             "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                //
                                                //         ),
                                                //         fit: BoxFit.cover
                                                //     )
                                                // ),
                                                // child: ChewieVideoPlayer(
                                                //   //1
                                                //
                                                //   index: 0,
                                                //   thumbnailUrl:
                                                //       'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                                // )
                                              ),
                                            );
                                          }),
                                      SizedBox(
                                        height: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      : controller.isAbout == true
                          ? SingleChildScrollView(
                              child: Padding(
                                padding: EdgeInsets.all(10),
                                child: Container(
                                  width: Get.width,
                                  height: 250,
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Color(0xFF252526)
                                        : Color(0xFFfafafa),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 10, left: 10),
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.category,
                                              color: controller
                                                  .newsfeedController
                                                  .displayColor,
                                              size: 25,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "Category:",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                            Text(
                                              "General",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.group,
                                              color: controller
                                                  .newsfeedController
                                                  .displayColor,
                                              size: 25,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "Members:  ",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                            Text(
                                              "1",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.remove_red_eye_rounded,
                                              color: controller
                                                  .newsfeedController
                                                  .displayColor,
                                              size: 25,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "Pubic",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Tooltip(
                                              message:
                                                  "Anyone can join this group",
                                              child: Icon(
                                                Icons.info,
                                                color: controller
                                                    .newsfeedController
                                                    .displayColor,
                                                size: 20,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            Icon(
                                              Icons.remove_red_eye_rounded,
                                              color: controller
                                                  .newsfeedController
                                                  .displayColor,
                                              size: 25,
                                            ),
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Text(
                                              "Visibility:  ",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                            Text(
                                              "Visible Publicly",
                                              style: TextStyle(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: 14,
                                              ),
                                            ),
                                            SizedBox(
                                              width: 5,
                                            ),
                                            Tooltip(
                                              message:
                                                  "Anyone can search for your group",
                                              child: Icon(
                                                Icons.info,
                                                color: controller
                                                    .newsfeedController
                                                    .displayColor,
                                                size: 20,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            GestureDetector(
                                              onTap: kIsWeb
                                                  ? () {
                                                      showDialog(
                                                          context: context,
                                                          builder: (BuildContext
                                                              con) {
                                                            return AlertDialog(
                                                              contentPadding:
                                                                  EdgeInsets
                                                                      .zero,
                                                              content: StatefulBuilder(builder:
                                                                  (BuildContext
                                                                          context,
                                                                      StateSetter
                                                                          setState) {
                                                                return CommunityRequests(

                                                                    // communitiesController: communitiesController,
                                                                    );
                                                              }),
                                                            );
                                                          });
                                                    }
                                                  : () {
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                CommunityRequests()),
                                                      );
                                                    },
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    Icons.group,
                                                    color: controller
                                                        .newsfeedController
                                                        .displayColor,
                                                    size: 25,
                                                  ),
                                                  SizedBox(
                                                    width: 10,
                                                  ),
                                                  Text(
                                                    "Join Request:  ",
                                                    style: TextStyle(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                  Text(
                                                    "1",
                                                    style: TextStyle(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: 14,
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  Tooltip(
                                                    message:
                                                        "Admin will Approved all the request to join private group",
                                                    child: Icon(
                                                      Icons.info,
                                                      color: controller
                                                          .newsfeedController
                                                          .displayColor,
                                                      size: 20,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        // kIsWeb
                                        //     ? Row(
                                        //   mainAxisAlignment:
                                        //   MainAxisAlignment.spaceBetween,
                                        //   children: [
                                        //
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //
                                        //
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //
                                        //
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //
                                        //
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //
                                        //
                                        //   ],
                                        // )
                                        //     : Row(
                                        //   mainAxisAlignment:
                                        //   MainAxisAlignment.spaceBetween,
                                        //   children: [
                                        //     Icon(
                                        //       Icons.category,
                                        //       color: Color(0xFF0157d3),
                                        //       size: 18,
                                        //     ),
                                        //     Text(
                                        //       "Category:",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Text(
                                        //       "General",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //     Icon(
                                        //       Icons.group,
                                        //       color: Color(0xFF0157d3),
                                        //       size: 18,
                                        //     ),
                                        //     Text(
                                        //       "Members:  ",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Text(
                                        //       "1",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //     Icon(
                                        //       Icons.remove_red_eye_rounded,
                                        //       color: Color(0xFF0157d3),
                                        //       size: 18,
                                        //     ),
                                        //     Text(
                                        //       "Pubic",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Tooltip(
                                        //       message:
                                        //       "Anyone can join this group",
                                        //       child: Icon(
                                        //         Icons.info,
                                        //         color: Color(0xFF0157d3),
                                        //         size: 18,
                                        //       ),
                                        //     ),
                                        //   ],
                                        // ),
                                        // !kIsWeb
                                        //     ? Divider(
                                        //   thickness: 1,
                                        // )
                                        //     : SizedBox(),
                                        // !kIsWeb
                                        //     ? Row(
                                        //   mainAxisAlignment:
                                        //   MainAxisAlignment.spaceBetween,
                                        //   children: [
                                        //     Icon(
                                        //       Icons.remove_red_eye_rounded,
                                        //       color: Color(0xFF0157d3),
                                        //       size: 18,
                                        //     ),
                                        //     Text(
                                        //       "Visibility:  ",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Text(
                                        //       "Visible Publicly",
                                        //       style: TextStyle(
                                        //         color: Theme.of(context)
                                        //             .brightness ==
                                        //             Brightness.dark
                                        //             ? Colors.white
                                        //             : Colors.black,
                                        //         fontSize: 14,
                                        //       ),
                                        //     ),
                                        //     Tooltip(
                                        //       message:
                                        //       "Anyone can search for your group",
                                        //       child: Icon(
                                        //         Icons.info,
                                        //         color: Color(0xFF0157d3),
                                        //         size: 18,
                                        //       ),
                                        //     ),
                                        //     Container(
                                        //       height: 50,
                                        //       width: 1,
                                        //       color: Colors.grey,
                                        //     ),
                                        //     GestureDetector(
                                        //       onTap: kIsWeb
                                        //           ? () {
                                        //         showDialog(
                                        //             context: context,
                                        //             builder:
                                        //                 (BuildContext
                                        //             con) {
                                        //               return AlertDialog(
                                        //                 contentPadding:
                                        //                 EdgeInsets
                                        //                     .zero,
                                        //                 content: StatefulBuilder(builder:
                                        //                     (BuildContext
                                        //                 context,
                                        //                     StateSetter
                                        //                     setState) {
                                        //                   return CommunityRequests(
                                        //
                                        //                     // communitiesController: communitiesController,
                                        //                   );
                                        //                 }),
                                        //               );
                                        //             });
                                        //       }
                                        //           : () {
                                        //         Navigator.push(
                                        //           context,
                                        //           MaterialPageRoute(
                                        //               builder: (context) =>
                                        //                   CommunityRequests()),
                                        //         );
                                        //       },
                                        //       child: Row(
                                        //         children: [
                                        //           Icon(
                                        //             Icons.group,
                                        //             color: Color(0xFF0157d3),
                                        //             size: 18,
                                        //           ),
                                        //           Text(
                                        //             "Join Request:  ",
                                        //             style: TextStyle(
                                        //               color: Theme.of(context)
                                        //                   .brightness ==
                                        //                   Brightness.dark
                                        //                   ? Colors.white
                                        //                   : Colors.black,
                                        //               fontSize: 14,
                                        //             ),
                                        //           ),
                                        //           Text(
                                        //             "1",
                                        //             style: TextStyle(
                                        //               color: Theme.of(context)
                                        //                   .brightness ==
                                        //                   Brightness.dark
                                        //                   ? Colors.white
                                        //                   : Colors.black,
                                        //               fontSize: 14,
                                        //             ),
                                        //           ),
                                        //           Tooltip(
                                        //             message:
                                        //             "Admin will Approved all the request to join private group",
                                        //             child: Icon(
                                        //               Icons.info,
                                        //               color:
                                        //               Color(0xFF0157d3),
                                        //               size: 15,
                                        //             ),
                                        //           ),
                                        //         ],
                                        //       ),
                                        //     ),
                                        //   ],
                                        // )
                                        //     : SizedBox(),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            )
                          : Container(),
        ),
        floatingActionButton: kIsWeb
            ? SizedBox()
            : controller.isHome == true
                ? FloatingActionButton(
                    heroTag: UniqueKey(),
                    onPressed: () {
                      newsfeedController.modelList2 = [];

                      newsfeedController.modelList2.add(ModelClass.fromJson({
                        'body': '',
                        'poll_ques_first': null,
                        'poll_ques_first': null,
                        'poll_ques_third': null,
                        'poll_ques_fourth': null,
                        //  selectType: "Public",
                        'files': [],
                        'link_meta': '',
                        'link': '',
                        'link_image': '',
                        'link_title': '',
                        'days': '',
                        'minutes': '',
                        'hours': '',
                        'location': '',
                        'lat': '',
                        'lng': '',
                        'poll_thread': false,
                        'type': newsfeedController.modelList2.length < 2
                            ? 'post'
                            : 'thread'
                      }));

                      //   widget.controller. indexOfText();
                      // print('list of ');
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              CreatePostMobile(newsfeedController),
                        ),
                      );
                    },
                    backgroundColor: MyColors.blue,
                    child: Icon(Icons.add),
                  )
                : SizedBox(),
      );
    });
  }

  Widget myPopMenu({BuildContext context}) {
    return Align(
        alignment: Alignment.topRight,
        child: PopupMenuButton(

            // position: PopupMenuPosition.under,
            padding: EdgeInsets.zero,
            icon: Icon(
              Icons.settings,
              size: kIsWeb ? 30 : 22,
              color: Colors.grey,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            ),
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            // Callback that sets the selected popup menu item.
            onSelected: (value) async {
              if (value == 1) {
                if (kIsWeb) {
                  return showDialog(
                      context: context,
                      builder: (BuildContext con) {
                        return AlertDialog(
                          contentPadding: EdgeInsets.zero,
                          content: StatefulBuilder(builder:
                              (BuildContext context, StateSetter setState) {
                            return CreateCommunity(
                              editCheck: false,

                              // communitiesController: communitiesController,
                            );
                          }),
                        );
                      });
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateCommunity(
                              editCheck: false,
                            )),
                  );
                }
              }

              // Navigator.push(
              //   context,
              //   MaterialPageRoute(builder: (context) =>  CreateCommunity()),
              // );
            },
            itemBuilder: (BuildContext context) => [
                  PopupMenuItem(
                    value: 1,
                    child: Text(
                      'Edit Community',
                      style: Theme.of(context).brightness == Brightness.dark
                          ? TextStyle(
                              color: Colors.white,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold)
                          : TextStyle(
                              color: Colors.black,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold),
                    ),
                  ),
                  PopupMenuItem(
                    value: 2,
                    child: Text(
                      'Delete Community',
                      style: Theme.of(context).brightness == Brightness.dark
                          ? TextStyle(
                              color: Colors.white,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold)
                          : TextStyle(
                              color: Colors.black,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold),
                    ),
                  ),
                  PopupMenuItem(
                    value: 3,
                    child: Text(
                      'Report Community',
                      style: Theme.of(context).brightness == Brightness.dark
                          ? TextStyle(
                              color: Colors.white,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold)
                          : TextStyle(
                              color: Colors.black,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold),
                    ),
                  ),
                  PopupMenuItem(
                    value: 4,
                    child: Text(
                      'Invite Friend',
                      style: Theme.of(context).brightness == Brightness.dark
                          ? TextStyle(
                              color: Colors.white,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold)
                          : TextStyle(
                              color: Colors.black,
                              fontSize: 13.0,
                              fontWeight: FontWeight.bold),
                    ),
                  ),
                ]));
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

  Future<List<Post>> _fetchData(int page) async {
    return await newsfeedController.getNewsFeedPagged(page: page);
  }

  // Widget _itemRow(BuildContext context, Post post) {
  //   int index = newsfeedController.postList.indexWhere((element) {
  //     return element.postId == post.postId;
  //   });
  //
  //   // print( "scaffoldkey from user:   ${_scaffoldKey.currentContext}");
  //   return Column(
  //     crossAxisAlignment: CrossAxisAlignment.start,
  //     children: [
  //       post.pinPost == 1? Row(
  //         children: [
  //           Icon(Icons.push_pin),
  //           SizedBox(
  //             width: 5,
  //           ),
  //           Text("Pinned Werf"),
  //         ],
  //       ):SizedBox(),
  //       newsfeedController.postList[index].type=='thread'?
  //       ThreadPostCard(
  //         index: index,
  //         post: newsfeedController.postList[index],
  //         // scaffoldKey: _scaffoldKey,
  //         controller: newsfeedController,
  //       ):
  //       PostCard(
  //         index: index,
  //         post: newsfeedController.postList[index],
  //         // scaffoldKey:  _scaffoldKey,
  //         controller: newsfeedController,
  //       ),
  //     ],
  //   );
  // }

  Widget _itemRow(BuildContext context, Post post) {
    int index = newsfeedController.postList.indexWhere((element) {
      // print(element.postId.toString() + ' : ' + post.postId.toString());
      return element.postId == post.postId;
    });

    print(
        'check the index number  :${index} :${newsfeedController.postList[index].thread_no}'
        ' :${newsfeedController.postList.asMap().containsKey(index - 1) ? newsfeedController.postList[index - 1].thread_no : null}');

    if (index != 0 && index % 14 == 0 && !kIsWeb) {
      // print('Called this many times ${widget.num++}');
      return Column(
        children: [
          newsfeedController.postList[index].type == 'thread'
              ? ThreadPostCard(
                  scaffoldKey: _scaffoldKey,
                  post: newsfeedController?.postList[index],
                  index: index,
                  controller: newsfeedController)
              : PostCard(
                  post: newsfeedController?.postList[index],
                  scaffoldKey: _scaffoldKey,
                  index: index,
                  controller: newsfeedController,
                ),
          SizedBox(height: 4),
          CustomAdWidget(
              // ad: widget.controller.ads[widget.adIndex++],
              ),
        ],
      );
    } else {
      return VisibilityDetector(
        key: Key('postCard-widget-key'),
        onVisibilityChanged: (visibilityInfo) {
          double visiblePercentage = visibilityInfo.visibleFraction * 100;
          // debugPrint(
          //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
          if (visiblePercentage > 20 &&
              post.authorId != newsfeedController.userId) {
            newsfeedController.emitImpressionsSocket(post.postId);
          }
        },
        child: newsfeedController.postList[index].type == 'thread'
            ? ThreadPostCard(
                scaffoldKey: _scaffoldKey,
                post: newsfeedController?.postList[index],
                index: index,
                controller: newsfeedController)
            // : SizedBox()
            //  :Text('null')
            : PostCard(
                post: newsfeedController?.postList[index],
                scaffoldKey: _scaffoldKey,
                index: index,
                controller: newsfeedController),
      );
    }
  }
// Widget buildPostShimmer(BuildContext context) => ListTile(
//       //Shimmer for Profile Photo
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           //Shimmer for username
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 20),
//           //Shimmer for post text
//           CustomShimmerWidget.rectangular(
//             height: 210,
//           ),
//           SizedBox(height: 20),
//           //Shimmer for reaction row
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               //  SizedBox(width: 16),
//             ],
//           ),
//           SizedBox(height: 16),
//         ],
//       ),
//       // trailing: SizedBox(),
//       // subtitle: CustomShimmerWidget.rectangular(
//       //     height: 14, width: MediaQuery.of(context).size.width * 0.3),
//     );
//
// Widget buildPostShimmer(BuildContext context) => ListTile(
//       //Shimmer for Profile Photo
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           //Shimmer for username
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 20),
//           //Shimmer for post text
//           CustomShimmerWidget.rectangular(
//             height: 210,
//           ),
//           SizedBox(height: 20),
//           //Shimmer for reaction row
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               //  SizedBox(width: 16),
//             ],
//           ),
//           SizedBox(height: 16),
//         ],
//       ),
//       // trailing: SizedBox(),
//       // subtitle: CustomShimmerWidget.rectangular(
//       //     height: 14, width: MediaQuery.of(context).size.width * 0.3),
//     );
}

class Tab extends StatelessWidget {
  final String title;
  final bool isSelected;
  final Function onTap;

  const Tab({this.title, this.isSelected, this.onTap});

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      color: isSelected ? Color(0xFF0157d3) : Colors.white,
      onPressed: onTap,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22.0)),
      child: Column(
        children: [
          Text(
            title,
            style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isSelected ? Colors.white : Colors.black),
          ),
          // SizedBox(
          //   height: 5,
          // ),
          // Container(
          //   height: 5,
          //   width: 100,
          //   color: isSelected ? Color(0xFFedab30) : Colors.white,
          // )
        ],
      ),
    );
  }
}

/*class ChewieVideoPlayer extends StatefulWidget {
  const ChewieVideoPlayer({
    Key key,
    this.post,
    this.index,
    this.videoUrl,
    this.isAudio = false,
    this.aspectRatio,
    this.borderRadius = 12,
    this.allowFullScreen = true,
    this.isFullScreenOnMobile = false,
    this.thumbnailUrl,
    this.isQuoteWerfPlayer = false,
    this.quoteWerf,
  }) : super(key: key);

  final Post post;
  final QuoteWerf quoteWerf;
  final int index;
  final String videoUrl;
  final bool isAudio;
  final double aspectRatio;
  final double borderRadius;
  final bool isFullScreenOnMobile;
  final bool isQuoteWerfPlayer;
  final allowFullScreen;
  final thumbnailUrl;

  @override
  State<ChewieVideoPlayer> createState() => _ChewieVideoPlayerState();
}

class _ChewieVideoPlayerState extends State<ChewieVideoPlayer> {
  VideoPlayerController videoPlayerController;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    videoPlayerController = VideoPlayerController.network(
        "https://storage.googleapis.com/buzznbees/files/UbEm1GpQYjKRmUHYdNRaaxFKFjQitJuvRBEEbAau.mp4",
        videoPlayerOptions: VideoPlayerOptions(allowBackgroundPlayback: false));

    // widget.isQuoteWerfPlayer ? videoPlayerController = VideoPlayerController.network(
    //     widget.videoUrl != null
    //         ? widget.videoUrl
    //         : widget.quoteWerf.postFiles[widget.index]['file_path']) : videoPlayerController = VideoPlayerController.network(
    //     widget.videoUrl != null
    //         ? widget.videoUrl
    //         : widget.post.postFiles[widget.index]['file_path']);
  }

  @override
  void dispose() {
    videoPlayerController.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.isAudio
        //audio player
        ? ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Chewie(
                  controller: ChewieController(
                    autoInitialize: false,
                    allowFullScreen: true,
                    placeholder: Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: 300,
                        width: 300,
                        alignment: Alignment.center,
                        child: Image.asset(
                          'assets/images/audio_placeholder.png',
                          alignment: Alignment.center,
                        ),
                      ),
                    ),
                    aspectRatio: 16 / 9,
                    allowMuting: true,
                    videoPlayerController: videoPlayerController,
                    autoPlay: false,
                    looping: true,
                  ),
                )),
          )
        : ClipRRect(
            borderRadius: BorderRadius.circular(widget.borderRadius),
            child: widget.isFullScreenOnMobile
                ?
                //mobile video player
                Chewie(
                    controller: ChewieController(
                      errorBuilder: (context, _) {
                        return SizedBox();
                      },
                      placeholder: Center(
                        child: AspectRatio(
                          aspectRatio: videoPlayerController.value.aspectRatio,
                          child: Image.network(
                            widget.thumbnailUrl,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      // placeholder: Image.network(thumbnailUrl),
                      // fullScreenByDefault: true,
                      autoInitialize: true,
                      allowFullScreen: widget.allowFullScreen,
                      deviceOrientationsOnEnterFullScreen: [
                        DeviceOrientation.portraitUp
                      ],
                      allowMuting: true,
                      aspectRatio: videoPlayerController.value.aspectRatio,
                      autoPlay: true,
                      videoPlayerController: videoPlayerController,
                      looping: true,
                    ),
                  )
                : Chewie(
                    controller: ChewieController(
                      showOptions: false,
                      errorBuilder: (context, _) {
                        return SizedBox();
                      },
                      placeholder: Align(
                        alignment: Alignment.center,
                        child: Container(
                          alignment: Alignment.center,
                          child: Image.network(
                            widget.thumbnailUrl,
                            alignment: Alignment.center,
                          ),
                        ),
                      ),
                      autoInitialize: false,
                      allowFullScreen: widget.allowFullScreen,
                      aspectRatio: 16 / 9,
                      allowMuting: true,
                      videoPlayerController: videoPlayerController,
                      autoPlay: false,
                      looping: false,
                    ),
                  ),
          );
  }
}*/
