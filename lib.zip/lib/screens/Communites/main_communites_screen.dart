import 'dart:async';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';
import 'package:werfieapp/network/controller/communities_controller.dart';
import 'package:werfieapp/widgets/communities_card.dart';
import 'package:werfieapp/widgets/create_community.dart';

import 'all_group_screen.dart';
import 'community_screen.dart';

class MainCommunitiesScreen extends StatefulWidget {
  MainCommunitiesScreen({Key key}) : super(key: key);

  @override
  State<MainCommunitiesScreen> createState() => _MainCommunitiesScreenState();
}

class _MainCommunitiesScreenState extends State<MainCommunitiesScreen> {
  final communitiesController = Get.put(CommunitiesController());

  final scrollController = ScrollController();

  Future scrollToItem(int index,
      {ItemScrollController itemScrollController}) async {
    itemScrollController.scrollTo(index: index, duration: Duration(seconds: 1));
  }

  @override
  void dispose() {
    super.dispose();
  }

  void initState() {
    super.initState();
  }

  animateToMaxMin(double max, double min, double direction, int seconds,
      ScrollController scrollController) {
    scrollController
        .animateTo(direction,
            duration: Duration(seconds: seconds), curve: Curves.linear)
        .then((value) {
      direction = direction == max ? min : max;
      animateToMaxMin(max, min, direction, seconds, scrollController);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: kIsWeb
          ? PreferredSize(
              preferredSize: Size.fromHeight(50.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    kIsWeb
                        ? SizedBox(
                            height: 20,
                          )
                        : SizedBox(height: 49),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: kIsWeb
                                ? () {
                                    // controller.newsfeedController.isTrendsScreen =
                                    // false;
                                    // controller.newsfeedController.isNewsFeedScreen =
                                    // true;
                                    // controller.newsfeedController.isBrowseScreen =
                                    // false;
                                    // controller.newsfeedController
                                    //     .isNotificationScreen = false;
                                    // controller.newsfeedController.isChatScreen =
                                    // false;
                                    // controller.newsfeedController
                                    //     .isSavedPostScreen = false;
                                    // controller.newsfeedController.isPostDetails =
                                    // false;
                                    // controller.newsfeedController.isProfileScreen =
                                    // false;
                                    // controller.newsfeedController
                                    //     .isOtherUserProfileScreen = false;
                                    // controller.newsfeedController.isTopicScreen =
                                    // false;
                                    // controller.newsfeedController.isListScreen =
                                    // false;
                                    // controller.newsfeedController
                                    //     .isMainTopicScreen = false;
                                    // controller.newsfeedController.update();
                                  }
                                : () {
                                    Navigator.pop(context);
                                  },
                            child: Icon(
                              Icons.arrow_back,
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              size: 25,
                            ),
                          ),
                          kIsWeb
                              ? SizedBox(
                                  width: 50,
                                )
                              : SizedBox(width: 20),
                          Text(
                            'Communities',
                            style:
                                Theme.of(context).brightness == Brightness.dark
                                    ? TextStyle(
                                        color: Colors.white,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                        fontSize: 20,
                                      ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
          : AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              title: Row(
                children: [
                  GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(
                        Icons.arrow_back,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        size: 25,
                      )),
                  SizedBox(
                    width: 20,
                  ),
                  Text('Communities',
                      style: Theme.of(context).brightness == Brightness.dark
                          ? TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                            )
                          : TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                            )),
                ],
              ),
            ),
      body: Container(
        child: Padding(
          padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
          child: SingleChildScrollView(
            controller: scrollController,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text("Your Community",
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              )
                            : TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                              )),
                    SizedBox(
                      width: 40,
                    ),
                    Tooltip(
                      message: 'Create Community',
                      child: GestureDetector(
                        onTap: kIsWeb
                            ? () {
                                showDialog(
                                    context: context,
                                    builder: (BuildContext con) {
                                      return AlertDialog(
                                        contentPadding: EdgeInsets.zero,
                                        content: StatefulBuilder(builder:
                                            (BuildContext context,
                                                StateSetter setState) {
                                          return CreateCommunity(
                                            editCheck: true,
                                            // communitiesController: communitiesController,
                                          );
                                        }),
                                      );
                                    });
                              }
                            : () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CreateCommunity(
                                            editCheck: true,
                                          )),
                                );
                              },
                        child: Container(
                          height: 18,
                          width: 18,
                          decoration: BoxDecoration(
                              color: Color(0xFF0157d3), shape: BoxShape.circle),
                          child: Align(
                            alignment: Alignment.center,
                            child: Icon(
                              Icons.add,
                              color: Colors.white,
                              size: 15,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Spacer(),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue >= 2) {
                                // print(communitiesController.scrollValue);
                                // print("+");
                                communitiesController.scrollValue =
                                    communitiesController.scrollValue - 2;
                                communitiesController.update();
                                scrollToItem(communitiesController.scrollValue,
                                    itemScrollController: communitiesController
                                        .itemScrollController1);
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey.withOpacity(0.5),
                                ),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_back_ios_sharp,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 5,
                    ),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue <
                                  communitiesController.listLength - 2) {
                                communitiesController.scrollValue =
                                    communitiesController.scrollValue + 2;
                                // print(communitiesController.scrollValue);
                                // print("+");
                                communitiesController.update();
                                if (communitiesController.scrollValue <=
                                    communitiesController.listLength - 2) {
                                  scrollToItem(
                                      communitiesController.scrollValue,
                                      itemScrollController:
                                          communitiesController
                                              .itemScrollController1);
                                }
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5)),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  "Communities you have created",
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0157d3),
                      fontSize: 15),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                    height: 300,
                    child: ScrollablePositionedList.builder(
                      addAutomaticKeepAlives: true,
                      shrinkWrap: true,
                      itemScrollController:
                          communitiesController.itemScrollController1,
                      physics: kIsWeb
                          ? NeverScrollableScrollPhysics()
                          : ScrollPhysics(),
                      scrollDirection: Axis.horizontal,
                      itemCount: communitiesController.listLength,
                      itemBuilder: (context, int index) {
                        return GestureDetector(
                          onTap: kIsWeb
                              ? () {
                                  communitiesController.timer?.cancel();
                                  communitiesController.timer3?.cancel();
                                  communitiesController.timer2?.cancel();
                                  communitiesController.timer4?.cancel();
                                  communitiesController.update();

                                  ///idhr ana

                                  communitiesController
                                      .newsfeedController.isSearch = false;
                                  communitiesController
                                      .newsfeedController.isFilter = false;
                                  communitiesController.newsfeedController
                                      .isFilterScreen = false;
                                  communitiesController.newsfeedController
                                      .isTrendsScreen = false;
                                  communitiesController.newsfeedController
                                      .isNewsFeedScreen = false;
                                  communitiesController.newsfeedController
                                      .isBrowseScreen = false;
                                  communitiesController.newsfeedController
                                      .isNotificationScreen = false;
                                  communitiesController.newsfeedController
                                      .isSavedPostScreen = false;
                                  communitiesController.newsfeedController
                                      .isWhoToFollowScreen = false;
                                  communitiesController
                                      .newsfeedController.isChatScreen = false;
                                  communitiesController
                                      .newsfeedController.isPostDetails = false;
                                  communitiesController
                                      .newsfeedController.searchText.text = '';
                                  communitiesController
                                      .newsfeedController.isListScreen = false;
                                  communitiesController.newsfeedController
                                      .isListDetailScreen = false;
                                  communitiesController.newsfeedController
                                      .isProfileScreen = false;
                                  communitiesController.newsfeedController
                                      .isFollwerScreen = false;
                                  communitiesController.newsfeedController
                                      .isSettingsScreen = false;
                                  communitiesController
                                      .newsfeedController.isTopicScreen = false;
                                  communitiesController.newsfeedController
                                      .isCommunitesScreen = false;
                                  communitiesController.newsfeedController
                                      .isCommunityScreen = true;
                                  communitiesController.newsfeedController
                                      .update();
                                }
                              : () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            CommunityScreen()),
                                  );
                                },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: CommunitiesCard(
                              cardType: "YourGroup",
                              communitiesController: communitiesController,
                            ),
                          ),
                        );
                      },
                    )),
                SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    Text("Communities you've joined",
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              )
                            : TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                              )),
                    Spacer(),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue2 >= 2) {
                                // print(communitiesController.scrollValue2);
                                // print("+");
                                communitiesController.scrollValue2 =
                                    communitiesController.scrollValue2 - 2;
                                communitiesController.update();
                                scrollToItem(communitiesController.scrollValue2,
                                    itemScrollController: communitiesController
                                        .itemScrollController2);
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey.withOpacity(0.5),
                                ),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_back_ios_sharp,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 5,
                    ),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue2 <
                                  communitiesController.listLength2 - 2) {
                                communitiesController.scrollValue2 =
                                    communitiesController.scrollValue2 + 2;
                                // print(communitiesController.scrollValue2);
                                // print("+");
                                communitiesController.update();
                                if (communitiesController.scrollValue2 <=
                                    communitiesController.listLength2 - 2) {
                                  scrollToItem(
                                      communitiesController.scrollValue2,
                                      itemScrollController:
                                          communitiesController
                                              .itemScrollController2);
                                }
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5)),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                    height: 300,
                    child: ScrollablePositionedList.builder(
                        physics: kIsWeb
                            ? NeverScrollableScrollPhysics()
                            : ScrollPhysics(),
                        itemScrollController:
                            communitiesController.itemScrollController2,
                        scrollDirection: Axis.horizontal,
                        itemCount: communitiesController.listLength2,
                        itemBuilder: (BuildContext context, int index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: CommunitiesCard(
                              cardType: "joinCommunity",
                              communitiesController: communitiesController,
                            ),
                          );
                        })),
                SizedBox(
                  height: 30,
                ),
                Row(
                  children: [
                    Text("Suggested for You",
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              )
                            : TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                              )),
                    SizedBox(
                      width: 10,
                    ),
                    GestureDetector(
                      onTap: () {
                        communitiesController.timer?.cancel();
                        communitiesController.timer3?.cancel();
                        communitiesController.timer2?.cancel();
                        communitiesController.timer4?.cancel();
                        communitiesController.CategoryName = "All";
                        communitiesController.update();
                        communitiesController.newsfeedController.isSearch =
                            false;
                        communitiesController.newsfeedController.isFilter =
                            false;
                        communitiesController
                            .newsfeedController.isFilterScreen = false;
                        communitiesController
                            .newsfeedController.isTrendsScreen = false;
                        communitiesController
                            .newsfeedController.isNewsFeedScreen = false;
                        communitiesController
                            .newsfeedController.isBrowseScreen = false;
                        communitiesController
                            .newsfeedController.isNotificationScreen = false;
                        communitiesController
                            .newsfeedController.isSavedPostScreen = false;
                        communitiesController
                            .newsfeedController.isWhoToFollowScreen = false;
                        communitiesController.newsfeedController.isChatScreen =
                            false;
                        communitiesController.newsfeedController.isPostDetails =
                            false;
                        communitiesController
                            .newsfeedController.searchText.text = '';
                        communitiesController.newsfeedController.isListScreen =
                            false;
                        communitiesController
                            .newsfeedController.isListDetailScreen = false;
                        communitiesController
                            .newsfeedController.isProfileScreen = false;
                        communitiesController
                            .newsfeedController.isFollwerScreen = false;
                        communitiesController
                            .newsfeedController.isSettingsScreen = false;
                        communitiesController.newsfeedController.isTopicScreen =
                            false;
                        communitiesController
                            .newsfeedController.isCommunitesScreen = false;
                        communitiesController
                            .newsfeedController.isCommunityScreen = false;
                        communitiesController
                            .newsfeedController.isAllGroupScreen = true;
                        communitiesController.newsfeedController.update();
                      },
                      child: Text("See all",
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          )),
                    ),
                    Spacer(),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue3 >= 2) {
                                // print(communitiesController.scrollValue3);
                                // print("+");
                                communitiesController.scrollValue3 =
                                    communitiesController.scrollValue3 - 2;
                                communitiesController.update();
                                scrollToItem(communitiesController.scrollValue3,
                                    itemScrollController: communitiesController
                                        .itemScrollController3);
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey.withOpacity(0.5),
                                ),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_back_ios_sharp,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 5,
                    ),
                    kIsWeb
                        ? GestureDetector(
                            onTap: () {
                              if (communitiesController.scrollValue3 <
                                  communitiesController.listLength3 - 2) {
                                communitiesController.scrollValue3 =
                                    communitiesController.scrollValue3 + 2;
                                // print(communitiesController.scrollValue3);
                                // print("+");
                                communitiesController.update();
                                if (communitiesController.scrollValue3 <=
                                    communitiesController.listLength3 - 2) {
                                  scrollToItem(
                                      communitiesController.scrollValue3,
                                      itemScrollController:
                                          communitiesController
                                              .itemScrollController3);
                                }
                              }
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white.withOpacity(0.5)
                                        : Colors.grey.withOpacity(0.5)),
                              ),
                              child: Align(
                                alignment: Alignment.center,
                                child: Icon(
                                  Icons.arrow_forward_ios,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  size: 15,
                                ),
                              ),
                            ),
                          )
                        : SizedBox(),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                    height: 300,
                    child: ScrollablePositionedList.builder(
                        itemScrollController:
                            communitiesController.itemScrollController3,
                        physics: kIsWeb
                            ? NeverScrollableScrollPhysics()
                            : ScrollPhysics(),
                        scrollDirection: Axis.horizontal,
                        itemCount: communitiesController.listLength3,
                        itemBuilder: (BuildContext context, int index) {
                          return Padding(
                            padding: const EdgeInsets.only(right: 20),
                            child: CommunitiesCard(
                              cardType: "SuggestedCommunity",
                              communitiesController: communitiesController,
                            ),
                          );
                        })),
                SizedBox(
                  height: 30,
                ),
                !kIsWeb
                    ? Text("Find Community by browsing top categories",
                        style: Theme.of(context).brightness == Brightness.dark
                            ? TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              )
                            : TextStyle(
                                color: Colors.black,
                                fontSize: 20,
                              ))
                    : Row(
                        children: [
                          Text("Find Community by browsing top categories",
                              style: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? TextStyle(
                                      color: Colors.white,
                                      fontSize: kIsWeb ? 20 : 18,
                                      fontWeight: FontWeight.w700,
                                    )
                                  : TextStyle(
                                      color: Colors.black,
                                      fontSize: kIsWeb ? 20 : 18,
                                    )),
                          Spacer(),
                          kIsWeb
                              ? GestureDetector(
                                  onTap: () {
                                    if (communitiesController.scrollValue4 >=
                                        2) {
                                      // print(communitiesController.scrollValue4);
                                      // print("+");
                                      communitiesController.scrollValue4 =
                                          communitiesController.scrollValue4 -
                                              2;
                                      communitiesController.update();
                                      scrollToItem(
                                          communitiesController.scrollValue4,
                                          itemScrollController:
                                              communitiesController
                                                  .itemScrollController4);
                                    }
                                  },
                                  child: Container(
                                    height: 30,
                                    width: 30,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white.withOpacity(0.5)
                                            : Colors.grey.withOpacity(0.5),
                                      ),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Icon(
                                        Icons.arrow_back_ios_sharp,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        size: 15,
                                      ),
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          SizedBox(
                            width: 5,
                          ),
                          kIsWeb
                              ? GestureDetector(
                                  onTap: () {
                                    if (communitiesController.scrollValue4 <
                                        communitiesController.listLength4 - 2) {
                                      communitiesController.scrollValue4 =
                                          communitiesController.scrollValue4 +
                                              2;
                                      // print(communitiesController.scrollValue4);
                                      // print("+");
                                      communitiesController.update();
                                      if (communitiesController.scrollValue4 <=
                                          communitiesController.listLength4 -
                                              2) {
                                        scrollToItem(
                                            communitiesController.scrollValue4,
                                            itemScrollController:
                                                communitiesController
                                                    .itemScrollController4);
                                      }
                                    }
                                  },
                                  child: Container(
                                    height: 30,
                                    width: 30,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Colors.white.withOpacity(0.5)
                                              : Colors.grey.withOpacity(0.5)),
                                    ),
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Icon(
                                        Icons.arrow_forward_ios,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        size: 15,
                                      ),
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                SizedBox(
                  height: 20,
                ),
                Container(
                    height: 250,
                    child: ScrollablePositionedList.builder(
                        physics: kIsWeb
                            ? NeverScrollableScrollPhysics()
                            : ScrollPhysics(),
                        itemScrollController:
                            communitiesController.itemScrollController4,
                        scrollDirection: Axis.horizontal,
                        itemCount: communitiesController.list.length,
                        itemBuilder: (BuildContext context, int index) {
                          return GestureDetector(
                            onTap: kIsWeb
                                ? () {
                                    communitiesController.timer?.cancel();
                                    communitiesController.timer3?.cancel();
                                    communitiesController.timer2?.cancel();
                                    communitiesController.timer4?.cancel();
                                    communitiesController.update();

                                    communitiesController
                                        .newsfeedController.isSearch = false;
                                    communitiesController
                                        .newsfeedController.isFilter = false;
                                    communitiesController.newsfeedController
                                        .isFilterScreen = false;
                                    communitiesController.newsfeedController
                                        .isTrendsScreen = false;
                                    communitiesController.newsfeedController
                                        .isNewsFeedScreen = false;
                                    communitiesController.newsfeedController
                                        .isBrowseScreen = false;
                                    communitiesController.newsfeedController
                                        .isNotificationScreen = false;
                                    communitiesController.newsfeedController
                                        .isSavedPostScreen = false;
                                    communitiesController.newsfeedController
                                        .isWhoToFollowScreen = false;
                                    communitiesController.newsfeedController
                                        .isChatScreen = false;
                                    communitiesController.newsfeedController
                                        .isPostDetails = false;
                                    communitiesController.newsfeedController
                                        .searchText.text = '';
                                    communitiesController.newsfeedController
                                        .isListScreen = false;
                                    communitiesController.newsfeedController
                                        .isListDetailScreen = false;
                                    communitiesController.newsfeedController
                                        .isProfileScreen = false;
                                    communitiesController.newsfeedController
                                        .isFollwerScreen = false;
                                    communitiesController.newsfeedController
                                        .isSettingsScreen = false;
                                    communitiesController.newsfeedController
                                        .isTopicScreen = false;
                                    communitiesController.newsfeedController
                                        .isCommunitesScreen = false;
                                    communitiesController.newsfeedController
                                        .isCommunityScreen = false;
                                    // Get.delete<CommunitiesController>();

                                    communitiesController.newsfeedController
                                        .isAllGroupScreen = true;
                                    communitiesController.CategoryName =
                                        communitiesController.list[index];

                                    communitiesController.newsfeedController
                                        .update();
                                  }
                                : () {
                                    communitiesController.CategoryName =
                                        communitiesController.list[index];
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => AllGroupScreen(),
                                      ),
                                    );
                                  },
                            child: Padding(
                              padding: const EdgeInsets.only(right: 20),
                              child: CategoriesCard(
                                communitiesController: communitiesController,
                                categoriesNames:
                                    communitiesController.list[index],
                              ),
                            ),
                          );
                        })),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// class MainCommunitiesScreen extends StatelessWidget {
//    MainCommunitiesScreen({Key key}) : super(key: key);
//
//   final communitiesController = Get.put(CommunitiesController());
//   final scrollController =   ScrollController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//
//       appBar: kIsWeb ? PreferredSize(
//         preferredSize: Size.fromHeight(50.0),
//         child: Container(
//
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.start,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               kIsWeb ? SizedBox(height: 20,) : SizedBox(height: 49),
//               Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 15),
//                 child: Row(
//                   children: [
//                     GestureDetector(
//                       onTap: kIsWeb ? () {
//                         // controller.newsfeedController.isTrendsScreen =
//                         // false;
//                         // controller.newsfeedController.isNewsFeedScreen =
//                         // true;
//                         // controller.newsfeedController.isBrowseScreen =
//                         // false;
//                         // controller.newsfeedController
//                         //     .isNotificationScreen = false;
//                         // controller.newsfeedController.isChatScreen =
//                         // false;
//                         // controller.newsfeedController
//                         //     .isSavedPostScreen = false;
//                         // controller.newsfeedController.isPostDetails =
//                         // false;
//                         // controller.newsfeedController.isProfileScreen =
//                         // false;
//                         // controller.newsfeedController
//                         //     .isOtherUserProfileScreen = false;
//                         // controller.newsfeedController.isTopicScreen =
//                         // false;
//                         // controller.newsfeedController.isListScreen =
//                         // false;
//                         // controller.newsfeedController
//                         //     .isMainTopicScreen = false;
//                         // controller.newsfeedController.update();
//                       } : () {
//                         Navigator.pop(context);
//                       },
//                       child: Icon(
//                         Icons.arrow_back,
//                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white:Colors.black, size: 25,
//                       ),
//                     ),
//                     kIsWeb ? SizedBox(width: 50,) : SizedBox(width: 20),
//                     Text('Communities',
//                       style: Theme.of(context).brightness == Brightness.dark ?
//                       TextStyle(color: Colors.white,
//                         fontSize: 20,
//                         fontWeight: FontWeight.w700,) :
//                       TextStyle(color: Colors.black,  fontSize: 20,
//                     ),
//                     ),
//
//                   ],
//                 ),
//               ),
//
//
//             ],
//           ),
//         ),
//       ): AppBar(
//
//         automaticallyImplyLeading: false,
//
//         backgroundColor: Colors.white,
//         title:Row(
//           children: [
//             GestureDetector(
//                 onTap: (){
//                   Navigator.pop(context);
//                 },
//                 child: Icon(Icons.arrow_back, color: Colors.black, size: 25,)
//             ),
//             SizedBox(
//               width: 20,
//             ),
//             Text('Communities',
//              style: Theme.of(context).brightness == Brightness.dark ?
//               TextStyle(color: Colors.white,
//                 fontSize: 20,
//                 fontWeight: FontWeight.w700,) :
//              TextStyle(color: Colors.black,  fontSize: 20,
//
//             )
//             ),
//           ],
//         ),
//
//       ),
//
//       body: Container(
//         child: Padding(
//           padding: const EdgeInsets.only(left: 20,right:20,top:20),
//           child: SingleChildScrollView(
//             controller: scrollController,
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                   children: [
//                     Text(
//                       "Your Community",
//                         style: Theme.of(context).brightness == Brightness.dark ?
//                         TextStyle(color: Colors.white,
//                           fontSize: 20,
//                           fontWeight: FontWeight.w700,) :
//                         TextStyle(color: Colors.black,  fontSize: 20,
//
//                         )
//                     ),
//                     SizedBox(
//
//                       width: 40,
//                     ),
//                     Tooltip(
//                       message: 'Create Community',
//
//                       child: GestureDetector(
//                         onTap:kIsWeb? (){
//                           showDialog(
//                               context: context,
//                               builder: (BuildContext con) {
//                                 return AlertDialog(
//                                   contentPadding: EdgeInsets.zero,
//                                   content: StatefulBuilder(
//                                     builder: (BuildContext context, StateSetter setState) {
//                                       return CreateCommunity(
//                                         editCheck: true,
//                                         // communitiesController: communitiesController,
//
//                                       );
//                                     }
//                                   ),
//                                 );
//                               });
//
//
//
//
//
//
//                         }:(){
//
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(builder: (context) =>  CreateCommunity(
//                               editCheck: true,
//                             )),
//                           );
//
//                         },
//                         child: Container(
//                           height: 18,
//                           width: 18,
//                           decoration: BoxDecoration(
//                             color: Color(0xFF0157d3),
//
//                             shape: BoxShape.circle
//                           ),
//                           child: Align(
//                              alignment: Alignment.center,
//                             child: Icon(
//                               Icons.add,
//                               color: Colors.white,
//                               size: 15,
//
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 5,
//                 ),
//                 Text(
//                   "Communities you have created",
//                   style: TextStyle(
//                       fontWeight: FontWeight.bold,
//                       color: Color(0xFF0157d3),
//                       fontSize: 15
//                   ),
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Container(
//                  height: 300,
//
//
//                   child: ScrollablePositionedList.builder(
//                    // itemScrollController: ,
//                     scrollDirection: Axis.horizontal,
//                     itemCount: 10,
//                       itemBuilder: (BuildContext context, int index){
//                        return GestureDetector(
//                          onTap: (){
//
//                            communitiesController.newsfeedController.isSearch = false;
//                            communitiesController.newsfeedController.isFilter = false;
//                            communitiesController.newsfeedController.isFilterScreen = false;
//                            communitiesController.newsfeedController.isTrendsScreen = false;
//                            communitiesController.newsfeedController.isNewsFeedScreen = false;
//                            communitiesController.newsfeedController.isBrowseScreen = false;
//                            communitiesController.newsfeedController.isNotificationScreen = false;
//                            communitiesController.newsfeedController.isSavedPostScreen = false;
//                            communitiesController.newsfeedController.isWhoToFollowScreen = false;
//                            communitiesController.newsfeedController.isChatScreen = false;
//                            communitiesController.newsfeedController.isPostDetails = false;
//                            communitiesController.newsfeedController.searchText.text = '';
//                            communitiesController.newsfeedController.isListScreen = false;
//                            communitiesController.newsfeedController.isListDetailScreen = false;
//                            communitiesController.newsfeedController.isProfileScreen = false;
//                            communitiesController.newsfeedController.isFollwerScreen = false;
//                            communitiesController.newsfeedController.isSettingsScreen = false;
//                            communitiesController.newsfeedController.isTopicScreen = false;
//                            communitiesController.newsfeedController.isCommunitesScreen = false;
//                            communitiesController.newsfeedController.isCommunityScreen = true;
//
//                            communitiesController.newsfeedController.update();
//                          },
//                          child: Padding(
//                            padding: const EdgeInsets.only(right: 20),
//                            child: CommunitiesCard(
//                              key: communitiesController.itemKey,
//                              cardType: "YourGroup",
//                              communitiesController: communitiesController,
//
//                            ),
//                          ),
//                        );
//
//                       }
//                   )
//
//                 ),
//                 SizedBox(
//                   height: 30,
//                 ),
//                 Text(
//                   "Communities you've joined",
//                     style: Theme.of(context).brightness == Brightness.dark ?
//                     TextStyle(color: Colors.white,
//                       fontSize: 20,
//                       fontWeight: FontWeight.w700,) :
//                     TextStyle(color: Colors.black,  fontSize: 20,
//
//                     )
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Container(
//                     height: 300,
//
//
//                     child: ListView.builder(
//                         scrollDirection: Axis.horizontal,
//                         itemCount: 10,
//                         itemBuilder: (BuildContext context, int index){
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 20),
//                             child: CommunitiesCard(
//                               cardType:"joinCommunity",
//                               communitiesController: communitiesController,
//
//                             ),
//                           );
//
//                         }
//                     )
//
//                 ),
//                 SizedBox(
//                   height: 30,
//                 ),
//                 Text(
//                   "Suggested for You",
//                     style: Theme.of(context).brightness == Brightness.dark ?
//                     TextStyle(color: Colors.white,
//                       fontSize: 20,
//                       fontWeight: FontWeight.w700,) :
//                     TextStyle(color: Colors.black,  fontSize: 20,
//
//                     )
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Container(
//                     height: 300,
//
//
//                     child: ListView.builder(
//                         scrollDirection: Axis.horizontal,
//                         itemCount: 10,
//                         itemBuilder: (BuildContext context, int index){
//                           return Padding(
//                             padding: const EdgeInsets.only(right: 20),
//                             child: CommunitiesCard(
//                               cardType:"SuggestedCommunity",
//                               communitiesController: communitiesController,
//
//                             ),
//                           );
//
//                         }
//                     )
//
//                 ),
//                 SizedBox(
//                   height: 30,
//                 ),
//                 Text(
//                   "Find Community by browsing top categories",
//                   style: Theme.of(context).brightness == Brightness.dark ?
//                   TextStyle(color: Colors.white,
//                     fontSize: 20,
//                     fontWeight: FontWeight.w700,) :
//                   TextStyle(color: Colors.black,  fontSize: 20,
//
//                   )
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//                 Container(
//                     height: 250,
//
//                     child: ListView.builder(
//                         scrollDirection: Axis.horizontal,
//                         itemCount: communitiesController.list.length,
//                         itemBuilder: (BuildContext context, int index){
//                           return GestureDetector(
//                             onTap: (){
//                               communitiesController.newsfeedController.isSearch = false;
//                               communitiesController.newsfeedController.isFilter = false;
//                               communitiesController.newsfeedController.isFilterScreen = false;
//                               communitiesController.newsfeedController.isTrendsScreen = false;
//                               communitiesController.newsfeedController.isNewsFeedScreen = false;
//                               communitiesController.newsfeedController.isBrowseScreen = false;
//                               communitiesController.newsfeedController.isNotificationScreen = false;
//                               communitiesController.newsfeedController.isSavedPostScreen = false;
//                               communitiesController.newsfeedController.isWhoToFollowScreen = false;
//                               communitiesController.newsfeedController.isChatScreen = false;
//                               communitiesController.newsfeedController.isPostDetails = false;
//                               communitiesController.newsfeedController.searchText.text = '';
//                               communitiesController.newsfeedController.isListScreen = false;
//                               communitiesController.newsfeedController.isListDetailScreen = false;
//                               communitiesController.newsfeedController.isProfileScreen = false;
//                               communitiesController.newsfeedController.isFollwerScreen = false;
//                               communitiesController.newsfeedController.isSettingsScreen = false;
//                               communitiesController.newsfeedController.isTopicScreen = false;
//                               communitiesController.newsfeedController.isCommunitesScreen = false;
//                               communitiesController.newsfeedController.isCommunityScreen = false;
//                               communitiesController.newsfeedController.isAllGroupScreen = true;
//
//                               communitiesController.CategoryName = communitiesController.list[index];
//
//                               communitiesController.newsfeedController.update();
//                             },
//                             child: Padding(
//                               padding: const EdgeInsets.only(right: 20),
//                               child: CategoriesCard(
//
//                                 communitiesController: communitiesController,
//                                 categoriesNames:communitiesController.list[index],
//
//                               ),
//                             ),
//                           );
//
//                         }
//                     )
//
//                 ),
//                 SizedBox(
//                   height: 20,
//                 ),
//
//
//
//
//               ],
//             ),
//           ),
//         ),
//
//
//       ),
//
//     );
//   }
// }
