import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../models/list_create_model.dart';
import '../network/controller/List_controller.dart';
import '../network/singleTone.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/strings.dart';
import '../utils/utils_methods.dart';
import '../widgets/textformfield_screen.dart';
import 'dicover_list_post_screen.dart';
import 'list_screen.dart';

class CreateNewList extends StatefulWidget {
  const CreateNewList({Key key}) : super(key: key);

  @override
  State<CreateNewList> createState() => _CreateNewListState();
}

class _CreateNewListState extends State<CreateNewList> {
  bool imageAvailable = false;
  bool isLoading = false;
  String nameList;
  String crateId;
  String listId;
  final newsfeedController = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ListController>(
      init: ListController(),
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: false,
            backgroundColor: Theme.of(context).brightness == Brightness.dark
                ? Colors.black
                : Colors.white,
            leading: IconButton(
                onPressed: () {
                  SingleTone.instance.selectedLocation = null;
                  controller.userNameController.clear();
                  controller.descriptionController.clear();
                  setState(() {});
                  Navigator.of(context).pop();
                },
                icon: Icon(
                  Icons.close,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                )),
            title: Text(
              Strings.createNewList,
              style: Styles.baseTextTheme.headline2.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                fontWeight: FontWeight.bold,
              ),
              // TextStyle(
              //     fontSize: 14),
            ),
            actions: [
              Padding(
                  padding: const EdgeInsets.all(15),
                  child: isLoading
                      ? Center(
                          child: CircularProgressIndicator(),
                        )
                      : MaterialButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          color: controller.userNameController.text.isNotEmpty
                              ? controller.newsfeedController.displayColor
                              : Colors.grey[500],
                          // background
                          textColor: Colors.white,
                          // foreground
                          onPressed: () async {
                            //   print("hello");

                            if (controller.userNameController.text.isNotEmpty) {
                              setState(() {
                                isLoading = true;
                              });
                              DataListCreated data =
                                  await controller.createList(
                                      isChecked: controller.isChecked,
                                      type: "create",
                                      CoverImageBytes: controller.coverImage);

                              if (data != null) {
                                nameList = data.name;
                                crateId = data.id.toString();
                                Navigator.pop(context);
                                controller.SuggestedPost(
                                    list_Id: data.id.toString(),
                                    name: data.name);
                                setState(() {
                                  isLoading = false;
                                });
                              }
                              setState(() {
                                isLoading = false;
                              });
                              showDialog<String>(
                                context: context,
                                builder: (BuildContext context) => kIsWeb
                                    ? GetBuilder<ListController>(
                                        assignId: true,
                                        id: "edit_suggestion",
                                        builder: (controller) => AlertDialog(
                                            contentPadding:
                                                const EdgeInsets.fromLTRB(
                                                    0.0, 0.0, 0.0, 0.0),
                                            content: Container(
                                              height: Get.height * 0.70,
                                              width: 600,
                                              child: CreateNewListWidget(
                                                newsfeedController:
                                                    newsfeedController,
                                                controller: controller,
                                                data: data,
                                              ),
//                                         SingleChildScrollView(
//                                           child: Column(
//                                             children: [
//                                               ListTile(
//                                                 leading: IconButton(
//                                                     onPressed: () {
//                                                       // SingleTone.instance.selectedLocation = null;
//                                                     //  setState(() {});
//                                                      // Navigator.of(context).pop();
//                                                       Navigator.pop(context);
//                                                     },
//                                                     icon: Icon(
//                                                       Icons.close,
//                                                       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                     )),
//                                                   title: Text(
//                                                     'Add To Your List',
//                                                     style:
//                                                     Styles.baseTextTheme.headline2.copyWith(
//                                                       color: Theme.of(context).brightness == Brightness.dark
//                                                           ? Colors.white
//                                                           : Colors.black,
//                                                       fontWeight: FontWeight.bold,
//                                                     ),
//                                                   ),
//                                                   trailing: MaterialButton(
//                                                     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
//                                                     color: controller.newsfeedController.displayColor,
//                                                     // backgroundRtab
//                                                     textColor: Colors.white,
//                                                     // foreground
//                                                     onPressed: () async{
//                                                       print("list create button");
//
//                                                       if(kIsWeb) {
//                                                         controller.selectedList = await controller.listDetail(listId : data.id);
//                                                         Navigator.pop(context);
//
//                                                         controller.newsfeedController.isSearch = false;
//                                                         controller.newsfeedController.isFilter = false;
//                                                         controller.newsfeedController.isFilterScreen = false;
//                                                         controller.newsfeedController.isTrendsScreen = false;
//                                                         controller.newsfeedController.isNewsFeedScreen = false;
//                                                         controller.newsfeedController.isBrowseScreen = false;
//                                                         controller.newsfeedController.isNotificationScreen = false;
//                                                         controller.newsfeedController.isWhoToFollowScreen = false;
//                                                         controller.newsfeedController.isSavedPostScreen = false;
//                                                         controller.newsfeedController.isChatScreen = false;
//                                                         controller.newsfeedController.isPostDetails = false;
//                                                         controller.newsfeedController.isProfileScreen = false;
//                                                         controller.newsfeedController.searchText.text = '';
//                                                         controller.newsfeedController.isListScreen = false;
//                                                         controller.newsfeedController.isFollwerScreen = false;
//                                                         controller.newsfeedController.isSettingsScreen = false;
//                                                         controller.newsfeedController.isListDetailScreen = true;
//                                                         controller.newsfeedController.navRoute = "isListDetailScreen";
//                                                     //    controller.selectedList = await controller.listDetail(listId : data.id);
//                                                         controller.newsfeedController.update();
//                                                         controller.update();
//                                                       }
//
//
//                                                     //  controller.newsfeedController.update();
// else{
//
//                                                         Navigator.push(
//                                                           context,
//                                                           MaterialPageRoute(
//                                                             builder: (
//                                                                 BuildContext context) =>
//                                                                 DiscoverListScreen(controller: controller.newsfeedController,),
//
//
//                                                           ),
//                                                         );
//                                                         controller.selectedList = await controller.listDetail(listId : data.id);
//                                                         controller.update();
//
//                                                         controller.newsfeedController.update();
//                                                       }
//
//
//
//
//                                                    //   Navigator.pop(context);
//                                                     },
//                                                     child: Text('Done'),
//                                                   )),
//                                               Container(
//                                                 child: SingleChildScrollView(
//                                                   child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
//                                                     SizedBox(height: 20.0),
//                                                     DefaultTabController(
//                                                         length: 2, // length of tabs
//                                                         initialIndex: 1,
//                                                         child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: <Widget>[
//                                                           Container(
//                                                             child: TabBar(
//                                                               labelColor: controller.newsfeedController.displayColor,
//                                                               unselectedLabelColor: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                               tabs: [
//                                                                 Tab(text: 'Members ${controller.addMemberList.length}'),
//                                                                 Tab(text: 'Sugge'
//                                                                     'sted'),
//                                                               ],
//                                                             ),
//                                                           ),
//                                                           Container(
//                                                               height: Get.height,
//                                                               //height of TabBarView
//                                                               decoration: BoxDecoration(border: Border(top: BorderSide(color: Colors.grey, width: 0.5))),
//                                                               child: TabBarView(children: <Widget>[
//                                                                 Container(
//                                                                   height: Get.width*0.27,
//                                                                   child:  SingleChildScrollView(
//                                                                     child: Column(
//                                                                       children: List.generate(
//                                                                           controller.addMemberList.length,
//                                                                               (index) => ListTile(
//                                                                             leading: Container(
//                                                                               height: 40,
//                                                                               width: 40,
//                                                                               decoration: BoxDecoration(
//                                                                                 color: Colors.grey,
//                                                                                 borderRadius: BorderRadius.circular(10),
//                                                                                 image: DecorationImage(
//                                                                                   image: NetworkImage(
//                                                                                       controller.addMemberList[index].authorProfileImage == null
//                                                                                           ? "https://www.challengetires.com/assets/img/placeholder.jpg"
//                                                                                           : controller.addMemberList[index].authorProfileImage),
//                                                                                   fit: BoxFit.fill,
//                                                                                 ),
//                                                                               ),
//                                                                             ),
//                                                                             title: Text(controller.addMemberList[index].authorName,
//                                                                               style: Styles.baseTextTheme.headline1.copyWith(
//                                                                                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                                                 fontSize: 14,
//                                                                               ),
//                                                                             ),
//                                                                             subtitle: Row(
//                                                                               children: [
//                                                                                 Text(
//                                                                                   "@"+controller.addMemberList[index].username,
//                                                                                   style: Styles.baseTextTheme.headline2.copyWith(
//                                                                                     fontSize: 12,
//                                                                                   ),
//                                                                                 ),
//                                                                                 // SizedBox(
//                                                                                 //   width: 4,
//                                                                                 // ),
//                                                                                 // Text(controller.addMemberList[index].username),
//                                                                               ],
//                                                                             ),
//                                                                           )),
//                                                                     ),
//                                                                   ),
//                                                                 ),
//                                                                 Container(
//                                                                   child: SingleChildScrollView(
//                                                                     child: Column(
//                                                                       children: [
//                                                                         Padding(
//                                                                           padding: EdgeInsets.only(top: 10, right: 10, bottom: 10, left: 10),
//                                                                           child: TextField(
//                                                                             style: LightStyles.baseTextTheme.headline2.copyWith(
//                                                                               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                                               // fontSize: 14,
//                                                                               // fontWeight: FontWeight.bold,
//                                                                             ),
//                                                                             autofocus: true,
//                                                                             // controller: controller.chatSearchTEC,
//                                                                             // focusNode: controller.chatSearchTextFocus,
//                                                                             onChanged: (value) async {
//
//                                                                               String search=value;
//                                                                               if(search.startsWith('@')){
//                                                                                 var splitArray = search.split('@');
//                                                                                 print("splitArray @:$splitArray");
//                                                                                 print(splitArray[1]);
//                                                                                 search=splitArray[1];
//                                                                               }
//                                                                               else if(search.startsWith('#')){
//                                                                                 var splitArray = search.split('#');
//                                                                                 print("splitArray #:$splitArray");
//                                                                                 print(splitArray[1]);
//                                                                                 search=splitArray[1];
//                                                                               }
//                                                                               else{
//                                                                                 search=value;
//                                                                               }
//
//                                                                               controller.modelSuggestList = await controller.SuggestedPost(list_Id: data.id.toString(),name:search);
//                                                                             },
//                                                                             textAlignVertical: TextAlignVertical.center,
//                                                                             decoration: InputDecoration(
//                                                                               hintText: Strings.searchPeople,
//                                                                               hintStyle: LightStyles.baseTextTheme.headline3,
//                                                                               prefixIcon: Icon(Icons.search, size: 20,
//                                                                               color: controller.newsfeedController.displayColor,
//                                                                               ),
//                                                                               focusedBorder:  OutlineInputBorder(
//                                                                                   borderRadius: BorderRadius.circular(40),
//                                                                                   borderSide: BorderSide(
//                                                                                     width: 1,
//                                                                                     color:
//                                                                                     controller.newsfeedController.displayColor,
//                                                                                   )),
//                                                                               border: OutlineInputBorder(
//                                                                                 borderRadius: BorderRadius.circular(40),
//                                                                                 borderSide: BorderSide(
//                                                                                   width: 1,
//                                                                                   color: Colors.grey,
//                                                                                 ),
//                                                                               ),
//                                                                               enabledBorder: OutlineInputBorder(
//                                                                                 borderRadius: BorderRadius.circular(40),
//                                                                                 borderSide: BorderSide(
//                                                                                 width: 1,
//                                                                                 color: Colors.grey,
//                                                                               ),
//                                                                               ),
//                                                                               fillColor: Colors.grey[250],
//                                                                             ),
//                                                                           ),
//                                                                         ),
//
//                                                                         SizedBox(
//                                                                           height:kIsWeb? MediaQuery
//                                                                               .of(
//                                                                               context)
//                                                                               .size
//                                                                               .height : MediaQuery
//                                                                               .of(
//                                                                               context)
//                                                                               .size
//                                                                               .height ,
//                                                                           width: Get.width ,
//                                                                           child: controller.modelSuggestList.isEmpty || controller.modelSuggestList == null?Center(child: Padding(
//                                                                             padding: const EdgeInsets.only(top:20.0),
//                                                                             child: Text("No results"),
//                                                                           ),) :SingleChildScrollView(child:Column(
//                                                                             children: List.generate(
//                                                                                 controller.modelSuggestList.length,
//                                                                                     (index) => ListTile(
//                                                                                     leading: Container(
//                                                                                       height: 40,
//                                                                                       width: 40,
//                                                                                       decoration: BoxDecoration(
//                                                                                           color: Colors.grey,
//                                                                                           borderRadius: BorderRadius.circular(10),
//                                                                                           image: DecorationImage(
//                                                                                               image: NetworkImage(
//                                                                                                   controller.modelSuggestList[index].authorProfileImage==null?
//                                                                                                   "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
//                                                                                                       : controller.modelSuggestList[index].authorProfileImage
//                                                                                               ), fit: BoxFit.fill)),
//                                                                                     ),
//                                                                                     title: Text(
//                                                                                       controller.modelSuggestList[index].authorName,
//                                                                                       style: Styles.baseTextTheme.headline1.copyWith(
//                                                                                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                                                         fontSize: 14,
//                                                                                       ),
//                                                                                     ),
//                                                                                     subtitle: Row(
//                                                                                       children: [
//                                                                                         Text("@"+controller.modelSuggestList[index].username,
//                                                                                           style: Styles.baseTextTheme.headline2.copyWith(
//                                                                                             fontSize: 12,
//                                                                                           ),
//                                                                                         ),
//                                                                                         // SizedBox(
//                                                                                         //   width: 4,
//                                                                                         // ),
//                                                                                         // Text(controller.modelSuggestList[index].username),
//                                                                                       ],
//                                                                                     ),
//                                                                                     trailing:
//                                                                                     ElevatedButton(
//                                                                                         style: ElevatedButton.styleFrom(
//                                                                                           shape: RoundedRectangleBorder(
//                                                                                               borderRadius: BorderRadius.circular(30)
//                                                                                           ),
//                                                                                           primary: Theme.of(context).brightness == Brightness.dark ?!controller.modelSuggestList[index].isFollow ? Colors.white : Colors.black: !controller.modelSuggestList[index].isFollow ? Colors.black : Colors.white,
//
//
//
//
//                                                                                           // controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30),
//                                                                                         ),
//                                                                                         onPressed: controller.modelSuggestList[index].isFollow == false ?
//                                                                                             () async{
//
//                                                                                           controller.modelSuggestList[index].isFollow = true;
//                                                                                           controller.addMemberList.add(controller.modelSuggestList[index]);
//
//                                                                                           controller.update(["edit_suggestion"]);
//                                                                                           controller.update();
//                                                                                           print("list  fllow suggestion id check ${controller.modelSuggestList[index].id}");
//                                                                                           print("list  fllow data id check ${data.id}");
//                                                                                           controller.memberAdd(data.id.toString(), controller.modelSuggestList[index].id,"member");
//
//                                                                                         }
//                                                                                             : () {
//
//                                                                                           controller.modelSuggestList[index].isFollow == false;
//
//                                                                                           controller.modelSuggestList.forEach((element) {
//                                                                                             if(element.id == controller.modelSuggestList[index].id ){
//                                                                                               element.isFollow = false;
//                                                                                             }
//                                                                                           });
//                                                                                           for(int i=0; i< controller.addMemberList.length; i++  ){
//                                                                                             if(controller.addMemberList[i].id == controller.modelSuggestList[index].id){
//                                                                                               controller.addMemberList.removeAt(i);
//                                                                                             }
//                                                                                           }
//                                                                                           controller.update(["edit_suggestion"]);
//                                                                                           controller.update();
//
//                                                                                           controller.deletePost(controller.modelSuggestList[index].id);
//                                                                                           // dataList.remove(
//                                                                                           //     controller.  listOfDiscover[index]);
//
//
//                                                                                           controller.update(["edit_suggestion"]);
//                                                                                           controller.update();
//                                                                                           print("list  unfllow suggestion id check ${controller.modelSuggestList[index].id}");
//                                                                                           print("list  unfllow data id check ${data.id}");
//                                                                                           controller.unFollowRemoveMethod( list_Id:data.id.toString(),
//                                                                                               member_id:controller.modelSuggestList[index].id.toString(),type:"member");
//                                                                                         },
//                                                                                         child: controller.modelSuggestList[index].isFollow == false
//                                                                                             ? Text(
//                                                                                             "Add",
//                                                                                             style: Styles.baseTextTheme.headline1.copyWith(
//                                                                                               fontSize: 14,
//                                                                                               color: Theme.of(context).brightness == Brightness.dark ?Colors.black:Colors.white,
//                                                                                             )
//                                                                                           // Theme.of(context).textTheme.headline6.copyWith(
//                                                                                           //   fontSize: 14,
//                                                                                           //   fontWeight: FontWeight.w700,
//                                                                                           //   color: Colors.white,
//                                                                                           // ),
//                                                                                         )
//                                                                                             : Text(
//                                                                                           "Remove",
//                                                                                           style: Styles.baseTextTheme.headline1.copyWith(
//                                                                                             fontSize: 14,
//                                                                                             color: Theme.of(context).brightness == Brightness.dark ?Colors.white:Colors.black,
//                                                                                           ),
//                                                                                           // Theme.of(context).textTheme.headline6.copyWith(
//                                                                                           //   fontSize: 14,
//                                                                                           //   fontWeight: FontWeight.w700,
//                                                                                           //   color: Colors.white,
//                                                                                           // ),
//                                                                                         ))
//
//                                                                                 )),
//                                                                           )),
//                                                                         ),
//                                                                       ],
//                                                                     ),
//                                                                   ),
//                                                                 ),
//                                                               ]))
//                                                         ])),
//                                                   ]),
//                                                 ),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
                                            )),
                                      )
                                    : CreateNewListWidget(
                                        newsfeedController: newsfeedController,
                                        controller: controller,
                                        data: data,
                                      ),
                              );
                            } else {
                              UtilsMethods.toastMessageShow(
                                newsfeedController.displayColor,
                                newsfeedController.displayColor,
                                newsfeedController.displayColor,
                                message: 'Please enter the name ',
                              );
                            }
                          },
                          child: Text(Strings.next),
                        )),
            ],
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                    padding: const EdgeInsets.only(left: 2, right: 2),
                    child: Container(
                      width: Get.width,
                      height: Get.height * 0.25,
                      decoration: BoxDecoration(color: Colors.grey[500]),
                      child: imageAvailable == false
                          ? Center(
                              child: CircleAvatar(
                              radius: 30,
                              backgroundColor: Colors.black54,
                              child:

                                  ///firstcamera fault
                                  IconButton(
                                onPressed: () async {
                                  controller.coverImage =
                                      await controller.callGetImage();

                                  // print(
                                  //     "controller.coverImage ${controller.coverImage}");

                                  controller.update();

                                  setState(() {
                                    imageAvailable = true;
                                    // // imageFile = image as Uint8List;
                                  });
                                },
                                icon: Icon(
                                  Icons.camera_alt,
                                  color: Colors.white,
                                ),
                                splashColor: Colors.black,
                              ),
                            ))
                          : Stack(children: [
                              Container(
                                height: Get.height,
                                width: Get.width,
                                child: controller.coverImage != null
                                    ? Image.memory(
                                        controller.coverImage,
                                        fit: BoxFit.cover,
                                      )
                                    : Image.asset(
                                        'assets/images/person_placeholder.png',
                                        fit: BoxFit.cover,
                                      ),
                              ),
                              Positioned(
                                top: 0,
                                right: 0,
                                child: Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Row(
                                      children: [
                                        Card(
                                            color: Colors.black26,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(80),
                                            ),
                                            child: Center(
                                                child: IconButton(
                                                    onPressed: () async {
                                                      ///2ndcamera fault

                                                      controller.coverImage =
                                                          await controller
                                                              .callGetImage();

                                                      setState;
                                                      setState(() {
                                                        imageAvailable = true;
                                                      });
                                                    },
                                                    icon: Icon(
                                                      Icons.camera_alt,
                                                      color: Colors.white,
                                                      size: 25,
                                                    )))),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Card(
                                            color: Colors.black26,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(80),
                                            ),
                                            child: Center(
                                                child: IconButton(
                                                    onPressed: () {
                                                      setState;
                                                      setState(() {
                                                        imageAvailable = false;
                                                        controller.coverImage =
                                                            null;
                                                      });
                                                    },
                                                    icon: Icon(
                                                      Icons.close,
                                                      color: Colors.white,
                                                      size: 25,
                                                    )))),
                                      ],
                                    )),
                              ),
                            ]),
                    )),
                SizedBox(
                  height: 20,
                ),
                CustomFormField(
                  // label: "Name",
                  hintText: Strings.name,
                  focusBorderColor: controller.newsfeedController.displayColor,
                  // labelStyle: Styles.baseTextTheme.headline2.copyWith(
                  //   color: controller.newsfeedController.displayColor,
                  //   fontWeight: FontWeight.w400,
                  //   fontSize: kIsWeb ? 16 : 14,
                  // ),
                  controller: controller.userNameController,
                  onChange: (value) {
                    // controller.userNameController.text = value;

                    setState(() {});
                    // if(controller.userNameController.text.length>0)
                    //   {
                    //
                    //
                    //   }
                    // else if(controller.userNameController.text.length == 0)
                    //   {
                    //
                    //     setState(() { });
                    //
                    //   }

                    controller.update();
                  },
                  maxLength: 25,
                ),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 15, right: 15),
                  child: Container(
                    alignment: Alignment.centerLeft,
                    //  height: 130,
                    child: TextFormField(
                      textAlign: TextAlign.start,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.w500,
                        fontSize: kIsWeb ? 16 : 14,
                      ),
                      controller: controller.descriptionController,
                      onChanged: (value) {
                        // value = controller
                        // .descriptionController
                        // .text  ;
                        controller.update();
                      },
                      maxLines: 2,
                      maxLength: 100,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(color: Colors.grey, width: 1),
                        ),
                        contentPadding: const EdgeInsets.only(
                            bottom: 30, top: 10, left: 15, right: 5),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(
                              color: controller.newsfeedController.displayColor,
                              width: 1,
                            )),
                        filled: true,
                        // label: Text("Descriptions"),
                        // labelStyle: Styles.baseTextTheme.headline2.copyWith(
                        //   color: controller.newsfeedController.displayColor,
                        //   fontWeight: FontWeight.w400,
                        //   fontSize: kIsWeb ? 16 : 14,
                        // ),
                        hintText: Strings.enterDescription,
                        hintStyle: Styles.baseTextTheme.headline2.copyWith(
                          // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontWeight: FontWeight.w400,

                          fontSize: kIsWeb ? 16 : 14,
                        ),
                        fillColor: Colors.grey[250],
                      ),
                      cursorColor: controller.newsfeedController.displayColor,
                    ),
                  ),
                ),
                ListTile(
                  trailing: CheckBoxList(),
                  title: Text(Strings.private,
                      style: Styles.baseTextTheme.headline1.copyWith(
                        fontSize: 16,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                      // Theme.of(context).textTheme.headline6.copyWith(
                      //   fontSize: 16,
                      //   fontWeight: FontWeight.w800,
                      //   color: Colors.black,
                      // ),
                      ),
                  subtitle: Text(
                    Strings.whenYouMakeAList,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      fontSize: 14,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                    // Theme
                    //     .of(
                    //     context)
                    //     .textTheme
                    //     .headline6
                    //     .copyWith(
                    //   fontSize:
                    //   16,
                    //   fontWeight:
                    //   FontWeight
                    //       .w800,
                    //   color: Colors
                    //       .black26,
                    // ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class CreateNewListWidget extends StatefulWidget {
  final NewsfeedController newsfeedController;
  final ListController controller;
  final DataListCreated data;

  const CreateNewListWidget(
      {Key key, this.newsfeedController, this.controller, this.data})
      : super(key: key);

  @override
  State<CreateNewListWidget> createState() => _CreateNewListWidgetState();
}

class _CreateNewListWidgetState extends State<CreateNewListWidget> {
  // const CreateNewListWidget({Key key, this.newsfeedController, this.controller, this.data}) : super(key: key);
  bool isLoading = false;
  final storage = GetStorage();
  NewsfeedController newsfeedController;
  ListController controller;
  DataListCreated data;
  Timer _userSuggestionsTypingTimer;


  @override
  void initState() {
    super.initState();
    newsfeedController = widget.newsfeedController;
    controller = widget.controller;
    data = widget.data;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            ListTile(
                leading: IconButton(
                    onPressed: () {
                      // SingleTone.instance.selectedLocation = null;
                      //  setState(() {});
                      // Navigator.of(context).pop();
                      Navigator.pop(context);
                    },
                    icon: Icon(
                      Icons.close,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    )),
                title: Text(
                  Strings.addToYourList,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                trailing: isLoading
                    ? CircularProgressIndicator()
                    : MaterialButton(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15)),
                        color:
                            widget.controller.newsfeedController.displayColor,
                        // backgroundRtab
                        textColor: Colors.white,
                        // foreground
                        onPressed: () async {
                          // print("list create button");

                          if (kIsWeb) {
                            setState(() {
                              isLoading = true;
                            });

                            // widget.controller.selectedList = await widget.controller.listDetail(
                            //     listId: widget.data.id);
                            Navigator.pop(context);



                          /*  widget.controller.newsfeedController.isSearch = false;
                            widget.controller.newsfeedController.isFilter = false;
                            widget.controller.newsfeedController.isFilterScreen = false;
                            widget.controller.newsfeedController.isTrendsScreen = false;
                            widget.controller.newsfeedController.isNewsFeedScreen = false;
                            widget.controller.newsfeedController.isBrowseScreen = false;
                            widget.controller.newsfeedController.isNotificationScreen = false;
                            widget.controller.newsfeedController.isWhoToFollowScreen = false;
                            widget.controller.newsfeedController.isSavedPostScreen = false;
                            widget.controller.newsfeedController.isChatScreen = false;
                            widget.controller.newsfeedController.isPostDetails = false;
                            widget.controller.newsfeedController.isProfileScreen = false;
                            widget.controller.newsfeedController.searchText.text = '';
                            widget.controller.newsfeedController.isListScreen = false;
                            widget.controller.newsfeedController.isFollwerScreen = false;
                            widget.controller.newsfeedController.isSettingsScreen = false;
                            widget.controller.newsfeedController.isListDetailScreen = true;*/
                            setState(() {
                              isLoading = false;
                            });
                            storage.write("clickId", 3);
                            storage.write("pinId", widget.data.id);
                            controller.newsfeedController.isListDetailScreen = true;
                            controller.newsfeedController.isSearch = false;
                            controller.newsfeedController.isFilter = false;
                            controller.newsfeedController.isFilterScreen = false;
                            controller.newsfeedController.isTrendsScreen = false;
                            controller.newsfeedController.isNewsFeedScreen = false;
                            controller.newsfeedController.isBrowseScreen = false;
                            controller.newsfeedController.isNotificationScreen = false;
                            controller.newsfeedController.isWhoToFollowScreen = false;
                            controller.newsfeedController.isSavedPostScreen = false;
                            controller.newsfeedController.isChatScreen = false;
                            controller.newsfeedController.isPostDetails = false;
                            controller.newsfeedController.isProfileScreen = false;
                            controller.newsfeedController.searchText.text = '';
                            controller.newsfeedController.isListScreen = false;
                            controller.newsfeedController.isFollwerScreen = false;
                            controller.newsfeedController.isSettingsScreen = false;
                            controller.newsfeedController.navRoute = "isChatScreen";
                            controller.newsfeedController.update();
                            // print("list iD?>>>>>>>>>>>>>>>>>>>>>" +
                            //     widget.data.id.toString());
                            Get.toNamed(FluroRouters.mainScreen +
                                "/listDetail/" + widget.data.id.toString() );
                           /* widget.controller.newsfeedController.navRoute = "isListDetailScreen";
                                controller.selectedList = await controller.listDetail(listId : data.id);
                            widget.controller.newsfeedController.update();
                            widget.controller.update();*/
                          }

                          //  controller.newsfeedController.update();
                          else {
                            setState(() {
                              isLoading = true;
                            });
                            Navigator.pop(context);
                            setState(() {
                              isLoading = false;
                            });
                           /* Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    DiscoverListScreen(
                                  controller: widget.controller.newsfeedController,

                                ),
                              ),
                            );*/
                            Navigator.push(context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    DiscoverListScreen(
                                      controller: widget.controller.newsfeedController,
                                      index: 0.toString(),
                                      clickId: 3,
                                      listId: widget.data.id ,

                                    ),
                              ),
                            );
                            // widget.controller.selectedList = await widget
                            //     .controller
                            //     .listDetail(listId: widget.data.id);
                            // widget.controller.update();
                            //
                            // widget.controller.newsfeedController.update();
                          }

                          //   Navigator.pop(context);
                        },
                        child: Text(Strings.done),
                      )),
            Container(
              child: SingleChildScrollView(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      SizedBox(height: 20.0),
                      DefaultTabController(
                          length: 2, // length of tabs
                          initialIndex: 1,
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: <Widget>[
                                Container(
                                  child: TabBar(
                                    labelColor: widget.controller
                                        .newsfeedController.displayColor,
                                    unselectedLabelColor:
                                        Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                    tabs: [
                                      Tab(
                                          text:
                                              '${Strings.members} ${widget.controller.addMemberList.length}'),
                                      Tab(
                                          text: Strings.suggested),
                                    ],
                                  ),
                                ),
                                Container(
                                    height: Get.height,
                                    //height of TabBarView
                                    decoration: BoxDecoration(
                                        border: Border(
                                            top: BorderSide(
                                                color: Colors.grey,
                                                width: 0.5))),
                                    child: TabBarView(children: [
                                      Container(
                                        height: Get.width * 0.27,
                                        child: SingleChildScrollView(
                                          child: Column(
                                            children: List.generate(
                                                widget.controller.addMemberList.length,
                                                (index) => ListTile(
                                                      leading: Container(
                                                        height: 40,
                                                        width: 40,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: Colors.grey,
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(10),
                                                          image:
                                                              DecorationImage(
                                                            image: NetworkImage(widget.controller.addMemberList[index]
                                                                        .authorProfileImage ==
                                                                    null
                                                                ? "https://www.challengetires.com/assets/img/placeholder.jpg"
                                                                : widget
                                                                    .controller
                                                                    .addMemberList[
                                                                        index]
                                                                    .authorProfileImage),
                                                            fit: BoxFit.fill,
                                                          ),
                                                        ),
                                                      ),
                                                      title: Text(
                                                        widget.controller.addMemberList[index].authorName,
                                                        style: Styles
                                                            .baseTextTheme
                                                            .headline1
                                                            .copyWith(
                                                          color: Theme.of(context)
                                                                      .brightness ==
                                                                  Brightness
                                                                      .dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                          fontSize: 14,
                                                        ),
                                                      ),
                                                      subtitle: Row(
                                                        children: [
                                                          Text(
                                                            "@" +
                                                                widget
                                                                    .controller
                                                                    .addMemberList[
                                                                        index]
                                                                    .username,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              fontSize: 12,
                                                            ),
                                                          ),
                                                          // SizedBox(
                                                          //   width: 4,
                                                          // ),
                                                          // Text(controller.addMemberList[index].username),
                                                        ],
                                                      ),
                                                    )),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        child: SingleChildScrollView(
                                          child: Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    top: 10,
                                                    right: 10,
                                                    bottom: 10,
                                                    left: 10),
                                                child: TextField(
controller: controller.searchTextController,
                                                  style: LightStyles
                                                      .baseTextTheme.headline2
                                                      .copyWith(
                                                    color: Theme.of(context)
                                                                .brightness ==
                                                            Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    // fontSize: 14,
                                                    // fontWeight: FontWeight.bold,
                                                  ),
                                                  autofocus: true,
                                                  // controller: controller.chatSearchTEC,
                                                  // focusNode: controller.chatSearchTextFocus,
                                                  onChanged: (value)  {

                                                    resetTimerMembersSuggestion(value);

                                                    },

                                                  textAlignVertical:
                                                      TextAlignVertical.center,
                                                  decoration: InputDecoration(
                                                    hintText:
                                                        Strings.searchPeople,
                                                    hintStyle: LightStyles
                                                        .baseTextTheme
                                                        .headline3,
                                                    prefixIcon: Icon(
                                                      Icons.search,
                                                      size: 20,
                                                      color: widget
                                                          .controller
                                                          .newsfeedController
                                                          .displayColor,
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        40),
                                                            borderSide:
                                                                BorderSide(
                                                              width: 1,
                                                              color: widget
                                                                  .controller
                                                                  .newsfeedController
                                                                  .displayColor,
                                                            )),
                                                    border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40),
                                                      borderSide: BorderSide(
                                                        width: 1,
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              40),
                                                      borderSide: BorderSide(
                                                        width: 1,
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                    fillColor: Colors.grey[250],
                                                  ),
                                                ),
                                              ),
                                              controller.searchFilter==true?
                                              SizedBox(
                                                height: kIsWeb
                                                    ? MediaQuery.of(context)
                                                        .size
                                                        .height
                                                    : MediaQuery.of(context)
                                                        .size
                                                        .height,
                                                width: Get.width,
                                                child: widget.controller.modelSuggestList.isEmpty ||
                                                        widget.controller.modelSuggestList == null
                                                    ? Center(
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .only(
                                                                  top: 20.0),
                                                          child: Text(
                                                              Strings.noResults),
                                                        ),
                                                      )
                                                    : SingleChildScrollView(
                                                        child: Column(
                                                        children: List.generate(
                                                            widget
                                                                .controller
                                                                .modelSuggestList
                                                                .length,
                                                            (index) => ListTile(
                                                                leading:
                                                                    Container(
                                                                  height: 40,
                                                                  width: 40,
                                                                  decoration: BoxDecoration(
                                                                      color: Colors
                                                                          .grey,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              10),
                                                                      image: DecorationImage(
                                                                          image: NetworkImage(widget.controller.modelSuggestList[index].authorProfileImage == null
                                                                              ? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"
                                                                              : widget.controller.modelSuggestList[index].authorProfileImage),
                                                                          fit: BoxFit.fill)),
                                                                ),
                                                                title: Text(
                                                                  widget
                                                                      .controller
                                                                      .modelSuggestList[
                                                                          index]
                                                                      .authorName,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline1
                                                                      .copyWith(
                                                                    color: Theme.of(context).brightness ==
                                                                            Brightness
                                                                                .dark
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black,
                                                                    fontSize:
                                                                        14,
                                                                  ),
                                                                ),
                                                                subtitle: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child:
                                                                          Text(
                                                                        "@" +
                                                                            controller.modelSuggestList[index].username,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          fontSize:
                                                                              12,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    // SizedBox(
                                                                    //   width: 4,
                                                                    // ),
                                                                    // Text(controller.modelSuggestList[index].username),
                                                                  ],
                                                                ),
                                                                trailing: ElevatedButton(
                                                                    style: ElevatedButton.styleFrom(
                                                                      shape: RoundedRectangleBorder(
                                                                          borderRadius:
                                                                              BorderRadius.circular(30)),
                                                                      primary: Theme.of(context).brightness ==
                                                                              Brightness.dark
                                                                          ? !widget.controller.modelSuggestList[index].isFollow
                                                                              ? Colors.white
                                                                              : Colors.black
                                                                          : !widget.controller.modelSuggestList[index].isFollow
                                                                              ? Colors.black
                                                                              : Colors.white,

                                                                      // controller.modelSuggestList[index].isFollow ? Colors.blueAccent : Color(0xFFedab30),
                                                                    ),
                                                                    onPressed: widget.controller.modelSuggestList[index].isFollow == false
                                                                        ? () async {
                                                                            widget.controller.modelSuggestList[index].isFollow =
                                                                                true;
                                                                            widget.controller.addMemberList.add(widget.controller.modelSuggestList[index]);

                                                                            widget.controller.update([
                                                                              "edit_suggestion"
                                                                            ]);
                                                                            widget.controller.update();
                                                                            // print("list  fllow suggestion id check ${controller.modelSuggestList[index].id}");
                                                                            // print("list  fllow data id check ${data.id}");
                                                                            widget.controller.memberAdd(
                                                                                data.id.toString(),
                                                                                controller.modelSuggestList[index].id,
                                                                                "member");
                                                                            setState(() {});
                                                                          }
                                                                        : () {
                                                                            widget.controller.modelSuggestList[index].isFollow ==
                                                                                false;

                                                                            widget.controller.modelSuggestList.forEach((element) {
                                                                              if (element.id == widget.controller.modelSuggestList[index].id) {
                                                                                element.isFollow = false;
                                                                              }
                                                                            });
                                                                            for (int i = 0;
                                                                                i < widget.controller.addMemberList.length;
                                                                                i++) {
                                                                              if (widget.controller.addMemberList[i].id == widget.controller.modelSuggestList[index].id) {
                                                                                widget.controller.addMemberList.removeAt(i);
                                                                              }
                                                                            }
                                                                            widget.controller.update([
                                                                              "edit_suggestion"
                                                                            ]);
                                                                            widget.controller.update();

                                                                            // controller.deletePost(controller.modelSuggestList[index].id);
                                                                            // dataList.remove(
                                                                            //     controller.  listOfDiscover[index]);

                                                                            // controller.update(["edit_suggestion"]);
                                                                            // controller.update();
                                                                            // print("list  unfllow suggestion id check ${controller.modelSuggestList[index].id}");
                                                                            // print("list  unfllow data id check ${data.id}");
                                                                            controller.unFollowRemoveMethod(
                                                                                list_Id: data.id.toString(),
                                                                                member_id: controller.modelSuggestList[index].id.toString(),
                                                                                type: "member");
                                                                            setState(() {});
                                                                          },
                                                                    child: widget.controller.modelSuggestList[index].isFollow == false
                                                                        ? Text(Strings.add,
                                                                            style: Styles.baseTextTheme.headline1.copyWith(
                                                                              fontSize: 14,
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                                                                            )
                                                                            // Theme.of(context).textTheme.headline6.copyWith(
                                                                            //   fontSize: 14,
                                                                            //   fontWeight: FontWeight.w700,
                                                                            //   color: Colors.white,
                                                                            // ),
                                                                            )
                                                                        : Text(
                                                                      Strings.remove,
                                                                            style:
                                                                                Styles.baseTextTheme.headline1.copyWith(
                                                                              fontSize: 14,
                                                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            ),
                                                                            // Theme.of(context).textTheme.headline6.copyWith(
                                                                            //   fontSize: 14,
                                                                            //   fontWeight: FontWeight.w700,
                                                                            //   color: Colors.white,
                                                                            // ),
                                                                          )))),
                                                      )),
                                              ):
                                              SizedBox(),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ]))
                              ])),
                    ]),
              ),
            ),
          ],
        ),
      ),
    );
  }


  startTimerMembersSuggestion(String value) {
    String search = value;
    _userSuggestionsTypingTimer = Timer(const Duration(seconds: 1), () async {
      if(controller.searchTextController.text.isNotEmpty){
        if(search.startsWith('@')){
          var splitArray = search.split('@');
          // print("splitArray @:$splitArray");
          // print(splitArray[1]);
          search=splitArray[1];
        }
        else if(search.startsWith('#')){
          var splitArray = search.split('#');
          search=splitArray[1];
        }
        else{
          search=value;
        }

        widget.controller
            .modelSuggestList =
        await widget.controller
            .SuggestedPost(
            list_Id: widget
                .data.id
                .toString(),
            name: search);
      }
      else if(controller.searchTextController.text.isEmpty){
        controller.searchFilter=false;
        controller.update();
      }
    });
  }

  resetTimerMembersSuggestion(String value) {
    _userSuggestionsTypingTimer?.cancel();
    startTimerMembersSuggestion(value);
  }
}
