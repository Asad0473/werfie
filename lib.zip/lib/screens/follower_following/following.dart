import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/follower_following_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/blue_tick.dart';

import '../../models/get_follower.dart';
import '../../models/profile.dart';
import '../../utils/colors.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';

class FollowingWidget extends StatelessWidget {
  final FollowerController controller;
  final NewsfeedController newsfeedController;
  final isOtherUserProfile;

  const FollowingWidget(
      {Key key, this.controller, this.newsfeedController, this.isOtherUserProfile}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: controller.isLoading /*|| newsfeedController.isLoading*/
            ? const CircularProgressIndicator(
                color: MyColors.BlueColor,
              )
            : controller.followingList == null ||
                    controller.followingList.isEmpty
                ? Text(Strings.noFollowings)
                : ListView.separated(
                    separatorBuilder: (context, index) => const SizedBox(),
                   // padding: const EdgeInsets.all(15),
                    itemCount: controller.followingList.length,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: !kIsWeb
                            ? () async {
                          // if (Get.isRegistered<OtherUserController>()) {
                          //   Get.delete<OtherUserController>();
                          // }
                          // if (Get.isRegistered<FollowerController>()) {
                          //   Get.delete<FollowerController>();
                          // }
                          newsfeedController.otherUserId =
                              controller.followingList[index].followerId;
                          newsfeedController.otherUserName =
                              controller.followingList[index].username;
                          newsfeedController.update();

                          // controller.update();
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => OtherUsersProfile(
                                controller: newsfeedController,
                              ),
                            ),
                          );

                          Get.find<NewsfeedController>().userInfo =
                              UserProfile();
                          Get.find<NewsfeedController>().userInfo =
                          await Get.find<NewsfeedController>()
                              .getOtherUserProfile(controller
                              .followingList[index].followerId);

                          await Get.find<OtherUserController>()
                              .filterUsersPostPagged("posts", page: 1);
                          Get.find<OtherUserController>()
                              .userPosts
                              .forEach((element) {
                            element.mute = Get.find<NewsfeedController>()
                                .userInfo
                                .muted;
                          });
                          Get.find<OtherUserController>().update();
                        }
                            : () async {
                          if (GetStorage().read('id') ==
                              controller
                                  .followingList[index].followerId) {
                            newsfeedController.isTrendsScreen = false;
                            newsfeedController.isNewsFeedScreen = false;
                            newsfeedController.isBrowseScreen = false;
                            newsfeedController.isNotificationScreen =
                            false;
                            newsfeedController.isChatScreen = false;
                            newsfeedController.isSavedPostScreen = false;
                            newsfeedController.isPostDetails = false;
                            newsfeedController.isProfileScreen = true;
                            newsfeedController.isOtherUserProfileScreen =
                            false;
                          } else {
                            newsfeedController.isTrendsScreen = false;
                            newsfeedController.isNewsFeedScreen = false;
                            newsfeedController.isBrowseScreen = false;
                            newsfeedController.isNotificationScreen =
                            false;
                            newsfeedController.isChatScreen = false;
                            newsfeedController.isSavedPostScreen = false;
                            newsfeedController.isPostDetails = false;
                            newsfeedController.isProfileScreen = false;
                            newsfeedController.isFollwerScreen = false;
                            newsfeedController.isOtherUserProfileScreen =
                            true;

                            newsfeedController.otherUserName =
                                controller.followingList[index].username;
                            newsfeedController.otherUserId = controller
                                .followingList[index].followerId;

                            // print(
                            //     "controller.followingList[index].username ${controller.followingList[index].username} ");
                            //
                            // print(
                            //     "controller.followingList[index].followerId ${controller.followingList[index].followerId} ");

                            Get.toNamed(FluroRouters.mainScreen +
                                "/profile/" +
                                newsfeedController.otherUserId
                                    .toString());

                            Get.find<NewsfeedController>().userInfo =
                                UserProfile();
                            Get.find<NewsfeedController>().userInfo =
                            await newsfeedController
                                .getOtherUserProfile(controller
                                .followingList[index].followerId);

                            // print("idhr aya hai gg ");

                            await Get.find<OtherUserController>()
                                .filterUsersPostPagged("posts", page: 1);

                            Get.find<OtherUserController>()
                                .userPosts[0]
                                .mute =
                                Get.find<NewsfeedController>()
                                    .userInfo
                                    .muted;

                            Get.find<OtherUserController>()
                                .userPosts
                                .forEach((element) {
                              element.mute =
                                  Get.find<NewsfeedController>()
                                      .userInfo
                                      .muted;
                              // print("element.mute  ${element.mute}");
                            });

                            newsfeedController.update();
                          }
                          // controller.userProfile = await getUserProfile(userId);
                          newsfeedController.otherUserId =
                              controller.followingList[index].followerId;
                          newsfeedController.otherUserName =
                              controller.followingList[index].username;
                          newsfeedController.update();
                          controller.update();
                        },
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              ListTile(
contentPadding: const EdgeInsets.symmetric(horizontal: 0,vertical: 0),
                                title: Column(
                                  children: [
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        CircleAvatar(
                                          radius: 25,
                                          foregroundImage: controller
                                                      .followingList[index]
                                                      .profileImage !=
                                                  null
                                              ? NetworkImage(controller
                                                  .followingList[index].profileImage)
                                              : const AssetImage(
                                                  'assets/images/person_placeholder.png'),
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Row(
                                              children: [
                                                Text(
                                                  controller.followingList[index].name,
                                                  style: Styles.baseTextTheme.headline2
                                                      .copyWith(
                                                    color:
                                                        Theme.of(context).brightness ==
                                                                Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                    fontWeight: FontWeight.bold,
                                                    fontSize: 15,
                                                  ),
                                                ),
                                                controller.followingList[index]
                                                            .accountVerified ==
                                                        "verified"
                                                    ? Wrap(
                                                        children: [
                                                          const SizedBox(
                                                            width: 5,
                                                          ),
                                                          BlueTick(
                                                            height: 15,
                                                            width: 15,
                                                            iconSize: 12,
                                                          ),
                                                        ],
                                                      )
                                                    : const SizedBox(),
                                              ],
                                            ),
                                            Text(
                                              "@${controller.followingList[index].username}",
                                              style: Styles.baseTextTheme.headline2
                                                  .copyWith(
                                                fontSize: kIsWeb ? 15 : 15,
                                              ),
                                            ),
                                          ],
                                        ),
                                        // Spacer(),
                                      ],
                                    ),
                                  ],
                                ),
                                trailing: SizedBox(
                                  width: 100,
                                  height: kIsWeb?35:30,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20),
                                    child: newsfeedController.storage.read('userName') !=
                                            controller.followingList[index].username
                                        ? MaterialButton(
                                            padding: const EdgeInsets.all(0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20),
                                        side:  BorderSide(color:
                                        Theme.of(context).brightness == Brightness.dark?
                                             controller.followingList[index].isFollow == true?
                                        Colors.white:Colors.grey: controller.followingList[index].isFollow == true?
                                        Colors.black:Colors.grey
                                        ),
                                      ),
                                            color: Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? controller.followingList[index]
                                                            .isFollow ==
                                                        true
                                                    ? Colors.white
                                                    : Colors.black
                                                : controller.followingList[index]
                                                            .isFollow ==
                                                        true
                                                    ? Colors.black
                                                    : Colors.white,
                                            onPressed: () async {
                                              // print(
                                              //     "idhr aya hai follow   ${controller.followingList[index].isFollow}");

                                              if (controller
                                                      .followingList[index].isFollow ==
                                                  true) {
                                                controller.followingList[index].isFollow =
                                                    false;
                                                controller.update();
                                              } else if (controller
                                                      .followingList[index].isFollow ==
                                                  false) {
                                                controller.followingList[index].isFollow =
                                                    true;
                                                controller.update();
                                              }

                                              if (controller
                                                      .followingList[index].isFollow ==
                                                  false) {
                                                await newsfeedController.addFollowing(
                                                    controller
                                                        .followingList[index].followerId,
                                                    "follow");
                                                // controller.followingList[index].isFollow = true;
                                                controller.update();
                                              } else if (controller
                                                      .followingList[index].isFollow ==
                                                  true) {
                                                await newsfeedController.addFollowing(
                                                    controller
                                                        .followingList[index].followerId,
                                                    "unFollow");
                                                await newsfeedController.followSuggestions();
                                                // controller.followingList[index].isFollow = false;
                                                 controller.update();
                                              }

                                            },
                                            child: Text(
                                              controller.followingList[index].isFollow ==
                                                      true
                                                  ? "${Strings.follow}".capitalizeFirst
                                                  : Strings.following,
                                              style: TextStyle(
                                                // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                fontSize: 14,
                                                fontWeight: FontWeight.bold,
                                                color: Theme.of(context).brightness ==
                                                        Brightness.dark
                                                    ? controller.followingList[index]
                                                                .isFollow ==
                                                            true
                                                        ? Colors.black
                                                        : Colors.white
                                                    : controller.followingList[index]
                                                                .isFollow ==
                                                            true
                                                        ? Colors.white
                                                        : Colors.black,
                                              ),

                                            ),
                                          )
                                        : const SizedBox(),
                                  ),
                                ),

                              ),
                              controller.followingList[index].bio==null?const SizedBox()
                              :Align(
                                alignment: Alignment.topLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 60,right: 0),
                                  child: Text(controller.followingList[index].bio ,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 2,
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w400,
                                          color: Theme.of(context).brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black
                                      )
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
