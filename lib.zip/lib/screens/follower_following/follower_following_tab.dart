import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/network/controller/follower_following_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/follower_following/follower.dart';
import 'package:werfieapp/screens/follower_following/following.dart';
import 'package:werfieapp/screens/follower_following/verified_followers.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../utils/font.dart';
import '../../web_views/web_main_screen.dart';

class FollowerScreen extends StatelessWidget {
  final bool isOtherUserProfile;
  final NewsfeedController controller;
  final String id;
  final String page;

  FollowerScreen(
      {this.controller, this.isOtherUserProfile, this.id, this.page});

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Responsive(
        mobile: FollowerTabScreen(
            newsfeedController: controller,
            id: id,
            page: page,
            isOtherUserProfile: isOtherUserProfile),
        tablet: FollowerTabScreen(
            newsfeedController: controller,
            id: id,
            page: page,
            isOtherUserProfile: isOtherUserProfile),
        desktop: FollowerTabScreen(
            newsfeedController: controller,
            id: id,
            page: page,
            isOtherUserProfile: isOtherUserProfile),
      ),
    );
  }
}

class FollowerTabScreen extends StatefulWidget {
  final NewsfeedController newsfeedController;
  final bool isOtherUserProfile;
  final String id;
  final String page;

  FollowerTabScreen(
      {this.newsfeedController, this.isOtherUserProfile, this.id, this.page});

  @override
  State<FollowerTabScreen> createState() => _FollowerTabScreenState();
}

class _FollowerTabScreenState extends State<FollowerTabScreen>
    with TickerProviderStateMixin {
  TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController =  TabController(
        initialIndex: widget.newsfeedController.followTabIndex,
        length: 3,
        vsync: this);
    if (kIsWeb) {
      _tabController.addListener(() {
        widget.newsfeedController.followTabIndex = _tabController.index;
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  getApidata() async {
    // if (!widget.isOtherUserProfile) {
    if (GetStorage().read('id').toString() == widget.id.toString()) {
      // print("isOtherUserProfile if: " + widget.id.toString());

      await Get.put(FollowerController());
      Get.find<FollowerController>().followingCheck = 1;

      Get.find<FollowerController>().update();
      widget.page == "followings"
          ? Get.find<FollowerController>().followingCheck = 1
          : Get.find<FollowerController>().followingCheck = 0;

      await Get.find<FollowerController>()
          .getFollower(userId: GetStorage().read('id'), isFromRoute: true);
      await Get.find<FollowerController>()
          .getFollowing(userId: GetStorage().read('id'), isFromRoute: true);
      Get.find<FollowerController>().update();
    } else {
      // print("isOtherUserProfile else: " + GetStorage().read('id').toString());

      await Get.put(FollowerController());

      Get.find<FollowerController>().followingCheck = 0;

      Get.find<FollowerController>().update();

      widget.page == "followings"
          ? Get.find<FollowerController>().followingCheck = 1
          : Get.find<FollowerController>().followingCheck = 0;
      await Get.find<FollowerController>()
          .getFollower(userId: widget.id, isFromRoute: true);
      await Get.find<FollowerController>()
          .getFollowing(userId: widget.id, isFromRoute: true);
      Get.find<FollowerController>().update();
    }
  }

  @override
  Widget build(BuildContext context) {
    // return Container();
    return GetBuilder<FollowerController>(
      // init: FollowerController(),
      builder: (controller) {
        return DefaultTabController(
          length: 3,
          child: Scaffold(
            appBar: AppBar(
              elevation:kIsWeb?0:1,
              centerTitle: false,
              automaticallyImplyLeading: false,
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              title: Row(
                children: [
                  IconButton(
                    onPressed: kIsWeb
                        ? () {
                            // print("profile pr aya hai");
                            if (widget.newsfeedController.othersUserid > 0) {
                              // print("profile pr aya hai");
                            } else {
                              onProfileChange = true;
                            }

                            if (widget.newsfeedController.navRoute ==
                                "isProfileScreen") {
                              widget.newsfeedController.isProfileScreen = true;
                              widget.newsfeedController.isFollwerScreen = false;
                              widget.newsfeedController.update();
                            } else if (widget.newsfeedController.navRoute ==
                                'isOtherUserScreen') {
                              widget.newsfeedController
                                  .isOtherUserProfileScreen = true;
                              widget.newsfeedController.isFollwerScreen = false;
                              widget.newsfeedController.update();
                            } else if (widget.newsfeedController.navRoute ==
                                "isNewsFeedScreen") {
                              widget.newsfeedController.isNewsFeedScreen = true;
                              widget.newsfeedController.isFollwerScreen = false;
                              widget.newsfeedController.update();
                            }
                            Get.back();
                          }
                        : () {
                            Navigator.of(context).pop();
                          },
                    icon: Icon(
                      Icons.arrow_back_ios,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                    ),
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                  Text(
                    '${Strings.followers} & ${Strings.followings}',
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              bottom: TabBar(
                  controller: _tabController,
                  indicatorColor: widget.newsfeedController.displayColor,
                  indicatorWeight: 4,
                  indicatorSize: TabBarIndicatorSize.label,
                  isScrollable:true,

                  automaticIndicatorColorAdjustment: true,
                  labelColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  unselectedLabelColor: const Color(0xFF586976),
                  labelStyle: Styles.baseTextTheme.headline1.copyWith(
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 18 : 14,
                  ),
                  unselectedLabelStyle: Styles.baseTextTheme.headline2.copyWith(
                    fontWeight: FontWeight.w500,
                    fontSize: kIsWeb ? 18 : 14,
                  ),
                  tabs: controller.followingCheck == 1
                      ? <Tab>[
                          Tab(text: Strings.verifiedFollowers),
                          Tab(text: Strings.followings),
                          Tab(text: Strings.followers)
                        ]
                      : <Tab>[
                          Tab(text:Strings.verifiedFollowers),
                          Tab(text: Strings.followers),
                          Tab(text: Strings.followings)
                        ]),
            ),
            body: controller.followingCheck == 1
                ? TabBarView(
                    controller: _tabController,
                    children: [
                      VerifiedFollower(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                      FollowingWidget(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                      FollowerWidget(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                    ],
                  )
                : TabBarView(
                    controller: _tabController,
                    children: [
                      VerifiedFollower(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                      FollowerWidget(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                      FollowingWidget(
                        isOtherUserProfile: widget.isOtherUserProfile,
                        controller: controller,
                        newsfeedController: widget.newsfeedController,
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Future<bool> _onBackPressed(BuildContext context) async {
    // print("profile pr aya hai");
    if (widget.newsfeedController.othersUserid > 0) {
      // print("profile pr aya hai");
    } else {
      onProfileChange = true;
    }

    if (widget.newsfeedController.navRoute == "isProfileScreen") {
      widget.newsfeedController.isProfileScreen = true;
      widget.newsfeedController.isFollwerScreen = false;
      widget.newsfeedController.update();
    } else if (widget.newsfeedController.navRoute == 'isOtherUserScreen') {
      widget.newsfeedController.isOtherUserProfileScreen = true;
      widget.newsfeedController.isFollwerScreen = false;
      widget.newsfeedController.update();
    } else if (widget.newsfeedController.navRoute == "isNewsFeedScreen") {
      widget.newsfeedController.isNewsFeedScreen = true;
      widget.newsfeedController.isFollwerScreen = false;
      widget.newsfeedController.update();
    }

    return Future.value(true);
  }
}
