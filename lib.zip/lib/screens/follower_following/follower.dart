import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/network/controller/follower_following_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../models/profile.dart';
import '../../utils/colors.dart';
import '../../utils/fluro_router.dart';
import '../../utils/font.dart';
import '../../widgets/blue_tick.dart';

class FollowerWidget extends StatelessWidget {
  final FollowerController controller;
  final NewsfeedController newsfeedController;
  final isOtherUserProfile;

  const FollowerWidget(
      {Key key, this.controller, this.newsfeedController, this.isOtherUserProfile}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FollowerController>(builder: (controller) {
      return Scaffold(
        body: Center(
          child: controller.isLoading == true
              ? const CircularProgressIndicator(
                  color: MyColors.BlueColor,
                )
              : controller.followerList == null ||
                      controller.followerList.isEmpty
                  ? Text(Strings.noFollowers)
                  : ListView.separated(
                      separatorBuilder: (context, index) => const SizedBox(),
                      itemCount: controller.followerList.length,
                      itemBuilder: (context, index) {
                        controller.followerList[index].isFollow =
                            controller.followerList[index].follow;

                        return InkWell(
                          onTap: !kIsWeb
                              ? () async {
                            // if (Get.isRegistered<OtherUserController>()) {
                            //   Get.delete<OtherUserController>();
                            // }
                            // if (Get.isRegistered<FollowerController>()) {
                            //
                            //
                            //   Get.delete<FollowerController>();
                            // }
                            //
                            newsfeedController.otherUserId =
                                controller.followerList[index].followerId;
                            newsfeedController.otherUserName =
                                controller.followerList[index].username;

                            newsfeedController.update();
                            controller.update();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => OtherUsersProfile(
                                  controller: newsfeedController,
                                ),
                              ),
                            );

                            Get.find<NewsfeedController>().userInfo =
                                UserProfile();
                            Get.find<NewsfeedController>().userInfo =
                            await Get.find<NewsfeedController>()
                                .getOtherUserProfile(controller
                                .followerList[index].followerId);

                            await Get.find<OtherUserController>()
                                .filterUsersPostPagged("posts", page: 1);
                            Get.find<OtherUserController>()
                                .userPosts
                                .forEach((element) {
                              element.mute =
                                  Get.find<NewsfeedController>()
                                      .userInfo
                                      .muted;
                            });
                            Get.find<OtherUserController>().update();
                          }
                              : () async {
                            newsfeedController.otherUserId =
                                controller.followerList[index].followerId;
                            newsfeedController.otherUserName =
                                controller.followerList[index].username;

                            if (GetStorage().read('id') ==
                                controller
                                    .followerList[index].followerId) {
                              newsfeedController.isTrendsScreen = false;
                              newsfeedController.isNewsFeedScreen = false;
                              newsfeedController.isBrowseScreen = false;
                              newsfeedController.isNotificationScreen =
                              false;
                              newsfeedController.isChatScreen = false;
                              newsfeedController.isSavedPostScreen =
                              false;
                              newsfeedController.isPostDetails = false;
                              newsfeedController.isProfileScreen = true;
                              newsfeedController
                                  .isOtherUserProfileScreen = false;
                            } else {
                              /// idhr ana wapis
                              newsfeedController.isTrendsScreen = false;
                              newsfeedController.isNewsFeedScreen = false;
                              newsfeedController.isBrowseScreen = false;
                              newsfeedController.isNotificationScreen =
                              false;
                              newsfeedController.isChatScreen = false;
                              newsfeedController.isSavedPostScreen =
                              false;
                              newsfeedController.isPostDetails = false;
                              newsfeedController.isProfileScreen = false;
                              newsfeedController
                                  .isOtherUserProfileScreen = true;

                              newsfeedController.otherUserName =
                                  controller.followerList[index].name;
                              newsfeedController.otherUserId = controller
                                  .followerList[index].followerId;

                              // controller.isTrendsScreen = false;
                              // controller.isNewsFeedScreen = false;
                              // controller.isBrowseScreen = false;
                              // controller.isNotificationScreen = false;
                              // controller.isChatScreen = false;
                              // controller.isSavedPostScreen = false;
                              // controller.isPostDetails = false;
                              // controller.isProfileScreen = false;
                              // controller.isOtherUserProfileScreen = true;
                              // controller.isFilterScreen = false;
                              // controller.otherUserName = controller.filteredPeople[index].authorName;
                              // controller.otherUserId = controller.filteredPeople[index].userId;
                              // print("idhr aya hai  ");
                              Get.toNamed(FluroRouters.mainScreen +
                                  "/profile/" +
                                  newsfeedController.otherUserId
                                      .toString());
                              Get.find<NewsfeedController>().userInfo =
                                  UserProfile();
                              Get.find<NewsfeedController>().userInfo =
                              await newsfeedController
                                  .getOtherUserProfile(controller
                                  .followerList[index]
                                  .followerId);
                              await Get.find<OtherUserController>()
                                  .filterUsersPostPagged("posts",
                                  page: 1);
                              Get.find<OtherUserController>()
                                  .userPosts[0]
                                  .mute =
                                  Get.find<NewsfeedController>()
                                      .userInfo
                                      .muted;

                              Get.find<OtherUserController>()
                                  .userPosts
                                  .forEach((element) {
                                element.mute =
                                    Get.find<NewsfeedController>()
                                        .userInfo
                                        .muted;
                                // print("element.mute  ${element.mute}");
                              });

                              newsfeedController.update();
                            }
                            newsfeedController.update();
                            controller.update();
                          },
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              children: [
                                ListTile(

                                  contentPadding:
                                      const EdgeInsets.symmetric(vertical: 0, horizontal: 0),

                                  title: Column(
                                    children: [
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          CircleAvatar(
                                            radius: 25,
                                            foregroundImage: controller
                                                        .followerList[index]
                                                        .profileImage !=
                                                    null
                                                ? NetworkImage(controller
                                                    .followerList[index].profileImage)
                                                : const AssetImage(
                                                    'assets/images/person_placeholder.png'),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  Text(
                                                    controller.followerList[index].name,
                                                    style: Styles
                                                        .baseTextTheme.headline2
                                                        .copyWith(
                                                      color: Theme.of(context)
                                                                  .brightness ==
                                                              Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight: FontWeight.bold,
                                                      fontSize: 15,
                                                    ),
                                                  ),
                                                  controller.followerList[index]
                                                              .accountVerified ==
                                                          "verified"
                                                      ? Wrap(
                                                          children: [
                                                            const SizedBox(
                                                              width: 5,
                                                            ),
                                                            BlueTick(
                                                              height: 15,
                                                              width: 15,
                                                              iconSize: 12,
                                                            ),
                                                          ],
                                                        )
                                                     : const SizedBox(),
                                                ],
                                              ),
                                              // SizedBox(height: 5),
                                              FittedBox(
                                                fit: BoxFit.cover,
                                                child: Text(
                                                  "@${controller.followerList[index].username}",
                                                  style: Styles.baseTextTheme.headline2
                                                      .copyWith(
                                                    // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    // fontWeight: FontWeight.w500,
                                                    fontSize: kIsWeb ? 16 : 15,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          // Spacer(),
                                        ],
                                      ),
                                    ],
                                  ),
                                  trailing: SizedBox(
                                    width: 100,
                                    height: kIsWeb?35:30,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: newsfeedController
                                                  .storage
                                                  .read('userName') !=
                                              controller.followerList[index].username
                                          ? MaterialButton(
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(20),
                                            side:  BorderSide(color:
                                            Theme.of(context).brightness == Brightness.dark?
                                            !controller.followerList[index].follow?
                                            Colors.white:Colors.grey: !controller.followerList[index].follow?
                                            Colors.black:Colors.grey
                                            ),
                                          ),
                                              padding: const EdgeInsets.all(4),
                                              color: Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? !controller.followerList[index].follow
                                                      ? Colors.white
                                                      : Colors.black
                                                  : !controller.followerList[index].follow
                                                      ? Colors.black
                                                      : Colors.white,
                                              onPressed: () async {


                                                if (controller
                                                        .followerList[index].follow ==
                                                    false) {
                                                  controller.followerList[index].follow =
                                                      true;

                                                  controller.update();
                                                  await newsfeedController.addFollowing(
                                                      controller.followerList[index].id,
                                                      "follow");
                                                  controller.update();
                                                  // newsfeedController.update();
                                                } else if (controller
                                                        .followerList[index].follow ==
                                                    true) {
                                                  controller.followerList[index].follow =
                                                      false;
                                                  controller.update();
                                                  await newsfeedController.addFollowing(
                                                      controller.followerList[index].id,
                                                      "unFollow");
                                                  controller.update();
                                                }
                                                // print(
                                                //     "${controller.followerList[index].username}");
                                                // print(
                                                //     "${controller.followerList[index].id}");

                                              },
                                              child: Text(
                                                  !controller.followerList[index].follow
                                                      ? "${Strings.follow}"
                                                          .capitalizeFirst
                                                      :   Strings.following,
                                                  style: TextStyle(
                                                      fontSize: 14,
                                                      color:
                                                          Theme.of(context).brightness ==
                                                                  Brightness.dark
                                                              ? !controller.followerList[index].follow
                                                                  ? Colors.black
                                                                  : Colors.white
                                                              : !controller
                                                                      .followerList[index]
                                                                      .follow
                                                                  ? Colors.white
                                                                  : Colors.black,
                                                      fontWeight: FontWeight.bold)))
                                          : const SizedBox(),
                                    ),
                                  ),
                                ),
                                controller.followerList[index].bio==null?const SizedBox()
                                    :Align(
                                  alignment: Alignment.topLeft,
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 60,right: 0),
                                    child: Text(controller.followerList[index].bio ,
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 2,
                                        style: TextStyle(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400,
                                            color: Theme.of(context).brightness == Brightness.dark
                                                ? Colors.white
                                                : Colors.black
                                        )
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
        ),
      );
    });
  }
}
