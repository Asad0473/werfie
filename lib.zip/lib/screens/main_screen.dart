import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_sharing_intent/flutter_sharing_intent.dart';
import 'package:flutter_sharing_intent/model/sharing_file.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
// import 'package:receive_sharing_intent/receive_sharing_intent.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/main.dart';
import 'package:werfieapp/models/languages.dart';
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/bottom_nav_screen.dart';
import 'package:werfieapp/screens/login_screen.dart';
import 'package:werfieapp/screens/session.dart';
import 'package:werfieapp/web_views/web_main_screen.dart';

import '../helper/world_noor_helper/MethodChannelWorldNoor.dart';
import '../models/create_post_model/create_post_model.dart';
import '../models/profile.dart';
import '../network/controller/browse_controller.dart';
import '../network/controller/notification_controller.dart';
import '../network/controller/profile_controller.dart';
import '../network/singleTone.dart';
import '../utils/strings.dart';
import '../utils/utils_methods.dart';
import '../video_call/utilities/video_call_utilities.dart';
import 'create_post_mobile.dart';

// ignore: must_be_immutable
class MainScreen extends StatefulWidget {
  String postId;
  String profileId;
  String page;
  String extra;
  // bool isFromSignUp;
  Map<String, dynamic> params;

  bool isLoggedInFromPosh = false;
  bool isFromPosh = false;
  String poshID;
  String WNToken;


  MainScreen({this.postId, this.profileId, this.page, this.extra,this.params,this.isFromPosh = false, this.poshID, this.WNToken,this.isLoggedInFromPosh = false});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> with WidgetsBindingObserver {
  String userName;

  String postId;

  String profileId;

  final storage = GetStorage();
  SharedPreferences shared;

  // NewsfeedController controller = Get.put(NewsfeedController());
  StreamSubscription _intentDataStreamSubscription;

  var loginController=Get.find<LoginController>();


  @override
  void initState() {
    // debugPrint('Welcome Message Showing 1 ${loginController.isShowWelcomeMsg}');

    if(loginController.isShowWelcomeMsg==true){
      UtilsMethods.toastMessageShow(
          Color(0xFF2769d9),
          Color(0xFF2769d9),
          Color(0xFF2769d9),
          message:Get.find<NewsfeedController>().userName!=null? "${Strings.welcomeToWerfie} '${Get.find<NewsfeedController>().userName}'":Strings.welcomeToWerfie);

    }


    WidgetsBinding.instance.addObserver(this);
    // profileId = Get.arguments["profileId"];
    call(context);

    userName = storage.read("userName");
    // print(" userName hai yahan pr  $userName");
    getMessageNotificationCount();

    // print('HERE IN ELSE CONDITION'+profileId.toString()+'HERE IN ELSE CONDITION');
    // if(profileId!=null){
    //
    //   // Go to profile route with ID
    //   Get.to(ProfileScreen(controller: Get.find<NewsfeedController>(),),arguments: {
    //     "userName": userName,
    //     "profileId": profileId != null ? profileId : null
    //   });
    //
    // }

    super.initState();
    loginController.updateInitialWelcomeMsg(false);

    if(!kIsWeb && (Platform.isAndroid /*|| Platform.isIOS*/)) {
      getDataFromWorldNoorApp();
    }

  }

  /* //All listeners to listen Sharing media files & text
  void listenShareMediaFiles(BuildContext context) {
    // For sharing images coming from outside the app

    // while the app is in the memory
    ReceiveSharingIntent.getMediaStream().listen((List<SharedMediaFile> value) {
      navigateToShareMedia(context, value);
    }, onError: (err) {
      debugPrint("$err");
    });

    // For sharing images coming from outside the app while the app is closed
    ReceiveSharingIntent.getInitialMedia().then((List<SharedMediaFile> value) {
      navigateToShareMedia(context, value);
    });

    // For sharing or opening urls/text coming from outside the app while the app is in the memory
    ReceiveSharingIntent.getTextStream().listen((String value) {
      navigateToShareText(context, value);
    }, onError: (err) {
      debugPrint("$err");
    });

    // For sharing or opening urls/text coming from outside the app while the app is closed
    ReceiveSharingIntent.getInitialText().then((String value) {
      navigateToShareText(context, value);
    });
  }

  void navigateToShareMedia(BuildContext context, List<SharedMediaFile> value) {


    if (value.isNotEmpty) {
      var newFiles = <File>[];
      value.forEach((element) {
        newFiles.add(File(
          Platform.isIOS
              ? element.type == SharedMediaType.FILE
              ? element.path
              .toString()
              .replaceAll("file://", "")
              : element.path
              : element.path,
        ));
      });

      NewsfeedController newFeedController =Get.find<NewsfeedController>();
      newFeedController.modelList2 = [];
      newFeedController.modelList2.add(ModelClass.fromJson({
        'body': '',
        'poll_ques_first': null,
        'poll_ques_first': null,
        'poll_ques_third': null,
        'poll_ques_fourth': null,
        //  selectType: "Public",
        'files': [],
        'link_meta': '',
        'link': '',
        'link_image': '',
        'link_title': '',
        'days': '',
        'minutes': '',
        'hours': '',
        'location': '',
        'lat': '',
        'lng': '',
        'poll_thread': false,
        'type': newFeedController.modelList2.length < 2
            ? 'post'
            : 'thread'
      }));



      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (BuildContext context) =>
              CreatePostMobile(newFeedController*/ /*,sharedMediaFiles: value*/ /*),
        ),
      );




    }
  }

  void navigateToShareText(BuildContext context, String value) {
    if (value != null && value.toString().isNotEmpty) {

    }
  }*/
  Future<void> call(BuildContext context) async {
    /* if (widget.initialLink != null) {
      final Uri deepLink = widget.initialLink.link;
      Fluttertoast.showToast(
          msg: deepLink.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.TOP,
          timeInSecForIosWeb: 5);
      FirebaseDynamicLinks.instance.onLink.listen((dynamicLinkData) {
        Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => ProfileScreen(
                controller: Get.isRegistered<NewsfeedController>()
                    ? Get.put(NewsfeedController())
                    : Get.find<NewsfeedController>(),
                profileId: "429")));
        // Navigator.pushNamed(context, dynamicLinkData.link.path);
      }).onError((error) {
        // Handle errors
      });
      // Example of using the dynamic link to push the user to a different screen
      // Navigator.pushNamed(context, ProfileScreen());
      Get.to(() =>  ProfileScreen(
          controller: Get.isRegistered<NewsfeedController>()
              ? Get.put(NewsfeedController())
              : Get.find<NewsfeedController>(),
          profileId: "429"));
      // Navigator.of(context).push(MaterialPageRoute(
      //     builder: (context) => ProfileScreen(
      //         controller: Get.isRegistered<NewsfeedController>()
      //             ? Get.put(NewsfeedController())
      //             : Get.find<NewsfeedController>(),
      //         profileId: "429")));
    }*/
    shared = await SharedPreferences.getInstance();
    // print("yes token print");


    Future.delayed(Duration(milliseconds: 1000), () async {
      // print("put start");

      // Future.delayed(Duration(seconds: 2), () async {
      // Get.offAllNamed(AppRoute.mainScreen,arguments: {
      //   "userName": shared.getString("userName"),
      //   "postId": postId != null ? postId : null,
      //   "profileId": profileId != null ? profileId : null,
      // });
      // Future.delayed(Duration(seconds: 3), () {
      // if (Get.isRegistered<NewsfeedController>()) {
      // print('i am here in if session controller');
      /*  if (kIsWeb) {
          print("changeeeee");
          // Get.offAllNamed(FluroRouters.mainScreen);
          context.go(AppRoute.mainScreen);

        } else {
          // if(widget.profileId!=null){
          //   print('HERE IN ELSE CONDITION'+widget.profileId.toString());
          //   // Go to profile route with ID
          //   Get.to(MobileProfileScreen(),arguments: {
          //     "userName": shared.getString("userName"),
          //     "profileId": widget.profileId != null ? widget.profileId : null
          //   });
          //
          // }
          // else{
          Get.offAll(MainScreen(), arguments: {
            "userName": shared.getString("userName"),
            "postId": widget.postId != null ? widget.postId : null,
            "profileId": widget.profileId != null ? widget.profileId : null
          });
        }*/
      // }
      // }
      // else {
      //   // print('i am here in else session controller');
      //   // Get.put(NewsfeedController(
      //   //   linkId: postId != null ? postId : null,
      //   //   profileId: profileId != null ? profileId : null,
      //   // ));
      //   if (kIsWeb) {
      //     Routemaster.of(context)
      //         .replace(AppRoute.mainScreen, queryParameters: {
      //       "userName": shared.getString("userName"),
      //       "postId": widget.postId != null ? widget.postId : null,
      //       "profileId": widget.profileId != null ? widget.profileId : null
      //     });
      //   } else {
      //
      //     if(widget.profileId!=null){
      //       // Go to profile route with ID
      //       Get.to(MobileProfileScreen(),arguments: {
      //         "userName": shared.getString("userName"),
      //         "profileId": widget.profileId != null ? widget.profileId : null
      //       });
      //
      //     }else{
      //     Get.offAll(MainScreen(), arguments: {
      //       "userName": shared.getString("userName"),
      //       "postId": widget.postId != null ? widget.postId : null,
      //       "profileId": widget.profileId != null ? widget.profileId : null
      //     });}
      //   }
      //   // Get.offAll(MainScreen(
      //   //   userName: shared.getString("userName"),
      //   //   postId: widget.postId != null ? widget.postId : null,
      //   //   profileId: widget.profileId != null ? widget.profileId : null,
      //   // ));
      // }

      Get.put(NewsfeedController(
        linkId: widget.postId != null ? widget.postId : null,
        profileId: widget.profileId != null ? widget.profileId : null,
      ));
     // print("newsfeed Controller is put here");
      // print("put end");
     Get.find<NewsfeedController>().languageData =
     await Get.find<NewsfeedController>().getLanguages();
     if(kIsWeb) {
       String userData = storage.read("user_profile");
       // print(storage.read('token')+" user data"+userData);
       // print('================================================');
       // print(userData);
       if (userData != null) {
         Get
             .find<NewsfeedController>()
             .userProfile =
             UserProfile.fromJson(jsonDecode(userData));
         Get
             .find<NewsfeedController>()
             .userProfile
             .username =
             storage.read("user_name");
         Get
             .find<NewsfeedController>()
             .userProfile
             .notificationAllowed =
             storage.read("notificationAllowed");
       }


       if (userData != null && Get
           .find<NewsfeedController>()
           .userProfile
           .notificationAllowed == 1) {
         Get
             .find<NewsfeedController>()
             .notificationStatus = true;
       } else {
         Get
             .find<NewsfeedController>()
             .notificationStatus = false;
       }
       Get.find<NewsfeedController>().update();
     }

      Get.find<NewsfeedController>().selectedAppLanguageInfoId =
          Get.find<NewsfeedController>().languageData.appLang.id;

      Get.find<NewsfeedController>().upDateLocale(
          Get.find<NewsfeedController>().languageData.appLang.code);

      int index =
          Get.find<NewsfeedController>().languagesList.indexWhere((element) {
        return Get.find<NewsfeedController>().languageData.appLang.id ==
            element.id;
      });

      int index2 = Get.find<NewsfeedController>()
          .translationLanguage
          .indexWhere((element) {
        return Get.find<NewsfeedController>().languageData.myLang.id ==
            element.id;
      });

      Get.find<NewsfeedController>().dropdownValue =
          Get.find<NewsfeedController>().languagesList[index];

      Get.find<NewsfeedController>().dropdownValue1 =
          Get.find<NewsfeedController>().translationLanguage[index2];

      // Get.find<NewsfeedController>().update();
      if (Get.find<NewsfeedController>().languageData != null) {
        Get.find<NewsfeedController>().isAutoTranslate =
            Get.find<NewsfeedController>()
                        .languageData
                        .autoTranslateSettings
                        .autoTranslate ==
                    1
                ? true
                : false;
        Get.find<NewsfeedController>().selectedLanguage =
            Get.find<NewsfeedController>().languageData.myLang;
      }

      Future.delayed(Duration.zero, () {
        // listenShareMediaFiles(context);
      });
      // print('CALL SHARED INIT WITH ID');
      // });

      // Get.delete<SessionController>();
      // });

      // For sharing images coming from outside the app while the app is in the memory
      _intentDataStreamSubscription = FlutterSharingIntent.instance
          .getMediaStream()
          .listen((List<SharedFile> value) {
        navigateToShareMedia(context, value);
        print("Shared: getMediaStream ${value.map((f) => f.value).join(",")}");
      }, onError: (err) {
        print("getIntentDataStream error: $err");
      });

      // For sharing images coming from outside the app while the app is closed
      FlutterSharingIntent.instance
          .getInitialSharing()
          .then((List<SharedFile> value) {
        navigateToShareMedia(context, value);
        print("Shared: getInitialMedia ${value.map((f) => f.value).join(",")}");
      });
    });
    if(!kIsWeb) {
      if (Platform.isIOS)
        MethodChannelWorldNoor.instance.configureChannel();
    }

  }

  void navigateToShareMedia(BuildContext context, List<SharedFile> value) {
    if (value != null && value.isNotEmpty) {
      if (value.isNotEmpty && value.first.type == SharedMediaType.image ||
          value.first.type == SharedMediaType.video || value.first.type == SharedMediaType.url) {
        NewsfeedController newFeedController = Get.find<NewsfeedController>();
        newFeedController.modelList2 = [];
        newFeedController.modelList2.add(ModelClass.fromJson({
          'body': '',
          'poll_ques_first': null,
          'poll_ques_first': null,
          'poll_ques_third': null,
          'poll_ques_fourth': null,
          //  selectType: "Public",
          'files': [],
          'link_meta': '',
          'link': '',
          'link_image': '',
          'link_title': '',
          'days': '',
          'minutes': '',
          'hours': '',
          'location': '',
          'lat': '',
          'lng': '',
          'poll_thread': false,
          'type': newFeedController.modelList2.length < 2 ? 'post' : 'thread'
        }));

        if(value.first.type == SharedMediaType.url){
          if(value.first.value.toLowerCase().contains("https://werfie.com/home/") || value.first.value.toLowerCase().trim().startsWith('werfie.com')){
            return;
          }
        }
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) =>
                CreatePostMobile(newFeedController, sharedMediaFiles: value),
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _intentDataStreamSubscription.cancel();
    super.dispose();
  }

  getMessageNotificationCount() async {
    final sharedPrefs = await SharedPreferences.getInstance();
    if (sharedPrefs.containsKey('messageCount')) {
      messageNotifications.value = await sharedPrefs.getInt('messageCount');
      messageNotifications.refresh();
    } else {
      sharedPrefs.setInt('messageCount', 0);
      messageNotifications.value = 0;
      messageNotifications.refresh();
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    if (state == AppLifecycleState.resumed) {
      final sharedPrefs = await SharedPreferences.getInstance();
      await sharedPrefs.reload();
      messageNotifications.value = await sharedPrefs.getInt('messageCount');
      if (messageNotifications.value == null) {
        messageNotifications.value = 0;
      }
      messageNotifications.refresh();
      // Fluttertoast.showToast(msg: "Resume ");
      if (!kIsWeb) VideoCallUtilities.checkBackgroundCall();
    } else {
      print(state.toString());
    }
  }

  // final userName =Get.arguments != null ? Get.arguments["userName"]:null;
  @override
  Widget build(BuildContext context) {
    // Map arguments = ModalRoute.of(context).settings.arguments as Map;
    // print( arguments['userName']);
    // String someResult = arguments['userName'];
    // print(someResult);

    // print(" userName hai yahan prr  ${storage.read("userName")}");
    // profileId = Get.arguments["profileId"];
    // if (profileId != null) {
    //   print('POST ID I HA MAINSCREEN' + postId);
    // } else if (profileId != null) {
    //   // print('PROFILE ID I HA MAINSCREEN' + profileId);
    // } else {}
    // return Obx((){

    return GetBuilder<NewsfeedController>(builder: (controller) {
      return Scaffold(
        body: Responsive(
          mobile: MediaQuery.of(context).size.width >= 500
              ? WebMainScreen(
                  userName: storage.read("userName"),
                  controller: controller,
                  page: widget.page,
                  extra: widget.postId,
                  params: widget.params,
                  isFromPosh: widget.isFromPosh,
            poshID: widget.poshID,
            WNToken: widget.WNToken,
                )
              : BottomNavScreen(),
          tablet: kIsWeb
              ? WebMainScreen(
                  userName: storage.read("userName"),
                  controller: controller,
                  page: widget.page,
                  extra: widget.postId,
                  params: widget.params,
            isFromPosh: widget.isFromPosh,
            poshID: widget.poshID,
            WNToken: widget.WNToken,
                )
              : BottomNavScreen(),

          // NewsFeedMobile(
          //   controller: controller,
          // ),
          desktop:
              // GuestUserMainScreen()
              WebMainScreen(
            userName: storage.read("userName"),
            controller: controller,
            page: widget.page,
            extra: widget.postId,
            params: widget.params,
                isFromPosh: widget.isFromPosh,
                poshID: widget.poshID,
                WNToken: widget.WNToken,
          ),
        ),
      );
    });
  }



  Future<Map<String, dynamic>> getDataFromWorldNoorApp() async {
    const platform = const MethodChannel('worldnoor');

    var extraData;
    Map<String, dynamic> dataFromWorldNoorApp;
    try {
      final String result =
      await platform.invokeMethod('readDataFromWorldNoor');
      extraData = result;
      dataFromWorldNoorApp = json.decode(extraData);
      // print("<=========== isLoggedInFromPosh ==============>");
      print(widget.isLoggedInFromPosh);
      if(dataFromWorldNoorApp != null && dataFromWorldNoorApp.isNotEmpty && dataFromWorldNoorApp["isAutoLogin"] as bool && widget.isLoggedInFromPosh == false){
        if(shared.getString("userName") != dataFromWorldNoorApp['email'] && (storage.read("email") as String ?? "") != dataFromWorldNoorApp['email'])
          showDialogLoginWithPosh(context,dataFromWorldNoorApp["name"],dataFromWorldNoorApp["profilePic"]);
      }

    } on PlatformException catch (e) {
      extraData = "Failed to get data: '${e.message}'.";
    }

    return dataFromWorldNoorApp;
  }


  showDialogLoginWithPosh(BuildContext context,String poshName, String profilePicUrl){
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Login with WorldNoor', style: TextStyle(fontSize: 18,color: Colors.black,fontWeight: FontWeight.bold),),
          content: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(35),
                child: FadeInImage(
                  fit: BoxFit.cover,
                  width: 50,
                  height: 50,
                  placeholder: AssetImage(
                      'assets/images/person_placeholder.png'),
                  image: NetworkImage(profilePicUrl !=
                      null
                      ? profilePicUrl
                      : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Expanded(child: RichText(
                text: TextSpan(
                  text: 'You are currently logged in with ',
                  style: TextStyle(fontSize: 14,color: Colors.black),
                  children: <TextSpan>[
                    TextSpan(text: userName, style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16)),
                    TextSpan(text: ". Do you want to stay logged in with this account or switch to WorldNoor Account ",style: TextStyle(fontSize: 14),),
                    TextSpan(text: poshName, style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16)),
                    TextSpan(text: " ?",style: TextStyle(fontSize: 14),),

                  ],
                ),
              )),
              //Expanded(child: Text('You are currently logged in with ${userName} account. Do you want to stay logged in with this account or switch to WorldNoor Account :  $poshName?')),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                // Close the dialog
                Navigator.of(context).pop();
              },
              child: Text('Close'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop();

                  SharedPreferences preferences =
                  await SharedPreferences.getInstance();
                  if (preferences.getBool('socialLogin') == true) {
                    print('social logout');
                    UtilsMethods utils = UtilsMethods();
                    utils.signOutGoogle();

                    await preferences.clear();
                    await preferences.remove("userName");
                    await preferences.remove("id");
                    await Get.find<NewsfeedController>().storage.erase();

                    Get.delete<SessionController>();
                    Get.delete<NewsfeedController>();
                    Get.delete<ProfileController>();
                    Get.delete<BrowseController>();
                    Get.delete<NotificationController>();
                    preferences.setBool('guestUser', true);
                    SingleTone.instance.socialLogin = false;

                      Get.offUntil(
                          MaterialPageRoute(
                              builder: (context) => LoginScreen(isFromWorldNoorApp: 1,)),
                              (route) => false);

                  } else {
                    print('else logout');

                    await preferences.clear();
                    await preferences.remove("userName");
                    await preferences.remove("id");
                    await Get.find<NewsfeedController>().storage.erase();

                    Get.delete<SessionController>();
                    Get.delete<NewsfeedController>();
                    Get.delete<ProfileController>();
                    Get.delete<BrowseController>();
                    Get.delete<NotificationController>();

                    preferences.setBool('guestUser', true);
                    SingleTone.instance.socialLogin = false;

                      Get.offUntil(
                          MaterialPageRoute(
                              builder: (context) => LoginScreen(isFromWorldNoorApp: 1,)),
                              (route) => false);

                  }


              },
              child: Text('Login with WorldNoor'),
            ),
          ],
        );
      },
    );
  }

}
