

// ignore: must_be_immutable
// class ReplyCommentScreenMobile extends StatelessWidget {
//   final int commentId;
//   Post post;
//   final int postIndex;
//   final int commentIndex;
//   var newsFeedController = Get.find<NewsfeedController>();
//   ReplyCommentScreenMobile(
//       this.commentId, this.postIndex, this.post, this.commentIndex,this.newsFeedController);
//
//   final DummyData dataController = Get.find();
//   final viewInsets = EdgeInsets.fromWindowPadding(
//       WidgetsBinding.instance.window.viewInsets,
//       WidgetsBinding.instance.window.devicePixelRatio);
//
//
//   // final commentController = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     final bool isKeyboard = MediaQuery.of(context).viewInsets.bottom == 0.0;
//     return GetBuilder<MobileCommentsController>(
//         // init: MobileCommentsController(),
//         builder: (controller) {
//       return Scaffold(
//         appBar: AppBar(
//           iconTheme: IconThemeData(
//               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black
//           ),
//           backgroundColor: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
//           title: Text(
//             Strings.replyToComment,
//             style: Styles.baseTextTheme.headline2.copyWith(
//               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//               fontWeight: FontWeight.bold,
//             ),
//           ),
//         ),
//         body: Column(
//           children: [
//             Padding(
//               padding: const EdgeInsets.only(
//                 top: 20.0,
//                 left: 20,
//                 right: 20,
//               ),
//               child: Column(
//                 children: [
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       CircleAvatar(
//                         backgroundImage: post.comments[commentIndex].author.profileImage != null
//                             ? NetworkImage(
//                                 post.comments[commentIndex].author.profileImage)
//                             : AssetImage(
//                                 'assets/images/person_placeholder.png'),
//                         radius: 12,
//                       ),
//                       SizedBox(width: 6),
//                       Text(post.authorName,
//                         style: Styles.baseTextTheme.headline2.copyWith(
//                           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                           fontWeight: FontWeight.w500,
//                           fontSize: 14,
//                         ),
//                         ),
//                       SizedBox(width: 6),
//                       Text(Strings.replied,
//                         style: Styles.baseTextTheme.headline4.copyWith(
//                           //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                           fontSize: kIsWeb ? 14 : 12,
//                         ),),
//                       SizedBox(width: 12),
//                       Expanded(
//                         child:
//                             Text(post.comments[commentIndex].commentedTimeAgo,
//                               style:Styles.baseTextTheme.headline2.copyWith(
//                                 //color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                 fontSize: kIsWeb ? 14 : 12,
//                               ),),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 4),
//                   Padding(
//                     padding: const EdgeInsets.only(left: 16.0),
//                     child: ClipRRect(
//                       borderRadius: BorderRadius.circular(80),
//                       child: Container(
//                         padding:
//                             EdgeInsets.symmetric(vertical: 8, horizontal: 12),
//                         width: double.infinity,
//                         height: 40,
//                         decoration: ShapeDecoration(
//                           color: Colors.grey,
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(20),
//                           ),
//                         ),
//                         child: Text(
//                           post.comments[commentIndex].body,
//                           style: Theme.of(context).brightness == Brightness.dark ?
//                           TextStyle(color: Colors.white,
//                           )
//                               : TextStyle(color: Colors.black,
//                           ),
//                           // dataController.posts[postIndex]['comments'][commentIndex]
//                           //     ['commentText'],
//                         ),
//                       ),
//                     ),
//                   ),
//                   post.comments[commentIndex].replies == null
//                       ? SizedBox()
//                       : Container(
//                           // height: Get.height / 1.5,
//                           child: SingleChildScrollView(
//                             child: post.comments[commentIndex].replies.length >
//                                     0
//                                 ? Column(
//                                     children: List.generate(
//                                         post.comments[commentIndex].replies
//                                             .length, (ind) {
//                                       return Column(
//                                         crossAxisAlignment:
//                                             CrossAxisAlignment.start,
//                                         children: [
//                                           Padding(
//                                             padding: const EdgeInsets.only(
//                                                 left: 22, right: 22, top: 12),
//                                             child: ClipRRect(
//                                               borderRadius:
//                                                   BorderRadius.circular(80),
//                                               child: Container(
//                                                 padding: EdgeInsets.symmetric(
//                                                     vertical: 8,
//                                                     horizontal: 12),
//                                                 width: double.infinity,
//                                                 height: 40,
//                                                 decoration: ShapeDecoration(
//                                                   color: Colors.grey,
//                                                   shape: RoundedRectangleBorder(
//                                                     borderRadius:
//                                                         BorderRadius.circular(
//                                                             20),
//                                                   ),
//                                                 ),
//                                                 child: Align(
//                                                   alignment:
//                                                       Alignment.centerLeft,
//                                                   child: Text(
//                                                     post.comments[commentIndex]
//                                                         .replies[ind].body,
//                                                     style: Styles.baseTextTheme.headline4.copyWith(
//                                                       color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                       fontWeight: FontWeight.w500,
//                                                       fontSize: 14,
//                                                     ),
//                                                   ),
//                                                 ),
//                                               ),
//                                             ),
//                                           ),
//                                           SizedBox(height: 6),
//                                           post.comments[commentIndex].author.username != Get.find<NewsfeedController>()
//                                                       .storage
//                                                       .read('userName')
//                                               ? SizedBox()
//                                               : InkWell(
//                                                   onTap: () async {
//                                                     print(
//                                                         "delete comment pressed");
//                                                     await Get.find<
//                                                             NewsfeedController>()
//                                                         .deleteComment(post
//                                                             .comments[
//                                                                 commentIndex]
//                                                             .replies[ind]
//                                                             .id);
//                                                   },
//                                                   child: Padding(
//                                                     padding:
//                                                         const EdgeInsets.only(
//                                                       left: 22,
//                                                       right: 22,
//                                                     ),
//                                                     child: Text(Strings.delete,
//                                                       style: Styles.baseTextTheme.headline4.copyWith(
//                                                         color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                                         fontSize: kIsWeb ? 14 : 12,
//                                                       ),),
//                                                   ),
//                                                 ),
//                                         ],
//                                       );
//                                     }),
//                                   )
//                                 : Container(),
//                           ),
//                         )
//                 ],
//               ),
//             ),
//             Spacer(),
//
//
//
//             !controller.mentionTag
//                 ? SizedBox()
//                 :Align(
//                   alignment: Alignment.centerLeft,
//                   child: Container(
//                     decoration:
//                     BoxDecoration(
//
//                       color:Colors.white,
//                       border: Border.all(
//                         color: Colors.grey[300],
//                         width: 0.5,
//                       ),
//                       borderRadius:
//                       BorderRadius
//                           .circular(
//                           4),
//                     ),
//                     height: 150,
//                     width: 300,
//                     child: newsFeedController.tags.length ==
//                         0
//                         ? SpinKitWave(
//                       size: 30,
//                       color: Color(
//                           0xFFedab30),
//                     )
//                         : ListView
//                         .builder(
//                         itemCount: newsFeedController.tags.length,
//                         itemBuilder:
//                             (context,
//                             index) {
//                           return ListTile(
//                             onTap:
//                                 () async {
//                               //   temp='';
//                               // print("textvalue " + _controller[controller.currentIndexText].text);
//                               // print(temp);
//                               print(newsFeedController.tags[index]['title']);
//
//                               /*     _controller[controller.currentIndexText].text =
//                                                                   _controller[controller.currentIndexText].text.replaceAll(temp, "")+
//                                                                  ' ' +
//                                                                       widget.tags[index]['title'];*/
//                               newsFeedController.tempValue = newsFeedController.tempValue.substring(0, newsFeedController
//                                   .tempValue.length - newsFeedController.temp.length);
//
//                               newsFeedController.tempValue = newsFeedController. tempValue + ' ' + newsFeedController.tags[index]['title'];
//
//
//
//                               newsFeedController.commentController.text ="";
//
//                               newsFeedController.commentController.text =   newsFeedController.tempValue;
//                               // tempValue="";
//                               newsFeedController.commentController.selection = TextSelection.fromPosition(TextPosition(offset:  newsFeedController.commentController.text.length));
//                               // widget.focusNode
//                               //     .requestFocus();
//                               print('selection tag  ${  newsFeedController.commentController.selection}');
//                               print('value temp${  newsFeedController.commentController.text}');
//
//                               controller.mentionTag =
//                               false;
//                               controller.update();
//
//                               //  widget.tags = [];
//                               controller.update();
//                             },
//                             title:
//                             Text(
//                               newsFeedController.tags[index]['title'],
//                               style:
//                               Styles.baseTextTheme.headline2.copyWith(
//                                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                                 fontWeight: FontWeight.w700,
//                                 fontSize: 15,
//                               ),
//                             ),
//                           );
//                         }),
//                   ),
//                 ),
//
//             Container(
//               height: 50,
//               child: ListTile(
//                 contentPadding: EdgeInsets.only(
//                   left: Platform.isIOS ? 20 : 10,
//                   right: Platform.isIOS ? 20 : 10,
//                   bottom: isKeyboard ? 0 : viewInsets.bottom,
//                 ),
//                 // tileColor: Colors.white,
//                 // selectedTileColor: Colors.white,
//                 // focusColor: Colors.white,
//                 leading: controller.controller.userProfile == null
//                     ? Container(
//                         width: 24,
//                         child: Center(
//                           child: SpinKitCircle(
//                             color: Colors.grey,
//                             size: 40,
//                           ),
//                         ))
//                     : controller.controller.userProfile.profileImage == null
//                         ? CircleAvatar(
//                             radius: 12,
//                             backgroundImage: AssetImage(
//                                 "assets/images/person_placeholder.png"))
//                         : ClipRRect(
//                             borderRadius: BorderRadius.circular(40),
//                             child: FadeInImage(
//                                 fit: BoxFit.cover,
//                                 width: 24,
//                                 height: 24,
//                                 placeholder: AssetImage(
//                                     'assets/images/person_placeholder.png'),
//                                 image: NetworkImage(controller.controller
//                                             .userProfile.coverImage !=
//                                         null
//                                     ? controller
//                                         .controller.userProfile.profileImage
//                                     : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
//                           ),
//                 title: HashTagTextField(
//                   // style:Theme.of(context).brightness == Brightness.dark ?
//                   // TextStyle(color: Colors.white,
//                   //   fontWeight: FontWeight.normal,
//                   // )
//                   //     : TextStyle(color: Colors.black,
//                   //   fontWeight: FontWeight.normal,
//
//           cursorColor:Theme.of(context).brightness == Brightness.dark ?Colors.white:Colors.black ,
//                   controller: newsFeedController.commentController,
//                   // style: Theme.of(context).textTheme.bodyText1,
//                   // style: Theme.of(context).textTheme.bodyText1,
//                   // style: LightStyles.baseTextTheme.headline2.copyWith(
//                   //    color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
//                   //   //fontWeight: FontWeight.w500,
//                   //   // fontSize: 16,
//                   // ),
//                   decoration: InputDecoration(
//                     contentPadding: const EdgeInsets.only(left: 20 ,top: 15 , right: 10),
//                     border: OutlineInputBorder(
//                       borderSide: BorderSide(color: Colors.grey,width: 1),
//                       borderRadius:  BorderRadius.circular(30),
//                     ),
//                     fillColor: Colors.grey[250],
//                     filled: true,
//                     focusColor: Colors.grey[250],
//                     hintText: Strings.leaveAComment,
//                     hintStyle: LightStyles.baseTextTheme.headline3,
//                   ),
//
//                   onChanged: (value) async{
//
//
//
//                     newsFeedController.tempValue = value;
//                     print('change value $value');
//                     // print(getHashTags(value));
//
//
//
//
//                     // if (value.length > 0 && widget.commentTextController.text.trim().isNotEmpty)
//
//
//                     if (value.length < 2) {
//                       /// user tag and mention tag
//                       newsFeedController.mentionUser = false;
//                       controller.mentionTag = false;
//                       newsFeedController.temp = '';
//                       newsFeedController.tempUsername = '';
//                       newsFeedController.tags.clear();
//
//                       /// end
//                       // visibility = true;
//
//                       controller.update();
//
//                       newsFeedController.update();
//                       // setState(() {});
//                     }
//
//                     /// user # tag and @ mention user
//                     if (value.length >
//                         0) {
//                       int tempLength = 0;
//                       //  temp='';
//                       // tempUsername = '';
//                       ///hash tag
//                       if (value[value
//                           .length -
//                           1] ==
//                           '#') {
//                         // temp = '';
//                         print(
//                             'if  ${value[value.length - 1]}');
//                         newsFeedController.temp = value[
//                         value.length -
//                             1];
//                         print('1  # : ' +
//                             newsFeedController. temp);
//                       } else if (newsFeedController.temp !=
//                           '' &&
//                           value[value.length -
//                               1] !=
//                               ' ') {
//                         // temp = '';
//                         print(
//                             'if else value ${value[value.length - 1]}');
//
//                         newsFeedController.temp = newsFeedController.temp +
//                             value[value
//                                 .length -
//                                 1];
//                         print('2  # : ' +
//                             newsFeedController. temp);
//                       } else if (value[
//                       value.length -
//                           1] ==
//                           ' ') {
//                         print('3   # :' +
//                             newsFeedController .temp);
//                         newsFeedController.temp = '';
//                         newsFeedController.mentionUser =
//                         false;
//                         controller. mentionTag = false;
//
//                         controller.update();
//                       }
//                       if (newsFeedController.temp.length > 1) {
//                         print('temp value # : ' +newsFeedController. temp);
//                         newsFeedController.tags.clear();
//                         print('hashtag temp value :${newsFeedController.temp}');
//
//                         newsFeedController.tags = await newsFeedController.searchTags(newsFeedController.temp.substring(1));
//                         //  await   print('hastag api value:${widget.tags}');
//                         if (newsFeedController.tags[0] == false) {
//                           newsFeedController.tags.clear();
//                           controller.mentionTag =
//                           false;
//                           controller. mentionTag = false;
//
//                           controller.update();
//                           //  temp='';
//                           controller.update();
//                         } else {
//                           // widget.controller.mentionUser =
//                           // false;
//
//                           controller. mentionTag = true;
//
//                           controller.update();
//
//                           // controller.mentionTag = true;
//                           // print("hit {} ")
//                           controller.update();
//
//                         }
//                       }
//                       print(
//                           "temp store value#: ${newsFeedController.temp}");
//
//                       /// @ mention user
//                       /*   if (value[value
//                                   .length -
//                                   1] ==
//                                   '@') {
//                                 widget.controller. mentionUser =
//                                 false;
//                                 widget.controller.update();
//                                 widget.controller.tempUsername =
//                                     widget.controller. tempUsername +
//                                         value[value
//                                             .length -
//                                             1];
//                                 print('1   @: ' +
//                                     widget.controller.tempUsername);
//                               } else if (widget.controller.tempUsername !=
//                                   '' &&
//                                   value[value.length -
//                                       1] !=
//                                       ' ') {
//                                 widget.controller.tempUsername =
//                                     widget.controller.tempUsername +
//                                         value[value
//                                             .length -
//                                             1];
//                                 print('2  @ : ' +
//                                     widget.controller. tempUsername);
//                               } else if (value[
//                               value.length -
//                                   1] ==
//                                   ' ') {
//                                 print('3   @ :' +
//                                     widget.controller. tempUsername);
//                                 widget.controller. tempUsername = '';
//                                 widget.controller.mentionUser =
//                                 false;
//                                 widget.controller. mentionTag =
//                                 false;
//                               }
//                               if (widget.controller.tempUsername
//                                   .length >
//                                   1) {
//                                 print('temp value @ : ' +
//                                     widget.controller.tempUsername);
//
//                                 widget.controller. users.clear();
//                                 widget.controller. users =
//                                     await widget
//                                     .controller
//                                     .searchChatUser(
//                                       widget.controller. tempUsername
//                                       .substring(
//                                       1),
//                                 );
//                                 if (widget.controller.users[
//                                 0] ==
//                                     false) {
//                                   widget.controller. users
//                                       .clear();
//                                   widget.controller.mentionUser =
//                                   false;
//                                   widget.controller.update();
//                                   // setState(() {});
//                                 } else {
//                                   widget.controller.  mentionUser =
//                                   true;
//                                   widget.controller.update();
//                                   // setState(() {});
//                                 }
//                               }*/
//                       // _controller[controller.currentIndexText].text=selectedHashTag;
//                       ///
//                     }
//
//
//
//
//
//
//
//
//
//
//                   },
//
//
//
//
//
//                 ),
//                 trailing: InkWell(
//                   onTap: () async {
//                     if (newsFeedController.commentController.text.isNotEmpty) {
//                       print('AAAAAAAAAAAAAAAAAAAAAAAAAAA');
//                       controller.isLoading = true;
//                       controller.update();
//                       controller.controller.createDeleteComment(
//                           post.postId,
//                           controller.controller.userProfile == null
//                               ? "assets/images/person_placeholder.png"
//                               : controller.controller.userProfile
//                                           .profileImage ==
//                                       null
//                                   ? "assets/images/person_placeholder.png"
//                                   : controller
//                                       .controller.userProfile.profileImage,
//                           newsFeedController.commentController.text,
//                           'create',
//                           {
//                             'audio_file_url': null,
//                             'audio_path': null,
//                             'author': {
//                               'firstname':
//                                   controller.controller.userProfile.firstname,
//                               'id': GetStorage().read('id'),
//                               'lastname':
//                                   controller.controller.userProfile.lastname,
//                               'profile_image': controller
//                                           .controller.userProfile ==
//                                       null
//                                   ? "assets/images/person_placeholder.png"
//                                   : controller.controller.userProfile
//                                               .profileImage ==
//                                           null
//                                       ? "assets/images/person_placeholder.png"
//                                       : controller
//                                           .controller.userProfile.profileImage,
//                               'username': controller.controller.userName,
//                             },
//                             'body': newsFeedController.commentController.text,
//                             'id': null,
//                             'isLiked': false,
//                             'postId': post.postId,
//                             'replies': post.comments[commentIndex].replies,
//                             'repliesCount': 0,
//                             'user_id': controller.controller.storage.read("id"),
//                             'commented_time_ago': "Just Now",
//                             'created_at': null,
//                             'in_reply_to_id': commentId,
//                             'language_id':
//                                 post.languageId,
//                             'link': null,
//                             'link_image': null,
//                             'link_meta': null,
//                             'link_title': null,
//                             'post_type_id': post.postType,
//                             // int.parse(_.postDetail.postType),
//                             'processing_status': null,
//                             'simple_dislike_count': 0,
//                             'simple_like_count': 0,
//                             'speech_to_text': null,
//                             'status': null,
//                             'updated_at': null,
//                           });
//
//                       var isCommentSuccessful =
//                           await controller.controller.createComment(
//                         newsFeedController.commentController.text,
//                         post,
//                         commentId: post.comments[commentIndex].id,
//                       );
//                       if (isCommentSuccessful['meta']['code'] == 200) {
//                         print('S U C C E S S F U L ');
//
//                         newsFeedController.selectedPost2 = await  newsFeedController.getSingleNewsFeedItem(post.postId,commentCheck: false);
//
//                         //controller.controller.postDetail = await controller.controller.getSingleNewsFeedItem(post.postId);
//                         controller.isLoading = false;
//                         newsFeedController.commentController.clear();
//                         controller.isLoading = false;
//                         controller.update();
//                         controller.update();
//                         newsFeedController.update();
//                         Navigator.of(context).pop();
//                       }
//                     }
//                   },
//                   child: Container(
//                     child: controller.isLoading
//                         ? CircularProgressIndicator(
//                       color: MyColors.BlueColor,
//                           )
//                         : Icon(
//                             Icons.send,
//                             color: controller.controller.displayColor,
//                           ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(height: 20,),
//           ],
//         ),
//       );
//     });
//   }
// }
