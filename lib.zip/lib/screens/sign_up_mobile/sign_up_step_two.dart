import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_three.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../../widgets/sign_up_app_bar_widget.dart';


class SignUpStepTwo extends StatefulWidget {

   const SignUpStepTwo({Key key,}) : super(key: key);

  @override
  State<SignUpStepTwo> createState() => _SignUpStepTwoState();
}

class _SignUpStepTwoState extends State<SignUpStepTwo> {
  bool _isChecked=false;
  bool _isChromeChecked=false;
  final signupController = Get.find<SignupController>();



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: SignUpAppBarWidget(
        bottomText: Strings.customizeYourExperience,
        onPress:(){
          if(kIsWeb){
            signupController.updateUI(1);
          }else {
            Navigator.pop(context);
          }
      } ,),

      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child:Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
             Text(
             Strings.trackWhereYouSeeWerfieContentAcrossTheWeb,
              style: const TextStyle(
                fontSize: 16.0,
                  fontFamily: 'Poppins',
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height:kIsWeb?20: 30),

            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: MyColors.werfieBlue,
              title: Text(
                Strings.werfieUsesThisDataToPersonalizeYourExperience,
                style: const TextStyle(
                  fontSize: 13.0,
                  fontFamily: 'Poppins',

                  fontWeight: FontWeight.w700,
                ),
              ),
              value: _isChecked,
              onChanged: (newValue) => setState(() => _isChecked = newValue),
            ),
            const SizedBox(height:kIsWeb?20: 30),
            Flexible(
              child: RichText(
                // maxLines: 2,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: '${Strings.bySigningUpYouAgree} ',
                      style: const TextStyle(color: Colors.black54,fontSize: 11,fontFamily: 'Poppins',),
                    ),
                    TextSpan(
                      text: Strings.termsOfService,
                      style: TextStyle(
                          color: MyColors.werfieBlue,
                          fontSize: 13,fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          launchUrl(Uri.parse(
                              'https://api.werfie.com/terms'));
                        },
                    ),
                    TextSpan(
                      text: ' ${Strings.and} ',
                      style: const TextStyle(color: Colors.black54,fontSize: 11,fontFamily: 'Poppins',),
                    ),
                    TextSpan(
                      text: Strings.privacyPolicy,
                      style: TextStyle(
                          color: MyColors.werfieBlue,
                          fontSize: 13,fontFamily: 'Poppins',
                          fontWeight: FontWeight.w400),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () {
                          launchUrl(Uri.parse(
                              'https://api.werfie.com/privacy'));
                        },
                    ),
                     TextSpan(
                      text: Strings.werfieMayUseYourContactInformationIncludingYouEmail,
                      style: const TextStyle(color: Colors.black54, fontSize: 11,fontFamily: 'Poppins',),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 60),
            CustomElevatedButton(
              text: Strings.next,
              margin: const EdgeInsets.only(right: 1),
              onPressed: _moveToNext,
            ),
          ],
        ),
      ),
    );
  }
  Future<void> _moveToNext()async {
    if(_isChecked) {
      if (kIsWeb) {
        signupController.updateUI(3);
      }else {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) => SignUpStepThree(),
          ),
        );
      }
    }else{
      UtilsMethods.toastMessageShow(
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        MyColors.werfieBlue,
        message: Strings.pleaseAgreeToWerfieTermsConditions,
      );
    }
  }
}
