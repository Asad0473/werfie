import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/apis/signup/signup_api.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';

import '../../components/rounded_button.dart';
import '../../network/controller/signup_controller.dart';
import '../../utils/colors.dart';
import '../../utils/login_theme/theme_helper.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../../widgets/sign_in_sign_up_widget/custom_password_field.dart';
import '../../widgets/sign_up_app_bar_widget.dart';

class SignUpStepFive extends StatefulWidget {
  const SignUpStepFive({
    Key key,
  }) : super(key: key);

  @override
  State<SignUpStepFive> createState() => _SignUpStepFiveState();
}

class _SignUpStepFiveState extends State<SignUpStepFive> {

  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  final controller = Get.find<SignupController>();

  bool _passwordError = false;
  bool _confirmPasswordError = false;
  bool _isPasswordFieldTouched = false;
  bool _isConfirmPasswordFieldTouched = false;
  var _isObsecure = true;

  double _strength = 0;
  String password = "";
  RegExp regExpMedium = RegExp(r'^(?=.*[A-Z])(?=.*\d).+$');
  RegExp regExpStrong = RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=]).+$');
  RegExp emailregExp =
      RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');

  String get passwordError {
    final text = _passwordController.text;
    if (text.isEmpty) {
      _passwordError = true;
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      _passwordError = true;

      return Strings.passwordShouldBeMin8Char;
    } /*else if (emailregExp.hasMatch(password)) {
      _passwordError = true;

      return Strings.cantChooseEmailAsApass;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      _passwordError = true;

      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (_strength == 0.5) {
      _passwordError = true;

      return Strings.yourPasswordIsWeak;
    } */else {
      _passwordError = false;

      return null;
    }
  }

  String get confirmPasswordErr {
    final text = _confirmPasswordController.text;
    if (text.isEmpty) {
      _confirmPasswordError = true;
      return Strings.passwordCannotBeEmpty;
    } else if (_passwordController.text != _confirmPasswordController.text) {
      _confirmPasswordError = true;

      return Strings.bothPasswordAndConfirmPassShouldMatch;
    } else if (text.length < 8) {
      _confirmPasswordError = true;
      return Strings.passwordShouldBeMin8Char;
    } /*else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      _confirmPasswordError = true;
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (_strength == 0.5) {
      _confirmPasswordError = true;

      return Strings.yourPasswordIsWeak;
    }*/ else {
      _confirmPasswordError = false;

      return null;
    }
  }

  void _checkPassword(String value) {
    password = value.trim();

    if (password.isEmpty) {
      setState(() {
        _strength = 0;
      });
    } else if (password.length > 7 &&
        regExpMedium.hasMatch(password) &&
        !regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 0.5;
      });
    } else if (password.length > 7 && regExpStrong.hasMatch(password)) {
      setState(() {
        _strength = 1;
      });
    } else {
      setState(() {
        _strength = 0.3;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: SignUpAppBarWidget(
        bottomText: Strings.youWillNeedAPassword,
        onPress: () {
          if(kIsWeb){
            if(controller.isSignupUsingEmail) {
              controller.updateUI(4);
            }else{
              controller.updateUI(3);
            }
          }else {
            Navigator.pop(context);
          }

        },
      ),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
               Text(
                 Strings.passwordMustBeCharactersLong,
                textAlign: TextAlign.left,
                style: const TextStyle(
                  fontSize: 10.0,
                  color: Colors.black54,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              _buildPasswordField(),
              // TextFormField(
              //   controller: _passwordController,
              //   decoration: InputDecoration(
              //     labelText: 'Password',
              //     errorText: _isPasswordFieldTouched ? passwordError : null,
              //     border: OutlineInputBorder(
              //       borderRadius: BorderRadius.circular(10),
              //
              //     ),
              //
              //     filled: true,
              //     fillColor: Colors.white,
              //     prefixIcon: const Padding(
              //       padding: EdgeInsets.symmetric(
              //           horizontal: 12, vertical: kIsWeb ? 5 : 0),
              //       child: CircleAvatar(
              //         backgroundColor: Colors.white,
              //         child: Icon(
              //           Icons.vpn_key,
              //           color: Colors.black,
              //         ),
              //       ),
              //     ),
              //     suffixIcon: Padding(
              //       padding: const EdgeInsets.symmetric(horizontal: 12),
              //       child: IconButton(
              //         icon: Icon(
              //           _isObsecure ? Icons.visibility_off : Icons.visibility,
              //         ),
              //         onPressed: () {
              //           setState(() {
              //             _isObsecure = !_isObsecure;
              //           });
              //         },
              //       ),
              //     ),
              //   ),
              //   obscuringCharacter: '.',
              //   obscureText: _isObsecure,
              //   onChanged: (value) {
              //     password = value;
              //     _checkPassword(password);
              //
              //     setState(() {
              //       // _verificationCode = value.isEmpty;
              //     });
              //   },
              //   onTap: () {
              //     _isPasswordFieldTouched = true;
              //   },
              // ),
              const SizedBox(height: 10),
              /*Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0.0),
                child: SizedBox(
                  // width: 160,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                    child: LinearProgressIndicator(
                      value: _strength,
                      backgroundColor: Colors.white,
                      color: _strength == 0.3
                          ? Colors.red
                          : _strength == 0.5
                              ? Colors.yellow
                              : _strength == 1
                                  ? Colors.green
                                  : Colors.red,
                      minHeight: 3,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.only(left: 0.0, bottom: 10.0),
                child: _strength == 0.3
                    ? const Text(
                        'Choose a secure password',
                        style: TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Poppins',
                            fontSize: 12),
                      )
                    : _strength == 0.5
                        ? const Text(
                            'Password Strength Weak',
                            style: TextStyle(
                                color: Colors.amber,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Poppins',
                                fontSize: 12),
                          )
                        : _strength == 1
                            ? const Text(
                                'Password Strength Strong',
                                style: TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Poppins',
                                    fontSize: 12),
                              )
                            : const SizedBox(),
              ),
              const SizedBox(height: 10),*/
              _buildConfirmPasswordField(),
              // TextFormField(
              //   controller: _confirmPasswordController,
              //   decoration: InputDecoration(
              //     labelText: 'Confirm Password',
              //     errorText:
              //         _isConfirmPasswordFieldTouched ? confirmPasswordErr : null,
              //     border: OutlineInputBorder(
              //       borderRadius: BorderRadius.circular(40),
              //     ),
              //     filled: true,
              //     fillColor: Colors.grey[250],
              //     prefixIcon: Padding(
              //       padding: const EdgeInsets.symmetric(
              //           horizontal: 12, vertical: kIsWeb ? 5 : 0),
              //       child: CircleAvatar(
              //         backgroundColor: Colors.white,
              //         child: Icon(
              //           Icons.vpn_key,
              //           color: Colors.black,
              //         ),
              //       ),
              //     ),
              //     suffixIcon: Padding(
              //       padding: const EdgeInsets.symmetric(horizontal: 12),
              //       child: IconButton(
              //         icon: Icon(
              //           _isObsecure ? Icons.visibility_off : Icons.visibility,
              //         ),
              //         onPressed: () {
              //           setState(() {
              //             _isObsecure = !_isObsecure;
              //           });
              //         },
              //       ),
              //     ),
              //   ),
              //   obscuringCharacter: '.',
              //   obscureText: _isObsecure,
              //   onChanged: (value) {
              //     setState(() {
              //       // _verificationCode = value.isEmpty;
              //     });
              //   },
              //   onTap: () {
              //     _isConfirmPasswordFieldTouched = true;
              //   },
              // ),
              const SizedBox(height:kIsWeb?30: 60),
              CustomElevatedButton(
                text: Strings.next,
                margin: const EdgeInsets.only(right: 1),
                onPressed: _moveToNext,
              ),

            ],
          ),
        ),
      ),
    );
  }
  Widget _buildPasswordField(){ return CustomPasswordField(

    textInputAction: TextInputAction.next,
    controller: _passwordController,
    hintText: Strings.enterNewPassword,
    contentPadding: const EdgeInsets.symmetric(horizontal: 12,vertical: 18),
    hintStyle:   TextStyle(
      color: appTheme.blueGray700,
      fontSize: 16,
      fontFamily: 'Poppins',
      fontWeight: FontWeight.w400,
    ),
    textInputType:
    TextInputType.visiblePassword,
    obscureText: _isObsecure,
    suffix: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: IconButton(
        icon: Icon(
          _isObsecure ? Icons.visibility_off : Icons.visibility,
        ),
        onPressed: () {
          setState(() {
            _isObsecure = !_isObsecure;
          });
        },
      ),
    ),
    errorText: _isPasswordFieldTouched ? passwordError : null,
    onChanged: (value) {
      password = value;
      _checkPassword(password);

      setState(() {
        // _verificationCode = value.isEmpty;
      });
    },
    onTap: () {
      _isPasswordFieldTouched = true;
    },
  ); }
  Widget _buildConfirmPasswordField(){ return   CustomPasswordField(
    controller: _confirmPasswordController,
    contentPadding: const EdgeInsets.symmetric(horizontal: 12,vertical: 18),
    hintText: Strings.confirmYourPasswords,
    hintStyle:   TextStyle(
      color: appTheme.blueGray700,
      fontSize: 16,
      fontFamily: 'Poppins',
      fontWeight: FontWeight.w400,
    ),
    textInputType:
    TextInputType.visiblePassword,
    obscureText: _isObsecure,
    suffix: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: IconButton(
        icon: Icon(
          _isObsecure ? Icons.visibility_off : Icons.visibility,
        ),
        onPressed: () {
          setState(() {
            _isObsecure = !_isObsecure;
          });
        },
      ),
    ),
    errorText:
    _isConfirmPasswordFieldTouched ? confirmPasswordErr : null,
    onChanged: (value) {
      setState(() {
        // _verificationCode = value.isEmpty;
      });
    },
    onTap: () {
      _isConfirmPasswordFieldTouched = true;
    },
  );}
  _moveToNext()async {
    if(!_passwordError && !_confirmPasswordError && _passwordController.text != null && _passwordController.text.isNotEmpty && _confirmPasswordController.text != null && _confirmPasswordController.text.isNotEmpty){
      controller.password = password;
      await signUpApi();
    }else{
      _isPasswordFieldTouched = true;
      _isConfirmPasswordFieldTouched = true;
      setState(() {

      });
    }
  }

  signUpApi() async {
    DialogBuilder(context).showLoadingIndicator();
    try {
      SignUpAPIRes signUpAPIRes =
      await SignUpAPI().signUp(context);
      if (signUpAPIRes.success) {
        //DialogBuilder(context).hideOpenDialog();

      } else {
        DialogBuilder(context).hideOpenDialog();
        UtilsMethods.toastMessageShow(
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          message: signUpAPIRes.message,
        );
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
    }
  }

}
