import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/apis/signup/send_verification_email.dart';
import 'package:werfieapp/network/apis/signup/verify_email_code_api.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_five.dart';
import 'package:werfieapp/utils/loading_dialog_builder.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../../components/input_field.dart';
import '../../components/rounded_button.dart';
import '../../network/controller/login_controller.dart';
import '../../network/controller/signup_controller.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';
import '../../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../../widgets/sign_up_app_bar_widget.dart';

class SignUpStepFour extends StatefulWidget {
  const SignUpStepFour({Key key}) : super(key: key);

  @override
  State<SignUpStepFour> createState() => _SignUpStepFourState();
}

class _SignUpStepFourState extends State<SignUpStepFour> {
  final TextEditingController _otpController = TextEditingController();
  String enteredOTP = '';
  bool _verificationCode = false;

  final controller = Get.find<SignupController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: SignUpAppBarWidget(
        bottomText: Strings.weSentYouACode,
        onPress: () {
          if(kIsWeb){
            controller.updateUI(3);
          }else {
            Navigator.pop(context);
          }

        },
      ),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  Strings.enterItBelowToVerify,
                  textAlign: TextAlign.left,
                  style: const TextStyle(
                    fontSize: 14.0,
                    color: Colors.black54,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                Expanded(
                  child: Text(
                    controller.email,
                    textAlign: TextAlign.left,
                    style: const TextStyle(
                      fontSize: 14.0,
                      fontFamily: 'Poppins',
                      color: Colors.black54,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            PinCodeTextField(
              controller: _otpController,
              length: 6,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],
              obscureText: false,
              keyboardType: TextInputType.number,
              appContext: context,
              onChanged: (value) {
                enteredOTP = value;
              },
              onCompleted: (value) {
                enteredOTP = value;
                if (enteredOTP.isNotEmpty) {
                  verifyCode(value);
                }
              },
              pinTheme: PinTheme(
                shape: PinCodeFieldShape.box,
                borderRadius: BorderRadius.circular(8),
                fieldHeight: 50,
                fieldWidth: 50,
                activeColor: MyColors.werfieBlue,
                activeFillColor: MyColors.werfieBlue.withOpacity(0.1),
                inactiveColor: Colors.grey,
              ),
              autoFocus: true,
              textInputAction: TextInputAction.done,
            ),
            const SizedBox(height: 10),
            GestureDetector(
              behavior: HitTestBehavior.translucent,
              child: Text(
               Strings.didNotReceiveEmail,
                textAlign: TextAlign.left,
                style: TextStyle(
                  fontSize: 14.0,
                  fontFamily: 'Poppins',
                  color: MyColors.werfieBlue,
                  fontWeight: FontWeight.w400,
                ),
              ),
              onTap: () async {
                SendVerificationEmailAPIRes sendVerificationEmailAPIRes =
                    await SendVerificationEmailAPI()
                        .sendVerificationEmail(controller.email);
                UtilsMethods.toastMessageShow(
                  MyColors.werfieBlue,
                  MyColors.werfieBlue,
                  MyColors.werfieBlue,
                  message: sendVerificationEmailAPIRes.message,
                );
              },
            ),
            const SizedBox(height: kIsWeb?30:60),
            CustomElevatedButton(
              text:Strings.next,
              margin: const EdgeInsets.only(right: 1),
              onPressed: _moveToNext,
            ),

          ],
        ),
      ),
    );
  }

  _moveToNext()async {
    if (enteredOTP.isNotEmpty || !(enteredOTP.length < 6)) {
      verifyCode(enteredOTP);
    }
  }
  verifyCode(String verificationCode) async {
    DialogBuilder(context).showLoadingIndicator();
    try {
      VerifyEmailCodeAPIRes verifyEmailCodeAPIRes =
          await VerifyEmailCodeAPI().verifyCode(verificationCode,controller.email);
      if (verifyEmailCodeAPIRes.success) {
        DialogBuilder(context).hideOpenDialog();
        if(kIsWeb){
          controller.updateUI(5);
        }else {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => const SignUpStepFive(),
            ),
          );
        }
      } else {
        DialogBuilder(context).hideOpenDialog();
        UtilsMethods.toastMessageShow(
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          MyColors.werfieBlue,
          message: verifyEmailCodeAPIRes.message,
        );
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
    }
  }
}
