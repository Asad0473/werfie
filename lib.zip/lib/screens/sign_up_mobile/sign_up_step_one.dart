import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:phone_form_field/phone_form_field.dart';
import 'package:werfieapp/network/apis/signup/werfie_handle_suggestions_api.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_two.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/auth_back_ground.dart';

import '../../components/rounded_button.dart';
import '../../network/apis/signup/email_available_api.dart';
import '../../network/controller/login_controller.dart';
import '../../network/controller/signup_controller.dart';
import '../../utils/asset_string.dart';
import '../../utils/colors.dart';
import '../../utils/login_theme/custom_text_style.dart';
import '../../utils/login_theme/theme_helper.dart';
import '../../utils/strings.dart';
import '../../widgets/login_form.dart';
import '../../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../../widgets/sign_in_sign_up_widget/custom_image_view.dart';
import '../../widgets/sign_in_sign_up_widget/custom_text_form_field.dart';
import '../../widgets/sign_up_app_bar_widget.dart';
import 'package:multi_masked_formatter/multi_masked_formatter.dart';

import '../language_settings.dart';

class SignUpStepOne extends StatefulWidget {
 final LoginController controller;

  const SignUpStepOne({Key key, this.controller}) : super(key: key);

  @override
  State<SignUpStepOne> createState() => _SignUpStepOneState();
}

class _SignUpStepOneState extends State<SignUpStepOne> {
  String name = '';
  bool errorText = false;
  String werfieHandle = '';
  String email = '';
  String password = '';
  String confirmPassword = '';

  String isoCountryCode;
  String countryDialCode;
  String werfieHandleErrorMessage = 'Please enter a handle';
  String emailErrorMessage = 'Please enter a valid email';

  final double _strength = 0;

  bool _isValidName = false;
  bool _isValidWerfieHandle = false;
  bool _isValidEmail = false;
  bool _isValidDOB = false;
  bool _isSignupUsingEmail = true;

  bool _isNameFieldTouched = false;
  bool _isWerfieHandleFieldTouched = false;
  bool _isEmailFieldTouched = false;
  bool _isDOBFieldTouched = false;
  bool _isWerfieHandleAvailable = false;
  bool _isEmailAvailable = false;


  bool _isWerfieHandleLoading = false;
  bool _isEmailLoading = false;

  Locale deviceLocale;
  IsoCode isoCode;
  Timer _werfieHandleTypingTimer;
  Timer _emailTypingTimer;
  WerfieHandleSuggestionsAPIRes werfieHandleSuggestionsAPIRes;

  RegExp regExpMedium = RegExp(r'^(?=.*[A-Z])(?=.*\d).+$');
  RegExp regExpStrong = RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=]).+$');
  RegExp emailregExp =
      RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
  final RegExp _dateRegExp = RegExp(r'^\d{0,2}/?\d{0,2}/?\d{0,4}$');

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _handlerController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();
  PhoneController _phoneFieldController;

  final signupController = Get.find<SignupController>();

  @override
  void initState() {
    signupController.loginController = widget.controller;
    _phoneFieldController = PhoneController(
        PhoneNumber(isoCode: signupController.isoCode ?? IsoCode.US, nsn: ''));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: (){
          if(!kIsWeb) {
            FocusScope.of(context).requestFocus(FocusNode());
          }
          //FocusManager.instance.primaryFocus?.unfocus();

        },
        child: Container(
          color: Colors.grey.shade100,
       //   alignment: Alignment.center,
       //   padding: EdgeInsets.all(30.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
             !kIsWeb?     _buildBackIconWidget():const SizedBox(),
                  const SizedBox(height:kIsWeb?10: 40),
                  _buildWerfieLogoWidget(),
                  const SizedBox(height:kIsWeb?10: 45),
                  _buildSignInText(text: Strings.signUpToYourAccount, ),
                  const SizedBox(height:kIsWeb?15: 25),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildNameTextField(),

                          const SizedBox(height:kIsWeb?10: 20),
                          _buildWerfieHandelField(),

                          Visibility(
                            visible: werfieHandleSuggestionsAPIRes != null &&
                                werfieHandleSuggestionsAPIRes.data != null &&
                                werfieHandleSuggestionsAPIRes.data != null &&
                                werfieHandleSuggestionsAPIRes
                                        .data.usernameSuggestion !=
                                    null &&
                                werfieHandleSuggestionsAPIRes
                                    .data.usernameSuggestion.isNotEmpty,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  Strings.suggestions,
                                  style: TextStyle(
                                      color: MyColors.werfieBlue,
                                      fontWeight: FontWeight.w500),
                                ),
                                SizedBox(
                                  height: 40,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount:
                                        werfieHandleSuggestionsAPIRes != null &&
                                                werfieHandleSuggestionsAPIRes.data !=
                                                    null &&
                                                werfieHandleSuggestionsAPIRes
                                                        .data.usernameSuggestion !=
                                                    null &&
                                                werfieHandleSuggestionsAPIRes.data
                                                    .usernameSuggestion.isNotEmpty
                                            ? werfieHandleSuggestionsAPIRes
                                                .data.usernameSuggestion.length
                                            : 0,
                                    itemBuilder: (BuildContext context, int index) {
                                      return GestureDetector(
                                        onTap: () {
                                          // Handle the onTap for each item
                                          _handlerController.text =
                                              werfieHandleSuggestionsAPIRes
                                                  .data.usernameSuggestion[index];
                                          _isValidWerfieHandle = true;
                                          _isWerfieHandleAvailable = true;
                                          setState(() {});
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(5.0),
                                          child: Text(
                                            "${werfieHandleSuggestionsAPIRes.data.usernameSuggestion[index]} ",
                                            style: TextStyle(
                                                color: MyColors.werfieBlue,
                                                fontWeight: FontWeight.w400),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(
                            height:kIsWeb?10: 20,
                          ),
                          _buildDateOfBirthField(),

                          const SizedBox(height:kIsWeb?10: 20),
                          Visibility(
                              visible: !_isSignupUsingEmail,
                              child: _buildPhoneField()),

                          Visibility(
                              visible: _isSignupUsingEmail,
                              child: _buildEmailField()),
                          const SizedBox(height: 10),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    _isSignupUsingEmail = !_isSignupUsingEmail;
                                  });
                                },
                                child: Text(
                                    _isSignupUsingEmail
                                        ? Strings.usePhoneInstead
                                        : Strings.useEmailInstead,
                                    textAlign: TextAlign.left,
                                    style: TextStyle(
                                      color: appTheme.blueColorHere,
                                      fontSize: 16,
                                      fontFamily: 'Poppins',
                                      fontWeight: FontWeight.w500,
                                    )
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height:kIsWeb?15: 30),
                          CustomElevatedButton(
                            text: Strings.next,
                            margin: const EdgeInsets.only(right: 1),
                            onPressed: _moveToNext,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

    );

  }


  Widget _buildPhoneField(){
    return  PhoneFormField(
      key: const Key('phone-field'),
      controller: _phoneFieldController,
      initialValue: null,
      shouldFormat: true,
      defaultCountry: signupController.isoCode,
      style: theme.textTheme.bodyLarge,
      countryCodeStyle:
      theme.textTheme.bodyLarge,
      decoration: InputDecoration(
        hintStyle:  theme.textTheme.bodyLarge,
       hintText: Strings.phone,
        border:  OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.white,

        contentPadding:  const EdgeInsets.symmetric(
            horizontal: 20,vertical: 17
        ),

      ),
      validator:
      PhoneValidator.validMobile(allowEmpty: false),
      isCountryChipPersistent: false,
      isCountrySelectionEnabled: true,
      countrySelectorNavigator:
      const CountrySelectorNavigator.dialog(width:kIsWeb ? 400 : null,height: kIsWeb ? 500 : null,),
      showFlagInInput: false,
      flagSize: 16,
      autofillHints: const [AutofillHints.telephoneNumber],
      enabled: true,
      autofocus: false,
      onSaved: (PhoneNumber p) => {},
      onChanged: (PhoneNumber p) => {},
    );
  }
  Widget _buildNameTextField(){
    return  CustomTextFormField(
      controller: _nameController,
        inputFormatters: [
          LengthLimitingTextInputFormatter(20),
          FilteringTextInputFormatter.deny("@"),
        ],
    contentPadding:  const EdgeInsets.symmetric(
            horizontal: 20,vertical: 17
        ),
        hintText: Strings.name,
        errorText: _isNameFieldTouched
              ? _isValidName
              ? null
              : Strings.pleaseEnterYourName
              : null,
        onChanged: (value) {
          setState(() {
            _isValidName = value.isNotEmpty;
          });
        },
        onTap: () {
          _isNameFieldTouched = true;
        },

    );
  }
Widget _buildEmailField(){
    return
      CustomTextFormField(
        controller: _emailController,
        contentPadding:  const EdgeInsets.symmetric(
            horizontal: 20,vertical: 17
        ),
        hintText: Strings.email,
        errorText: _isEmailFieldTouched
            ? _isValidEmail
            ? null
            : Strings.emailErrorMessage
            : null,
       suffix: Visibility(
         visible: _isEmailLoading,
         child: Container(
           width: 30,
           height: 30,
           padding: const EdgeInsets.all(8.0),
           child: const CircularProgressIndicator(),
         ),
       ),
        textInputAction: TextInputAction.done,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        onChanged: (value) {
          setState(() {
            _isValidEmail = RegExp(
                r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b',
                caseSensitive: false)
                .hasMatch(value);
            if (_isValidEmail) {
              resetTimerEmail();
            }
          });
        },
        onTap: () {
          _isEmailFieldTouched = true;
        },
      );
}
  Widget _buildWerfieHandelField(){
    return CustomTextFormField(
      controller: _handlerController,
        inputFormatters: [
        LengthLimitingTextInputFormatter(20),
        // FilteringTextInputFormatter.allow(
        //     RegExp('[a-zA-Z]+[ a-zA-Z]*')),
        // FilteringTextInputFormatter.deny(RegExp(r'[0-9]')),
        FilteringTextInputFormatter.deny('@'),
        FilteringTextInputFormatter.allow(
            RegExp(r'[a-z A-Z 0-9_]')),
        FilteringTextInputFormatter.deny(RegExp(r'\s')),
      ],
      contentPadding:  const EdgeInsets.symmetric(
          horizontal: 20,vertical: 17
      ),
      hintText: Strings.werfieHandle,
        errorText: _isWerfieHandleFieldTouched
                  ? _isValidWerfieHandle
                  ? null
                  : Strings.werfieHandleErrorMessage
                  : null,

                  suffix: Visibility(
            visible: _isWerfieHandleLoading,
            child: Container(
              width: 30,
              height: 30,
              padding: const EdgeInsets.all(8.0),
              child: const CircularProgressIndicator(),
            )),
        onChanged: (value) {
              setState(() {
                _isValidWerfieHandle = value.isNotEmpty;
              });
              resetTimerWerfieHandle();
            },
            onTap: () {
              _isWerfieHandleFieldTouched = true;
            },

    );
  }
   Widget _buildDateOfBirthField(){
    return
      CustomTextFormField(
      controller: _dobController,
      contentPadding:  const EdgeInsets.symmetric(
          horizontal: 20,vertical: 17
      ),
      hintText: Strings.pleaseEnterDOB,
        errorText: _isDOBFieldTouched
              ? _isValidDOB
              ? null
              : Strings.pleaseEnterAValidDOB
              : null,
      autovalidateMode: AutovalidateMode.onUserInteraction,
       textInputType: TextInputType.number,
        inputFormatters: [
          MultiMaskedTextInputFormatter(
              masks: ['xx/xx/xxxx'], separator: '/')
        ],
        onChanged: (value) {
          setState(() {
            _isValidDOB =
                _dateRegExp.hasMatch(value) && value.length == 10;
          });
        },
        onTap: () {
          _isDOBFieldTouched = true;
        },

    );

   }
  Widget _buildBackIconWidget(){
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: const EdgeInsets.only(right: 25,top: 60,left: 25),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: (){
                Get.back();
              },
              child: const Icon(
                Icons.arrow_back,
                size: 25,
                color: Colors.black,
              ),
            ),

          ],
        ),
      ),
    );
  }
  Widget _buildWerfieLogoWidget(){
    return  CustomImageShow(
      imagePath: AppImages.newWerfieLogoPng,
      height: 39,
      width: 162,
    );
  }

  Widget _buildSignInText({@required String text}){
    return Text(
      text,
      style: CustomTextStyles
          .headlineMediumPoppinsSecondaryContainer,
    );
  }
  startTimerWerfieHandle() {
    _werfieHandleTypingTimer = Timer(const Duration(seconds: 1), () async {
      verifyWerfieHandleAndGetSuggestionsApi();
    });
  }

  resetTimerWerfieHandle() {
    _werfieHandleTypingTimer?.cancel();
    startTimerWerfieHandle();
  }

  verifyWerfieHandleAndGetSuggestionsApi() async {

    setState(() {
      _isWerfieHandleLoading = true;
    });
    werfieHandleSuggestionsAPIRes = await WerfieHandleSuggestionsAPI()
        .verifyHandleAndGetSuggestions(_handlerController.text);
    if (werfieHandleSuggestionsAPIRes.success) {
      _isValidWerfieHandle = true;
      _isWerfieHandleAvailable = true;
      _isWerfieHandleLoading = false;
      setState(() {

      });
    } else {
      werfieHandleErrorMessage = werfieHandleSuggestionsAPIRes.message;
      _isValidWerfieHandle = false;
      _isWerfieHandleAvailable = false;
      _isWerfieHandleLoading = false;
      setState(() {});
    }
  }

  startTimerEmail() {
    _emailTypingTimer = Timer(const Duration(seconds: 1), () async {
      isEmailAvailableApi();
    });
  }

  resetTimerEmail() {
    _emailTypingTimer?.cancel();
    startTimerEmail();
  }

  isEmailAvailableApi() async {
    setState(() {
      _isEmailLoading = true;
    });

    IsEmailAvailableAPIRes isEmailAvailableAPIRes =
        await EmailAvailableAPI().isEmailAvailable(_emailController.text);
    if (isEmailAvailableAPIRes.success) {
      _isValidEmail = true;
      _isEmailAvailable = true;
      _isEmailLoading = false;
      setState(() {

      });
    } else {
      _isValidEmail = false;
      _isEmailAvailable = false;
      _isEmailLoading = false;
      emailErrorMessage = isEmailAvailableAPIRes.message;
      setState(() {});
    }
  }
  Future <void>_moveToNext()async {
    setState(() {
      _isNameFieldTouched = true;
      _isValidName = _nameController.text.isNotEmpty;

      _isWerfieHandleFieldTouched = true;
      if (_handlerController.text.isNotEmpty &&
          _isWerfieHandleAvailable) {
        _isValidWerfieHandle = true;
      } else {
        _isValidWerfieHandle = false;
      }

      _isEmailFieldTouched = true;
      _isDOBFieldTouched = true;
      if (_dobController.text.isNotEmpty &&
          _dateRegExp.hasMatch(_dobController.text)) {
        _isValidDOB = true;
      } else {
        _isValidDOB = false;
      }

      if (RegExp(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b',
          caseSensitive: false)
          .hasMatch(_emailController.text) &&
          _isEmailAvailable) {
        _isValidEmail = true;
      } else {
        _isValidEmail = false;
      }
    });

    if (_isValidName && _isValidWerfieHandle && _isValidDOB) {
      signupController.name = _nameController.text;
      signupController.handle = _handlerController.text;
      signupController.setDob(_dobController.text);
      if (_isSignupUsingEmail) {
        if (_isValidEmail) {
          signupController.email = _emailController.text;
          signupController.isSignupUsingEmail = _isSignupUsingEmail;
          if (kIsWeb) {
            signupController.updateUI(2);
          } else {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (BuildContext context) => SignUpStepTwo(),
              ),
            );
          }
        }
      } else if (_formKey.currentState.validate()) {
        signupController.phone =
            _phoneFieldController.value.countryCode +
                _phoneFieldController.value.nsn;
        signupController.isSignupUsingEmail = _isSignupUsingEmail;
        if (kIsWeb) {
          signupController.updateUI(2);
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (BuildContext context) => SignUpStepTwo(),
            ),
          );
        }
      }
    }
  }

  String get nameError {
    final text = widget.controller.firstName.text;
    if (text.isEmpty) {
      return Strings.nameCannotBeEmpty;
    }
    // else if ( !RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    //        return "Name start with must be Alphabets ";
    //      }
    else if (text.length > 20) {
      return Strings.nameLengthShouldMax20;
    }
    return null;
  }

  String get userNameError {
    final text = widget.controller.username.text;
    if (text.isEmpty) {
      return Strings.werfieHandleIsRequired;
      // } else if (!RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    } else if (!RegExp(r'^[a-zA-Z0-9_]{4,15}$').hasMatch(text)) {
      return Strings.nameStartsWithCharacter;
    }
    return null;
  }

  String get emailError {
    final text = widget.controller.signupEmail.text;
    if (text.isEmpty) {
      return Strings.emailFieldCannotBeEmpty;
    } else if (!RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(text)) {
      return Strings.pleaseProvideAValidEmail;
    } else {
      return null;
    }
  }

  String get passwordError {
    final text = widget.controller.signupPassword.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return Strings.passwordShouldBeMin8Char;
    } else if (emailregExp.hasMatch(password)) {
      return Strings.cantChooseEmailAsApass;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    } else if (_strength == 0.5) {
      return Strings.yourPasswordIsWeak;
    } else {
      return null;
    }
  }

  String get confirmPasswordErr {
    final text = widget.controller.signupPasswordCon.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return Strings.passwordShouldBeMin8Char;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    } else if (_strength == 0.5) {
      return Strings.yourPasswordIsWeak;
    } else {
      return null;
    }
  }
}
