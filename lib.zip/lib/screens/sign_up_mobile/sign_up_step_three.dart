import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:phone_form_field/phone_form_field.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_five.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_four.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_one.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_text_form_field.dart';

import '../../components/input_field.dart';
import '../../components/rounded_button.dart';
import '../../network/apis/signup/send_verification_email.dart';
import '../../network/controller/login_controller.dart';
import '../../utils/colors.dart';
import '../../utils/strings.dart';
import '../../utils/utils_methods.dart';
import '../../widgets/sign_in_sign_up_widget/custom_elevated_button.dart';
import '../../widgets/sign_up_app_bar_widget.dart';

class SignUpStepThree extends StatefulWidget {
final  LoginController controller;

  const SignUpStepThree({Key key, this.controller}) : super(key: key);

  @override
  State<SignUpStepThree> createState() => _SignUpStepThreeState();
}

class _SignUpStepThreeState extends State<SignUpStepThree> {
  String name = '';
  bool errorText = false;
  String werfieHandle = '';
  String email = '';
  String password = '';
  String confirmPassword = '';
  RegExp regExpMedium = RegExp(r'^(?=.*[A-Z])(?=.*\d).+$');
  RegExp regExpStrong = RegExp(r'^(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=]).+$');
  RegExp emailregExp =
      RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
  final double _strength = 0;

  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _handlerController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  final controller = Get.find<SignupController>();

  void backToStepOne() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (BuildContext context) => const SignUpStepOne(),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _nameController.text = controller.name;
    _handlerController.text = controller.handle;
    _emailController.text = controller.email;
    _phoneController.text = controller.phone;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: SignUpAppBarWidget(
        bottomText: Strings.createYourAccount,
        onPress: () {
          if(kIsWeb){
            controller.updateUI(2);
          }else {
            Navigator.pop(context);
          }
        },
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 30,right: 30),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildNameField(),
              const SizedBox(height:kIsWeb?10: 20),
              _buildWerfieHandelName(),
              const SizedBox(height:kIsWeb?10: 20),
              Visibility(
                visible: !controller.isSignupUsingEmail,
                child: _buildPhoneField(),
              ),
              const SizedBox(height:kIsWeb?10: 20),
              Visibility(
                visible: controller.isSignupUsingEmail,
                child: _buildEmailField(),
              ),
              const SizedBox(height:kIsWeb?30: 60),
              CustomElevatedButton(
                text: Strings.next,
                margin: const EdgeInsets.only(right: 1),
                onPressed: _moveToNext,
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNameField(){return CustomTextFormField(
    enabled: false,
    controller: _nameController,
    suffix: const Icon(
      Icons.check_circle,
      color: Colors.green,
      size: 20,
    ),
    contentPadding:  const EdgeInsets.symmetric(
        horizontal: 20,vertical: 17
    ),

  ); }
Widget _buildWerfieHandelName(){ return   CustomTextFormField(
  enabled: false,
  controller: _handlerController,
  suffix: const Icon(
    Icons.check_circle,
    color: Colors.green,
    size: 20,
  ),
  contentPadding:  const EdgeInsets.symmetric(
      horizontal: 20,vertical: 17
  ),
  inputFormatters: [
    LengthLimitingTextInputFormatter(20),
    // FilteringTextInputFormatter.allow(
    //     RegExp('[a-zA-Z]+[ a-zA-Z]*')),
    // FilteringTextInputFormatter.deny(RegExp(r'[0-9]')),
    FilteringTextInputFormatter.deny('@'),
    FilteringTextInputFormatter.allow(RegExp(r'[a-z A-Z 0-9_]')),
    FilteringTextInputFormatter.deny(RegExp(r'\s')),
  ],
);}
  Widget _buildPhoneField(){
    return CustomTextFormField(
    enabled: false,
      suffix: const Icon(
        Icons.check_circle,
        color: Colors.green,
        size: 20,
      ),
      contentPadding:  const EdgeInsets.symmetric(
          horizontal: 20,vertical: 17
      ),
    controller: _phoneController,);}
  Widget _buildEmailField(){ return CustomTextFormField(
    enabled: false,
    controller: _emailController,
    suffix: const Icon(
      Icons.check_circle,
      color: Colors.green,
      size: 20,
    ),
    contentPadding:  const EdgeInsets.symmetric(
        horizontal: 20,vertical: 17
    ),
  ); }
  _moveToNext()async {
    if(controller.isSignupUsingEmail) {
      SendVerificationEmailAPI().sendVerificationEmail(controller.email);
      if (kIsWeb) {
        controller.updateUI(4);
      }else {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) => SignUpStepFour(),
          ),
        );
      }
    }else{
      if (kIsWeb) {
        controller.updateUI(5);
      }else {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (BuildContext context) => SignUpStepFive(),
          ),
        );
      }
    }
  }
  String get nameError {
    final text = widget.controller.firstName.text;
    if (text.isEmpty) {
      return Strings.nameCannotBeEmpty;
    }
    // else if ( !RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    //        return "Name start with must be Alphabets ";
    //      }
    else if (text.length > 20) {
      return Strings.nameLengthShouldMax20;
    }
    return null;
  }

  String get userNameError {
    final text = widget.controller.username.text;
    if (text.isEmpty) {
      return Strings.werfieHandleIsRequired;
      // } else if (!RegExp('[a-zA-Z]+[ a-zA-Z]*').hasMatch(text)) {
    } else if (!RegExp(r'^[a-zA-Z0-9_]{4,15}$').hasMatch(text)) {
      return Strings.nameStartsWithCharacter;
    }
    return null;
  }

  String get emailError {
    final text = widget.controller.signupEmail.text;
    if (text.isEmpty) {
      return Strings.emailFieldCannotBeEmpty;
    } else if (!RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(text)) {
      return Strings.pleaseProvideAValidEmail;
    } else {
      return null;
    }
  }

  String get passwordError {
    final text = widget.controller.signupPassword.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return Strings.passwordShouldBeMin8Char;
    } else if (emailregExp.hasMatch(password)) {
      return Strings.cantChooseEmailAsApass;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    } else if (_strength == 0.5) {
      return Strings.yourPasswordIsWeak;
    } else {
      return null;
    }
  }

  String get confirmPasswordErr {
    final text = widget.controller.signupPasswordCon.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return Strings.passwordShouldBeMin8Char;
    } else if (!RegExp(r'^(?=.*[A-Z])(?=.*\d).+$').hasMatch(text)) {
      return Strings.passMustContainUpperCaseAndLeeter;
    } else if (widget.controller.signupPassword.text !=
        widget.controller.signupPasswordCon.text) {
      return Strings.bothPasswordAndConfirmPassShouldMatch;
    } else if (_strength == 0.5) {
      return Strings.yourPasswordIsWeak;
    } else {
      return null;
    }
  }
}
