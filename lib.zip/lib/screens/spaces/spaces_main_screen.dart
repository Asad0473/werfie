import 'package:bottom_picker/bottom_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../../components/input_field.dart';
import '../../components/rounded_button.dart';
import '../../models/chatUserModel.dart';
import '../../models/topic_model/suggested_following_topic_model.dart';
import '../../network/apis/spaces/create_space_api.dart';
import '../../network/apis/spaces/get_spaces_api.dart';
import '../../network/apis/spaces/post_join_space_api.dart';
import '../../network/controller/share_via_direct_message_controller.dart';
import '../../network/controller/topic_controller.dart';
import '../../utils/asset_string.dart';
import '../../utils/colors.dart';
import '../../utils/font.dart';
import '../../utils/loading_dialog_builder.dart';
import '../../utils/logging_utils.dart';
import '../../utils/metaTags/MetaTags.dart';
import '../../utils/metaTags/MetaTagsValues.dart';
import '../../utils/strings.dart';
import '../../utils/urls.dart';
import '../../web_views/dialogbox_web.dart';
import '../../web_views/web_main_screen.dart';
import '../../widgets/choice_chip_widget.dart';
import '../../widgets/new_message_dialog.dart';

class SpacesMainScreen extends StatefulWidget {
  const SpacesMainScreen({Key key}) : super(key: key);

  @override
  State<SpacesMainScreen> createState() => _SpacesMainScreenState();
}

class _SpacesMainScreenState extends State<SpacesMainScreen> {
  Future<GetSpacesAPIRes> getSpaces;
  Future<FollowingAndSuggestedTopics> getTopics;
  TopicController topicController = Get.put(TopicController());
  String url="";
  String profilePicUrl="https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png";
  @override
  void initState() {
    // TODO: implement initState
    getSpaces = GetSpacesAPI().getSpaces(Get.find<NewsfeedController>().userProfile.userId);
    getTopics =  topicController.suggestedTopic();
    addSpacesMetaTags();
    super.initState();
  }

  addSpacesMetaTags(){
    MetaTags().addMetaTag(
        pageTitle: MetaTagValues.pageTitleSpaces,
        metaTagDescription: MetaTagValues.spacesMetaDescription,
        metaTagKeywords: MetaTagValues.spacesMetaKeywords,
        ogTitle: MetaTagValues.spacesOGTitle,
        ogDescription: MetaTagValues.spacesOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
        id:"spaces",
        builder: (controller) {
      return Scaffold(
          appBar: PreferredSize(
              preferredSize: Size(double.infinity, 60),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    // splashColor: Colors.white,
                    // hoverColor: Colors.grey[100],
                    icon: Icon(
                      Icons.arrow_back,
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      size: 25,
                    ),
                    onPressed: () {
                      onHomeChange = true;
                      onBrowsChange = false;
                      onTrendsChange = false;
                      onBookMarksChange = false;
                      onChatsChange = false;
                      onProfileChange = false;
                      onSettingChange = false;
                      onSpacesScreen = false;
                      onListChange = false;
                      onNotificationChange = false;
                      onMoreChange = false;

                      controller.isTrendsScreen = false;
                      controller.isNewsFeedScreen = true;
                      controller.isBrowseScreen =
                          controller.isSpacesScreen = false;
                      controller.isNotificationScreen = false;

                      controller.isChatScreen = false;
                      controller.isSavedPostScreen = false;
                      controller.isPostDetails = false;
                      controller.isProfileScreen = false;
                      controller.isOtherUserProfileScreen = false;

                      controller.update();
                      // Get.delete<OtherUserController>();
                      Get.back();
                    },
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  SizedBox(
                      height: 29,
                      child: kIsWeb && controller.userInfo != null
                          ? Text(
                        Strings.watchPartyLetGo,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            )
                          : Text(
                              Strings.watchPartyLetGo,
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                ],
              )),
          body: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: <Widget>[
                    SizedBox(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width * 0.10,
                      height:
                      MediaQuery
                          .of(context)
                          .size
                          .height * 0.05,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(
                                25.0), // Adjust as needed
                          ),
                          primary: MyColors.werfieBlue,
                        ),
                        onPressed: () {

                          _showBottomSheetCreate(
                              context, controller);
                        },
                        child:  Text(
                          Strings.createSpace,
                          style:
                          TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              FutureBuilder(
                  future: getSpaces,
                  // future: GetSpacesAPI().getSpaces(Get.find<NewsfeedController>().userProfile.userId),
                  builder: (context, dataSnapshot) {
                    if (dataSnapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    } else {
                      if (dataSnapshot.error != null) {
                        print(dataSnapshot.error);
                        return  Center(
                          child:
                              Text(Strings.oopsSomethingWentWrongPleaseTryAgain),
                        );
                      } else {
                        GetSpacesAPIRes model = dataSnapshot.data;
                        // Check if the data list is empty
                        if (dataSnapshot.hasData && model.data.isEmpty) {
                          return  Center(
                            child:
                            Text(Strings.noSpacesAvailable),
                          );
                        } else if (dataSnapshot.hasData) {
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[

                                const SizedBox(
                                  height: 20,
                                ),
                                ListView.builder(
                                  itemCount: model.data.length,
                                  shrinkWrap: true,
                                  itemBuilder: (context, index) {
                                    return Card(
                                      margin: const EdgeInsets.all(16.0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            15.0),
                                      ),
                                      elevation: 4.0,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.circular(
                                            15.0),
                                        child: Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 30, horizontal: 10),
                                          decoration: BoxDecoration(
                                            gradient: index % 2 == 0
                                                ? LinearGradient(
                                              colors: [
                                                MyColors.werfieBlue
                                                    .withOpacity(0.3),
                                                Colors.blue.shade100
                                              ],
                                              // Replace with your desired colors
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                            )
                                                : LinearGradient(
                                              colors: [
                                                Colors.red.withOpacity(0.3),
                                                Colors.orange.shade100
                                              ],
                                              // Gradient for odd indexed items
                                              begin: Alignment.topLeft,
                                              end: Alignment.bottomRight,
                                            ),
                                          ),
                                          child: ListTile(
                                            contentPadding: EdgeInsets.all(10),
                                            leading: Visibility(
                                              visible: !(controller.userProfile
                                                  .userId
                                                  .toString() ==
                                                  model.data[index].userId
                                                      .toString() &&
                                                  model.data[index].endTime ==
                                                      null &&
                                                  model.data[index].type ==
                                                      "schedule" ||
                                                  model.data[index].endTime !=
                                                      null),
                                              child: Image.asset(
                                                "assets/images/live.gif",
                                                height: 125.0,
                                                width: 125.0,
                                              ),
                                            ),
                                            title: Text(
                                              model.data[index].name,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16,
                                                  color: Colors.white),
                                            ),
                                            subtitle: Text(
                                              model.data[index].type,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14,
                                                  color: Colors.white),
                                            ),
                                            trailing: model.data[index]
                                                .endTime ==
                                                null
                                                ? SizedBox(
                                              width: MediaQuery
                                                  .of(context)
                                                  .size
                                                  .width *
                                                  0.05,
                                              height: MediaQuery
                                                  .of(context)
                                                  .size
                                                  .height *
                                                  0.05,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                  shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                    BorderRadius.circular(
                                                        25.0), // Adjust as needed
                                                  ),
                                                  primary: Colors.black
                                                      .withOpacity(0.7),
                                                ),
                                                onPressed: () async {
                                                  // Action when the button is pressed
                                                  PostJoinSpaceAPI()
                                                      .spaceJoinApiCall(context,
                                                      spaceId: model.data[index]
                                                          .id.toString());
                                                  profilePicUrl = controller
                                                      .userProfile
                                                      .profileImage !=
                                                      null
                                                      ? controller.userProfile
                                                      .profileImage
                                                      : 'https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png';
                                                  url =
                                                  '${Url
                                                      .spaceStagingUrl}join?space_id=${model
                                                      .data[index]
                                                      .id}&user_id=${controller
                                                      .userProfile
                                                      .userId}&first_name=${controller
                                                      .userProfile
                                                      .firstname}&last_name=${controller
                                                      .userProfile
                                                      .lastname}&profile_picture_url=${profilePicUrl}?hmac=2qrt5LEJcx2B__YaKzZG3LV4EOpUqlanRy-CxdifXjE';
                                                  final Uri uri =
                                                  Uri.parse(url);

                                                  if (await canLaunchUrl(uri)) {
                                                    await launchUrl(uri,
                                                        webOnlyWindowName:
                                                        '_blank');
                                                  } else {
                                                    throw 'Could not launch $url';
                                                  }
                                                  // Navigator.push(
                                                  //   context,
                                                  //   MaterialPageRoute(
                                                  //     builder: (BuildContext context) => SpacesWebviewScreen(url: url,),
                                                  //   ),
                                                  // );
                                                },
                                                child: Text(controller
                                                    .userProfile
                                                    .userId
                                                    .toString() ==
                                                    model.data[index]
                                                        .userId
                                                        .toString() &&
                                                    model.data[index]
                                                        .endTime ==
                                                        null &&
                                                    model.data[index]
                                                        .type ==
                                                        "schedule"
                                                    ? 'Start'
                                                    : 'Join'),
                                              ),
                                            )
                                                : SizedBox.shrink(),
                                          ),
                                        ),
                                      ),
                                    );

                                    Card(
                                        clipBehavior: Clip.antiAlias,
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                              BorderRadius.circular(20)),
                                          margin: EdgeInsets.only(bottom: 10),
                                          child: ListTile(
                                            tileColor: MyColors
                                                .imagePlaceHolderBackgroundColor,
                                            contentPadding: EdgeInsets.all(10),
                                            title: Text(
                                              model.data[index].name,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16),
                                            ),
                                            subtitle: Text(
                                              model.data[index].type,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w400,
                                                  fontSize: 14),
                                            ),
                                            trailing: model.data[index]
                                                .endTime ==
                                                null
                                                ? ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                  BorderRadius.circular(
                                                      20.0), // Adjust as needed
                                                ),
                                                primary: Colors.black,
                                              ),
                                              onPressed: () async {
                                                // Action when the button is pressed
                                                print(
                                                    'Button pressed for ${controller
                                                        .userProfile
                                                        .username}');

                                                print(
                                                    'Button pressed for ${controller
                                                        .userProfile
                                                        .firstname}');
                                                print(
                                                    'Button pressed for ${controller
                                                        .userProfile
                                                        .lastname}');
                                                print(
                                                    'Button pressed for ${controller
                                                        .userProfile.userId}');
                                                print(
                                                    'Button pressed for ${controller
                                                        .userProfile
                                                        .profileImage}');

                                                String profilePicUrl = controller
                                                    .userProfile
                                                    .profileImage !=
                                                    null
                                                    ? controller.userProfile
                                                    .profileImage
                                                    : 'https://fastly.picsum.photos/id/522/536/354.jpg';
                                                String url =
                                                    '${Url
                                                    .spaceStagingUrl}join?space_id=${model
                                                    .data[index]
                                                    .id}&user_id=${controller
                                                    .userProfile
                                                    .userId}&first_name=${controller
                                                    .userProfile
                                                    .firstname}&last_name=${controller
                                                    .userProfile
                                                    .lastname}&profile_picture_url=${profilePicUrl}?hmac=2qrt5LEJcx2B__YaKzZG3LV4EOpUqlanRy-CxdifXjE';
                                                final Uri uri = Uri.parse(url);

                                                if (await canLaunchUrl(uri)) {
                                                  await launchUrl(uri,
                                                      webOnlyWindowName:
                                                      '_blank');
                                                } else {
                                                  throw 'Could not launch $url';
                                                }
                                              },
                                              child: Text('Join'),
                                            )
                                                : SizedBox.shrink(),
                                          ),
                                        ));
                                  },
                                ),
                              ],
                            ),
                          );
                        } else {
                          return Center(
                            child:
                            Text(Strings.noSpacesAvailable),
                          );
                          }
                      }
                    }
                  }),
            ],
          ));
    });
  }
  void _startMeetingDialog(BuildContext context,String url, NewsfeedController controller,int spaceId) {
    TextEditingController urlController = TextEditingController();
    urlController.text=url;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20.0),
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 500.0, // Set the desired maximum width here
              maxHeight: 500.0, // Set the desired maximum width here
              minHeight: 200.0, // Set the desired maximum width here
            ),
            child: Container(
            width: 300.0, // Set your desired width here
            height: 200.0, // Set your desired height here
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      Strings.yourSpaceIsReady,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18.0,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
                SizedBox(height: 16.0),
                TextField(
                  // enabled: true,
                  readOnly: true,
                  controller: urlController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    suffixIcon:  InkWell(
                        child: PopupMenuButton(
                        tooltip: Strings.share,
                        position: PopupMenuPosition.under,
                        padding: EdgeInsets.zero,

                        icon: Icon(Icons.share_outlined, size: 20, color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.grey,),


                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark ? Colors.black : Colors
                            .white,
                        // Callback that sets the selected popup menu item.
                        onSelected: (value) async {
                          if (value == 2) {
                            showDialog(
                                barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10.0))),
                                      insetPadding: EdgeInsets.symmetric(
                                          horizontal: 0, vertical: 0),
                                      contentPadding: EdgeInsets.symmetric(
                                          horizontal: 12),
                                      content: DialogboxWeb(
                                        controller,
                                        controller.userProfile.profileImage,
                                        true,
                                        spaceURL:url,

                                        ShowPolls: false,
                                      ));
                                });

                            // Clipboard.setData(ClipboardData(text: url)).then((_) {
                            //   Fluttertoast.showToast(
                            //       msg: 'Space link copied successfully',
                            //       toastLength:
                            //       Toast.LENGTH_SHORT,
                            //       gravity: ToastGravity.TOP,
                            //       timeInSecForIosWeb:
                            //       1,
                            //       backgroundColor: controller.displayColor,
                            //
                            //       textColor: Colors.white,
                            //       webPosition: "center",
                            //       webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                            //       fontSize: 16.0);
                            // });


                          }
                         else if (value == 3) {

                            Clipboard.setData(ClipboardData(text: url)).then((_) {
                              Fluttertoast.showToast(
                                  msg: Strings.spaceLinkCopiedSuccessfully,
                                  toastLength:
                                  Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.TOP,
                                  timeInSecForIosWeb:
                                  1,
                                  backgroundColor: controller.displayColor,

                                  textColor: Colors.white,
                                  webPosition: "center",
                                  webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                                  fontSize: 16.0);
                            });


                          }
                          else if (value == 4) {

                            Share.share(url, subject: 'Join space');

                          }
                          else if (value == 5) {


                            showDialog(
                              context: context,
                              builder:
                                  (BuildContext context) {
                                List<ChatUserModel> filterListChatUserList = [];
                                List<ChatUserModel> selectedUserList = [];
                                TextEditingController messageController = TextEditingController();
                                messageController.text=url;

                                return StatefulBuilder(
                                  builder: (context, setState) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 40),
                                      child: AlertDialog(
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.all(
                                                  Radius.circular(
                                                      10.0))),
                                          insetPadding:
                                          EdgeInsets.symmetric(
                                              horizontal: 0,
                                              vertical: 0),
                                          contentPadding:
                                          EdgeInsets.symmetric(
                                              horizontal: 12),
                                          content: AspectRatio(
                                            aspectRatio: 4 / 6,
                                            child: SingleChildScrollView(
                                              child: Column(
                                                  mainAxisSize: MainAxisSize.min,
                                                  children: <Widget>[
                                                    MouseRegion(
                                                      cursor: SystemMouseCursors.click,
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          Navigator.pop(context);
                                                        },
                                                        child: Padding(
                                                          padding: const EdgeInsets
                                                              .only(top: 20,

                                                              left: 10),
                                                          child: Align(
                                                            alignment: Alignment
                                                                .topRight,
                                                            child: Icon(
                                                              Icons.close,
                                                              size: 25,
                                                              color: Theme.of(context).brightness == Brightness.dark
                                                                  ? Colors.white : Colors.black,

                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(height: 20,),
                                                    TextField(
                                                      style: LightStyles.baseTextTheme
                                                          .headline4.copyWith(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark ? Colors
                                                            .white : Colors
                                                            .black,
                                                        //fontWeight: FontWeight.w500,
                                                        // fontSize: 14,
                                                      ),
                                                      cursorColor: Theme
                                                          .of(context)
                                                          .brightness == Brightness.dark
                                                          ? Colors.white
                                                          : Colors
                                                          .black,
                                                      onTap: () {
                                                        print("search tap called");
                                                      },
                                                      controller: controller
                                                          .searchTextForDM,
                                                      onChanged: (val) async {
                                                        if (val != null &&
                                                            val.isNotEmpty) {
                                                          filterListChatUserList =
                                                              controller.chatUserList
                                                                  .where((element) =>
                                                              element.name != null &&
                                                                  element.name
                                                                      .toLowerCase()
                                                                      .contains(val
                                                                      .toLowerCase()))
                                                                  .toList();
                                                          print("list of: " +
                                                              filterListChatUserList
                                                                  .length.toString());
                                                        } else {
                                                          filterListChatUserList = [];
                                                        }
                                                        setState(() {});
                                                      },
                                                      textAlignVertical: TextAlignVertical
                                                          .center,

                                                      decoration: InputDecoration(
                                                        filled: true,
                                                        hintText: Strings.search,
                                                        // border: InputBorder.none,
                                                        contentPadding: EdgeInsets.only(
                                                            left: 0,
                                                            bottom: 13,
                                                            top: 0,
                                                            right: 0),
                                                        hintStyle: LightStyles
                                                            .baseTextTheme.headline3.copyWith(
                                                          color:Theme
                                                              .of(context)
                                                              .brightness ==
                                                              Brightness.dark ? Colors
                                                              .white60 : Colors
                                                              .black45,
                                                        ),
                                                        prefixIcon: Icon(
                                                          Icons.search,
                                                          size: 20,
                                                          color: Theme
                                                              .of(context)
                                                              .brightness ==
                                                              Brightness.dark
                                                              ? Colors.white
                                                              : Colors.black,
                                                        ),
                                                        border: OutlineInputBorder(
                                                          borderRadius: BorderRadius
                                                              .circular(40),
                                                          borderSide: BorderSide(
                                                              color: Colors.grey,
                                                              width: 1),
                                                        ),

                                                        fillColor: Theme.of(context).brightness == Brightness.dark
                                                            ? Colors.black54 : Color(0XFFeff3f4), //
                                                      ),
                                                    ),
                                                    SizedBox(height: 20,),
                                                    selectedUserList.isNotEmpty ?
                                                    SizedBox(
                                                      height: 40,
                                                      width: 800,
                                                      child: ListView.builder(
                                                          shrinkWrap: true,
                                                          scrollDirection: Axis
                                                              .horizontal,
                                                          itemCount: selectedUserList
                                                              .length,
                                                          itemBuilder: (context,
                                                              index) {
                                                            return Row(
                                                              children: [
                                                                ChoiceChipWidget(
                                                                    imageUrl: selectedUserList[index]
                                                                        .profileImage,
                                                                    name: selectedUserList[index]
                                                                        .name,
                                                                    onDelete: () {
                                                                      selectedUserList
                                                                          .removeAt(
                                                                          index);
                                                                      setState(() {});
                                                                    }),
                                                                SizedBox(width: 5,)
                                                              ],
                                                            );
                                                          }),
                                                    ) :
                                                    SizedBox.shrink(),
                                                    SizedBox(height: 20,),
                                                    controller.isChatLoad
                                                        ? Center(
                                                      child: Padding(
                                                        padding: const EdgeInsets.only(
                                                            top: 10.0),
                                                        child: CircularProgressIndicator(
                                                          color: MyColors.BlueColor,),
                                                      ),
                                                    )
                                                        : filterListChatUserList !=
                                                        null || filterListChatUserList
                                                        .isNotEmpty
                                                        ? Column(
                                                      crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                      children: [

                                                        ///1st list
                                                        Column(
                                                          children: List.generate(
                                                              filterListChatUserList
                                                                  .length, (index) {
                                                            return Padding(
                                                              padding: const EdgeInsets
                                                                  .only(
                                                                  top: 0.0,
                                                                  left: 0,
                                                                  right: 0),
                                                              child: InkWell(
                                                                onTap: () {
                                                                  if (!selectedUserList
                                                                      .contains(
                                                                      filterListChatUserList[index])) {
                                                                    selectedUserList
                                                                        .add(
                                                                        filterListChatUserList[index]);
                                                                    setState(() {});
                                                                  }
                                                                },
                                                                child: Card(
                                                                  elevation: 0.0,
                                                                  color: controller
                                                                      .highlighteTheChat ==
                                                                      index
                                                                      ? Theme
                                                                      .of(context)
                                                                      .brightness ==
                                                                      Brightness.dark
                                                                      ? Color(
                                                                      0xff202327)
                                                                      : Color(
                                                                      0xffeff3f4)
                                                                      : Colors
                                                                      .transparent,
                                                                  child: Padding(
                                                                      padding:
                                                                      const EdgeInsets
                                                                          .all(8.0),
                                                                      child:


                                                                      Row(
                                                                        crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .start,
                                                                        children: [
                                                                          filterListChatUserList[index]
                                                                              .conversationType !=
                                                                              "group"
                                                                              ?


                                                                          CircleAvatar(
                                                                            backgroundImage:

                                                                            filterListChatUserList[index]
                                                                                .profileImage !=
                                                                                null
                                                                                ? NetworkImage(
                                                                                filterListChatUserList[index]
                                                                                    .profileImage)
                                                                                : AssetImage(
                                                                                'assets/images/person_placeholder.png'),
                                                                            radius: 22,
                                                                          )
                                                                              : CircleAvatar(
                                                                            backgroundImage: filterListChatUserList[index]
                                                                                .groupImage !=
                                                                                null
                                                                                ? NetworkImage(
                                                                                filterListChatUserList[index]
                                                                                    .groupImage)
                                                                                : AssetImage(
                                                                                'assets/images/person_placeholder.png'),
                                                                            radius: 22,
                                                                          ),
                                                                          SizedBox(
                                                                            width: 20,
                                                                          ),
                                                                          Expanded(
                                                                            child: Column(
                                                                              crossAxisAlignment:
                                                                              CrossAxisAlignment
                                                                                  .start,
                                                                              mainAxisAlignment:
                                                                              MainAxisAlignment
                                                                                  .spaceEvenly,
                                                                              children: [
                                                                                FittedBox(
                                                                                  child: Row(


                                                                                    children: [
                                                                                      filterListChatUserList[index]
                                                                                          .conversationType ==
                                                                                          "group"
                                                                                          ?
                                                                                      filterListChatUserList[index]
                                                                                          .name !=
                                                                                          null
                                                                                          ? Text(
                                                                                        "${filterListChatUserList[index]
                                                                                            .name}",
                                                                                        style: Styles
                                                                                            .baseTextTheme
                                                                                            .headline4
                                                                                            .copyWith(
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                          fontSize: 15,
                                                                                          fontWeight: FontWeight
                                                                                              .bold,
                                                                                        ),
                                                                                      )
                                                                                          : filterListChatUserList[index]
                                                                                          .members
                                                                                          .length ==
                                                                                          1
                                                                                          ? FittedBox(
                                                                                          child: Row(
                                                                                            children: [
                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members[0]
                                                                                                    .firstname}",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),


                                                                                            ],
                                                                                          )
                                                                                      )
                                                                                          : filterListChatUserList[index]
                                                                                          .members
                                                                                          .length ==
                                                                                          2
                                                                                          ? FittedBox(
                                                                                          child: Row(
                                                                                            children: [
                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members[0]
                                                                                                    .firstname}, ",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),
                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members[1]
                                                                                                    .firstname}",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),

                                                                                            ],
                                                                                          )
                                                                                      )
                                                                                          : filterListChatUserList[index]
                                                                                          .members
                                                                                          .length ==
                                                                                          3
                                                                                          ? FittedBox(
                                                                                        child: Row(
                                                                                          children: [
                                                                                            Text(
                                                                                              "${filterListChatUserList[index]
                                                                                                  .members[0]
                                                                                                  .firstname}, ",
                                                                                              style: Styles
                                                                                                  .baseTextTheme
                                                                                                  .headline4
                                                                                                  .copyWith(
                                                                                                color: Theme
                                                                                                    .of(
                                                                                                    context)
                                                                                                    .brightness ==
                                                                                                    Brightness
                                                                                                        .dark
                                                                                                    ? Colors
                                                                                                    .white
                                                                                                    : Colors
                                                                                                    .black,
                                                                                                fontSize: 15,
                                                                                                fontWeight: FontWeight
                                                                                                    .bold,
                                                                                              ),
                                                                                            ),
                                                                                            Text(
                                                                                              "${filterListChatUserList[index]
                                                                                                  .members
                                                                                                  .length -
                                                                                                  1} ${Strings.otherChat}",
                                                                                              style: Styles
                                                                                                  .baseTextTheme
                                                                                                  .headline4
                                                                                                  .copyWith(
                                                                                                color: Theme
                                                                                                    .of(
                                                                                                    context)
                                                                                                    .brightness ==
                                                                                                    Brightness
                                                                                                        .dark
                                                                                                    ? Colors
                                                                                                    .white
                                                                                                    : Colors
                                                                                                    .black,
                                                                                                fontSize: 15,
                                                                                                fontWeight: FontWeight
                                                                                                    .bold,
                                                                                              ),
                                                                                            ),
                                                                                          ],
                                                                                        ),
                                                                                      )
                                                                                          : filterListChatUserList[index]
                                                                                          .members
                                                                                          .length >=
                                                                                          4
                                                                                          ? FittedBox(
                                                                                          child: Row(
                                                                                            children: [

                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members[0]
                                                                                                    .firstname}, ",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),
                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members[1]
                                                                                                    .firstname}, ",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),

                                                                                              Text(
                                                                                                "${filterListChatUserList[index]
                                                                                                    .members
                                                                                                    .length -
                                                                                                    2} ${Strings.otherChat}",
                                                                                                style: Styles
                                                                                                    .baseTextTheme
                                                                                                    .headline4
                                                                                                    .copyWith(
                                                                                                  color: Theme
                                                                                                      .of(
                                                                                                      context)
                                                                                                      .brightness ==
                                                                                                      Brightness
                                                                                                          .dark
                                                                                                      ? Colors
                                                                                                      .white
                                                                                                      : Colors
                                                                                                      .black,
                                                                                                  fontSize: 15,
                                                                                                  fontWeight: FontWeight
                                                                                                      .bold,
                                                                                                ),
                                                                                              ),
                                                                                            ],
                                                                                          )
                                                                                      )


                                                                                          : SizedBox()
                                                                                          : SizedBox(),


                                                                                      filterListChatUserList[index]
                                                                                          .conversationType ==
                                                                                          "single"
                                                                                          ?


                                                                                      Text(
                                                                                        "${filterListChatUserList[index]
                                                                                            .name}",
                                                                                        style: Styles
                                                                                            .baseTextTheme
                                                                                            .headline4
                                                                                            .copyWith(
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                          fontSize: 15,
                                                                                          fontWeight: FontWeight
                                                                                              .bold,
                                                                                        ),
                                                                                      )
                                                                                          : SizedBox()


                                                                                    ],
                                                                                  ),
                                                                                ),

                                                                                SizedBox(
                                                                                  width: 150,
                                                                                  child: Text(
                                                                                    filterListChatUserList[index]
                                                                                        .latestMessage ==
                                                                                        null
                                                                                        ? ""
                                                                                        : filterListChatUserList[index]
                                                                                        .latestMessage,
                                                                                    overflow: TextOverflow
                                                                                        .ellipsis,
                                                                                    maxLines: 1,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline2
                                                                                        .copyWith(
                                                                                      color: Theme
                                                                                          .of(
                                                                                          context)
                                                                                          .brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .white
                                                                                          : Colors
                                                                                          .black,
                                                                                      fontSize: kIsWeb
                                                                                          ? 14
                                                                                          : 12,
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ),
                                                                          // Column(
                                                                          //   children: [
                                                                          //     Text(
                                                                          //         "jkbdjsbfjbfjksbdfjbsdf")
                                                                          //   ],
                                                                          // )
                                                                        ],
                                                                      )
                                                                  ),
                                                                ),
                                                              ),
                                                            );
                                                          }),
                                                        ),
                                                      ],
                                                    )
                                                        : Column(
                                                      children: [
                                                        Text(
                                                          Strings
                                                              .sendAMessageGetAMessage,
                                                          // style: TextStyle(
                                                          //     fontSize: 18,
                                                          //     color: Colors.black,
                                                          //     fontWeight: FontWeight.w900),

                                                          style: Styles.baseTextTheme
                                                              .headline4.copyWith(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark ? Colors
                                                                .white : Colors.black,
                                                            fontSize: kIsWeb ? 14 : 12,
                                                          ),
                                                        ),
                                                        SizedBox(height: 10),
                                                        Text(
                                                          Strings
                                                              .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                                                          textAlign: TextAlign.center,
                                                          // style: TextStyle(color: Colors.black),

                                                          style: Styles.baseTextTheme
                                                              .headline4.copyWith(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark ? Colors
                                                                .white : Colors.black,
                                                            fontSize: kIsWeb ? 14 : 12,
                                                          ),

                                                        ),
                                                        SizedBox(height: 14),
                                                        RoundedButton(

                                                          Strings.startAConversation,
                                                              () {
                                                            showDialog(
                                                              context: context,
                                                              builder: (
                                                                  BuildContext context) {
                                                                return AlertDialog(
                                                                  contentPadding: EdgeInsets
                                                                      .zero,
                                                                  insetPadding: EdgeInsets
                                                                      .zero,
                                                                  shape: RoundedRectangleBorder(
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(20),
                                                                  ),
                                                                  content: NewMessageDialogBox(),
                                                                );
                                                              },
                                                            );
                                                          },
                                                          horizontalPadding: 40,
                                                          roundedButtonColor: controller
                                                              .displayColor,
                                                        ),
                                                      ],
                                                    ),
                                                    Visibility(
                                                      visible: selectedUserList
                                                          .isNotEmpty,
                                                      child: Padding(
                                                        padding: EdgeInsets.only(
                                                            bottom: kIsWeb
                                                                ? 0
                                                                : MediaQuery
                                                                .of(context)
                                                                .viewInsets
                                                                .bottom),
                                                        child: Row(
                                                          children: [
                                                            SizedBox(
                                                              width: 10,
                                                            ),

                                                            SizedBox(width: 5),
                                                            Expanded(
                                                              child: Builder(
                                                                  builder: (context) {
                                                                    return


                                                                      InputField(
                                                                        contextPadding: EdgeInsets
                                                                            .only(
                                                                            left: kIsWeb
                                                                                ? 20
                                                                                : 20,
                                                                            top: kIsWeb
                                                                                ? 30
                                                                                : 20,
                                                                            bottom: kIsWeb
                                                                                ? 20
                                                                                : 15),


                                                                        suffixIconColor: controller
                                                                            .displayColor,
                                                                        controller: messageController,


                                                                        maxLine: 7,
                                                                        minLine: 1,
                                                                        // hint: 'Enter your message',
                                                                        hint: Strings
                                                                            .enterYourComment,
                                                                        // suffixIcon: Icons.emoji_emotions_outlined,
                                                                      );
                                                                  }),
                                                            ),

                                                            IconButton(
                                                              onPressed:

                                                                  () async {
                                                                final String messageText =
                                                                messageController
                                                                    .text.trim();
                                                                if (selectedUserList
                                                                    .isNotEmpty) {
                                                                  var params = {
                                                                    "conversation_ids": selectedUserList
                                                                        .map((e) =>
                                                                    e.conversationId)
                                                                        .toList(),
                                                                    // "post_id": post.postId,
                                                                    "space_id": spaceId.toString(),
                                                                    "comment": messageController.text
                                                                  };

                                                                  LoggingUtils
                                                                      .printValue(
                                                                      "Params", params);
                                                                  DialogBuilder(context)
                                                                      .showLoadingIndicator();

                                                                  await ShareViaDirectMessage()
                                                                      .sharePostApi(
                                                                      params);
                                                                  controller.getChat();
                                                                  DialogBuilder(context)
                                                                      .hideOpenDialog();

                                                                  Navigator.pop(
                                                                      context);
                                                                } else {


                                                                }
                                                              },
                                                              icon: Icon(
                                                                Icons.send_outlined,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),

                                                  ]
                                              ),
                                            ),)
                                        // :

                                        // DialogboxMobile(
                                        //     _scaffoldKey, controller),
                                      ),
                                    );
                                  },
                                );
                              },
                              barrierDismissible: true,
                            );
                          }


                        },
                        itemBuilder: (BuildContext context) =>
                        [
                          PopupMenuItem(
                            value: 2,
                            child: Row(
                                children: [
                                  Container(
                                      width: 20,
                                      height: 20,
                                      child: Image.asset(
                                        AppImages.createWerf,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      )
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    Strings.creatAsWerf,
                                    style:
                                    TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors
                                            .black,
                                        fontSize: 14
                                    ),),
                                ]),),

                          PopupMenuItem(
                            value: 3,
                            child: Row(
                                children: [
                                  Container(
                                      width: 20,
                                      height: 20,
                                      child: Image.asset(
                                        AppImages.copylink,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      )
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    Strings.copylinkToWerf,
                                    style:
                                    TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors
                                            .black,
                                        fontSize: 14
                                    ),),
                                ]),),
                          // if(!kIsWeb)
                          PopupMenuItem(
                            value: 4,
                            child: Row(
                                children: [
                                  Container(
                                      width: 20,
                                      height: 20,
                                      child: Image.asset(
                                        AppImages.share,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      )
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    Strings.shareWerf,
                                    style:
                                    TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors
                                            .black,
                                        fontSize: 14
                                    ),),
                                ]),),
                          PopupMenuItem(
                            value: 5,
                            child: Row(
                                children: [
                                  Container(
                                      width: 20,
                                      height: 20,
                                      child: Image.asset(
                                        AppImages.copylink,
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      )
                                  ),
                                  SizedBox(width: 5),
                                  Text(
                                    Strings.sendViaDirectMessage,
                                    style:
                                    TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors
                                            .black,
                                        fontSize: 14
                                    ),),
                                ]),),

                        ]
                    )
                    ),


                  ),
                ),
                SizedBox(height: 16.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
      /*              ElevatedButton(
                      onPressed: () {
                        // Action when Share button is pressed

                        // Share.share(url, subject: 'Space url');

                      },
                      child: Text('Share'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                      ),
                    ),*/
                    ElevatedButton(
                      onPressed: () async {
                        // Action when Start Now button is pressed
                        final Uri uri = Uri.parse(url);

                        if (await canLaunchUrl(uri)) {
                        await launchUrl(uri, webOnlyWindowName: '_blank');
                        } else {
                        throw 'Could not launch $url';
                        }
                      },
                      child: Text('Start Now'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),),
        );
      },
    );
  }
  void _showBottomSheetCreate(
      BuildContext context, NewsfeedController controller) {
    TextEditingController spaceNameController = TextEditingController();

    String selectedateTime = DateTime.now().toString();
    String selectedOption = 'instant';
    String selectedTopics = '';
    int selectedChipIndex = 0; // Index of the selected chip

    FollowingAndSuggestedTopics model;
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setState) {
          return Dialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(
                    16.0), // Adjust the corner radius as needed
              ),
              child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: 600.0, // Set the desired maximum width here
                    maxHeight: 800.0, // Set the desired maximum width here
                    minHeight: 500.0, // Set the desired maximum width here
                  ),
                  child: Container(
                    padding: EdgeInsets.all(16.0),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Text(
                                Strings.createSpace,
                                style: TextStyle(
                                  fontSize: 20.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: Icon(Icons.help_outline),
                                color: Colors.blue,
                                onPressed: () {
                                  // Handle the question mark icon tap
                                },
                              ),
                            ],
                          ),
                          SizedBox(height: 20.0),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                child: RadioListTile<String>(
                                  title: Text(
                                    Strings.instant,
                                    style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  value: Strings.instant,
                                  groupValue: selectedOption,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedOption = value;
                                    });
                                  },
                                ),
                              ),
                              Expanded(
                                child: RadioListTile<String>(
                                  title: Text(
                                    Strings.schedule,
                                    style: const TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  value: Strings.schedule,
                                  groupValue: selectedOption,
                                  onChanged: (value) {
                                    setState(() {
                                      selectedOption = value;
                                      selectedateTime = DateTime.now().toString();
                                    });
                                  },
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20.0),
                          Text(
                            Strings.nameYourSpace,
                            style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 20.0),
                          TextField(
                            controller: spaceNameController,
                            decoration: InputDecoration(
                                hintText: Strings.whatDoYouWantToTalkAbout,
                                hintStyle: TextStyle(fontSize: 14)),
                          ),
                          SizedBox(height: 20.0),

                          selectedOption == "schedule"
                              ? InkWell(
                            onTap: (){
                              BottomPicker.dateTime(
                                title: Strings.scheduleYourSpace,
                                description: Strings.watchPartyLetGo,
                                titleAlignment:
                                CrossAxisAlignment.start,

                                titleStyle: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    color: Colors.black),
                                onSubmit: (date) {
                                  print(date);
                                  selectedateTime = date.toString();
                                },
                                onClose: () {
                                  print("Picker closed");
                                },
                                buttonText: Strings.confirm,
                                buttonTextStyle: const TextStyle(
                                    color: Colors.white),
                                buttonSingleColor: Colors.blue,
                                minDateTime: DateTime.now(),

                                // minDateTime:  DateTime(2021, 5, 1),
                                // maxDateTime:  DateTime(2021, 8, 2),
                              ).show(context);

                            },
                            child: Row(children: [
                              Expanded(
                                child: Text(
                                  // 'Select up to 3 topics',
                                 UtilsMethods.dateTimeFormat(selectedateTime.toString(),"MMMM dd, yyyy hh:mm a") ,
                                  style: TextStyle(
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                              ),
                               IconButton(
                                icon: Icon(Icons.calendar_month),
                                color: Colors.blue,
                                onPressed: () {
                                  // Handle the question mark icon tap
                                },
                              )

                            ],),
                          ):SizedBox.shrink(),

                          SizedBox(height: 20.0),
                          Text(
                            // 'Select up to 3 topics',
                            Strings.selectTopic,
                            style: TextStyle(
                              fontSize: 16.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 20.0),
                          FutureBuilder(
                              future: getTopics,
                              builder: (context, dataSnapshot) {
                                if (dataSnapshot.connectionState ==
                                    ConnectionState.waiting) {
                                  return Center(
                                    child: CircularProgressIndicator(),
                                  );
                                } else {
                                  if (dataSnapshot.error != null) {
                                    print(dataSnapshot.error);
                                    return Center(
                                      child: Text(
                                          Strings.oopsSomethingWentWrongPleaseTryAgain),
                                    );
                                  } else {
                                     model = dataSnapshot.data;
                                     model.data.suggestedTopics.sort((a, b) => a.topic.compareTo(b.topic));

                                    return Wrap(
                                      spacing: 20.0,
                                      children: List.generate(
                                        model.data.suggestedTopics.length,
                                        // You can change this to the number of topics available
                                        (index) {

                                          return Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: ChoiceChip(
                                              label: Text('${model.data.suggestedTopics[index].topic}'),
                                              selected: selectedChipIndex == index,
                                              //// Set selected status accordingly
                                              selectedColor: Colors.blue,
                                              onSelected: (selected) {
                                                // Handle chip selection here
                                                if (selected) {
                                                  setState(() {
                                                    selectedChipIndex = index;
                                                    selectedTopics = model.data.suggestedTopics[selectedChipIndex].topic;
                                                  });
                                                }
                                              },
                                            ),
                                          );
                                        },
                                      ),
                                    );
                                  }
                                }
                              }),
                          SizedBox(height: 30.0),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                  height: 50,
                                  margin: EdgeInsets.all(16.0),
                                  child: ElevatedButton(
                                    onPressed: () {
                                      // Add functionality for the round shape button here
                                      if (spaceNameController.text.isEmpty) {
                                        Fluttertoast.showToast(
                                            msg: Strings.pleaseEnterTheSpaceName,
                                            toastLength: Toast.LENGTH_SHORT,
                                            gravity: ToastGravity.CENTER,
                                            timeInSecForIosWeb: 1,
                                            backgroundColor: Colors.red,
                                            textColor: Colors.white,
                                            fontSize: 16.0);
                                        return;
                                      } else {
                                        // print(selectedTopics);
                                        // print(model.data.suggestedTopics[selectedChipIndex].id.toString());
                                        createSpaceApiCall(context,
                                            controller: controller,
                                            name: spaceNameController.text,
                                            type: selectedOption,
                                            startTime: selectedateTime,
                                            url:url,
                                            topicIds: model.data.suggestedTopics[selectedChipIndex].id.toString());
                                      }
                                    },
                                    child: Text(Strings.createSpace),
                                    style: ElevatedButton.styleFrom(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(30.0),
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  )));
        });
      },
    );
  }

  createSpaceApiCall(BuildContext context,
      {String name,
      String type,
      String startTime,
      String topicIds,
        String url,
      NewsfeedController controller}) async {
    try {
      DialogBuilder(context).showLoadingIndicator();

      CreateSpaceAPIRes response = await CreateSpaceAPI().createSpace(
          name: name, type: type, startTime: startTime, topicIds: topicIds);

      if (response.success) {
        DialogBuilder(context).hideOpenDialog();
        Fluttertoast.showToast(
            msg: Strings.createSpaceSuccessfully,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.green,
            textColor: Colors.white,
            fontSize: 16.0);
      //    setState(() {
      //
      // });
      // return;
    // });
        DialogBuilder(context).hideOpenDialog();

        Navigator.pop(context);
        // await  GetSpacesAPI().getSpaces(Get.find<NewsfeedController>().userProfile.userId);
        // setState(() {
        //
        // });
        profilePicUrl = controller
            .userProfile
            .profileImage !=
            null
            ? controller.userProfile
            .profileImage
            : 'https://storage.googleapis.com/buzznbees/files/6zgncERXGi5iIStbD3kl3MLB0rLjcTtSlXmc1XTF.png';
        url =
        '${Url.spaceStagingUrl}join?space_id=${response.data.data[0].id}&user_id=${controller.userProfile.userId}&first_name=${controller.userProfile.firstname}&last_name=${controller.userProfile.lastname}&profile_picture_url=${profilePicUrl}?hmac=2qrt5LEJcx2B__YaKzZG3LV4EOpUqlanRy-CxdifXjE';


        _startMeetingDialog(context,url,controller,response.data.data[0].id);

      } else {
        DialogBuilder(context).hideOpenDialog();

        Fluttertoast.showToast(
            msg: response.message,
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        return;
      }
    } catch (e) {
      DialogBuilder(context).hideOpenDialog();
      Fluttertoast.showToast(
          msg: e.toString(),
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return;

      // TODO
    }
  }
}
