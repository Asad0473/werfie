import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:werfieapp/web_views/web_view_screen.dart';

class SpacesWebviewScreen extends StatefulWidget {
  String url;
   SpacesWebviewScreen({Key key,this.url}) : super(key: key);

  @override
  State<SpacesWebviewScreen> createState() => _SpacesWebviewScreenState();
}

class _SpacesWebviewScreenState extends State<SpacesWebviewScreen> {
   InAppWebViewController _webViewController;
   double progress = 0;

  @override
  Widget build(BuildContext context) {
    print(widget.url);
    print(Uri.encodeFull(widget.url));
    return Scaffold(
        // appBar: AppBar(title: Text("InAppWebView")),
        body: WillPopScope(
          onWillPop: _exitApp,

          child: SafeArea(
            child: Container(
                child: Column(children: <Widget>[
                  Container(
                      // padding: EdgeInsets.all(10.0),
                      child: progress < 1.0
                          ? LinearProgressIndicator(value: progress)
                          : SizedBox.shrink()),
                  Expanded(
                    child:/*Platform.isIOS?WebViewScreen(String: Uri.encodeFull(widget.url),)
                        :*/ InAppWebView(
                        initialUrlRequest:
                        // URLRequest(url: Uri.parse("https://mizdah.com/meetings/j/RMTA5NzI=s?pwd=VZHlwdGJym")),
                        URLRequest(url: Uri.parse(Uri.encodeFull(widget.url))),

                        onProgressChanged: (InAppWebViewController controller, int progress) {
                          setState(() {
                            this.progress = progress / 100;
                          });
                        },
                     onLoadError: (InAppWebViewController con, Uri uri, int i, String s){
                          print(con);
                          print(uri);
                          print(s);
                          print(i);
                     },

                        initialOptions: InAppWebViewGroupOptions(
                            android: AndroidInAppWebViewOptions(
                              hardwareAcceleration: true,
                                useHybridComposition: true

                            ),
                            ios: IOSInAppWebViewOptions(
                              allowsInlineMediaPlayback: true,
                            ),

                            crossPlatform: InAppWebViewOptions(
                                javaScriptEnabled: true,
                                javaScriptCanOpenWindowsAutomatically: true,
                                mediaPlaybackRequiresUserGesture: false,
                                clearCache: true,
                                preferredContentMode: UserPreferredContentMode.MOBILE
                              // debuggingEnabled: true,
                            )
                        ),
                        onWebViewCreated: (InAppWebViewController controller) {
                          _webViewController = controller;

                        },
                        androidOnPermissionRequest:
                            (InAppWebViewController controller, String origin,
                            List<String> resources) async {
                          return PermissionRequestResponse(
                              resources: resources,
                              action: PermissionRequestResponseAction.GRANT);
                        }),
                  ),
                ])),
          ),
        ));

  }

   Future<bool> _exitApp() async {
     if ( _webViewController!=null) {
       print("onwill goback");
       _webViewController.goBack();
       return Future.value(true);
     } else {
       // Scaffold.of(context).showSnackBar(
       //   const SnackBar(content: Text("No back history item")),
       // );
       return Future.value(false);
     }
   }
}
