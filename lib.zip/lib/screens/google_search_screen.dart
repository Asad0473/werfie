import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/google_search_location.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../models/map_autocomplete_model/map_auto_complete_model.dart';
import '../utils/colors.dart';
import '../utils/strings.dart';

class GoogleSearchSuggestion extends StatelessWidget {
  GoogleSearchLocation locationController = Get.put(GoogleSearchLocation());
  bool check = false;
  int index;
  bool isReply = false;

  GoogleSearchSuggestion({Key key, this.index, this.isReply}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder(builder: (GoogleSearchLocation locationController) {
        return SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(
                    top: 20, bottom: 10, left: 10, right: 10),
                child: Row(
                  children: [
                    Spacer(),
                    Text(
                      Strings.tagLocation,
                      style: TextStyle(
                        color: MyColors.grey,
                        fontWeight: FontWeight.bold,
                        fontFamily: "assets/fonts/Arial-Bold.ttf",
                        fontSize: 25,
                      ),
                    ),
                    Spacer(),
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Text(
                        Strings.done,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.blue,
                          fontWeight: FontWeight.bold,
                          fontFamily: "assets/fonts/Arial-Bold.ttf",
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Divider(
                thickness: 2,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: GestureDetector(
                  onTap: () {
                    locationController.update();
                    locationController
                        .callApi(locationController.customLocation.value);
                    locationController.update();
                  },
                  child: TextFormField(
                    cursorHeight: 30,
                    cursorWidth: 2,
                    cursorRadius: const Radius.circular(500),
                    style: TextStyle(fontSize: 20, height: 1.5 //Add this
                        ),
                    onEditingComplete: () {
                      FocusScope.of(context).requestFocus(FocusNode());
                    },
                    controller: locationController.locationTextController,
                    onChanged: (value) {
                      locationController.callApi(value);
                    },
                    decoration: InputDecoration(
                      hintText: Strings.searchLocation,
                      hintStyle: TextStyle(
                        color: MyColors.grey,
                        fontSize: 20,
                      ),
                      prefixIcon: locationController
                                  .locationTextController.text.length >
                              0
                          ? Icon(
                              Icons.search,
                              color: Colors.grey,
                              size: 30,
                            )
                          : null,
                      suffixIcon: locationController
                                  .locationTextController.text.length >
                              0
                          ? IconButton(
                              icon: Icon(
                                Icons.clear,
                                color: Colors.black,
                                size: 30,
                              ),
                              onPressed: () {
                                locationController.locationTextController
                                    .clear();
                              })
                          : null,

                      //   filled: true,

                      // contentPadding: EdgeInsets.only(top: 20,left: 10),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(width: 2, color: Colors.blue),
                      ),

                      // enabledBorder: UnderlineInputBorder(
                      //   borderSide: BorderSide(
                      //        color: Colors.blue),
                      // ),
                    ),
                  ),
                ),
              ),
              //  Selectedlocation(
              //     context: context
              // ),
              Expanded(
                child: Container(
                    // height: Get.height * 0.6,
                    child: locationController.searchPlaces.value != null
                        ? Obx(() => listview(context,
                            locationController.searchPlaces.value, index))
                        : Text('')),
              ),
            ],
          ),
        );
      }),
    );
  }

  // Widget Selectedlocation({@required BuildContext context,}) {
  //   return Container(
  //     width: MediaQuery
  //         .of(context)
  //         .size
  //         .width,
  //     height: 60,
  //     color: Colors.blue,
  //     child: Column(
  //       crossAxisAlignment: CrossAxisAlignment.start,
  //       children: [
  //         const SizedBox(
  //           height: 20,
  //         ),
  //         Padding(
  //           padding: const EdgeInsets.only(left: 20, right: 20),
  //           child: Row(
  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //             children: [
  //               ConstrainedBox(
  //                 constraints: const BoxConstraints(maxWidth: 200),
  //                 child: Text(
  //                   locationController.mainText,
  //                   overflow: TextOverflow.ellipsis,
  //                   style: TextStyle(
  //                     fontSize: 20,
  //                     color: Colors.white,
  //                     fontWeight: FontWeight.bold,
  //                     fontFamily: "assets/fonts/Arial-Bold.ttf",
  //                   ),
  //                 ),
  //               ),
  //               Icon(
  //                 Icons.clear,
  //                 color: Colors.white,
  //               ),
  //             ],
  //           ),
  //         ),
  //         const SizedBox(
  //           height: 2,
  //         ),
  //         // Text(
  //         //   secnT(data: data),
  //         //   textAlign: TextAlign.left,
  //         //   style: TextStyle(
  //         //     color: Colorss.grey,
  //         //     fontFamily: "assets/fonts/Regular.ttf",
  //         //   ),
  //         // ),
  //       ],
  //     ),
  //   );
  // }

  Widget _location(
      {@required StructuredFormatting data,
      @required BuildContext context,
      @required int index}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 200),
                  child: Text(
                    data.maintext,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: "assets/fonts/Arial-Bold.ttf",
                    ),
                  ),
                ),
                const SizedBox(
                  height: 2,
                ),
                data.secondarytext != null
                    ? Text(data.secondarytext,
                        //secnT(data: data),
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: MyColors.grey,
                          fontFamily: "assets/fonts/Regular.ttf",
                        ))
                    : Text(""),
              ],
            )),
        Divider(
          thickness: 2,
        ),
      ],
    );
  }

  String secnT({@required StructuredFormatting data}) {
    if (data.secondarytext != null) {
      return data.secondarytext;
    }
    locationController.update();
    return '';
  }

  Widget listview(
      BuildContext context, AutoComplete data, int currentPostIndex) {
    return Container(
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: data.predict.length,
        padding: const EdgeInsets.only(top: 5),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () async {
              // print("index location ${currentPostIndex}");
              // print("idhr ayi location");


              if (isReply != null && isReply){
              Get.find<NewsfeedController>().replayModelList[currentPostIndex].location = data.predict[index].structuredformatting.maintext;
              Get.find<NewsfeedController>().replayModelList[currentPostIndex].lat = locationController.lat.value.toString();
              Get.find<NewsfeedController>().replayModelList[currentPostIndex].lng = locationController.lng.value.toString();
              } else{
              Get.find<NewsfeedController>().modelList2[currentPostIndex].location = data.predict[index].structuredformatting.maintext;
              Get.find<NewsfeedController>().modelList2[currentPostIndex].lat = locationController.lat.value.toString();
              Get.find<NewsfeedController>().modelList2[currentPostIndex].lng = locationController.lng.value.toString();
              }

              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              // SingleTone.instance.lat = locationController.lat.value;
              // SingleTone.instance.lng = locationController.lng.value;
              Get.find<NewsfeedController>().postText = true;
              locationController.mainText = data.predict[index].structuredformatting.maintext;
              locationController.secondaryText = data.predict[index].structuredformatting.secondarytext;
              locationController.callApi(' ');
              locationController.locationTextController.text = locationController.mainText;
              // Selectedlocation(context: context);
              locationController.update();
              Get.find<NewsfeedController>().update();
              FocusScope.of(context).requestFocus(new FocusNode());
              await locationController.callApiLatLong(data.predict[index].placeid);

              Get.back();
            },
            child: _location(
              data: data.predict[index].structuredformatting,
              context: context,
              index: index,
            ),
          );
        },
      ),
    );
  }
}
