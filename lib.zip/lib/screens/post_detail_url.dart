import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:werfieapp/components/web_appbar.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/browse_screen.dart';
import 'package:werfieapp/screens/chat_screen.dart';
import 'package:werfieapp/screens/filter_screen.dart';
import 'package:werfieapp/screens/follower_following/follower_following_tab.dart';
import 'package:werfieapp/screens/notification_screen.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/screens/post_detail.dart';
import 'package:werfieapp/screens/trends_screen.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/screens/who_to_follow_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/web_views/web_newsfeed_right_section.dart';
import 'package:werfieapp/web_views/web_settings_screen.dart';
import 'package:werfieapp/widgets/newsfeed_mobile.dart';
import 'package:werfieapp/widgets/saved_post_mobile.dart';

// ignore: must_be_immutable
class PostDetailUrl extends StatelessWidget {
  // final userName;
  NewsfeedController controller = Get.put(NewsfeedController());

  PostDetailUrl();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () {
          controller.isSearch = false;
          controller.searchResult = [];
          if (controller.isBrowseScreen) {
            Get.find<BrowseController>().isSearch = false;
            Get.find<BrowseController>().searchResult = [];
            Get.find<BrowseController>().searchField = false;
            Get.find<BrowseController>().update();
          }
          controller.update();
        },
        child: Scaffold(
          body: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              WebAppBar(
                userName: controller.userName,
                controller: controller,
              ),
              Container(
                height: 2,
                color: Colors.grey[200],
              ),
              // Divider(
              //   thickness: 0,
              //   height: 2,
              // ),
              Expanded(
                child: Row(
                  children: [
                    webLeftSectionPost(context, controller),
                    Container(
                      width: 2,
                      color: Colors.grey[200],
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: controller.isSavedPostScreen ||
                                    controller.isChatScreen
                                ? 0
                                : 0),
                        child: controller.isNewsFeedScreen
                            ? NewsFeedMobile(
                                controller: controller,
                              )
                            : controller.isTrendsScreen
                                ? MobileTrendsScreen(controller: controller)
                                : controller.isWhoToFollowScreen
                                    ? WhoToFollow(controller: controller)
                                    : controller.isProfileScreen
                                        ? ProfileScreen(controller: controller)
                                        : controller.isBrowseScreen
                                            ? BrowseScreen(
                                                controller: controller)
                                            // ? MobileQuestScreen(controller: controller)
                                            : controller.isNotificationScreen
                                                ? NotificationScreen()
                                                : controller.isSavedPostScreen
                                                    ? MobileSavedPost(
                                                        newsFeedController:
                                                            controller)
                                                    : controller.isChatScreen
                                                        ? MobileChatScreen()
                                                        : controller
                                                                .isPostDetails
                                                            ? PostDetail(
                                                                controller:
                                                                    controller,
                                                                post: controller
                                                                    .selectedPost,
                                                              )
                                                            : controller
                                                                    .isFilterScreen
                                                                ? FilteredScreen(
                                                                    newsfeedController:
                                                                        controller)
                                                                : controller
                                                                        .isOtherUserProfileScreen
                                                                    ? OtherUsersProfile(
                                                                        controller:
                                                                            controller,
                                                                      )
                                                                    : controller
                                                                            .isClickWhoToFollow
                                                                        ? OtherUsersProfile(
                                                                            controller:
                                                                                controller,
                                                                          )
                                                                        : controller.isFollwerScreen
                                                                            ? FollowerScreen(controller: controller)
                                                                            : controller.isSettingsScreen
                                                                                ? WebSettingsScreen(controller: controller)
                                                                                : NewsFeedMobile(),
                      ),
                    ),
                    Container(
                      width: 2,
                      color: Colors.grey[200],
                    ),
                    !controller.isChatScreen && !controller.isSettingsScreen
                        ? WebNewsfeedRightSection(controller)
                        : Container(),
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget webLeftSectionPost(
      BuildContext context, NewsfeedController controller) {
    // print('jkhgjfgGHFGHFHGFHGFHGFHGFGHFHGFHFHG');
    return Container(
      width: MediaQuery.of(context).size.width * 0.25,
      child: Padding(
        padding: EdgeInsets.only(top: 20, left: 60, right: 80),
        child: ListView(
          children: [
            GestureDetector(
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = false;
                controller.isPostDetails = false;
                controller.isFollwerScreen = false;
                controller.isProfileScreen = true;
                controller.isSettingsScreen = false;
                controller.navRoute = "isProfileScreen";
                controller.update();
              },
              child: Align(
                  alignment: Alignment.center,
                  child: controller.userProfile == null
                      ? Container(
                          width: 24,
                          child: Center(
                            child: SpinKitCircle(
                              color: Colors.grey,
                              size: 40,
                            ),
                          ))
                      : controller.userProfile.profileImage == null
                          ? CircleAvatar(
                              radius: 36,
                              backgroundImage: AssetImage(
                                  "assets/images/person_placeholder.png"))
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(50),
                              child: FadeInImage(
                                  fit: BoxFit.cover,
                                  width: 80,
                                  height: 80,
                                  placeholder: AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  image: NetworkImage(controller
                                              .userProfile.profileImage !=
                                          null
                                      ? controller.userProfile.profileImage
                                      : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                            )),
            ),
            SizedBox(height: 6),
            GestureDetector(
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = false;
                controller.isPostDetails = false;
                controller.isFollwerScreen = false;
                controller.isProfileScreen = true;
                controller.isSettingsScreen = false;
                controller.navRoute = "isProfileScreen";
                controller.update();
              },
              child: Align(
                alignment: Alignment.center,
                child: Text(
                  controller.userName != null ? controller.userName : 'Alexa',
                  style: Theme.of(context).textTheme.headline3,
                ),
              ),
            ),
            SizedBox(height: 20),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isNewsFeedScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/Home.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/Home.png'),
                    ),
              title: Text(
                Strings.home,
                style: TextStyle(
                  // fontWeight: controller.isNewsFeedScreen,
                  // ? FontWeight.bold
                  // : FontWeight.normal,
                  fontSize: 18,
                  color: controller.isNewsFeedScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  // fontWeight: FontWeight.w900,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = true;
                controller.isWhoToFollowScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isChatScreen = false;
                controller.isSavedPostScreen = false;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isNewsFeedScreen";
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isBrowseScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/Browse.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/Browse.png'),
                    ),
              title: Text(
                Strings.browse,
                style: TextStyle(
                  color: controller.isBrowseScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isQuestScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = true;
                controller.isWhoToFollowScreen = false;
                controller.isNotificationScreen = false;
                controller.isChatScreen = false;
                controller.isSavedPostScreen = false;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isQuestScreen";
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isTrendsScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/hot_trends.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/hot_trends.png'),
                    ),
              title: Text(
                Strings.hotTrends,
                style: TextStyle(
                  color: controller.isTrendsScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isTrendsScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = true;
                controller.isNewsFeedScreen = false;
                controller.isWhoToFollowScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isChatScreen = false;
                controller.isSavedPostScreen = false;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isTrendsScreen";
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isSavedPostScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/saved.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/saved.png'),
                    ),
              title: Text(
                Strings.saved,
                style: TextStyle(
                  color: controller.isSavedPostScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isSavedPostScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isSavedPostScreen = true;
                controller.isWhoToFollowScreen = false;
                controller.isChatScreen = false;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isSavedPostScreen";
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isChatScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/messages.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/messages.png'),
                    ),
              title: Text(
                Strings.messages,
                style: TextStyle(
                  color: controller.isChatScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isChatScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () async {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isWhoToFollowScreen = false;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = true;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isChatScreen";
                controller.chatUserList = await controller.getChat();
                // print("preesssseddd");
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isProfileScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/profile.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/profile.png'),
                    ),
              title: Text(
                Strings.myProfile,
                style: TextStyle(
                  color: controller.isProfileScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isProfileScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isWhoToFollowScreen = false;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = false;
                controller.isPostDetails = false;
                controller.isFollwerScreen = false;
                controller.isProfileScreen = true;
                controller.isSettingsScreen = false;
                controller.navRoute = "isProfileScreen";
                controller.update();
              },
            ),
            SizedBox(height: 10),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isSettingsScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/settings.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child: Image.asset('assets/drawer_icons/settings.png'),
                    ),
              title: Text(
                Strings.settings,
                style: TextStyle(
                  color: controller.isSettingsScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isSettingsScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isWhoToFollowScreen = false;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = false;
                controller.isPostDetails = false;
                controller.isFollwerScreen = false;
                controller.isProfileScreen = false;
                controller.isSettingsScreen = true;
                controller.navRoute = "isSettingsScreen";
                controller.update();
              },
            ),
            ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              horizontalTitleGap: 18,
              leading: !controller.isNotificationScreen
                  ? Container(
                      width: 24,
                      height: 24,
                      child:
                          Image.asset('assets/drawer_icons/Notification.png'),
                    )
                  : Container(
                      width: 24,
                      height: 24,
                      child:
                          Image.asset('assets/drawer_icons/Notification.png'),
                    ),
              title: Text(
                Strings.notifications,
                style: TextStyle(
                  color: controller.isNotificationScreen
                      ? Color(0xFFedab30)
                      : Colors.black,
                  fontSize: 18,
                  // fontWeight: FontWeight.w900,
                  // fontWeight: controller.isNotificationScreen
                  //     ? FontWeight.bold
                  //     : FontWeight.normal,
                ),
              ),
              onTap: () {
                controller.isSearch = false;
                controller.isFilter = false;
                controller.isFilterScreen = false;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = true;
                controller.isSavedPostScreen = false;
                controller.isChatScreen = false;
                controller.isWhoToFollowScreen = false;
                controller.isPostDetails = false;
                controller.isProfileScreen = false;
                controller.isFollwerScreen = false;
                controller.isSettingsScreen = false;
                controller.navRoute = "isNotificationScreen";
                controller.update();
              },
            ),
            PopupMenuButton(
              padding: EdgeInsets.zero,
              offset: Offset(6, -220),
              onSelected: (value) {
                // print(value);
              },
              child: ListTile(
                contentPadding:
                    EdgeInsets.symmetric(vertical: 0, horizontal: 6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
                horizontalTitleGap: 18,
                leading: Container(
                  width: 24,
                  height: 24,
                  child: Image.asset('assets/drawer_icons/more.png'),
                ),
                title: Text(
                  Strings.more,
                  style: Theme.of(context).brightness == Brightness.dark
                      ? TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18)
                      : TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 18),
                ),
              ),
              itemBuilder: (BuildContext context) => <PopupMenuEntry>[
                popUpMenuItem(
                  'assets/drawer_icons/about.png',
                  Strings.about,
                  1,
                  () {},
                ),
                popUpMenuItem(
                    'assets/drawer_icons/help.png', Strings.help, 2, () {}),
                popUpMenuItem('assets/drawer_icons/privacy_policy.png',
                    Strings.privacyPolicy, 3, () {}),
                popUpMenuItem(
                    'assets/drawer_icons/blogs.png', Strings.blog, 4, () {}),
                popUpMenuItem('assets/drawer_icons/terms_and_conditions.png',
                    Strings.termsOfService, 5, () {}),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget popUpMenuItem(
      String iconImage, String s, int value, Function function) {
    return PopupMenuItem(
      value: value,
      child: ListTile(
        hoverColor: Colors.transparent,
        leading:
            Container(width: 24, height: 24, child: new Image.asset(iconImage)),
        title: Text(
          s,
        ),
        onTap: function,
      ),
    );
  }
}
