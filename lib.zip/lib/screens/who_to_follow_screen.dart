import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/get_follower.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';

import 'package:werfieapp/utils/strings.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';

import '../network/singleTone.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import '../widgets/blue_tick.dart';

class WhoToFollow extends StatefulWidget {
  const WhoToFollow({Key key, this.controller}) : super(key: key);

  final NewsfeedController controller;

  @override
  State<WhoToFollow> createState() => _WhoToFollowState();
}

class _WhoToFollowState extends State<WhoToFollow> {
  @override
  void initState() {
    super.initState();
    initialize();
  }

  void initialize() async{
   await widget.controller.followSuggestions();
   // print('MAIn WHO TO FOLLOW SCREEN MAI HU');
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return WillPopScope(
          onWillPop: () async {
            controller.isBrowseScreen = false;
            controller.isNewsFeedScreen = true;
            controller.isTrendsScreen = false;
            controller.isWhoToFollowScreen = false;
            controller.isNotificationScreen = false;
            controller.isChatScreen = false;
            controller.isSavedPostScreen = false;
            controller.isProfileScreen = false;
            controller.isSettingsScreen = false;
            controller.update();
            Navigator.pop(context);
            return false;
          },
          child: Scaffold(
            appBar: !Responsive.isDesktop(context)
                ? kIsWeb
                    ? AppBar(
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        iconTheme: const IconThemeData(
                          color: Color(0xFF4f515b),
                        ),
                        title: SizedBox(
                          height: 45,
                          width: MediaQuery.of(context).size.width * 0.7,
                        ),
                        // automaticallyImplyLeading: !Responsive.isDesktop(context) ? true : false,
                      )
                    : AppBar(
                        automaticallyImplyLeading: false,
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                        iconTheme: const IconThemeData(
                          color: Color(0xFF4f515b),
                        ),
                        title: Row(
                          children: [
                            GestureDetector(
                                onTap: () {
                                  Get.back();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                )),
                            const Spacer(),
                            Text(
                              Strings.whoToFollow,
                              textAlign: TextAlign.left,
                              // style: Theme.of(context)
                              //     .textTheme
                              //     .headline6
                              //     .copyWith(
                              //       fontSize: 18,
                              //       fontWeight: FontWeight.w700,
                              //       color: Colors.black,
                              //     ),
                              style: Styles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20
                              ),
                            ),
                            const Spacer(),
                          ],
                        ),
                        //  automaticallyImplyLeading: !Responsive.isDesktop(context) ? true : false,
                      )
                : PreferredSize(
                    preferredSize: const Size(0.0, 0.0),
                    child: Container(),
                  ),
            // drawer: !Responsive.isDesktop(context) ? MainDrawer(controller) : Container(),
            // drawerEnableOpenDragGesture:
            //     !Responsive.isDesktop(context) ? false : true,
            // !kIsWeb
            //     ? AppBar(
            //   centerTitle: true,
            //   title: Text(
            //     Strings.whoToFollow,
            //   ),
            // )
            //     : PreferredSize(
            //   child: Container(),
            //   preferredSize: Size(0, 0),
            // ),
            body: kIsWeb
                ? SingleChildScrollView(
                  child: Stack(
                      children: [
                        Column(
                          children: [
                            kIsWeb
                                ? Padding(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 16.0,
                                      horizontal: 12,
                                    ),
                                    child: Row(
                                      children: [
                                        GestureDetector(
                                            onTap: () {
                                              // print("12133");
                                              // controller.isSearch = false;
                                              // controller.isFilter = false;
                                              // controller.isFilterScreen = false;
                                              // controller.isTrendsScreen = false;
                                              // controller.isNewsFeedScreen = true;
                                              // controller.isBrowseScreen = false;
                                              // controller.isNotificationScreen = false;
                                              // controller.isChatScreen = false;
                                              // controller.isSavedPostScreen = false;
                                              // controller.isPostDetails = false;
                                              // controller.isProfileScreen = false;
                                              // controller.isFollwerScreen = false;
                                              // controller.isWhoToFollowScreen = false;
                                              // controller.isSettingsScreen = false;
                                              // controller.navRoute = "isNewsFeedScreen";
                                              //
                                              // controller.update();
                                              // print("kkkkrtrtr");
                                              Navigator.of(context).pop();
                                            },
                                            child: MouseRegion(
                                                cursor: MouseCursor.defer,
                                                child: Icon(
                                                  Icons.arrow_back,
                                                  color: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                ))),
                                        const SizedBox(
                                          width: 20,
                                        ),
                                        Expanded(
                                          child: Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              Strings.whoToFollow,
                                              textAlign: TextAlign.left,
                                              // style: Theme.of(context)
                                              //     .textTheme
                                              //     .headline6
                                              //     .copyWith(
                                              //       fontSize: 18,
                                              //       fontWeight: FontWeight.w700,
                                              //       color: Colors.black,
                                              //     ),
                                              style: Styles
                                                  .baseTextTheme.headline2
                                                  .copyWith(
                                                color: Theme.of(context)
                                                            .brightness ==
                                                        Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 20
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  )
                                : Container(),
                            // Container(
                            //   height: 1,
                            //   color: Colors.grey[300],
                            // ),
                            controller.isWhoToFollow == true
                                ? const Padding(
                                    padding: EdgeInsets.only(top: 20.0),
                                    child: Center(
                                      child: CircularProgressIndicator(
                                        color: MyColors.BlueColor,
                                      ),
                                    ),
                                  )
                                : controller.followSuggestionsList == null ||
                                        controller.followSuggestionsList.isEmpty
                                    ? Center(child: Text(Strings.noSuggestion))
                                    : Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: List.generate(
                                          controller.followSuggestionsList
                                              .length, (index) {
                                        return InkWell(
                                          hoverColor:
                                              Colors.grey.withOpacity(0.1),
                                            onTap: kIsWeb
                                                ? () async {
                                                    // print("kisweb");
                                                    onHomeChange = false;
                                                    onBrowsChange = false;
                                                    onTrendsChange = false;
                                                    onBookMarksChange = false;
                                                    onChatsChange = false;
                                                    onProfileChange = false;
                                                    onSettingChange = false;
                                                    onListChange = false;
                                                    onNotificationChange = false;
                                                    onMoreChange = false;

                                                    Get.find<NewsfeedController>().userInfo = UserProfile();
                                                    Get.find<NewsfeedController>().update();
                                                    await _clickWho(controller.followSuggestionsList[index]);
                                                  }
                                                : () async {
                                                    await _clickWho(controller.followSuggestionsList[index]);

                                                    if(!mounted) return;
                                                    Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                            builder: (BuildContext context) => OtherUsersProfile(controller: controller)));
                                                  },
                                            child: Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 10),
                                              child: Column(
                                                children: [
                                                  ListTile(
                                                  minVerticalPadding: 0,
                                                  leading: controller
                                                              .userProfile ==
                                                          null
                                                      ? SizedBox(
                                                          width: 24,
                                                          child: Center(
                                                            child: SpinKitCircle(
                                                              color: Colors.grey,
                                                              size: 40,
                                                            ),
                                                          ))
                                                      : controller
                                                                  .followSuggestionsList[
                                                                      index]
                                                                  .profileImage ==
                                                              null
                                                          ? const CircleAvatar(
                                                              radius: 25,
                                                              backgroundImage:
                                                                  AssetImage(
                                                                      "assets/images/person_placeholder.png"))
                                                          : ClipRRect(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          30),
                                                              child: FadeInImage(
                                                                  fit: BoxFit
                                                                      .cover,
                                                                  width: 50,
                                                                  height: 50,
                                                                  placeholder:
                                                                      const AssetImage(
                                                                          'assets/images/person_placeholder.png'),
                                                                  image: NetworkImage(controller
                                                                          .followSuggestionsList[
                                                                              index]
                                                                          .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                            ),
                                                  title: Align(
                                                    alignment:
                                                        Alignment.bottomLeft,

                                                    ///blue tick

                                                    child: Row(
                                                      children: [
                                                        Text(
                                                          controller.followSuggestionsList[index].name,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 18,
                                                          ),
                                                        ),
                                                        controller
                                                                    .followSuggestionsList[
                                                                        index]
                                                                    .accountVerified ==
                                                                "verified"
                                                            ? Row(
                                                                children: [
                                                                  const SizedBox(
                                                                    width: 5,
                                                                  ),
                                                                  BlueTick(
                                                                    height: 15,
                                                                    width: 15,
                                                                    iconSize: 10,
                                                                  ),
                                                                ],
                                                              )
                                                            : const SizedBox(),
                                                      ],
                                                    ),
                                                  ),
                                                  subtitle: Align(
                                                    alignment: Alignment.topLeft,
                                                    child: Text(
                                                      '@${controller.followSuggestionsList[index].username}',
                                                      style: Styles
                                                          .baseTextTheme.headline2
                                                          .copyWith(
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontSize:
                                                              16,
                                                      ),
                                                    ),
                                                  ),
                                                  trailing: ClipRRect(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              20),
                                                      child: MediaQuery.of(
                                                                      context)
                                                                  .size
                                                                  .width <=
                                                              1250
                                                          ? SizedBox(
                                                              width: 100,
                                                              height: 35,
                                                              child:
                                                                  MaterialButton(
                                                                padding:
                                                                    const EdgeInsets
                                                                        .all(4), shape: RoundedRectangleBorder(
                                                                    borderRadius: BorderRadius.circular(20),
                                                                    side:  BorderSide(color:
                                                                    Theme.of(context).brightness == Brightness.dark?
                                                                    !controller.followSuggestionsList[index].isFollow?
                                                                    Colors.white:Colors.grey:
                                                                    !controller.followSuggestionsList[index].isFollow?
                                                                    Colors.black
                                                                      : Colors.grey),
                                                                  ),

                                                                color:
                                                                Theme.of(context)
                                                                            .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                    ? !controller
                                                                            .followSuggestionsList[
                                                                                index]
                                                                            .isFollow
                                                                        ? Colors
                                                                            .white
                                                                        : Colors
                                                                            .black
                                                                    : !controller
                                                                            .followSuggestionsList[
                                                                                index]
                                                                            .isFollow
                                                                        ? Colors
                                                                            .black
                                                                        : Colors
                                                                            .white,
                                                                onPressed:
                                                                    () async {
                                                                  if (controller
                                                                          .followSuggestionsList[
                                                                              index]
                                                                          .isFollow ==
                                                                      false) {
                                                                    controller
                                                                        .followSuggestionsList[
                                                                            index]
                                                                        .isFollow = true;
                                                                    controller
                                                                        .update();
                                                                    await controller.addFollowing(
                                                                        controller
                                                                            .followSuggestionsList[
                                                                                index]
                                                                            .id,
                                                                        "follow");
                                                                  } else if (controller
                                                                          .followSuggestionsList[
                                                                              index]
                                                                          .isFollow ==
                                                                      true) {
                                                                    controller
                                                                        .followSuggestionsList[
                                                                            index]
                                                                        .isFollow = false;
                                                                    await controller.addFollowing(
                                                                        controller
                                                                            .followSuggestionsList[
                                                                                index]
                                                                            .id,
                                                                        "unFollow");
                                                                    controller
                                                                        .update();
                                                                  }
                                                                },
                                                                child: Text(
                                                                  !controller
                                                                          .followSuggestionsList[
                                                                              index]
                                                                          .isFollow
                                                                      ? "${Strings.follow}"
                                                                          .capitalizeFirst
                                                                      : "${Strings.unFollow}"
                                                                          .capitalizeFirst,
                                                                  style: TextStyle(
                                                                      color: Theme.of(context).brightness == Brightness.dark
                                                                          ? !controller.followSuggestionsList[index].isFollow
                                                                              ? Colors.black
                                                                              : Colors.white
                                                                          : !controller.followSuggestionsList[index].isFollow
                                                                              ? Colors.white
                                                                              : Colors.black,
                                                                      fontWeight: FontWeight.bold,
                                                                      fontSize: 16,
                                                                      height: 1.2),
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                ),
                                                              ),
                                                            )
                                                          : SizedBox(
                                                              height: 35,
                                                              width: 100,
                                                              child:
                                                                  UnfollowBtnWidget(
                                                                index,
                                                                controller,
                                                                key: Key(index
                                                                    .toString()),
                                                              ))),
                                          ),
                                                  controller.followSuggestionsList[index].bio ==null?const SizedBox():
                                                  Padding(
                                                    padding: const EdgeInsets.only(left: 82,right: 14),
                                                    child: Text(
                                                        controller.followSuggestionsList[index].bio ,
                                                        overflow: TextOverflow.ellipsis,
                                                        maxLines: 2,
                                                        style: TextStyle(
                                                            fontSize: 16,
                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                ? Colors.white
                                                                : Colors.black
                                                        )
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                        );
                                      }),
                                    ),
                          ],
                        ),
                      ],
                    ),
                )
                : Column(
                    children: [
                      kIsWeb
                          ? Padding(
                              padding: const EdgeInsets.symmetric(
                                vertical: 16.0,
                                horizontal: 12,
                              ),
                              child: Row(
                                children: [
                                  GestureDetector(
                                      onTap: () {
                                        controller.isSearch = false;
                                        controller.isFilter = false;
                                        controller.isFilterScreen = false;
                                        controller.isTrendsScreen = false;
                                        controller.isNewsFeedScreen = true;
                                        controller.isBrowseScreen = false;
                                        controller.isNotificationScreen =
                                            false;
                                        controller.isChatScreen = false;
                                        controller.isSavedPostScreen = false;
                                        controller.isPostDetails = false;
                                        controller.isProfileScreen = false;
                                        controller.isFollwerScreen = false;
                                        controller.isWhoToFollowScreen =
                                            false;
                                        controller.isSettingsScreen = false;
                                        controller.navRoute =
                                            "isNewsFeedScreen";
                                        controller.update();
                                      },
                                      child: Icon(
                                        Icons.arrow_back,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      )),
                                  Expanded(
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                        Strings.whoToFollow,
                                        textAlign: TextAlign.left,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color:
                                              Theme.of(context).brightness ==
                                                      Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 14,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Container(),
                      Container(
                        height: 1,
                        color: Colors.grey[300],
                      ),
                      controller.isWhoToFollow == true
                          ? const Padding(
                              padding: EdgeInsets.only(top: 20.0),
                              child: Center(
                                child: CircularProgressIndicator(
                                  color: MyColors.BlueColor,
                                ),
                              ),
                            )
                          : controller.followSuggestionsList == null ||
                                  controller.followSuggestionsList.isEmpty
                              ? Center(child: Text(Strings.noSuggestion))
                              : Expanded(
                                child: ListView.builder(
                                    itemCount: controller
                                        .followSuggestionsList.length,
                                    itemBuilder: (context, index) {
                                      return InkWell(
                                        key: Key(index.toString()),
                                        hoverColor: Colors.grey
                                            .withOpacity(0.1),
                                          onTap: kIsWeb
                                              ? () async {


                                                  Get.find<NewsfeedController>().userInfo = UserProfile();
                                                  Get.find<NewsfeedController>().update();
                                                  await _clickWho(controller.followSuggestionsList[index]);
                                                }
                                              : () async {
                                                  await _clickWho(controller.followSuggestionsList[index]);
                                                  Get.to(() => OtherUsersProfile(
                                                        controller: controller,
                                                      ));
                                                  // Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => OtherUsersProfile(controller: controller)));
                                                },
                                          child: Column(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              ListTile(
                                              minVerticalPadding: 0,
                                              leading: controller
                                                          .userProfile ==
                                                      null
                                                  ? SizedBox(
                                                      width: 24,
                                                      child: Center(
                                                        child:
                                                            SpinKitCircle(
                                                          color:
                                                              Colors.grey,
                                                          size: 40,
                                                        ),
                                                      ))
                                                  : controller
                                                              .followSuggestionsList[
                                                                  index]
                                                              .profileImage ==
                                                          null
                                                      ? const CircleAvatar(
                                                          radius: 25,
                                                          backgroundImage:
                                                              AssetImage(
                                                                  "assets/images/person_placeholder.png"))
                                                      : CircleAvatar(
                                                radius: 25,
                                                        backgroundColor: Colors.transparent,
                                                        child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        30),
                                                            child: FadeInImage(
                                                                fit: BoxFit
                                                                    .cover,
                                                                width: 50,
                                                                height: 50,
                                                                placeholder:
                                                                    const AssetImage(
                                                                        'assets/images/person_placeholder.png'),
                                                                image: NetworkImage(controller
                                                                        .followSuggestionsList[index]
                                                                        .profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
                                                          ),
                                                      ),
                                              title: Align(
                                                alignment:
                                                    Alignment.bottomLeft,

                                                ///blue tick

                                                child: Row(
                                                  children: [
                                                    Text(
                                                      controller.followSuggestionsList[index].name,
                                                      style: Styles
                                                          .baseTextTheme
                                                          .headline2
                                                          .copyWith(
                                                        color: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness
                                                                    .dark
                                                            ? Colors.white
                                                            : Colors
                                                                .black,
                                                        fontWeight:
                                                            FontWeight
                                                                .bold,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                    controller
                                                                .followSuggestionsList[
                                                                    index]
                                                                .accountVerified ==
                                                            "verified"
                                                        ? Row(
                                                            children: [
                                                              const SizedBox(
                                                                width: 5,
                                                              ),
                                                              BlueTick(
                                                                height:
                                                                    15,
                                                                width: 15,
                                                                iconSize:
                                                                    10,
                                                              ),
                                                            ],
                                                          )
                                                        : const SizedBox(),
                                                  ],
                                                ),
                                              ),
                                              subtitle: Align(
                                                alignment:
                                                    Alignment.topLeft,
                                                child: Text(
                                                  '@${controller.followSuggestionsList[index].username}',
                                                  style: Styles
                                                      .baseTextTheme
                                                      .headline2
                                                      .copyWith(
                                                    // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                    // fontWeight: FontWeight.w500,
                                                    fontSize:
                                                        kIsWeb ? 15 : 15,
                                                  ),
                                                ),
                                              ),
                                              trailing: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        20),
                                                child:
                                                    MediaQuery.of(context)
                                                                .size
                                                                .width <=
                                                            1250
                                                        ? SizedBox(
                                                            width:
                                                                Get.width /
                                                                    4.45,
                                                            height: 30,

                                                            ///
                                                            child:
                                                                UnfollowBtnWidget(
                                                              index,
                                                              controller,
                                                              key: Key(index
                                                                  .toString()),
                                                            ),
                                                          )
                                                        : SizedBox(
                                                            width:
                                                               100,
                                                            height: 30,
                                                            child:
                                                                MaterialButton(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(4),
                                                              color: Theme.of(context).brightness ==
                                                                      Brightness.dark
                                                                  ? !controller.followSuggestionsList[index].isFollow
                                                                      ? Colors.white
                                                                      : Colors.black
                                                                  : !controller.followSuggestionsList[index].isFollow
                                                                      ? Colors.black
                                                                      : Colors.white,
                                                              onPressed:
                                                                  () async {
                                                                if (controller
                                                                        .followSuggestionsList[
                                                                            index]
                                                                        .isFollow ==
                                                                    false) {
                                                                  controller
                                                                      .followSuggestionsList[index]
                                                                      .isFollow = true;
                                                                  controller
                                                                      .update();
                                                                  await controller.addFollowing(
                                                                      controller.followSuggestionsList[index].id,
                                                                      "follow");
                                                                } else if (controller
                                                                        .followSuggestionsList[index]
                                                                        .isFollow ==
                                                                    true) {
                                                                  controller
                                                                      .followSuggestionsList[index]
                                                                      .isFollow = false;
                                                                  await controller.addFollowing(
                                                                      controller.followSuggestionsList[index].id,
                                                                      "unFollow");
                                                                  controller
                                                                      .update();
                                                                }
                                                                print(
                                                                    "${controller.followSuggestionsList[index].username}");
                                                                print(
                                                                    "${controller.followSuggestionsList[index].id}");
                                                              },
                                                              child: Text(
                                                                !controller
                                                                        .followSuggestionsList[
                                                                            index]
                                                                        .isFollow
                                                                    ? "${Strings.follow}"
                                                                        .capitalizeFirst
                                                                    : Strings.following,
                                                                style: TextStyle(
                                                                    fontSize: 14,
                                                                    color: Theme.of(context).brightness == Brightness.dark
                                                                        ? !controller.followSuggestionsList[index].isFollow
                                                                            ? Colors.black
                                                                            : Colors.white
                                                                        : !controller.followSuggestionsList[index].isFollow
                                                                            ? Colors.white
                                                                            : Colors.black,
                                                                    fontWeight: FontWeight.bold),
                                                              ),
                                                            ),
                                                          ),
                                              ),
                                        ),

                                              controller.followSuggestionsList[index].bio ==null?const SizedBox():
                                              Padding(
                                               padding: const EdgeInsets.only(left: 82,right: 14),
                                               child: Text(controller.followSuggestionsList[index].bio ,
                                               overflow: TextOverflow.ellipsis,
                                                 maxLines: 2,
                                                 style: TextStyle(
                                                     fontSize: 15,
                                                     color: Theme.of(context).brightness == Brightness.dark
                                                         ? Colors.white
                                                         : Colors.black
                                                 )
                                               ),
                                             ),
                                            ],
                                          ),
                                      );
                                    }),
                              ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  Future<void> _clickWho(GetFollowerModel post) async {

    if (kIsWeb) {
      Get.offNamed(FluroRouters.mainScreen + "/profile/" + post.id.toString());
      widget.controller.otherUserId = post.id;
      widget.controller.isProfileScreen = false;
      widget.controller.isWhoToFollowScreen = false;
      widget.controller.isOtherUserProfileScreen = true;
      widget.controller.isTrendsScreen = false;
      widget.controller.isNewsFeedScreen = false;
      widget.controller.isBrowseScreen = false;
      widget.controller.isNotificationScreen = false;
      widget.controller.isChatScreen = false;
      widget.controller.isPostDetails = false;
      widget.controller.isSettingsScreen = false;
      widget.controller.isListScreen = false;
    }

    try {

      SingleTone.instance.userId = post.id.toString();

      // Get.find<NewsfeedController>().userInfo = UserProfile();
      Get.find<NewsfeedController>().userInfo =
          await widget.controller.getOtherUserProfile(post.id);

      await Get.find<OtherUserController>()
          .filterUsersPostPagged("posts", page: 1);
      Get.find<OtherUserController>().userPosts.forEach((element) {
        element.mute = Get.find<NewsfeedController>().userInfo.muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {}
    widget.controller.update();
    // try{
    //   if(controller.isOtherUserProfileScreen || controller.isClickWhoToFollow){
    //     final otherUserController = Get.find<OtherUserController>();
    //     controller.otherUserId = post.id;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isClickWhoToFollow = true;
    //     controller.isWhoToFollowScreen = false;
    //     controller.isOtherUserProfileScreen = false;
    //     controller.isTrendsScreen = false;
    //     controller.isNewsFeedScreen = false;
    //     controller.isQuestScreen = false;
    //     controller.isNotificationScreen = false;
    //     controller.isChatScreen = false;
    //     controller.isPostDetails = false;
    //     otherUserController.update();
    // } else {

    // }finally{
  }


}



class UnfollowBtnWidget extends StatefulWidget {
 final int index;
 final NewsfeedController controller;

  const UnfollowBtnWidget(
    this.index,
    this.controller, {
    Key key,
  }) : super(key: key);

  @override
  State<UnfollowBtnWidget> createState() => _UnfollowBtnWidgetState();
}

class _UnfollowBtnWidgetState extends State<UnfollowBtnWidget> {
  bool isLoadFollowing = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: isLoadFollowing
          ? const Center(
              child: SizedBox(
                  height: 30, width: 30, child: CircularProgressIndicator()))
          : MaterialButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side:  BorderSide(color:
          Theme.of(context).brightness == Brightness.dark?
          !widget.controller.followSuggestionsList[widget.index].isFollow?
              Colors.white:Colors.grey:
          !widget.controller.followSuggestionsList[widget.index].isFollow?
          Colors.black:Colors.grey
         ),
        ),
              padding: const EdgeInsets.all(4),
              color:
              Theme.of(context).brightness == Brightness.dark
                  ? !widget.controller.followSuggestionsList[widget.index]
                          .isFollow
                      ? Colors.white
                      : Colors.black
                  : !widget.controller.followSuggestionsList[widget.index]
                          .isFollow
                      ? Colors.black
                      : Colors.white,
              onPressed: () async {
                setState(() {
                  isLoadFollowing = true;
                });

                if (widget.controller.followSuggestionsList[widget.index]
                        .isFollow ==
                    false) {
                  widget.controller.followSuggestionsList[widget.index]
                      .isFollow = true;
                  widget.controller.update();

                  await widget.controller.addFollowing(
                      widget.controller.followSuggestionsList[widget.index].id,
                      "follow");
                  isLoadFollowing = false;
                  setState(() {});
                } else if (widget.controller.followSuggestionsList[widget.index]
                        .isFollow ==
                    true) {
                  widget.controller.followSuggestionsList[widget.index]
                      .isFollow = false;
                  await widget.controller.addFollowing(
                      widget.controller.followSuggestionsList[widget.index].id,
                      "unFollow");
                  widget.controller.update();
                  isLoadFollowing = false;
                  setState(() {});
                }
              },
              child: Text(
                !widget.controller.followSuggestionsList[widget.index].isFollow
                    ? "${Strings.follow}".capitalizeFirst
                    : Strings.following,
                style: TextStyle(
                    height: 1.2,
                    fontSize: kIsWeb ? 16 : 14,
                    color: Theme.of(context).brightness == Brightness.dark
                        ? !widget.controller.followSuggestionsList[widget.index]
                                .isFollow
                            ? Colors.black
                            : Colors.white
                        : !widget.controller.followSuggestionsList[widget.index]
                                .isFollow
                            ? Colors.white
                            : Colors.black,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ),
    );
  }
}
