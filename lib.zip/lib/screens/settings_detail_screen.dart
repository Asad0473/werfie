import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/language_settings.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/listtile_settings.dart';

import '../utils/font.dart';
import 'privacy_and_safety/mute_and_block/mobile_blocked_accounts_screen.dart';

class SettingsDetailScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();
  final String settingsType;

  SettingsDetailScreen({this.settingsType});

  // static const List settings = [
  //   'Blocked accounts (add, view or remove)',
  //   'Language Settings',
  //   'Translations',
  //   'Security and Account Access',
  //   'Accessibility and Languages',
  // ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Theme.of(context).brightness == Brightness.dark
                  ? Colors.black
                  : Colors.white,
              iconTheme: IconThemeData(
                color: Color(0xFF4f515b),
              ),
              title: Container(
                width: Get.width / 1.5,
                child: Center(
                  child: Text(
                    settingsType != null ? settingsType : Strings.settingsType,
                    textAlign: TextAlign.left,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                    // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                    //     fontSize: 18,fontWeight: FontWeight.w700
                    // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,
                  ),
                  // style: Theme.of(context).textTheme.headline6.copyWith(
                  //       fontSize: 18,
                  //       fontWeight: FontWeight.w700,
                  //       color: Colors.black,
                  //     ),
                ),
              ),
            )
          : PreferredSize(
              child: Container(),
              preferredSize: Size(0, 0),
            ),
      body: Column(
        children: [
          !kIsWeb
              ? Container()
              : Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 16.0,
                    horizontal: 12,
                  ),
                  child: Align(
                    alignment: Alignment.center,
                    child: Row(
                      children: [
                        MediaQuery.of(context).size.width >= 1050
                            ? SizedBox()
                            : IconButton(
                                onPressed: () {
                                  controller.isSettingDetail = true;
                                  controller.isSettingTypeDetail = false;
                                  controller.update();
                                },
                                icon: Icon(Icons.arrow_back),
                              ),
                        Text(
                          Strings.settingsType,
                          textAlign: TextAlign.left,
                          style: Styles.baseTextTheme.headline1.copyWith(
                              color: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontSize: controller.languageData.appLang.id == 2
                                  ? 22
                                  : 18,
                              fontWeight:
                                  controller.languageData.appLang.id == 2
                                      ? FontWeight.bold
                                      : FontWeight.normal),
                          // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                          //     fontSize: 18,fontWeight: FontWeight.w700
                          // ) : TextStyle(color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,
                          //
                          //
                          // ),
                          // style: Theme.of(context).textTheme.headline6.copyWith(
                          //       fontSize: 18,
                          //       fontWeight: FontWeight.w700,
                          //       color: Colors.black,
                          //     ),
                        ),
                      ],
                    ),
                  ),
                ),
          Container(
            height: 1,
            color: Colors.grey[300],
          ),
          controller.isLanguageSettings
              ? Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(
                        top: 10,
                      ),
                      child: Text(
                        Strings.updateYourLanguageAndTranslation,
                        // Strings.manageHowBuzzNBeeContentIsDisplayedToYou,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        style: Styles.baseTextTheme.headline2.copyWith(
                            fontSize: kIsWeb
                                ? controller.languageData.appLang.id == 2
                                    ? 18
                                    : 14
                                : 12,
                            fontWeight: controller.languageData.appLang.id == 2
                                ? FontWeight.bold
                                : FontWeight.normal),
                        // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                        //     fontSize: 14,fontWeight: FontWeight.w900
                        // ) : TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.w900,
                        //
                        //
                        // ),
                        // style: TextStyle(
                        //     fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                    ),
                    ListTileSettings(
                      Strings.selectYourProfileLanguage,
                      Icons.arrow_forward_ios,
                      () async {
                        controller.isLanguageType = false;
                        controller.isProfileLanguagetype = true;
                        controller.isBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isListOfBlockedAccounts = false;
                        controller.isLanguageSettings = true;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = true;
                        print("njkdjfnkjnf");
                        print(controller.isLanguageType.toString());
                        print(controller.isProfileLanguagetype.toString());
                        print(controller.isTranslations.toString());
                        print(controller.isLanguageSettings.toString());
                        print("njkdjfnkjnf");

                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        LanguageSettings()))
                            : Container();
                      },
                      false,
                      FontWeight.w500,
                    ),
                    ListTileSettings(
                      Strings.selectYourAppLanguage,
                      Icons.arrow_forward_ios,
                      () {
                        controller.isBlockedAccounts = false;
                        controller.isTranslations = false;
                        controller.isProfileLanguagetype = false;
                        controller.isListOfBlockedAccounts = false;
                        controller.isLanguageSettings = true;
                        controller.isSettingDetail = false;
                        controller.isSettingTypeDetail = true;
                        controller.isLanguageType = true;
                        print("njkdjfnkjnf");
                        print(controller.isLanguageType.toString());
                        print(controller.isProfileLanguagetype.toString());
                        print(controller.isTranslations.toString());
                        print(controller.isLanguageSettings.toString());
                        print("njkdjfnkjnf");
                        controller.update();
                        !kIsWeb
                            ?
                        Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        LanguageSettings()))
                            : Container();
                      },
                      false,
                      FontWeight.w500,
                    ),
                    // ListTileSettings(Strings.enableDisableAutoTranslation,
                    //     Icons.arrow_forward_ios, () {}, false),
                  ],
                )
              : controller.isBlockedAccounts
                  ? Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                            top: 10,
                          ),
                          child: Text(
                            Strings.manageHowBuzzNBeeContentIsDisplayedToYou,
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            style: Styles.baseTextTheme.headline2.copyWith(
                              fontSize: 14,
                            ),
                            //   TextStyle(
                            //    color: Colors.white,
                            //     fontSize: 14,
                            //     fontWeight: FontWeight.bold
                            // ),
                          ),
                        ),
                        ListTileSettings(
                          Strings.viewListOfBlockedAccounts,
                          Icons.arrow_forward_ios,
                          () {
                            controller.isBlockedAccounts = false;
                            controller.isTranslations = false;
                            controller.isLanguageSettings = false;
                            controller.isProfileLanguagetype = false;
                            controller.isLanguageType = false;
                            controller.isBlockedAccounts = true;
                            controller.isListOfBlockedAccounts = true;
                            controller.update();
                            // !kIsWeb
                            //     ?
                            Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            MobileBlockedAccountsScreen()));
                                // : Container();
                          },
                          false,
                          FontWeight.w600,
                        ),
                      ],
                    )
                  : controller.isTranslations
                      ? Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 10,
                              ),
                              child: Text(
                                Strings
                                    .manageHowBuzzNBeeContentIsDisplayedToYou,
                                maxLines: 2,
                                textAlign: TextAlign.center,
                                style: Styles.baseTextTheme.headline2.copyWith(
                                  fontSize: 14,
                                ),
                                // Theme.of(context).brightness == Brightness.dark ? TextStyle(color: Colors.white,
                                //     fontSize: 14,fontWeight: FontWeight.bold
                                // ) : TextStyle(color: Colors.black,fontSize: 14,fontWeight: FontWeight.bold,
                                //
                                //
                                // ),
                                // style: TextStyle(
                                //     fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                            ),
                            ListTileSettings(
                              Strings.realTimePostTranslation,
                              Icons.arrow_forward_ios,
                              () {},
                              false,
                              FontWeight.w600,
                            ),
                            ListTileSettings(
                              Strings
                                  .selectLanguageTheTimeOfUploadingVideoOrAudio,
                              Icons.arrow_forward_ios,
                              () {},
                              false,
                              FontWeight.w600,
                            ),
                            ListTileSettings(
                              Strings.originalTranslatedScriptAudioPost,
                              Icons.arrow_forward_ios,
                              () {},
                              false,
                              FontWeight.w600,
                            ),
                            ListTileSettings(
                              Strings.listenTranslatedScript,
                              Icons.arrow_forward_ios,
                              () {},
                              false,
                              FontWeight.w600,
                            ),
                            ListTileSettings(
                              Strings
                                  .automaticallyTranslateMessagesChatUsersSelectedLanguage,
                              Icons.arrow_forward_ios,
                              () {},
                              false,
                              FontWeight.w600,
                            ),
                          ],
                        )
                      : controller.isAccountPrivacy
                          ? Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 10,
                                  ),
                                  child: Text(
                                    Strings.manageYourPrivacySettings,
                                    maxLines: 2,
                                    textAlign: TextAlign.center,
                                    style:
                                        Styles.baseTextTheme.headline2.copyWith(
                                      fontSize: kIsWeb ? 14 : 12,
                                    ),
                                    // TextStyle(
                                    //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //     fontSize: 14,
                                    //     fontWeight: FontWeight.bold
                                    // ),
                                  ),
                                ),
                                ListTileSettings(
                                  Strings.whoCanMessageYou,
                                  Icons.arrow_forward_ios,
                                  () async {
                                    controller.isBlockedAccounts = false;
                                    controller.isTranslations = false;
                                    controller.isListOfBlockedAccounts = false;
                                    controller.isLanguageSettings = false;
                                    controller.isLanguageType = false;
                                    controller.isAccountPrivacy = true;
                                    controller.isSettingDetail = false;
                                    controller.isSettingTypeDetail = true;
                                    controller.isAccountPrivacySettings = true;
                                    controller.userPrivacy =
                                        await controller.getUserCahtPrivacy();
                                    if (controller.userPrivacy == "no_one") {
                                      controller.radioValueAccount = 0;
                                    } else if (controller.userPrivacy ==
                                        "followers") {
                                      controller.radioValueAccount = 1;
                                    } else if (controller.userPrivacy ==
                                        "ever_one") {
                                      controller.radioValueAccount = 2;
                                    }
                                    // controller.update();

                                    controller.update();
                                    // !kIsWeb
                                    //     ?
                                    Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        LanguageSettings()));
                                        // : Container();
                                  },
                                  false,
                                  FontWeight.w500,
                                ),
                                // ListTileSettings(
                                //     'Who can mention you',
                                //     Icons.arrow_forward_ios,
                                //         () {},
                                //     false),
                                // ListTileSettings(
                                //     'Who can follow you',
                                //     Icons.arrow_forward_ios,
                                //         () {},
                                //     false),
                              ],
                            )
                          : controller.isNotificationsSettings
                              ? Column(
                                  children: [],
                                )
                              :
                              //    controller.isChangeUserName
                              //     ? Column(
                              //   children: [
                              //     Padding(
                              //       padding: const EdgeInsets.only(
                              //         top: 10,
                              //       ),
                              //       child: Text(
                              //         'Manage your Username settings',
                              //         maxLines: 2,
                              //         textAlign: TextAlign.center,
                              //         style: Styles.baseTextTheme.headline2.copyWith(
                              //           fontSize: kIsWeb ? 14 : 12,
                              //         ),
                              //         // TextStyle(
                              //         //     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                              //         //     fontSize: 14,
                              //         //     fontWeight: FontWeight.bold
                              //         // ),
                              //       ),
                              //     ),
                              //
                              //
                              //     // ListTileSettings(
                              //     //   "",
                              //     //   Icons.arrow_forward_ios, () async {
                              //     //   controller.isBlockedAccounts = false;
                              //     //   controller.isTranslations = false;
                              //     //   controller.isListOfBlockedAccounts = false;
                              //     //   controller.isLanguageSettings = false;
                              //     //   controller.isLanguageType = false;
                              //     //   controller.isAccountPrivacy = false;
                              //     //   controller.isAccountPrivacySettings = false;
                              //     //   controller.update();
                              //     //   !kIsWeb
                              //     //       ? Navigator.push(
                              //     //       context,
                              //     //       MaterialPageRoute(builder: (BuildContext context) => LanguageSettings()))
                              //     //       : Container();
                              //     // },
                              //     //   true,
                              //     //   FontWeight.w500,
                              //     // ),
                              //   ],
                              // )

                              Column(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                        top: 10,
                                      ),
                                      child: Text(
                                        Strings
                                            .manageHowBuzzNBeeContentIsDisplayedToYou,
                                        maxLines: 2,
                                        textAlign: TextAlign.center,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          fontSize: 14,
                                        ),
                                        // TextStyle(
                                        //     color: Theme.of(context).brightness == Brightness.dark
                                        //         ? Colors.white
                                        //         : Colors.black,
                                        //     fontSize: 14,
                                        //     fontWeight: FontWeight.bold,
                                        // ),
                                      ),
                                    ),
                                    ListTileSettings(
                                      Strings.selectYourProfileLanguage,
                                      Icons.arrow_forward_ios,
                                      () {},
                                      false,
                                      FontWeight.w600,
                                    ),
                                    ListTileSettings(
                                      Strings.selectYourAppLanguage,
                                      Icons.arrow_forward_ios,
                                      () {},
                                      false,
                                      FontWeight.w600,
                                    ),
                                    ListTileSettings(
                                      Strings.enableDisableAutoTranslation,
                                      Icons.arrow_forward_ios,
                                      () {},
                                      false,
                                      FontWeight.w600,
                                    ),
                                  ],
                                ),
        ],
      ),
    );
  }
}

// code to update locale
// Get.updateLocale(Locale('en'));
