import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/screens/reset_password_screen.dart';
import 'package:werfieapp/screens/verification_Password_Screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_password_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/settings_controller.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';

class ChangePassword extends StatelessWidget {
  ChangePassword({Key key}) : super(key: key);

  SettingController settingController = Get.put(SettingController());
  GlobalKey<FormState> passwordkey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SettingController>(
      builder: (controller) {
        return Scaffold(
          appBar: !kIsWeb
              ? AppBar(
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  centerTitle: true,
                  title: Text(
                    Strings.ChangePasswordSettings,
                    style: Styles.baseTextTheme.headline1.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: 16,
                    ),
                    // TextStyle(
                    //     color: Colors.white,
                    //     fontSize: 18,
                    //     fontWeight: FontWeight.w700
                    // ),
                    // style: Theme.of(context).textTheme.headline6.copyWith(
                    //   fontSize: 18,
                    //   fontWeight: FontWeight.w700,
                    //   color: Colors.black,
                    // ),
                  ),
                  leading: !kIsWeb
                      ? MouseRegion(
                          cursor: SystemMouseCursors.click,
                          child: GestureDetector(
                              onTap: () {
                                controller.newsfeedController
                                    .isListOfBlockedAccounts = false;
                                controller.newsfeedController.isTranslations =
                                    false;
                                controller.newsfeedController
                                    .isLanguageSettings = true;
                                controller.newsfeedController.isLanguageType =
                                    false;
                                controller.newsfeedController
                                    .isListOfBlockedAccounts = false;
                                if (!kIsWeb) {
                                  settingController.newPasswordTxt.clear();
                                  settingController.currentPassword.clear();
                                  settingController.confirmPassword.clear();
                                  FocusManager.instance.primaryFocus?.unfocus();
                                  Navigator.of(context).pop();
                                }
                                controller.update();
                              },
                              child: Icon(
                                Icons.arrow_back,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )),
                        )
                      : SizedBox(),
                )
              : PreferredSize(
                  child: Container(),
                  preferredSize: Size(0, 0),
                ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                kIsWeb
                    ? Padding(
                        padding: const EdgeInsets.symmetric(
                          vertical: 16.0,
                          horizontal: 12,
                        ),
                        child: Row(
                          children: [
                            // MediaQuery.of(context).size.width >= 1050
                            //     ? SizedBox()
                            //     :
                            MouseRegion(
                              cursor: SystemMouseCursors.click,
                              child: GestureDetector(
                                onTap: () {
                                  controller.newsfeedController
                                      .isListOfBlockedAccounts = false;
                                  controller.newsfeedController.isTranslations =
                                      false;
                                  controller.newsfeedController
                                      .isLanguageSettings = false;
                                  controller.newsfeedController
                                      .isSettingDetail = false;
                                  controller.newsfeedController
                                      .isSettingTypeDetail = false;
                                  controller.newsfeedController.isLanguageType =
                                      false;
                                  controller.newsfeedController
                                      .isListOfBlockedAccounts = false;
                                  controller.newsfeedController
                                      .isChangeUserName = false;
                                  controller.newsfeedController.isYourAccount =
                                      true;
                                  controller.newsfeedController
                                      .isChangePassword = false;
                                  controller.newsfeedController.update();
                                },
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                            ),
                            Expanded(
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(
                                  Strings.ChangePasswordSettings,
                                  textAlign: TextAlign.left,
                                  style:
                                      Styles.baseTextTheme.headline1.copyWith(
                                    color: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(),
                Container(
                  height: 1,
                  color: Colors.grey[300],
                ),
                SizedBox(height: 20),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: 20,
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                            Strings.enterYourNewPassword),
                        SizedBox(
                          height: 20,
                        ),
                        Form(
                          key: passwordkey,
                          child: Column(
                            children: [
                              InputPasswordField(
                                text: Strings.enterCurrentPassword,
                                onPasswordEntered: (value) {
                                  value = controller.currentPassword.text;
                                },
                                controller: controller.currentPassword,
                                validator: (value) {
                                  print("idhgrtwerr");

                                  if (controller.passwordValidator == true) {
                                    print(",______");

                                    return "Wrong password";
                                  }
                                  if (value == null || value.isEmpty) {
                                    return Strings.passwordCannotBeEmpty;
                                  }
                                  if (value.length < 8)
                                    return Strings.passwordShouldBeCharacter;
                                  return null;
                                },

                                //     (value) {
                                //   return UtilsMethods.validatePassword(value);
                                // },
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Padding(
                                  padding: const EdgeInsets.only(right: 15.0),
                                  child: TextButton(
                                    onPressed: () async {
                                      //print("hello");
                                      if (!kIsWeb) {
                                        Get.to(
                                          // MaterialPageRoute(
                                          //   builder: (context) =>
                                          ResetPasswordScreen(),
                                          // ),
                                        );
                                      } else {
                                        // Get.to(ResetPasswordScreen());
                                        // Get.toNamed(FluroRouters.resetPasswordScreen);
                                        Get.toNamed(
                                            FluroRouters.resetPasswordScreen);
                                        // context.push(AppRoute.resetPasswordScreen);
                                      }
                                    },
                                    child: Text(
                                      Strings.lostPassword,
                                      style: Styles.baseTextTheme.headline1
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                        fontSize: kIsWeb ? 12 : 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 10),
                              InputPasswordField(
                                text: Strings.enterNewPassword,
                                onPasswordEntered: (value) {
                                  value = controller.newPasswordTxt.text;
                                },
                                controller: controller.newPasswordTxt,
                                validator: (value) {
                                  return UtilsMethods.validatePassword(value);
                                },
                              ),
                              SizedBox(height: 10),
                              InputPasswordField(
                                text: Strings.reEnterPassword,
                                onPasswordEntered: (value) {
                                  value = controller.confirmPassword.text;
                                },
                                controller: controller.confirmPassword,
                                validator: (val) {
                                  if (val.isEmpty)
                                    return Strings.passwordCannotBeEmpty;
                                  if (val.length < 8)
                                    return Strings.passwordShouldBeCharacter;
                                  if (val != controller.newPasswordTxt.text)
                                    return Strings.passwordShouldBeMatched;
                                  return null;
                                },
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        controller.newsfeedController.buttonCheck == true
                            ? Align(
                                alignment: Alignment.centerRight,
                                child: CircularProgressIndicator())
                            : Align(
                                alignment: Alignment.centerRight,
                                child: RoundedButton(
                                  Strings.next,
                                  controller.newsfeedController.buttonCheck ==
                                          false
                                      ? () async {
                                          controller.newsfeedController
                                              .buttonCheck = true;
                                          controller.update();
                                          await controller.verifyPassword(
                                              controller
                                                  .newsfeedController.userId,
                                              controller.currentPassword.text);
                                          print(
                                              " controller.passValidator ${controller.passwordValidator}");
                                          if (controller.passwordValidator ==
                                              true) {
                                            controller.newsfeedController
                                                .buttonCheck = false;
                                            // controller.newsfeedController.update();
                                          }

                                          controller.update();

                                          if (passwordkey.currentState
                                              .validate()) {
                                            controller.currentEmail =
                                                await controller.storage
                                                    .read('CurrentEmail');
                                            print(
                                                "controller.newsfeedController.email ${controller.currentEmail}");

                                            int isSuccess = await controller
                                                .sendVerification(
                                                    controller.currentEmail);

                                            if (isSuccess == 1) {
                                              if (kIsWeb) {
                                                showDialog<String>(
                                                    context: context,
                                                    builder:
                                                        (BuildContext context) {
                                                      return AlertDialog(
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius:
                                                                BorderRadius.all(
                                                                    Radius.circular(
                                                                        10.0))),
                                                        contentPadding:
                                                            EdgeInsets.zero,
                                                        content:
                                                            verificationPasswordScreen(
                                                          email: controller
                                                              .currentEmail,
                                                        ),
                                                      );
                                                    });
                                              } else {
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (context) =>
                                                          verificationPasswordScreen(
                                                            email: controller
                                                                .currentEmail,
                                                          )),
                                                );
                                              }

                                              UtilsMethods.toastMessageShow(
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  message:
                                                      'We sent you a code ');
                                            } else {
                                              UtilsMethods.toastMessageShow(
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  controller.newsfeedController
                                                      .displayColor,
                                                  message:
                                                      'error occur while sending you code');
                                            }

                                            Future.delayed(
                                                const Duration(seconds: 3), () {
                                              controller.newsfeedController
                                                  .buttonCheck = false;
                                              controller
                                                  .update(); // Prints after 1 second.
                                            });
                                          } else {
                                            controller.newsfeedController
                                                .buttonCheck = false;
                                            controller.update();
                                          }
                                        }
                                      : () {},
                                  verticalPadding: 10.00,
                                  horizontalPadding: 20.0,
                                  roundedButtonColor: MyColors.werfieBlue,
                                ),
                              )
                      ],
                    ),
                  ),
                ),
                //
                // SizedBox(height: 20),
              ],
            ),
          ),
        );
      },
    );
  }
}
