import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/verification_email_screen.dart';
import 'package:werfieapp/utils/strings.dart';

import '../components/input_field.dart';
import '../components/rounded_button.dart';
import '../network/controller/login_controller.dart';
import '../utils/utils_methods.dart';

// ignore: must_be_immutable
class changeEmailScreen extends StatelessWidget {
  final controller = Get.find<NewsfeedController>();

  TextEditingController username = TextEditingController();
  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      builder: (controller) {
        return kIsWeb
            ? Container(
                height: 500,
                width: 450,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.changeEmail,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(height: 20),
                        Form(
                          key: formKey,
                          child: InputField(
                            // focusNode: controller.focus1,

                            TextInputAction: TextInputAction.next,
                            onChanged: (_) {},
                            hint: Strings.enterYourEmail,

                            onValueEntered: (_) {},
                            // onValueEntered: (value) {
                            //   print('value will be' + value);
                            //   value = email.text;
                            // },
                            controller: Get.find<LoginController>().email,
                            validator: (value) {
                              print("idhgrtwerr");

                              if (controller.emailValidator == true) {
                                return "Email already taken";
                              }
                              if (value == null || value.isEmpty) {
                                return Strings.emailFieldCannotBeEmpty;
                              }
                              if (value.isNotEmpty) {
                                bool isValidEmail() {
                                  return RegExp(
                                          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
                                      .hasMatch(value);
                                }

                                if (isValidEmail() == false) {
                                  return Strings.emailFormatIsInvalid;
                                } else {
                                  return null;
                                }
                              }
                              return null;
                            },

                            textInputType: TextInputType.emailAddress,
                            fieldIcon: Icons.email,
                          ),
                        ),
                        Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RoundedButton(
                              Strings.cancel,
                              () {
                                Navigator.pop(context);
                              },
                              horizontalPadding: 30.0,
                              roundedButtonColor: Colors.red,
                            ),
                            RoundedButton(
                              Strings.next,
                              controller.buttonCheck == false
                                  ? () async {
                                      controller.buttonCheck = true;
                                      controller.update();
                                      await controller.emailTakenOrNot(
                                          Get.find<LoginController>()
                                              .email
                                              .text);

                                      print(
                                          " controller.emailValidator ${controller.emailValidator}");
                                      if (controller.emailValidator == true) {
                                        controller.buttonCheck = false;
                                        controller.update();
                                      }

                                      controller.update();

                                      if (formKey.currentState.validate()) {
                                        print("dssfdds");

                                        int isSuccess = await controller
                                            .sendEmailVerification(
                                                Get.find<LoginController>()
                                                    .email
                                                    .text);
                                        if (isSuccess == 1) {
                                          Navigator.pop(context);
                                          showDialog<String>(
                                              context: context,
                                              builder: (BuildContext context) {
                                                return AlertDialog(
                                                  shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  10.0))),
                                                  contentPadding:
                                                      EdgeInsets.zero,
                                                  content: verificationEmailScreen(
                                                      email: Get.find<
                                                              LoginController>()
                                                          .email
                                                          .text),
                                                );
                                              });

                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor,
                                              controller.displayColor,
                                              controller.displayColor,
                                              message: 'We sent you a code ');
                                        } else if (isSuccess == 2) {
                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor,
                                              controller.displayColor,
                                              controller.displayColor,
                                              message: Strings.wrongPasswordMsg);
                                        }

                                        Future.delayed(
                                            const Duration(seconds: 3), () {
                                          controller.buttonCheck = false;
                                          controller
                                              .update(); // Prints after 1 second.
                                        });
                                      }
                                    }
                                  : () {},
                              horizontalPadding: 30.0,
                              roundedButtonColor: controller.displayColor,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : Scaffold(
                appBar: kIsWeb
                    ? PreferredSize(
                        child: Container(),
                        preferredSize: Size(0, 0),
                      )
                    : AppBar(
                        automaticallyImplyLeading: false,
                        title: Image.asset(
                          "assets/drawer_icons/WerfieLogoWIcon.png",
                          alignment: Alignment.centerLeft,
                          width: 60,
                          height: 60,
                        ),
                        centerTitle: true,
                        elevation: 0.0,
                        backgroundColor:
                            Theme.of(context).brightness == Brightness.dark
                                ? Colors.black
                                : Colors.white,
                      ),
                body: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
                  child: SafeArea(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          Strings.changeEmail,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                        ),
                        SizedBox(height: 20),
                        Form(
                          key: formKey,
                          child: InputField(
                            // focusNode: controller.focus1,

                            TextInputAction: TextInputAction.next,
                            onChanged: (_) {},
                            hint: Strings.enterYourEmail,

                            onValueEntered: (_) {},
                            // onValueEntered: (value) {
                            //   print('value will be' + value);
                            //   value = email.text;
                            // },
                            controller: Get.find<LoginController>().email,
                            validator: (value) {
                              print("idhgrtwerr");

                              if (controller.emailValidator == true) {
                                return "Email already taken";
                              }
                              if (value == null || value.isEmpty) {
                                return Strings.emailFieldCannotBeEmpty;
                              }
                              if (value.isNotEmpty) {
                                bool isValidEmail() {
                                  return RegExp(
                                          r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
                                      .hasMatch(value);
                                }

                                if (isValidEmail() == false) {
                                  return Strings.emailFormatIsInvalid;
                                } else {
                                  return null;
                                }
                              }
                              return null;
                            },
                            textInputType: TextInputType.emailAddress,
                            fieldIcon: Icons.email,
                          ),
                        ),
                        Spacer(),
                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RoundedButton(
                              Strings.cancel,
                              () {
                                Navigator.pop(context);
                              },
                              horizontalPadding: 30.0,
                              roundedButtonColor: Colors.red,
                            ),
                            RoundedButton(
                              Strings.next,
                              controller.buttonCheck == false
                                  ? () async {
                                      controller.buttonCheck = true;
                                      controller.update();
                                      int isSuccess =
                                          await controller.emailTakenOrNot(
                                              Get.find<LoginController>()
                                                  .email
                                                  .text);

                                      print(
                                          " controller.emailValidator ${controller.emailValidator}");
                                      if (controller.emailValidator == true) {
                                        controller.buttonCheck = false;
                                        controller.update();
                                      }

                                      controller.update();

                                      if (formKey.currentState.validate()) {
                                        print("dssfdds");

                                        int isSuccess = await controller
                                            .sendEmailVerification(
                                                Get.find<LoginController>()
                                                    .email
                                                    .text);

                                        if (isSuccess == 1) {
                                          Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                          context) =>
                                                      verificationEmailScreen(
                                                          email: Get.find<
                                                                  LoginController>()
                                                              .email
                                                              .text)));

                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor,
                                              controller.displayColor,
                                              controller.displayColor,
                                              message: 'We sent you a code ');
                                        } else if (isSuccess == 2) {
                                          UtilsMethods.toastMessageShow(
                                              controller.displayColor,
                                              controller.displayColor,
                                              controller.displayColor,
                                              message: Strings.wrongPasswordMsg);
                                        }

                                        Future.delayed(
                                            const Duration(seconds: 3), () {
                                          controller.buttonCheck = false;
                                          controller
                                              .update(); // Prints after 1 second.
                                        });
                                      }
                                    }
                                  : () {},
                              horizontalPadding: 30.0,
                              roundedButtonColor: controller.displayColor,
                            ),
                          ],
                        ),
                        Container(
                          height: 1,
                          color: Colors.grey[300],
                        ),
                      ],
                    ),
                  ),
                ),
              );
      },
    );
  }
}
