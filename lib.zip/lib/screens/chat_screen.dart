import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/chatUserModel.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/chat_screen_mobile.dart';
import 'package:werfieapp/widgets/main_drawer.dart';
import 'package:werfieapp/widgets/new_message_dialog.dart';
import 'package:werfieapp/models/message.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:flutter_svg/svg.dart';

import '../utils/chat_utils.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../utils/metaTags/MetaTags.dart';
import '../utils/metaTags/MetaTagsValues.dart';
import '../utils/utils_methods.dart';
import 'message_request_screen.dart';
import '../widgets/RegexTextHighlight.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Responsive(
        mobile: MobileChatScreen(),
        tablet: MobileChatScreen(),
        desktop: MobileChatScreen(),
      ),
    );
  }
}

class MobileChatScreen extends StatefulWidget {
  const MobileChatScreen({Key key}) : super(key: key);

  @override
  State<MobileChatScreen> createState() => _MobileChatScreenState();
}

class _MobileChatScreenState extends State<MobileChatScreen> with TickerProviderStateMixin{
  bool isChatUpdate = false;
  //bool isRequestScreen = false;

  NewsfeedController controller = Get.find<NewsfeedController>();
  TabController searchChatTabController;
  final ScrollController chatScreenController = ScrollController();

  void _clickWho(Member post) async {
    final NewsfeedController newsfeedController =
        Get.find<NewsfeedController>();
    newsfeedController.otherUserId = post.id;
    newsfeedController.isProfileScreen = false;
    // controller.isClickWhoToFollow = true;
    newsfeedController.isWhoToFollowScreen = false;
    newsfeedController.isOtherUserProfileScreen = true;
    newsfeedController.isTrendsScreen = false;
    newsfeedController.isNewsFeedScreen = false;
    newsfeedController.isBrowseScreen = false;
    newsfeedController.isNotificationScreen = false;
    newsfeedController.isChatScreen = false;
    newsfeedController.isPostDetails = false;
    newsfeedController.isSettingsScreen = false;
    newsfeedController.isListScreen = false;

    try {
      Get.find<NewsfeedController>().userInfo = UserProfile();
      Get.find<NewsfeedController>().userInfo =
          await newsfeedController.getOtherUserProfile(post.id);

      await Get.find<OtherUserController>()
          .filterUsersPostPagged("posts", page: 1);
      Get.find<OtherUserController>().userPosts.forEach((element) {
        element.mute = Get.find<NewsfeedController>().userInfo.muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {}
    newsfeedController.update();
  }

  void _clickChatUser(ChatUserModel post) async {
    final NewsfeedController newsfeedController =
        Get.find<NewsfeedController>();
    newsfeedController.otherUserId = post.memberId;
    newsfeedController.isProfileScreen = false;
    newsfeedController.isWhoToFollowScreen = false;
    newsfeedController.isOtherUserProfileScreen = true;
    newsfeedController.isTrendsScreen = false;
    newsfeedController.isNewsFeedScreen = false;
    newsfeedController.isBrowseScreen = false;
    newsfeedController.isNotificationScreen = false;
    newsfeedController.isChatScreen = false;
    newsfeedController.isPostDetails = false;
    newsfeedController.isSettingsScreen = false;
    newsfeedController.isListScreen = false;

    try {
      Get.find<NewsfeedController>().userInfo = UserProfile();
      Get.find<NewsfeedController>().userInfo =
          await newsfeedController.getOtherUserProfile(post.memberId);

      await Get.find<OtherUserController>()
          .filterUsersPostPagged("posts", page: 1);
      Get.find<OtherUserController>().userPosts.forEach((element) {
        element.mute = Get.find<NewsfeedController>().userInfo.muted;
      });
      Get.find<OtherUserController>().update();
    } catch (_) {}
    newsfeedController.update();
  }

  @override
  void initState() {

    // Below callback is added for the error Error: setState() or markNeedsBuild() called during build.

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if(!mounted) return;
      getChats();
      searchChatTabController = TabController(vsync: this, length: 4);
    });
    addChatsMetaTags();
    super.initState();
  }
  addChatsMetaTags(){
    MetaTags().addMetaTag(
      pageTitle: MetaTagValues.pageTitleChats,
        metaTagDescription: MetaTagValues.chatsMetaDescription,
        metaTagKeywords: MetaTagValues.chatsMetaKeywords,
        ogTitle: MetaTagValues.chatsOGTitle,
        ogDescription: MetaTagValues.chatsOGDescription,
        ogImage: MetaTagValues.ogImage
    );
  }

  @override
  void dispose() {
    super.dispose();
    searchChatTabController.dispose();
  }

  getChats() async {
    controller.chatUserList = await controller.getChat();
    controller.chatRequestUserList = await controller.getMessageRequest();
    // chatName field is updated only when user tap a conversation. so when user come back here when there is a chat open
    // and if there is any update in the already selected conversation like user is blocked or unblocked then its not updating.
    // so to solve this whenever we fetch updated data, we update the user selected chatName variable. - K
    if (controller.chatUserList != null) {
      int currentIndex = controller.chatUserList.indexWhere((element) {
        return element.conversationId == controller.chatName.conversationId;
      });
      if (currentIndex != -1) {
        controller.chatName = controller.chatUserList[currentIndex];
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!isChatUpdate) {
      if (controller.chatUserList != null &&
          controller.chatUserList.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          getMessagesOfAConversation(context, controller);
          isChatUpdate = true;
        });
      }
    }
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return Scaffold(
        appBar: !Responsive.isDesktop(context)
            ? kIsWeb
            ? PreferredSize(
          preferredSize: Size(0.0, 0.0),
          child: Container(),
        )
        // AppBar(
        //             backgroundColor: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
        //             iconTheme: IconThemeData(
        //               color: Color(0xFF4f515b),
        //             ),
        //             title: Container(
        //               height: 45,
        //               width: MediaQuery.of(context).size.width * 0.7,
        //               child: TextField(
        //                 textAlignVertical: TextAlignVertical.bottom,
        //                 style: LightStyles.baseTextTheme.headline2.copyWith(
        //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
        //                   //fontWeight: FontWeight.w500,
        //                  // fontSize: 14,
        //                 ),
        //                 cursorColor:Theme.of(context).brightness == Brightness.dark ?Colors.white:Colors.black ,
        //                 decoration: InputDecoration(
        //                   hintText: Strings.search,
        //                   hintStyle: LightStyles.baseTextTheme.headline3,
        //                   prefixIcon: Icon(Icons.search),
        //                   border: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(40),
        //                   ),
        //                   enabledBorder: OutlineInputBorder(
        //                     borderRadius: BorderRadius.circular(40),
        //                     borderSide: BorderSide(
        //                       width: 0,
        //                       style: BorderStyle.none,
        //                     ),
        //                   ),
        //                   fillColor: Colors.grey[250],
        //                   filled: true,
        //                 ),
        //               ),
        //             ),
        //             automaticallyImplyLeading:
        //                 !Responsive.isDesktop(context) ? true : false,
        //           )
            : AppBar(
          backgroundColor:
          Theme.of(context).brightness == Brightness.dark
              ? Colors.black
              : Colors.white,
          iconTheme: IconThemeData(
            color: Color(0xFF4f515b),
          ),
          title: Container(
            height: 45,
            width: MediaQuery.of(context).size.width * 0.9,
            child: TextField(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) => SearchScreen(),
                  ),
                );
              },
              style: LightStyles.baseTextTheme.headline2.copyWith(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                //fontWeight: FontWeight.w500,
                // fontSize: 14,
              ),
              cursorColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              textAlignVertical: TextAlignVertical.bottom,
              decoration: InputDecoration(
                hintText: Strings.search,
                prefixIcon: Icon(Icons.search),
                hintStyle: LightStyles.baseTextTheme.headline3,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                  borderSide: BorderSide(
                    width: 0,
                    style: BorderStyle.none,
                  ),
                ),
                fillColor: Colors.grey[250],
                filled: true,
              ),
            ),
          ),
          automaticallyImplyLeading:
          !Responsive.isDesktop(context) ? true : false,
        )
            : PreferredSize(
          preferredSize: Size(0.0, 0.0),
          child: Container(),
        ),
        drawer: !Responsive.isDesktop(context)
            ? MainDrawer(controller)
            : Container(),
        drawerEnableOpenDragGesture:
        !Responsive.isDesktop(context) ? false : true,
        body: Row(
          children: [
            MediaQuery.of(context).size.width >= 1050
                ? conversationsList(context, controller)
                : const SizedBox(),
            Container(
              height: Get.height,
              width: 1,
              color: Colors.grey[200],
            ),

            controller.isDeletingConversation ? Container(
                    width: MediaQuery.of(context).size.width >= 700 ? 560 : MediaQuery.of(context).size.width / 1.3,
                    height: Get.height,
                    decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.white)),
                    child: const Center(
                child: Padding(
                  padding: EdgeInsets.only(top: 10.0),
                  child: CircularProgressIndicator(
                    color: MyColors.BlueColor,
                  ),
                ),
              ),
            ) :
            controller.isChatScreenWeb
                ? controller.infoChatInfo
                ? Container(
              width: MediaQuery.of(context).size.width >= 700
                  ? 560
                  : MediaQuery.of(context).size.width / 1.3,
              height: Get.height,
              decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  border: Border.all(
                      color: Colors.grey.withOpacity(0.4))),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              IconButton(
                                  onPressed: () {
                                    controller.showOverlay = true;
                                    controller.infoChatInfo = false;

                                    print('sdfdsfkkk');
                                    controller.update();
                                  },
                                  icon: Icon(
                                    Icons.arrow_back,
                                    color: Theme.of(context)
                                        .brightness ==
                                        Brightness.dark
                                        ? Colors.white
                                        : Colors.black,
                                  )),
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                controller.chatName
                                    .conversationType ==
                                    "group"
                                    ? Strings.groupInfo
                                    : Strings.chatInfo,
                                style: Styles.baseTextTheme.headline2
                                    .copyWith(
                                  color:
                                  Theme.of(context).brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                              )
                            ],
                          ),
                          Container(
                            margin:
                            EdgeInsets.only(top: 10, bottom: 10),
                            height: 1,
                            color: Colors.grey.withOpacity(0.4),
                            width: Get.width,
                          ),
                                    controller.chatName.conversationType == "group" ? ListTile(
                            leading: CircleAvatar(
                              backgroundImage: controller.chatName
                                  .conversationType ==
                                  'single'
                                  ? controller.chatName
                                  .profileImage !=
                                  null
                                  ? NetworkImage(controller
                                  .chatName.profileImage)
                                  : AssetImage(
                                  'assets/images/person_placeholder.png')
                                  : controller.chatName
                                  .conversationType ==
                                  'group'
                                  ? controller.tempProfileImageGroupChat !=
                                  null
                                  ? MemoryImage(controller
                                  .tempProfileImageGroupChat)
                                  : controller.chatName
                                  .groupImage !=
                                  null
                                  ? NetworkImage(
                                  controller.chatName
                                      .groupImage)
                                  : AssetImage(
                                  'assets/images/person_placeholder.png')
                                  : SizedBox(),
                            ),
                            trailing:
                            controller.chatName
                                .conversationType !=
                                "group"
                                ? SizedBox()

                            /// edit group in web chat
                                : InkWell(
                              child: Text(
                                                    Strings.editGroup,
                                style: Styles
                                    .baseTextTheme.headline2
                                    .copyWith(
                                  color: controller
                                      .displayColor,
                                  fontSize: 16,
                                  fontWeight:
                                  FontWeight.bold,
                                ),
                              ),
                              onTap: () {
                                controller
                                    .profileImageGroupChat =
                                null;
                                controller.update();

                                showDialog(
                                  context: context,
                                  builder: (BuildContext
                                  context) {
                                    return StatefulBuilder(
                                        builder: (context,
                                            setState) {
                                          return AlertDialog(
                                            contentPadding:
                                            EdgeInsets.zero,
                                            insetPadding:
                                            EdgeInsets.zero,
                                            shape:
                                            RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius
                                                  .circular(
                                                  20),
                                            ),
                                            content: Container(
                                              height: 300,
                                              width: 400,
                                              child: Column(
                                                crossAxisAlignment:
                                                CrossAxisAlignment
                                                    .center,
                                                mainAxisAlignment:
                                                MainAxisAlignment
                                                    .spaceBetween,
                                                children: [
                                                  Column(
                                                    children: [
                                                      ListTile(
                                                        title:
                                                        Text(
                                                                          Strings.editGroup,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                            FontWeight.bold,
                                                          ),
                                                        ),
                                                        leading:
                                                        IconButton(
                                                          icon:
                                                          Icon(
                                                            Icons.close,
                                                            color: Theme.of(context).brightness == Brightness.dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                          ),
                                                          onPressed:
                                                              () {
                                                            Navigator.of(context).pop();
                                                          },
                                                        ),
                                                        trailing:
                                                        MaterialButton(
                                                          child:
                                                          Text(
                                                            Strings.save,
                                                            style:
                                                            TextStyle(color: Colors.white),
                                                          ),
                                                          onPressed:
                                                              () {
                                                            print("sadsfddfd");
                                                            // controller.isChatScreenWeb = false;
                                                                            if (controller.groupName == null || controller.groupName == "null" || controller.groupName.trim() == ""){
                                                                              controller.groupName = "";
                                                                            }

                                                            controller.updateGroupName(context,
                                                                groupName: controller.groupName,
                                                                conversationId: controller.chatName.conversationId);

                                                            if (controller.profileImageGroupChat !=
                                                                null) {
                                                              controller.updateGroupImage(
                                                                conversationId: controller.chatName.conversationId,
                                                                groupProfileImage: controller.profileImageGroupChat,
                                                              );
                                                            }
                                                            controller.showOverlay =
                                                            true;
                                                            controller.infoChatInfo =
                                                            false;
                                                            controller.tempGroupName =
                                                                controller.groupName;

                                                            controller.tempProfileImageGroupChat =
                                                                controller.profileImageGroupChat;
                                                            controller.checkUpdateGroupName =
                                                            true;

                                                            controller.update();
                                                          },
                                                          color:
                                                          controller.displayColor,
                                                          shape:
                                                          RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
                                                        ),
                                                      ),
                                                      Container(
                                                        color: Colors
                                                            .grey
                                                            .withOpacity(0.1),
                                                        height:
                                                        1,
                                                        width: Get
                                                            .width,
                                                        margin: EdgeInsets.only(
                                                            top:
                                                            5,
                                                            bottom:
                                                            20),
                                                      ),
                                                    ],
                                                  ),
                                                  Stack(
                                                    alignment:
                                                    Alignment
                                                        .center,
                                                    children: [
                                                      controller.tempProfileImageGroupChat !=
                                                          null
                                                          ? CircleAvatar(
                                                        maxRadius: 60,
                                                        minRadius: 60,
                                                        backgroundImage: MemoryImage(controller.tempProfileImageGroupChat),
                                                        backgroundColor: Colors.white,
                                                      )
                                                          : controller.profileImageGroupChat != null
                                                          ? CircleAvatar(
                                                        maxRadius: 60,
                                                        minRadius: 60,
                                                        backgroundImage: MemoryImage(controller.profileImageGroupChat),
                                                        backgroundColor: Colors.white,
                                                      )
                                                          : controller.chatName.conversationType == 'group' && controller.chatName.groupImage != null
                                                          ? CircleAvatar(
                                                        backgroundImage: NetworkImage(controller.chatName.groupImage),
                                                        minRadius: 60,
                                                        maxRadius: 60,
                                                      )
                                                          : CircleAvatar(
                                                        backgroundImage: AssetImage('assets/images/person_placeholder.png'),
                                                        minRadius: 60,
                                                        maxRadius: 60,
                                                      ),
                                                      IconButton(
                                                          onPressed:
                                                              () async {
                                                            controller.tempProfileImageGroupChat =
                                                            null;
                                                            controller.update();

                                                            controller.profileImageGroupChat =
                                                            await controller.callGetImage();
                                                            print(controller.profileImageGroupChat.toString());
                                                            setState(() {});
                                                          },
                                                          icon:
                                                          Icon(
                                                            Icons.camera_alt_outlined,
                                                            size:
                                                            25,
                                                            color:
                                                            Colors.black,
                                                          )),
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                    const EdgeInsets.all(
                                                        8.0),
                                                    child:
                                                    TextFormField(
                                                      style:
                                                      TextStyle(
                                                        color: Theme.of(context).brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontWeight:
                                                        FontWeight.w500,
                                                        fontSize:
                                                        14,
                                                      ),
                                                      initialValue: controller.groupName ==
                                                          'null'
                                                          ? ''
                                                          : controller
                                                          .groupName,
                                                      onChanged:
                                                          (val) {
                                                        print(
                                                            'group name of ${controller.groupName}');
                                                        controller.groupName =
                                                            val;
                                                      },
                                                      decoration:
                                                      new InputDecoration(
                                                        fillColor:
                                                        Colors.grey[250],
                                                        hintStyle: LightStyles
                                                            .baseTextTheme
                                                            .headline3,
                                                        label: Text(
                                                            Strings.enterGroupChatTitle),
                                                        labelStyle: LightStyles
                                                            .baseTextTheme
                                                            .headline3,
                                                        focusedBorder:
                                                        OutlineInputBorder(
                                                          borderRadius:
                                                          BorderRadius.circular(5),
                                                          borderSide: BorderSide(
                                                              color: Colors.grey,
                                                              width: 1.0),
                                                        ),
                                                        enabledBorder:
                                                        OutlineInputBorder(
                                                          borderRadius:
                                                          BorderRadius.circular(5),
                                                          borderSide:
                                                          BorderSide(
                                                            color:
                                                            Colors.grey,
                                                            width:
                                                            1.0,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        });
                                  },
                                );
                              },
                            ),

                            ///Edit group name
                            // title: Text(
                            //     "${controller.groupName != null ? controller.groupName : controller.chatName.name}"),
                            title: Text(
                              "${controller.chatName.username == null ? Strings.groupsTabChat : controller.chatName.username}",
                              style: Styles.baseTextTheme.headline2
                                  .copyWith(
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                                    ) : SizedBox(),
                                    controller.chatName.conversationType == "group" ? Container(
                            margin:
                            EdgeInsets.only(top: 10, bottom: 10),
                            height: 1,
                            color: Colors.grey.withOpacity(0.4),
                            width: Get.width,
                                    ) : SizedBox(),
                                    controller.chatName.conversationType == "group" ? Padding(
                            padding: const EdgeInsets.only(
                                top: 8.0, bottom: 8.0, left: 15),
                            child: Text(
                              Strings.peopleInThisChat,
                              style: Styles.baseTextTheme.headline2
                                  .copyWith(
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              ),
                            ),
                                    ) : SizedBox(),
                          controller.chatName.conversationType !=
                              "group"
                              ? GestureDetector(
                                            // onTap: kIsWeb
                                            //     ? () {
                                            //         Get.find<NewsfeedController>()
                                            //                 .userInfo =
                                            //             UserProfile();
                                            //         Get.find<
                                            //                 NewsfeedController>()
                                            //             .update();
                                            //         _clickChatUser(
                                            //             controller.chatName);
                                            //       }
                                            //     : () async {
                                            //         _clickChatUser(
                                            //             controller.chatName);
                                            //         Navigator.push(
                                            //             context,
                                            //             MaterialPageRoute(
                                            //                 builder: (BuildContext
                                            //                         context) =>
                                            //                     OtherUsersProfile(
                                            //                         controller:
                                            //                             controller)));
                                            //       },
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundImage: controller
                                    .chatName
                                    .profileImage !=
                                    null
                                    ? NetworkImage(controller
                                    .chatName.profileImage)
                                    : AssetImage(
                                    'assets/images/person_placeholder.png'),
                              ),
                              trailing: MaterialButton(
                                shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(
                                        20.0)),
                                child: Text(
                                  controller.chatName
                                      .singlePersonFollow
                                      ? Strings.unFollow
                                      : Strings.follow,
                                  style: TextStyle(
                                      color: Theme.of(context)
                                          .brightness ==
                                          Brightness.dark
                                          ? Colors.black
                                          : Colors.white),
                                ),
                                onPressed: () {
                                  controller.chatName
                                      .singlePersonFollow
                                      ? {
                                    controller.chatName
                                        .singlePersonFollow =
                                    false,
                                    controller.update(),
                                    controller
                                        .addFollowing(
                                        controller
                                            .chatName
                                            .memberId,
                                        "unfollow")
                                  }
                                      : {
                                    controller.chatName
                                        .singlePersonFollow =
                                    true,
                                    controller.update(),
                                    controller
                                        .addFollowing(
                                        controller
                                            .chatName
                                            .memberId,
                                        "follow"),
                                  };
                                },
                                color: //Theme.of(context).brightness == Brightness.dark ?!controller.chatName.singlePersonFollow ? Colors.white : Colors.black : !controller.chatName.singlePersonFollow ? Colors.black : Colors.white,

                                Theme.of(context)
                                    .brightness ==
                                    Brightness.dark
                                    ? Colors.white
                                    : Theme.of(context)
                                    .colorScheme
                                    .secondary,
                              ),
                              title: Text(
                                "${controller.chatName.name}",
                                style: Styles
                                    .baseTextTheme.headline2
                                    .copyWith(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context)
                                      .brightness ==
                                      Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                              subtitle: Text(
                                "${controller.chatName.username == null ? Strings.groupsTabChat : controller.chatName.username}",
                                style: Styles
                                    .baseTextTheme.headline2
                                    .copyWith(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                                              onTap: kIsWeb
                                                  ? () {
                                                Get.find<NewsfeedController>().userInfo = UserProfile();
                                                Get.find<NewsfeedController>().update();
                                                _clickChatUser(controller.chatName);
                                                Get.toNamed(FluroRouters.mainScreen +
                                                    "/profile/" +
                                                    controller.otherUserId
                                                        .toString());
                                              }
                                                  : () async {
                                                _clickChatUser(controller.chatName);
                                                Navigator.push(context, MaterialPageRoute(builder: (BuildContextcontext) => OtherUsersProfile(controller: controller)));
                                              },
                            ),
                          )
                              : Column(
                            /// 2nd list
                            children: List.generate(
                                controller.chatName.members
                                    .length, (ind) {
                              return GestureDetector(
                                                // onTap: kIsWeb
                                                //     ? () {
                                                //         if (controller
                                                //                 .userProfile
                                                //                 .userId !=
                                                //             controller
                                                //                 .chatName
                                                //                 .members[ind]
                                                //                 .id) {
                                                //           Get.find<NewsfeedController>()
                                                //                   .userInfo =
                                                //               UserProfile();
                                                //           Get.find<
                                                //                   NewsfeedController>()
                                                //               .update();
                                                //           _clickWho(controller
                                                //               .chatName
                                                //               .members[ind]);
                                                //         }
                                                //       }
                                                //     : () async {
                                                //         if (controller
                                                //                 .userProfile
                                                //                 .userId !=
                                                //             controller
                                                //                 .chatName
                                                //                 .members[ind]
                                                //                 .id) {
                                                //           _clickWho(controller
                                                //               .chatName
                                                //               .members[ind]);
                                                //           Navigator.push(
                                                //               context,
                                                //               MaterialPageRoute(
                                                //                   builder: (BuildContext
                                                //                           context) =>
                                                //                       OtherUsersProfile(
                                                //                           controller:
                                                //                               controller)));
                                                //         }
                                                //       },
                                child: ListTile(
                                  leading: CircleAvatar(
                                    backgroundImage: controller
                                        .chatName
                                        .members[ind]
                                        .profileImage !=
                                        null
                                        ? NetworkImage(
                                        controller
                                            .chatName
                                            .members[ind]
                                            .profileImage)
                                        : AssetImage(
                                        'assets/images/person_placeholder.png'),
                                  ),
                                  trailing:
                                  controller
                                      .chatName
                                      .members[ind]
                                      .id
                                      .toString() ==
                                      controller.storage
                                          .read('id')
                                          .toString()
                                      ? SizedBox()
                                      : MaterialButton(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius
                                            .circular(
                                            20.0)),
                                    child: Text(
                                      controller
                                          .chatName
                                          .members[
                                      ind]
                                          .follow
                                                                    ? Strings.unFollow
                                                                    : Strings.follow,
                                      style: TextStyle(
                                          color: Theme.of(context).brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors
                                              .black
                                              : Colors
                                              .white),
                                    ),
                                    onPressed: () {
                                      controller
                                          .chatName
                                          .members[
                                      ind]
                                          .follow
                                          ? {
                                        controller
                                            .chatName
                                            .members[ind]
                                            .follow = false,
                                        controller
                                            .update(),
                                        controller.addFollowing(
                                            controller.chatName.members[ind].id,
                                            "unfollow")
                                      }
                                          : {
                                        controller
                                            .chatName
                                            .members[ind]
                                            .follow = true,
                                        controller
                                            .update(),
                                        controller.addFollowing(
                                            controller.chatName.members[ind].id,
                                            "follow"),
                                      };
                                    },
                                    color:
                                    // controller
                                    //         .chatName
                                    //         .members[ind]
                                    //         .follow
                                    //     ?
                                    //     Colors.blueAccent
                                    //     :
                                    Theme.of(context)
                                        .brightness ==
                                        Brightness
                                            .dark
                                        ? Colors
                                        .white
                                        : Theme.of(
                                        context)
                                        .colorScheme
                                        .secondary,
                                  ),
                                  title: Text(
                                    "${controller.chatName.members[ind].firstname} ${controller.chatName.members[ind].lastname}",
                                    style: Styles
                                        .baseTextTheme.headline2
                                        .copyWith(
                                      fontSize: 15,
                                      fontWeight:
                                      FontWeight.bold,
                                      color: Theme.of(context)
                                          .brightness ==
                                          Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  subtitle: Text(
                                    "${controller.chatName.members[ind].username}",
                                    style: Styles
                                        .baseTextTheme.headline2
                                        .copyWith(
                                      fontSize: 14,
                                      fontWeight:
                                      FontWeight.w400,
                                    ),
                                  ),
                                                  onTap: kIsWeb
                                                      ? () {
                                                    if (controller.userProfile.userId != controller.chatName.members[ind].id) {
                                                      Get.find<NewsfeedController>().userInfo = UserProfile();
                                                      Get.find<NewsfeedController>().update();
                                                      _clickWho(controller.chatName.members[ind]);
                                                      Get.toNamed(FluroRouters.mainScreen +
                                                          "/profile/" +
                                                          controller.otherUserId
                                                              .toString());
                                                    }
                                                  }
                                                      : () async {
                                                    if (controller.userProfile.userId != controller.chatName.members[ind].id) {
                                                      _clickWho(controller.chatName.members[ind]);
                                                      Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => OtherUsersProfile(controller: controller)));
                                                    }
                                                  },
                                ),
                              );
                            }),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          controller.chatName.conversationType ==
                              'single'
                              ? SizedBox()
                              : Center(
                              child: InkWell(
                                child: Text(Strings.addPeople,
                                    style: Styles
                                        .baseTextTheme.headline2
                                        .copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color:
                                      controller.displayColor,
                                    )),
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder:
                                        (BuildContext context) {
                                      return AlertDialog(
                                        contentPadding:
                                        EdgeInsets.zero,
                                        insetPadding:
                                        EdgeInsets.zero,
                                        shape:
                                        RoundedRectangleBorder(
                                          borderRadius:
                                          BorderRadius.circular(
                                              20),
                                        ),
                                        content:
                                        NewMessageDialogBox(
                                          isAddingMembersToChat:
                                          true,
                                          conversationId: controller
                                              .chatName
                                              .conversationId,
                                        ),
                                      );
                                    },
                                  );
                                },
                              )),

                          SizedBox(),
                                    Container(
                                      margin:
                                      EdgeInsets.only(top: 10, bottom: 10),
                                      height: 1,
                                      color: Colors.grey.withOpacity(0.4),
                                      width: Get.width,
                                    ),
                                    notificationSettings(),
                          Container(
                            margin:
                            EdgeInsets.only(top: 10, bottom: 10),
                            height: 1,
                            color: Colors.grey.withOpacity(0.4),
                            width: Get.width,
                          ),
                          // Center(
                          //     child: InkWell(
                          //   child: Text(
                          //     Strings.reportConversation,
                          //     style: TextStyle(
                          //         color: Colors.blueAccent,
                          //         fontSize: 18),
                          //   ),
                          //   onTap: () {},
                          // )),
                          // SizedBox(
                          //   height: 10,
                          // ),
                          controller.chatName.conversationType ==
                              'single'
                              ? Column(
                                children: [
                                  Center(
                                      child: InkWell(
                                        child: Padding(
                                          padding: const EdgeInsets.all(16.0),
                                          child: Text(
                                              "${Strings.block} @${controller.chatName.username ?? ""}",
                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                color: MyColors.blue,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,)),
                                        ),
                                        onTap: () async {
                                          controller.isDeletingConversation = true;
                                          controller.update();
                                          String userID = controller.chatName.memberId.toString();
                                          bool isSuccess = await controller.blockUserFromChat(userID);
                                          if (isSuccess){
                                            await ChatUtils.deleteConversation(controller);
                                            debugPrint("user blocked chat_screen");

                                          } else {

                                          }
                                          controller.isDeletingConversation = false;
                                          controller.update();
                                        },
                                      )),
                                  Center(
                                      child: InkWell(
                                        child: Padding(
                                          padding: const EdgeInsets.all(16.0),
                                          child: Text(
                                              "${Strings.report} @${controller.chatName.username ?? ""}",
                                              style: Styles.baseTextTheme.headline2.copyWith(
                                                color: MyColors.blue,
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                              )),
                                        ),
                                        onTap: () async {
                                          String userID = controller.chatName.memberId.toString();
                                          await ChatUtils.showReportUserDialog(context, userID, controller);
                                          controller.update();
                                        },
                                      )),
                                  Center(
                                  child: InkWell(
                                                child: Padding(
                                                  padding: const EdgeInsets.all(16.0),
                                                  child: Text(Strings.deleteConversation,
                                        style: Styles
                                            .baseTextTheme.headline2
                                            .copyWith(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          color: Colors.red,
                                        )),
                                                ),
                                                onTap: () async {
                                                  controller.isDeletingConversation = true;
                                                  controller.update();
                                                  await ChatUtils.deleteConversation(controller);
                                                  controller.isDeletingConversation = false;
                                                  controller.update();
/*                                                  await controller.deleteConversation(controller.chatName.conversationId);
                                                  controller.chatUserList = await controller.getChat();
                                                  controller.chatRequestUserList = await controller.getMessageRequest();
                                                  controller.showOverlay = false;
                                                  controller.infoChatInfo = true;
                                                  controller.isChatScreenWeb = false;

                                                  controller.update();*/
                                                },
                                              )),
                                ],
                              )
                              : Center(
                              child: InkWell(
                                child: Text(
                                    Strings.leaveConversation,
                                    style: Styles
                                        .baseTextTheme.headline2
                                        .copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.red,
                                      fontSize: 16,
                                    )),
                                            onTap: () async {
                                              controller.leaveConversation(controller.chatName.conversationId);
                                              controller.chatUserList = await controller.getChat();
                                              controller.update();
                                            },
                                          )),
                          SizedBox(
                            height: 10,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
                : Container(
                width: MediaQuery.of(context).size.width >= 700
                    ? 560
                    : MediaQuery.of(context).size.width / 1.3,
                        child: controller.isRequestScreen? ChatScreenMobile(controller, true): ChatScreenMobile(controller,false))
                : MediaQuery.of(context).size.width >= 1050
                ? Container(
              width: MediaQuery.of(context).size.width >= 700
                  ? 560
                  : MediaQuery.of(context).size.width / 1.3,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    Strings.youDoNotHaveAChatSelected,
                    // style: TextStyle(
                    //     fontSize: 18,
                    //     color: Colors.black,
                    //     fontWeight: FontWeight.w900),

                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 25 : 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    Strings
                        .chooseOneFromYourExistingChatsOrStartANewOne,
                    // style: TextStyle(color: Colors.black),

                    style: Theme.of(context).brightness ==
                        Brightness.dark
                        ? TextStyle(color: Colors.white)
                        : TextStyle(color: Colors.black),
                  ),
                  SizedBox(height: 14),
                  RoundedButton(
                    Strings.newChat,
                        () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            backgroundColor:
                            Theme.of(context).brightness ==
                                Brightness.dark
                                ? Colors.black
                                : Colors.white,
                            contentPadding: EdgeInsets.zero,
                            insetPadding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            content: NewMessageDialogBox(),
                          );
                        },
                      );
                    },
                    horizontalPadding: 40,
                    roundedButtonColor: controller.displayColor,
                  ),
                ],
              ),
            )
                : conversationsList(context, controller),
            Container(
              width: 1,
              color: Colors.grey[200],
            ),
            // SizedBox(width: 20),
          ],
        ),
      );
    });
  }

  Widget notificationSettings(){
    return controller.chatName.conversationType ==
        'single'
        ? Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
              top: 8.0, bottom: 8.0, left: 15),
          child: Text(
            Strings.notifications,
            style: Styles.baseTextTheme.headline2
                .copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 10),
          child: Column(

            children: [
              Padding(
                padding: EdgeInsets.only(
                    right: controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        " ${Strings.snoozeNotificationsFrom}${controller.chatName.username}",//Strings.pushNotifications,
                        style:
                        Styles.baseTextTheme.headline1.copyWith(
                          color: Theme
                              .of(context)
                              .brightness ==
                              Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontSize: kIsWeb ? 16 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                    Switch(
                        value: controller.isChatSnoozeNotification,
                        activeColor: controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          controller.setSnoozeNotification("message", snoozeValue);
                        }),
                  ],
                ),
              ),

              SizedBox(
                height: 10,
              ),

            ],
          ),
        )
      ],
    )
        : Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
              top: 8.0, bottom: 8.0, left: 15),
          child: Text(
            Strings.notifications,
            style: Styles.baseTextTheme.headline2
                .copyWith(
              fontWeight: FontWeight.bold,
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 15.0, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.only(
                    right: controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Text(
                     Strings.snoozeNotificationsFromTheGroup,//Strings.pushNotifications,
                      style:
                      Styles.baseTextTheme.headline1.copyWith(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Switch(
                        value: controller.isChatSnoozeNotification,
                        activeColor: controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          controller.setSnoozeNotification("message", snoozeValue);
                        }),
                  ],
                ),
              ),
              SizedBox(
                height: 5,
              ),
              Padding(
                padding: EdgeInsets.only(
                    right: controller.languageData.appLang.id == 2
                        ? 15.0
                        : 0),
                child: Row(
                  children: [
                    Text(
                      Strings.snoozeMentions,//Strings.pushNotifications,
                      style:
                      Styles.baseTextTheme.headline1.copyWith(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 16 : 14,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Spacer(),
                    Switch(
                        value: controller.isChatSnoozeMention,
                        activeColor: controller.displayColor,
                        onChanged: (value) async {
                          int snoozeValue = value ? 1 : 0;
                          controller.setSnoozeNotification("mention", snoozeValue);
                        }),
                  ],
                ),
              ),
              Text(
               Strings.disableNotificationsWhenPeoplemention,
                style: TextStyle(
                    fontSize: 12, color: Colors.grey[500]),
              ),
              SizedBox(
                height: 10,
              ),

            ],
          ),
        )
      ],
    );

  }

  void getMessagesOfAConversation(BuildContext context, NewsfeedController controller) {
    controller.isImagePickedChat = false;
    controller.isVideoPickedChat = false;
    controller.isDocumentPickedChat = false;
    controller.messageController.clear();
    controller.showOverlay = false;
    // print("pressed button on click");
    controller.messageController.text = "";
    controller.messageSearchController.text = "";
    controller.isChatSearchActive = false;

    controller.tempGroupName = "";
    controller.tempProfileImageGroupChat = null;

    controller.focusNode.requestFocus();
    controller.isChatScreenWeb = true;
    if (controller.chatName == null) controller.chatName = controller.chatUserList[0];
    controller.groupName = controller.chatName.conversationType == "group"
        ? "${controller.chatName.name}"
        : "${controller.chatName.name}";
    controller.infoChatInfo = false;
    controller.getMessagesOfAConversation(controller.chatName.conversationId);

    int chatIndex = 0;
    chatIndex = controller.chatUserList.indexWhere((element) {
      return element.conversationId == controller.chatName.conversationId;
    });
    controller.chatIndex = chatIndex;
    controller.highlighteTheChat = chatIndex;

    // controller.update();
  }

  Widget conversationsList(BuildContext context, NewsfeedController controller) {
    return SizedBox(
      height: Get.height,
      width: MediaQuery.of(context).size.width >= 1050
          ? 380
          : MediaQuery.of(context).size.width >= 1050
          ? 952
          : MediaQuery.of(context).size.width >= 700
          ? 560
          : MediaQuery.of(context).size.width / 1.3,
      child: controller.isRequestScreen ? const MessageRequestScreen() : SingleChildScrollView(
        controller: chatScreenController,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(
                  left: 10.0, right: 10.0, top: 10, bottom: 14),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      Strings.chats,
                      // style: TextStyle(
                      //     fontSize: 18,
                      //     color: Colors.black,
                      //     fontWeight: FontWeight.w900)
                      style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  ),
                  // IconButton(
                  //   onPressed: () {},
                  //   icon: Icon(Icons.settings),
                  // ),
                  GestureDetector(
                    onTap: () {
                      print("jkkjbkjb");
                      controller.idList.clear();
                      controller.chatSearchTEC.clear();
                      controller.usersList = null;
                      controller.randomGroup = "";
                      controller.update();
                      showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            contentPadding: EdgeInsets.zero,
                            insetPadding: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            content: NewMessageDialogBox(),
                          );
                        },
                      );
                    },
                    child: Image.asset(
                      'assets/chaticons/message_icon.png',
                      width: 25,
                      height: 25,
                      color: Colors.black,
                    ),
                    // Icon(
                    //   Icons.add,
                    //   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                    // ),
                  ),
                ],
              ),
            ),
            // Container(
            //   height: 1,
            //   width: Get.width,
            //   color: Colors.grey[200],
            // ),
            searchChatBar(),
            controller != null && controller.chatRequestUserList != null?
            InkWell(
              onTap: () async{
                controller.chatRequestUserList = await controller.getMessageRequest();
                setState(() {
                  controller.isRequestScreen = true;
                });

                // Get.to(MessageRequestScreen());
              },
              child: ListTile(
                leading: CircleAvatar(
                  child: Image.asset("assets/chaticons/message_icon.png",
                    color: Colors.black,
                    height: 50,
                    width: 50,
                  ),
                  backgroundColor: Colors.white,
                ),
                title: Text(Strings.messageRequests,
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold
                  ),
                ),
                subtitle: Text(controller.chatRequestUserList==null || controller==null? "0 "+Strings.pendingRequest:"${controller.chatRequestUserList.length} " +Strings.pendingRequest),

              ),
            )
                : const SizedBox(),
            controller.isChatLoad && (controller.chatUserList == null || controller.chatUserList.isEmpty)
                ? const Center(
              child: Padding(
                padding: EdgeInsets.only(top: 10.0),
                child: CircularProgressIndicator(
                  color: MyColors.BlueColor,
                ),
              ),
            ) :
            controller.isChatSearchActive && controller.messageSearchController.text.trim() == ""
                // Chat search is active with empty search string
                ? Container(
                margin: const EdgeInsets.only(top:30.0),
                child: Text(Strings.trySearchingForPeopleGroupsOrMessages,
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white70
                          : Colors.black54,
                      fontSize: 14),
                )
            )
                : controller.isChatSearchActive && controller.messageSearchController.text.trim() != ""
                // Chat search is active with a valid search string
                ? searchChatTabs()
                : controller.chatUserList == null? Container(): controller.chatUserList != null ||
                controller.chatUserList.isNotEmpty
                // Chat Conversation List
                ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ///1st list
                Column(
                            children:controller.chatUserList ==null || controller==null? SizedBox(): List.generate(
                      controller.chatUserList.length, (index) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          top: 0.0, left: 0, right: 0),
                      child: Card(
                        elevation: 0.0,
                        color:
                        /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
                        controller.chatName != null &&
                            controller.chatName
                                .conversationId !=
                                null &&
                            controller.chatUserList[index]
                                .conversationId !=
                                null &&
                            controller.chatName
                                .conversationId ==
                                controller.chatUserList[index]
                                                      .conversationId && controller.chatName.name != null
                        // controller.highlighteTheChat ==  index
                            ? Theme.of(context).brightness ==
                            Brightness.dark
                            ? Color(0xff202327)
                            : Color(0xffeff3f4)
                            : Colors.transparent,
                        child: InkWell(
                          onTap: kIsWeb
                              ? () {
                            controller.isImagePickedChat =
                            false;
                            controller.isVideoPickedChat =
                            false;
                            controller.isDocumentPickedChat =
                            false;
                            controller.messageController
                                .clear();
                            controller.showOverlay = false;
                            // print("pressed button on click");
                            controller.messageController.text =
                            "";

                            controller.tempGroupName = "";
                            controller
                                .tempProfileImageGroupChat =
                            null;

                            controller.focusNode.requestFocus();
                            controller.isChatScreenWeb = true;
                            controller.chatName =
                            controller.chatUserList[index];
                            controller.groupName = controller
                                .chatName
                                .conversationType ==
                                "group"
                                ? "${controller.chatName.name}"
                                : "${controller.chatName.name}";
                            controller.infoChatInfo = false;
                            controller.getMessagesOfAConversation(controller
                                .chatName.conversationId);
                            controller.chatIndex = index;
                            controller.highlighteTheChat =
                                index;

                            controller.update();
                          }
                              : () {
                            print("pressed");
                            controller.messageController.text =
                            "";
                            controller.tempGroupName = "";
                            controller
                                .tempProfileImageGroupChat =
                            null;
                            controller.update();
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ChatScreenMobile(
                                                            controller, false)));
                          },
                          child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  controller.chatUserList[index]
                                      .conversationType !=
                                      "group"
                                      ? CircleAvatar(
                                    backgroundImage: controller
                                        .chatUserList[
                                    index]
                                        .profileImage !=
                                        null
                                        ? NetworkImage(
                                        controller
                                            .chatUserList[
                                        index]
                                            .profileImage)
                                        : AssetImage(
                                        'assets/images/person_placeholder.png'),
                                    radius: 22,
                                  )
                                      : CircleAvatar(
                                    backgroundImage: controller
                                        .chatUserList[
                                    index]
                                        .groupImage !=
                                        null
                                        ? NetworkImage(
                                        controller
                                            .chatUserList[
                                        index]
                                            .groupImage)
                                        : AssetImage(
                                        'assets/images/person_placeholder.png'),
                                    radius: 22,
                                  ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                      MainAxisAlignment.start,
                                      children: [
                                        conversationTitle(index),
                                        Text(
                                          controller
                                              .chatUserList[index].latest_message_type == 1
                                              ? controller.chatUserList[index].latestMessage : controller.chatUserList[index].latest_message_type == 2
                                              ? Strings.photoChat
                                              : controller
                                              .chatUserList[
                                          index]
                                              .latest_message_type ==
                                              3
                                              ? Strings.videoChat
                                              : controller.chatUserList[index]
                                              .latest_message_type ==
                                              9
                                              ? Strings.fileChat
                                              : '',
                                          overflow:
                                          TextOverflow.ellipsis,
                                          maxLines: 1,
                                          style: Styles
                                              .baseTextTheme.headline2
                                              .copyWith(
                                            color: Theme.of(context)
                                                .brightness ==
                                                Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                            fontSize: 15,
                                            fontWeight:
                                            FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Column(
                                  //   children: [
                                  //     Text(
                                  //         "jkbdjsbfjbfjksbdfjbsdf")
                                  //   ],
                                  // )
                                ],
                              )),
                        ),
                      ),
                    );
                  }),
                ),
              ],
            )
                // No Chat Message
                : Column(
              children: [
                Text(
                  Strings.sendAMessageGetAMessage,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900),

                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 14 : 12,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  Strings
                      .directMessagesArePrivateConversationsBetweenYouAndOtherPeopleOnTwitterShareTweetsMediaAndMore,
                  textAlign: TextAlign.center,
                  // style: TextStyle(color: Colors.black),

                  style: Styles.baseTextTheme.headline4.copyWith(
                    color: Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.white
                        : Colors.black,
                    fontSize: kIsWeb ? 14 : 12,
                  ),
                ),
                SizedBox(height: 14),
                RoundedButton(
                  Strings.startAConversation,
                      () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          contentPadding: EdgeInsets.zero,
                          insetPadding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          content: NewMessageDialogBox(),
                        );
                      },
                    );
                  },
                  horizontalPadding: 40,
                  roundedButtonColor: controller.displayColor,
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget conversationTitle(int index) {
    String chatUserName = controller.chatUserList[index].username;
    String getChatDate = controller.chatUserList[index].latestMessageTime == null
        ? ""
        : UtilsMethods.getChatDate(controller.chatUserList[index].latestMessageTime);

    String conversationTitle = "";
    if (controller.chatUserList[index].conversationType == "group"){
      conversationTitle = ChatUtils.getGroupChatName(controller.chatUserList[index].members);
    } else {
      conversationTitle = controller.chatUserList[index].name ?? Strings.werfieUser;
    }


    return FittedBox(
      child: Row(
        children: [
   /*       controller.chatUserList[index].conversationType == "group"
              ? controller.chatUserList[index].name != null && controller.chatUserList[index].name != ""
                  ? SizedBox(
                      width: chatAuthorName.length > 10 ? 85 : null,
                      child: Text(
                        chatAuthorName ?? Strings.werfieUser,
                        overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline4.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    )
                  : controller.chatUserList[index].members.length == 1
                      ? FittedBox(
                          child: Row(
                          children: [
                            SizedBox(
                              width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                              child: Text(
                                controller.chatUserList[index].members[0].firstname,
                                overflow: controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                maxLines: 1,
                                style: Styles.baseTextTheme.headline4.copyWith(
                                  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ))
                      : controller.chatUserList[index].members.length == 2
                          ? FittedBox(
                              child: Row(
                              children: [
                                Container(
                                  width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                  child: Text(
                                    "${controller.chatUserList[index].members[0].firstname}, ",
                                    overflow:
                                        controller.chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    maxLines: 1,
                                    style: Styles.baseTextTheme.headline4.copyWith(
                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Container(
                                  width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                  child: Text(
                                    "${controller.chatUserList[index].members[1].firstname}",
                                    overflow:
                                        controller.chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    maxLines: 1,
                                    style: Styles.baseTextTheme.headline4.copyWith(
                                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ))
                          : controller.chatUserList[index].members.length == 3
                              ? FittedBox(
                                  child: Row(
                                    children: [
                                      Container(
                                        width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                        child: Text(
                                          "${controller.chatUserList[index].members[0].firstname}, ",
                                          overflow: controller.chatUserList[index].members[0].firstname.length > 10
                                              ? TextOverflow.ellipsis
                                              : null,
                                          maxLines: 1,
                                          style: Styles.baseTextTheme.headline4.copyWith(
                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      Text(
                                        "${controller.chatUserList[index].members.length - 1} ${Strings.otherChat}",
                                        style: Styles.baseTextTheme.headline4.copyWith(
                                          color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                          fontSize: 15,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : controller.chatUserList[index].members.length >= 4
                                  ? FittedBox(
                                      child: Row(
                                      children: [
                                        Container(
                                          width: controller.chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                          child: Text(
                                            "${controller.chatUserList[index].members[0].firstname}, ",
                                            overflow: controller.chatUserList[index].members[0].firstname.length > 10
                                                ? TextOverflow.ellipsis
                                                : null,
                                            maxLines: 1,
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        Container(
                                          width: controller.chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                          child: Text(
                                            "${controller.chatUserList[index].members[1].firstname}, ",
                                            overflow: controller.chatUserList[index].members[1].firstname.length > 10
                                                ? TextOverflow.ellipsis
                                                : null,
                                            maxLines: 1,
                                            style: Styles.baseTextTheme.headline4.copyWith(
                                              color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                        ),
                                        // Text(
                                        //   "${controller.chatUserList[index].members[2].firstname} and ",
                                        //   style: Theme.of(context).brightness == Brightness.dark ?
                                        //   TextStyle(color: Colors.white,
                                        //       fontWeight: FontWeight.w600,overflow:
                                        //       TextOverflow.ellipsis
                                        //   )
                                        //       : TextStyle(color: Colors.black,
                                        //       fontWeight: FontWeight.w600,overflow:
                                        //       TextOverflow.ellipsis
                                        //   ),
                                        // ),
                                        Text(
                                          "${controller.chatUserList[index].members.length - 2} ${Strings.otherChat}",
                                          style: Styles.baseTextTheme.headline4.copyWith(
                                            color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                            fontSize: 15,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ))
                                  : SizedBox()
              : SizedBox(),*/

       /*   controller.chatUserList[index].conversationType == "single"
              ? Container(
                  width: chatAuthorName.length > 10 ? 85 : null,
                  child: Text(
                    "${chatAuthorName}",
                    overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                    maxLines: 1,
                    style: Styles.baseTextTheme.headline4.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )
              : SizedBox(),*/

          // controller.chatUserList[index].accountVerified =="verified"?
          // Row(children: [
          //   SizedBox(
          //     width: 5,
          //   ),
          //   BlueTick(
          //     height: 15,
          //     width: 15,
          //     iconSize:10,
          //   ),
          // ],):SizedBox()

          Container(
            // width: conversationTitle.length > 10 ? 85 : null,
            child: Text(
              conversationTitle,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          controller.chatUserList[index].conversationType == "group"
              ? Text(
                  Strings.groupsTabChat,
                  style: Styles.baseTextTheme.headline2.copyWith(
                    fontWeight: FontWeight.w400,
                    fontSize: 15,
                  ),
                )
              : controller.chatUserList[index].conversationType == "single"
                  ? Container(
                      width: chatUserName.length > 15 ? 100 : null,
                      child: Text(
                        "@${chatUserName}",
                        overflow: chatUserName.length > 15 ? TextOverflow.ellipsis : null,
                        softWrap: false,
                        maxLines: 1,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          fontWeight: FontWeight.w400,
                          fontSize: 15,
                        ),
                      ),
                    )
                  : SizedBox(),
          controller.chatUserList[index].latestMessageTime == null
              ? SizedBox()
              : Row(
                  children: [
                    SizedBox(
                      width: 2,
                    ),
                    Text(
                      ".",
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(
                      width: 2,
                    ),
                    Text(
                      getChatDate == null ? "" : getChatDate,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        fontSize: 15,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
        ],
      ),
    );
  }

  /* Chat Search related methods */
  Widget searchChatBar(){
    return Container(
      margin: const EdgeInsets.only(left: 10.0, right: 10.0, bottom: 15.0, top:5.0),
      height: 45,
      width: MediaQuery.of(context).size.width * 0.7,
      child: Row(
        children: [
          controller.isChatSearchActive ? GestureDetector(
            onTap: () {
                controller.isChatSearchActive = false;
                controller.messageSearchController.text= "";
                controller.update();
            },
            child: Container(
              margin: const EdgeInsets.only(right:5.0),
              child: Icon(
                Icons.arrow_back,
                color: Theme.of(context).brightness ==
                    Brightness.dark
                    ? Colors.white
                    : Colors.black,
                size: 25,
              ),
            ),
          ) : Container(),
          Expanded(
            child: TextField(
              controller: controller.messageSearchController,
              onTap: (){
                print("Textfield tapped");
                  controller.isChatSearchActive = true;
                  controller.update();

              },
              onChanged: (value){
                controller.isChatSearchActive = true;
                if (value != null && value.trim() != ""){
                  controller.searchChat(value);
                }
                // controller.update();
              },
              style: LightStyles.baseTextTheme.headline2.copyWith(
                color:
                Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
                //fontWeight: FontWeight.w500,
                // fontSize: 14,
              ),
              cursorColor:
              Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              textAlignVertical: TextAlignVertical.bottom,
              decoration: InputDecoration(
                hintText: Strings.searchChats, //Strings.search,
                hintStyle: LightStyles.baseTextTheme.headline3,
                prefixIcon: Icon(
                  Icons.search,
                  size: 20,
                  color: Theme.of(context).brightness ==
                      Brightness.dark
                      ? Colors.white
                      : Colors.black,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                  borderSide:
                  BorderSide(color: Colors.grey, width: 1),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(40),
                  borderSide:
                  BorderSide(color: Colors.grey, width: 1),
                  // style: BorderStyle.none,
                ),
                fillColor: Colors.white, //Colors.grey[250],
                filled: true,
              ),
            ),
          ),
        ],
      ),
    );
  }
  Widget searchChatTabs(){
    return Column(
        // crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TabBar(
            onTap: (index) {
              setState(() {
                // To update the view we need setState here.
              });
            },
            labelColor: Colors.black,
            indicatorColor: Colors.blue,
            indicatorWeight: 3.0,
            controller: searchChatTabController,
            // unselectedLabelColor: Colors.black,
            tabs:  [
              Tab(text:Strings.allTabChat ),
              Tab(text: Strings.peopleTabChat),
              Tab(text: Strings.groupsTabChat),
              Tab(text: Strings.chatsTabChat),
            ],
          ),
          Container(
              // height: Get.height,

              //height of TabBarView
              decoration: const BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          color: Colors.grey,
                          width: 0.5))),
              child: Column(
                // physics: const NeverScrollableScrollPhysics(),
                // controller: searchChatTabController,
                  children: <Widget>[
                    searchChatTabController.index == 0 ? allTabsSearchChat() : SizedBox(),
                    searchChatTabController.index == 1 ? searchPeopleList(controller.chatSearchPeopleList) : SizedBox(),
                    searchChatTabController.index == 2 ? searchGroupList(controller.chatSearchGroupList) : SizedBox(),
                    searchChatTabController.index == 3 ? searchMessageList(controller.chatSearchMessageList) : SizedBox(),
              ]))
        ]);
  }
  Widget noSearchResultMessage(){
    return Container(
      margin: const EdgeInsets.only(top: 25),
      child: Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "${Strings.noResultsFor} '${controller.messageSearchController.text}'", // Strings.youDoNotHaveAChatSelected,
            // style: TextStyle(
            //     fontSize: 18,
            //     color: Colors.black,
            //     fontWeight: FontWeight.w900),

            style: Styles.baseTextTheme.headline2.copyWith(
              color: Theme.of(context).brightness ==
                  Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontSize: kIsWeb ? 25 : 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Text(
            Strings.theTermYouEnteredDidNotBring,
            // Strings.chooseOneFromYourExistingChatsOrStartANewOne,
            // style: TextStyle(color: Colors.black),

            style: Theme.of(context).brightness ==
                Brightness.dark
                ? TextStyle(color: Colors.white)
                : TextStyle(color: Colors.black),
          ),
          SizedBox(height: 14),
          RoundedButton(
            Strings.newChat,
                () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    backgroundColor:
                    Theme.of(context).brightness ==
                        Brightness.dark
                        ? Colors.black
                        : Colors.white,
                    contentPadding: EdgeInsets.zero,
                    insetPadding: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    content: NewMessageDialogBox(),
                  );
                },
              );
            },
            horizontalPadding: 40,
            roundedButtonColor: controller.displayColor,
          ),
        ],
      ),
    );
  }
  Widget allTabsSearchChat(){
    return Column(
      children: [
        controller.chatSearchPeopleList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    'assets/svg_drawer_icons/profileFill.svg',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),

                Text(
                  Strings.peopleTabChat,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchPeopleList(controller.chatSearchPeopleList, isAllTab: true),
            controller.chatSearchPeopleList.length > 5 ? Column(
              children: [
                const Divider(height: 1.0,),
                InkWell(
                  onTap: (){
                    chatScreenController.jumpTo(
                      chatScreenController.position.minScrollExtent,
                    );
                    searchChatTabController.animateTo(1);
                    setState(() {
                      // to update the view we need setState here.
                    });
                  },
                  child: Container(
                      margin: const EdgeInsets.all(10.0),
                      child:  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(Strings.seeMore, textAlign: TextAlign.start, style: TextStyle(color: Colors.blue),))),
                ),
              ],
            ) : const SizedBox(),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        controller.chatSearchGroupList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                    margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                    child: const Icon(Icons.group,)),
                Text(
                  Strings.groupsTabChat,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchGroupList(controller.chatSearchGroupList,  isAllTab: true),
            controller.chatSearchGroupList.length > 5 ? Column(
              children: [
                const Divider(height: 1.0,),
                InkWell(
                  onTap: (){
                    chatScreenController.jumpTo(
                      chatScreenController.position.minScrollExtent,
                    );
                    searchChatTabController.animateTo(2);
                    setState(() {
                      // to update the view we need setState here.
                    });
                  },
                  child: Container(
                      margin: const EdgeInsets.all(10.0),
                      child:  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(Strings.seeMore, textAlign: TextAlign.start, style: TextStyle(color: Colors.blue),))),
                ),
              ],
            ) : const SizedBox(),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        controller.chatSearchMessageList.isNotEmpty ? Column(
          children: [
            const SizedBox(height: 10.0,),
            Row(
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 10.0, right: 10.0),
                  width: 30,
                  height: 30,
                  child: SvgPicture.asset(
                    'assets/svg_drawer_icons/messageFill.svg',
                    color: Theme.of(context).brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black,
                  ),
                ),
                Text(
                  Strings.message,//Strings.chats,
                  // style: TextStyle(
                  //     fontSize: 18,
                  //     color: Colors.black,
                  //     fontWeight: FontWeight.w900)
                  style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ),
              ],
            ),
            const SizedBox(height: 10.0,),
            const Divider(height: 1.0,),
            searchMessageList(controller.chatSearchMessageList,  isAllTab: true),
            controller.chatSearchMessageList.length > 5 ? Column(
              children: [
                const Divider(height: 1.0,),
                InkWell(
                  onTap: (){
                    chatScreenController.jumpTo(
                      chatScreenController.position.minScrollExtent,
                    );
                    searchChatTabController.animateTo(3);
                    setState(() {
                      // to update the view we need setState here.
                    });
                  },
                  child: Container(
                      margin: const EdgeInsets.all(10.0),
                      child:  Align(
                          alignment: Alignment.centerLeft,
                          child: Text(Strings.seeMore, textAlign: TextAlign.start, style: TextStyle(color: Colors.blue),))),
                ),
              ],
            ) : const SizedBox(),
            const Divider(height: 1.0,),
          ],
        ) : const SizedBox(),
        const SizedBox(height: 10.0,),
      ],
    );
  }
  Widget searchPeopleList(List<MessageModel> searchPeopleList, {bool isAllTab = false}){
    if(searchPeopleList.isEmpty){
      return noSearchResultMessage();
    }

    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
      itemCount: searchPeopleList.length,
      itemBuilder: (BuildContext context, int index){

        String ChatUserName = searchPeopleList[index].username ?? "";
        String chatAuthorName = searchPeopleList[index].firstname ?? "";

        return Padding(
          padding: const EdgeInsets.only(
              top: 0.0, left: 0, right: 0),
          child: Card(
            elevation: 0.0,
            color:
            /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
            controller.chatName != null && controller.chatName.conversationId != null
                // && controller.chatUserList[index].conversationId != null
                && controller.chatName.conversationId == searchPeopleList[index].id
            // controller.highlighteTheChat ==  index
                ? Theme.of(context).brightness == Brightness.dark
                ? Color(0xff202327)
                : Color(0xffeff3f4)
                : Colors.transparent,
            child: InkWell(
              onTap: () {
                gotoChatMessage(searchPeopleList[index].conversationId);
                // Search Peple - {id: 452, firstname: Kathir Testing, lastname: , username: KathirTest, profile_image: null, body: Hi, message_id: 2835}
                // Conversation List - {"conversation_id":433,"conversation_type":"single","name":"Kathir Testing ","group_image":null,"target_id":428,"user_id":452,"is_request":1,"is_mute":0,
                // int chatIndex = controller.chatUserList.indexWhere((item) => item.conversationId == searchPeopleList[index].id);
                // if (chatIndex == -1) {
                //   print("index not found chat conversation");
                //   return;
                // }
                // controller.isImagePickedChat = false;
                // controller.isVideoPickedChat = false;
                // controller.isDocumentPickedChat = false;
                // controller.messageController.clear();
                // controller.showOverlay = false;
                // controller.messageController.text = "";
                //
                // controller.tempGroupName = "";
                //         controller.tempProfileImageGroupChat = null;
                //
                //         controller.focusNode.requestFocus();
                //         controller.isChatScreenWeb = true;
                //
                //         controller.chatName = controller.chatUserList[chatIndex];
                //         controller.groupName =
                //             controller.chatName.conversationType == "group"
                //                 ? "${controller.chatName.name}"
                //                 : "${controller.chatName.name}";
                //         controller.infoChatInfo = false;
                //         controller
                //             .createMessage(controller.chatName.conversationId);
                //         controller.chatIndex = chatIndex;
                //         controller.highlighteTheChat = chatIndex;
                //
                //         controller.update();
                      },
              child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    crossAxisAlignment:
                    CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        backgroundImage: searchPeopleList[
                        index]
                            .profileImage !=
                            null
                            ? NetworkImage(searchPeopleList[
                        index]
                            .profileImage)
                            : AssetImage(
                            'assets/images/person_placeholder.png'),
                        radius: 22,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.start,
                          children: [
                            FittedBox(
                              child: Row(
                                children: [
                                  Container(width: 1.0, height:1.0),
                                  Container(
                                    width: chatAuthorName.length > 10 ? 85 : null,
                                    child: Text(
                                      "${chatAuthorName}",
                                      overflow: chatAuthorName.length > 10
                                          ? TextOverflow.ellipsis : null,
                                      maxLines: 1,
                                      style: Styles
                                          .baseTextTheme
                                          .headline4
                                          .copyWith(
                                        color: Theme.of(context).brightness ==
                                            Brightness
                                                .dark
                                            ? Colors
                                            .white
                                            : Colors
                                            .black,
                                        fontSize:
                                        15,
                                        fontWeight:
                                        FontWeight
                                            .bold,
                                      ),
                                    ),
                                  ),


                                  // controller.chatUserList[index].accountVerified =="verified"?
                                  // Row(children: [
                                  //   SizedBox(
                                  //     width: 5,
                                  //   ),
                                  //   BlueTick(
                                  //     height: 15,
                                  //     width: 15,
                                  //     iconSize:10,
                                  //   ),
                                  // ],):SizedBox()



                                ],
                              ),
                            ),
                            RegexTextHighlight(text: "@$ChatUserName",
                              maxLines: 1,
                              highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                              highlightStyle: Styles.baseTextTheme.headline2
                                  .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                              nonHighlightStyle: Styles.baseTextTheme.headline2
                                  .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                            ),
                            // Container(
                            //   // width: ChatUserName.length >
                            //   //     15
                            //   //     ? 100
                            //   //     : null,
                            //   child: Text(
                            //     "@${ChatUserName}",
                            //     overflow: TextOverflow.ellipsis,
                            //     softWrap:
                            //     false,
                            //     maxLines:
                            //     1,
                            //     style: Styles
                            //         .baseTextTheme
                            //         .headline2
                            //         .copyWith(
                            //       fontWeight:
                            //       FontWeight.w400,
                            //       fontSize:
                            //       15,
                            //     ),
                            //   ),
                            // ),

                          ],
                        ),
                      ),

                    ],
                  )),
            ),
          ),
        );
      });
  }
  Widget searchGroupList(List<ChatUserModel> chatUserList, {bool isAllTab = false}){
    if(chatUserList.isEmpty){
      return noSearchResultMessage();
    }
    int groupLength = chatUserList.length;
    if (isAllTab && chatUserList.length > 5) {
      groupLength = 5;
    }
    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: groupLength,
        itemBuilder: (BuildContext context, int index){
          String chatAuthorName = chatUserList[index].name ?? "";
          return Padding(
            padding: const EdgeInsets.only(
                top: 0.0, left: 0, right: 0),
            child: Card(
              elevation: 0.0,
              // color:
              /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
              // controller.chatName != null && controller.chatName.conversationId != null
              //     && controller.chatUserList[index].conversationId != null
              //     && controller.chatName.conversationId == controller.chatUserList[index].conversationId
              // // controller.highlighteTheChat ==  index
              //     ? Theme.of(context).brightness == Brightness.dark
              //     ? Color(0xff202327)
              //     : Color(0xffeff3f4)
              //     : Colors.transparent,
              child: InkWell(
                onTap: () {
                  gotoChatMessage(chatUserList[index].conversationId);
                  // controller.isImagePickedChat =
                  // false;
                  // controller.isVideoPickedChat =
                  // false;
                  // controller.isDocumentPickedChat =
                  // false;
                  // controller.messageController
                  //     .clear();
                  // controller.showOverlay = false;
                  // print("pressed button on click");
                  // controller.messageController.text =
                  // "";
                  //
                  // controller.tempGroupName = "";
                  // controller
                  //     .tempProfileImageGroupChat =
                  // null;
                  //
                  // controller.focusNode.requestFocus();
                  // controller.isChatScreenWeb = true;
                  // controller.chatName =
                  // controller.chatUserList[index];
                  // controller.groupName = controller
                  //     .chatName
                  //     .conversationType ==
                  //     "group"
                  //     ? "${controller.chatName.name}"
                  //     : "${controller.chatName.name}";
                  // controller.infoChatInfo = false;
                  // controller.createMessage(controller
                  //     .chatName.conversationId);
                  // controller.chatIndex = index;
                  // controller.highlighteTheChat =
                  //     index;
                  //
                  // controller.update();
                },
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [

                        CircleAvatar(
                          backgroundImage:
                          chatUserList[
                          index]
                              .groupImage !=
                              null
                              ? NetworkImage(

                              chatUserList[
                              index]
                                  .groupImage)
                              : AssetImage(
                              'assets/images/person_placeholder.png'),
                          radius: 22,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: [
                              FittedBox(
                                child: Row(
                                  children: [
                                    Container(width: 1.0, height:1.0),
                                    // chatUserList[index].conversationType == "group" ?
                                    // : chatUserList[index].members.length == 1
                                    //         ? FittedBox(
                                    //         child:
                                    //         Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10
                                    //                   ? 85
                                    //                   : null,
                                    //               child:
                                    //               Text(
                                    //                 "${chatUserList[index].members[0].firstname}",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : chatUserList[index].members.length ==
                                    //         2
                                    //         ? FittedBox(
                                    //         child:
                                    //         Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[0].firstname}, ",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             Container(
                                    //               width: chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[1].firstname}",
                                    //                 overflow: chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : chatUserList[index].members.length ==
                                    //         3
                                    //         ? FittedBox(
                                    //       child: Row(
                                    //         children: [
                                    //           Container(
                                    //             width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //             child: Text(
                                    //               "${chatUserList[index].members[0].firstname}, ",
                                    //               overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //               maxLines: 1,
                                    //               style: Styles.baseTextTheme.headline4.copyWith(
                                    //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                 fontSize: 15,
                                    //                 fontWeight: FontWeight.bold,
                                    //               ),
                                    //             ),
                                    //           ),
                                    //           Text(
                                    //             "${chatUserList[index].members.length - 1} other...",
                                    //             style: Styles.baseTextTheme.headline4.copyWith(
                                    //               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //               fontSize: 15,
                                    //               fontWeight: FontWeight.bold,
                                    //             ),
                                    //           ),
                                    //         ],
                                    //       ),
                                    //     )
                                    //         : chatUserList[index].members.length >= 4
                                    //         ? FittedBox(
                                    //         child: Row(
                                    //           children: [
                                    //             Container(
                                    //               width: chatUserList[index].members[0].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[0].firstname}, ",
                                    //                 overflow: chatUserList[index].members[0].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             Container(
                                    //               width: chatUserList[index].members[1].firstname.length > 10 ? 85 : null,
                                    //               child: Text(
                                    //                 "${chatUserList[index].members[1].firstname}, ",
                                    //                 overflow: chatUserList[index].members[1].firstname.length > 10 ? TextOverflow.ellipsis : null,
                                    //                 maxLines: 1,
                                    //                 style: Styles.baseTextTheme.headline4.copyWith(
                                    //                   color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                   fontSize: 15,
                                    //                   fontWeight: FontWeight.bold,
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //             // Text(
                                    //             //   "${controller.chatUserList[index].members[2].firstname} and ",
                                    //             //   style: Theme.of(context).brightness == Brightness.dark ?
                                    //             //   TextStyle(color: Colors.white,
                                    //             //       fontWeight: FontWeight.w600,overflow:
                                    //             //       TextOverflow.ellipsis
                                    //             //   )
                                    //             //       : TextStyle(color: Colors.black,
                                    //             //       fontWeight: FontWeight.w600,overflow:
                                    //             //       TextOverflow.ellipsis
                                    //             //   ),
                                    //             // ),
                                    //             Text(
                                    //               "${chatUserList[index].members.length - 2} other...",
                                    //               style: Styles.baseTextTheme.headline4.copyWith(
                                    //                 color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                    //                 fontSize: 15,
                                    //                 fontWeight: FontWeight.bold,
                                    //               ),
                                    //             ),
                                    //           ],
                                    //         ))
                                    //         : SizedBox()
                                    //         : SizedBox(),

                                    // controller.chatUserList[index].accountVerified != null &&
                                    // controller.chatUserList[index].accountVerified =="verified"?
                                    // Row(children: [
                                    //   SizedBox(
                                    //     width: 5,
                                    //   ),
                                    //   BlueTick(
                                    //     height: 15,
                                    //     width: 15,
                                    //     iconSize:10,
                                    //   ),
                                    // ],):SizedBox(),
                                    Text(
                                      Strings.groupsTabChat,
                                      style: Styles
                                          .baseTextTheme
                                          .headline2
                                          .copyWith(
                                        fontWeight:
                                        FontWeight
                                            .bold,
                                        color: Theme.of(context).brightness ==
                                            Brightness.dark ? Colors.white : Colors.black,
                                        fontSize: 15,
                                      ),
                                    ),
                                    // chatUserList[index].latestMessageTime == null
                                    //     ? SizedBox()
                                    //     : Row(
                                    //   children: [
                                    //     SizedBox(
                                    //       width: 2,
                                    //     ),
                                    //     Text(
                                    //       ".",
                                    //       style: Styles
                                    //           .baseTextTheme
                                    //           .headline2
                                    //           .copyWith(
                                    //         fontSize:
                                    //         20,
                                    //         fontWeight:
                                    //         FontWeight
                                    //             .w500,
                                    //       ),
                                    //     ),
                                    //     SizedBox(
                                    //       width: 2,
                                    //     ),
                                    //     Text(
                                    //       getChatDate ==
                                    //           null
                                    //           ? ""
                                    //           : getChatDate,
                                    //       overflow:
                                    //       TextOverflow
                                    //           .ellipsis,
                                    //       maxLines: 1,
                                    //       style: Styles
                                    //           .baseTextTheme
                                    //           .headline2
                                    //           .copyWith(
                                    //         fontSize:
                                    //         15,
                                    //         fontWeight:
                                    //         FontWeight
                                    //             .w400,
                                    //       ),
                                    //     ),
                                    //   ],
                                    // ),


                                  ],
                                ),
                              ),
                              RegexTextHighlight(text: chatAuthorName,
                                maxLines: 1,
                                highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                                highlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                                nonHighlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                              ),

                              // chatUserList[index].name != null
                              //     ? Container(
                              //   width: 170, //chatAuthorName.length > 10 ? 85 : null,
                              //   child: Text(
                              //     "${chatAuthorName}",
                              //     overflow: chatAuthorName.length > 10 ? TextOverflow.ellipsis : null,
                              //     maxLines: 1,
                              //     style: Styles.baseTextTheme.headline4
                              //         .copyWith(
                              //
                              //       fontSize: 15,
                              //       fontWeight: FontWeight.w400,
                              //     ),
                              //   ),
                              // ) : Container(),
                            ],
                          ),
                        ),

                      ],
                    )),
              ),
            ),
          );
        });
  }
  Widget searchMessageList(List<MessageModel> msgModelList, {bool isAllTab = false}){
    if(msgModelList.isEmpty){
      return noSearchResultMessage();
    }
    return ListView.builder(
        physics: const NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        itemCount: msgModelList.length,
        itemBuilder: (BuildContext context, int index){
          // String getChatDate;
          // getChatDate = chatUserList[index]
          //     .latestMessageTime ==
          //     null
          //     ? ""
          //     : UtilsMethods.getChatDate(chatUserList[index].latestMessageTime);

          // String ChatUserName = msgModelList[index].username ?? "";
          String chatAuthorName = msgModelList[index].firstname ?? "";
          String message = msgModelList[index].body ?? "";

          // return Text("Search $index");
          return Padding(
            padding: const EdgeInsets.only(
                top: 0.0, left: 0, right: 0),
            child: Card(
              elevation: 0.0,
              // color:
              /* Changed the logic of highlighting from using index to comparing conversation ID due to web bug - When the user message a user who is in the
                                bottom of the chat list then that user comes to top of the list as it is the active chat. but we are not
                                changing the "controller.highlighteTheChat" value during that time. we change this only when selecting the chat. So its
                                highlighting the wrong chat. Highlighting using conversation id solves this problem. - K
                            */
              // controller.chatName != null && controller.chatName.conversationId != null
              //     && controller.chatUserList[index].conversationId != null
              //     && controller.chatName.conversationId == controller.chatUserList[index].conversationId
              // // controller.highlighteTheChat ==  index
              //     ? Theme.of(context).brightness == Brightness.dark
              //     ? Color(0xff202327)
              //     : Color(0xffeff3f4)
              //     : Colors.transparent,
              child: InkWell(
                onTap:() {
                  gotoChatMessage(msgModelList[index].conversationId);
                  // controller.isImagePickedChat =
                  // false;
                  // controller.isVideoPickedChat =
                  // false;
                  // controller.isDocumentPickedChat =
                  // false;
                  // controller.messageController
                  //     .clear();
                  // controller.showOverlay = false;
                  // print("pressed button on click");
                  // controller.messageController.text =
                  // "";
                  //
                  // controller.tempGroupName = "";
                  // controller
                  //     .tempProfileImageGroupChat =
                  // null;
                  //
                  // controller.focusNode.requestFocus();
                  // controller.isChatScreenWeb = true;
                  // controller.chatName =
                  // controller.chatUserList[index];
                  // controller.groupName = controller
                  //     .chatName
                  //     .conversationType ==
                  //     "group"
                  //     ? "${controller.chatName.name}"
                  //     : "${controller.chatName.name}";
                  // controller.infoChatInfo = false;
                  // controller.createMessage(controller
                  //     .chatName.conversationId);
                  // controller.chatIndex = index;
                  // controller.highlighteTheChat =
                  //     index;
                  //
                  // controller.update();
                },
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundImage: msgModelList[
                          index]
                              .profileImage !=
                              null
                              ? NetworkImage(msgModelList[
                          index]
                              .profileImage)
                              : AssetImage(
                              'assets/images/person_placeholder.png'),
                          radius: 22,
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            mainAxisAlignment:
                            MainAxisAlignment.start,
                            children: [
                              FittedBox(
                                child: Row(
                                  children: [
                                    Container(width: 1.0, height:1.0),
                                    Container(
                                      width: chatAuthorName.length > 10 ? 85 : null,
                                      child: Text(
                                        "${chatAuthorName}",
                                        overflow: chatAuthorName.length > 10
                                            ? TextOverflow.ellipsis : null,
                                        maxLines: 1,
                                        style: Styles
                                            .baseTextTheme
                                            .headline4
                                            .copyWith(
                                          color: Theme.of(context).brightness ==
                                              Brightness
                                                  .dark
                                              ? Colors
                                              .white
                                              : Colors
                                              .black,
                                          fontSize:
                                          15,
                                          fontWeight:
                                          FontWeight
                                              .bold,
                                        ),
                                      ),
                                    ),


                                    // msgModelList[index].accountVerified =="verified"?
                                    // Row(children: [
                                    //   SizedBox(
                                    //     width: 5,
                                    //   ),
                                    //   BlueTick(
                                    //     height: 15,
                                    //     width: 15,
                                    //     iconSize:10,
                                    //   ),
                                    // ],):SizedBox()



                                  ],
                                ),
                              ),

                              RegexTextHighlight(text: message,
                                maxLines: 2,
                                highlightRegex: RegExp(controller.messageSearchController.text.trim(), caseSensitive: false),
                                highlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15, backgroundColor: Colors.yellow),
                                nonHighlightStyle: Styles.baseTextTheme.headline2
                                    .copyWith(fontWeight: FontWeight.w400, fontSize: 15,),
                              ),
                              // Container(
                              //   // width: ChatUserName.length >
                              //   //     15
                              //   //     ? 100
                              //   //     : null,
                              //   child: Text(
                              //     message,
                              //     overflow: TextOverflow.ellipsis,
                              //     softWrap: false,
                              //     maxLines: 2,
                              //     style: Styles
                              //         .baseTextTheme
                              //         .headline2
                              //         .copyWith(
                              //       fontWeight:
                              //       FontWeight.w400,
                              //       fontSize:
                              //       15,
                              //     ),
                              //   ),
                              // ),

                            ],
                          ),
                        ),

                      ],
                    )),
              ),
            ),
          );
        });
  }
  gotoChatMessage(var conversationId){

    controller.isImagePickedChat = false;
    controller.isVideoPickedChat = false;
    controller.isDocumentPickedChat = false;
    controller.messageController.clear();
    controller.showOverlay = false;
    controller.messageController.text = "";
    controller.tempGroupName = "";
    controller.tempProfileImageGroupChat = null;
    controller.focusNode.requestFocus();
    controller.isChatScreenWeb = true;

    int chatIndex = 0;
    for(int i = 0; i < controller.chatUserList.length; i++ ){
      if (controller.chatUserList[i].conversationId == conversationId){
        chatIndex = i;
        controller.chatName = controller.chatUserList[i];
      }
    }
    controller.groupName = controller.chatName.conversationType == "group"
        ? "${controller.chatName.name}"
        : "${controller.chatName.name}";
    controller.infoChatInfo = false;
    controller.getMessagesOfAConversation(controller.chatName.conversationId);
    controller.chatIndex = chatIndex;
    controller.highlighteTheChat = chatIndex;

    controller.update();
  }
}
