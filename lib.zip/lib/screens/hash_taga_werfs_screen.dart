import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../utils/font.dart';
import '../widgets/custom_adwidget.dart';
import '../widgets/loading_widgets/list_view_loading_shimmer.dart';
import '../widgets/pagged_list_view.dart';
import '../widgets/post_card.dart';
import '../widgets/thread_post_card.dart';

class HashTagWerfsScreen extends StatefulWidget {
  final NewsfeedController controller;
  final String tag;

  const HashTagWerfsScreen({Key key, this.controller, this.tag})
      : super(key: key);

  @override
  State<HashTagWerfsScreen> createState() => _HashTagWerfsScreenState();
}

class _HashTagWerfsScreenState extends State<HashTagWerfsScreen> {
  @override
  void initState() {
    // TODO: implement initState
    //LoggingUtils.printValue("tag value", widget.tag);
    callHashTagApi();

    super.initState();
  }

  callHashTagApi() async {
    await widget.controller.hashTagWerfs(
        pageNo: 1, tag: widget.tag.trim(), isFromRoute: kIsWeb ? true : true);

    if(mounted)
    setState(() {});
  }

  //
  // void getDataForMobile() async{
  //   await widget.controller.hashTagWerfs(pageNo: 1,tag:widget.tag,isFromRoute: false);
  // setState(() {
  //
  // });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Responsive(
        mobile: HashTagWerfsClass(widget.tag),
        tablet: HashTagWerfsClass(widget.tag),
        desktop: HashTagWerfsClass(widget.tag),
      ),
    );
  }
}

class HashTagWerfsClass extends StatelessWidget {
  String tag;

  HashTagWerfsClass(this.tag);

  NewsfeedController controller = Get.find<NewsfeedController>();
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: !kIsWeb
          ? AppBar(
              backgroundColor: Colors.white,
              elevation: 0,
              iconTheme: IconThemeData(
                color: Colors.black,
              ),
              title: Text(
                Strings.werfHashTag,
                // style: TextStyle(color: Colors.black),
                style: Styles.baseTextTheme.headline2.copyWith(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
        leading: !kIsWeb
            ? MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GestureDetector(
              onTap: () {

                if (!kIsWeb) {
                  Navigator.of(context).pop();
                }else{
                  controller.isHiddenReplay = false;
                  controller.isPostDetails = false;
                  controller.isTrendsScreen = false;
                  controller.isBrowseScreen = false;
                  controller.isNotificationScreen = false;
                  controller.isChatScreen = false;
                  controller.isSavedPostScreen = false;
                  controller.isPostDetails = false;
                  controller.fromNotificationsScreen = false;
                  controller.isProfileScreen = false;
                  controller.isTagInfoScreen = false;
                  controller.isTagWerfsScreen = false;
                  controller.navRoute = "isNewsFeedScreen";
                  controller.isNewsFeedScreen = true;
                  controller.update();
                }

              },
              child: Icon(
                Icons.arrow_back,
                color: Theme.of(context).brightness ==
                    Brightness.dark
                    ? Colors.white
                    : Colors.black,
              )),
        )
            : SizedBox(),
            )
          : PreferredSize(child: Container(), preferredSize: Size(0, 0)),
      body: WillPopScope(

        onWillPop: () async {
          controller.isHiddenReplay = false;
          controller.isPostDetails = false;
          controller.isTrendsScreen = false;
          controller.isBrowseScreen = false;
          controller.isNotificationScreen = false;
          controller.isChatScreen = false;
          controller.isSavedPostScreen = false;
          controller.isTagInfoScreen = false;
          controller.isTagWerfsScreen = false;
          controller.isPostDetails = false;
          controller.isTagWerfsScreen = false;
          controller.fromNotificationsScreen = false;
          controller.isProfileScreen = false;
          controller.isTagInfoScreen = false;
          controller.navRoute = "isNewsFeedScreen";
          controller.isNewsFeedScreen = true;


          controller.update();
          return false;
        },
    child: kIsWeb
            ? Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                          // splashColor: Colors.white,
                          // hoverColor: Colors.grey[100],
                          icon: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                          ),
                          onPressed: () {

                            controller.isHiddenReplay = false;
                            controller.isPostDetails = false;
                            controller.isTrendsScreen = false;
                            controller.isBrowseScreen = false;
                            controller.isNotificationScreen = false;
                            controller.isChatScreen = false;
                            controller.isSavedPostScreen = false;
                            controller.isTagInfoScreen = false;
                            controller.isTagWerfsScreen = false;
                            controller.isPostDetails = false;
                            controller.fromNotificationsScreen = false;
                            controller.isProfileScreen = false;
                            controller.isTagInfoScreen = false;
                            controller.navRoute = "isNewsFeedScreen";
                            controller.isNewsFeedScreen = true;
                            controller.update();
                            Get.back();

                          }),
                      SizedBox(width: 30),
                      Text(
                        Strings.werfHashTag,
                        style: Styles.baseTextTheme.headline2.copyWith(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  kIsWeb
                      ? GetBuilder<NewsfeedController>(
                          id: "post",
                          builder: (_) {
                            // print("first builder");
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                        backgroundColor: Colors.black,
                                        scrollbarTheme: ScrollbarThemeData(
                                          radius: Radius.circular(10.0),
                                          thumbColor: MaterialStateProperty.all(
                                              Colors.grey),
                                          trackColor: MaterialStateProperty.all(
                                              Color(0xFFf7f9f9)),
                                          trackBorderColor:
                                              MaterialStateProperty.all(
                                                  Color(0xFFf7f9f9)),
                                          showTrackOnHover: true,
                                          trackVisibility:
                                              MaterialStateProperty.all(true),
                                          thickness:
                                              MaterialStateProperty.all(10),
                                          minThumbLength: 100,
                                          isAlwaysShown: true,
                                        ),
                                      ),
                                child: _.hashTagList.isNotEmpty
                                    ? PagedL(
                                        emptyStateWidget:
                                            ListViewLoadingShimmer(),

                                        // Text(Strings.noPosts),
                                        itemBuilder: _itemRow,
                                        padding: EdgeInsets.only(
                                            top: 16.00, left: 0.00, right: 0.00),
                                        loadingIndicator: Padding(
                                          padding: EdgeInsets.all(10.00),
                                          child: ListViewLoadingShimmer(),
                                        ),
                                        itemDataProvider: _fetchData,
                                        list: _.hashTagList,
                                        listSize:
                                            _checkPage(_.hashTagList.length),

                                        // + 1
                                        // : _checkPage(_.postList.length),
                                        newsFeedCheck: false,
                                      )
                                    : Center(child: CircularProgressIndicator()),
                              ),
                            );
                          })
                      : SizedBox(),
                ],
              )
            : Column(
                children: [
                  controller.hashTagList.isNotEmpty
                      ? GetBuilder<NewsfeedController>(
                          id: "ccc",
                          builder: (_) {
                            return Expanded(
                              child: Theme(
                                data: Theme.of(context).brightness ==
                                    Brightness.dark
                                    ? Styles.appTheme
                                    : ThemeData(
                                  backgroundColor: Colors.black,
                                  scrollbarTheme: ScrollbarThemeData(
                                    radius: Radius.circular(10.0),
                                    thumbColor: MaterialStateProperty.all(
                                        Colors.grey),
                                    trackColor: MaterialStateProperty.all(
                                        Color(0xFFf7f9f9)),
                                    trackBorderColor:
                                    MaterialStateProperty.all(
                                        Color(0xFFf7f9f9)),
                                    showTrackOnHover: true,
                                    trackVisibility:
                                    MaterialStateProperty.all(true),
                                    thickness:
                                    MaterialStateProperty.all(10),
                                    minThumbLength: 100,
                                    isAlwaysShown: true,
                                  ),
                                ),
                                child: Container(
                                  child: _.hashTagList.isEmpty
                                      ? SizedBox()
                                      : PagedL(
                                          emptyStateWidget:
                                              ListViewLoadingShimmer(),
                                          // Text(Strings.noPosts),
                                          itemBuilder: _itemRow,
                                          padding: EdgeInsets.only(
                                              top: 0.00, left: 4.00, right: 4.00),
                                          loadingIndicator: Padding(
                                            padding: EdgeInsets.all(10.00),
                                            child: Center(
                                                child: ListViewLoadingShimmer()
                                                // Container(
                                                //     color: Colors.grey[200],
                                                //     // margin: EdgeInsets.all(10),
                                                //     height: 320,
                                                //     child: buildPostShimmer(
                                                //         context)),
                                                ),
                                          ),
                                          itemDataProvider: _fetchData,
                                          list: _.hashTagList,
                                          listSize:
                                              _checkPage(_.hashTagList.length),
                                          newsFeedCheck: false,
                                        ),
                                ),
                              ),
                            );
                          })
                      : Center(child: CircularProgressIndicator()),
                ],
              ),
      ),
    );
  }

  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

// get newsfeed
  Future<List<Post>> _fetchData(int page) async {
    // print("page is: ");
    // print(page);
    return await controller.hashTagWerfsPagged(pageNo: page, tag: tag);
  }

// item rows
  Widget _itemRow(BuildContext context, Post post, {bool isListEmpty = false}) {
    List<Post> list;
    list = controller.hashTagList;

    int index = list.indexWhere((element) {
      return element.postId == post.postId;
    });

    if (index != 0 && index % 13 == 0 && !kIsWeb) {
      return Column(
        children: [
          list[index].type == 'thread'
              ? index == 0
                  ? Column(
                      children: [
                        ThreadPostCard(
                            postList: list,
                            scaffoldKey: _scaffoldKey,
                            post: list[index],
                            index: index,
                            controller: controller,
                            deletePostId: 1,
                            mute: 0),
                      ],
                    )
                  : ThreadPostCard(
                      postList: list,
                      scaffoldKey: _scaffoldKey,
                      post: list[index],
                      index: index,
                      controller: controller,
                      deletePostId: 1,
                      mute: 0)
              : index == 0
                  ? Column(
                      children: [
                        GestureDetector(
                          child: PostCard(
                              postList: list,
                              post: list[index],
                              scaffoldKey: _scaffoldKey,
                              index: index,
                              controller: controller,
                              deletePostId: controller.deletePostId,
                              mute: 0),
                        ),
                      ],
                    )
                  : GestureDetector(
                      child: PostCard(
                          postList: list,
                          post: list[index],
                          scaffoldKey: _scaffoldKey,
                          index: index,
                          controller: controller,
                          deletePostId: controller.deletePostId,
                          mute: 0),
                    ),
          SizedBox(height: 4),

          // kIsWeb?CustomAdWidgetWeb(): CustomAdWidget(
          CustomAdWidget(
              // ad: widget.controller.ads[widget.adIndex++],
              ),
        ],
      );
    } else {
      return Column(
        children: [
          VisibilityDetector(
            key: Key('postCard-widget-key'),
            onVisibilityChanged: (visibilityInfo) {
              double visiblePercentage = visibilityInfo.visibleFraction * 100;
              // debugPrint(
              //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
              if (visiblePercentage > 20 &&
                  post.authorId != controller.userId) {
                controller.emitImpressionsSocket(post.postId);
              }
            },
            child: list[index].type == 'thread'
                ? index == 0
                    ? Column(
                        children: [
                          ThreadPostCard(
                              postList: list,
                              scaffoldKey: _scaffoldKey,
                              post: list[index],
                              index: index,
                              controller: controller,
                              deletePostId: 1,
                              mute: 0),
                        ],
                      )
                    : ThreadPostCard(
                        postList: list,
                        scaffoldKey: _scaffoldKey,
                        post: list[index],
                        index: index,
                        controller: controller,
                        deletePostId: 1,
                        mute: 0)
                : index == 0
                    ? Column(
                        children: [
                          PostCard(
                              postList: list,
                              post: list[index],
                              scaffoldKey: _scaffoldKey,
                              index: index,
                              controller: controller,
                              deletePostId: 1,
                              mute: 0),
                        ],
                      )
                    : PostCard(
                        postList: list,
                        post: list[index],
                        scaffoldKey: _scaffoldKey,
                        index: index,
                        controller: controller,
                        deletePostId: 1,
                        mute: 0),
          ),
        ],
      );
    }
  }
}
