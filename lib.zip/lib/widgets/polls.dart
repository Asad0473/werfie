import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../utils/strings.dart';
import '../utils/utils_methods.dart';

class Polls extends StatefulWidget {
  const Polls({
    Key key,
    @required this.post,
    @required this.controller,
  }) : super(key: key);

  final Post post;
  final NewsfeedController controller;

  @override
  State<Polls> createState() => _PollsState();
}

class _PollsState extends State<Polls> {
  var votePercent = 0;

  @override
  Widget build(BuildContext context) {
    DateTime dateTime =
        DateFormat("yyyy-MM-dd HH:mm:ss").parse(widget.post.pollExpires, true);
    DateTime currentTime = DateTime.now();
    var obj = currentTime.difference(dateTime.toLocal());
    // print('current time ' + currentTime.toString());
    // print(dateTime.toLocal());
    var time = dateTime.toLocal().compareTo(currentTime);
    // print('Time  ' + time.toString());
    // print('Date Difference  ' + obj.toString());

    var getDateLeft = UtilsMethods.getLeftDate(dateTime);

    return Padding(
      padding: EdgeInsets.only(top: 20.0, left: 17.0),
      child: Container(
        width: kIsWeb ? 400 : 300,
        child: //When poll is expired
            time <= 0
                ? Column(
                    children: [
                      InkWell(
                        onTap: widget.post.authorId == GetStorage().read('id')
                            ? () {}
                            : widget.post.pollInfo['me_voted'] != false
                                ? () {}
                                : () {
                                    // print(widget.post.postId);
                                    widget.controller.addVoteToPoll(
                                        widget.post.postId, 'vote_for_first');
                                  },
                        child: Container(
                          height: 40,
                          child: Stack(
                            children: [
                              Container(
                                width: 400 *
                                            widget.post.pollInfo[widget.post
                                                .pollQuestionOne]['votes_per'] /
                                            100 <
                                        2
                                    ? 10
                                    : 400 *
                                        widget.post.pollInfo[widget.post
                                            .pollQuestionOne]['votes_per'] /
                                        100,
                                color: Color.fromRGBO(199, 212, 217, 1.0),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    SizedBox(width: 8),
                                    Text(
                                      '${widget.post.pollQuestionOne}',
                                      style: Get.isDarkMode
                                          ? TextStyle(
                                              color: Colors.white,
                                            )
                                          : TextStyle(
                                              color: Colors.black,
                                            ),
                                    ),
                                    SizedBox(width: 8),
                                    widget.post.pollInfo['me_voted'] ==
                                            'vote_for_first'
                                        ? Icon(
                                            Icons.check_circle_outline,
                                            color: Colors.grey,
                                          )
                                        : SizedBox(),
                                    Spacer(),
                                    Text(
                                      '${widget.post.pollInfo[widget.post.pollQuestionOne]['votes_per']}%',
                                      style: Get.isDarkMode
                                          ? TextStyle(
                                              color: Colors.white,
                                            )
                                          : TextStyle(
                                              color: Colors.black,
                                            ),
                                    ),
                                  ],
                                ),
                                // ListTile(

                                //   trailing: Text(
                                //       '${widget.post.pollInfo[widget.post.pollQuestionOne]['votes_per']}%'),
                                //   title: widget.post.pollInfo['me_voted'] ==
                                //           'vote_for_first'
                                //       ? Row(
                                //           children: [
                                //             Text('${widget.post.pollQuestionOne}'),
                                //             SizedBox(width: 8),
                                //             Icon(
                                //               Icons.check_circle_outline,
                                //               color: Colors.grey,
                                //             ),
                                //           ],
                                //         )
                                //       : Text('${widget.post.pollQuestionOne}'),
                                // ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      InkWell(
                        onTap: widget.post.authorId == GetStorage().read('id')
                            ? () {}
                            : widget.post.pollInfo['me_voted'] != false
                                ? () {}
                                : () {
                                    // print(widget.post.postId);
                                    widget.controller.addVoteToPoll(
                                        widget.post.postId, 'vote_for_second');
                                  },
                        child: Container(
                          height: 40,
                          child: Stack(
                            children: [
                              Container(
                                width: 400 *
                                            widget.post.pollInfo[widget.post
                                                .pollQuestionTwo]['votes_per'] /
                                            100 <
                                        2
                                    ? 10
                                    : 400 *
                                        widget.post.pollInfo[widget.post
                                            .pollQuestionTwo]['votes_per'] /
                                        100,
                                color: Color.fromRGBO(199, 212, 217, 1.0),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    SizedBox(width: 8),
                                    Text('${widget.post.pollQuestionTwo}'),
                                    SizedBox(width: 8),
                                    widget.post.pollInfo['me_voted'] ==
                                            'vote_for_second'
                                        ? Icon(
                                            Icons.check_circle_outline,
                                            color: Colors.grey,
                                          )
                                        : SizedBox(),
                                    Spacer(),
                                    Text(
                                      '${widget.post.pollInfo[widget.post.pollQuestionTwo]['votes_per']}%',
                                      style: Get.isDarkMode
                                          ? TextStyle(
                                              color: Colors.white,
                                            )
                                          : TextStyle(
                                              color: Colors.black,
                                            ),
                                    ),
                                  ],
                                ),

                                // ListTile(
                                //   trailing: Text(
                                //       '${widget.post.pollInfo[widget.post.pollQuestionTwo]['votes_per']}%'),
                                //   title: widget.post.pollInfo['me_voted'] ==
                                //           'vote_for_second'
                                //       ? Row(
                                //           children: [
                                //             Text('${widget.post.pollQuestionTwo}'),
                                //             SizedBox(width: 8),
                                //             Icon(
                                //               Icons.check_circle_outline,
                                //               color: Colors.grey,
                                //             ),
                                //           ],
                                //         )
                                //       : Text('${widget.post.pollQuestionTwo}'),
                                // ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      widget.post.pollQuestionThree.isNotEmpty
                          ? InkWell(
                              onTap: widget.post.authorId ==
                                      GetStorage().read('id')
                                  ? () {}
                                  : widget.post.pollInfo['me_voted'] != false
                                      ? () {}
                                      : () {
                                          // print(widget.post.postId);
                                          widget.controller.addVoteToPoll(
                                              widget.post.postId,
                                              'vote_for_third');
                                        },
                              child: Container(
                                height: 40,
                                child: Stack(
                                  children: [
                                    Container(
                                      width: 400 *
                                                  widget.post.pollInfo[widget
                                                          .post
                                                          .pollQuestionThree]
                                                      ['votes_per'] /
                                                  100 <
                                              2
                                          ? 10
                                          : 400 *
                                              widget.post.pollInfo[widget
                                                      .post.pollQuestionThree]
                                                  ['votes_per'] /
                                              100,
                                      color: Color.fromRGBO(199, 212, 217, 1.0),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Row(
                                        children: [
                                          SizedBox(width: 8),
                                          Text(
                                              '${widget.post.pollQuestionThree}'),
                                          SizedBox(width: 8),
                                          widget.post.pollInfo['me_voted'] ==
                                                  'vote_for_third'
                                              ? Icon(
                                                  Icons.check_circle_outline,
                                                  color: Colors.grey,
                                                )
                                              : SizedBox(),
                                          Spacer(),
                                          Text(
                                            '${widget.post.pollInfo[widget.post.pollQuestionThree]['votes_per']}%',
                                            style:
                                            Get.isDarkMode
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                          ),
                                        ],
                                      ),
                                      // ListTile(
                                      //   trailing: Text(
                                      //       '${widget.post.pollInfo[widget.post.pollQuestionThree]['votes_per']}%'),
                                      //   title: widget.post.pollInfo['me_voted'] ==
                                      //           'vote_for_third'
                                      //       ? Row(
                                      //           children: [
                                      //             Text(
                                      //                 '${widget.post.pollQuestionThree}'),
                                      //             SizedBox(width: 8),
                                      //             Icon(
                                      //               Icons.check_circle_outline,
                                      //               color: Colors.grey,
                                      //             ),
                                      //           ],
                                      //         )
                                      //       : Text(
                                      //           '${widget.post.pollQuestionThree}'),
                                      // ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : SizedBox(),
                      SizedBox(height: 10),
                      widget.post.pollQuestionFour.isNotEmpty
                          ? InkWell(
                              onTap: widget.post.authorId ==
                                      GetStorage().read('id')
                                  ? () {}
                                  : widget.post.pollInfo['me_voted'] != false
                                      ? () {}
                                      : () {
                                          // print(widget.post.postId);
                                          widget.controller.addVoteToPoll(
                                              widget.post.postId,
                                              'vote_for_fourth');
                                        },
                              child: Container(
                                height: 40,
                                child: Stack(
                                  children: [
                                    Container(
                                      width: 400 *
                                                  widget.post.pollInfo[widget
                                                          .post
                                                          .pollQuestionFour]
                                                      ['votes_per'] /
                                                  100 <
                                              2
                                          ? 10
                                          : 400 *
                                              widget.post.pollInfo[widget
                                                      .post.pollQuestionFour]
                                                  ['votes_per'] /
                                              100,
                                      color: Color.fromRGBO(199, 212, 217, 1.0),
                                    ),
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Row(
                                        children: [
                                          SizedBox(width: 8),
                                          Text(
                                              '${widget.post.pollQuestionFour}',style: TextStyle(color:Get.isDarkMode?Colors.white:Colors.black),),
                                          SizedBox(width: 8),
                                          widget.post.pollInfo['me_voted'] ==
                                                  'vote_for_fourth'
                                              ? Icon(
                                                  Icons.check_circle_outline,
                                                  color: Get.isDarkMode?Colors.white:Colors.grey,
                                                )
                                              : SizedBox(),
                                          Spacer(),
                                          Text(
                                            '${widget.post.pollInfo[widget.post.pollQuestionFour]['votes_per']}%',
                                            style:
                                                Get.isDarkMode? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                          ),
                                        ],
                                      ),
                                      //  ListTile(
                                      //   trailing: Text(
                                      //       '${widget.post.pollInfo[widget.post.pollQuestionFour]['votes_per']}%'),
                                      //   title: widget.post.pollInfo['me_voted'] ==
                                      //           'vote_for_fourth'
                                      //       ? Row(
                                      //           children: [
                                      //             Text(
                                      //                 '${widget.post.pollQuestionFour}'),
                                      //             SizedBox(width: 8),
                                      //             Icon(Icons.check_circle_outline,
                                      //                 color: Colors.grey),
                                      //           ],
                                      //         )
                                      //       : Text(
                                      //           '${widget.post.pollQuestionFour}'),
                                      // ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : SizedBox(),
                      Row(
                        children: [
                          Text(
                            '${widget.post.pollInfo['votes']} votes',
                            style:
                                Get.isDarkMode?
                                     TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                          ),
                          SizedBox(width: 20),
                          Text(
                          Strings.thisPollHasExpired,
                            style:
                                Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                          ),
                        ],
                      ),
                    ],
                  )
                : widget.post.pollInfo['me_voted'] == false &&
                        widget.post.authorId != GetStorage().read('id')
                    //View for when you have not voted yet
                    ? Column(
                        children: [
                          InkWell(
                            hoverColor: Colors.transparent,
                            onTap: () {
                              // print(widget.post.postId);
                              widget.post.pollInfo['me_voted'] = true;

                              // widget.post.pollInfo[widget.post.pollQuestionOne]['votes']+1;
                              widget.post.pollInfo[widget.post.pollQuestionOne]
                                  ['votes_per'] = ((widget.post.pollInfo[widget
                                              .post.pollQuestionOne]['votes'] +
                                          1) *
                                      100) /
                                  (widget.post.pollInfo['votes'] + 1);
                              widget.post.pollInfo[widget.post.pollQuestionTwo]
                                  ['votes_per'] = ((widget.post.pollInfo[widget
                                          .post.pollQuestionTwo]['votes']) *
                                      100) /
                                  (widget.post.pollInfo['votes'] + 1);
                              if (widget.post.pollQuestionThree.isNotEmpty)
                                widget.post
                                        .pollInfo[widget.post.pollQuestionThree]
                                    ['votes_per'] = ((widget.post.pollInfo[
                                                widget.post.pollQuestionThree]
                                            ['votes']) *
                                        100) /
                                    (widget.post.pollInfo['votes'] + 1);
                              if (widget.post.pollQuestionFour.isNotEmpty)
                                widget.post
                                        .pollInfo[widget.post.pollQuestionFour]
                                    ['votes_per'] = ((widget.post.pollInfo[
                                                widget.post.pollQuestionFour]
                                            ['votes']) *
                                        100) /
                                    (widget.post.pollInfo['votes'] + 1);

                              widget.post.pollInfo['votes'] =
                                  widget.post.pollInfo['votes'] + 1;
                              widget.post.pollInfo['me_voted'] =
                                  'vote_for_first';
                              setState(() {});
                              widget.controller.addVoteToPoll(
                                  widget.post.postId, 'vote_for_first');
                            },
                            child: Container(
                              height: 40,
                              alignment: Alignment.center,
                              width: kIsWeb ? 400 : 300,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.blue),
                              ),
                              child: Text(
                                '${widget.post.pollQuestionOne}',
                                style: Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          InkWell(
                            hoverColor: Colors.transparent,
                            onTap: () {
                              // print(widget.post.postId);
                              widget.post.pollInfo['me_voted'] = true;
                              widget.post.pollInfo[widget.post.pollQuestionOne]
                                  ['votes_per'] = ((widget.post.pollInfo[widget
                                          .post.pollQuestionOne]['votes']) *
                                      100) /
                                  (widget.post.pollInfo['votes'] + 1);
                              widget.post.pollInfo[widget.post.pollQuestionTwo]
                                  ['votes_per'] = ((widget.post.pollInfo[widget
                                              .post.pollQuestionTwo]['votes'] +
                                          1) *
                                      100) /
                                  (widget.post.pollInfo['votes'] + 1);
                              if (widget.post.pollQuestionThree.isNotEmpty)
                                widget.post
                                        .pollInfo[widget.post.pollQuestionThree]
                                    ['votes_per'] = ((widget.post.pollInfo[
                                                widget.post.pollQuestionThree]
                                            ['votes']) *
                                        100) /
                                    (widget.post.pollInfo['votes'] + 1);
                              if (widget.post.pollQuestionFour.isNotEmpty)
                                widget.post
                                        .pollInfo[widget.post.pollQuestionFour]
                                    ['votes_per'] = ((widget.post.pollInfo[
                                                widget.post.pollQuestionFour]
                                            ['votes']) *
                                        100) /
                                    (widget.post.pollInfo['votes'] + 1);

                              widget.post.pollInfo['votes'] =
                                  widget.post.pollInfo['votes'] + 1;
                              widget.post.pollInfo['me_voted'] =
                                  'vote_for_second';
                              setState(() {});
                              widget.controller.addVoteToPoll(
                                  widget.post.postId, 'vote_for_second');
                            },
                            child: Container(
                              height: 40,
                              width: kIsWeb ? 400 : 300,
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Colors.blue),
                              ),
                              child: Text(
                                '${widget.post.pollQuestionTwo}',
                                style: Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          widget.post.pollQuestionThree.isNotEmpty
                              ? InkWell(
                                  hoverColor: Colors.transparent,
                                  onTap: () {
                                    // print(widget.post.postId);
                                    widget.post.pollInfo['me_voted'] = true;
                                    widget.post.pollInfo['me_voted'] = true;
                                    widget.post.pollInfo[
                                            widget.post.pollQuestionOne]
                                        ['votes_per'] = ((widget.post.pollInfo[
                                                    widget.post.pollQuestionOne]
                                                ['votes']) *
                                            100) /
                                        (widget.post.pollInfo['votes'] + 1);
                                    widget.post.pollInfo[
                                            widget.post.pollQuestionTwo]
                                        ['votes_per'] = ((widget.post.pollInfo[
                                                    widget.post.pollQuestionTwo]
                                                ['votes']) *
                                            100) /
                                        (widget.post.pollInfo['votes'] + 1);
                                    if (widget
                                        .post.pollQuestionThree.isNotEmpty)
                                      widget.post.pollInfo[
                                              widget.post.pollQuestionThree]
                                          ['votes_per'] = ((widget
                                                              .post.pollInfo[
                                                          widget.post
                                                              .pollQuestionThree]
                                                      ['votes'] +
                                                  1) *
                                              100) /
                                          (widget.post.pollInfo['votes'] + 1);
                                    if (widget.post.pollQuestionFour.isNotEmpty)
                                      widget.post.pollInfo[widget.post
                                              .pollQuestionFour]['votes_per'] =
                                          ((widget.post.pollInfo[widget.post
                                                          .pollQuestionFour]
                                                      ['votes']) *
                                                  100) /
                                              (widget.post.pollInfo['votes'] +
                                                  1);

                                    widget.post.pollInfo['votes'] =
                                        widget.post.pollInfo['votes'] + 1;
                                    widget.post.pollInfo['me_voted'] =
                                        'vote_for_third';
                                    setState(() {});
                                    widget.controller.addVoteToPoll(
                                        widget.post.postId, 'vote_for_third');
                                  },
                                  child: Container(
                                    height: 40,
                                    width: kIsWeb ? 400 : 300,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: Colors.blue),
                                    ),
                                    child: Text(
                                      '${widget.post.pollQuestionThree}',
                                      style: Get.isDarkMode
                                          ? TextStyle(
                                              color: Colors.white,
                                            )
                                          : TextStyle(
                                              color: Colors.black,
                                            ),
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          SizedBox(height: 10),
                          widget.post.pollQuestionFour.isNotEmpty
                              ? InkWell(
                                  hoverColor: Colors.transparent,
                                  onTap: () {
                                    // print(widget.post.postId);
                                    widget.post.pollInfo['me_voted'] = true;
                                    widget.post.pollInfo['me_voted'] = true;
                                    widget.post.pollInfo[
                                            widget.post.pollQuestionOne]
                                        ['votes_per'] = ((widget.post.pollInfo[
                                                    widget.post.pollQuestionOne]
                                                ['votes']) *
                                            100) /
                                        (widget.post.pollInfo['votes'] + 1);
                                    widget.post.pollInfo[
                                            widget.post.pollQuestionTwo]
                                        ['votes_per'] = ((widget.post.pollInfo[
                                                    widget.post.pollQuestionTwo]
                                                ['votes']) *
                                            100) /
                                        (widget.post.pollInfo['votes'] + 1);
                                    if (widget
                                        .post.pollQuestionThree.isNotEmpty)
                                      widget.post.pollInfo[
                                              widget.post.pollQuestionThree]
                                          ['votes_per'] = ((widget
                                                          .post.pollInfo[
                                                      widget.post
                                                          .pollQuestionThree]
                                                  ['votes']) *
                                              100) /
                                          (widget.post.pollInfo['votes'] + 1);
                                    if (widget.post.pollQuestionFour.isNotEmpty)
                                      widget.post.pollInfo[widget.post
                                              .pollQuestionFour]['votes_per'] =
                                          ((widget.post.pollInfo[widget.post
                                                              .pollQuestionFour]
                                                          ['votes'] +
                                                      1) *
                                                  100) /
                                              (widget.post.pollInfo['votes'] +
                                                  1);

                                    widget.post.pollInfo['votes'] =
                                        widget.post.pollInfo['votes'] + 1;
                                    widget.post.pollInfo['me_voted'] =
                                        'vote_for_fourth';
                                    setState(() {});
                                    widget.controller.addVoteToPoll(
                                        widget.post.postId, 'vote_for_fourth');
                                  },
                                  child: Container(
                                    height: 40,
                                    width: kIsWeb ? 400 : 300,
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(color: Colors.blue),
                                    ),
                                    child: Text(
                                      '${widget.post.pollQuestionFour}',
                                      style: Get.isDarkMode
                                          ? TextStyle(
                                              color: Colors.white,
                                            )
                                          : TextStyle(
                                              color: Colors.black,
                                            ),
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          Row(
                            children: [
                              Text(
                                '${widget.post.pollInfo['votes']} votes',
                                style: Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                              ),
                              SizedBox(width: 20),
                              Text(
                                '${widget.post.pollExpires}',
                                style: Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(color: Colors.black),
                              ),
                            ],
                          ),
                        ],
                      )
                    //View for when it is your poll and you cannot vote
                    : Column(
                        children: [
                          InkWell(
                            onTap:
                                widget.post.authorId == GetStorage().read('id')
                                    ? () {
                                        // print('Post');
                                        UtilsMethods.toastMessageShow(
                                          widget.controller.displayColor,
                                          widget.controller.displayColor,
                                          widget.controller.displayColor,
                                          message:
                                             Strings.youCannotVoteOnYourOwnPoll,
                                        );
                                        // ScaffoldMessenger.of(context).showSnackBar(
                                        //   SnackBar(
                                        //     content: Text(
                                        //         'You cannot vote on your own poll!',
                                        //       style: Theme.of(context).brightness == Brightness.dark ?
                                        //       TextStyle(color: Colors.white,
                                        //
                                        //       )
                                        //           : TextStyle( color: Colors.black,
                                        //       ),),
                                        //   ),
                                        // );
                                      }
                                    : widget.post.pollInfo['me_voted'] != false
                                        ? () {}
                                        : () {
                                            // print(widget.post.postId);
                                            widget.controller.addVoteToPoll(
                                                widget.post.postId,
                                                'vote_for_first');
                                          },
                            child: Container(
                              height: 40,
                              child: Stack(
                                children: [
                                  Container(
                                    width: 400 *
                                                widget.post.pollInfo[widget
                                                        .post.pollQuestionOne]
                                                    ['votes_per'] /
                                                100 <
                                            2
                                        ? 10
                                        : 400 *
                                            widget.post.pollInfo[widget.post
                                                .pollQuestionOne]['votes_per'] /
                                            100,
                                    color: Color.fromRGBO(199, 212, 217, 1.0),
                                  ),
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        SizedBox(width: 8),
                                        Text(
                                          '${widget.post.pollQuestionOne}',
                                          style: Get.isDarkMode
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                        SizedBox(width: 8),
                                        widget.post.pollInfo['me_voted'] ==
                                                'vote_for_first'
                                            ? Icon(
                                                Icons.check_circle_outline,
                                                color: Colors.grey,
                                              )
                                            : SizedBox(),
                                        Spacer(),
                                        Text(
                                          '${widget.post.pollInfo[widget.post.pollQuestionOne]['votes_per']}%',
                                          style: Get.isDarkMode
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                      ],
                                    ),
                                    // ListTile(

                                    //   trailing: Text(
                                    //       '${widget.post.pollInfo[widget.post.pollQuestionOne]['votes_per']}%'),
                                    //   title: widget.post.pollInfo['me_voted'] ==
                                    //           'vote_for_first'
                                    //       ? Row(
                                    //           children: [
                                    //             Text('${widget.post.pollQuestionOne}'),
                                    //             SizedBox(width: 8),
                                    //             Icon(
                                    //               Icons.check_circle_outline,
                                    //               color: Colors.grey,
                                    //             ),
                                    //           ],
                                    //         )
                                    //       : Text('${widget.post.pollQuestionOne}'),
                                    // ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          InkWell(
                            onTap:
                                widget.post.authorId == GetStorage().read('id')
                                    ? () {}
                                    : widget.post.pollInfo['me_voted'] != false
                                        ? () {}
                                        : () {
                                            print(widget.post.postId);
                                            widget.controller.addVoteToPoll(
                                                widget.post.postId,
                                                'vote_for_second');
                                          },
                            child: Container(
                              height: 40,
                              child: Stack(
                                children: [
                                  Container(
                                    width: 400 *
                                                widget.post.pollInfo[widget
                                                        .post.pollQuestionTwo]
                                                    ['votes_per'] /
                                                100 <
                                            2
                                        ? 10
                                        : 400 *
                                            widget.post.pollInfo[widget.post
                                                .pollQuestionTwo]['votes_per'] /
                                            100,
                                    color: Color.fromRGBO(199, 212, 217, 1.0),
                                  ),
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        SizedBox(width: 8),
                                        Text(
                                          '${widget.post.pollQuestionTwo}',
                                          style: Get.isDarkMode
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                        SizedBox(width: 8),
                                        widget.post.pollInfo['me_voted'] ==
                                                'vote_for_second'
                                            ? Icon(
                                                Icons.check_circle_outline,
                                                color: Colors.grey,
                                              )
                                            : SizedBox(),
                                        Spacer(),
                                        Text(
                                          '${widget.post.pollInfo[widget.post.pollQuestionTwo]['votes_per']}%',
                                          style: Get.isDarkMode
                                              ? TextStyle(
                                                  color: Colors.white,
                                                )
                                              : TextStyle(
                                                  color: Colors.black,
                                                ),
                                        ),
                                      ],
                                    ),

                                    // ListTile(
                                    //   trailing: Text(
                                    //       '${widget.post.pollInfo[widget.post.pollQuestionTwo]['votes_per']}%'),
                                    //   title: widget.post.pollInfo['me_voted'] ==
                                    //           'vote_for_second'
                                    //       ? Row(
                                    //           children: [
                                    //             Text('${widget.post.pollQuestionTwo}'),
                                    //             SizedBox(width: 8),
                                    //             Icon(
                                    //               Icons.check_circle_outline,
                                    //               color: Colors.grey,
                                    //             ),
                                    //           ],
                                    //         )
                                    //       : Text('${widget.post.pollQuestionTwo}'),
                                    // ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          widget.post.pollQuestionThree.isNotEmpty
                              ? InkWell(
                                  onTap: widget.post.authorId ==
                                          GetStorage().read('id')
                                      ? () {}
                                      : widget.post.pollInfo['me_voted'] !=
                                              false
                                          ? () {}
                                          : () {
                                              print(widget.post.postId);
                                              widget.controller.addVoteToPoll(
                                                  widget.post.postId,
                                                  'vote_for_third');
                                            },
                                  child: Container(
                                    height: 40,
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: 400 *
                                                      widget.post.pollInfo[widget
                                                              .post
                                                              .pollQuestionThree]
                                                          ['votes_per'] /
                                                      100 <
                                                  2
                                              ? 10
                                              : 400 *
                                                  widget.post.pollInfo[widget
                                                          .post
                                                          .pollQuestionThree]
                                                      ['votes_per'] /
                                                  100,
                                          color: Color.fromRGBO(
                                              199, 212, 217, 1.0),
                                        ),
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Row(
                                            children: [
                                              SizedBox(width: 8),
                                              Text(
                                                '${widget.post.pollQuestionThree}',
                                                style: Get.isDarkMode
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                              ),
                                              SizedBox(width: 8),
                                              widget.post.pollInfo[
                                                          'me_voted'] ==
                                                      'vote_for_third'
                                                  ? Icon(
                                                      Icons
                                                          .check_circle_outline,
                                                      color: Colors.grey,
                                                    )
                                                  : SizedBox(),
                                              Spacer(),
                                              Text(
                                                '${widget.post.pollInfo[widget.post.pollQuestionThree]['votes_per']}%',
                                                style: Get.isDarkMode
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                              ),
                                            ],
                                          ),
                                          // ListTile(
                                          //   trailing: Text(
                                          //       '${widget.post.pollInfo[widget.post.pollQuestionThree]['votes_per']}%'),
                                          //   title: widget.post.pollInfo['me_voted'] ==
                                          //           'vote_for_third'
                                          //       ? Row(
                                          //           children: [
                                          //             Text(
                                          //                 '${widget.post.pollQuestionThree}'),
                                          //             SizedBox(width: 8),
                                          //             Icon(
                                          //               Icons.check_circle_outline,
                                          //               color: Colors.grey,
                                          //             ),
                                          //           ],
                                          //         )
                                          //       : Text(
                                          //           '${widget.post.pollQuestionThree}'),
                                          // ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          SizedBox(height: 10),
                          widget.post.pollQuestionFour.isNotEmpty
                              ? InkWell(
                                  onTap: widget.post.authorId ==
                                          GetStorage().read('id')
                                      ? () {}
                                      : widget.post.pollInfo['me_voted'] !=
                                              false
                                          ? () {}
                                          : () {
                                              print(widget.post.postId);
                                              widget.controller.addVoteToPoll(
                                                  widget.post.postId,
                                                  'vote_for_fourth');
                                            },
                                  child: Container(
                                    height: 40,
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: 400 *
                                                      widget.post.pollInfo[widget
                                                              .post
                                                              .pollQuestionFour]
                                                          ['votes_per'] /
                                                      100 <
                                                  2
                                              ? 10
                                              : 400 *
                                                  widget.post.pollInfo[widget
                                                          .post
                                                          .pollQuestionFour]
                                                      ['votes_per'] /
                                                  100,
                                          color: Color.fromRGBO(
                                              199, 212, 217, 1.0),
                                        ),
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Row(
                                            children: [
                                              SizedBox(width: 8),
                                              Text(
                                                '${widget.post.pollQuestionFour}',
                                                style:Get.isDarkMode
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                              ),
                                              SizedBox(width: 8),
                                              widget.post.pollInfo[
                                                          'me_voted'] ==
                                                      'vote_for_fourth'
                                                  ? Icon(
                                                      Icons
                                                          .check_circle_outline,
                                                      color: Colors.grey,
                                                    )
                                                  : SizedBox(),
                                              Spacer(),
                                              Text(
                                                '${widget.post.pollInfo[widget.post.pollQuestionFour]['votes_per']}%',
                                                style: Get.isDarkMode
                                                    ? TextStyle(
                                                        color: Colors.white,
                                                      )
                                                    : TextStyle(
                                                        color: Colors.black,
                                                      ),
                                              ),
                                            ],
                                          ),
                                          //  ListTile(
                                          //   trailing: Text(
                                          //       '${widget.post.pollInfo[widget.post.pollQuestionFour]['votes_per']}%'),
                                          //   title: widget.post.pollInfo['me_voted'] ==
                                          //           'vote_for_fourth'
                                          //       ? Row(
                                          //           children: [
                                          //             Text(
                                          //                 '${widget.post.pollQuestionFour}'),
                                          //             SizedBox(width: 8),
                                          //             Icon(Icons.check_circle_outline,
                                          //                 color: Colors.grey),
                                          //           ],
                                          //         )
                                          //       : Text(
                                          //           '${widget.post.pollQuestionFour}'),
                                          // ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              : SizedBox(),
                          Row(
                            children: [
                              Text(
                                '${widget.post.pollInfo['votes']} votes',
                                style: Get.isDarkMode
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                              ),
                              SizedBox(width: 20),
                              Text(
                                '$getDateLeft',
                                style: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? TextStyle(
                                        color: Colors.white,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                      ),
                              ),
                            ],
                          ),
                        ],
                      ),
      ),
    );
  }
}
