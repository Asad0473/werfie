import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:werfieapp/models/view_edit_history.dart';

class CheckHistory extends StatelessWidget {
  ViewEditHistory viewEditHistory;

  CheckHistory({this.viewEditHistory});

  @override
  Widget build(BuildContext context) {
    viewEditHistory ?? [];
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Edit History",
                style: TextStyle(
                  fontSize: 35,
                  fontFamily: "Arial-Regular.ttf",
                ),
              ),
              IconButton(
                  padding: EdgeInsets.zero,
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(
                    Icons.clear,
                    size: 35,
                  )),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            shrinkWrap: true,
            separatorBuilder: (BuildContext context, int index) =>
                const Divider(
              thickness: 2,
            ),
            itemCount: viewEditHistory.data.length,
            itemBuilder: (BuildContext context, int index) {
              var dateTime = DateFormat("yyyy-MM-dd HH:mm:ss").parse(
                  viewEditHistory.data[index].updatedAt.toString(), true);
              String dateLocal = dateTime.toLocal().toString();
              dateLocal = dateLocal.toString().split('.')[0].toString();
              return ListTile(
                contentPadding: const EdgeInsets.only(left: 20, right: 20),
                title: Text(
                  viewEditHistory.data[index].description,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontFamily: "Arial-Regular.ttf",
                  ),
                ),
                subtitle: Text(dateLocal.toString()),
              );
            },
          ),
        ),
      ],
    );
  }
}
