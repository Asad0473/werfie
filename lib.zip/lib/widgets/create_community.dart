import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/communities_controller.dart';
import 'package:werfieapp/utils/font.dart';

import '../utils/strings.dart';

class CreateCommunity extends StatelessWidget {
  CreateCommunity({Key key, this.editCheck}) : super(key: key);
  final CommunitiesController communitiesController =
      Get.put(CommunitiesController());
  bool editCheck;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CommunitiesController>(
      assignId: true,
      builder: (controller) {
        return kIsWeb
            ? Container(
                height: 590,
                width: 500,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                child: SingleChildScrollView(
                  controller: ScrollController(),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            editCheck == false
                                ? Text(
                                    'Edit Community',
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white)
                                        : TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                  )
                                : Text(
                                    'Create New Community',
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white)
                                        : TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                  ),
                            GestureDetector(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Icon(
                                Icons.cancel,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                size: 25,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Divider(
                        thickness: 1,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            editCheck == false
                                ? Text(
                                    "Edit name of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Enter name of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            TextField(
                              style:
                                  LightStyles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                // fontSize: 16,
                                // fontWeight: FontWeight.w500,
                              ),
                              cursorHeight: 15,
                              cursorColor: Colors.black,
                              cursorWidth: 1.0,
                              decoration: InputDecoration(
                                fillColor: Colors.grey[250],
                                filled: true,
                                hintText: "Community Name",
                                hintStyle: LightStyles.baseTextTheme.headline3,
                                hintTextDirection: TextDirection.ltr,
                                isDense: true,
                                contentPadding: EdgeInsets.only(
                                    bottom: 14, top: 14, left: 10, right: 10),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1,
                                      color: Colors.grey), //<-- SEE HERE
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1,
                                      color: Colors.blue), //<-- SEE HERE
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit the category of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Select category of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),

                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value:
                                            communitiesController.dropdownValue,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController.dropdownValue =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController.list
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),

                            ///privacy
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit Privacy",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Privacy",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      // hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value: communitiesController
                                            .dropdownValueForPrivateList,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController
                                                  .dropdownValueForPrivateList =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController.privacyList
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "Public: Anyone can join your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                            Text(
                              "Private: You will approve all the requests to join the group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),

                            ///visibility
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit Visibility",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Visibility",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      // hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value: communitiesController
                                            .dropdownValueForVisibilityList,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController
                                                  .dropdownValueForVisibilityList =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController
                                            .visibilityList
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "Visible to public: Anyone can search for your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                            Text(
                              "all. Private: Only you can see your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Divider(
                        thickness: 2,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 10, top: 10),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: MaterialButton(
                            color: Color(0xFF0157d3),
                            elevation: 0.0,

                            onHighlightChanged: (bool value) {},
                            // hoverColor: Color(0xFF0157d3),
                            // borderSide: const BorderSide(
                            //   color: Colors.white,
                            //   style: BorderStyle.solid,
                            //   width: 1,
                            // ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),

                            onPressed: () {},
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: editCheck == false
                                  ? Text(
                                      Strings.save,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    )
                                  : Text(
                                      Strings.create,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              )
            : Scaffold(
                appBar: AppBar(
                  automaticallyImplyLeading: false,
                  backgroundColor:
                      Theme.of(context).brightness == Brightness.dark
                          ? Colors.black
                          : Colors.white,
                  title: Row(
                    children: [
                      GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Icon(
                            Icons.arrow_back,
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            size: 25,
                          )),
                      SizedBox(
                        width: 10,
                      ),
                      Spacer(),
                      editCheck == false
                          ? Text(
                              'Edit Community',
                              style: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)
                                  : TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                            )
                          : Text(
                              'Create New Community',
                              style: Theme.of(context).brightness ==
                                      Brightness.dark
                                  ? TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white)
                                  : TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                            ),
                      Spacer(),
                    ],
                  ),
                ),
                body: Container(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.black
                      : Colors.white,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            editCheck == false
                                ? Text(
                                    "Edit name of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Enter name of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            TextField(
                              style: LightStyles.baseTextTheme.headline2
                                  .copyWith(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Colors.white
                                          : Colors.black),
                              cursorHeight: 15,
                              cursorColor: Colors.black,
                              cursorWidth: 1.0,
                              decoration: InputDecoration(
                                hintText: "Community Name",
                                hintStyle: LightStyles.baseTextTheme.headline3,
                                hintTextDirection: TextDirection.ltr,
                                isDense: true,
                                contentPadding: EdgeInsets.only(
                                    bottom: 14, top: 14, left: 10, right: 10),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1,
                                      color: Colors.grey), //<-- SEE HERE
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                      width: 1,
                                      color: Colors.blue), //<-- SEE HERE
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit the category of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Select category of your Community",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),

                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value:
                                            communitiesController.dropdownValue,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController.dropdownValue =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController.list
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),

                            ///privacy
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit Privacy",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Privacy",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      // hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value: communitiesController
                                            .dropdownValueForPrivateList,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController
                                                  .dropdownValueForPrivateList =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController.privacyList
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "Public: Anyone can join your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                            Text(
                              "Private: You will approve all the requests to join the group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),

                            ///visibility
                            SizedBox(
                              height: 20,
                            ),
                            editCheck == false
                                ? Text(
                                    "Edit Visibility",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  )
                                : Text(
                                    "Visibility",
                                    style: TextStyle(
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black),
                                  ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 34,
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return InputDecorator(
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.only(
                                          bottom: 10,
                                          top: 10,
                                          left: 10,
                                          right: 10),
                                      // labelText: "hi",
                                      // labelStyle: textStyle,
                                      // labelText: _dropdownValue == null
                                      //     ? 'Where are you from'
                                      //     : 'From',
                                      // hintText: "Community Name",

                                      enabledBorder: OutlineInputBorder(
                                          borderSide: BorderSide(
                                              width: 1, color: Colors.grey)),

                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                            width: 1,
                                            color: Colors.blue), //<-- SEE HERE
                                      ),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        iconEnabledColor:
                                            Theme.of(context).brightness ==
                                                    Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                        menuMaxHeight: 300,

                                        value: communitiesController
                                            .dropdownValueForVisibilityList,
                                        style: TextStyle(
                                          color: Colors.grey,
                                        ),
                                        // hint: Text(
                                        //   "Select Bank",
                                        //   style: TextStyle(
                                        //     color: Colors.grey,
                                        //     fontSize: 16,
                                        //     fontFamily: "verdana_regular",
                                        //   ),
                                        // ),
                                        onChanged: (String value) {
                                          communitiesController
                                                  .dropdownValueForVisibilityList =
                                              value;
                                          communitiesController.update();
                                        },
                                        items: communitiesController
                                            .visibilityList
                                            .map<DropdownMenuItem<String>>(
                                                (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(
                                              value,
                                              // style: TextStyle(
                                              //   fontWeight: FontWeight.bold,
                                              //   color:Theme.of(context).brightness == Brightness.dark?Colors.white: Colors.black
                                              // ),
                                            ),
                                          );
                                        }).toList(),
                                        isExpanded: false,
                                        isDense: true,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              "Visible to public: Anyone can search for your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                            Text(
                              "all. Private: Only you can see your group",
                              style: TextStyle(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white.withOpacity(0.5)
                                      : Colors.grey),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 30,
                      ),
                      Divider(
                        thickness: 2,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 10, top: 10),
                        child: Align(
                          alignment: Alignment.centerRight,
                          child: MaterialButton(
                            color: Color(0xFF0157d3),
                            elevation: 0.0,

                            onHighlightChanged: (bool value) {},
                            // hoverColor: Color(0xFF0157d3),
                            // borderSide: const BorderSide(
                            //   color: Colors.white,
                            //   style: BorderStyle.solid,
                            //   width: 1,
                            // ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(5.0),
                            ),

                            onPressed: () {},
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(top: 10, bottom: 10),
                              child: editCheck == false
                                  ? Text(
                                      Strings.save,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    )
                                  : Text(
                                      Strings.create,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ));
      },
    );
  }
}
