import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/dummy_data.dart';
import 'package:werfieapp/main.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/create_post_mobile.dart';
import 'package:werfieapp/screens/search_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/colors.dart';
import 'package:werfieapp/widgets/custom_adwidget.dart';
import 'package:werfieapp/widgets/loading_widgets/list_view_loading_shimmer.dart';
import 'package:werfieapp/widgets/pagged_list_view.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/thread_post_card.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_PostWeb.dart';

import '../models/create_post_model/create_post_model.dart';
import '../utils/font.dart';
import 'main_drawer.dart';

// ignore: must_be_immutable
class NewsFeedMobile extends StatefulWidget {
  int adIndex = 0;
  NewsfeedController controller;
  String postId;
  String profileId;
  bool isPullToRefresh = false;
  Post post;

  bool newsFeedCheck = false;

  NewsFeedMobile({this.controller, this.postId, this.profileId, this.post});

  static const routeName = '\NewsFeedMobile';
  int num = 0;

  @override
  State<NewsFeedMobile> createState() => _NewsFeedMobileState();
}

class _NewsFeedMobileState extends State<NewsFeedMobile> {
  final DummyData dataController = Get.put(DummyData());

  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  // ignore: unused_field
  final _controller = ScrollController();
  String link, linkTitle, linkMeta, linkImage;

  @override
  Widget build(BuildContext context) {
    // print('BUILD CALLED');
    if (widget.postId != null) {
      // print('POST ID I HA NEWSFEED' + widget.postId);
    } else if (widget.profileId != null) {
      // print('PROFILE ID I HA NEWSFEED' + widget.profileId);
    } else {}
    return Scaffold(
        key: _scaffoldKey,
        // appBar: !Responsive.isDesktop(context) && !Responsive.isTablet(context)
        //     ? kIsWeb
        //     ? AppBar(
        //   backgroundColor: Colors.black,
        //   iconTheme: IconThemeData(
        //     color: Color(0xFF4f515b),
        //   ),
        //   title: Container(
        //     height: 45,
        //     width: MediaQuery.of(context).size.width * 0.7,
        //     child: TextField(style:Theme.of(context).brightness == Brightness.dark ?
        //     TextStyle(color: Colors.white,
        //       fontWeight: FontWeight.normal,
        //     )
        //         : TextStyle(color: Colors.black,
        //       fontWeight: FontWeight.normal,
        //     ) ,cursorColor:Theme.of(context).brightness == Brightness.dark ?Colors.white:Colors.black ,
        //       textAlignVertical: TextAlignVertical.bottom,
        //       decoration: InputDecoration(
        //         hintText: Strings.search,
        //         prefixIcon: Icon(Icons.search),
        //         border: OutlineInputBorder(
        //           borderRadius: BorderRadius.circular(40),
        //         ),
        //         enabledBorder: OutlineInputBorder(
        //           borderRadius: BorderRadius.circular(40),
        //           borderSide: BorderSide(
        //             width: 0,
        //             style: BorderStyle.none,
        //           ),
        //         ),
        //         fillColor: Colors.grey[250],
        //         filled: true,
        //       ),
        //     ),
        //   ),
        //   automaticallyImplyLeading:
        //   !Responsive.isDesktop(context) ? true : false,
        // )
        //     : AppBar(
        //   leading: widget.controller.userProfile == null
        //       ? Container(
        //     width: 24,
        //     child: Center(
        //       child: SpinKitCircle(
        //         color: Colors.grey,
        //         size: 40,
        //       ),
        //     ),
        //   )
        //       : GestureDetector(
        //     onTap: () {
        //       Scaffold.of(context).openDrawer();
        //     },
        //     child: Padding(
        //       padding: EdgeInsets.symmetric(
        //           horizontal: 10, vertical: 10),
        //       child: ClipRRect(
        //         borderRadius: BorderRadius.circular(40),
        //         child: FadeInImage(
        //           fit: BoxFit.cover,
        //           width: 30,
        //           height: 30,
        //           placeholder: AssetImage(
        //               'assets/images/person_placeholder.png'),
        //           image: NetworkImage(widget.controller
        //               .userProfile.profileImage !=
        //               null
        //               ? widget
        //               .controller.userProfile.profileImage
        //               : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
        //         ),
        //       ),
        //     ),
        //   ),
        //   backgroundColor:Theme.of(context).brightness == Brightness.dark ?  Colors.black:Colors.white,
        //   iconTheme: IconThemeData(
        //     color: Color(0xFF4f515b),
        //   ),
        //   centerTitle: true,
        //   title: Container(
        //     height: 50,
        //     width: 100,
        //     child: SvgPicture.asset(
        //       AppImages.logo,
        //
        //       // color: Color((0xFF47b867)),
        //     ),
        //   ),
        //   // Image.asset('assets/images/Logo_werfie.png'),
        //   actions: [
        //     InkWell(
        //         onTap: () {
        //           notifi.value = 0;
        //           notifi.refresh();
        //           Navigator.push(
        //             context,
        //             MaterialPageRoute(
        //               builder: (BuildContext context) =>
        //                   SearchScreen(),
        //             ),
        //           );
        //         },
        //         child: Padding(
        //           padding: const EdgeInsets.only(right: 12.0),
        //           child: Icon(Icons.search),
        //         )),
        //     ///ASAD UNDO THIS CODE
        //     ///ASAD UNDO THIS CODE
        //   ],
        //
        //   automaticallyImplyLeading:
        //   !Responsive.isDesktop(context) ? true : false,
        // )
        //     : PreferredSize(
        //   preferredSize: Size(0.0, 0.0),
        //   child: Container(),
        // ),
        appBar: kIsWeb
            ? MediaQuery.of(context).size.width >= 500
                ? PreferredSize(
                    preferredSize: Size(0.0, 0.0),
                    child: Container(),
                  )
                : AppBar(
                    leading: widget.controller.userProfile == null
                        ? Container(
                            width: 24,
                            child: Center(
                              child: SpinKitCircle(
                                color: Colors.grey,
                                size: 40,
                              ),
                            ),
                          )
                        : GestureDetector(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            child: Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(40),
                                child: FadeInImage(
                                  fit: BoxFit.cover,
                                  width: 30,
                                  height: 30,
                                  placeholder: AssetImage(
                                      'assets/images/person_placeholder.png'),
                                  image: NetworkImage(widget.controller
                                              .userProfile.profileImage !=
                                          null
                                      ? widget
                                          .controller.userProfile.profileImage
                                      : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                ),
                              ),
                            ),
                          ),
                    backgroundColor:
                        Theme.of(context).brightness == Brightness.dark
                            ? Colors.black
                            : Colors.white,
                    iconTheme: IconThemeData(
                      color: Color(0xFF4f515b),
                    ),
                    centerTitle: true,
                    title: Container(
                      height: 40,
                      width: 100,
                      child: Image.asset(
                        Theme.of(context).brightness == Brightness.dark?
                        AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,

                        // color: Color((0xFF47b867)),
                      ),
                    ),
                    // Image.asset('assets/images/Logo_werfie.png'),
                    actions: [
                      // MediaQuery.of(context).size.width >500?SizedBox() :
                      // GestureDetector(
                      //   onTap: (){
                      //
                      //     return showDialog<void>(
                      //       context: context,
                      //       barrierDismissible: true, // user must tap button!
                      //       builder: (BuildContext context) {
                      //         return AlertDialog(
                      //           contentPadding: EdgeInsets.zero,
                      //           titlePadding:EdgeInsets.zero ,
                      //
                      //           content: GetBuilder<NewsfeedController>(builder: (controller) {
                      //             return Padding(
                      //               padding: const EdgeInsets.all(8.0),
                      //               child: Container(
                      //                 decoration: BoxDecoration(
                      //                   borderRadius: BorderRadius.circular(15),
                      //                   color: Colors.white,
                      //                 ),
                      //
                      //                 height: 250,
                      //                 width: 350,
                      //
                      //                 child: Padding(
                      //                   padding: const EdgeInsets.all(8.0),
                      //                   child: Column(
                      //                     crossAxisAlignment: CrossAxisAlignment.start,
                      //                     children: [
                      //                       Align(
                      //
                      //                         // alignment:
                      //                         child: GestureDetector(
                      //                           onTap:(){
                      //                             Navigator.pop(context);
                      //                           },
                      //                           child: Icon(
                      //                             Icons.cancel,
                      //                           ),
                      //                         ),
                      //                         alignment:Alignment.topRight,
                      //                       ),
                      //                       Text(
                      //                         "App Language",
                      //
                      //                         style: TextStyle(
                      //                           color: controller.displayColor,
                      //                           fontSize: 15,
                      //
                      //                         ),
                      //                       ),
                      //                       SizedBox(
                      //                         height: 5,
                      //                       ),
                      //                       SizedBox(
                      //                           height: 40,
                      //                         child: FormField<String>(
                      //
                      //                           builder: (FormFieldState<String> state) {
                      //                             return InputDecorator(
                      //                               decoration: InputDecoration(
                      //                                 fillColor: Colors.transparent,
                      //                                 focusColor: Colors.transparent,
                      //                                 contentPadding: EdgeInsets.only(
                      //                                     bottom: 5,
                      //                                     top: 2,
                      //                                     left: 15,
                      //                                     right: 2),
                      //                                 // labelText: "hi",
                      //                                 // labelStyle: textStyle,
                      //                                 // labelText: _dropdownValue == null
                      //                                 //     ? 'Where are you from'
                      //                                 //     : 'From',
                      //                                 hintText: "Community Name",
                      //
                      //                                 enabledBorder: OutlineInputBorder(
                      //                                   borderSide: BorderSide(
                      //                                       width: 1, color: Colors.grey
                      //
                      //                                   ),
                      //                                   borderRadius: BorderRadius.circular(60),
                      //
                      //                                 ),
                      //
                      //                                 focusedBorder: OutlineInputBorder(
                      //                                   borderSide: BorderSide(
                      //                                       width: 1,
                      //                                       color: Colors.blue
                      //                                   ), //<-- SEE HERE
                      //                                 ),
                      //
                      //                               ),
                      //                               child: DropdownButtonHideUnderline(
                      //
                      //                                 child: DropdownButton<AppLanguage>(
                      //
                      //                                   // borderRadius: BorderRadius.circular(20),
                      //                                   focusColor: Colors.transparent,
                      //
                      //                                   iconEnabledColor: controller.displayColor,
                      //                                   menuMaxHeight: 200,
                      //
                      //                                   value: controller.dropdownValue,
                      //                                   style: TextStyle(
                      //                                     color: Colors.black,
                      //                                   ),
                      //                                   // hint: Text(
                      //                                   //   "Select Bank",
                      //                                   //   style: TextStyle(
                      //                                   //     color: Colors.grey,
                      //                                   //     fontSize: 16,
                      //                                   //     fontFamily: "verdana_regular",
                      //                                   //   ),
                      //                                   // ),
                      //                                   onChanged: (AppLanguage value) {
                      //
                      //
                      //
                      //                                     print("controller.languageData ${controller.languageData.myLang.name}");
                      //
                      //
                      //
                      //
                      //
                      //                                     Navigator.pop(context);
                      //                                     controller.dropdownValue = value;
                      //
                      //
                      //
                      //
                      //                                     controller.languagesRequest(languageId: controller.selectedLanguage != null ? controller.selectedLanguage.id.toString() : 1.toString(), autoTranslate: 1.toString(),
                      //                                         appLanguageId: controller.dropdownValue.id,
                      //                                         appLanguage: controller.dropdownValue.name,
                      //                                         appLanguageCode: controller.dropdownValue.code);
                      //
                      //
                      //
                      //
                      //
                      //                                   print('heheheheheheeh');
                      //                                   Get.delete<
                      //                                       NewsfeedController>();
                      //                                   if (kIsWeb) {
                      //                                     Get.offNamed(FluroRouters.mainScreen);
                      //
                      //                                   } else {
                      //                                     Get.offUntil(
                      //                                         MaterialPageRoute(
                      //                                           builder: (context) =>
                      //                                               Session(),
                      //                                         ),
                      //                                             (route) => false);
                      //                                   }
                      //
                      //                                     print( controller.dropdownValue.name);
                      //                                     controller.update();
                      //                                   },
                      //                                   items:controller.languagesList.map((AppLanguage language) {
                      //                                     return new DropdownMenuItem<AppLanguage>(
                      //                                       value: language,
                      //                                       child: Row(
                      //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //                                         children: [
                      //                                           new Text(
                      //                                             language.name,
                      //                                             style: new TextStyle(color: Colors.black),
                      //                                           ),
                      //                                         ],
                      //                                       ),
                      //                                     );
                      //                                   }).toList(),
                      //                                   isExpanded: false,
                      //                                   isDense: true,
                      //
                      //
                      //                                 ),
                      //                               ),
                      //                             );
                      //                           },
                      //                         ),
                      //                       ),
                      //                       Padding(
                      //                         padding: const EdgeInsets.all(8.0),
                      //                         child: Divider(),
                      //                       ),
                      //                       Text(
                      //                         "Translation Language",
                      //
                      //                         style: TextStyle(
                      //                           color: controller.displayColor,
                      //                           fontSize: 15,
                      //
                      //                         ),
                      //                       ),
                      //                       SizedBox(
                      //                         height: 5,
                      //                       ),
                      //                       SizedBox(
                      //             height:40,
                      //
                      //                         child: FormField<String>(
                      //
                      //                           builder: (FormFieldState<String> state) {
                      //                             return InputDecorator(
                      //                               decoration: InputDecoration(
                      //                                 fillColor: Colors.transparent,
                      //                                 focusColor: Colors.transparent,
                      //                                 contentPadding: EdgeInsets.only(
                      //                                     bottom: 5,
                      //                                     top: 2,
                      //                                     left: 15,
                      //                                     right: 2),
                      //                                 // labelText: "hi",
                      //                                 // labelStyle: textStyle,
                      //                                 // labelText: _dropdownValue == null
                      //                                 //     ? 'Where are you from'
                      //                                 //     : 'From',
                      //                                 hintText: "Community Name",
                      //
                      //                                 enabledBorder: OutlineInputBorder(
                      //                                   borderSide: BorderSide(
                      //                                       width: 1, color: Colors.grey
                      //
                      //                                   ),
                      //                                   borderRadius: BorderRadius.circular(60),
                      //
                      //                                 ),
                      //
                      //                                 focusedBorder: OutlineInputBorder(
                      //                                   borderSide: BorderSide(
                      //                                       width: 1,
                      //                                       color: Colors.blue
                      //                                   ), //<-- SEE HERE
                      //                                 ),
                      //
                      //                               ),
                      //                               child: DropdownButtonHideUnderline(
                      //
                      //                                 child: DropdownButton<AppLanguage>(
                      //
                      //
                      //                                   // borderRadius: BorderRadius.circular(20),
                      //                                   focusColor: Colors.transparent,
                      //
                      //                                   iconEnabledColor: controller.displayColor,
                      //                                   menuMaxHeight: 200,
                      //
                      //                                   value: controller.dropdownValue1,
                      //                                   style: TextStyle(
                      //                                     color: Colors.black,
                      //                                   ),
                      //                                   // hint: Text(
                      //                                   //   "Select Bank",
                      //                                   //   style: TextStyle(
                      //                                   //     color: Colors.grey,
                      //                                   //     fontSize: 16,
                      //                                   //     fontFamily: "verdana_regular",
                      //                                   //   ),
                      //                                   // ),
                      //                                   onChanged: (AppLanguage value) {
                      //                                     Navigator.pop(context);
                      //                                     controller.dropdownValue1 = value;
                      //
                      //                                     // controller.selectedLanguage =  controller.dropdownValue1.id;
                      //                                     if (controller.isAutoTranslate) {
                      //                                       controller.languagesRequest(languageId:    controller.dropdownValue1 != null ?    controller.dropdownValue1.id.toString() : 1.toString(), autoTranslate: 1.toString());
                      //                                       // controller.postList =await controller.getNewsFeed(reload: true);
                      //                                       // controller.languageData =await controller.getLanguages();
                      //                                       // // await controller.get
                      //                                       // controller.isLanguageSettings =false;
                      //                                       //     controller.isProfileLanguagetype = false;
                      //                                       //     controller.isNewsFeedScreen =true;
                      //                                       //     controller.isSettingsScreen =false;
                      //
                      //                                       // MyApp.rebirth(context);
                      //                                       // controller.update();
                      //
                      //                                       // Future.delayed(
                      //                                       //     Duration(seconds: 2), () {
                      //
                      //
                      //                                     Get.delete<
                      //                                         NewsfeedController>();
                      //                                     if (kIsWeb) {
                      //                                       Get.offNamed(FluroRouters.mainScreen);
                      //
                      //                                     } else {
                      //                                       Get.offUntil(
                      //                                           MaterialPageRoute(
                      //                                             builder: (context) => Session(),
                      //                                           ),
                      //                                               (route) => false);
                      //                                     }
                      //                                     // Navigator.of(context)
                      //                                     //     .pushAndRemoveUntil(
                      //                                     //         MaterialPageRoute(
                      //                                     //             builder:
                      //                                     //                 (context) =>
                      //                                     //                     Session()),
                      //                                     //         (Route<dynamic>
                      //                                     //                 route) =>
                      //                                     //             false);
                      //                                     // });
                      //                                     // Phoenix.rebirth(context);
                      //
                      //                                     }
                      //
                      //
                      //
                      //
                      //
                      //
                      //
                      //
                      //
                      //
                      //                                     print( controller.dropdownValue1.name);
                      //                                     controller.update();
                      //                                   },
                      //                                   items:controller.translationLanguage.map((AppLanguage language) {
                      //                                     return new DropdownMenuItem<AppLanguage>(
                      //
                      //                                       value: language,
                      //                                       child: Row(
                      //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //                                         children: [
                      //                                           new Text(
                      //                                             language.name,
                      //                                             style: new TextStyle(color: Colors.black),
                      //                                           ),
                      //
                      //                                         ],
                      //                                       ),
                      //                                     );
                      //                                   }).toList(),
                      //                                   isExpanded: false,
                      //                                   isDense: true,
                      //
                      //
                      //                                 ),
                      //                               ),
                      //                             );
                      //                           },
                      //                         ),
                      //                       ),
                      //
                      //                     ],
                      //                   ),
                      //                 ),
                      //               ),
                      //             );
                      //           }),
                      //
                      //
                      //
                      //           // actions: <Widget>[
                      //           //   TextButton(
                      //           //     child: const Text('Approve'),
                      //           //     onPressed: () {
                      //           //       Navigator.of(context).pop();
                      //           //     },
                      //           //   ),
                      //           // ],
                      //         );
                      //       },
                      //     );
                      //
                      //   },
                      //   child: SvgPicture.asset(
                      //     AppImages.languageIcon,
                      //     height: 30,
                      //     width: 30,
                      //     color: widget.controller.displayColor,
                      //
                      //   ),
                      // ),
                      // SizedBox(width: 5,),

                      MediaQuery.of(context).size.width > 500
                          ? SizedBox()
                          : InkWell(
                              onTap: () {
                                notifi.value = 0;
                                notifi.refresh();
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        SearchScreen(),
                                  ),
                                );
                              },
                              child: Padding(
                                padding: const EdgeInsets.only(right: 12.0),
                                child: Icon(Icons.search),
                              )),

                      ///ASAD UNDO THIS CODE
                      ///ASAD UNDO THIS CODE
                    ],

                    automaticallyImplyLeading:
                        !Responsive.isDesktop(context) ? true : false,
                  )
            : AppBar(
                leading: widget.controller.userProfile == null
                    ? Container(
                        width: 24,
                        child: Center(
                          child: SpinKitCircle(
                            color: Colors.grey,
                            size: 40,
                          ),
                        ),
                      )
                    : GestureDetector(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        child: Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(40),
                            child: FadeInImage(
                              fit: BoxFit.cover,
                              width: 30,
                              height: 30,
                              placeholder: AssetImage(
                                  'assets/images/person_placeholder.png'),
                              image: NetworkImage(widget.controller.userProfile
                                          .profileImage !=
                                      null
                                  ? widget.controller.userProfile.profileImage
                                  : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                            ),
                          ),
                        ),
                      ),
                backgroundColor: Theme.of(context).brightness == Brightness.dark
                    ? Colors.black
                    : Colors.white,
                iconTheme: IconThemeData(
                  color: Color(0xFF4f515b),
                ),
                centerTitle: true,
                title: Container(
                  height: 40,
                  width: 100,
                  child: Image.asset(
                   Theme.of(context).brightness == Brightness.dark?
                    AppImages.simpleWhiteWLogo:AppImages.simpleBlackWLogo,

                    // color: Color((0xFF47b867)),
                  ),
                ),
                // Image.asset('assets/images/Logo_werfie.png'),
                actions: [
                  // MediaQuery.of(context).size.width >500?SizedBox() :
                  // GestureDetector(
                  //   onTap: (){
                  //
                  //     return showDialog<void>(
                  //       context: context,
                  //       barrierDismissible: true, // user must tap button!
                  //       builder: (BuildContext context) {
                  //         return AlertDialog(
                  //           contentPadding: EdgeInsets.zero,
                  //           titlePadding:EdgeInsets.zero ,
                  //
                  //           content: GetBuilder<NewsfeedController>(builder: (controller) {
                  //             return Padding(
                  //               padding: const EdgeInsets.all(8.0),
                  //               child: Container(
                  //                 decoration: BoxDecoration(
                  //                   borderRadius: BorderRadius.circular(15),
                  //                   color: Colors.white,
                  //                 ),
                  //
                  //                 height: 250,
                  //                 width: 350,
                  //
                  //                 child: Padding(
                  //                   padding: const EdgeInsets.all(8.0),
                  //                   child: Column(
                  //                     crossAxisAlignment: CrossAxisAlignment.start,
                  //                     children: [
                  //                       Align(
                  //
                  //                         // alignment:
                  //                         child: GestureDetector(
                  //                           onTap:(){
                  //                   Navigator.pop(context);
                  //                 },
                  //                           child: Icon(
                  //                             Icons.cancel,
                  //                           ),
                  //                         ),
                  //                           alignment:Alignment.topRight,
                  //                       ),
                  //                       Text(
                  //                         "App Language",
                  //
                  //                         style: TextStyle(
                  //                           color: controller.displayColor,
                  //                           fontSize: 15,
                  //
                  //                         ),
                  //                       ),
                  //                       SizedBox(
                  //                         height: 5,
                  //                       ),
                  //                       SizedBox(
                  //                         height: 40,
                  //                         child: FormField<String>(
                  //
                  //                           builder: (FormFieldState<String> state) {
                  //                             return InputDecorator(
                  //                               decoration: InputDecoration(
                  //                                 fillColor: Colors.transparent,
                  //                                 focusColor: Colors.transparent,
                  //                                 contentPadding: EdgeInsets.only(
                  //                                     bottom: 5,
                  //                                     top: 2,
                  //                                     left: 15,
                  //                                     right: 2),
                  //                                 // labelText: "hi",
                  //                                 // labelStyle: textStyle,
                  //                                 // labelText: _dropdownValue == null
                  //                                 //     ? 'Where are you from'
                  //                                 //     : 'From',
                  //                                 hintText: "Community Name",
                  //
                  //                                 enabledBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1, color: Colors.grey
                  //
                  //                                   ),
                  //                                   borderRadius: BorderRadius.circular(60),
                  //
                  //                                 ),
                  //
                  //                                 focusedBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1,
                  //                                       color: Colors.blue
                  //                                   ), //<-- SEE HERE
                  //                                 ),
                  //
                  //                               ),
                  //                               child: DropdownButtonHideUnderline(
                  //
                  //                                 child: DropdownButton<AppLanguage>(
                  //
                  //                                   // borderRadius: BorderRadius.circular(20),
                  //                                   focusColor: Colors.transparent,
                  //
                  //                                   iconEnabledColor: controller.displayColor,
                  //                                   menuMaxHeight: 200,
                  //
                  //                                   value: controller.dropdownValue,
                  //                                   style: TextStyle(
                  //                                     color: Colors.black,
                  //                                   ),
                  //                                   // hint: Text(
                  //                                   //   "Select Bank",
                  //                                   //   style: TextStyle(
                  //                                   //     color: Colors.grey,
                  //                                   //     fontSize: 16,
                  //                                   //     fontFamily: "verdana_regular",
                  //                                   //   ),
                  //                                   // ),
                  //                                   onChanged: (AppLanguage value) {
                  //
                  //
                  //
                  //                                     print("controller.languageData ${controller.languageData.myLang.name}");
                  //
                  //
                  //
                  //
                  //
                  //                                     Navigator.pop(context);
                  //                                     controller.dropdownValue = value;
                  //
                  //
                  //
                  //
                  //                                     controller.languagesRequest(languageId: controller.selectedLanguage != null ? controller.selectedLanguage.id.toString() : 1.toString(), autoTranslate: 1.toString(),
                  //                                         appLanguageId: controller.dropdownValue.id,
                  //                                         appLanguage: controller.dropdownValue.name,
                  //                                         appLanguageCode: controller.dropdownValue.code);
                  //
                  //
                  //
                  //
                  //
                  //                                   print('heheheheheheeh');
                  //                                   Get.delete<
                  //                                       NewsfeedController>();
                  //                                   if (kIsWeb) {
                  //                                     Get.offNamed(FluroRouters.mainScreen);
                  //
                  //                                   } else {
                  //                                     Get.offUntil(
                  //                                         MaterialPageRoute(
                  //                                           builder: (context) =>
                  //                                               Session(),
                  //                                         ),
                  //                                             (route) => false);
                  //                                   }
                  //
                  //                                     print( controller.dropdownValue.name);
                  //                                     controller.update();
                  //                                   },
                  //                                   items:controller.languagesList.map((AppLanguage language) {
                  //                                     return new DropdownMenuItem<AppLanguage>(
                  //                                       value: language,
                  //                                       child: Row(
                  //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //                                         children: [
                  //                                           new Text(
                  //                                             language.name,
                  //                                             style: new TextStyle(color: Colors.black),
                  //                                           ),
                  //
                  //                                         ],
                  //                                       ),
                  //                                     );
                  //                                   }).toList(),
                  //                                   isExpanded: false,
                  //                                   isDense: true,
                  //
                  //
                  //                                 ),
                  //                               ),
                  //                             );
                  //                           },
                  //                         ),
                  //                       ),
                  //                       Padding(
                  //                         padding: const EdgeInsets.all(8.0),
                  //                         child: Divider(),
                  //                       ),
                  //                       Text(
                  //                         "Translation Language",
                  //
                  //                         style: TextStyle(
                  //                           color: controller.displayColor,
                  //                           fontSize: 15,
                  //
                  //                         ),
                  //                       ),
                  //                       SizedBox(
                  //                         height: 5,
                  //                       ),
                  //                       SizedBox(
                  //                         height: 40,
                  //                         child: FormField<String>(
                  //
                  //                           builder: (FormFieldState<String> state) {
                  //                             return InputDecorator(
                  //                               decoration: InputDecoration(
                  //                                 fillColor: Colors.transparent,
                  //                                 focusColor: Colors.transparent,
                  //                                 contentPadding: EdgeInsets.only(
                  //                                     bottom: 5,
                  //                                     top: 2,
                  //                                     left: 15,
                  //                                     right: 2),
                  //                                 // labelText: "hi",
                  //                                 // labelStyle: textStyle,
                  //                                 // labelText: _dropdownValue == null
                  //                                 //     ? 'Where are you from'
                  //                                 //     : 'From',
                  //                                 hintText: "Community Name",
                  //
                  //                                 enabledBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1, color: Colors.grey
                  //
                  //                                   ),
                  //                                   borderRadius: BorderRadius.circular(60),
                  //
                  //                                 ),
                  //
                  //                                 focusedBorder: OutlineInputBorder(
                  //                                   borderSide: BorderSide(
                  //                                       width: 1,
                  //                                       color: Colors.blue
                  //                                   ), //<-- SEE HERE
                  //                                 ),
                  //
                  //                               ),
                  //                               child: DropdownButtonHideUnderline(
                  //
                  //                                 child: DropdownButton<AppLanguage>(
                  //
                  //
                  //                                   // borderRadius: BorderRadius.circular(20),
                  //                                   focusColor: Colors.transparent,
                  //
                  //                                   iconEnabledColor: controller.displayColor,
                  //                                   menuMaxHeight: 200,
                  //
                  //                                   value: controller.dropdownValue1,
                  //                                   style: TextStyle(
                  //                                     color: Colors.black,
                  //                                   ),
                  //                                   // hint: Text(
                  //                                   //   "Select Bank",
                  //                                   //   style: TextStyle(
                  //                                   //     color: Colors.grey,
                  //                                   //     fontSize: 16,
                  //                                   //     fontFamily: "verdana_regular",
                  //                                   //   ),
                  //                                   // ),
                  //                                   onChanged: (AppLanguage value) {
                  //                                     Navigator.pop(context);
                  //                                     controller.dropdownValue1 = value;
                  //
                  //                                     // controller.selectedLanguage =  controller.dropdownValue1.id;
                  //                                     if (controller.isAutoTranslate) {
                  //                                       controller.languagesRequest(languageId:    controller.dropdownValue1 != null ?    controller.dropdownValue1.id.toString() : 1.toString(), autoTranslate: 1.toString());
                  //                                       // controller.postList =await controller.getNewsFeed(reload: true);
                  //                                       // controller.languageData =await controller.getLanguages();
                  //                                       // // await controller.get
                  //                                       // controller.isLanguageSettings =false;
                  //                                       //     controller.isProfileLanguagetype = false;
                  //                                       //     controller.isNewsFeedScreen =true;
                  //                                       //     controller.isSettingsScreen =false;
                  //
                  //                                       // MyApp.rebirth(context);
                  //                                       // controller.update();
                  //
                  //                                       // Future.delayed(
                  //                                       //     Duration(seconds: 2), () {
                  //
                  //
                  //                                     Get.delete<
                  //                                         NewsfeedController>();
                  //                                     if (kIsWeb) {
                  //                                       Get.offNamed(FluroRouters.mainScreen);
                  //
                  //                                     } else {
                  //                                       Get.offUntil(
                  //                                           MaterialPageRoute(
                  //                                             builder: (context) => Session(),
                  //                                           ),
                  //                                               (route) => false);
                  //                                     }
                  //                                     // Navigator.of(context)
                  //                                     //     .pushAndRemoveUntil(
                  //                                     //         MaterialPageRoute(
                  //                                     //             builder:
                  //                                     //                 (context) =>
                  //                                     //                     Session()),
                  //                                     //         (Route<dynamic>
                  //                                     //                 route) =>
                  //                                     //             false);
                  //                                     // });
                  //                                     // Phoenix.rebirth(context);
                  //
                  //                                     }
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //
                  //                                     print( controller.dropdownValue1.name);
                  //                                     controller.update();
                  //                                   },
                  //                                   items:controller.translationLanguage.map((AppLanguage language) {
                  //                                     return new DropdownMenuItem<AppLanguage>(
                  //
                  //                                       value: language,
                  //                                       child: Row(
                  //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  //                                         children: [
                  //                                           new Text(
                  //                                             language.name,
                  //                                             style: new TextStyle(color: Colors.black),
                  //                                           ),
                  //                                           // controller.languageData.myLang.name == language.name?
                  //                                           // Icon(
                  //                                           //     Icons.check
                  //                                           // ):SizedBox(),
                  //                                         ],
                  //                                       ),
                  //                                     );
                  //                                   }).toList(),
                  //                                   isExpanded: false,
                  //                                   isDense: true,
                  //
                  //
                  //                                 ),
                  //                               ),
                  //                             );
                  //                           },
                  //                         ),
                  //                       ),
                  //
                  //                     ],
                  //                   ),
                  //                 ),
                  //               ),
                  //             );
                  //           }),
                  //
                  //
                  //
                  //           // actions: <Widget>[
                  //           //   TextButton(
                  //           //     child: const Text('Approve'),
                  //           //     onPressed: () {
                  //           //       Navigator.of(context).pop();
                  //           //     },
                  //           //   ),
                  //           // ],
                  //         );
                  //       },
                  //     );
                  //
                  //   },
                  //   child: SvgPicture.asset(
                  //     AppImages.languageIcon,
                  //     height: 30,
                  //     width: 30,
                  //     color: widget.controller.displayColor,
                  //
                  //   ),
                  // ),
                  // SizedBox(width: 5,),

                  MediaQuery.of(context).size.width > 500
                      ? SizedBox()
                      : InkWell(
                          onTap: () {
                            notifi.value = 0;
                            notifi.refresh();
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (BuildContext context) =>
                                    SearchScreen(),
                              ),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(right: 12.0),
                            child: Icon(Icons.search),
                          )),

                  ///ASAD UNDO THIS CODE
                  ///ASAD UNDO THIS CODE
                ],

                automaticallyImplyLeading:
                    !Responsive.isDesktop(context) ? true : false,
              ),
        drawer: Responsive.isDesktop(context)
            ? MainDrawer(widget.controller)
            : Container(),
        drawerEnableOpenDragGesture:
            !Responsive.isDesktop(context) ? false : true,
        floatingActionButton: kIsWeb
            ? MediaQuery.of(context).size.width >= 500
                ? SizedBox()
                : FloatingActionButton(
                    heroTag: UniqueKey(),
                    onPressed: () {
                      widget.controller.modelList2 = [];

                      widget.controller.modelList2.add(ModelClass.fromJson({
                        'body': '',
                        'poll_ques_first': null,
                        'poll_ques_first': null,
                        'poll_ques_third': null,
                        'poll_ques_fourth': null,
                        //  selectType: "Public",
                        'files': [],
                        'link_meta': '',
                        'link': '',
                        'link_image': '',
                        'link_title': '',
                        'days': '',
                        'minutes': '',
                        'hours': '',
                        'location': '',
                        'lat': '',
                        'lng': '',
                        'poll_thread': false,
                        'type': widget.controller.modelList2.length < 2
                            ? 'post'
                            : 'thread'
                      }));

                      //   widget.controller. indexOfText();
                      print('list of ');
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              CreatePostMobile(widget.controller),
                        ),
                      );
                    },
                    backgroundColor: widget.controller.displayColor,
                    child: Icon(
                      Icons.add,
                      color: Colors.white,
                    ),
                  )
            : FloatingActionButton(
                heroTag: UniqueKey(),
                onPressed: () {
                  widget.controller.modelList2 = [];

                  widget.controller.modelList2.add(ModelClass.fromJson({
                    'body': '',
                    'poll_ques_first': null,
                    'poll_ques_first': null,
                    'poll_ques_third': null,
                    'poll_ques_fourth': null,
                    //  selectType: "Public",
                    'files': [],
                    'link_meta': '',
                    'link': '',
                    'link_image': '',
                    'link_title': '',
                    'days': '',
                    'minutes': '',
                    'hours': '',
                    'location': '',
                    'lat': '',
                    'lng': '',
                    'poll_thread': false,
                    'type': widget.controller.modelList2.length < 2
                        ? 'post'
                        : 'thread'
                  }));

                  //   widget.controller. indexOfText();
                  print('list of ');
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          CreatePostMobile(widget.controller),
                    ),
                  );
                },
                backgroundColor: widget.controller.displayColor,
                child: Icon(
                  Icons.add,
                  color: Colors.white,
                ),
              ),
        body: widget.controller.isNewsfeedLoading == true ||
                widget.controller.languageData == null
            ? Center(
                child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                  MyColors.BlueColor,
                ),
              ))
            : /*GetBuilder<NewsfeedController>(
            builder: (controller) {
              return Container(
                //  color: Colors.amber,
                height: Get.height*6,
                child:ListView.builder(
                  itemCount: controller.postList.length,
                  itemBuilder: (context, index) {
                    return Container(
                      child: controller.postList[index].type=='thread'?
                      ThreadPostCard(
                          scaffoldKey: _scaffoldKey,
                          post: widget.controller?.postList[index],
                          index: index,
                          controller: widget.controller) :
                      PostCard(
                        postList:  widget.controller.postList,
                        post: widget.controller?.postList[index],
                        scaffoldKey: _scaffoldKey,
                        index: index,
                        controller: widget.controller,
                      ),
                    );
                  },
                ),

              );
            }
        )*/
            Stack(
                alignment: Alignment.topCenter,
                children: [
                  Column(
                    children: [
                      kIsWeb
                          ? GetBuilder<NewsfeedController>(
                              id: "post",
                              builder: (_) {
                                // print("first builder");
                                return Expanded(
                                  child: Theme(
                                    data: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? Styles.appTheme
                                        : ThemeData(
                                            backgroundColor: Colors.black,
                                            scrollbarTheme: ScrollbarThemeData(
                                              radius: Radius.circular(10.0),
                                              thumbColor:
                                                  MaterialStateProperty.all(
                                                      Colors.grey),
                                              trackColor:
                                                  MaterialStateProperty.all(
                                                      Color(0xFFf7f9f9)),
                                              trackBorderColor:
                                                  MaterialStateProperty.all(
                                                      Color(0xFFf7f9f9)),
                                              showTrackOnHover: true,
                                              trackVisibility:
                                                  MaterialStateProperty.all(
                                                      true),
                                              thickness:
                                                  MaterialStateProperty.all(10),
                                              minThumbLength: 100,
                                              isAlwaysShown: true,
                                            ),
                                          ),
                                    child: PagedL(
                                      emptyStateWidget:
                                          ListViewLoadingShimmer(),
                                      // Text(Strings.noPosts),
                                      itemBuilder: _itemRow,
                                      padding: EdgeInsets.only(
                                          top: 16.00, left: 0.00, right: 0.00),
                                      loadingIndicator: Padding(
                                        padding: EdgeInsets.all(10.00),
                                        child: ListViewLoadingShimmer(),
                                      ),
                                      itemDataProvider: _fetchData,
                                      list: _.postList,
                                      listSize: _checkPage(_.postList.length),

                                      // + 1
                                      // : _checkPage(_.postList.length),
                                      newsFeedCheck: true,
                                    ),
                                  ),
                                );
                              })
                          : GetBuilder<NewsfeedController>(
                              id: "ccc",
                              builder: (_) {
                                //return SizedBox();
                                // print("second builder" + _.postList[0].body);
                                return Expanded(
                                  child: RefreshIndicator(
                                    triggerMode:
                                        RefreshIndicatorTriggerMode.anywhere,
                                    onRefresh: () async {
                                      widget.isPullToRefresh = true;
                                      // widget.controller.postList = await widget.controller.getNewsFeed(
                                      //     shouldUpdate: true, reload: true);
                                      // widget.controller.update();
                                      widget.controller.postList =
                                          await widget.controller.getNewsFeed(
                                        shouldUpdate: false,
                                        reload: true,
                                        newsFeedMobile: true,
                                      );
                                      widget.controller.update();

                                      widget.isPullToRefresh = false;
                                      /*return await _.getNewsFeed(
                                    shouldUpdate: true, reload: false);*/
                                    },
                                    child: _.postList.isEmpty
                                        ? SizedBox()
                                        : PagedL(
                                            emptyStateWidget:
                                                ListViewLoadingShimmer(),
                                            // Text(Strings.noPosts),
                                            itemBuilder: _itemRow,
                                            padding: EdgeInsets.only(
                                                top: 0.00,
                                                left: 4.00,
                                                right: 4.00),
                                            loadingIndicator: Padding(
                                              padding: EdgeInsets.all(10.00),
                                              child: Center(
                                                  child:
                                                      ListViewLoadingShimmer()
                                                  // Container(
                                                  //     color: Colors.grey[200],
                                                  //     // margin: EdgeInsets.all(10),
                                                  //     height: 320,
                                                  //     child: buildPostShimmer(
                                                  //         context)),
                                                  ),
                                            ),
                                            itemDataProvider: _fetchData,
                                            list: _.postList,
                                            listSize:
                                                _checkPage(_.postList.length),
                                            newsFeedCheck: true,
                                          ),
                                  ),
                                );
                              }),
                    ],
                  ),
                  // widget.controller.isSearch == true
                  //     ? Padding(
                  //         padding: const EdgeInsets.only(top: 0.0),
                  //         child: Card(
                  //           child: Container(
                  //             height: MediaQuery.of(context).size.height / 2.5,
                  //             width: MediaQuery.of(context).size.width / 2.5,
                  //             color: Theme.of(context).brightness == Brightness.dark ? Colors.black : Colors.white,
                  //             padding: EdgeInsets.all(5),
                  //             child: widget.controller.searchResult == null ||
                  //                     widget.controller.searchResult.isEmpty
                  //                 ? Align(
                  //                     alignment: Alignment.topCenter,
                  //                     child: Text(
                  //                       Strings.noSearchResult,
                  //                         style: Styles.baseTextTheme.headline2.copyWith(
                  //                           color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                  //                           fontWeight: FontWeight.bold,
                  //                         ),
                  //                     ))
                  //                 : SingleChildScrollView(
                  //                     child: Column(
                  //                       crossAxisAlignment:
                  //                           CrossAxisAlignment.center,
                  //                       children: [
                  //                         Text(
                  //                           Strings.searchResult,
                  //                             style: Styles.baseTextTheme.headline2.copyWith(
                  //                               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                  //                               fontWeight: FontWeight.bold,
                  //                             ),
                  //                         ),
                  //                         SizedBox(
                  //                           height: 10,
                  //                         ),
                  //                         Column(
                  //                           crossAxisAlignment:
                  //                               CrossAxisAlignment.start,
                  //                           children: List.generate(
                  //                               widget.controller.searchResult
                  //                                   .length, (index) {
                  //                             if (widget.controller.searchResult[index].username != null)
                  //                               return InkWell(
                  //                                 splashColor: Colors.grey,
                  //                                 onTap: () {
                  //                                   print("hiiiiiiiiiiiii");
                  //
                  //
                  //
                  //
                  //                                   widget.controller.searchText.text = widget.controller.searchResult[index].username.trim();
                  //
                  //                                   widget.controller.tagText = widget.controller.searchResult[index].username;
                  //                                   widget.controller.isFilterScreen = true;
                  //                                   widget.controller.isNewsFeedScreen = false;
                  //                                   widget.controller.isSearch = false;
                  //                                   widget.controller.isBrowseScreen = false;
                  //                                   widget.controller.isSavedPostScreen = false;
                  //                                   widget.controller.searchSelected = widget.controller.searchResult[index];
                  //                                   widget.controller.otherUserName = widget.controller.searchResult[index].username;
                  //                                   widget.controller.postUserId = widget.controller.searchResult[index].id;
                  //
                  //                                   SingleTone.instance.searchId=widget.controller.searchResult[index].id.toString();
                  //                                   SingleTone.instance.searchType=widget.controller.searchResult[index].type;
                  //                                   SingleTone.instance.searchTag=widget.controller.searchResult[index].username.trim();
                  //                                   SingleTone.instance.searchTab=widget.controller.seletedTab;
                  //                                   Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");
                  //
                  //                                   // Get.toNamed(FluroRouters.mainScreen + "/filters/"+widget.controller.searchResult[index].username.toString());
                  //
                  //
                  //                                  /* widget.controller.filterUsers(id: widget.controller.searchResult[index].id,
                  //                                       type: widget.controller.searchResult[index].type,
                  //                                       tag: widget.controller.searchResult[index].username);
                  //                                   widget.controller.update();*/
                  //
                  //
                  //
                  //
                  //                                   // print(widget
                  //                                   //     .controller
                  //                                   //     .searchResult[index]
                  //                                   //     .username);
                  //                                   // print(widget
                  //                                   //     .controller
                  //                                   //     .searchResult[index]
                  //                                   //     .title);
                  //                                   // print(widget
                  //                                   //     .controller
                  //                                   //     .searchResult[index]
                  //                                   //     .id);
                  //                                 },
                  //                                 child: Container(
                  //                                   width: Get.width,
                  //                                   margin: EdgeInsets.only(
                  //                                       bottom: 5),
                  //                                   padding:
                  //                                       EdgeInsets.all(8.0),
                  //                                   color: Colors.grey
                  //                                       .withOpacity(0.05),
                  //                                   child: Row(
                  //                                     children: [
                  //                                       CircleAvatar(
                  //                                         backgroundImage: widget
                  //                                                     .controller
                  //                                                     .searchResult[
                  //                                                         index]
                  //                                                     .profileImage !=
                  //                                                 null
                  //                                             ? NetworkImage(widget
                  //                                                 .controller
                  //                                                 .searchResult[
                  //                                                     index]
                  //                                                 .profileImage)
                  //                                             : AssetImage(
                  //                                                 "assets/images/person_placeholder.png"),
                  //                                         radius: 18,
                  //                                       ),
                  //                                       SizedBox(
                  //                                         width: 20,
                  //                                       ),
                  //                                       Column(
                  //                                         crossAxisAlignment: CrossAxisAlignment.start,
                  //                                         children: [
                  //                                           ///bluetick
                  //
                  //                                           Row(
                  //                                             // mainAxisAlignment: MainAxisAlignment.center,
                  //                                             children: [
                  //                                               Text(
                  //                                                   "${widget.controller.searchResult[index].firstname}",
                  //                                                   style:Styles.baseTextTheme.headline2.copyWith(
                  //                                                     color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                  //                                                     fontWeight: FontWeight.bold,
                  //                                                     fontSize: 15,
                  //                                                   ),),
                  //                                               widget.controller.searchResult[index].accountVerified == "verified"?
                  //                                               Row(children: [
                  //                                                 SizedBox(
                  //                                                   width: 5,
                  //                                                 ),
                  //                                                 BlueTick(
                  //                                                   height: 15,
                  //                                                   width: 15,
                  //                                                   iconSize:10,
                  //                                                 ),
                  //                                               ],):SizedBox(),
                  //
                  //                                             ],
                  //                                           ),
                  //                                           Text(
                  //                                               "${widget.controller.searchResult[index].username}",
                  //                                             style: Styles.baseTextTheme.headline2.copyWith(
                  //                                              fontSize: kIsWeb? 14 : 12,
                  //                                             ),),
                  //
                  //                                         ],
                  //                                       ),
                  //                                     ],
                  //                                   ),
                  //                                 ),
                  //                               );
                  //                             return InkWell(
                  //                               splashColor: Colors.grey,
                  //                               onTap: () async {
                  //                                 print("search filter");
                  //
                  //                                 widget.controller.isFilterScreen = true;
                  //                                 widget.controller.isNewsFeedScreen = false;
                  //                                 widget.controller.isSearch = false;
                  //                                 widget.controller.isBrowseScreen = false;
                  //                                 widget.controller.isSavedPostScreen = false;
                  //                                 widget.controller.searchSelected = widget.controller.searchResult[index];
                  //
                  //                                 SingleTone.instance.searchId=widget.controller.searchResult[index].id.toString();
                  //                                 SingleTone.instance.searchType=widget.controller.searchResult[index].type;
                  //                                 SingleTone.instance.searchTag="";
                  //                                 SingleTone.instance.searchTab=widget.controller.seletedTab;
                  //                                 Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=false");
                  //                                 // Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${0.toString()}&type=${"tag"}&tag=${string}");
                  //
                  //                                 /*widget.controller.filterUsers(
                  //                                   id: widget.controller.searchResult[index].id,
                  //                                   type: widget.controller.searchResult[index].type,
                  //                                 );
                  //                                 widget.controller.update();*/
                  //                                 // print(widget
                  //                                 //     .controller
                  //                                 //     .searchResult[index]
                  //                                 //     .username);
                  //                                 // print(widget
                  //                                 //     .controller
                  //                                 //     .searchResult[index]
                  //                                 //     .title);
                  //                                 // print(widget.controller
                  //                                 //     .searchResult[index].id);
                  //                               },
                  //                               child: Container(
                  //                                 width: Get.width,
                  //                                 margin: EdgeInsets.only(
                  //                                     bottom: 5),
                  //                                 padding: EdgeInsets.all(8.0),
                  //                                 color: Colors.grey
                  //                                     .withOpacity(0.05),
                  //                                 child: Row(
                  //                                   children: [
                  //                                     CircleAvatar(
                  //                                       backgroundImage: widget
                  //                                                   .controller
                  //                                                   .searchResult[
                  //                                                       index]
                  //                                                   .profileImage !=
                  //                                               null
                  //                                           ? NetworkImage(widget
                  //                                               .controller
                  //                                               .searchResult[
                  //                                                   index]
                  //                                               .profileImage)
                  //                                           : AssetImage(
                  //                                               "assets/images/person_placeholder.png"),
                  //                                       radius: 18,
                  //                                     ),
                  //                                     SizedBox(
                  //                                       width: 20,
                  //                                     ),
                  //                                     new Text(
                  //                                         "${widget.controller.searchResult[index].title}",
                  //                             style:Styles.baseTextTheme.headline2.copyWith(
                  //                               color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                  //                               fontWeight: FontWeight.bold,
                  //                               fontSize: 15,
                  //                             ),),
                  //                                   ],
                  //                                 ),
                  //                               ),
                  //                             );
                  //                           }),
                  //                         ),
                  //                       ],
                  //                     ),
                  //                   ),
                  //           ),
                  //         ),
                  //       )
                  //     : SizedBox(),
                ],
              ));
  }

  ///  addd
// Widget createAd() {
//   bool isLoaded = false;
//   _ad = NativeAd(
//     adUnitId: AdHelper.bannerAdUnitId,
//     factoryId: 'listTile',
//     request: AdRequest(),
//     listener: _adHelper.adListener,
//   );
//   _ad.load().whenComplete(() =>isLoaded = true );
//   if(isLoaded){

//   }
//   else{
//     Container('-')
//   }

// }

//ignore: missing_return
  // page list
  int _checkPage(int list) {
    if (list != 0) {
      int remain = list % 10;
      if (remain != 0) {
        return 50000;
      } else {
        // ignore: division_optimization
        int page = (list / 10).toInt();
        // print("Page" + page.toString());
        if (page == 0 || page == 1) {
          return 2;
        } else {
          return page++;
        }
      }
    }
  }

// get newsfeed
  Future<List<Post>> _fetchData(int page) async {
    return await widget.controller.getNewsFeedPagged(page: page);
  }

// item rows
  Widget _itemRow(BuildContext context, Post post) {
    //
    // print("aya hai idhrvvv");

    int index = widget.controller.postList.indexWhere((element) {
      // print(element.postId.toString() + ' : ' + post.postId.toString());
      return element.postId == post.postId;
    });

    /*  print('check the index number  :${index} :${widget.controller.postList[index].thread_no}'
       ' :${widget.controller.postList.asMap().containsKey(index-1) ?
   widget.controller.postList[index-1].thread_no :null}');*/

    // if (widget.controller.languageData ==null)
    //   {
    //
    //     return CircularProgressIndicator();
    //   }
    //else

    if (index != 0 && index % 13 == 0 && !kIsWeb) {
      // print('Called this many times ${widget.num++}');
      return Column(
        children: [
          widget.controller.postList[index].type == 'thread'
              ? index == 0
                  ? Column(
                      children: [
                        !kIsWeb
                            ? SizedBox()
                            : CreatePostWeb(
                                widget.controller,
                                widget.controller.userProfile,
                                post: widget.post,
                              ),
                        Divider(
                          thickness: 2,
                          color: Colors.grey[200],
                        ),
                        ThreadPostCard(
                            postList: widget.controller.postList,
                            scaffoldKey: _scaffoldKey,
                            post: widget.controller?.postList[index],
                            index: index,
                            controller: widget.controller,
                            deletePostId: 1,
                            mute: 0),
                      ],
                    )
                  : ThreadPostCard(
                      postList: widget.controller.postList,
                      scaffoldKey: _scaffoldKey,
                      post: widget.controller?.postList[index],
                      index: index,
                      controller: widget.controller,
                      deletePostId: 1,
                      mute: 0)
              : index == 0
                  ? Column(
                      children: [
                        !kIsWeb
                            ? SizedBox()
                            : CreatePostWeb(
                                widget.controller,
                                widget.controller.userProfile,
                                post: widget.post,
                              ),
                        Divider(
                          thickness: 2,
                          color: Colors.grey[200],
                        ),
                        GestureDetector(
                          child: PostCard(
                              postList: widget.controller.postList,
                              post: widget.controller?.postList[index],
                              scaffoldKey: _scaffoldKey,
                              index: index,
                              controller: widget.controller,
                              deletePostId: widget.controller.deletePostId,
                              mute: 0),
                        ),
                      ],
                    )
                  : GestureDetector(
                      child: PostCard(
                          postList: widget.controller.postList,
                          post: widget.controller?.postList[index],
                          scaffoldKey: _scaffoldKey,
                          index: index,
                          controller: widget.controller,
                          deletePostId: widget.controller.deletePostId,
                          mute: 0),
                    ),
          SizedBox(height: 4),

          // kIsWeb?CustomAdWidgetWeb(): CustomAdWidget(
          CustomAdWidget(
              // ad: widget.controller.ads[widget.adIndex++],
              ),
        ],
      );
    } else {
      return VisibilityDetector(
        key: Key('postCard-widget-key'),
        onVisibilityChanged: (visibilityInfo) {
          double visiblePercentage = visibilityInfo.visibleFraction * 100;
          // debugPrint(
          //     'Widget ${visibilityInfo.key} is ${visiblePercentage}% visible with post id ${post.postId}');
          if (visiblePercentage > 20 &&
              post.authorId != widget.controller.userId) {
            widget.controller.emitImpressionsSocket(post.postId);
          }
        },
        child: widget.controller.postList[index].type == 'thread'
            ? index == 0
                ? Column(
                    children: [
                      !kIsWeb
                          ? SizedBox()
                          : CreatePostWeb(
                              widget.controller,
                              widget.controller.userProfile,
                              post: widget.post,
                            ),
                      Divider(
                        thickness: 2,
                        color: Colors.grey[200],
                      ),
                      ThreadPostCard(
                          postList: widget.controller.postList,
                          scaffoldKey: _scaffoldKey,
                          post: widget.controller?.postList[index],
                          index: index,
                          controller: widget.controller,
                          deletePostId: 1,
                          mute: 0),
                    ],
                  )
                : ThreadPostCard(
                    postList: widget.controller.postList,
                    scaffoldKey: _scaffoldKey,
                    post: widget.controller?.postList[index],
                    index: index,
                    controller: widget.controller,
                    deletePostId: 1,
                    mute: 0)
            : index == 0
                ? Column(
                    children: [
                      !kIsWeb
                          ? SizedBox()
                          : CreatePostWeb(
                              widget.controller,
                              widget.controller.userProfile,
                              post: widget.post,
                            ),
                      Divider(
                        thickness: 2,
                        color: Colors.grey[200],
                      ),
                      PostCard(
                          postList: widget.controller.postList,
                          post: widget.controller?.postList[index],
                          scaffoldKey: _scaffoldKey,
                          index: index,
                          controller: widget.controller,
                          deletePostId: 1,
                          mute: 0),
                    ],
                  )
                : PostCard(
                    postList: widget.controller.postList,
                    post: widget.controller?.postList[index],
                    scaffoldKey: _scaffoldKey,
                    index: index,
                    controller: widget.controller,
                    deletePostId: 1,
                    mute: 0),
      );
    }
  }

// Widget buildPostShimmer(BuildContext context) => ListTile(
//       //Shimmer for Profile Photo
//       leading: CustomShimmerWidget.circular(height: 64, width: 64),
//       title: Column(
//         children: [
//           SizedBox(height: 20),
//           //Shimmer for username
//           Align(
//             alignment: Alignment.centerLeft,
//             child: CustomShimmerWidget.rectangular(
//               height: 16,
//               width: MediaQuery.of(context).size.width * 0.3,
//             ),
//           ),
//           SizedBox(height: 20),
//           //Shimmer for post text
//           CustomShimmerWidget.rectangular(
//             height: 210,
//           ),
//           SizedBox(height: 20),
//           //Shimmer for reaction row
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               SizedBox(width: 16),
//               CustomShimmerWidget.rectangular(
//                 height: 14,
//                 width: kIsWeb
//                     ? MediaQuery.of(context).size.width * 0.07
//                     : MediaQuery.of(context).size.width * 0.15,
//               ),
//               //  SizedBox(width: 16),
//             ],
//           ),
//           SizedBox(height: 16),
//         ],
//       ),
//       // trailing: SizedBox(),
//       // subtitle: CustomShimmerWidget.rectangular(
//       //     height: 14, width: MediaQuery.of(context).size.width * 0.3),
//     );
}
