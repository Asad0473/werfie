import 'package:flutter/material.dart';

class MentionsWidget extends StatelessWidget {
  const MentionsWidget({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
        child: ListView.separated(
      separatorBuilder: (context, index) => Divider(height: 1),
      padding: EdgeInsets.all(15),
      itemCount: 12,
      itemBuilder: (context, i) {
        return ListTile(
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [Icon(Icons.more_horiz)],
          ),
          contentPadding: EdgeInsets.all(11),
          leading: CircleAvatar(
            radius: 44,
            foregroundImage: AssetImage('assets/images/image.jpg'),
          ),
          title: Text("Ali Ahmed has mentioned you in group name Friends"),
          subtitle: Text('23 mins ago'),
        );
      },
    ));
  }
}
