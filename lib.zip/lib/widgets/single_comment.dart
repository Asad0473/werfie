import 'package:flutter/material.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

// ignore: must_be_immutable
// class SingleComment extends StatelessWidget {
//   final Post post;
//
//   final index;
//   final NewsfeedController controller;
//
//
//   MobileCommentsController mobileCommentsController = Get.put(
//       MobileCommentsController());
//
//   SingleComment(this.post, this.index, this.controller);
//
//   @override
//   Widget build(BuildContext context) {
//     String authorName = post.comments[index].author.firstname + ' ' +
//         post.comments[index].author.lastname;
//     return Stack(
//       children: [
//         Obx(() {
//           return Column(
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   CircleAvatar(
//                     backgroundImage: post.comments[index].author.profileImage !=
//                         null
//                         ? NetworkImage(post.comments[index].author.profileImage)
//                         : AssetImage('assets/images/person_placeholder.png'),
//                     radius: 12,
//                   ),
//                   SizedBox(width: 5),
//                   Container(
//                     width: authorName.length >= 15 ? 120 : null,
//                     child: Text(
//                       authorName,
//                       overflow : TextOverflow.ellipsis,
//                       maxLines : 1,
//                       style: Styles.baseTextTheme.headline2.copyWith(
//                         color: Theme
//                             .of(context)
//                             .brightness == Brightness.dark ? Colors.white : Colors
//                             .black,
//                         fontSize: 12,
//                         fontWeight: FontWeight.w500,
//                       ),
//                     ),
//                   ),
//                   // SizedBox(width: 6),
//                   Text(
//                     Strings.replied,
//                     style: Styles.baseTextTheme.headline4.copyWith(
//                       color: Theme
//                           .of(context)
//                           .brightness == Brightness.dark ? Colors.white : Colors
//                           .black,
//                       fontSize: kIsWeb ? 14 : 12,
//                       fontWeight: FontWeight.w400,
//                     ),
//                   ),
//                   SizedBox(width: 5),
//                   Expanded(
//                     child: Text(
//                       post.comments[index].commentedTimeAgo,
//                       style: Styles.baseTextTheme.headline4.copyWith(
//                         color: Theme
//                             .of(context)
//                             .brightness == Brightness.dark
//                             ? Colors.white
//                             : Colors.black,
//                         fontSize: kIsWeb ? 14 : 12,
//                         fontWeight: FontWeight.w400,
//                       ),
//                     ),
//                   ),
//
//
//                   post.comments[index].userId == post.authorId.toString()
//                       ? SizedBox()
//                       : myPopMenu(
//                       context, post, post.comments[index].id, controller,
//                       index),
//
//                 ],
//               ),
//               SizedBox(height: 4),
//               ClipRRect(
//                 borderRadius: BorderRadius.circular(80),
//                 child: Container(
//                   padding: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
//                   width: double.infinity,
//                   // height: 40,
//                   alignment: Alignment.centerLeft,
//                   decoration: ShapeDecoration(
//                     color: Colors.grey[200],
//                     shape: RoundedRectangleBorder(
//                       borderRadius: BorderRadius.circular(20),
//                     ),
//                   ),
//                   child: Row(
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     children: [
//                       // Text(
//                       //   'Hello',
//                       //   style: Theme.of(context).textTheme.bodyText1,
//                       // ),
//                       RichTextView(
//                         context,
//                         post.comments[index].body,
//                         false,
//                         controller,
//                         post.authorId,
//                         Colors.black,
//                         post,
//                         shouldGiveFixedHeight: kIsWeb ? false : true,
//                       ),
//                       InkWell(
//                         onTap: () async {
//                           print('PRESSED SPEAKER');
//
//                           if (post.comments[index].isTTSPlayingComments) {
//                             post.comments[index].isTTSPlayingComments =
//                             !post.comments[index].isTTSPlayingComments;
//                             // widget.post.tts.pauseHandler();
//                             post.comments[index].tts.stop();
//                             controller.update();
//                           } else
//                           if (!post.comments[index].isTTSPlayingComments) {
//                             post.comments[index].tts = FlutterTts();
//
//                             post.comments.forEach((element) {
//                               element.tts = FlutterTts();
//
//                               print(element.isTTSPlayingComments.toString());
//                               element.isTTSPlayingComments = false;
//                               element.tts.stop();
//                               controller.update();
//                             });
//
//                             post.comments[index].isTTSPlayingComments = true;
//
//                             controller.update();
//                             post.comments[index].tts.awaitSpeakCompletion(true);
//                             post.comments[index].tts.speak(post.comments[index]
//                                 .body);
//                             post.comments[index].tts.setLanguage(
//                                 "${controller.languageData.myLang.code}");
//                             // await widget.post.tts.setPitch(1.0);
//                             post.comments[index].tts.setCompletionHandler(() {
//                               print("Complete");
//                               post.comments[index].isTTSPlayingComments = false;
//                               controller.update();
//                             });
//                           }
//                           controller.update();
//                         },
//                         child: FaIcon(
//                           post.comments[index].isTTSPlayingComments
//                               ? FontAwesomeIcons.volumeUp
//                               : FontAwesomeIcons.volumeDown,
//                           color: Colors.black,
//                           size: 20,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               SizedBox(height: 6),
//               post.comments[index].id == null || post.comments[index].id == ""
//                   ? SizedBox()
//                   :
//
//               Obx(() {
//                 return Row(
//                   children: [
//                     SizedBox(width: 12),
//
//                     /// temperory_comment
//                     InkWell(
//                       onTap: kIsWeb
//                           ? () async {
//                         if (post.comments[index].reactionCheck == false) {
//                           post.comments.forEach((element) {
//                             element.reactionCheck.value =
//                                 post.reactionCheck.value = false;
//                           });
//                           post.comments[index].reactionCheck.value = true;
//
//
//                           print("post.reactionCheck.value ${post.comments[index]
//                               .reactionCheck.value}");
//                         }
//                         else if (post.comments[index].reactionCheck == true) {
//                           post.comments[index].reactionCheck.value = false;
//                           print(
//                               "post.reactionCheck.value ${ post.comments[index]
//                                   .reactionCheck.value}");
//                         }
//
//
//                         // post.comments[index].isLiked ? post.comments[index].simpleLikeCount = post.comments[index].simpleLikeCount - 1 :
//                         // post.comments[index].simpleLikeCount = post.comments[index].simpleLikeCount + 1;
//                         // post.comments[index].isLiked = !post.comments[index].isLiked;
//                         //
//                         // controller.update();
//                         // var response = await controller.likeComment(int.parse(post.comments[index].id));
//                         // if (response) {
//                         //   print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                         //   ;
//                         // }
//                       }
//                           : () async {
//                         if (post.comments[index].reactionCheck == false) {
//                           post.comments.forEach((element) {
//                             element.reactionCheck.value =
//                                 post.reactionCheck.value = false;
//                           });
//
//                           post.comments[index].reactionCheck.value = true;
//                           print("post.reactionCheck.value ${post.comments[index]
//                               .reactionCheck.value}");
//                         }
//                         else if (post.comments[index].reactionCheck == true) {
//                           post.comments[index].reactionCheck.value = false;
//                           print(
//                               "post.reactionCheck.value ${ post.comments[index]
//                                   .reactionCheck.value}");
//                         }
//
//                         // post.comments[index].isLiked ? post.comments[index].simpleLikeCount = post.comments[index].simpleLikeCount - 1
//                         //     : post.comments[index].simpleLikeCount =
//                         //         post.comments[index].simpleLikeCount + 1;
//                         // post.comments[index].isLiked = !post.comments[index].isLiked;
//                         // Get.find<MobileCommentsController>().update();
//                         //
//                         // var response = await controller.likeComment(
//                         //     int.parse(post.comments[index].id));
//                         // if (response) {
//                         //   print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                         //   controller.update();
//                         // }
//                       },
//                       child:
//                       post.comments[index].reactionType.value == "love" ?
//                       Image.asset(
//                         'assets/reaction_gif/love-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == "simple_like" ?
//                       Image.asset(
//                         'assets/reaction_gif/like-min.png',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == null ?
//                       Image.asset(
//                         'assets/drawer_icons/not_like.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 25,
//                         height: 25,
//
//                       ) :
//                       post.comments[index].reactionType.value == "lough" ?
//                       Image.asset(
//                         'assets/reaction_gif/laugh-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == "smile" ?
//                       Image.asset(
//                         'assets/reaction_gif/smile-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == "thanks" ?
//                       Image.asset(
//                         'assets/reaction_gif/thanks-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == "excited" ?
//                       Image.asset(
//                         'assets/reaction_gif/excited-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ) :
//                       post.comments[index].reactionType.value == "cry" ?
//                       Image.asset(
//                         'assets/reaction_gif/cry-min.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//                       ) :
//                       Image.asset(
//                         'assets/drawer_icons/not_like.png',
//                         // : 'assets/reaction_gif/like_gif.gif',
//                         width: 20,
//                         height: 20,
//
//                       ),
//
//
//                       // Text(
//                       //
//                       //
//                       //     post.comments[index].isLiked ? Strings.liked : Strings.like,
//                       //
//                       //     style: Theme.of(context).textTheme.bodyText2.copyWith(color: post.comments[index].isLiked ? Colors.blue : Colors.black))
//
//
//                     ),
//
//
//                     SizedBox(width: 5),
//                     GestureDetector(
//                       onTap: () async {
//                         if (kIsWeb) {
//                           showDialog(
//                               context: context,
//                               builder: (context) {
//                                 return CommentReact(
//                                   'People who reacted',
//                                   comment: post.comments[index],
//
//                                   // reactions: data,
//                                 );
//                               });
//                           await controller.getWhoReactedForCommment(
//                               post.comments[index].id, reactionType: "all",
//                               allLikes: 0);
//                         }
//                         else {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(builder: (context) =>
//                                 CommentReact(
//                                   'People who reacted',
//                                   comment: post.comments[index],
//                                   // post: post,
//                                   // reactions: data,
//                                 )),
//                           );
//                           // List<Reaction1> data =
//
//                           print(post.postId);
//                           await controller.getWhoReactedForCommment(post
//                               .comments[index].id, reactionType: "all",
//                               allLikes: 0);
//                         }
//                       },
//                       child: Container(
//                         padding: const EdgeInsets.symmetric(
//                           horizontal: 5,
//                           vertical: 1,
//                         ),
//                         decoration: BoxDecoration(
//                           color: Colors.grey[100],
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         child: Text(
//                           "${post.comments[index].commentCount.value}",
//                           // style: TextStyle(
//                           //   color: Colors.black,
//                           //   fontSize: 12,
//                           // ),
//                           style: Theme
//                               .of(context)
//                               .brightness == Brightness.dark ?
//                           TextStyle(color: Colors.black,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12
//                           )
//                               : TextStyle(color: Colors.black,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10),
//                     InkWell(
//                       onTap: () {
//                         // if( controller.replyMentionTag.length>0)
//                         //   {
//                         //     controller.replyMentionTag.forEach((element) {
//                         //
//                         //       element= false;
//                         //       print("sdassdfsdfsdfsdfsdfsdfsdfd");
//                         //     });
//                         //     controller.update();
//                         //   }
//
//
//                         if(   kIsWeb)
//                           {
//                             controller.ReplyCommentController.clear();
//                             controller.update();
//                           }
//
//                         kIsWeb
//                             ? post.comments.forEach((element) {
//                           element.isReply.value = false;
//                           element.replyMentionTag.value = false;
//                         })
//                             : Navigator.of(context).push(MaterialPageRoute(
//                             builder: (BuildContext context) =>
//                                 ReplyCommentScreenMobile(
//                                     post.comments[index].id,
//                                     post.postId,
//                                     post,
//                                     index,
//                                     controller
//
//                                 )));
//                         if (kIsWeb) post.comments[index].isReply.value = true;
//                       },
//                       child: Text(Strings.reply,
//                         style: Theme
//                             .of(context)
//                             .brightness == Brightness.dark ?
//                         TextStyle(
//                             color: Colors.white, fontWeight: FontWeight.bold
//                         )
//                             : TextStyle(
//                             color: Colors.black, fontWeight: FontWeight.bold
//                         ),),
//                     ),
//                     SizedBox(
//                       width: 8,
//                     ),
//                     GestureDetector(
//                       onTap: () async {},
//                       child: Container(
//                         padding: const EdgeInsets.symmetric(
//                           horizontal: 5,
//                           vertical: 1,
//                         ),
//                         decoration: BoxDecoration(
//                           color: Colors.grey[100],
//                           borderRadius: BorderRadius.circular(20),
//                         ),
//                         child: Text(
//                           "${post.comments[index].repliesCount}",
//                           // style: TextStyle(
//                           //   color: Colors.black,
//                           //   fontSize: 12,
//                           // ),
//                           style: Theme
//                               .of(context)
//                               .brightness == Brightness.dark ?
//                           TextStyle(color: Colors.black,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12
//                           )
//                               : TextStyle(color: Colors.black,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 12
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(
//                       width: 8,
//                     ),
//                     post.comments[index].author.username !=
//                         controller.storage.read('userName')
//                         ? SizedBox()
//                         : InkWell(
//                       onTap: () async {
//                         kIsWeb ? {
//
//                           print("post.comments[index].commentCount.value  ${post
//                               .commentCount.value}"),
//                           post.commentCount.value = post.commentCount.value - 1,
//
//                           print("post.comments[index].commentCount.value  ${post
//                               .commentCount.value}"),
//
//
//                           controller.deleteComment(post.comments[index].id),
//
//                           controller.selectedPost2.forEach((element) {
//                             if (element.postId == post.postId) {
//                               element.commentCount.value =
//                                   post.commentCount.value;
//                             }
//                           }),
//
//                           print("delete hello"),
//
//                           print("comment  index ${index}"),
//                           post.comments.removeAt(index),
//
//                           controller.update(),
//                         } :
//                         {
//
//                           print("post.comments[index].commentCount.value  ${post
//                               .commentCount.value}"),
//
//
//                           post.commentCount.value = post.commentCount.value - 1,
//
//                           controller.selectedPost2.forEach((element) {
//                             if (element.username == post.username) {
//                               element.commentCount.value =
//                                   post.commentCount.value;
//                             }
//                           }),
//
//                           print("post.comments[index].commentCount.value  ${post
//                               .commentCount.value}"),
//
//                           controller.update(),
//
//                           // controller.deleteComment(post.comments[index].id),
//
//                           Get.find<MobileCommentsController>().deleteComment(
//                               post.comments[index].id),
//                           // print( "post.comments[index].commentCount.value  ${post.commentCount.value}"),
//
//
//                           post.comments.removeAt(index),
//
//
//                           controller.update(),
//                           Get.find<MobileCommentsController>().update(),
//                         };
//                       },
//                       child: Text(
//
//                         ///
//                         Strings.delete,
//                         style: Theme
//                             .of(context)
//                             .brightness == Brightness.dark ?
//                         TextStyle(
//                           color: Colors.white, fontWeight: FontWeight.bold,
//                         )
//                             : TextStyle(
//                           color: Colors.black, fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ],
//                 );
//               }),
//
//
//               post.comments[index].replies == null
//                   ? SizedBox()
//                   : post.comments[index].replies.length > 0
//                   ? ListView.builder(
//                   shrinkWrap: true,
//                   physics: NeverScrollableScrollPhysics(),
//                   itemCount: post.comments[index].replies.length,
//                   itemBuilder: (context, ind) {
//                     String authorNameReplies = post.comments[index].replies[ind].author.firstname + ' ' + post.comments[index].replies[ind].author.lastname;
//                     return Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Padding(
//                           padding: const EdgeInsets.only(
//                               left: 22, right: 22, top: 12),
//                           child: Row(
//                             children: [
//                               CircleAvatar(
//                                 backgroundImage: post
//                                     .comments[index]
//                                     .replies[ind]
//                                     .author
//                                     .profileImage !=
//                                     null
//                                     ? NetworkImage(post.comments[index]
//                                     .replies[ind].author.profileImage)
//                                     : AssetImage(
//                                     'assets/images/person_placeholder.png'),
//                                 radius: 12,
//                               ),
//                               SizedBox(width: 5),
//                               Container(
//                                 width : authorNameReplies.length >= 15 ?  120 : null,
//                                 child: Text(
//                                   authorNameReplies,
//                                   // style: Theme
//                                   //     .of(context)
//                                   //     .textTheme
//                                   //     .bodyText1
//                                   //     .copyWith(color: Colors.black
//                                   // ),
//                                   overflow : TextOverflow.ellipsis,
//                                   maxLines: 1,
//                                   style: Styles.baseTextTheme.headline4.copyWith(
//                                     color: Theme
//                                         .of(context)
//                                         .brightness == Brightness.dark ? Colors
//                                         .white : Colors.black,
//                                     fontSize: 12,
//                                     fontWeight: FontWeight.w500,
//                                   ),
//                                 ),
//                               ),
//                               SizedBox(width: 4),
//                               Text(
//                                 'replied',
//                                 style: Styles.baseTextTheme.headline4.copyWith(
//                                   color: Theme
//                                       .of(context)
//                                       .brightness == Brightness.dark ? Colors
//                                       .white : Colors.black,
//                                   fontSize: 14,
//                                   fontWeight: FontWeight.w500,
//                                 ),
//                               ),
//                               // Text(post.comments[index].replies[ind]
//                               //     .commentedTimeAgo)
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.only(
//                               left: 22, right: 22, top: 6),
//                           child: ClipRRect(
//                             borderRadius: BorderRadius.circular(80),
//                             child: Container(
//                               padding: EdgeInsets.symmetric(
//                                   vertical: 8, horizontal: 12),
//                               width: double.infinity,
//                               height: 40,
//                               decoration: ShapeDecoration(
//                                 color: Colors.grey[200],
//                                 shape: RoundedRectangleBorder(
//                                   borderRadius: BorderRadius.circular(20),
//                                 ),
//                               ),
//                               child: Align(
//                                 alignment: Alignment.centerLeft,
//                                 child: RichTextView(
//                                   context,
//                                   post.comments[index].replies[ind].body,
//                                   false,
//                                   controller,
//                                   post.authorId,
//                                   Colors.black,
//                                   post,
//                                 ),
//
//                                 // Text(
//                                 //   post.comments[index].replies[ind].body,
//                                 // ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         SizedBox(height: 6),
//                         post.comments[index].replies[ind].author.username !=
//                             controller.storage.read('userName')
//                             ? SizedBox()
//                             : InkWell(
//                           onTap: () async {
//                             kIsWeb ? {
//
//                               print(
//                                   "post.comments[index].commentCount.value  ${post
//                                       .commentCount.value}"),
//                               post.commentCount.value =
//                                   post.commentCount.value - 1,
//
//                               print(
//                                   "post.comments[index].commentCount.value  ${post
//                                       .commentCount.value}"),
//
//
//                               controller.deleteComment(
//                                   post.comments[index].replies[ind].id),
//
//                               controller.selectedPost2.forEach((element) {
//                                 if (element.postId == post.postId) {
//                                   element.commentCount.value =
//                                       post.commentCount.value;
//                                 }
//                               }),
//
//                               post.comments[index].replies.removeAt(ind),
//                               print("delete hello"),
//
//                               print("comment  index ${index}"),
//
//                               controller.update(),
//                             } :
//                             {
//
//                               print(
//                                   "post.comments[index].commentCount.value  ${post
//                                       .commentCount.value}"),
//
//
//                               post.commentCount.value =
//                                   post.commentCount.value - 1,
//
//                               controller.selectedPost2.forEach((element) {
//                                 if (element.username == post.username) {
//                                   element.commentCount.value =
//                                       post.commentCount.value;
//                                 }
//                               }),
//
//                               print(
//                                   "post.comments[index].commentCount.value  ${post
//                                       .commentCount.value}"),
//
//                               controller.update(),
//
//                               // controller.deleteComment(post.comments[index].id),
//
//                               Get.find<MobileCommentsController>()
//                                   .deleteComment(
//                                   post.comments[index].replies[ind].id),
//                               // print( "post.comments[index].commentCount.value  ${post.commentCount.value}"),
//
//
//                               post.comments[index].replies.removeAt(ind),
//
//
//                               controller.update(),
//                               Get.find<MobileCommentsController>().update(),
//                             };
//
//
//                             // Get.find<MobileCommentsController>().deleteComment(post.comments[index].replies[ind].id,);
//                             // post.commentsCount = post.commentsCount - 1;
//                             // post.comments[index].repliesCount = post.comments[index].repliesCount - 1;
//                             //
//                             //
//                             //
//                             //
//                             //
//                             //
//                             // post.comments[index].replies.removeAt(ind);
//                             // Get.find<MobileCommentsController>()
//                             //     .update();
//                             //
//                             // print("delete comment pressed");
//                             //  controller.deleteComment(
//                             //     post.comments[index].replies[ind].id);
//                           },
//                           child: Padding(
//                             padding: const EdgeInsets.only(
//                               left: 22,
//                               right: 22,
//                             ),
//                             child: Text(
//
//                               ///replay delete for web
//                               Strings.delete,
//                               style: Theme
//                                   .of(context)
//                                   .brightness == Brightness.dark ?
//                               TextStyle(color: Colors.white,
//                                 fontWeight: FontWeight.w700,
//                               )
//                                   : TextStyle(color: Colors.black,
//                                 fontWeight: FontWeight.w700,
//                               ),),
//                           ),
//                         ),
//                       ],
//                     );
//                   })
//                   : Container(),
//
//               post.comments[index].replyMentionTag.value == false
//                   ? SizedBox()
//                   : Align(
//                 alignment: Alignment
//                     .centerLeft,
//                 child: Container(
//                   decoration:
//                   BoxDecoration(
//                     border: Border.all(
//                       color: Colors
//                           .grey[300],
//                       width: 0.5,
//                     ),
//                     borderRadius:
//                     BorderRadius
//                         .circular(
//                         4),
//                   ),
//                   height: 150,
//                   width: 300,
//                   child: controller.replyTags.length ==
//                       0
//                       ? SpinKitWave(
//                     size: 30,
//                     color: Color(
//                         0xFFedab30),
//                   )
//                       : ListView
//                       .builder(
//                       itemCount: controller.replyTags.length,
//                       itemBuilder:
//                           (context,
//                           index_) {
//                         return ListTile(
//                           onTap:
//                               () async {
//                             //   temp='';
//                             // print("textvalue " + _controller[controller.currentIndexText].text);
//                             // print(temp);
//                             print(controller.replyTags[index_]['title']);
//
//                             /*     _controller[controller.currentIndexText].text =
//                                                       _controller[controller.currentIndexText].text.replaceAll(temp, "")+
//                                                      ' ' +
//                                                           widget.tags[index]['title'];*/
//                             controller.replyTempValue =
//                                 controller.replyTempValue.substring(0,
//                                     controller.replyTempValue.length -
//                                         controller.replyTemp.length);
//
//                             controller.replyTempValue =
//                                 controller.replyTempValue + ' ' +
//                                     controller.replyTags[index_]['title'];
//
//
//                             controller.ReplyCommentController.text = "";
//
//                             controller.ReplyCommentController.text =
//                                 controller.replyTempValue;
//                             // tempValue="";
//                             controller.ReplyCommentController.selection =
//                                 TextSelection.fromPosition(TextPosition(
//                                     offset: controller.ReplyCommentController
//                                         .text.length));
//                             // widget.focusNode
//                             //     .requestFocus();
//                             print('selection tag  ${ controller
//                                 .ReplyCommentController.selection}');
//                             print(
//                                 'value temp${ controller.ReplyCommentController
//                                     .text}');
//
//                          //   controller.replyMentionTag[index] = false;
//                             post.comments[index].replyMentionTag.value = false;
//                             //  widget.tags = [];
//                             controller.update();
//                           },
//                           title:
//                           Text(
//                             controller.replyTags[index_]['title'],
//                             style:
//                             Styles.baseTextTheme.headline2.copyWith(
//                               color: Theme
//                                   .of(context)
//                                   .brightness == Brightness.dark
//                                   ? Colors.white
//                                   : Colors.black,
//                               fontWeight: FontWeight.w700,
//                               fontSize: 15,
//                             ),
//                           ),
//                         );
//                       }),
//                 ),
//               ),
//
//               buildSimpleCommentField(controller, context, post, index)
//             ],
//           );
//         }),
//         Obx(() {
//           return
//             post.comments[index].reactionCheck.value == true ?
//             Positioned(
//               bottom: 40,
//               left: 40,
//               child: Container(
//                 height: 45,
//                 width: 260,
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.all(
//                     Radius.circular(50),
//                   ),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.grey.withOpacity(0.5),
//                       spreadRadius: 5,
//                       blurRadius: 7,
//                       offset: Offset(0, 3), // changes position of shadow
//                     ),
//                   ],
//                 ),
//                 child: ListView(
//                   scrollDirection: Axis.horizontal,
//                   children: [
//
//                     SizedBox(width: 5),
//
//                     ///like
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             'simple_like') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null || post.comments[index].reactionType.value ==
//                             "simple_dislike" ||
//                             post.comments[index].reactionType.value == "love" ||
//                             post.comments[index].reactionType.value == "cry" ||
//                             post.comments[index].reactionType.value ==
//                                 "excited" || post.comments[index].reactionType
//                             .value == "lough" || post.comments[index]
//                             .reactionType.value == "smile" || post
//                             .comments[index]
//                             .reactionType.value == "thanks") {
//                           post.comments[index].reactionType.value =
//                           "simple_like";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//
//                           post.comments[index].reactionType.value =
//                           "simple_like";
//                           post.comments[index].reactionCheck.value = false;
//
//
//                           var response = await controller.likeComment(
//                               post.comments[index].id,
//                               post.comments[index].reactionType.value
//                           );
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value =
//                           "simple_like";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                       },
//
//
//                       child: Image.asset(
//                         AppImages.like,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//                     ///love
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//                         if (post.comments[index].reactionType.value == 'love') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "cry" ||
//                             post.comments[index].reactionType.value ==
//                                 "excited" ||
//                             post.comments[index].reactionType.value ==
//                                 "lough" ||
//                             post.comments[index].reactionType.value ==
//                                 "smile" ||
//                             post.comments[index].reactionType.value ==
//                                 "thanks") {
//                           print("kilo");
//                           post.comments[index].reactionType.value = "love";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "love";
//                           post.comments[index].reactionCheck.value = false;
//
//
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "love";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                       },
//                       child: Image.asset(
//                         AppImages.love,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//                     ///lough
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//                         if (post.comments[index].reactionType.value ==
//                             'lough') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "love" ||
//                             post.comments[index].reactionType.value == "cry" ||
//                             post.comments[index].reactionType.value ==
//                                 "excited" ||
//                             post.comments[index].reactionType.value ==
//                                 "smile" ||
//                             post.comments[index].reactionType.value ==
//                                 "thanks") {
//                           post.comments[index].reactionType.value = "lough";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "lough";
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//
//
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "lough";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                       },
//
//
//                       child: Image.asset(
//                         AppImages.lough,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//                     ///excited
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//                         if (post.comments[index].reactionType.value ==
//                             'excited') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 'lough' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "love" ||
//                             post.comments[index].reactionType.value == "cry" ||
//                             post.comments[index].reactionType.value ==
//                                 "smile" ||
//                             post.comments[index].reactionType.value ==
//                                 "thanks") {
//                           post.comments[index].reactionType.value = "excited";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "excited";
//                           post.comments[index].reactionCheck.value = false;
//
//
//                           if (post.comments[index].reactionType.value ==
//                               "simple_dislike" || post.comments[index]
//                               .reactionType.value == null) {
//                             post.comments[index].commentCount.value =
//                                 post.comments[index].commentCount.value + 1;
//                           }
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "excited";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//
//
//                         // controller.postIndex = index;
//                         // controller.update();
//
//
//                         controller.update();
//                       },
//
//
//                       child: Image.asset(
//                         AppImages.excited,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//
//                     ///thanks
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//                         if (post.comments[index].reactionType.value ==
//                             'thanks') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value ==
//                                 'excited' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 'lough' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "love" ||
//                             post.comments[index].reactionType.value == "cry" ||
//                             post.comments[index].reactionType.value ==
//                                 "smile") {
//                           post.comments[index].reactionType.value = "thanks";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "thanks";
//                           post.comments[index].reactionCheck.value = false;
//
//                           if (post.comments[index].reactionType.value ==
//                               "simple_dislike" || post.comments[index]
//                               .reactionType.value == null) {
//                             post.comments[index].commentCount.value =
//                                 post.comments[index].commentCount.value + 1;
//                           }
//
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "thanks";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                       },
//
//
//                       child: Image.asset(
//                         AppImages.thanks,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//
//                     ///cry
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//                         if (post.comments[index].reactionType.value == 'cry') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value ==
//                                 'thanks' ||
//                             post.comments[index].reactionType.value ==
//                                 'excited' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 'lough' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "love" ||
//                             post.comments[index].reactionType.value ==
//                                 "smile") {
//                           post.comments[index].reactionType.value = "cry";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "cry";
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//
//                           if (post.comments[index].reactionType.value ==
//                               "simple_dislike" || post.comments[index]
//                               .reactionType.value == null) {
//                             post.comments[index].commentCount.value =
//                                 post.comments[index].commentCount.value + 1;
//                           }
//
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "cry";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//
//
//                         controller.update();
//                       },
//                       child: Image.asset(
//                         AppImages.cry,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//                     ///smile
//                     GestureDetector(
//                       onTap: () async {
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike" || post.comments[index]
//                             .reactionType.value == null) {
//                           print("aasdasdasd");
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value + 1;
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             'smile') {
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                         }
//                         else if (post.comments[index].reactionType.value ==
//                             null ||
//                             post.comments[index].reactionType.value == 'cry' ||
//                             post.comments[index].reactionType.value ==
//                                 'thanks' ||
//                             post.comments[index].reactionType.value ==
//                                 'excited' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_dislike" ||
//                             post.comments[index].reactionType.value ==
//                                 'lough' ||
//                             post.comments[index].reactionType.value ==
//                                 "simple_like" ||
//                             post.comments[index].reactionType.value == "love") {
//                           post.comments[index].reactionType.value = "smile";
//                         }
//
//
//                         if (post.comments[index].reactionType.value ==
//                             "simple_dislike") {
//                           post.comments[index].commentCount.value = post
//                               .comments[index].commentCount.value - 1;
//                           post.comments[index].reactionType.value = "smile";
//                           post.comments[index].reactionCheck.value = false;
//
//                           if (post.comments[index].reactionType.value ==
//                               "simple_dislike" || post.comments[index]
//                               .reactionType.value == null) {
//                             post.comments[index].commentCount.value =
//                                 post.comments[index].commentCount.value + 1;
//                           }
//
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//
//                           post.comments[index].reactionType.value =
//                           "simple_dislike";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                         else {
//                           print("post.comments[index].reactionType.value ${post
//                               .comments[index].reactionType.value} ");
//                           post.comments[index].reactionCheck.value = false;
//                           var response = await controller.likeComment(post
//                               .comments[index].id,
//                               post.comments[index].reactionType.value);
//                           if (response) {
//                             print('djsdjsadjasjnnxjdsannsnsnsnsnsnsns');
//                             ;
//                           }
//                           post.comments[index].reactionType.value = "smile";
//                           controller.postIndex = index;
//                           controller.update();
//                         }
//                       },
//
//                       child: Image.asset(
//                         AppImages.smile,
//                         height: 30.0,
//                         width: 30.0,
//                       ),
//                     ),
//                     SizedBox(width: 5),
//
//
//                   ],
//                 ),
//               ),
//
//             ) : SizedBox()
//           ;
//         })
//       ],
//     );
//   }
//
//   dynamic buildSimpleCommentField(NewsfeedController controlle,
//       BuildContext context, Post post, index) {
//     return Obx(() {
//       return post.comments[index].isReply.value
//           ? ReplyToComment(
//           controller, post.postId, post.comments[index].id, post, index)
//       // ListTile(
//       //         contentPadding: EdgeInsets.symmetric(horizontal: 0),
//       //         title: Container(
//       //           child: Row(
//       //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       //             children: [
//       //               CircleAvatar(
//       //                 radius: 12,
//       //                 backgroundImage: AssetImage('assets/images/image.jpg'),
//       //               ),
//       //               SizedBox(
//       //                 width: 12,
//       //               ),
//       //               Expanded(
//       //                 child: Container(
//       //                   height: 50,
//       //                   child: HashTagTextField(
//       //                     controller: controller.commentTextController,
//       //                     textAlignVertical: TextAlignVertical.bottom,
//       //                     decoratedStyle: TextStyle(fontSize: 16, color: Colors.blue),
//       //                     decoration: InputDecoration(
//       //                       hintText: Strings.replyToComment,
//       //                       border: OutlineInputBorder(
//       //                         borderRadius: BorderRadius.circular(40),
//       //                       ),
//       //                       enabledBorder: OutlineInputBorder(
//       //                         borderRadius: BorderRadius.circular(40),
//       //                         borderSide: BorderSide(
//       //                           width: 0,
//       //                           style: BorderStyle.none,
//       //                         ),
//       //                       ),
//       //                       fillColor: Colors.grey[100],
//       //                       filled: true,
//       //                     ),
//       //                     onChanged: (value) {
//       //                       if (controller.commentTextController.text.length > 0)
//       //                         controller.postText = true;
//       //                       else controller.postText = false;
//       //                     },
//       //                   ),
//       //                 ),
//       //               ),
//       //             ],
//       //           ),
//       //         ),
//       //         subtitle: Padding(
//       //           padding: const EdgeInsets.only(top: 12.0, left: 32, bottom: 4),
//       //           child: Row(
//       //             children: [
//       //               ElevatedButton(
//       //                 style: ButtonStyle(
//       //                   padding: MaterialStateProperty.all(
//       //                     EdgeInsets.symmetric(
//       //                       horizontal: 40,
//       //                       vertical: 10,
//       //                     ),
//       //                   ),
//       //                   shape: MaterialStateProperty.all(
//       //                     RoundedRectangleBorder(
//       //                       borderRadius: BorderRadius.circular(40),
//       //                     ),
//       //                   ),
//       //                   backgroundColor: MaterialStateProperty.all(
//       //                     Theme.of(context).primaryColor,
//       //                   ),
//       //                 ),
//       //                 onPressed: () async {
//       //                   if (controller.commentTextController.text.isNotEmpty) {
//       //                     await controller.createComment(
//       //                       controller.commentTextController.text,
//       //                       post.postId,
//       //                       commentId: post.comments[index].id,
//       //                     );
//       //                     controller.commentTextController.clear();
//       //
//       //                     controller.isReplyComment = false;
//       //
//       //                     controller.update();
//       //                     controller.postList = [];
//       //                     controller.isLoading = true;
//       //                     controller.update();
//       //
//       //                     controller.postList = await controller.getNewsFeed();
//       //                     controller.isLoading = false;
//       //                     controller.update();
//       //                   }
//       //                 },
//       //                 child: Text(Strings.post),
//       //               ),
//       //               SizedBox(width: 12),
//       //               InkWell(
//       //                   onTap: () {
//       //                     controller.isReplyComment = false;
//       //                     controller.update();
//       //                   },
//       //                   child: Text(Strings.cancel)),
//       //               controller.postText ? controller.urlOrNot(controller.commentTextController.text) ?
//       //               Container(child: urlFetch(controller),) : Container() : Container(),
//       //             ],
//       //           ),
//       //         ),
//       //       )
//           : Container();
//     });
//   }
//
//   Widget myPopMenu(BuildContext context, Post post,
//       int commmentid, NewsfeedController controller, int index) {
//     return Align(
//         alignment: Alignment.topRight,
//         child: PopupMenuButton(
//
//             initialValue: 1,
//             padding: EdgeInsets.zero,
//             icon: Icon(
//               Icons.more_horiz,
//               size: kIsWeb ? 30 : 22,
//               color: Colors.grey,
//             ),
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(5),
//             ),
//             color: Colors.white,
//             // Callback that sets the selected popup menu item.
//             onSelected: (value) async {
//               await controller.HideUnHideReplay(commentId: commmentid);
//
//               print("hello aya hai");
//
//               if (!kIsWeb) {
//                 controller.selectedPost2 = await controller.getSingleNewsFeedItem(
//                     post.postId, isReload: true);
//                 controller.update();
//                 mobileCommentsController.update();
//               }
//               else {
//                 controller.selectedPost2 =
//                 await controller.getSingleNewsFeedItem(post.postId);
//               }
//               Fluttertoast.showToast(
//                   msg: "Reply Hidden from Werf",
//                   toastLength:
//                   Toast.LENGTH_SHORT,
//                   gravity: ToastGravity.CENTER,
//                   timeInSecForIosWeb: 2,
//                   backgroundColor: Colors.red,
//                   textColor: Colors.white,
//                   fontSize: 16.0);
//
//               // post.comments.forEach((element) {
//               //
//               //   if(element == commmentid)
//               //   {
//               //     post.comments.remove(element);
//               //
//               //
//               //   }
//               //
//               //
//               //
//               //
//               //
//               //   setState(() {
//               //
//               //   });
//               //
//               //
//               //
//               //
//               // });
//
//             },
//             itemBuilder: (BuildContext context) =>
//             [
//               PopupMenuItem(
//                 value: 1,
//                 child: Text(
//                   'Hide Reply',
//                   // style: TextStyle(
//                   //   fontSize: 15,
//                   // ),
//                   style:
//                   TextStyle(color: Colors.black,
//                       fontWeight: FontWeight.w700,
//                       fontSize: 12
//
//                   ),
//                 ),
//               ),
//
//             ]
//         ));
//   }
// }

//
// class ReplyToComment extends StatefulWidget {
//   final NewsfeedController controller;
//   int postId;
//   Post post;
//   int postComentId;
//   int index;
//
//   ReplyToComment(this.controller, this.postId, this.postComentId, this.post,
//       this.index);
//
//   @override
//   _ReplyToCommentState createState() => _ReplyToCommentState();
// }

// class _ReplyToCommentState extends State<ReplyToComment> {
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       contentPadding: EdgeInsets.symmetric(horizontal: 0),
//       title: Container(
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             widget.controller.userProfile == null
//                 ? Container(
//                 width: 24,
//                 child: Center(
//                   child: SpinKitCircle(
//                     color: Colors.grey,
//                     size: 40,
//                   ),
//                 ))
//                 : widget.controller.userProfile.profileImage == null
//                 ? CircleAvatar(
//                 radius: 12,
//                 backgroundImage:
//                 AssetImage("assets/images/person_placeholder.png"))
//                 : ClipRRect(
//               borderRadius: BorderRadius.circular(40),
//               child: FadeInImage(
//                   fit: BoxFit.cover,
//                   width: 24,
//                   height: 24,
//                   placeholder: AssetImage(
//                       'assets/images/person_placeholder.png'),
//                   image: NetworkImage(widget
//                       .controller.userProfile.coverImage !=
//                       null
//                       ? widget.controller.userProfile.profileImage
//                       : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png")),
//             ),
//             SizedBox(
//               width: 12,
//             ),
//             Expanded(
//               child: Container(
//                 height: 50,
//                 child: HashTagTextField(
//                   key: Key(widget.postComentId.toString()),
//                   basicStyle: LightStyles.baseTextTheme.headline2.copyWith(
//                       color: Theme
//                           .of(context)
//                           .brightness == Brightness.dark
//                           ? Colors.white
//                           : Colors.black
//                   ),
//                   cursorColor: Theme
//                       .of(context)
//                       .brightness == Brightness.dark ? Colors.white : Colors
//                       .black,
//                   controller: widget.controller.ReplyCommentController,
//                   textAlignVertical: TextAlignVertical.bottom,
//                   decoratedStyle: LightStyles.baseTextTheme.headline2.copyWith(
//                     color: Colors.blue,
//                   ),
//                   decoration: InputDecoration(
//                     hintText: Strings.replyToComment,
//                     hintStyle: LightStyles.baseTextTheme.headline3,
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(40),
//                       borderSide: BorderSide(color: Colors.grey, width: 1),
//                     ),
//                     enabledBorder: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(40),
//                       borderSide: BorderSide(
//                         width: 0,
//                         style: BorderStyle.none,
//                       ),
//                     ),
//                     fillColor: Colors.grey[250],
//                     filled: true,
//                   ),
//
//
//                   onChanged: (value) async {
//                     // if (widget.controller.ReplyCommentController.text.length >
//                     //     0)
//                     //   setState(() {
//                     //     widget.controller.postText = true;
//                     //   });
//                     // else
//                     //   setState(() {
//                     //     widget.controller.postText = false;
//                     //   });
//
//
//                     widget.controller.replyTempValue = value;
//                     print('change value $value');
//                     // print(getHashTags(value));
//
//
//                     // if (value.length > 0 && widget.commentTextController.text.trim().isNotEmpty)
//
//
//                     if (value.length < 2) {
//                       /// user tag and mention tag
//                       widget.controller.replyMentionUser = false;
//
//                       widget.post.comments[widget.index].replyMentionTag.value = false;
//                       // widget.controller.replyMentionTag[widget.index] = false;
//                       widget.controller.replyTemp = '';
//                       widget.controller.replyTempUsername = '';
//                       widget.controller.replyTags.clear();
//
//                       /// end
//                       // visibility = true;
//
//                       widget.controller.update();
//                       // setState(() {});
//                     }
//
//                     /// user # tag and @ mention user
//                     if (value.length >
//                         0) {
//                       int tempLength = 0;
//                       //  temp='';
//                       // tempUsername = '';
//                       ///hash tag
//                       if (value[value
//                           .length -
//                           1] ==
//                           '#') {
//                         // temp = '';
//                         print(
//                             'if  ${value[value.length - 1]}');
//                         widget.controller.replyTemp = value[
//                         value.length -
//                             1];
//                         print('1  # : ' +
//                             widget.controller.replyTemp);
//                       } else if (widget.controller.replyTemp !=
//                           '' &&
//                           value[value.length -
//                               1] !=
//                               ' ') {
//                         // temp = '';
//                         print(
//                             'if else value ${value[value.length - 1]}');
//
//                         widget.controller.replyTemp =
//                             widget.controller.replyTemp +
//                                 value[value
//                                     .length -
//                                     1];
//                         print('2  # : ' +
//                             widget.controller.replyTemp);
//                       } else if (value[
//                       value.length -
//                           1] ==
//                           ' ') {
//                         print('3   # :' +
//                             widget.controller.replyTemp);
//                         widget.controller.replyTemp = '';
//                         widget.controller.replyMentionUser =
//                         false;
//
//                         widget.post.comments[widget.index].replyMentionTag.value = false;
//                         // widget.controller.replyMentionTag[widget.index] =
//                         // false;
//                       }
//                       if (widget.controller.replyTemp.length > 1) {
//                         print('temp value # : ' + widget.controller.replyTemp);
//                         widget.controller.replyTags.clear();
//                         print('hashtag temp value :${widget.controller
//                             .replyTemp}');
//
//                         widget.controller.replyTags =
//                         await widget.controller.searchTags(widget.controller
//                             .replyTemp.substring(1));
//                         //  await   print('hastag api value:${widget.tags}');
//                         if (widget.controller.replyTags[0] == false) {
//                           widget.controller.replyTags.clear();
//                           widget.post.comments[widget.index].replyMentionTag.value = false;
//                           // widget.controller.replyMentionTag[widget.index] =
//                           // false;
//                           //  temp='';
//                           widget.controller.update();
//                         } else {
//                           // widget.controller.mentionUser =
//                           // false;
//
//                           widget.post.comments[widget.index].replyMentionTag.value = true;
//                           // widget.controller.replyMentionTag[widget.index] =
//                           // true;
//                           widget.controller.update();
//                         }
//                       }
//                       print(
//                           "temp store value#: ${widget.controller.replyTemp}");
//
//                       /// @ mention user
//                       /*   if (value[value
//                           .length -
//                           1] ==
//                           '@') {
//                         widget.controller. mentionUser =
//                         false;
//                         widget.controller.update();
//                         widget.controller.tempUsername =
//                             widget.controller. tempUsername +
//                                 value[value
//                                     .length -
//                                     1];
//                         print('1   @: ' +
//                             widget.controller.tempUsername);
//                       } else if (widget.controller.tempUsername !=
//                           '' &&
//                           value[value.length -
//                               1] !=
//                               ' ') {
//                         widget.controller.tempUsername =
//                             widget.controller.tempUsername +
//                                 value[value
//                                     .length -
//                                     1];
//                         print('2  @ : ' +
//                             widget.controller. tempUsername);
//                       } else if (value[
//                       value.length -
//                           1] ==
//                           ' ') {
//                         print('3   @ :' +
//                             widget.controller. tempUsername);
//                         widget.controller. tempUsername = '';
//                         widget.controller.mentionUser =
//                         false;
//                         widget.controller. mentionTag =
//                         false;
//                       }
//                       if (widget.controller.tempUsername
//                           .length >
//                           1) {
//                         print('temp value @ : ' +
//                             widget.controller.tempUsername);
//
//                         widget.controller. users.clear();
//                         widget.controller. users =
//                             await widget
//                             .controller
//                             .searchChatUser(
//                               widget.controller. tempUsername
//                               .substring(
//                               1),
//                         );
//                         if (widget.controller.users[
//                         0] ==
//                             false) {
//                           widget.controller. users
//                               .clear();
//                           widget.controller.mentionUser =
//                           false;
//                           widget.controller.update();
//                           // setState(() {});
//                         } else {
//                           widget.controller.  mentionUser =
//                           true;
//                           widget.controller.update();
//                           // setState(() {});
//                         }
//                       }*/
//                       // _controller[controller.currentIndexText].text=selectedHashTag;
//                       ///
//                     }
//                   },
//
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//       subtitle: Padding(
//         padding: const EdgeInsets.only(top: 12.0, left: 40, bottom: 4),
//         child: Row(
//           children: [
//             ElevatedButton(
//               style: ButtonStyle(
//                 padding: MaterialStateProperty.all(
//                   EdgeInsets.symmetric(
//                     horizontal: 40,
//                     vertical: 10,
//                   ),
//                 ),
//                 shape: MaterialStateProperty.all(
//                   RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(40),
//                   ),
//                 ),
//                 backgroundColor: MaterialStateProperty.all(
//                   widget.controller.displayColor,
//                 ),
//               ),
//               onPressed: () async {
//                 if (widget.controller.ReplyCommentController.text.isNotEmpty) {
//                   Get
//                       .find<NewsfeedController>()
//                       .isPostDetails = true;
//
//                   Get.find<NewsfeedController>().update();
//
//
//                   widget.controller.createDeleteComment(
//                       widget.post.postId,
//                       widget.controller.userProfile.profileImage,
//                       widget.controller.ReplyCommentController.text,
//                       "create", {
//                     'audio_file_url': null,
//                     'audio_path': null,
//                     'author': {
//                       'id': widget.controller.storage.read('id'),
//                       'firstname': widget.controller.userProfile.firstname,
//                       'lastname': widget.controller.userProfile.lastname,
//                       'profile_image': widget.controller.userProfile == null
//                           ? "assets/images/person_placeholder.png"
//                           : widget.controller.userProfile.profileImage == null
//                           ? "assets/images/person_placeholder.png"
//                           : widget.controller.userProfile.profileImage,
//                       'username': widget.controller.userName,
//                     },
//                     'body': widget.controller.ReplyCommentController.text,
//                     'id': null,
//                     'isLiked': false,
//                     'postId': widget.post.postId,
//                     'replies': [],
//                     'repliesCount': 0,
//                     'user_id': widget.controller.userProfile,
//                     'commented_time_ago': "Just Now",
//                     'created_at': null,
//                     'in_reply_to_id': widget.postComentId,
//                     'language_id': widget.post.languageId,
//                     'link': null,
//                     'link_image': null,
//                     'link_meta': null,
//                     'link_title': null,
//                     'post_type_id': null,
//                     'processing_status': null,
//                     'simple_dislike_count': 0,
//                     'simple_like_count': 0,
//                     'speech_to_text': null,
//                     'status': null,
//                     'updated_at': null,
//                   });
//
//                   var response = await widget.controller.createComment(
//                     widget.controller.ReplyCommentController.text,
//                     widget.post,
//                     commentId: widget.postComentId,
//                   );
//                   if (response['meta']['code'] == 200) {
//                     print("hello world comment");
//                     widget.controller.ReplyCommentController.clear();
//                     widget.controller.selectedPost2 =
//                     await widget.controller.getSingleNewsFeedItem(
//                         widget.post.postId, commentCheck: false);
//                     widget.controller.update();
//
//                     widget.controller.isReplyComment = false;
//
//                     // widget.controller.createDeleteComment(
//                     //     widget.post.postId,
//                     //     widget.controller.userProfile.profileImage,
//                     //     widget.controller.commentTextController.text,
//                     //     "create", {
//                     //   'audio_file_url': null,
//                     //   'audio_path': null,
//                     //   'author': {
//                     //     'id': widget.controller.storage.read('id'),
//                     //     'firstname': widget.controller.userProfile.firstname,
//                     //     'lastname': widget.controller.userProfile.lastname,
//                     //     'profile_image': widget.controller.userProfile == null
//                     //         ? "assets/images/person_placeholder.png"
//                     //         : widget.controller.userProfile.profileImage == null
//                     //             ? "assets/images/person_placeholder.png"
//                     //             : widget.controller.userProfile.profileImage,
//                     //     'username': widget.controller.userName,
//                     //   },
//                     //   'body': response["data"]["body"],
//                     //   'id': response["data"]["id"],
//                     //   'isLiked': false,
//                     //   'postId': response["data"]["post_id"],
//                     //   'replies': [],
//                     //   'repliesCount': 0,
//                     //   'user_id': response["data"]["user_id"],
//                     //   'commented_time_ago': response["data"]
//                     //       ["commented_time_ago"],
//                     //   'created_at': response["data"]["created_at"],
//                     //   'in_reply_to_id': response["data"]["in_reply_to_id"],
//                     //   'language_id': response["data"]["language_id"],
//                     //   'link': null,
//                     //   'link_image': null,
//                     //   'link_meta': null,
//                     //   'link_title': null,
//                     //   'post_type_id': response["data"]["post_type_id"],
//                     //   'processing_status': null,
//                     //   'simple_dislike_count': 0,
//                     //   'simple_like_count': 0,
//                     //   'speech_to_text': null,
//                     //   'status': null,
//                     //   'updated_at': response["data"]["updated_at"],
//                     // });
//
//                     // widget.controller.postList = await widget.controller.getNewsFeed();
//                     // widget.controller.update();
//                   }
//
//                   // widget.controller.update();
//                   // widget.controller.postList = [];
//                   // widget.controller.isLoading = true;
//                   // widget.controller.update();
//                   //
//                   // widget.controller.postList = await widget.controller.getNewsFeed();
//                   // widget.controller.isLoading = false;
//                   // widget.controller.update();
//                 }
//               },
//               child: Text(Strings.post,
//                   style: Styles.baseTextTheme.headline2.copyWith(
//                     color: Colors.white,
//                     fontSize: 14,
//                   )
//               ),
//             ),
//             SizedBox(width: 20),
//             InkWell(
//                 onTap: () {
//                   widget.controller.isReplyComment = false;
//                   widget.controller.update();
//                 },
//                 child: Text(
//
//                     Strings.cancel,
//                     style: Styles.baseTextTheme.headline2.copyWith(
//                       color: Theme
//                           .of(context)
//                           .brightness == Brightness.dark
//                           ? Colors.white
//                           : Colors.black,
//                       fontSize: 14,
//                     ))),
//             SizedBox(width: 60),
//             widget.controller.postText
//                 ? widget.controller
//                 .urlOrNot(widget.controller.ReplyCommentController.text)
//                 ? Container(
//               child: Expanded(child: urlFetch(widget.controller)),
//             )
//                 : Container()
//                 : Container(),
//           ],
//         ),
//       ),
//     );
//   }
// }

Widget urlFetch(NewsfeedController controller) {
  // if(widget.controller.scrapUrl.contains('.com')){
  //   return
  return FutureBuilder<ScrappingData>(
    future: controller.urlScraping(controller.scrapUrl),
    builder: (context, snapshot) {
      if (snapshot.hasData) {
        return cardScrap(context, snapshot.data);
      } else if (snapshot.hasError) {
        print(snapshot.error.toString());
        return Container();
      }
      return Container(
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    },
  );

  // }else{
  //   return Container();
  // }
}

Widget cardScrap(BuildContext context, ScrappingData data) {
  // _validURL = true;
  if (data.title != '429 Too Many Requests') {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: GestureDetector(
        onTap: () {
          // Get.to(MenuListPage(
          //   restaurantId: id,
          // ));
        },
        child: Expanded(
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(5.0)),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.all(
                Radius.circular(5.0),
              ),
              child: Container(
                height: 80,
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 0),
                      child: Container(
                        height: 80,
                        width: 80,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(0.0),
                            image: DecorationImage(
                                image: data.images[0] != null
                                    ? NetworkImage(data.images[0].toString())
                                    : AssetImage(
                                        "assets/images/person_placeholder.png"),
                                fit: BoxFit.cover)),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding:
                                  const EdgeInsets.only(right: 8.0, top: 8.0),
                              child: InkWell(
                                onTap: () {},
                                child: SizedBox(
                                  height: 4,
                                  child: Align(
                                      alignment: Alignment.topRight,
                                      child: Icon(Icons.cancel)),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 8.00),
                              child: SizedBox(
                                height: 20,
                                child: Text(data.title.toString(),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 17,
                                    //   fontWeight: FontWeight.w500,
                                    // )
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 17,
                                            fontFamily: 'Cairo',
                                          )
                                        : TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 17,
                                            fontFamily: 'Cairo',
                                          )),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 8.00),
                              child: SizedBox(
                                height: 18,
                                child: Text(data.meta.toString(),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            fontFamily: 'Cairo',
                                          )
                                        : TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                            fontFamily: 'Cairo',
                                          )),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 8.00),
                              child: SizedBox(
                                height: 18,
                                child: Text(data.link.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context).brightness ==
                                            Brightness.dark
                                        ? TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            fontFamily: 'Cairo',
                                          )
                                        : TextStyle(
                                            color: Colors.grey[700],
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14,
                                            fontFamily: 'Cairo',
                                          )),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  } else {
    return Container();
  }
}
