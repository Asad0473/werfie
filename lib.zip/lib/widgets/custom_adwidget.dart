import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/services/ad_helper.dart';

class CustomAdWidget extends StatefulWidget {
  BannerAd ad;

  CustomAdWidget({this.ad});

  @override
  _CustomAdWidgetState createState() => _CustomAdWidgetState();
}

class _CustomAdWidgetState extends State<CustomAdWidget> {
  BannerAd _ad;
  String text;
  AdHelper _adHelper = AdHelper();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // print('INSIDE CUSTOM AD WIDGET INIT');
    _ad = BannerAd(
      adUnitId: AdHelper.bannerAdUnitId,
      size: AdSize.mediumRectangle,
      // factoryId: 'listTile',
      request: AdRequest(),

      listener: _adHelper.adListener,
    )
      ..load();
    // setState(() {});
    //   // controller.isAdLoaded = false;
    //   // controller.update();
    //   // super.didChangeDependencies();
    //   if (_ad != null) {
    //     _ad.dispose();
    //   }
    //   print('Inside dependecy state ');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: AdWidget(
        ad: _ad,
      ),
      height: 300.0,
      alignment: Alignment.center,
    );
  }
}
