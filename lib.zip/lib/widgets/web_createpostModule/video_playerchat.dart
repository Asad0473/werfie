import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoPlayerChat extends StatefulWidget {
  const VideoPlayerChat({Key key, this.videoUrl}) : super(key: key);
  final String videoUrl;

  @override
  State<VideoPlayerChat> createState() => _VideoPlayerChatState();
}

class _VideoPlayerChatState extends State<VideoPlayerChat> {
  VideoPlayerController _controller;
  ChewieController _chewieController;

  @override
  void initState() {
    _initControllers();
    super.initState();
  }

  void _initControllers() {
    _controller = VideoPlayerController.network(
      widget.videoUrl,
    )..initialize().then((value) {
        setState(() {});
      });
    _chewieController = ChewieController(
      looping: true,
      videoPlayerController: _controller,
      showOptions: false,
      allowFullScreen: false,
      allowMuting: false,
      // deviceOrientationsAfterFullScreen: [DeviceOrientation.portraitUp],
      materialProgressColors: ChewieProgressColors(
          backgroundColor: Colors.grey,
          bufferedColor: Colors.grey,
          playedColor: Colors.white),
      cupertinoProgressColors: ChewieProgressColors(
          backgroundColor: Colors.grey,
          bufferedColor: Colors.grey,
          playedColor: Colors.white),
      placeholder: AspectRatio(
          aspectRatio: 16 / 15,
          child: Container(decoration: BoxDecoration(color: Colors.black))),
    );

    // _videoController.addListener(reInitVideoManager);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.all(Radius.circular(15)),
      child: AspectRatio(
        aspectRatio: 16 / 15,
        child: _controller.value.isInitialized
            ? Chewie(controller: _chewieController)
            : Container(),
      ),
    );
  }
}
