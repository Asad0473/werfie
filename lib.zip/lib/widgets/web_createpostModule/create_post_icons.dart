import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../sign_in_sign_up_widget/custom_image_view.dart';

class CreatePostIcons extends StatelessWidget {
  const CreatePostIcons(this.image, this.onTap,
      {Key key, this.width = 23, this.height = 23, this.opacity = 1}) : super(key: key);

  final String image;
  final Function onTap;
  final double width;
  final double height;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.only(right: 12),
        child: CustomImageShow(
          width: width,
          imagePath: image,
          height: height,

        )


        ,
      ),
    );
  }
}
