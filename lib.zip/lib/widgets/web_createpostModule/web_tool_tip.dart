import 'package:flutter/material.dart';

class WebToolTipShow extends StatefulWidget {
  final String text;
 final Widget child;
 final Widget withOutTipChild;
  final Function onTap;
  final double opacity;
  const WebToolTipShow({Key key,this.text,this.child,this.withOutTipChild ,this.onTap, this.opacity}) : super(key: key);

  @override
  State<WebToolTipShow> createState() => _WebToolTipShowState();
}

class _WebToolTipShowState extends State<WebToolTipShow> {
 bool showToolTip =false;
  @override
  Widget build(BuildContext context) {
    return   MouseRegion(
      onEnter:(val){
        setState(() {
          showToolTip=true;
        });

      },

      onExit: (val){
        setState(() {
          showToolTip=false;
        });

      },

      onHover: (val){
        setState(() {
          showToolTip=true;
        });
      },

      child:
      showToolTip==true?
      Tooltip(
        message: widget.text,
        child: GestureDetector(
            onTap: widget.onTap,
            child: widget.child),
      ):widget.withOutTipChild


    );
  }
}
