// import 'dart:html' as html;
// import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_widget_from_html_core/flutter_widget_from_html_core.dart';

class CustomAdWidgetWeb extends StatefulWidget {
  const CustomAdWidgetWeb({Key key}) : super(key: key);

  @override
  _CustomAdWidgetWebState createState() => _CustomAdWidgetWebState();
}

class _CustomAdWidgetWebState extends State<CustomAdWidgetWeb> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Future<String> loadHtml() async {
    final String content = await rootBundle.loadString('assets/adview.html');
    return content;
  }

  @override
  Widget build(BuildContext context) {
    // ignore: undefined_prefixed_name
    // loadHtml();
    //    ui.platformViewRegistry.registerViewFactory(
    //        'rectangle',
    //            (int viewID) => html.IFrameElement()
    //          ..width = '320'
    //          ..height = '100'
    //          ..src = 'assets/assets/adview.html'
    //          ..style.border = 'none');

    return SizedBox(
      height: 0.0,
      width: 0.0,
      child: HtmlWidget(
        '''
        <div id='div-gpt-ad-1711005130989-0' style='min-width: 480px; min-height: 320px;'>
        <script>
        googletag.cmd.push(function() { googletag.display('div-gpt-ad-1711005130989-0'); });
        </script>
        </div>
    ''',
        onErrorBuilder: (context, element, dynamic) {
          return const Text(
            "Unable to load Ad",
            style: TextStyle(color: Colors.black),
          );
        },
        onLoadingBuilder: (context, element, double) {
          return const CircularProgressIndicator();
        },
      ),
    );
  }
}
