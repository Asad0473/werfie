import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:get/get.dart';
import 'package:werfieapp/utils/app_languages.dart';
import 'package:werfieapp/utils/colors.dart';
import '../../network/controller/news_feed_controller.dart';

class TextToSpeechWidget extends StatefulWidget {
  String text;
  int languageId;

  TextToSpeechWidget({
    Key key,
    this.text,
    this.languageId,
  }) : super(key: key);

  @override
  State<TextToSpeechWidget> createState() => _TextToSpeechWidgetState(
        newVoiceText: text,
        languageId: languageId,
      );
}

class _TextToSpeechWidgetState extends State<TextToSpeechWidget> {
  FlutterTts flutterTts;
  String language;
  String engine;
  double volume = 1.0;
  double pitch = 1.0;
  double rate = kIsWeb ? 1.0 : 0.5;
  bool isCurrentLanguageInstalled = false;

  String newVoiceText;
  int _inputLength;

  bool get isIOS => !kIsWeb && Platform.isIOS;

  bool get isAndroid => !kIsWeb && Platform.isAndroid;

  bool get isWindows => !kIsWeb && Platform.isWindows;

  bool get isWeb => kIsWeb;

  bool isPlay = false;
  int languageId;

  List<Map<String, dynamic>> languageList = [
    {
      "id": 1,
      "name": "English",
      "code": "en",
    },
    {
      "id": 2,
      "name": "Arabic",
      "code": "ar",
    },
    {
      "id": 3,
      "name": "French",
      "code": "fr",
    },
    {
      "id": 4,
      "name": "German",
      "code": "de",
    },
    {
      "id": 5,
      "name": "Italian",
      "code": "it",
    },
    {
      "id": 6,
      "name": "Japanese",
      "code": "ja",
    },
    {
      "id": 7,
      "name": "Russian",
      "code": "ru",
    },
    {
      "id": 8,
      "name": "Spanish",
      "code": "es",
    },
    {
      "id": 9,
      "name": "Hindi",
      "code": "hi",
    },
    {
      "id": 10,
      "name": "Czech",
      "code": "cs",
    },
    {
      "id": 11,
      "name": "Danish",
      "code": "da",
    },
    {
      "id": 12,
      "name": "Dutch",
      "code": "nl",
    },
    {
      "id": 13,
      "name": "Filipino",
      "code": "fil",
    },
    {
      "id": 14,
      "name": "Finnish",
      "code": "fi",
    },
    {
      "id": 15,
      "name": "Greek",
      "code": "el",
    },
    {
      "id": 16,
      "name": "Hungarian",
      "code": "hu",
    },
    {
      "id": 17,
      "name": "Indonesian",
      "code": "id",
    },
    {
      "id": 18,
      "name": "Korean",
      "code": "ko",
    },
    {
      "id": 19,
      "name": "Polish",
      "code": "pl",
    },
    {
      "id": 20,
      "name": "Portuguese",
      "code": "pt",
    },
    {
      "id": 21,
      "name": "Slovak",
      "code": "sk",
    },
    {
      "id": 22,
      "name": "Swedish",
      "code": "sv",
    },
    {
      "id": 23,
      "name": "Turkish",
      "code": "tr",
    },
    {
      "id": 24,
      "name": "Ukrainian",
      "code": "uk",
    },
    {
      "id": 25,
      "name": "Vietnamese",
      "code": "vi",
    },
    {
      "id": 26,
      "name": "Chinese",
      "code": "zh",
    },
    {
      "id": 27,
      "name": "Somali",
      "code": "so",
    },
    {
      "id": 28,
      "name": "Persian",
      "code": "fa",
    },
    {
      "id": 29,
      "name": "Urdu",
      "code": "ur",
    },
  ];

  final NewsfeedController newsfeedController = Get.find<NewsfeedController>();

  _TextToSpeechWidgetState({this.newVoiceText, this.languageId});

  @override
  void initState() {
    initTts();

    super.initState();
  }

  @override
  void didUpdateWidget(covariant TextToSpeechWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    languageId = widget.languageId;
    newVoiceText = widget.text;

    return newVoiceText != null && newVoiceText.isNotEmpty
        ? InkWell(
            onTap: () {
              if (isPlay) {
                flutterTts.stop();
                isPlay = false;
              } else {
                _speak();
              }
            },
            child: Container(
              padding: const EdgeInsets.only(left: 5,),
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.volume_up_outlined,
                    color: MyColors.werfieBlue,
                    size: 17,
                  ),
                  const SizedBox(
                    width: 2,
                  ),
                  Text(
                    "Listen",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12,
                        color: MyColors.werfieBlue,
                        fontWeight: FontWeight.normal),
                  ),
                ],
              ),
            ))
        : const SizedBox.shrink();
  }

  dynamic initTts() async {
    flutterTts = FlutterTts();
    //print(await _getLanguages());

    if (!kIsWeb && Platform.isIOS) {
      await flutterTts.setIosAudioCategory(
          IosTextToSpeechAudioCategory.playback,
          [
            IosTextToSpeechAudioCategoryOptions.allowBluetooth,
            IosTextToSpeechAudioCategoryOptions.allowBluetoothA2DP,
            IosTextToSpeechAudioCategoryOptions.mixWithOthers,
            IosTextToSpeechAudioCategoryOptions.defaultToSpeaker
          ],
          IosTextToSpeechAudioMode.defaultMode);
    }

    _setAwaitOptions();
    if (isAndroid) {
      _getDefaultEngine();
      _getDefaultVoice();
    }

    flutterTts.setStartHandler(() {
      setState(() {
        //print("Playing");
        //ttsState = TtsState.playing;
      });
    });

    flutterTts.setCompletionHandler(() {
      isPlay = false;
      /* setState(() {
        //print("Complete");
        //ttsState = TtsState.stopped;
        isPlay = false;
      });*/
    });

    flutterTts.setCancelHandler(() {
      setState(() {
        //print("Cancel");
        //ttsState = TtsState.stopped;
      });
    });

    flutterTts.setPauseHandler(() {
      setState(() {
        //print("Paused");
        //ttsState = TtsState.paused;
      });
    });

    flutterTts.setContinueHandler(() {
      setState(() {
        //print("Continued");
        //ttsState = TtsState.continued;
      });
    });

    flutterTts.setErrorHandler((msg) {
      setState(() {
        print("error: $msg");
        //ttsState = TtsState.stopped;
      });
    });
  }

  Future<dynamic> _getLanguages() async => await flutterTts.getLanguages;

  Future<dynamic> _getEngines() async => await flutterTts.getEngines;

  Future<void> _getDefaultEngine() async {
    var engine = await flutterTts.getDefaultEngine;
    if (engine != null) {
      //print(engine);
    }
  }

  Future<void> _getDefaultVoice() async {
    var voice = await flutterTts.getDefaultVoice;
    if (voice != null) {
      //print(voice);
    }
  }

  Future<void> _speak() async {
    String languageCode = languageList
        .firstWhere((element) => element['id'] == languageId)['code'];

    await flutterTts.setVolume(volume);
    await flutterTts.setSpeechRate(rate);
    await flutterTts.setPitch(pitch);
    await flutterTts.setLanguage(languageCode);
    if (newVoiceText != null) {
      if (newVoiceText.isNotEmpty) {
        isPlay = true;
        await flutterTts.speak(newVoiceText);
        isPlay = false;
      }
    }
  }

  Future<void> _setAwaitOptions() async {
    await flutterTts.awaitSpeakCompletion(true);
  }

  Future<void> _stop() async {
    var result = await flutterTts.stop();
    isPlay = false;
    //print(result);
    //if (result == 1) setState(() => ttsState = TtsState.stopped);
  }

  Future<void> _pause() async {
    var result = await flutterTts.pause();
    //if (result == 1) setState(() => ttsState = TtsState.paused);
  }

  @override
  void dispose() {
    super.dispose();
    flutterTts.stop();
  }
}
