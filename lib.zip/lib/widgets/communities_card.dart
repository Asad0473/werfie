import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/communities_controller.dart';

class CommunitiesCard extends StatelessWidget {
  CommunitiesCard({Key key, this.communitiesController, this.cardType})
      : super(key: key);
  final CommunitiesController communitiesController;

  String cardType;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).brightness == Brightness.dark
          ? Color(0xFF252526)
          : Color(0xFFfafafa),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      shadowColor: Colors.grey,
      elevation: 1.0,
      child: Container(
        width: 300,
        // decoration: BoxDecoration(
        //   color: Color(0xFFfafafa),
        //       borderRadius: BorderRadius.circular(10)
        // ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 150,
              width: 300,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10),
                      topLeft: Radius.circular(10)),
                  image: new DecorationImage(
                    image: new NetworkImage(
                        "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif"),
                    fit: BoxFit.fill,
                  )),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Row(
                children: [
                  CircleAvatar(
                    minRadius: 25,
                    backgroundImage: NetworkImage(
                      "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif",
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            "new group",
                            style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                          ),
                          Text(
                            "(Public)",
                            style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                          ),
                        ],
                      ),
                      Text(
                        "1 member",
                        style: TextStyle(
                            color:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                      ),
                    ],
                  )
                ],
              ),
            ),
            cardType == "joinCommunity"
                ? Padding(
                    padding: const EdgeInsets.only(left: 10, right: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        kIsWeb
                            ? Obx(() {
                                return Expanded(
                                  child: MouseRegion(
                                    onHover: (value) {
                                      communitiesController.hoverCheck.value =
                                          true;
                                    },
                                    onExit: (value) {
                                      communitiesController.hoverCheck.value =
                                          false;
                                    },
                                    child: MaterialButton(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Color(0xFF252526)
                                          : Colors.white,
                                      elevation: 0.0,

                                      onHighlightChanged: (bool value) {},
                                      hoverColor: Colors.red,
                                      // borderSide: const BorderSide(
                                      //   color: Colors.white,
                                      //   style: BorderStyle.solid,
                                      //   width: 1,
                                      // ),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(100.0),
                                          side: BorderSide(
                                              color: Colors.grey
                                                  .withOpacity(0.5))),

                                      onPressed: () {},
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 10),
                                        child: Text(
                                          "Leave Groups",
                                          style: TextStyle(
                                              color: communitiesController
                                                          .hoverCheck.value ==
                                                      false
                                                  ? Colors.red
                                                  : Colors.white,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              })
                            : Expanded(
                                child: MaterialButton(
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Color(0xFF252526)
                                      : Colors.white,
                                  elevation: 0.0,

                                  onHighlightChanged: (bool value) {},
                                  hoverColor: Colors.red,
                                  // borderSide: const BorderSide(
                                  //   color: Colors.white,
                                  //   style: BorderStyle.solid,
                                  //   width: 1,
                                  // ),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(100.0),
                                      side: BorderSide(
                                          color: Colors.grey.withOpacity(0.5))),

                                  onPressed: () {},
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        top: 10, bottom: 10),
                                    child: Text(
                                      "Leave Groups",
                                      style: TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              )
                      ],
                    ),
                  )
                : cardType == "SuggestedCommunity"
                    ? Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            kIsWeb
                                ? Obx(() {
                                    return Expanded(
                                      child: MouseRegion(
                                        onHover: (value) {
                                          communitiesController
                                              .hoverCheck.value = true;
                                        },
                                        onExit: (value) {
                                          communitiesController
                                              .hoverCheck.value = false;
                                        },
                                        child: MaterialButton(
                                          color: Theme.of(context).brightness ==
                                                  Brightness.dark
                                              ? Color(0xFF252526)
                                              : Colors.white,
                                          elevation: 0.0,

                                          onHighlightChanged: (bool value) {},
                                          hoverColor: Color(0xFF0157d3),
                                          // borderSide: const BorderSide(
                                          //   color: Colors.white,
                                          //   style: BorderStyle.solid,
                                          //   width: 1,
                                          // ),
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(100.0),
                                              side: BorderSide(
                                                  color: Colors.grey
                                                      .withOpacity(0.5))),

                                          onPressed: () {},
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                top: 10, bottom: 10),
                                            child: Text(
                                              "Join",
                                              style: TextStyle(
                                                  color: communitiesController
                                                              .hoverCheck
                                                              .value ==
                                                          false
                                                      ? Color(0xFF0157d3)
                                                      : Colors.white,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ),
                                      ),
                                    );
                                  })
                                : Expanded(
                                    child: MaterialButton(
                                      color: Theme.of(context).brightness ==
                                              Brightness.dark
                                          ? Color(0xFF252526)
                                          : Colors.white,
                                      elevation: 0.0,

                                      // borderSide: const BorderSide(
                                      //   color: Colors.white,
                                      //   style: BorderStyle.solid,
                                      //   width: 1,
                                      // ),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(100.0),
                                          side: BorderSide(
                                              color: Colors.grey
                                                  .withOpacity(0.5))),

                                      onPressed: () {},
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 10, bottom: 10),
                                        child: Text(
                                          "Join Group",
                                          style: TextStyle(
                                              color: Color(0xFF0157d3),
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                          ],
                        ),
                      )
                    : cardType == "YourGroup"
                        ? SizedBox()
                        : SizedBox(),
            SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}

class CategoriesCard extends StatelessWidget {
  CategoriesCard(
      {Key key,
      this.communitiesController,
      this.cardType,
      this.categoriesNames})
      : super(key: key);
  final CommunitiesController communitiesController;

  final String cardType;
  final String categoriesNames;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).brightness == Brightness.dark
          ? Color(0xFF252526)
          : Color(0xFFfafafa),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      shadowColor: Colors.grey,
      elevation: 1.0,
      child: Container(
        width: 200,
        // decoration: BoxDecoration(
        //   color: Color(0xFFfafafa),
        //       borderRadius: BorderRadius.circular(10)
        // ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: 150,
              width: 300,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(10),
                      topLeft: Radius.circular(10)),
                  image: new DecorationImage(
                    image: new NetworkImage(
                        "https://docs.flutter.dev/assets/images/dash/dash-fainting.gif"),
                    fit: BoxFit.fill,
                  )),
            ),
            Spacer(),
            Text(
              categoriesNames,
              style: TextStyle(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black),
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
