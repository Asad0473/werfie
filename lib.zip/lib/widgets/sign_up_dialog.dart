import 'dart:convert';

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/components/input_field.dart';
import 'package:werfieapp/components/input_password_field.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/models/GetCountriesResponse.dart' as cr;
import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/signup_controller.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_five.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_one.dart';
import 'package:werfieapp/screens/sign_up_mobile/sign_up_step_three.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';

import '../dummy_data.dart';
import '../network/controller/news_feed_controller.dart';
import '../network/controller/profile_controller.dart';
import '../network/singleTone.dart';
import '../screens/main_screen.dart';
import '../screens/sign_up_mobile/sign_up_step_four.dart';
import '../screens/sign_up_mobile/sign_up_step_two.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';

// ignore: must_be_immutable
class SignUpDialog extends StatefulWidget {
  LoginController controller;

  SignUpDialog({this.controller});

  static final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  State<SignUpDialog> createState() => _SignUpDialogState();
}

class _SignUpDialogState extends State<SignUpDialog> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SignupController>(builder: (signUpController) {
      return  getScreen(signUpController.currentStep);
    });
  }

  getScreen(int step){
    switch(step){
      case 1:
        return SignUpStepOne();
        break;
      case 2:
        return SignUpStepTwo();
        break;
      case 3:
        return SignUpStepThree();
        break;
      case 4:
        return SignUpStepFour();
        break;
      case 5:
        return SignUpStepFive();
        break;

    }
  }
}
