import 'package:chewie/chewie.dart';
import 'package:flick_video_player/flick_video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';
import 'package:werfieapp/models/post.dart';

import 'multi_manager/flick_multi_manager.dart';
import 'multi_manager/portrait_controls.dart';

class ChewieFeedVideoPlayer extends StatefulWidget {
  const ChewieFeedVideoPlayer({
    Key key,
    this.post,
    this.index,
    this.videoUrl,
    this.isAudio = false,
    this.aspectRatio,
    this.borderRadius = 12,
    this.allowFullScreen = true,
    this.isFullScreenOnMobile = false,
    this.thumbnailUrl,
    this.isQuoteWerfPlayer = false,
    this.quoteWerf,
  }) : super(key: key);

  final Post post;
  final QuoteWerf quoteWerf;
  final int index;
  final String videoUrl;
  final bool isAudio;
  final double aspectRatio;
  final double borderRadius;
  final bool isFullScreenOnMobile;
  final bool isQuoteWerfPlayer;
  final allowFullScreen;
  final thumbnailUrl;

  @override
  State<ChewieFeedVideoPlayer> createState() => _ChewieFeedVideoPlayerState();
}

class _ChewieFeedVideoPlayerState extends State<ChewieFeedVideoPlayer> {
  VideoPlayerController videoPlayerController;
  ChewieController chewieController;
  FlickManager flickManager;
  FlickMultiManager flickMultiManager;
  FlickControlManager control;
  String videoUrl;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    videoUrl = widget.isQuoteWerfPlayer
        ? widget.videoUrl != null
            ? widget.videoUrl
            : widget.quoteWerf.postFiles[widget.index]['file_path']
        : widget.videoUrl != null
            ? widget.videoUrl
            : widget.post.postFiles[widget.index]['file_path'];

    flickMultiManager = FlickMultiManager();

    flickManager = FlickManager(
      videoPlayerController: VideoPlayerController.network(videoUrl),
      autoPlay: false,
    );
    flickMultiManager.init(flickManager);

    // flickManager.flickControlManager.mute();

    // onVideoEnd: reInitVideoManager
  }

  void reInitVideoManager() {
    flickManager.flickVideoManager.videoPlayerController
        .seekTo(Duration(seconds: 0));
  }

  @override
  void dispose() {
    // print("dispose called");
    /* flickManager.flickControlManager.pause();
    flickManager.flickVideoManager.videoPlayerController.pause();
    flickManager.flickVideoManager.dispose();*/
    flickManager.dispose();

    // videoPlayerController.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.isAudio
        //audio player
        ? ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(aspectRatio: 16 / 9, child: Container()),
          )
        : ClipRRect(
            borderRadius: BorderRadius.circular(widget.borderRadius),
            child: widget.isFullScreenOnMobile
                ? VisibilityDetector(
                    key: ObjectKey(flickMultiManager),
                    onVisibilityChanged: (visibility) {
                      if (visibility.visibleFraction == 0 && this.mounted) {
                        // flickManager?.flickControlManager?.pause();//pausing  functionality
                        // flickManager.flickVideoManager.videoPlayerController.pause();
                        flickMultiManager.pause();
                      } else if (visibility.visibleFraction == 1) {
                        // flickManager.flickVideoManager.videoPlayerController.play();
                        flickMultiManager.play(flickManager);
                      }
                    },
                    child: AspectRatio(
                      aspectRatio: widget.aspectRatio == null
                          ? 16 / 9
                          : widget.aspectRatio,
                      child: Container(
                        child: FlickVideoPlayer(
                          flickManager: flickManager,
                          flickVideoWithControls: FlickVideoWithControls(
                            playerLoadingFallback: Positioned.fill(
                              child: Stack(
                                children: <Widget>[
                                  Positioned.fill(
                                    child: Image.network(
                                      "https://api.werfie.com/black_image.jpg",
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Positioned(
                                    right: 10,
                                    top: 10,
                                    child: Container(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        backgroundColor: Colors.white,
                                        strokeWidth: 4,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            controls: FeedPlayerPortraitControls(
                              flickMultiManager: flickMultiManager,
                              flickManager: flickManager,
                            ),
                          ),
                          flickVideoWithControlsFullscreen:
                              FlickVideoWithControls(
                            playerLoadingFallback: Center(
                                child: Image.network(
                              "https://api.werfie.com/black_image.jpg",
                              fit: BoxFit.fitWidth,
                            )),
                            controls: FlickLandscapeControls(),
                            iconThemeData: IconThemeData(
                              size: 40,
                              color: Colors.white,
                            ),
                            textStyle:
                                TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  )
                : SizedBox(),
          );
  }

  void playVideo() {
    if (kIsWeb) {
      if (chewieController != null) {
        if (!chewieController.isPlaying) {
          chewieController.play();
        }
      }
    } else {
      if (videoPlayerController != null) {
        videoPlayerController.play();
      }
    }
  }

  void pauseVideo() {
    if (kIsWeb) {
      if (chewieController != null) {
        if (chewieController.isPlaying) {
          chewieController.pause();
        }
      }
    } else {
      if (videoPlayerController != null) {
        videoPlayerController.pause();
      }
    }
  }
}
