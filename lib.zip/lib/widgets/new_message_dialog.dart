import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/font.dart';
import 'package:werfieapp/utils/strings.dart';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/widgets/blue_tick.dart';
import 'package:werfieapp/widgets/chat_screen_mobile.dart';

import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../web_views/web_main_screen.dart';

class NewMessageDialogBox extends StatelessWidget {
  NewMessageDialogBox(
      {this.isAddingMembersToChat = false, this.conversationId});

  final controller = Get.find<NewsfeedController>();
  final isAddingMembersToChat;
  final conversationId;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return SingleChildScrollView(
        child: StatefulBuilder(
          builder: (context, setState) {
            return Container(
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(.2),
                    spreadRadius: 0,
                    blurRadius: 0,
                    offset: Offset(0, 0), // changes position of shadow
                  ),
                ],
              ),
              width: kIsWeb ? 500 : MediaQuery.of(context).size.width * 0.9,
              height: kIsWeb ? 500 : MediaQuery.of(context).size.height * 0.6,
              child: !controller.isChatCreatedYet
                  ? Center(
                      child: CircularProgressIndicator(
                        color: Color(0xFFedab30),
                      ),
                    )
                  : Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: 12, right: 12, top: 12, bottom: 0),
                          child: Row(
                            //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              IconButton(
                                onPressed: () {
                                  Navigator.of(context).pop();

                                  controller.usersList.clear();
                                  controller.selectedPeople.clear();
                                  controller.idList.clear();

                                  controller.update();
                                },
                                icon: Icon(
                                  Icons.close,
                                  color: Theme.of(context).brightness ==
                                          Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              isAddingMembersToChat
                                  ? Text(
                                      Strings.addMembersToChat,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    )
                                  : Text(
                                      Strings.newChat,
                                      // style: TextStyle(
                                      //     fontWeight: FontWeight.bold),
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        fontWeight: FontWeight.bold,
                                        color: Theme.of(context).brightness ==
                                                Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                              Spacer(),
                              isAddingMembersToChat
                                  ? MouseRegion(
                                      cursor: SystemMouseCursors.click,
                                      child: RoundedButton(
                                        Strings.next,
                                        controller.selectedPeople.isEmpty ||
                                                controller.idList.isEmpty
                                            ? null
                                            : () async {
                                                if (!kIsWeb) {
                                                  controller.isChatCreatedYet =
                                                      false;
                                                  controller.update();
                                                  await controller
                                                      .addMembersToGroupChat(
                                                          conversationId,
                                                          controller.idList[0]);
                                                  controller.chatUserList =
                                                      await controller
                                                          .getChat();
                                                  controller.idList.clear();
                                                  controller.isChatCreatedYet =
                                                      true;
                                                  controller.usersList.clear();
                                                  controller.selectedPeople
                                                      .clear();
                                                  // controller.chatName = controller.randomGroup;
                                                  controller.update();
                                                  // controller.isChatScreenWeb = true;
                                                  Navigator.of(context).pop();
                                                  Navigator.of(context).pop();
                                                  Navigator.of(context).pop();

                                                  // Navigator.push(
                                                  //     context,
                                                  //     MaterialPageRoute(
                                                  //         builder: (BuildContext context) =>
                                                  //             ChatScreenMobile(controller)));
                                                } else {
                                                  controller.isChatCreatedYet =
                                                      false;
                                                  controller.update();
                                                  await controller
                                                      .addMembersToGroupChat(
                                                          conversationId,
                                                          controller.idList[0]);
                                                  controller.chatUserList =
                                                      await controller
                                                          .getChat();
                                                  controller.usersList.clear();
                                                  controller.idList.clear();
                                                  controller.isChatCreatedYet =
                                                      true;
                                                  controller.selectedPeople
                                                      .clear();
                                                  controller.infoChatInfo =
                                                      false;
                                                  controller.isChatScreenWeb =
                                                      false;
                                                  controller.isNewsFeedScreen =
                                                      false;

                                                  print(
                                                      "sdfsdfsdfsdfsdfsdfsfrtyrtyrtyrtyrt");

                                                  if (controller.isChatScreen ==
                                                      false) {
                                                    controller.isChatScreen =
                                                        true;
                                                    onChatsChange = true;
                                                    onBookMarksChange = false;
                                                    onTrendsChange = false;
                                                    onHomeChange = false;

                                                    onBrowsChange = false;
                                                    onMoreChange = false;
                                                    onNotificationChange =
                                                        false;
                                                    onListChange = false;
                                                    onSettingChange = false;
                                                    onProfileChange = false;
                                                  }

                                                  // controller.createChat();
                                                  await controller.createChat(
                                                      controller.idList,
                                                      controller.idList.length >
                                                              1
                                                          ? "group"
                                                          : "single",
                                                      groupMemberName:
                                                          controller
                                                              .randomGroup);
                                                  // controller.chatName = controller.randomGroup;

                                                  controller.update();

                                                  Navigator.of(context).pop();
                                                }
                                              },
                                        horizontalPadding: 30.0,
                                        verticalPadding: kIsWeb ? 14.0 : 6.0,
                                        roundedButtonColor:
                                            controller.displayColor,
                                      ),
                                    )
                                  : MouseRegion(
                                      cursor: SystemMouseCursors.click,
                                      child: RoundedButton(
                                        Strings.next,
                                        controller.selectedPeople.isEmpty ||
                                                controller.idList.isEmpty
                                            ? null
                                            : () async {
                                                if (!kIsWeb) {
                                                  controller.isChatCreatedYet =
                                                      false;
                                                  controller.update();
                                                  await controller.createChat(
                                                      controller.idList,
                                                      controller.idList.length >
                                                              1
                                                          ? "group"
                                                          : "single",
                                                      groupMemberName:
                                                          controller
                                                              .randomGroup);
                                                  controller.chatUserList =
                                                      await controller
                                                          .getChat();
                                                  controller.idList.clear();
                                                  controller.isChatCreatedYet =
                                                      true;
                                                  // controller.usersList.clear();
                                                  // controller.selectedPeople.clear();

                                                  // controller.chatName = controller.randomGroup;
                                                  // controller.update();
                                                  // controller.isChatScreenWeb = true;

                                                  int currentIndex = 0;
                                                  if (controller.chatUserList !=
                                                      null) {
                                                    currentIndex = controller
                                                        .chatUserList
                                                        .indexWhere((element) {
                                                      return "@${element.username}" ==
                                                          "${controller.selectedPeople[0]}";
                                                    });
                                                  }
                                                  if (currentIndex == -1)
                                                    currentIndex = 0;

                                                  controller.isImagePickedChat =
                                                      false;
                                                  controller.isVideoPickedChat =
                                                      false;
                                                  controller
                                                          .isDocumentPickedChat =
                                                      false;
                                                  controller.messageController
                                                      .clear();
                                                  controller.showOverlay =
                                                      false;
                                                  controller.messageController
                                                      .text = "";
                                                  controller.chatName =
                                                      controller.chatUserList[
                                                          currentIndex];
                                                  controller
                                                      .groupName = controller
                                                              .chatName
                                                              .conversationType ==
                                                          "group"
                                                      ? "${controller.chatName.name}"
                                                      : "${controller.chatName.name}";
                                                  controller.usersList.clear();
                                                  controller.selectedPeople
                                                      .clear();
                                                  controller.idList.clear();
                                                  controller.getMessagesOfAConversation(
                                                      controller.chatName
                                                          .conversationId);
                                                  controller.isVideoThumbnail =
                                                      false;
                                                  controller.videoThumbnail =
                                                      null;
                                                  controller.chatIndex =
                                                      currentIndex;
                                                  controller.tempGroupName = "";
                                                  controller
                                                          .tempProfileImageGroupChat =
                                                      null;
                                                  controller.update();
                                                  Navigator.of(context).pop();
                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                          builder: (BuildContext
                                                                  context) =>
                                                              ChatScreenMobile(
                                                                  controller, false)));
                                                } else {
                                                  print(
                                                      "chatopen  ${controller.selectedPeople[0]}");

                                                  controller.isChatCreatedYet =
                                                      false;
                                                  controller.update();
                                                  await controller.createChat(
                                                      controller.idList,
                                                      controller.idList.length >
                                                              1
                                                          ? "group"
                                                          : "single",
                                                      groupMemberName:
                                                          controller
                                                              .randomGroup);
                                                  controller.chatUserList =
                                                      await controller
                                                          .getChat();

                                                  int findUser = 0;
                                                  String temp = "";

                                                  if (controller
                                                          .idList.length ==
                                                      1) {
                                                    int counter = -1;
                                                    controller.chatUserList
                                                        .forEach((element) {
                                                      counter++;
                                                      temp =
                                                          '@${element.username}';

                                                      print("temp ${temp}");
                                                      if (temp ==
                                                          controller
                                                                  .selectedPeople[
                                                              0]) {
                                                        print("iiiii");
                                                        findUser = counter;
                                                      }
                                                    });
                                                  }

                                                  print("findUser ${findUser}");

                                                  controller.usersList.clear();
                                                  controller.idList.clear();
                                                  controller.isChatCreatedYet =
                                                      true;

                                                  controller.isImagePickedChat =
                                                      false;
                                                  controller.isVideoPickedChat =
                                                      false;
                                                  controller
                                                          .isDocumentPickedChat =
                                                      false;
                                                  controller.messageController
                                                      .clear();
                                                  controller.showOverlay =
                                                      false;

                                                  controller.messageController
                                                      .text = "";
                                                  controller.isChatScreenWeb =
                                                      true;
                                                  controller.chatName =
                                                      controller.chatUserList[
                                                          findUser];
                                                  controller
                                                      .groupName = controller
                                                              .chatName
                                                              .conversationType ==
                                                          "group"
                                                      ? "${controller.chatName.name}"
                                                      : "${controller.chatName.name}";
                                                  controller.infoChatInfo =
                                                      false;
                                                  controller.getMessagesOfAConversation(
                                                      controller.chatName
                                                          .conversationId);
                                                  controller.chatIndex =
                                                      findUser;
                                                  controller.highlighteTheChat =
                                                      findUser;
                                                  controller.update();
                                                  controller.selectedPeople
                                                      .clear();
                                                  controller.isNewsFeedScreen =
                                                      false;

                                                  print(
                                                      "sdfsdfsdfsdfsdfsdfsfrtyrtyrtyrtyrt");

                                                  if (controller.isChatScreen ==
                                                      false) {
                                                    controller.isChatScreen =
                                                        true;
                                                    onChatsChange = true;
                                                    onBookMarksChange = false;
                                                    onTrendsChange = false;
                                                    onHomeChange = false;

                                                    onBrowsChange = false;
                                                    onMoreChange = false;
                                                    onNotificationChange =
                                                        false;
                                                    onListChange = false;
                                                    onSettingChange = false;
                                                    onProfileChange = false;
                                                  }

                                                  // controller.chatName = controller.randomGroup;
                                                  controller.update();
                                                  // controller.isChatScreenWeb = true;

                                                  if (controller.navRoute != "isChatScreen"){
                                                    // This will be triggered when user start a new chat from "Web Home Page Right Section".
                                                    Navigator.pop(context, true);
                                                  } else {
                                                    Navigator.of(context).pop();
                                                  }
                                                  // if (controller.navRoute != "isChatScreen"){
                                                  //   // This will be triggered when user start a new chat from "Web Home Page Right Section".
                                                  //   controller.navRoute = "isChatScreen";
                                                  //   Get.toNamed(FluroRouters.mainScreen + '/chats');
                                                  // }
                                                }
                                              },
                                        horizontalPadding: 30.0,
                                        verticalPadding: kIsWeb ? 14.0 : 6.0,
                                        roundedButtonColor:
                                            controller.displayColor,
                                      ),
                                    ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: TextField(
                            style: LightStyles.baseTextTheme.headline2.copyWith(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black),
                            cursorColor:
                                Theme.of(context).brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                            autofocus: true,
                            controller: controller.chatSearchTEC,
                            focusNode: controller.chatSearchTextFocus,
                            onChanged: (value) async {
                              if (value.isEmpty) {
                                var result = await controller.searchChatUser("");
                                if (controller.chatSearchTEC.text == value){
                                  controller.usersList = result;
                                  controller.isChatUsersLoad = false;
                                  controller.usersList = null;
                                  controller.update();
                                }
                              } else {
                                if (value[0] == '@') {
                                  var result = await controller.searchChatUser(value.substring(1));
                                  if (controller.chatSearchTEC.text == value){
                                    controller.usersList = result;
                                    controller.update();
                                  }
                                } else {
                                  var result = await controller.searchChatUser(value);;
                                  if (controller.chatSearchTEC.text == value){
                                    controller.usersList = result;
                                    controller.update();
                                  }
                                }
                              }

                              // print(value);
                              // LoginController signupController = LoginController();
                              // var resBody =
                              //     await signupController.searchUsers(queryParameters: {
                              //   "search_text": value,
                              // }, token: {
                              //   "Authorization": " Bearer ${Url.webAPIKey}",
                              //   "Token":
                              //       "4be7185a7d4038949d14153402e31545600ef1a22efc34a6d208ba9ab45bfe23621ea1bb3940524d1edb14191b2005e5c7965a8213d69bcdf19e0c3b",
                              //   "X-Requested-With": "XMLHttpRequest"
                              // });
                              // usersList = resBody;
                              // print(resBody);
                              // setState(() {
                              //   print("my list");
                              // });
                            },
                            textAlignVertical: TextAlignVertical.center,
                            decoration: InputDecoration(
                              hintText: Strings.searchPeople,
                              hintStyle: LightStyles.baseTextTheme.headline3,
                              prefixIcon: Icon(
                                Icons.search,
                                size: 20,
                                color: controller.displayColor,
                              ),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 0,
                                  style: BorderStyle.none,
                                ),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(40),
                                borderSide: BorderSide(
                                  width: 0,
                                  style: BorderStyle.none,
                                ),
                              ),
                              fillColor: Colors.grey[250],
                            ),
                          ),
                        ),
                        controller.selectedPeople != null &&
                                controller.selectedPeople.isNotEmpty
                            ? Wrap(
                                children: List.generate(
                                    controller.selectedPeople.length, (index) {
                                  return Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: ActionChip(
                                      onPressed: () {
                                        print('pressed');
                                        controller.selectedPeople
                                            .removeAt(index);
                                        controller.usersList.removeAt(index);
                                        controller.idList.removeAt(index);
                                        controller.update();
                                        setState(() {});
                                      },
                                      elevation: 8.0,
                                      padding: EdgeInsets.symmetric(
                                          vertical: 6, horizontal: 2),
                                      avatar: CircleAvatar(
                                        radius: 16,
                                        backgroundColor: Colors.white,
                                        child: GestureDetector(
                                          onTap: () {
                                            print('pressed');
                                            controller.usersList.clear();
                                            controller.selectedPeople.clear();
                                            controller.idList.clear();

                                            controller.update();
                                            setState(() {});
                                          },
                                          child: Icon(
                                            Icons.close,
                                            color: controller.displayColor,
                                            size: 12,
                                          ),
                                        ),
                                      ),
                                      label: Text(
                                        controller.selectedPeople[index]
                                            .toString(),
                                        style: Styles.baseTextTheme.headline4
                                            .copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                      backgroundColor: controller.displayColor,
                                      shape: StadiumBorder(
                                          side: BorderSide(
                                        width: 1,
                                        color: controller.displayColor,
                                      )),
                                    ),
                                  );
                                }),
                              )
                            : Container(),
                        Divider(),

                        ///SearchList
                        controller.isChatUsersLoad
                            ? Center(
                                child: CircularProgressIndicator(),
                              )
                            : Expanded(
                                child: ListView.builder(
                                shrinkWrap: true,
                                itemCount: controller.usersList == null
                                    ? 0
                                    : controller.usersList.length,
                                itemBuilder: (context, index) => Card(
                                  elevation: 2,
                                  margin: EdgeInsets.all(10),
                                  child: ListTile(
                                    onTap: isAddingMembersToChat
                                        ? () async {
                                            if (!controller.idList.contains(controller.usersList[index]['id'])) {
                                              controller.selectedPeople.clear();
                                              controller.idList.clear();
                                              controller.selectedPeople.insert(0, controller.usersList[index]['username']);
                                              controller.idList.insert(0, controller.usersList[index]['id']);
                                              controller.randomGroup = controller.randomGroup + "${controller.usersList[0]['username']} ";

                                              controller.chatSearchTEC.clear();
                                              controller.chatSearchTextFocus.requestFocus();

                                              controller.selectedPeople.forEach((element) {
                                                print("chat members ${element}");
                                              });

                                              controller.update();
                                            }
                                          }
                                        : () async {
                                            if (!controller.idList.contains(
                                                controller.usersList[index]
                                                    ['id'])) {
                                              controller.selectedPeople.add(
                                                  controller.usersList[index]
                                                      ['username']);
                                              controller.idList.add(controller
                                                  .usersList[index]['id']);
                                              controller
                                                  .randomGroup = controller
                                                      .randomGroup +
                                                  "${controller.usersList[index]['username']} ";

                                              controller.chatSearchTEC.clear();
                                              controller.chatSearchTextFocus
                                                  .requestFocus();

                                              controller.update();
                                            }
                                          },
                                    leading: // controller.groupName != null ? controller.groupName :
                                        controller.usersList[index]
                                                    ['profile_image']
                                                // != null ? controller.chatName.profileImage
                                                ==
                                                null
                                            ? CircleAvatar(
                                                backgroundImage: AssetImage(
                                                    'assets/images/person_placeholder.png'),
                                              )
                                            : Padding(
                                                padding: const EdgeInsets.only(
                                                    bottom: 4, left: 7),
                                                child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.circular(30),
                                                  child: FadeInImage(
                                                      fit: BoxFit.cover,
                                                      width: 40,
                                                      height: 40,
                                                      placeholder: AssetImage(
                                                          'assets/images/person_placeholder.png'),
                                                      image: NetworkImage(controller
                                                                          .usersList[
                                                                      index][
                                                                  'profile_image'] !=
                                                              null
                                                          ? controller.usersList[
                                                                  index]
                                                              ['profile_image']
                                                          : "assets/images/person_placeholder.png")),
                                                ),
                                              ),
                                    title: Row(
                                      children: [
                                        Flexible(
                                          child: Text(
                                            controller.usersList[index]
                                                ['firstname'],
                                            softWrap: true,
                                            style: Styles.baseTextTheme.headline4
                                                .copyWith(
                                              color:
                                                  Theme.of(context).brightness ==
                                                          Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                            ),
                                          ),
                                        ),
                                        controller.usersList[index]
                                                    ['account_verified'] ==
                                                "verified"
                                            ? Row(
                                                children: [
                                                  SizedBox(
                                                    width: 5,
                                                  ),
                                                  BlueTick(
                                                    height: 15,
                                                    width: 15,
                                                    iconSize: 10,
                                                  ),
                                                ],
                                              )
                                            : SizedBox(),
                                      ],
                                    ),
                                    subtitle: Text(
                                      controller.usersList[index]['username'],
                                      style: Styles.baseTextTheme.headline4
                                          .copyWith(
                                        fontWeight: FontWeight.w400,
                                        fontSize: kIsWeb ? 14 : 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ))
                      ],
                    ),
            );
          },
        ),
      );
    });
  }
}
