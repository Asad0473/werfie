import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class CustomVideoPlayer extends StatefulWidget {
  final fileController;
  final webFileController;
  final videoUrl;

  CustomVideoPlayer(
      {this.fileController, this.webFileController, this.videoUrl});

  @override
  _CustomVideoPlayerState createState() => _CustomVideoPlayerState();
}

class _CustomVideoPlayerState extends State<CustomVideoPlayer> {
  VideoPlayerController _controller;
  Future<void> _initializeVideoPlayerFuture;

  @override
  void initState() {
    // Create and store the VideoPlayerController. The VideoPlayerController
    // offers several different constructors to play videos from assets, files,
    // or the internet.
    if (widget.fileController != null) {
      _controller = VideoPlayerController.file(widget.fileController);
    } else if (widget.videoUrl != null) {
      _controller = VideoPlayerController.network(widget.videoUrl);
    }

    // Initialize the controller and store the Future for later use.
    _initializeVideoPlayerFuture = _controller.initialize();

    // Use the controller to loop the video.
    _controller.setLooping(true);

    super.initState();
  }

  @override
  void dispose() {
    // Ensure disposing of the VideoPlayerController to free up resources.
    _controller.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        FutureBuilder(
          future: _initializeVideoPlayerFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              // If the VideoPlayerController has finished initialization, use
              // the data it provides to limit the aspect ratio of the video.
              // return Container(
              //     // color: Colors.red,
              //     decoration: BoxDecoration(
              //         color: Colors
              //             .yellow,
              //         borderRadius:
              //         BorderRadius
              //             .all(Radius
              //             .circular(
              //             88))),
              //     height: 80,
              //     // width: Get.height / 2,
              //     child: VideoPlayer(_controller)
              // );
              return AspectRatio(
                  aspectRatio: _controller.value.aspectRatio,
                  // _controller.value.size.width /
                  //     _controller.value.size.height,
                  //  height:     kIsWeb ? 480 : 240,,
                  child: VideoPlayer(_controller));
            } else {
              // If the VideoPlayerController is still initializing, show a
              // loading spinner.
              return Container(
                  height: 250,
                  child: Center(child: CircularProgressIndicator()));
            }
          },
        ),
        Positioned(
          bottom: 0,
          left: 0,
          right: 0,
          top: 0,
          child: IconButton(
            color: Colors.white,
            icon: Icon(
              _controller.value.isPlaying
                  ? Icons.pause
                  : Icons.play_circle_fill_outlined,
              //
              size: 70,
            ),
            onPressed: () {
              // Wrap the play or pause in a call to `setState`. This ensures the
              // correct icon is shown.
              setState(() {
                // If the video is playing, pause it.
                if (_controller.value.isPlaying) {
                  _controller.pause();
                } else {
                  // If the video is paused, play it.
                  _controller.play();
                }
              });
            },
          ),
        ),
      ],
    );
  }
}
