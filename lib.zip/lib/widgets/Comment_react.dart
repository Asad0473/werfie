import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/reaction.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:werfieapp/widgets/blue_tick.dart';

import '../models/post.dart';
import '../models/profile.dart';
import '../network/controller/other_users_controller.dart';
import '../screens/other_users_profile.dart';
import '../screens/user_profile.dart';
import '../utils/emojis.dart';
import '../utils/font.dart';

class CommentReact extends StatefulWidget {
  final title;
  final List<Reaction1> reactions;
  final List<Retweet> retweets;
  Post post;
  Comment comment;

  CommentReact(this.title,
      {this.reactions, this.retweets, this.post, this.comment});

  @override
  State<CommentReact> createState() => _CommentReactState();
}

class _CommentReactState extends State<CommentReact> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(
      // assignId: true,
      builder: (controller) {
        return AlertDialog(
            backgroundColor: Colors.white,
            contentPadding: EdgeInsets.zero,
            insetPadding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius:
                  kIsWeb ? BorderRadius.circular(20) : BorderRadius.circular(0),
            ),

            // title: Text(widget.title),
            content: SafeArea(
              child: Container(
                  width: kIsWeb ? 0 : MediaQuery.of(context).size.width,
                  height: kIsWeb ? 300 : MediaQuery.of(context).size.height,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: kIsWeb
                            ? MainAxisAlignment.spaceBetween
                            : MainAxisAlignment.start,
                        children: [
                          if (!kIsWeb)
                            IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: Icon(
                                  Icons.arrow_back,
                                )),
                          Spacer(),
                          Text(
                            widget.title,
                            // style: TextStyle(
                            //     fontSize: 20,
                            //     fontWeight: FontWeight.bold,
                            //     color: Colors.black
                            // ),
                            style:
                                Theme.of(context).brightness == Brightness.dark
                                    ? TextStyle(
                                        color: Colors.white,
                                        fontSize: kIsWeb ? 15 : 20,
                                        fontWeight: FontWeight.bold,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                        fontSize: kIsWeb ? 15 : 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                          ),
                          Spacer(),
                          if (kIsWeb)
                            IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: Icon(
                                  Icons.cancel,
                                )),
                        ],
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 0.1,
                              blurRadius: 0.1,
                              offset:
                                  Offset(0, 1), // changes position of shadow
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                            left: 15,
                            top: 10,
                          ),
                          child: controller.reactionLoading == true
                              ? Center(
                                  child: CircularProgressIndicator(),
                                )
                              : controller.commentReaction.data
                                          .reactionCounts !=
                                      null
                                  ? Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: Row(
                                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          GestureDetector(
                                            onTap: () async {
                                              await controller
                                                  .getWhoReactedForCommment(
                                                      widget.comment.id,
                                                      reactionType: "all",
                                                      allLikes: 1);
                                            },
                                            child: Row(
                                              children: [
                                                Text(
                                                  "All LIKES",
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.likes >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "simple_like",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/like-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.loves >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "love",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/love-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.loughs >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "lough",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/laugh-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .commentReaction
                                                      .data
                                                      .reactionCounts
                                                      .exciteds >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "excited",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/excited-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.thanks >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "thanks",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/thanks-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.crys >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType: "cry",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/cry-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.commentReaction.data
                                                      .reactionCounts.smiles >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReactedForCommment(
                                                            widget.comment.id,
                                                            reactionType:
                                                                "smile",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/smile-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                        ],
                                      ),
                                    )
                                  : SizedBox(),
                        ),
                      ),
                      Expanded(
                          child: controller.reactionLoading == true ||
                                  controller.rLoading == true
                              ? Center(
                                  child: CircularProgressIndicator(),
                                )
                              : controller.commentReaction.data.reactedUser !=
                                      null
                                  ? ListView.separated(
                                      separatorBuilder: (conext, index) {
                                        return (Divider(
                                          thickness: 1,
                                        ));
                                      },
                                      itemCount: controller.commentReaction.data
                                                  .reactedUser ==
                                              null
                                          ? 1
                                          : controller.commentReaction.data
                                              .reactedUser.length,
                                      itemBuilder: (context, index) {
                                        return controller.commentReaction.data
                                                    .reactedUser ==
                                                null
                                            ? Center(
                                                child: Text(Strings.nothingYet),
                                              )
                                            : Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 20),
                                                child: GestureDetector(
                                                  onTap: kIsWeb
                                                      ? () async {
                                                          if (GetStorage()
                                                                  .read('id') ==
                                                              controller
                                                                  .commentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId) {
                                                            print(
                                                                "react screen ");
                                                            Navigator.pop(
                                                                context);
                                                            controller
                                                                    .isTrendsScreen =
                                                                false;
                                                            controller
                                                                    .isNewsFeedScreen =
                                                                false;
                                                            controller
                                                                    .isBrowseScreen =
                                                                false;
                                                            controller
                                                                    .isNotificationScreen =
                                                                false;
                                                            controller
                                                                    .isChatScreen =
                                                                false;
                                                            controller
                                                                    .isSavedPostScreen =
                                                                false;
                                                            controller
                                                                    .isReplyComment =
                                                                false;
                                                            controller
                                                                    .isPostDetails =
                                                                false;
                                                            controller
                                                                    .isProfileScreen =
                                                                true;
                                                            controller
                                                                    .isOtherUserProfileScreen =
                                                                false;
                                                            controller.update();
                                                          } else {
                                                            Navigator.pop(
                                                                context);
                                                            controller
                                                                    .isTrendsScreen =
                                                                false;
                                                            controller
                                                                    .isNewsFeedScreen =
                                                                false;
                                                            controller
                                                                    .isBrowseScreen =
                                                                false;
                                                            controller
                                                                    .isNotificationScreen =
                                                                false;
                                                            controller
                                                                    .isChatScreen =
                                                                false;
                                                            controller
                                                                    .isSavedPostScreen =
                                                                false;
                                                            controller
                                                                    .isPostDetails =
                                                                false;
                                                            controller
                                                                    .isReplyComment =
                                                                false;
                                                            controller
                                                                    .isProfileScreen =
                                                                false;
                                                            controller
                                                                    .isOtherUserProfileScreen =
                                                                true;

                                                            // controller.otherUserName = controller.commentReaction.data.reactedUser[index].user;

                                                            controller
                                                                    .otherUserId =
                                                                controller
                                                                    .commentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .userId;
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                UserProfile();
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                await controller
                                                                    .getOtherUserProfile(controller
                                                                        .commentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .userId);

                                                            await Get.find<
                                                                    OtherUserController>()
                                                                .filterUsersPostPagged(
                                                                    "posts",
                                                                    page: 1);
                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts[0]
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;

                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts
                                                                .forEach(
                                                                    (element) {
                                                              element
                                                                  .mute = Get.find<
                                                                      NewsfeedController>()
                                                                  .userInfo
                                                                  .muted;
                                                              print(
                                                                  "element.mute  ${element.mute}");
                                                            });

                                                            controller.update();
                                                          }
                                                        }
                                                      : () async {
                                                          if (GetStorage()
                                                                  .read('id') ==
                                                              controller
                                                                  .commentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId) {
                                                            Navigator.pop(
                                                                context);
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        ProfileScreen(
                                                                  controller:
                                                                      controller,
                                                                ),
                                                              ),
                                                            );
                                                          } else {
                                                            Navigator.pop(
                                                                context);
                                                            // controller.otherUserName = controller.commentReaction.data.reactedUser[index].username;
                                                            controller
                                                                    .otherUserId =
                                                                controller
                                                                    .commentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .userId;
                                                            controller.update();
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        OtherUsersProfile(
                                                                  controller:
                                                                      controller,
                                                                ),
                                                              ),
                                                            );

                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                UserProfile();
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                await controller
                                                                    .getOtherUserProfile(controller
                                                                        .commentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .userId);

                                                            await Get.find<
                                                                    OtherUserController>()
                                                                .filterUsersPostPagged(
                                                                    "posts",
                                                                    page: 1);
                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts[0]
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;

                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts
                                                                .forEach(
                                                                    (element) {
                                                              element
                                                                  .mute = Get.find<
                                                                      NewsfeedController>()
                                                                  .userInfo
                                                                  .muted;
                                                              print(
                                                                  "element.mute  ${element.mute}");
                                                            });

                                                            controller.update();
                                                          }
                                                        },
                                                  child: ListTile(
                                                    leading: Stack(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundImage: controller
                                                                      .commentReaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .user
                                                                      .profileImage !=
                                                                  null
                                                              ? NetworkImage(controller
                                                                  .commentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .user
                                                                  .profileImage)
                                                              : AssetImage(
                                                                  'assets/images/person_placeholder.png'),
                                                        ),
                                                        controller
                                                                    .commentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .type ==
                                                                "love"
                                                            ? Positioned(
                                                                bottom: 1,
                                                                right: 0.1,
                                                                child:
                                                                    Image.asset(
                                                                  'assets/reaction_gif/love-min.png',
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ),
                                                              )
                                                            : controller
                                                                        .commentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .type ==
                                                                    "simple_like"
                                                                ? Positioned(
                                                                    bottom: 1,
                                                                    right: 0.1,
                                                                    child: Image
                                                                        .asset(
                                                                      'assets/reaction_gif/like-min.png',
                                                                      height:
                                                                          20.0,
                                                                      width:
                                                                          20.0,
                                                                    ),
                                                                  )
                                                                : controller
                                                                            .commentReaction
                                                                            .data
                                                                            .reactedUser[
                                                                                index]
                                                                            .type ==
                                                                        "smile"
                                                                    ? Positioned(
                                                                        bottom:
                                                                            1,
                                                                        right:
                                                                            0.1,
                                                                        child: Image
                                                                            .asset(
                                                                          'assets/reaction_gif/smile-min.png',
                                                                          height:
                                                                              20.0,
                                                                          width:
                                                                              20.0,
                                                                        ),
                                                                      )
                                                                    : controller.commentReaction.data.reactedUser[index].type ==
                                                                            "cry"
                                                                        ? Positioned(
                                                                            bottom:
                                                                                1,
                                                                            right:
                                                                                0.1,
                                                                            child:
                                                                                Image.asset(
                                                                              'assets/reaction_gif/cry-min.png',
                                                                              height: 20.0,
                                                                              width: 20.0,
                                                                            ),
                                                                          )
                                                                        : controller.commentReaction.data.reactedUser[index].type ==
                                                                                "thanks"
                                                                            ? Positioned(
                                                                                bottom: 1,
                                                                                right: 0.1,
                                                                                child: Image.asset(
                                                                                  'assets/reaction_gif/thanks-min.png',
                                                                                  height: 20.0,
                                                                                  width: 20.0,
                                                                                ),
                                                                              )
                                                                            : controller.commentReaction.data.reactedUser[index].type == "lough"
                                                                                ? Positioned(
                                                                                    bottom: 1,
                                                                                    right: 0.1,
                                                                                    child: Image.asset(
                                                                                      'assets/reaction_gif/laugh-min.png',
                                                                                      height: 20.0,
                                                                                      width: 20.0,
                                                                                    ),
                                                                                  )
                                                                                : controller.commentReaction.data.reactedUser[index].type == "excited"
                                                                                    ? Positioned(
                                                                                        bottom: 1,
                                                                                        right: 0.1,
                                                                                        child: Image.asset(
                                                                                          'assets/reaction_gif/excited-min.png',
                                                                                          height: 20.0,
                                                                                          width: 20.0,
                                                                                        ),
                                                                                      )
                                                                                    : SizedBox(),
                                                      ],
                                                    ),
                                                    title: Row(
                                                      children: [
                                                        Text(controller
                                                            .commentReaction
                                                            .data
                                                            .reactedUser[index]
                                                            .user
                                                            .username),
                                                        controller
                                                                    .commentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .user
                                                                    .accountVerified ==
                                                                "verified"
                                                            ? Wrap(children: [
                                                                SizedBox(
                                                                  width: 2,
                                                                ),
                                                                BlueTick(
                                                                  height: 15,
                                                                  width: 15,
                                                                  iconSize: 12,
                                                                )
                                                              ])
                                                            : SizedBox()
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              );
                                      })
                                  : ListView.separated(
                                      separatorBuilder: (conext, index) {
                                        return (Divider(
                                          thickness: 1,
                                        ));
                                      },
                                      itemCount: controller.allCommentReaction
                                                  .data.reactedUser ==
                                              null
                                          ? 1
                                          : controller.allCommentReaction.data
                                              .reactedUser.length,
                                      itemBuilder: (context, index) {
                                        return controller.allCommentReaction
                                                    .data.reactedUser ==
                                                null
                                            ? Center(
                                                child: Text(Strings.nothingYet),
                                              )
                                            : Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 20),
                                                child: GestureDetector(
                                                  onTap: kIsWeb
                                                      ? () async {
                                                          if (GetStorage()
                                                                  .read('id') ==
                                                              controller
                                                                  .allCommentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId) {
                                                            print(
                                                                "react screen ");
                                                            Navigator.pop(
                                                                context);
                                                            controller
                                                                    .isTrendsScreen =
                                                                false;
                                                            controller
                                                                    .isNewsFeedScreen =
                                                                false;
                                                            controller
                                                                    .isBrowseScreen =
                                                                false;
                                                            controller
                                                                    .isNotificationScreen =
                                                                false;
                                                            controller
                                                                    .isChatScreen =
                                                                false;
                                                            controller
                                                                    .isSavedPostScreen =
                                                                false;
                                                            controller
                                                                    .isReplyComment =
                                                                false;
                                                            controller
                                                                    .isPostDetails =
                                                                false;
                                                            controller
                                                                    .isProfileScreen =
                                                                true;
                                                            controller
                                                                    .isOtherUserProfileScreen =
                                                                false;
                                                            controller.update();
                                                          } else {
                                                            Navigator.pop(
                                                                context);
                                                            controller
                                                                    .isTrendsScreen =
                                                                false;
                                                            controller
                                                                    .isNewsFeedScreen =
                                                                false;
                                                            controller
                                                                    .isBrowseScreen =
                                                                false;
                                                            controller
                                                                    .isNotificationScreen =
                                                                false;
                                                            controller
                                                                    .isChatScreen =
                                                                false;
                                                            controller
                                                                    .isSavedPostScreen =
                                                                false;
                                                            controller
                                                                    .isPostDetails =
                                                                false;
                                                            controller
                                                                    .isReplyComment =
                                                                false;
                                                            controller
                                                                    .isProfileScreen =
                                                                false;
                                                            controller
                                                                    .isOtherUserProfileScreen =
                                                                true;

                                                            // controller.otherUserName = controller.commentReaction.data.reactedUser[index].user;

                                                            controller
                                                                    .otherUserId =
                                                                controller
                                                                    .allCommentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .userId;
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                UserProfile();
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                await controller
                                                                    .getOtherUserProfile(controller
                                                                        .allCommentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .userId);

                                                            await Get.find<
                                                                    OtherUserController>()
                                                                .filterUsersPostPagged(
                                                                    "posts",
                                                                    page: 1);
                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts[0]
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;

                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts
                                                                .forEach(
                                                                    (element) {
                                                              element
                                                                  .mute = Get.find<
                                                                      NewsfeedController>()
                                                                  .userInfo
                                                                  .muted;
                                                              print(
                                                                  "element.mute  ${element.mute}");
                                                            });

                                                            controller.update();
                                                          }
                                                        }
                                                      : () async {
                                                          if (GetStorage()
                                                                  .read('id') ==
                                                              controller
                                                                  .allCommentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId) {
                                                            Navigator.pop(
                                                                context);
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        ProfileScreen(
                                                                  controller:
                                                                      controller,
                                                                ),
                                                              ),
                                                            );
                                                          } else {
                                                            Navigator.pop(
                                                                context);
                                                            // controller.otherUserName = controller.commentReaction.data.reactedUser[index].username;
                                                            controller
                                                                    .otherUserId =
                                                                controller
                                                                    .allCommentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .userId;
                                                            controller.update();
                                                            Navigator.push(
                                                              context,
                                                              MaterialPageRoute(
                                                                builder:
                                                                    (context) =>
                                                                        OtherUsersProfile(
                                                                  controller:
                                                                      controller,
                                                                ),
                                                              ),
                                                            );

                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                UserProfile();
                                                            Get.find<NewsfeedController>()
                                                                    .userInfo =
                                                                await controller
                                                                    .getOtherUserProfile(controller
                                                                        .allCommentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .userId);

                                                            await Get.find<
                                                                    OtherUserController>()
                                                                .filterUsersPostPagged(
                                                                    "posts",
                                                                    page: 1);
                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts[0]
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;

                                                            Get.find<
                                                                    OtherUserController>()
                                                                .userPosts
                                                                .forEach(
                                                                    (element) {
                                                              element
                                                                  .mute = Get.find<
                                                                      NewsfeedController>()
                                                                  .userInfo
                                                                  .muted;
                                                              print(
                                                                  "element.mute  ${element.mute}");
                                                            });

                                                            controller.update();
                                                          }
                                                        },
                                                  child: ListTile(
                                                    leading: Stack(
                                                      children: [
                                                        CircleAvatar(
                                                          backgroundImage: controller
                                                                      .allCommentReaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .user
                                                                      .profileImage !=
                                                                  null
                                                              ? NetworkImage(controller
                                                                  .allCommentReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .user
                                                                  .profileImage)
                                                              : AssetImage(
                                                                  'assets/images/person_placeholder.png'),
                                                        ),
                                                        controller
                                                                    .allCommentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .type ==
                                                                "love"
                                                            ? Positioned(
                                                                bottom: 1,
                                                                right: 0.1,
                                                                child:
                                                                    Image.asset(
                                                                  'assets/reaction_gif/love-min.png',
                                                                  height: 20.0,
                                                                  width: 20.0,
                                                                ),
                                                              )
                                                            : controller
                                                                        .allCommentReaction
                                                                        .data
                                                                        .reactedUser[
                                                                            index]
                                                                        .type ==
                                                                    "simple_like"
                                                                ? Positioned(
                                                                    bottom: 1,
                                                                    right: 0.1,
                                                                    child: Image
                                                                        .asset(
                                                                      'assets/reaction_gif/like-min.png',
                                                                      height:
                                                                          20.0,
                                                                      width:
                                                                          20.0,
                                                                    ),
                                                                  )
                                                                : controller
                                                                            .allCommentReaction
                                                                            .data
                                                                            .reactedUser[
                                                                                index]
                                                                            .type ==
                                                                        "smile"
                                                                    ? Positioned(
                                                                        bottom:
                                                                            1,
                                                                        right:
                                                                            0.1,
                                                                        child: Image
                                                                            .asset(
                                                                          'assets/reaction_gif/smile-min.png',
                                                                          height:
                                                                              20.0,
                                                                          width:
                                                                              20.0,
                                                                        ),
                                                                      )
                                                                    : controller.allCommentReaction.data.reactedUser[index].type ==
                                                                            "cry"
                                                                        ? Positioned(
                                                                            bottom:
                                                                                1,
                                                                            right:
                                                                                0.1,
                                                                            child:
                                                                                Image.asset(
                                                                              'assets/reaction_gif/cry-min.png',
                                                                              height: 20.0,
                                                                              width: 20.0,
                                                                            ),
                                                                          )
                                                                        : controller.allCommentReaction.data.reactedUser[index].type ==
                                                                                "thanks"
                                                                            ? Positioned(
                                                                                bottom: 1,
                                                                                right: 0.1,
                                                                                child: Image.asset(
                                                                                  'assets/reaction_gif/thanks-min.png',
                                                                                  height: 20.0,
                                                                                  width: 20.0,
                                                                                ),
                                                                              )
                                                                            : controller.allCommentReaction.data.reactedUser[index].type == "lough"
                                                                                ? Positioned(
                                                                                    bottom: 1,
                                                                                    right: 0.1,
                                                                                    child: Image.asset(
                                                                                      'assets/reaction_gif/laugh-min.png',
                                                                                      height: 20.0,
                                                                                      width: 20.0,
                                                                                    ),
                                                                                  )
                                                                                : controller.allCommentReaction.data.reactedUser[index].type == "excited"
                                                                                    ? Positioned(
                                                                                        bottom: 1,
                                                                                        right: 0.1,
                                                                                        child: Image.asset(
                                                                                          'assets/reaction_gif/excited-min.png',
                                                                                          height: 20.0,
                                                                                          width: 20.0,
                                                                                        ),
                                                                                      )
                                                                                    : SizedBox(),
                                                      ],
                                                    ),
                                                    title: Row(
                                                      children: [
                                                        Text(
                                                          controller
                                                              .allCommentReaction
                                                              .data
                                                              .reactedUser[
                                                                  index]
                                                              .user
                                                              .username,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            color: Theme.of(context)
                                                                        .brightness ==
                                                                    Brightness
                                                                        .dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                            fontSize: 14,
                                                          ),
                                                        ),
                                                        controller
                                                                    .allCommentReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .user
                                                                    .accountVerified ==
                                                                "verified"
                                                            ? Wrap(children: [
                                                                SizedBox(
                                                                  width: 2,
                                                                ),
                                                                BlueTick(
                                                                  height: 15,
                                                                  width: 15,
                                                                  iconSize: 12,
                                                                )
                                                              ])
                                                            : SizedBox()
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              );
                                      })),
                    ],
                  )),
            ));
      },
    );
  }
}
