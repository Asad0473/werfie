// import 'package:werfieapp/models/reaction.dart';
// import 'package:werfieapp/models/retweet.dart';
// import 'package:werfieapp/utils/strings.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
//
// import '../utils/emojis.dart';
//
//  final  List<Tab> myTabs = <Tab>[
//
//   Tab(
//       text: 'All',
//   ),
//   Tab(
//       text: 'Like',
//     icon: Icon(
//       Icons.thumb_up
//     ),
//   ),
//
// ];
// class ReactRetweetDialog extends StatefulWidget  {
//   final title;
//   final List<Reaction1> reactions;
//   final List<Retweet> retweets;
//   ReactRetweetDialog(this.title, {this.reactions, this.retweets});
//
//   @override
//   State<ReactRetweetDialog> createState() => _ReactRetweetDialogState();
// }
//
// class _ReactRetweetDialogState extends State<ReactRetweetDialog>  with SingleTickerProviderStateMixin{
//
//
//
//
//   TabController tabController ;
//
//   @override
//   void initState() {
//
//     tabController = TabController(vsync: this, length: myTabs.length);
//
//     // TODO: implement initState
//     super.initState();
//   }
//
//
//   @override
//   void dispose() {
//     tabController.dispose();
//     super.dispose();
//   }
//
//   int currentIndex = 0;
//
//   @override
//   Widget build(BuildContext context) {
//
//     final cross = (MediaQuery.of(context).size.width * .025).round();
//     return DefaultTabController(
//         length: myTabs.length,
//         child: Builder(builder: (BuildContext context) {
//           final TabController tabController = DefaultTabController.of(context);
//           tabController.addListener(() {
//
//             if (!tabController.indexIsChanging) {
//
//               setState(() => currentIndex = tabController.index);
//               // Your code goes here.
//               // To get index of current tab use tabController.index
//             }
//           });
//           return AlertDialog(
//             backgroundColor: Colors.white,
//               contentPadding: EdgeInsets.zero,
//               insetPadding: EdgeInsets.zero,
//               title: Text(widget.title),
//               content:
//               Container(
//
//                     width: kIsWeb ? 500 : MediaQuery.of(context).size.width * 0.8,
//                     height: kIsWeb ? 500 : MediaQuery.of(context).size.height * 0.5,
//
//                 child: Scaffold(
//                  appBar:PreferredSize(
//
//                      child: Column(
//                        crossAxisAlignment: CrossAxisAlignment.start,
//                        children: [
//                          SizedBox(
//                            height: 20,
//                          ),
//                          Container(
//
//                            decoration: BoxDecoration(
//                              color: Colors.white,
//                              boxShadow: [
//                                BoxShadow(
//                                  color: Colors.grey.withOpacity(0.5),
//                                  spreadRadius: 0.1,
//                                  blurRadius: 0.1,
//                                  offset: Offset(0, 1), // changes position of shadow
//                                ),
//                              ],
//                            ),
//                              child: Row(
//                                children: [
//                                  EmojiTabBar(),
//
//                                ],
//                              )
//
//                          ),
//
//
//                        ],
//                      ),
//                      preferredSize: Size(double.infinity, 90)
//                 ),
//
//                   body: TabBarView(
//                     controller: tabController,
//
//
//
//                     children: myTabs.map((Tab tab) {
//                       final String label = tab.text.toLowerCase();
//                       return Center(
//                         child: Text(
//                           'This is the $label tab',
//                           style: const TextStyle(fontSize: 36),
//                         ),
//                       );
//                     }).toList(),
//                   ),
//                 ),
//               )
//
//
//             // ListView.separated(
//             //     separatorBuilder: (conext, index) {
//             //       return (Divider(
//             //         thickness: 1,
//             //       ));
//             //     },
//             //     itemCount: widget.reactions == null && widget.retweets == null ? 1 : widget.reactions == null ? widget.retweets.length : widget.reactions.length,
//             //     itemBuilder: (context, index) {
//             //       return widget.reactions == null && widget.retweets == null
//             //           ? Center(
//             //               child: Text(Strings.nothingYet),
//             //             )
//             //           : widget.reactions != null
//             //               ? ListTile(
//             //                   leading: CircleAvatar(
//             //                     backgroundImage: widget.reactions[index].profileImage !=
//             //                             null
//             //                         ? NetworkImage(widget.reactions[index].profileImage)
//             //                         : AssetImage(
//             //                             'assets/images/person_placeholder.png'),
//             //                   ),
//             //                   title: Text(widget.reactions[index].username),
//             //                 )
//             //               : ListTile(
//             //                   leading: CircleAvatar(
//             //                     backgroundImage:
//             //                         widget.retweets[index].profileImage != null
//             //                             ? NetworkImage(widget.retweets[index].profileImage)
//             //                             : AssetImage(
//             //                                 'assets/images/person_placeholder.png'),
//             //                   ),
//             //                   title: Text(widget.retweets[index].username),
//             //                 );
//             //     }),
//           );
//         })
//     );
//
//
//
//
//   }
// }
//
//
// int index =0;
// class EmojiTabBar extends StatelessWidget {
//   const EmojiTabBar({
//     Key key, this.tabController,
//   }) : super(key: key);
//   final TabController tabController;
//   @override
//   Widget build(BuildContext context) {
//     return TabBar(
//
//       onTap: (index) {
//         index = index;
//
//
//       },
//
//       controller: tabController,
//       isScrollable: true,
//       labelColor: Colors.blue,
//       unselectedLabelColor: Colors.grey,
//       labelStyle: const TextStyle(fontSize: 15),
//       unselectedLabelStyle: const TextStyle(fontSize: 15),
//       indicatorPadding: EdgeInsets.symmetric(horizontal: 20),
//       labelPadding: EdgeInsets.symmetric(horizontal: 20),
//       indicatorColor: Colors.blue,
//       indicatorSize: TabBarIndicatorSize.tab,
//     //indicator: BoxDecoration(color: Colors.grey.withOpacity(.3)),
//     // borderRadius: BorderRadius.circular(10)),
//
//
//
//     tabs: myTabs.map((  Tab tab) {
//
//       print("index  $index");
//     return Row(
//       children: [
//
//         Text(
//           '${tab.text}',
//         style: TextStyle(
//           fontSize: 15,
//         )
//         ),
//
//
//
//
//
//
//       ],
//     );
//
//
//     }).toList(),
//     );
//   }
// }
//
// class EmojisList extends StatelessWidget {
//   const EmojisList({Key key,
//     this.cross, TextEditingController textController, this.tabController})  : _textController = textController, super(key: key);
//
//   final int cross;
//   final TextEditingController _textController;
//   final TabController tabController;
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//         child: TabBarView(
//             controller: tabController,
//             children: emojis.map((e) {
//               final x = e.split(' ');
//               return GridView.builder(
//                   itemCount: x.length,
//                   scrollDirection: Axis.vertical,
//                   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                       crossAxisCount:cross,
//                       mainAxisSpacing: 2,
//                       crossAxisSpacing: 2),
//                   itemBuilder: (context, index) => GestureDetector(
//                       onTap: () {
//                         _textController.text = _textController.text + x[index];
//                       },
//                       child: Container(
//                           decoration: BoxDecoration(
//                               color: Colors.green.shade50,
//                               borderRadius: BorderRadius.circular(10)),
//                           alignment: Alignment.center,
//                           child: FittedBox(
//                               child: Text(x[index],
//                                   style: const TextStyle(fontSize: 30))))));
//             }).toList()));
//   }
// }

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// int index =0;
// class EmojiTabBar extends StatelessWidget {
//   const EmojiTabBar({
//     Key key, this.tabController,
//   }) : super(key: key);
//   final TabController tabController;
//   @override
//   Widget build(BuildContext context) {
//     return TabBar(
//
//       onTap: (index) {
//         index = index;
//
//
//       },
//
//       controller: tabController,
//       isScrollable: true,
//       labelColor: Colors.blue,
//       unselectedLabelColor: Colors.grey,
//       labelStyle: const TextStyle(fontSize: 15),
//       unselectedLabelStyle: const TextStyle(fontSize: 15),
//       indicatorPadding: EdgeInsets.symmetric(horizontal: 20),
//       labelPadding: EdgeInsets.symmetric(horizontal: 20),
//       indicatorColor: Colors.blue,
//       indicatorSize: TabBarIndicatorSize.tab,
//       //indicator: BoxDecoration(color: Colors.grey.withOpacity(.3)),
//       // borderRadius: BorderRadius.circular(10)),
//
//
//
//       tabs: myTabs.map((  Tab tab) {
//
//         print("index  $index");
//         return Row(
//           children: [
//
//             Text(
//                 '${tab.text}',
//                 style: TextStyle(
//                   fontSize: 15,
//                 )
//             ),
//
//
//
//
//
//
//           ],
//         );
//
//
//       }).toList(),
//     );
//   }
// }
//
// class EmojisList extends StatelessWidget {
//   const EmojisList({Key key,
//     this.cross, TextEditingController textController, this.tabController})  : _textController = textController, super(key: key);
//
//   final int cross;
//   final TextEditingController _textController;
//   final TabController tabController;
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Expanded(
//         child: TabBarView(
//             controller: tabController,
//             children: emojis.map((e) {
//               final x = e.split(' ');
//               return GridView.builder(
//                   itemCount: x.length,
//                   scrollDirection: Axis.vertical,
//                   gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//                       crossAxisCount:cross,
//                       mainAxisSpacing: 2,
//                       crossAxisSpacing: 2),
//                   itemBuilder: (context, index) => GestureDetector(
//                       onTap: () {
//                         _textController.text = _textController.text + x[index];
//                       },
//                       child: Container(
//                           decoration: BoxDecoration(
//                               color: Colors.green.shade50,
//                               borderRadius: BorderRadius.circular(10)),
//                           alignment: Alignment.center,
//                           child: FittedBox(
//                               child: Text(x[index],
//                                   style: const TextStyle(fontSize: 30))))));
//             }).toList()));
//   }
// }

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:werfieapp/models/reaction.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/blue_tick.dart';

import '../models/post.dart';
import '../models/profile.dart';
import '../network/controller/other_users_controller.dart';
import '../screens/other_users_profile.dart';
import '../screens/user_profile.dart';

class ReactRetweetDialog extends StatefulWidget {
  final title;
  final List<Reaction1> reactions;
  final List<Retweet> retweets;
  Post post;
  Comment comment;

  ReactRetweetDialog(this.title, {this.reactions, this.retweets, this.post});

  @override
  State<ReactRetweetDialog> createState() => _ReactRetweetDialogState();
}

class _ReactRetweetDialogState extends State<ReactRetweetDialog>
    with SingleTickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    print(
        "Get.find<NewsfeedController>().reactionLoading ${Get.find<NewsfeedController>().reactionLoading}");

    bool isRewerf = false;
    if (widget.title == Strings.peopleWhoRetweeted){
      isRewerf = true;
    }

    return GetBuilder<NewsfeedController>(
      // assignId: true,
      builder: (controller) {
        return AlertDialog(
            backgroundColor: Colors.white,
            contentPadding: EdgeInsets.zero,
            insetPadding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius:
                  kIsWeb ? BorderRadius.circular(20) : BorderRadius.circular(0),
            ),

            // title: Text(widget.title),
            content: SafeArea(
              child: Container(
                  width: kIsWeb ? 0 : MediaQuery.of(context).size.width,
                  height: kIsWeb ? 300 : MediaQuery.of(context).size.height,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: kIsWeb
                            ? MainAxisAlignment.spaceBetween
                            : MainAxisAlignment.start,
                        children: [
                          if (!kIsWeb)
                            IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: Icon(
                                  Icons.arrow_back,
                                )),
                          Spacer(),
                          Text(
                            widget.title,
                            // style: TextStyle(
                            //     fontSize: 20,
                            //     fontWeight: FontWeight.bold,
                            //     color: Colors.black
                            // ),
                            style:
                                Theme.of(context).brightness == Brightness.dark
                                    ? TextStyle(
                                        color: Colors.white,
                                        fontSize: kIsWeb ? 15 : 20,
                                        fontWeight: FontWeight.bold,
                                      )
                                    : TextStyle(
                                        color: Colors.black,
                                        fontSize: kIsWeb ? 15 : 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                          ),
                          Spacer(),
                          if (kIsWeb)
                            IconButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                icon: Icon(
                                  Icons.cancel,
                                )),
                        ],
                      ),

                      !isRewerf ? Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.5),
                              spreadRadius: 0.1,
                              blurRadius: 0.1,
                              offset:
                                  Offset(0, 1), // changes position of shadow
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(
                            left: 15,
                            top: 10,
                          ),
                          child: controller.reactionLoading == true
                              ? Center(
                                  child: CircularProgressIndicator(),
                                )
                              : controller.reaction != null && controller.reaction.data != null && controller.reaction.data.reactionCounts != null
                                  ? Padding(
                                      padding:
                                          const EdgeInsets.only(bottom: 10),
                                      child: Row(
                                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          GestureDetector(
                                            onTap: () async {
                                              await controller.getWhoReacted(
                                                  widget.post.postId,
                                                  reactionType: "all",
                                                  allLikes: 1);
                                            },
                                            child: Row(
                                              children: [
                                                Text(
                                                  "All LIKES",
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                        ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .likes >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller.getWhoReacted(
                                                        widget.post.postId,
                                                        reactionType:
                                                            "like_simple_like",
                                                        allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/like-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .loves >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType:
                                                                "love",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/love-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .loughs >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    print("lough");
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType:
                                                                "lough",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/laugh-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .exciteds >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType:
                                                                "excited",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/excited-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .thanks >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType:
                                                                "thanks",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/thanks-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller.reaction.data
                                                      .reactionCounts[0].crys >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType: "cry",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/cry-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                          SizedBox(
                                            width: 5,
                                          ),
                                          controller
                                                      .reaction
                                                      .data
                                                      .reactionCounts[0]
                                                      .smiles >=
                                                  1
                                              ? GestureDetector(
                                                  onTap: () async {
                                                    await controller
                                                        .getWhoReacted(
                                                            widget.post.postId,
                                                            reactionType:
                                                                "smile",
                                                            allLikes: 0);
                                                  },
                                                  child: Image.asset(
                                                    'assets/reaction_gif/smile-min.png',
                                                    height: 25.0,
                                                    width: 25.0,
                                                  ),
                                                )
                                              : SizedBox(),
                                        ],
                                      ),
                                    )
                                  : SizedBox(),
                        ),
                      ) : Divider(),

                      !isRewerf ? Expanded(
                          child: controller.reactionLoading == true ||
                                  controller.rLoading == true
                              ? Center(
                                  child: CircularProgressIndicator(),
                                )
                              : controller.reaction != null && controller.reaction.data != null && controller.reaction.data.reactedUser != null
                                  ? ListView.separated(
                                      separatorBuilder: (conext, index) {
                                        return (Divider(
                                          thickness: 1,
                                        ));
                                      },
                                      itemCount: controller
                                                  .reaction.data.reactedUser ==
                                              null
                                          ? 1
                                          : controller
                                              .reaction.data.reactedUser.length,
                                      itemBuilder: (context, index) {
                                        return controller.reaction.data
                                                    .reactedUser ==
                                                null
                                            ? Center(
                                                child: Text(
                                                  Strings.nothingYet,
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                ),
                                              )
                                            : GestureDetector(
                                                onTap: kIsWeb
                                                    ? () async {
                                                        if (GetStorage()
                                                                .read('id') ==
                                                            controller
                                                                .reaction
                                                                .data
                                                                .reactedUser[
                                                                    index]
                                                                .userId) {
                                                          print(
                                                              "react screen ");
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .isTrendsScreen =
                                                              false;
                                                          controller
                                                                  .isNewsFeedScreen =
                                                              false;
                                                          controller
                                                                  .isBrowseScreen =
                                                              false;
                                                          controller
                                                                  .isNotificationScreen =
                                                              false;
                                                          controller
                                                                  .isChatScreen =
                                                              false;
                                                          controller
                                                                  .isSavedPostScreen =
                                                              false;
                                                          controller
                                                                  .isPostDetails =
                                                              false;
                                                          controller
                                                                  .isProfileScreen =
                                                              true;
                                                          controller
                                                                  .isOtherUserProfileScreen =
                                                              false;
                                                          controller.update();
                                                        } else {
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .isTrendsScreen =
                                                              false;
                                                          controller
                                                                  .isNewsFeedScreen =
                                                              false;
                                                          controller
                                                                  .isBrowseScreen =
                                                              false;
                                                          controller
                                                                  .isNotificationScreen =
                                                              false;
                                                          controller
                                                                  .isChatScreen =
                                                              false;
                                                          controller
                                                                  .isSavedPostScreen =
                                                              false;
                                                          controller
                                                                  .isPostDetails =
                                                              false;
                                                          controller
                                                                  .isProfileScreen =
                                                              false;
                                                          controller
                                                                  .isOtherUserProfileScreen =
                                                              true;
                                                          controller
                                                                  .otherUserName =
                                                              controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .username;
                                                          controller
                                                                  .otherUserId =
                                                              controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId;
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              UserProfile();
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              await controller
                                                                  .getOtherUserProfile(controller
                                                                      .reaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .userId);

                                                          await Get.find<
                                                                  OtherUserController>()
                                                              .filterUsersPostPagged(
                                                                  "posts",
                                                                  page: 1);
                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts[0]
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;

                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;
                                                            print(
                                                                "element.mute  ${element.mute}");
                                                          });

                                                          controller.update();
                                                        }
                                                      }
                                                    : () async {
                                                        if (GetStorage()
                                                                .read('id') ==
                                                            controller
                                                                .reaction
                                                                .data
                                                                .reactedUser[
                                                                    index]
                                                                .userId) {
                                                          Navigator.pop(
                                                              context);
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  ProfileScreen(
                                                                controller:
                                                                    controller,
                                                              ),
                                                            ),
                                                          );
                                                        } else {
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .otherUserName =
                                                              controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .username;
                                                          controller
                                                                  .otherUserId =
                                                              controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId;
                                                          controller.update();
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  OtherUsersProfile(
                                                                controller:
                                                                    controller,
                                                              ),
                                                            ),
                                                          );

                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              UserProfile();
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              await controller
                                                                  .getOtherUserProfile(controller
                                                                      .reaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .userId);

                                                          await Get.find<
                                                                  OtherUserController>()
                                                              .filterUsersPostPagged(
                                                                  "posts",
                                                                  page: 1);
                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts[0]
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;

                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;
                                                            print(
                                                                "element.mute  ${element.mute}");
                                                          });

                                                          controller.update();
                                                        }
                                                      },
                                                child: ListTile(
                                                  leading: Stack(
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage: controller
                                                                    .reaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .profileImage !=
                                                                null
                                                            ? NetworkImage(
                                                                controller
                                                                    .reaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .profileImage)
                                                            : AssetImage(
                                                                'assets/images/person_placeholder.png'),
                                                      ),
                                                      controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .type ==
                                                              "love"
                                                          ? Positioned(
                                                              bottom: 1,
                                                              right: 0.1,
                                                              child:
                                                                  Image.asset(
                                                                'assets/reaction_gif/love-min.png',
                                                                height: 20.0,
                                                                width: 20.0,
                                                              ),
                                                            )
                                                          : controller
                                                                      .reaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .type ==
                                                                  "like_simple_like"
                                                              ? Positioned(
                                                                  bottom: 1,
                                                                  right: 0.1,
                                                                  child: Image
                                                                      .asset(
                                                                    'assets/reaction_gif/like-min.png',
                                                                    height:
                                                                        20.0,
                                                                    width: 20.0,
                                                                  ),
                                                                )
                                                              : controller
                                                                          .reaction
                                                                          .data
                                                                          .reactedUser[
                                                                              index]
                                                                          .type ==
                                                                      "smile"
                                                                  ? Positioned(
                                                                      bottom: 1,
                                                                      right:
                                                                          0.1,
                                                                      child: Image
                                                                          .asset(
                                                                        'assets/reaction_gif/smile-min.png',
                                                                        height:
                                                                            20.0,
                                                                        width:
                                                                            20.0,
                                                                      ),
                                                                    )
                                                                  : controller
                                                                              .reaction
                                                                              .data
                                                                              .reactedUser[
                                                                                  index]
                                                                              .type ==
                                                                          "cry"
                                                                      ? Positioned(
                                                                          bottom:
                                                                              1,
                                                                          right:
                                                                              0.1,
                                                                          child:
                                                                              Image.asset(
                                                                            'assets/reaction_gif/cry-min.png',
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          ),
                                                                        )
                                                                      : controller.reaction.data.reactedUser[index].type ==
                                                                              "thanks"
                                                                          ? Positioned(
                                                                              bottom: 1,
                                                                              right: 0.1,
                                                                              child: Image.asset(
                                                                                'assets/reaction_gif/thanks-min.png',
                                                                                height: 20.0,
                                                                                width: 20.0,
                                                                              ),
                                                                            )
                                                                          : controller.reaction.data.reactedUser[index].type == "lough"
                                                                              ? Positioned(
                                                                                  bottom: 1,
                                                                                  right: 0.1,
                                                                                  child: Image.asset(
                                                                                    'assets/reaction_gif/laugh-min.png',
                                                                                    height: 20.0,
                                                                                    width: 20.0,
                                                                                  ),
                                                                                )
                                                                              : controller.reaction.data.reactedUser[index].type == "excited"
                                                                                  ? Positioned(
                                                                                      bottom: 1,
                                                                                      right: 0.1,
                                                                                      child: Image.asset(
                                                                                        'assets/reaction_gif/excited-min.png',
                                                                                        height: 20.0,
                                                                                        width: 20.0,
                                                                                      ),
                                                                                    )
                                                                                  : SizedBox(),
                                                    ],
                                                  ),
                                                  title: Row(
                                                    children: [
                                                      Text(
                                                        controller
                                                            .reaction
                                                            .data
                                                            .reactedUser[index]
                                                            .username,
                                                        style: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                              )
                                                            : TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                              ),
                                                      ),
                                                      controller
                                                                  .reaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .accountVerified ==
                                                              "verified"
                                                          ? Wrap(children: [
                                                              SizedBox(
                                                                width: 2,
                                                              ),
                                                              BlueTick(
                                                                height: 15,
                                                                width: 15,
                                                                iconSize: 12,
                                                              )
                                                            ])
                                                          : SizedBox()
                                                    ],
                                                  ),
                                                ),
                                              );
                                      })
                                  : ListView.separated(
                                      separatorBuilder: (conext, index) {
                                        return (Divider(
                                          thickness: 1,
                                        ));
                                      },
                                      itemCount: controller.allReaction == null || controller.allReaction.data == null || controller.allReaction.data
                                                  .reactedUser ==
                                              null
                                          ? 1
                                          : controller.allReaction.data
                                              .reactedUser.length,
                                      itemBuilder: (context, index) {
                                        return controller.allReaction == null || controller.allReaction.data == null || controller.allReaction.data
                                                    .reactedUser ==
                                                null
                                            ? Center(
                                                child: Text(
                                                  Strings.nothingYet,
                                                  style: Theme.of(context)
                                                              .brightness ==
                                                          Brightness.dark
                                                      ? TextStyle(
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        )
                                                      : TextStyle(
                                                          color: Colors.black,
                                                          fontWeight:
                                                              FontWeight.w700,
                                                        ),
                                                ),
                                              )
                                            : GestureDetector(
                                                onTap: kIsWeb
                                                    ? () async {
                                                        if (GetStorage()
                                                                .read('id') ==
                                                            controller
                                                                .allReaction
                                                                .data
                                                                .reactedUser[
                                                                    index]
                                                                .userId) {
                                                          print(
                                                              "react screen ");
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .isTrendsScreen =
                                                              false;
                                                          controller
                                                                  .isNewsFeedScreen =
                                                              false;
                                                          controller
                                                                  .isBrowseScreen =
                                                              false;
                                                          controller
                                                                  .isNotificationScreen =
                                                              false;
                                                          controller
                                                                  .isChatScreen =
                                                              false;
                                                          controller
                                                                  .isSavedPostScreen =
                                                              false;
                                                          controller
                                                                  .isPostDetails =
                                                              false;
                                                          controller
                                                                  .isProfileScreen =
                                                              true;
                                                          controller
                                                                  .isOtherUserProfileScreen =
                                                              false;
                                                          controller.update();
                                                        } else {
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .isTrendsScreen =
                                                              false;
                                                          controller
                                                                  .isNewsFeedScreen =
                                                              false;
                                                          controller
                                                                  .isBrowseScreen =
                                                              false;
                                                          controller
                                                                  .isNotificationScreen =
                                                              false;
                                                          controller
                                                                  .isChatScreen =
                                                              false;
                                                          controller
                                                                  .isSavedPostScreen =
                                                              false;
                                                          controller
                                                                  .isPostDetails =
                                                              false;
                                                          controller
                                                                  .isProfileScreen =
                                                              false;
                                                          controller
                                                                  .isOtherUserProfileScreen =
                                                              true;
                                                          controller
                                                                  .otherUserName =
                                                              controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .username;
                                                          controller
                                                                  .otherUserId =
                                                              controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId;
                                                          // print(
                                                          //     "idhr aya hai  ");
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              UserProfile();
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              await controller
                                                                  .getOtherUserProfile(controller
                                                                      .allReaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .userId);

                                                          await Get.find<
                                                                  OtherUserController>()
                                                              .filterUsersPostPagged(
                                                                  "posts",
                                                                  page: 1);
                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts[0]
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;

                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;
                                                            print(
                                                                "element.mute  ${element.mute}");
                                                          });

                                                          controller.update();
                                                        }
                                                      }
                                                    : () async {
                                                        if (GetStorage()
                                                                .read('id') ==
                                                            controller
                                                                .allReaction
                                                                .data
                                                                .reactedUser[
                                                                    index]
                                                                .userId) {
                                                          Navigator.pop(
                                                              context);
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  ProfileScreen(
                                                                controller:
                                                                    controller,
                                                              ),
                                                            ),
                                                          );
                                                        } else {
                                                          Navigator.pop(
                                                              context);
                                                          controller
                                                                  .otherUserName =
                                                              controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .username;
                                                          controller
                                                                  .otherUserId =
                                                              controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .userId;
                                                          controller.update();
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) =>
                                                                  OtherUsersProfile(
                                                                controller:
                                                                    controller,
                                                              ),
                                                            ),
                                                          );

                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              UserProfile();
                                                          Get.find<NewsfeedController>()
                                                                  .userInfo =
                                                              await controller
                                                                  .getOtherUserProfile(controller
                                                                      .allReaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .userId);

                                                          await Get.find<
                                                                  OtherUserController>()
                                                              .filterUsersPostPagged(
                                                                  "posts",
                                                                  page: 1);
                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts[0]
                                                              .mute = Get.find<
                                                                  NewsfeedController>()
                                                              .userInfo
                                                              .muted;

                                                          Get.find<
                                                                  OtherUserController>()
                                                              .userPosts
                                                              .forEach(
                                                                  (element) {
                                                            element
                                                                .mute = Get.find<
                                                                    NewsfeedController>()
                                                                .userInfo
                                                                .muted;
                                                            print(
                                                                "element.mute  ${element.mute}");
                                                          });

                                                          controller.update();
                                                        }
                                                      },
                                                child: ListTile(
                                                  leading: Stack(
                                                    children: [
                                                      CircleAvatar(
                                                        backgroundImage: controller
                                                                    .allReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .profileImage !=
                                                                null
                                                            ? NetworkImage(
                                                                controller
                                                                    .allReaction
                                                                    .data
                                                                    .reactedUser[
                                                                        index]
                                                                    .profileImage)
                                                            : AssetImage(
                                                                'assets/images/person_placeholder.png'),
                                                      ),
                                                      controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .type ==
                                                              "love"
                                                          ? Positioned(
                                                              bottom: 1,
                                                              right: 0.1,
                                                              child:
                                                                  Image.asset(
                                                                'assets/reaction_gif/love-min.png',
                                                                height: 20.0,
                                                                width: 20.0,
                                                              ),
                                                            )
                                                          : controller
                                                                      .allReaction
                                                                      .data
                                                                      .reactedUser[
                                                                          index]
                                                                      .type ==
                                                                  "like_simple_like"
                                                              ? Positioned(
                                                                  bottom: 1,
                                                                  right: 0.1,
                                                                  child: Image
                                                                      .asset(
                                                                    'assets/reaction_gif/like-min.png',
                                                                    height:
                                                                        20.0,
                                                                    width: 20.0,
                                                                  ),
                                                                )
                                                              : controller
                                                                          .allReaction
                                                                          .data
                                                                          .reactedUser[
                                                                              index]
                                                                          .type ==
                                                                      "smile"
                                                                  ? Positioned(
                                                                      bottom: 1,
                                                                      right:
                                                                          0.1,
                                                                      child: Image
                                                                          .asset(
                                                                        'assets/reaction_gif/smile-min.png',
                                                                        height:
                                                                            20.0,
                                                                        width:
                                                                            20.0,
                                                                      ),
                                                                    )
                                                                  : controller
                                                                              .allReaction
                                                                              .data
                                                                              .reactedUser[
                                                                                  index]
                                                                              .type ==
                                                                          "cry"
                                                                      ? Positioned(
                                                                          bottom:
                                                                              1,
                                                                          right:
                                                                              0.1,
                                                                          child:
                                                                              Image.asset(
                                                                            'assets/reaction_gif/cry-min.png',
                                                                            height:
                                                                                20.0,
                                                                            width:
                                                                                20.0,
                                                                          ),
                                                                        )
                                                                      : controller.allReaction.data.reactedUser[index].type ==
                                                                              "thanks"
                                                                          ? Positioned(
                                                                              bottom: 1,
                                                                              right: 0.1,
                                                                              child: Image.asset(
                                                                                'assets/reaction_gif/thanks-min.png',
                                                                                height: 20.0,
                                                                                width: 20.0,
                                                                              ),
                                                                            )
                                                                          : controller.allReaction.data.reactedUser[index].type == "lough"
                                                                              ? Positioned(
                                                                                  bottom: 1,
                                                                                  right: 0.1,
                                                                                  child: Image.asset(
                                                                                    'assets/reaction_gif/laugh-min.png',
                                                                                    height: 20.0,
                                                                                    width: 20.0,
                                                                                  ),
                                                                                )
                                                                              : controller.allReaction.data.reactedUser[index].type == "excited"
                                                                                  ? Positioned(
                                                                                      bottom: 1,
                                                                                      right: 0.1,
                                                                                      child: Image.asset(
                                                                                        'assets/reaction_gif/excited-min.png',
                                                                                        height: 20.0,
                                                                                        width: 20.0,
                                                                                      ),
                                                                                    )
                                                                                  : SizedBox(),
                                                    ],
                                                  ),
                                                  title: Row(
                                                    children: [
                                                      Text(
                                                        controller
                                                            .allReaction
                                                            .data
                                                            .reactedUser[index]
                                                            .username,
                                                        style: Theme.of(context)
                                                                    .brightness ==
                                                                Brightness.dark
                                                            ? TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                              )
                                                            : TextStyle(
                                                                color: Colors
                                                                    .black,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w700,
                                                              ),
                                                      ),
                                                      controller
                                                                  .allReaction
                                                                  .data
                                                                  .reactedUser[
                                                                      index]
                                                                  .accountVerified ==
                                                              "verified"
                                                          ? Wrap(children: [
                                                              SizedBox(
                                                                width: 2,
                                                              ),
                                                              BlueTick(
                                                                height: 15,
                                                                width: 15,
                                                                iconSize: 12,
                                                              )
                                                            ])
                                                          : SizedBox()
                                                    ],
                                                  ),
                                                ),
                                              );
                                      })) : rewerfsWidget(controller),
                      // StatefulBuilder(
                      //     builder: (BuildContext context, StateSetter setState) {
                      //
                      //
                      //   return
                      // }),
                    ],
                  )

                  // Scaffold(
                  //     body:
                  // ),
                  ),
            ));
      },
    );
  }

  Widget rewerfsWidget(NewsfeedController controller) {
    return Expanded(
        child: ListView.separated(
            separatorBuilder: (conext, index) {
              return (Divider(
                thickness: 1,
              ));
            },
            itemCount: widget.retweets == null ? 1 : widget.retweets.length,
            itemBuilder: (context, index) {
              return widget.retweets == null
                  ? Center(
                      child: Text(Strings.nothingYet),
                    )
                  : ListTile(
                          leading: CircleAvatar(
                            backgroundImage: widget.retweets[index].profileImage != null
                                ? NetworkImage(widget.retweets[index].profileImage)
                                : AssetImage('assets/images/person_placeholder.png'),
                          ),
                          title: Text(widget.retweets[index].username),
                        );
            }));
  }
}
