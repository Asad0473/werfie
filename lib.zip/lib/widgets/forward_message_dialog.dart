import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';

import '../utils/font.dart';

class ForwardMessageDialogBox extends StatelessWidget {
  ForwardMessageDialogBox();

  final controller = Get.find<NewsfeedController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<NewsfeedController>(builder: (controller) {
      return SingleChildScrollView(
        child: Container(
          width: kIsWeb ? 500 : MediaQuery.of(context).size.width * 0.9,
          height: kIsWeb ? 500 : MediaQuery.of(context).size.height * 0.6,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding:
                    EdgeInsets.only(left: 12, right: 12, top: 12, bottom: 0),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: Icon(
                        Icons.close,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      ),
                    ),
                    SizedBox(
                      width: 12,
                    ),
                    Text(
                      Strings.forwardMessage,
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    Spacer(),
                    // RoundedButton(
                    //   Strings.next,
                    //   () async {
                    //     if (!kIsWeb) {
                    //       await controller.createChat(controller.idList,
                    //           controller.idList.length > 1 ? "group" : "single",
                    //           groupMemberName: controller.randomGroup);
                    //       controller.chatUserList = await controller.getChat();

                    //       // controller.chatName = controller.randomGroup;

                    //       controller.update();
                    //       // controller.isChatScreenWeb = true;
                    //       Navigator.of(context).pop();

                    //       // Navigator.push(
                    //       //     context,
                    //       //     MaterialPageRoute(
                    //       //         builder: (BuildContext context) =>
                    //       //             ChatScreenMobile(controller)));
                    //     } else {
                    //       await controller.createChat(controller.idList,
                    //           controller.idList.length > 1 ? "group" : "single",
                    //           groupMemberName: controller.randomGroup);
                    //       controller.chatUserList = await controller.getChat();
                    //       for (int i = 0;
                    //           i < controller.selectedMessages.length;
                    //           i++) {
                    //         controller.sendMessage(
                    //             messageData: controller.selectedMessages[i],
                    //             conversationId: controller
                    //                 .chatUserList[controller.forwardToUserId]
                    //                 .conversationId);
                    //         controller.isChatScreenWeb = true;
                    //         controller.chatName = controller
                    //             .chatUserList[controller.forwardToUserId];
                    //         controller.groupName =
                    //             controller.chatName.conversationType == "group"
                    //                 ? "${controller.chatName.name}"
                    //                 : "${controller.chatName.name}";
                    //         controller.infoChatInfo = false;
                    //         controller.createMessage(
                    //             controller.chatName.conversationId);

                    //         controller.update();
                    //       }
                    // controller.chatName = controller.randomGroup;
                    //       controller.update();
                    //       // controller.isChatScreenWeb = true;

                    //       Navigator.of(context).pop();
                    //     }
                    //   },
                    //   horizontalPadding: 30.0,
                    //   verticalPadding: kIsWeb ? 14.0 : 6.0,
                    // ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: TextField(
                  style: LightStyles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black),
                  cursorColor: Theme.of(context).brightness == Brightness.dark
                      ? Colors.white
                      : Colors.black,
                  onChanged: (value) async {
                    // print(value);
                    controller.usersList =
                        await controller.searchChatUser(value);

                    controller.update();
                  },
                  textAlignVertical: TextAlignVertical.center,
                  decoration: InputDecoration(
                    hintText: Strings.searchPeople,
                    hintStyle: LightStyles.baseTextTheme.headline3,
                    prefixIcon: Icon(Icons.search,
                        size: 20,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40),
                      borderSide: BorderSide(
                        width: 1,
                        color: Colors.grey,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(40),
                      borderSide: BorderSide(
                        width: 1,
                        color: Colors.grey,
                      ),
                    ),
                    fillColor: Colors.grey[250],
                  ),
                ),
              ),
              // controller.selectedPeople != null &&
              //         controller.selectedPeople.isNotEmpty
              //     ? Wrap(
              //         children: List.generate(controller.selectedPeople.length,
              //             (index) {
              //           return Padding(
              //             padding: const EdgeInsets.all(8.0),
              //             child: ActionChip(
              //               elevation: 8.0,
              //               padding: EdgeInsets.symmetric(
              //                   vertical: 6, horizontal: 2),
              //               avatar: CircleAvatar(
              //                 radius: 16,
              //                 backgroundColor: Colors.deepPurpleAccent,
              //                 child: Icon(
              //                   Icons.mode_comment,
              //                   color: Colors.white,
              //                   size: 12,
              //                 ),
              //               ),
              //               label: Text(
              //                   controller.selectedPeople[index].toString()),
              //               onPressed: () {
              //                 print("btn is pressed");
              //                 // Navigator.of(context).pop();
              //               },
              //               backgroundColor: Colors.grey[200],
              //               shape: StadiumBorder(
              //                   side: BorderSide(
              //                 width: 1,
              //                 color: Colors.deepPurpleAccent,
              //               )),
              //             ),
              //           );
              //         }),
              //       )
              //     : Container(),
              Divider(),
              Expanded(
                  child: ListView.builder(
                shrinkWrap: true,
                itemCount: controller.usersList == null
                    ? 0
                    : controller.usersList.length,
                itemBuilder: (context, index) => Card(
                  elevation: 2,
                  margin: EdgeInsets.all(10),
                  child: ListTile(
                    onTap: () async {
                      controller.forwardToUserId = index;
                      if (!kIsWeb) {
                        controller.forwardMsgLoading = true;
                        controller.update();
                        List chatIdList = [];
                        chatIdList.add(controller.usersList[index]['id']);

                        Navigator.of(context).pop();

                        await controller
                            .createChat(chatIdList, "single")
                            .then((value) async {
                          await controller.getChat().then((value) {
                            // print(value);
                            value.forEach((element) async {
                              if (element.memberId ==
                                  controller.usersList[index]['id']) {
                                for (int i = 0;
                                    i < controller.selectedMessages.length;
                                    i++) {
                                  // print(
                                  //     'REACHED HERE HER HE RHE EHEHEHEHEHEHEH    EHEHHEHEHHE    HEHHEHEHE');
                                  //
                                  // print(
                                  //     "controller.uploadMedia ${controller.uploadMedia_}");

                                  controller.sendMessage(
                                      scrappingData:
                                          controller.chatScrappingData,
                                      messageData:
                                          controller.selectedMessages[0],
                                      conversationId: element.conversationId,
                                      FileData: controller.uploadMedia_ != null
                                          ? controller.uploadMedia_
                                          : {});

                                  await Future.delayed(Duration(seconds: 2),
                                      () async {
                                    // 5s over, navigate to a new page

                                    controller.update();
                                    // controller.getChatForMessageScreen() is moved to 'new_message' socket listener in new_feed_controller.dart
                                    // While sending message this is helpful here but the user receiving the message should also have
                                    // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
                                    // Below is the link to one of the bug related to this on Asana:  - K
                                    // https://app.asana.com/0/1203291929645086/1204450039764493/f
                                    // await controller.getChatForMessageScreen();
                                    controller.forwardMsgLoading = false;

                                    controller.chatIndex = 0;
                                    controller.highlighteTheChat = 0;
                                    controller.update();

                                    // await  widget.controller.getChat();
                                  });

                                  controller.isImagePickedChat = false;
                                  controller.isVideoPickedChat = false;
                                  controller.isDocumentPickedChat = false;
                                  controller.messageController.clear();
                                  controller.showOverlay = false;
                                  controller.chatName = element;
                                  controller.tempGroupName = "";
                                  controller.tempProfileImageGroupChat = null;
                                  controller.groupName =
                                      controller.chatName.conversationType ==
                                              "group"
                                          ? "${controller.chatName.name}"
                                          : "${controller.chatName.name}";
                                  controller.update();
                                  controller.isVideoThumbnail = false;
                                  controller.videoThumbnail = null;

                                  // print("pressed");
                                  controller.getMessagesOfAConversation(
                                      controller.chatName.conversationId);

                                  controller.update();

                                  // UtilsMethods.toastMessageShow(message:'Message Forwarded Successfully!' );

                                  // Navigator.push(
                                  //   context,
                                  //   MaterialPageRoute(
                                  //     builder: (context) =>
                                  //         ChatScreenMobile(
                                  //             controller),
                                  //   ),
                                  // );

                                  // controller.chatName = controller.chatUserList[index];

                                  // controller.infoChatInfo = false;
                                  // controller
                                  //     .createMessage(element.conversationId);
                                }
                                // element.
                              }
                            });
                          });
                          // controller.chatName = ChatUserModel.fromJson(
                          //     controller.usersList[index]);

                          // print(
                          //     'HHEREEHEHEHEHEHEH AGAIN AGAINA GAIANA AAIUHNSA${controller.usersList[index]}');
                          // print(controller.chatName.username);
                          // controller.groupName =
                          //     controller.chatName.conversationType == "group"
                          //         ? "${controller.chatName.name}"
                          //         : "${controller.chatName.name}";
                          // print(
                          //     'GROUP GROUP GRAOUP GROUP GROUP GROUP GROUP GROUP GROUP{');

                          // for (int i = 0;
                          //     i < controller.selectedMessages.length;
                          //     i++) {
                          //   print(
                          //       'REACHED HERE HER HE RHE EHEHEHEHEHEHEH    EHEHHEHEHHE    HEHHEHEHE');
                          //   controller.sendMessage(
                          //       messageData: controller.selectedMessages[i],
                          //       conversationId:
                          //           controller.chatName.conversationId);
                          //   controller.isChatScreenWeb = true;
                          //   // controller.chatName = controller.chatUserList[index];

                          //   // controller.infoChatInfo = false;
                          //   controller.createMessage(
                          //       controller.chatName.conversationId);

                          //   controller.update();
                          // }
                        });
                      } else {
                        List chatIdList = [];
                        chatIdList.add(controller.usersList[index]['id']);
                        await controller
                            .createChat(chatIdList, "single")
                            .then((value) async {
                          await controller.getChat().then((value) {
                            print(value);

                            print(
                                "controller.usersList[index]['id'] ${controller.usersList[index]['id']} ");
                            value.forEach((element) async {
                              if (element.memberId ==
                                  controller.usersList[index]['id']) {
                                controller.forwardMsgLoading = true;
                                controller.update();
                                for (int i = 0;
                                    i < controller.selectedMessages.length;
                                    i++) {
                                  print(
                                      'REACHED HERE HER HE RHE EHEHEHEHEHEHEH    EHEHHEHEHHE    HEHHEHEHE');
                                  controller.sendMessage(
                                      scrappingData:
                                          controller.chatScrappingData,
                                      messageData:
                                          controller.selectedMessages[i],
                                      conversationId: element.conversationId,
                                      FileData: controller.uploadMedia_ != null
                                          ? controller.uploadMedia_
                                          : {});

                                  await Future.delayed(Duration(seconds: 2),
                                      () async {
                                    // 5s over, navigate to a new page

                                    controller.update();
                                    // controller.getChatForMessageScreen() is moved to 'new_message' socket listener in new_feed_controller.dart
                                    // While sending message this is helpful here but the user receiving the message should also have
                                    // updated conversation list. So, moving this to 'new_message' will update to both sender and receiver.
                                    // Below is the link to one of the bug related to this on Asana:  - K
                                    // https://app.asana.com/0/1203291929645086/1204450039764493/f
                                    // await controller.getChatForMessageScreen();
                                    controller.forwardMsgLoading = false;

                                    controller.chatIndex = 0;
                                    controller.highlighteTheChat = 0;
                                    controller.update();

                                    // await  widget.controller.getChat();
                                  });

                                  controller.isImagePickedChat = false;
                                  controller.isVideoPickedChat = false;
                                  controller.isDocumentPickedChat = false;
                                  controller.messageController.clear();
                                  controller.showOverlay = false;
                                  // print("pressed button on click");
                                  controller.messageController.text = "";

                                  controller.tempGroupName = "";
                                  controller.tempProfileImageGroupChat = null;

                                  controller.focusNode.requestFocus();
                                  controller.isChatScreenWeb = true;
                                  controller.chatName = element;
                                  controller.groupName =
                                      controller.chatName.conversationType ==
                                              "group"
                                          ? "${controller.chatName.name}"
                                          : "${controller.chatName.name}";
                                  controller.infoChatInfo = false;

                                  controller.getMessagesOfAConversation(
                                      controller.chatName.conversationId);

                                  // controller.isChatScreenWeb = false;
                                  // controller.chatName = controller.chatUserList[index];

                                  // controller.infoChatInfo = false;
                                  // controller.createMessage(element.conversationId);
                                  //
                                  // controller.update();
                                }
                                // element.

                                // controller.isChatScreenWeb = true;
                                // controller.chatName = controller.chatUserList[index];

                                // controller.infoChatInfo = false;

                                // print("sdfsdf");
                                // // controller.createMessage(element.conversationId);
                                //
                                // controller.update();
                              }
                            });
                          });
                          // controller.chatName = ChatUserModel.fromJson(
                          //     controller.usersList[index]);

                          // print('HHEREEHEHEHEHEHEH AGAIN AGAINA GAIANA AAIUHNSA${controller.usersList[index]}');
                          // print(controller.chatName.username);
                          // controller.groupName = controller.chatName.conversationType == "group"
                          //         ? "${controller.chatName.name}"
                          //         : "${controller.chatName.name}";
                          // print(
                          //     'GROUP GROUP GRAOUP GROUP GROUP GROUP GROUP GROUP GROUP{');

                          // for (int i = 0;
                          //     i < controller.selectedMessages.length;
                          //     i++) {
                          //   print(
                          //       'REACHED HERE HER HE RHE EHEHEHEHEHEHEH    EHEHHEHEHHE    HEHHEHEHE');
                          //   controller.sendMessage(
                          //       messageData: controller.selectedMessages[i],
                          //       conversationId:
                          //           controller.chatName.conversationId,
                          //     FileData:{},
                          //   );
                          //   controller.isChatScreenWeb = true;
                          //   // controller.chatName = controller.chatUserList[index];
                          //
                          //   // controller.infoChatInfo = false;
                          //   controller.createMessage(
                          //       controller.chatName.conversationId);
                          //
                          //   controller.update();
                          // }
                        });
                        // await controller.createChat(controller.idList,
                        //     controller.idList.length > 1 ? "group" : "single",
                        //     groupMemberName: controller.randomGroup);

                        // controller.chatName = controller.randomGroup;
                        // controller.update();
                        // controller.isChatScreenWeb = true;

                        Navigator.of(context).pop();
                      }

                      controller.update();
                    },
                    leading: controller.usersList[index]['conversationType'] !=
                            "group"
                        ? CircleAvatar(
                            backgroundImage: controller.usersList[index]
                                        ['profile_image'] !=
                                    null
                                ? NetworkImage(controller.usersList[index]
                                    ['profile_image'])
                                : AssetImage(
                                    'assets/images/person_placeholder.png'),
                            radius: 22,
                          )
                        : CircleAvatar(
                            backgroundImage: controller.usersList[index]
                                        ['groupImage'] !=
                                    null
                                ? NetworkImage(
                                    controller.usersList[index]['groupImage'])
                                : AssetImage('assets/images/image.jpg'),
                            radius: 22,
                          ),
                    title: Text(
                      controller.usersList[index]['username'],
                      style: Styles.baseTextTheme.headline2.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    subtitle: Text(
                      controller.usersList[index]['latest_message'] == null
                          ? ""
                          : controller.usersList[index]['latest_message'],
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: Styles.baseTextTheme.headline4.copyWith(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontSize: kIsWeb ? 14 : 12,
                      ),
                    ),
                  ),
                ),
              ))
            ],
          ),
        ),
      );
    });
  }
}
