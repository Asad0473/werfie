import 'dart:convert';
import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:g_recaptcha_v3/g_recaptcha_v3.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:routemaster/routemaster.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:the_apple_sign_in/scope.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:werfieapp/components/custom_dialog.dart';
import 'package:werfieapp/components/input_field.dart';
import 'package:werfieapp/components/input_password_field.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:http/http.dart' as http;

import 'package:werfieapp/network/controller/login_controller.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/network/singleTone.dart';
import 'package:werfieapp/screens/main_screen.dart';
import 'package:werfieapp/utils/asset_string.dart';
import 'package:werfieapp/utils/fluro_router.dart';
import 'package:werfieapp/utils/logging_utils.dart';
import 'package:werfieapp/utils/routes.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/web_views/web_guest_user/components/textButton.dart';
import 'package:werfieapp/widgets/custom_imageview.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/auth_back_ground.dart';
import 'package:werfieapp/widgets/sign_in_sign_up_widget/custom_image_view.dart';

import '../screens/reset_password_screen.dart';
import '../services/AuthService.dart';
import '../services/captcha_service.dart';
import '../utils/colors.dart';
import '../utils/font.dart';
import '../utils/loading_dialog_builder.dart';
import '../web_views/web_view_screen.dart';
import 'dialogs/LoginWithWorldNoorDialog.dart';

class loginForm extends StatefulWidget {
  int isFromWorldNoorApp;
  bool isAutoLogin = false;

  loginForm(BuildContext context, controller, formKey, id,
      {this.isFromWorldNoorApp = 0,this.isAutoLogin = false});

  @override
  State<loginForm> createState() => _loginFormState();
}

class _loginFormState extends State<loginForm> {
  int id;

  LoginController controller = Get.find<LoginController>();
  var languageDropVal = 'English';

  SharedPreferences shared;

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  final storage = GetStorage();

  bool errorText = false;
  bool isCaptchaSelected = false;
  String createdViewId = 'map_element';

  bool isCheckedGlobal = false;
  WebViewController webviewController;
  bool validationcheck = false;
  String email = '';
  String password = '';

  String get emailError {
    final text = controller.email.text;
    if (text.isEmpty) {
      return Strings.emailFieldCannotBeEmpty;
    } else if (!RegExp(
            r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(text)) {
      return Strings.pleaseProvideAValidEmail;
    } else
      return null;
  }

  String get passwordError {
    final text = controller.password.text;
    if (text.isEmpty) {
      return Strings.passwordCannotBeEmpty;
    } else if (text.length < 8) {
      return 'Password should be at least 8 character long';
    } else
      return null;
  }

  static const platform = const MethodChannel('worldnoor');

  Future<Map<String, dynamic>> futureBuilderGetDataFromWorldNoorApp;

  @override
  void initState() {
    // TODO: implement initState
    // ignore: undefined_prefixed_name
    /*  ui.platformViewRegistry.registerViewFactory(
      createdViewId,
          (int viewId) => html.IFrameElement()
        ..style.height = '100%'
        ..style.width = '100%'
        ..src = 'assets/webpages/index.html' // Path to your HTML file containing the reCAPTCHA widget.
        ..style.border = 'none',
    );*/

    if (!kIsWeb) {
      if (Platform.isAndroid || Platform.isIOS) {
        futureBuilderGetDataFromWorldNoorApp = getDataFromWorldNoorApp();
      }
    /*  webviewController = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(Colors.transparent)
        ..addJavaScriptChannel("Captcha",
            onMessageReceived: (JavaScriptMessage message) {

          LoggingUtils.printValue("Captcha Token", message.message);
          verifyCaptchaToken(message.message);
          //GGOGLE spi csll to verify token
        })
        ..setNavigationDelegate(
          NavigationDelegate(
            onProgress: (int progress) {
              // Update loading bar.
            },
            onPageStarted: (String url) {
              print(url);
            },
            onPageFinished: (String url) {
              print(url);
            },
            onWebResourceError: (WebResourceError error) {},
            // onNavigationRequest: (NavigationRequest request) {
            //   if (request.url.startsWith('https://www.youtube.com/')) {
            //     return NavigationDecision.prevent;
            //   }
            //   return NavigationDecision.navigate;
            // },
          ),
        )
        ..loadRequest(
            Uri.parse("https://api-staging.werfie.com/werfie-captcha"));

      // ..loadRequest(Uri.parse('assets/webpages/index.html'));*/
    }
    // print("msggggg");

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
     // color: Colors.grey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 30),
          kIsWeb && id == 1
              ? MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: GestureDetector(
                    onTap: () async {
                      shared = await SharedPreferences.getInstance();
                      shared.setBool('guestUser', true);
                      Routemaster.of(context).push(
                        AppRoute.guestUserMainScreen,
                      );
                    },
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Icon(
                        Icons.cancel,
                        size: 20,
                        color: Colors.black,
                      ),
                    ),
                  ),
                )
              : SizedBox(),
          kIsWeb
              ? Align(
                  alignment: Alignment.center,
                  child: Text(
                    Strings.login,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                )
              : Container(
                  width: 250,
                  // height: 150,
                  // color: Colors.grey,
                  child: Image.asset(
                    AppImages.logo,
                  ),
                ),
          !kIsWeb
              ? Align(
                  alignment: Alignment.center,
                  child: Text(
                    Strings.login,
                    style: Styles.baseTextTheme.headline2.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                )
              : SizedBox(),
          SizedBox(height: 10),
          //  SizedBox(height: 30),
          Form(
            key: formKey,
            child: Column(
              children: [
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): EnterName(),
                  },
                  child: Actions(
                    actions: {
                      EnterName: CallbackAction<EnterName>(onInvoke: (_) {
                        controller.focus1.unfocus();
                        FocusScope.of(context).requestFocus(controller.focus2);
                      }),
                    },
                    child: Container(
                      // height: 55,
                      child: errorText == false
                          ?

                      InputField(
                              focusNode: controller.focus1,

                              TextInputAction: TextInputAction.next,
                              onChanged: (value) {
                                setState(() {
                                  email = value;
                                });
                              },
                              hint: /*Strings.enterYourEmail*/ "Email / Phone",

                              onValueEntered: (_) {},
                              // onValueEntered: (value) {
                              //   print('value will be' + value);
                              //   value = email.text;
                              // },
                              controller: controller.email,
                              /*validator: (value) {
                                return UtilsMethods.validateEmail(value);
                              },*/
                              textInputType: TextInputType.emailAddress,
                              fieldIcon: Icons.account_circle_rounded,
                            )
                          : ValueListenableBuilder(
                              valueListenable: controller.email,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputField(
                                  focusNode: controller.focus1,

                                  TextInputAction: TextInputAction.next,
                                  onChanged: (value) {
                                    setState(() {
                                      email = value;
                                    });
                                  },
                                  hint: /*Strings.enterYourEmail*/ "Email / Phone",

                                  onValueEntered: (_) {},
                                  // onValueEntered: (value) {
                                  //   print('value will be' + value);
                                  //   value = email.text;
                                  // },
                                  controller: controller.email,
                                  //errorText: emailError,
                                 /* validator: (value) {
                                    return UtilsMethods.validateEmail(value);
                                  },*/
                                  textInputType: TextInputType.text,
                                  fieldIcon: Icons.account_circle_rounded,
                                );
                              },
                              // child: ,
                            ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): EnterPasswords(),
                  },
                  child: Actions(
                    actions: {
                      EnterPasswords:
                          CallbackAction<EnterPasswords>(onInvoke: (_) {
                        controller.focus2.unfocus();
                        FocusScope.of(context).requestFocus(controller.focus3);
                      }),
                    },
                    child: errorText == false
                        ? InputPasswordField(
                            focusNode: controller.focus2,
                            nextNode: controller.focus4,
                            TextInputAction: TextInputAction.next,
                            onChanged: (value) {
                              setState(() {
                                password = value;
                              });
                            },
                            text: Strings.enterYourPassword,
                            controller: controller.password,
                            validator: (value) {
                              return UtilsMethods.validatePassword(value);
                            },
                          )
                        : Container(
                            child: ValueListenableBuilder(
                              valueListenable: controller.password,
                              builder: (BuildContext context,
                                  TextEditingValue value, Widget child) {
                                return InputPasswordField(
                                  focusNode: controller.focus2,
                                  nextNode: controller.focus4,
                                  TextInputAction: TextInputAction.next,
                                  onChanged: (value) {
                                    setState(() {
                                      password = value;
                                    });
                                    debugPrint('PassWord 1---->>> ${password}');
                                  },
                                  text: Strings.enterYourPassword,
                                  controller: controller.password,
                                  errorText: passwordError,
                                  validator: (value) {
                                    return UtilsMethods.validatePassword(value);
                                  },
                                );
                              },
                              //  child: ,
                            ),
                          ),
                  ),
                ),

                SizedBox(height: 10),
                // id==2?SizedBox():
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): LostPassword(),
                  },
                  child: Actions(
                    actions: {
                      LostPassword: CallbackAction<LostPassword>(onInvoke: (_) {
                        controller.focus3.unfocus();
                        FocusScope.of(context).requestFocus(controller.focus4);
                      }),
                    },
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 15.0),
                        child: TextButton(
                          onPressed: () {
                            formKey.currentState?.reset();
                            if (!kIsWeb) {
                              Get.to(
                                // MaterialPageRoute(
                                //   builder: (context) =>
                                ResetPasswordScreen(),
                                // ),
                              );
                            } else {
                              Navigator.pop(context);
                              Get.toNamed(FluroRouters.resetPasswordScreen);
                              /* Routemaster.of(context).push(
                              AppRoute.resetPasswordScreen,
                            );*/
                            }
                          },
                          focusNode: controller.focus3,
                          child: Text(
                            Strings.lostPassword,
                            style: TextStyle(
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                                fontWeight: FontWeight.w500,
                                fontSize: 14),
                            // style: TextStyle(
                            //   color: Colors.black,
                            //   fontSize: 13,
                            // ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                // Container(
                //   height: 200,
                //   child: Directionality(
                //     textDirection: TextDirection.ltr,
                //     child: HtmlElementView(
                //       viewType: createdViewId,
                //     ),
                //   ),
                // ),

                // kIsWeb? Container(
                // ):  Container(height:200,
                //       width: 200,
                //       color: Colors.deepOrange,
                //       child: WebViewWidget(controller: webviewController)),
                /// login button
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): LoginButton(),
                  },
                  child: Actions(
                      actions: {
                        LoginButton: CallbackAction<LoginButton>(onInvoke: (_) {
                          controller.focus4.unfocus();
                          FocusScope.of(context).requestFocus(controller.focus5);
                        }),
                      },
                      child: Container(
                        width: Get.width,
                        child: RawKeyboardListener(
                          focusNode: controller.LoginFocusNode,
                          onKey: (RawKeyEvent event) async {
                            if (event.logicalKey == LogicalKeyboardKey.enter) {
                              if (email.isNotEmpty && password.isNotEmpty) {
                                if (formKey.currentState.validate()) {
                                  DialogBuilder(context).showLoadingIndicator();
                                  // print("Print me");
                                  if (kIsWeb) {
                                    bool _isNotABot =
                                        await RecaptchaService.isNotABot();

                                    if (!_isNotABot) {
                                      Fluttertoast.showToast(
                                          msg:
                                              'It seems like you are a robot. please verify again',
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.CENTER,
                                          timeInSecForIosWeb: 1,
                                          backgroundColor: Colors.red,
                                          textColor: Colors.white,
                                          fontSize: 16.0);
                                      DialogBuilder(context).hideOpenDialog();
                                      return;
                                    }
                                  }

                                  /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/
                                  // if(!isCaptchaSelected){
                                  //   Fluttertoast.showToast(
                                  //       msg: 'Please check the captcha',
                                  //       toastLength: Toast.LENGTH_SHORT,
                                  //       gravity: ToastGravity.CENTER,
                                  //       timeInSecForIosWeb: 1,
                                  //       backgroundColor: Colors.red,
                                  //       textColor: Colors.white,
                                  //       fontSize: 16.0);
                                  //   return;
                                  // }

                                  var response = await controller
                                      .login(queryParameters: {
                                    "email": controller.email.text,
                                    "password": controller.password.text
                                  }, token: {
                                    "Authorization": " Bearer ${Url.webAPIKey}"
                                  });

                                  var jsonResponse =
                                      jsonDecode(response.toString());
                                  // print("jsonResponse $jsonResponse");

                                  var responseCode = jsonResponse['meta']['code'];
                                  var responseMessage =
                                      jsonResponse['meta']['message'];
                                  var userName = jsonResponse['data']['username'];
                                  var token = jsonResponse['data']['token'];
                                  var userId = jsonResponse['data']['id'];
                                  var email = jsonResponse['data']['email'];
                                  shared = await SharedPreferences.getInstance();
                                  if (responseCode == 200) {
                                    controller.updateInitialWelcomeMsg(true);


                                    shared.setString("email", email.toString());

                                    shared.setString("token", token.toString());
                                    shared.setString(
                                        "userName", userName.toString());
                                    shared.setBool('guestUser', true);
                                    shared.setBool('socialLogin', false);
                                    storage.write('id', userId);
                                    storage.write("token", token.toString());
                                    storage.write("email", email.toString());

                                    storage.write(
                                        "CurrentEmail", controller.email.text);

                                    storage.write(
                                        "userName", userName.toString());

                                    storage.write("remember", isCheckedGlobal);

                                    controller.email.clear();
                                    controller.password.clear();
                                    controller.generateFCMToken(context);
                                    //  NewsfeedController newsfeedController;
                                    // newsfeedController=
                                    if (Get.isRegistered<NewsfeedController>()) {
                                      Get.delete<NewsfeedController>();
                                      if (kDebugMode) {
                                        print(
                                            'newfees controller is removed at login  controller1');
                                      }
                                      Get.put(NewsfeedController(
                                        linkId: controller.postId != null
                                            ? controller.postId
                                            : null,
                                        profileId: controller.profileId != null
                                            ? controller.profileId
                                            : null,
                                      ));
                                    } else {
                                      Get.put(NewsfeedController(
                                        linkId: controller.postId != null
                                            ? controller.postId
                                            : null,
                                        profileId: controller.profileId != null
                                            ? controller.profileId
                                            : null,
                                      ));
                                      if (kDebugMode) {

                                      }
                                    }

                                    // newsfeedController .languageData= await newsfeedController.getLanguages();
                                    Get.find<NewsfeedController>().languageData =
                                        await Get.find<NewsfeedController>()
                                            .getLanguages();
                                    int index = Get.find<NewsfeedController>()
                                        .languagesList
                                        .indexWhere((element) {
                                      return Get.find<NewsfeedController>()
                                              .languageData
                                              .appLang
                                              .id ==
                                          element.id;
                                    });

                                    int index2 = Get.find<NewsfeedController>()
                                        .translationLanguage
                                        .indexWhere((element) {
                                      return Get.find<NewsfeedController>()
                                              .languageData
                                              .myLang
                                              .id ==
                                          element.id;
                                    });

                                    Get.find<NewsfeedController>().dropdownValue =
                                        Get.find<NewsfeedController>()
                                            .languagesList[index];

                                    Get.find<NewsfeedController>()
                                            .dropdownValue1 =
                                        Get.find<NewsfeedController>()
                                            .translationLanguage[index2];

                                    // print("idhr sdfsdf");

                                    // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                    //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                    //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                    //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                    // );
                                    //
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                    Get.find<NewsfeedController>()
                                            .selectedAppLanguageInfoId =
                                        Get.find<NewsfeedController>()
                                            .languageData
                                            .appLang
                                            .id;

                                    Get.find<NewsfeedController>().upDateLocale(
                                        Get.find<NewsfeedController>()
                                            .languageData
                                            .appLang
                                            .code);
                                    Get.find<NewsfeedController>().update();

                                    if (kIsWeb) {
                                      if (id == 2) {
                                        SingleTone.instance.socialLogin = false;
                                        DialogBuilder(context).hideOpenDialog();

                                        // Navigator.pop(context);
                                        // Routemaster.of(context).pop();

                                        String userName =
                                            shared.getString("userName");
                                        // print({
                                        //   "userName on mainScreen :  $userName"
                                        // });
                                        // print(
                                        //     'postsid:${controller.postId}');
                                        // print(
                                        //     'profileId:${controller.profileId}');
                                        Get.offNamed(FluroRouters.mainScreen);

                                        // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                        //
                                        //
                                        //   "userName": shared.getString("userName"),
                                        //   "postId": controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   "profileId": controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null
                                        // });
                                      } else {
                                        SingleTone.instance.socialLogin = false;
                                        // Routemaster.of(context).pop();
                                        // Navigator.pop(context);
                                        DialogBuilder(context).hideOpenDialog();

                                        String userName =
                                            shared.getString("userName");
                                        // print({
                                        //   "userName on mainScreen :  $userName"
                                        // });
                                        // print(
                                        //     'postsid:${controller.postId}');
                                        // print(
                                        //     'profileId:${controller.profileId}');
                                        Get.offNamed(FluroRouters.mainScreen);

                                        // Routemaster.of(context).replace(
                                        //     AppRoute.mainScreen, queryParameters: {
                                        //
                                        //
                                        //   "userName": shared.getString("userName"),
                                        //   "postId": controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   "profileId": controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null
                                        // });
                                      }
                                    } else {
                                      SingleTone.instance.socialLogin = false;
                                      // Get.back();
                                      DialogBuilder(context).hideOpenDialog();

                                      Get.offAll(MainScreen(isLoggedInFromPosh: true,), arguments: {
                                        "userName": shared.getString("userName"),
                                        "postId": controller.postId != null
                                            ? controller.postId
                                            : null,
                                        "profileId": controller.profileId != null
                                            ? controller.profileId
                                            : null
                                      });
                                    }

                                    // Get.offAll(MainScreen(
                                    //   userName: shared.getString("userName"),
                                    //   postId: controller.postId != null
                                    //       ? controller.postId
                                    //       : null,
                                    //   profileId: controller.profileId != null
                                    //       ? controller.profileId
                                    //       : null,
                                    // ));
                                    // Navigator.of(context).pushAndRemoveUntil(
                                    //     MaterialPageRoute(
                                    //         builder: (context) => MainScreen(
                                    //               userName: userName,
                                    //               postId: controller.postId != null
                                    //                   ? controller.postId
                                    //                   : null,
                                    //               profileId: controller.profileId != null
                                    //                   ? controller.profileId
                                    //                   : null,
                                    //             )),
                                    //     (Route<dynamic> route) => false);
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (BuildContext context) =>
                                    //         MainScreen(userName: userName),
                                    // ),
                                    // );
                                  } else if (responseCode == 204) {
                                    DialogBuilder(context).hideOpenDialog();
                                    Fluttertoast.showToast(
                                        msg: responseMessage,
                                        toastLength: Toast.LENGTH_LONG,
                                        timeInSecForIosWeb: 5);
                                    Navigator.pop(context);
                                    showDialog(
                                      context: context,
                                      builder: (context) => OtpDialog(
                                        onSubmit: (otp) async {
                                          DialogBuilder(context)
                                              .showLoadingIndicator();

                                          var response = await controller
                                              .login(queryParameters: {
                                            "email": controller.email.text,
                                            "password": controller.password.text,
                                            "code": otp
                                          }, token: {
                                            "Authorization":
                                                " Bearer ${Url.webAPIKey}"
                                          });
                                          var jsonResponse =
                                              jsonDecode(response.toString());

                                          // print("jsonResponse $jsonResponse");

                                          var responseCode =
                                              jsonResponse['meta']['code'];
                                          var responseMessage =
                                              jsonResponse['meta']['message'];
                                          var userName =
                                              jsonResponse['data']['username'];
                                          var token =
                                              jsonResponse['data']['token'];
                                          var userId = jsonResponse['data']['id'];

                                          var email =
                                              jsonResponse['data']['email'];

                                          DialogBuilder(context).hideOpenDialog();

                                          if (responseCode == 200) {
                                            shared.setString(
                                                "token", token.toString());
                                            shared.setString(
                                                "userName", userName.toString());

                                            shared.setString(
                                                "email", email.toString());

                                            storage.write(
                                                "email", email.toString());

                                            shared.setBool('guestUser', true);
                                            shared.setBool('socialLogin', false);
                                            storage.write('id', userId);
                                            storage.write(
                                                "token", token.toString());

                                            storage.write("CurrentEmail",
                                                controller.email.text);
                                            storage.write(
                                                "userName", userName.toString());

                                            storage.write(
                                                "remember", isCheckedGlobal);

                                            controller.email.clear();
                                            controller.password.clear();
                                            controller.generateFCMToken(context);
                                            if (Get.isRegistered<
                                                NewsfeedController>()) {
                                              Get.delete<NewsfeedController>();
                                              if (kDebugMode) {
                                                print(
                                                    'newfees controller is removed at login  controller0');
                                              }
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));
                                            } else {
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));
                                              if (kDebugMode) {
                                                print(
                                                    'newfees controller is initalized at login  controller0');
                                              }
                                            }

                                            // Get.put(NewsfeedController(
                                            //   linkId: controller.postId != null ? controller.postId : null,
                                            //   profileId: controller.profileId != null ? controller.profileId : null,
                                            // ));

                                            Get.find<NewsfeedController>()
                                                .languageData = await Get.find<
                                                    NewsfeedController>()
                                                .getLanguages();
                                            int index =
                                                Get.find<NewsfeedController>()
                                                    .languagesList
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .id ==
                                                  element.id;
                                            });

                                            int index2 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .myLang
                                                      .id ==
                                                  element.id;
                                            });

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue =
                                                Get.find<NewsfeedController>()
                                                    .languagesList[index];

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue1 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage[index2];

                                            // print("idhr sdfsdf");

                                            // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                            //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                            //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                            //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                            // );
                                            //
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                            Get.find<NewsfeedController>()
                                                    .selectedAppLanguageInfoId =
                                                Get.find<NewsfeedController>()
                                                    .languageData
                                                    .appLang
                                                    .id;

                                            Get.find<NewsfeedController>()
                                                .upDateLocale(
                                                    Get.find<NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .code);
                                            Get.find<NewsfeedController>()
                                                .update();

                                            if (kIsWeb) {
                                              if (id == 2) {
                                                SingleTone.instance.socialLogin =
                                                    false;

                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              } else {
                                                SingleTone.instance.socialLogin =
                                                    false;
                                                Navigator.pop(context);

                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(
                                                //     AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              }
                                            } else {
                                              SingleTone.instance.socialLogin =
                                                  false;
                                              Get.back();
                                              Get.offAll(MainScreen(),
                                                  arguments: {
                                                    "userName": shared
                                                        .getString("userName"),
                                                    "postId":
                                                        controller.postId != null
                                                            ? controller.postId
                                                            : null,
                                                    "profileId":
                                                        controller.profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null
                                                  });
                                            }

                                            // Get.offAll(MainScreen(
                                            //   userName: shared.getString("userName"),
                                            //   postId: controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   profileId: controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null,
                                            // ));
                                            // Navigator.of(context).pushAndRemoveUntil(
                                            //     MaterialPageRoute(
                                            //         builder: (context) => MainScreen(
                                            //               userName: userName,
                                            //               postId: controller.postId != null
                                            //                   ? controller.postId
                                            //                   : null,
                                            //               profileId: controller.profileId != null
                                            //                   ? controller.profileId
                                            //                   : null,
                                            //             )),
                                            //     (Route<dynamic> route) => false);
                                            // Navigator.push(
                                            //   context,
                                            //   MaterialPageRoute(
                                            //     builder: (BuildContext context) =>
                                            //         MainScreen(userName: userName),
                                            // ),
                                            // );
                                          } else if (responseCode == 204) {
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                          } else if (responseCode == 205) {
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                          } else {
                                            Navigator.of(context).pop();

                                            customDialog(
                                              context,
                                              isSuccess: true,
                                              message: Strings
                                                  .emailOrPasswordIsIncorrect,
                                            );
                                          }
                                        },
                                      ),
                                    );
                                  } else if (responseCode == 205) {
                                    Fluttertoast.showToast(
                                        msg: responseMessage,
                                        toastLength: Toast.LENGTH_LONG,
                                        timeInSecForIosWeb: 5);
                                  } else {
                                    Navigator.of(context).pop();

                                    customDialog(
                                      context,
                                      isSuccess: true,
                                      message: Strings.emailOrPasswordIsIncorrect,
                                    );
                                  }
                                }
                              }
                            } else {
                              setState(() {
                                errorText = true;
                              });
                            }
                          },
                          child: kIsWeb
                              ? RoundedButton(
                                  Strings.cLOGIN,
                                  () async {
                                    {
                                      if (email.isNotEmpty &&
                                          password.isNotEmpty) {
                                        if (formKey.currentState.validate()) {
                                          DialogBuilder(context)
                                              .showLoadingIndicator();
                                          // print("Print me 2");
                                          if (kIsWeb) {
                                            bool _isNotABot =
                                                await RecaptchaService
                                                    .isNotABot();

                                            if (!_isNotABot) {
                                              Fluttertoast.showToast(
                                                  msg:
                                                      'It seems like you are a robot. please verify again',
                                                  toastLength: Toast.LENGTH_SHORT,
                                                  gravity: ToastGravity.CENTER,
                                                  timeInSecForIosWeb: 1,
                                                  backgroundColor: Colors.red,
                                                  textColor: Colors.white,
                                                  fontSize: 16.0);
                                              DialogBuilder(context)
                                                  .hideOpenDialog();
                                              return;
                                            }
                                          }

                                          /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/
                                          // if(!isCaptchaSelected){
                                          //   Fluttertoast.showToast(
                                          //       msg: 'Please check the captcha',
                                          //       toastLength: Toast.LENGTH_SHORT,
                                          //       gravity: ToastGravity.CENTER,
                                          //       timeInSecForIosWeb: 1,
                                          //       backgroundColor: Colors.red,
                                          //       textColor: Colors.white,
                                          //       fontSize: 16.0);
                                          //   return;
                                          // }

                                          var response = await controller
                                              .login(queryParameters: {
                                            "email": controller.email.text,
                                            "password": controller.password.text
                                          }, token: {
                                            "Authorization":
                                                " Bearer ${Url.webAPIKey}"
                                          });

                                          var jsonResponse =
                                              jsonDecode(response.toString());
                                          // print("jsonResponse $jsonResponse");

                                          var responseCode =
                                              jsonResponse['meta']['code'];
                                          var responseMessage =
                                              jsonResponse['meta']['message'];
                                          var userName =
                                              jsonResponse['data']['username'];
                                          var token =
                                              jsonResponse['data']['token'];
                                          var userId = jsonResponse['data']['id'];
                                          var email =
                                              jsonResponse['data']['email'];
                                          shared = await SharedPreferences
                                              .getInstance();
                                          if (responseCode == 200) {
                                            controller
                                                .updateInitialWelcomeMsg(true);


                                            shared.setString(
                                                "email", email.toString());

                                            shared.setString(
                                                "token", token.toString());
                                            shared.setString(
                                                "userName", userName.toString());
                                            shared.setBool('guestUser', true);
                                            shared.setBool('socialLogin', false);
                                            storage.write('id', userId);
                                            storage.write(
                                                "token", token.toString());
                                            storage.write(
                                                "email", email.toString());

                                            storage.write("CurrentEmail",
                                                controller.email.text);

                                            storage.write(
                                                "userName", userName.toString());

                                            storage.write(
                                                "remember", isCheckedGlobal);

                                            controller.email.clear();
                                            controller.password.clear();
                                            controller.generateFCMToken(context);
                                            //  NewsfeedController newsfeedController;
                                            // newsfeedController=
                                            if (Get.isRegistered<
                                                NewsfeedController>()) {
                                              Get.delete<NewsfeedController>();
                                              if (kDebugMode) {
                                                print(
                                                    'newfees controller is removed at login  controller1');
                                              }
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));
                                            } else {
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));

                                            }

                                            // newsfeedController .languageData= await newsfeedController.getLanguages();
                                            Get.find<NewsfeedController>()
                                                .languageData = await Get.find<
                                                    NewsfeedController>()
                                                .getLanguages();
                                            int index =
                                                Get.find<NewsfeedController>()
                                                    .languagesList
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .id ==
                                                  element.id;
                                            });

                                            int index2 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .myLang
                                                      .id ==
                                                  element.id;
                                            });

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue =
                                                Get.find<NewsfeedController>()
                                                    .languagesList[index];

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue1 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage[index2];

                                            // print("idhr sdfsdf");

                                            // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                            //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                            //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                            //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                            // );
                                            //
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                            Get.find<NewsfeedController>()
                                                    .selectedAppLanguageInfoId =
                                                Get.find<NewsfeedController>()
                                                    .languageData
                                                    .appLang
                                                    .id;

                                            Get.find<NewsfeedController>()
                                                .upDateLocale(
                                                    Get.find<NewsfeedController>()
                                                        .languageData
                                                        .appLang
                                                        .code);
                                            Get.find<NewsfeedController>()
                                                .update();

                                            if (kIsWeb) {
                                              if (id == 2) {
                                                SingleTone.instance.socialLogin =
                                                    false;
                                                DialogBuilder(context)
                                                    .hideOpenDialog();

                                                // Navigator.pop(context);
                                                // Routemaster.of(context).pop();

                                                String userName =
                                                    shared.getString("userName");
                                                // print({
                                                //   "userName on mainScreen :  $userName"
                                                // });
                                                // print(
                                                //     'postsid:${controller.postId}');
                                                // print(
                                                //     'profileId:${controller.profileId}');
                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              } else {
                                                SingleTone.instance.socialLogin =
                                                    false;
                                                // Routemaster.of(context).pop();
                                                // Navigator.pop(context);
                                                DialogBuilder(context)
                                                    .hideOpenDialog();

                                                String userName =
                                                    shared.getString("userName");
                                                // print({
                                                //   "userName on mainScreen :  $userName"
                                                // });
                                                // print(
                                                //     'postsid:${controller.postId}');
                                                // print(
                                                //     'profileId:${controller.profileId}');
                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(
                                                //     AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              }
                                            } else {
                                              SingleTone.instance.socialLogin =
                                                  false;
                                              // Get.back();
                                              DialogBuilder(context)
                                                  .hideOpenDialog();

                                              Get.offAll(MainScreen(),
                                                  arguments: {
                                                    "userName": shared
                                                        .getString("userName"),
                                                    "postId":
                                                        controller.postId != null
                                                            ? controller.postId
                                                            : null,
                                                    "profileId":
                                                        controller.profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null
                                                  });
                                            }

                                            // Get.offAll(MainScreen(
                                            //   userName: shared.getString("userName"),
                                            //   postId: controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   profileId: controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null,
                                            // ));
                                            // Navigator.of(context).pushAndRemoveUntil(
                                            //     MaterialPageRoute(
                                            //         builder: (context) => MainScreen(
                                            //               userName: userName,
                                            //               postId: controller.postId != null
                                            //                   ? controller.postId
                                            //                   : null,
                                            //               profileId: controller.profileId != null
                                            //                   ? controller.profileId
                                            //                   : null,
                                            //             )),
                                            //     (Route<dynamic> route) => false);
                                            // Navigator.push(
                                            //   context,
                                            //   MaterialPageRoute(
                                            //     builder: (BuildContext context) =>
                                            //         MainScreen(userName: userName),
                                            // ),
                                            // );
                                          } else if (responseCode == 204) {
                                            DialogBuilder(context)
                                                .hideOpenDialog();
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                            Navigator.pop(context);
                                            showDialog(
                                              context: context,
                                              builder: (context) => OtpDialog(
                                                onSubmit: (otp) async {
                                                  DialogBuilder(context)
                                                      .showLoadingIndicator();

                                                  var response = await controller
                                                      .login(queryParameters: {
                                                    "email":
                                                        controller.email.text,
                                                    "password":
                                                        controller.password.text,
                                                    "code": otp
                                                  }, token: {
                                                    "Authorization":
                                                        " Bearer ${Url.webAPIKey}"
                                                  });
                                                  var jsonResponse = jsonDecode(
                                                      response.toString());


                                                  var responseCode =
                                                      jsonResponse['meta']
                                                          ['code'];
                                                  var responseMessage =
                                                      jsonResponse['meta']
                                                          ['message'];
                                                  var userName =
                                                      jsonResponse['data']
                                                          ['username'];
                                                  var token = jsonResponse['data']
                                                      ['token'];
                                                  var userId =
                                                      jsonResponse['data']['id'];

                                                  var email = jsonResponse['data']
                                                      ['email'];

                                                  DialogBuilder(context)
                                                      .hideOpenDialog();

                                                  if (responseCode == 200) {
                                                    shared.setString("token",
                                                        token.toString());
                                                    shared.setString("userName",
                                                        userName.toString());

                                                    shared.setString("email",
                                                        email.toString());

                                                    storage.write("email",
                                                        email.toString());

                                                    shared.setBool(
                                                        'guestUser', true);
                                                    shared.setBool(
                                                        'socialLogin', false);
                                                    storage.write('id', userId);
                                                    storage.write("token",
                                                        token.toString());

                                                    storage.write("CurrentEmail",
                                                        controller.email.text);
                                                    storage.write("userName",
                                                        userName.toString());

                                                    storage.write("remember",
                                                        isCheckedGlobal);

                                                    controller.email.clear();
                                                    controller.password.clear();
                                                    controller.generateFCMToken(
                                                        context);
                                                    if (Get.isRegistered<
                                                        NewsfeedController>()) {
                                                      Get.delete<
                                                          NewsfeedController>();
                                                      if (kDebugMode) {
                                                        print(
                                                            'newfees controller is removed at login  controller0');
                                                      }
                                                      Get.put(NewsfeedController(
                                                        linkId: controller
                                                                    .postId !=
                                                                null
                                                            ? controller.postId
                                                            : null,
                                                        profileId: controller
                                                                    .profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null,
                                                      ));
                                                    } else {
                                                      Get.put(NewsfeedController(
                                                        linkId: controller
                                                                    .postId !=
                                                                null
                                                            ? controller.postId
                                                            : null,
                                                        profileId: controller
                                                                    .profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null,
                                                      ));
                                                      if (kDebugMode) {
                                                        print(
                                                            'newfees controller is initalized at login  controller0');
                                                      }
                                                    }

                                                    // Get.put(NewsfeedController(
                                                    //   linkId: controller.postId != null ? controller.postId : null,
                                                    //   profileId: controller.profileId != null ? controller.profileId : null,
                                                    // ));

                                                    Get.find<NewsfeedController>()
                                                            .languageData =
                                                        await Get.find<
                                                                NewsfeedController>()
                                                            .getLanguages();
                                                    int index = Get.find<
                                                            NewsfeedController>()
                                                        .languagesList
                                                        .indexWhere((element) {
                                                      return Get.find<
                                                                  NewsfeedController>()
                                                              .languageData
                                                              .appLang
                                                              .id ==
                                                          element.id;
                                                    });

                                                    int index2 = Get.find<
                                                            NewsfeedController>()
                                                        .translationLanguage
                                                        .indexWhere((element) {
                                                      return Get.find<
                                                                  NewsfeedController>()
                                                              .languageData
                                                              .myLang
                                                              .id ==
                                                          element.id;
                                                    });

                                                    Get.find<NewsfeedController>()
                                                        .dropdownValue = Get.find<
                                                            NewsfeedController>()
                                                        .languagesList[index];

                                                    Get.find<NewsfeedController>()
                                                        .dropdownValue1 = Get.find<
                                                            NewsfeedController>()
                                                        .translationLanguage[index2];

                                                    // print("idhr sdfsdf");

                                                    // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                                    //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                                    //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                                    //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                                    // );
                                                    //
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                                    Get.find<NewsfeedController>()
                                                            .selectedAppLanguageInfoId =
                                                        Get.find<
                                                                NewsfeedController>()
                                                            .languageData
                                                            .appLang
                                                            .id;

                                                    Get.find<NewsfeedController>()
                                                        .upDateLocale(Get.find<
                                                                NewsfeedController>()
                                                            .languageData
                                                            .appLang
                                                            .code);
                                                    Get.find<NewsfeedController>()
                                                        .update();

                                                    if (kIsWeb) {
                                                      if (id == 2) {
                                                        SingleTone.instance
                                                            .socialLogin = false;

                                                        Get.offNamed(FluroRouters
                                                            .mainScreen);

                                                        // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                        //
                                                        //
                                                        //   "userName": shared.getString("userName"),
                                                        //   "postId": controller.postId != null
                                                        //       ? controller.postId
                                                        //       : null,
                                                        //   "profileId": controller.profileId != null
                                                        //       ? controller.profileId
                                                        //       : null
                                                        // });
                                                      } else {
                                                        SingleTone.instance
                                                            .socialLogin = false;
                                                        Navigator.pop(context);

                                                        Get.offNamed(FluroRouters
                                                            .mainScreen);

                                                        // Routemaster.of(context).replace(
                                                        //     AppRoute.mainScreen, queryParameters: {
                                                        //
                                                        //
                                                        //   "userName": shared.getString("userName"),
                                                        //   "postId": controller.postId != null
                                                        //       ? controller.postId
                                                        //       : null,
                                                        //   "profileId": controller.profileId != null
                                                        //       ? controller.profileId
                                                        //       : null
                                                        // });
                                                      }
                                                    } else {
                                                      SingleTone.instance
                                                          .socialLogin = false;
                                                      Get.back();
                                                      Get.offAll(MainScreen(),
                                                          arguments: {
                                                            "userName":
                                                                shared.getString(
                                                                    "userName"),
                                                            "postId": controller
                                                                        .postId !=
                                                                    null
                                                                ? controller
                                                                    .postId
                                                                : null,
                                                            "profileId": controller
                                                                        .profileId !=
                                                                    null
                                                                ? controller
                                                                    .profileId
                                                                : null
                                                          });
                                                    }

                                                    // Get.offAll(MainScreen(
                                                    //   userName: shared.getString("userName"),
                                                    //   postId: controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   profileId: controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null,
                                                    // ));
                                                    // Navigator.of(context).pushAndRemoveUntil(
                                                    //     MaterialPageRoute(
                                                    //         builder: (context) => MainScreen(
                                                    //               userName: userName,
                                                    //               postId: controller.postId != null
                                                    //                   ? controller.postId
                                                    //                   : null,
                                                    //               profileId: controller.profileId != null
                                                    //                   ? controller.profileId
                                                    //                   : null,
                                                    //             )),
                                                    //     (Route<dynamic> route) => false);
                                                    // Navigator.push(
                                                    //   context,
                                                    //   MaterialPageRoute(
                                                    //     builder: (BuildContext context) =>
                                                    //         MainScreen(userName: userName),
                                                    // ),
                                                    // );
                                                  } else if (responseCode ==
                                                      204) {
                                                    Fluttertoast.showToast(
                                                        msg: responseMessage,
                                                        toastLength:
                                                            Toast.LENGTH_LONG,
                                                        timeInSecForIosWeb: 5);
                                                  } else if (responseCode ==
                                                      205) {
                                                    Fluttertoast.showToast(
                                                        msg: responseMessage,
                                                        toastLength:
                                                            Toast.LENGTH_LONG,
                                                        timeInSecForIosWeb: 5);
                                                  } else {
                                                    Navigator.of(context).pop();

                                                    customDialog(
                                                      context,
                                                      isSuccess: true,
                                                      message: Strings
                                                          .emailOrPasswordIsIncorrect,
                                                    );
                                                  }
                                                },
                                              ),
                                            );
                                          } else if (responseCode == 205) {
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                          } else {
                                            Navigator.of(context).pop();

                                            customDialog(
                                              context,
                                              isSuccess: true,
                                              message: Strings
                                                  .emailOrPasswordIsIncorrect,
                                            );
                                          }
                                        }
                                      } else {
                                        setState(() {
                                          errorText = true;
                                        });
                                      }
                                    }
                                  },
                                  verticalPadding: kIsWeb ? 20.0 : 15.0,
                                  horizontalPadding: Get.width / 14,
                                  focusNode: controller.focus4,
                                  roundedButtonColor: MyColors.werfieBlue,
                                )
                              : RoundedButton(
                                  Strings.cLOGIN,
                                  () async {
                                    // var internetStatus=await UtilsMethods.checkInternet();
                                    // if(internetStatus!=true){
                                    //   UtilsMethods.toastMessageShow(Colors.red, Colors.red, Colors.red,
                                    //     message: Strings.noInternetAvailable,
                                    //   );
                                    // }
                                    // else{

                                    if (email.length != '' &&
                                        password.length != '') {
                                      if (formKey.currentState.validate()) {
                                        DialogBuilder(context)
                                            .showLoadingIndicator();
                                        // print("Print me 3");
                                        if (kIsWeb) {
                                          bool _isNotABot =
                                              await RecaptchaService.isNotABot();

                                          if (!_isNotABot) {
                                            Fluttertoast.showToast(
                                                msg:
                                                    'It seems like you are a robot. please verify again',
                                                toastLength: Toast.LENGTH_SHORT,
                                                gravity: ToastGravity.CENTER,
                                                timeInSecForIosWeb: 1,
                                                backgroundColor: Colors.red,
                                                textColor: Colors.white,
                                                fontSize: 16.0);
                                            return;
                                          }
                                        }

                                        /*   showDialog(
                              // barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                    Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.all(Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });*/

                                        //Uncomment for captcha mobile step 1
                                        // if (isCaptchaSelected == true) {
                                          var response = await controller
                                              .login(queryParameters: {
                                            "email": controller.email.text,
                                            "password": controller.password.text
                                          }, token: {
                                            "Authorization":
                                                " Bearer ${Url.webAPIKey}"
                                          });

                                          var jsonResponse =
                                              jsonDecode(response.toString());

                                          var responseCode =
                                              jsonResponse['meta']['code'];
                                          var responseMessage =
                                              jsonResponse['meta']['message'];
                                          var userName =
                                              jsonResponse['data']['username'];
                                          var token =
                                              jsonResponse['data']['token'];
                                          var userId = jsonResponse['data']['id'];
                                          var email =
                                              jsonResponse['data']['email'];
                                          shared = await SharedPreferences
                                              .getInstance();
                                          if (responseCode == 200) {
                                            controller
                                                .updateInitialWelcomeMsg(true);

                                            shared.setString(
                                                "email", email.toString());

                                            shared.setString(
                                                "token", token.toString());
                                            shared.setString(
                                                "userName", userName.toString());
                                            shared.setBool('guestUser', true);
                                            shared.setBool('socialLogin', false);
                                            storage.write('id', userId);
                                            storage.write(
                                                "token", token.toString());
                                            storage.write(
                                                "email", email.toString());

                                            storage.write("CurrentEmail",
                                                controller.email.text);

                                            storage.write(
                                                "userName", userName.toString());

                                            storage.write(
                                                "remember", isCheckedGlobal);

                                            controller.email.clear();
                                            controller.password.clear();
                                            controller.generateFCMToken(context);
                                            //  NewsfeedController newsfeedController;
                                            // newsfeedController=
                                            if (Get.isRegistered<
                                                NewsfeedController>()) {
                                              Get.delete<NewsfeedController>();
                                              if (kDebugMode) {
                                                print(
                                                    'newfees controller is removed at login  controller1');
                                              }
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));
                                            } else {
                                              Get.put(NewsfeedController(
                                                linkId: controller.postId != null
                                                    ? controller.postId
                                                    : null,
                                                profileId:
                                                    controller.profileId != null
                                                        ? controller.profileId
                                                        : null,
                                              ));

                                            }

                                            // newsfeedController .languageData= await newsfeedController.getLanguages();

                                            Get.find<NewsfeedController>()
                                                .languageData = await Get.find<
                                                    NewsfeedController>()
                                                .getLanguages();
                                            int index =
                                                Get.find<NewsfeedController>()
                                                    .languagesList
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .appLang
                                                      .id ==
                                                  element.id;
                                            });

                                            int index2 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage
                                                    .indexWhere((element) {
                                              return Get.find<
                                                          NewsfeedController>()
                                                      .languageData
                                                      .myLang
                                                      .id ==
                                                  element.id;
                                            });

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue =
                                                Get.find<NewsfeedController>()
                                                    .languagesList[index];

                                            Get.find<NewsfeedController>()
                                                    .dropdownValue1 =
                                                Get.find<NewsfeedController>()
                                                    .translationLanguage[index2];

                                            // print("idhr sdfsdf");

                                            // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                            //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                            //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                            //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                            // );
                                            //
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                            // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                            Get.find<NewsfeedController>()
                                                    .selectedAppLanguageInfoId =
                                                Get.find<NewsfeedController>()
                                                    .languageData
                                                    .appLang
                                                    .id;

                                            String langCode = Get.find<NewsfeedController>().languageData.appLang.code;
                                            Get.find<NewsfeedController>()
                                                .upDateLocale(langCode);

                                            if (controller.selectedLanguage.code != langCode){
                                              await Get.find<NewsfeedController>().languagesRequest(
                                                  languageId: controller.selectedLanguage != null
                                                      ? controller.selectedLanguage.id.toString()
                                                      : 1.toString(),
                                                  autoTranslate: 1.toString(),
                                                  appLanguageId: controller.selectedLanguage.id,
                                                  appLanguage: controller.selectedLanguage.name,
                                                  appLanguageCode: controller.selectedLanguage.code);
                                            }

                                            Get.find<NewsfeedController>()
                                                .update();

                                            if (kIsWeb) {
                                              if (id == 2) {
                                                SingleTone.instance.socialLogin =
                                                    false;
                                                DialogBuilder(context)
                                                    .hideOpenDialog();

                                                // Navigator.pop(context);
                                                // Routemaster.of(context).pop();

                                                String userName =
                                                    shared.getString("userName");
                                                // print({
                                                //   "userName on mainScreen :  $userName"
                                                // });
                                                // print(
                                                //     'postsid:${controller.postId}');
                                                // print(
                                                //     'profileId:${controller.profileId}');
                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              } else {
                                                SingleTone.instance.socialLogin =
                                                    false;
                                                // Routemaster.of(context).pop();
                                                // Navigator.pop(context);
                                                DialogBuilder(context)
                                                    .hideOpenDialog();

                                                String userName =
                                                    shared.getString("userName");
                                                // print({
                                                //   "userName on mainScreen :  $userName"
                                                // });
                                                // print(
                                                //     'postsid:${controller.postId}');
                                                // print(
                                                //     'profileId:${controller.profileId}');
                                                Get.offNamed(
                                                    FluroRouters.mainScreen);

                                                // Routemaster.of(context).replace(
                                                //     AppRoute.mainScreen, queryParameters: {
                                                //
                                                //
                                                //   "userName": shared.getString("userName"),
                                                //   "postId": controller.postId != null
                                                //       ? controller.postId
                                                //       : null,
                                                //   "profileId": controller.profileId != null
                                                //       ? controller.profileId
                                                //       : null
                                                // });
                                              }
                                            } else {
                                              SingleTone.instance.socialLogin =
                                                  false;
                                              // Get.back();
                                              DialogBuilder(context)
                                                  .hideOpenDialog();

                                              Get.offAll(MainScreen(),
                                                  arguments: {
                                                    "userName": shared
                                                        .getString("userName"),
                                                    "postId":
                                                        controller.postId != null
                                                            ? controller.postId
                                                            : null,
                                                    "profileId":
                                                        controller.profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null
                                                  });
                                            }

                                            // Get.offAll(MainScreen(
                                            //   userName: shared.getString("userName"),
                                            //   postId: controller.postId != null
                                            //       ? controller.postId
                                            //       : null,
                                            //   profileId: controller.profileId != null
                                            //       ? controller.profileId
                                            //       : null,
                                            // ));
                                            // Navigator.of(context).pushAndRemoveUntil(
                                            //     MaterialPageRoute(
                                            //         builder: (context) => MainScreen(
                                            //               userName: userName,
                                            //               postId: controller.postId != null
                                            //                   ? controller.postId
                                            //                   : null,
                                            //               profileId: controller.profileId != null
                                            //                   ? controller.profileId
                                            //                   : null,
                                            //             )),
                                            //     (Route<dynamic> route) => false);
                                            // Navigator.push(
                                            //   context,
                                            //   MaterialPageRoute(
                                            //     builder: (BuildContext context) =>
                                            //         MainScreen(userName: userName),
                                            // ),
                                            // );
                                          } else if (responseCode == 204) {
                                            DialogBuilder(context)
                                                .hideOpenDialog();
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                            showDialog(
                                              context: context,
                                              builder: (context) => OtpDialog(
                                                onSubmit: (otp) async {
                                                  DialogBuilder(context)
                                                      .showLoadingIndicator();

                                                  var response = await controller
                                                      .login(queryParameters: {
                                                    "email":
                                                        controller.email.text,
                                                    "password":
                                                        controller.password.text,
                                                    "code": otp
                                                  }, token: {
                                                    "Authorization":
                                                        " Bearer ${Url.webAPIKey}"
                                                  });
                                                  var jsonResponse = jsonDecode(
                                                      response.toString());



                                                  var responseCode =
                                                      jsonResponse['meta']
                                                          ['code'];
                                                  var responseMessage =
                                                      jsonResponse['meta']
                                                          ['message'];
                                                  var userName =
                                                      jsonResponse['data']
                                                          ['username'];
                                                  var token = jsonResponse['data']
                                                      ['token'];
                                                  var userId =
                                                      jsonResponse['data']['id'];

                                                  var email = jsonResponse['data']
                                                      ['email'];

                                                  DialogBuilder(context)
                                                      .hideOpenDialog();

                                                  if (responseCode == 200) {
                                                    Navigator.of(context).pop();
                                                    shared.setString("token",
                                                        token.toString());
                                                    shared.setString("userName",
                                                        userName.toString());

                                                    shared.setString("email",
                                                        email.toString());

                                                    storage.write("email",
                                                        email.toString());

                                                    shared.setBool(
                                                        'guestUser', true);
                                                    shared.setBool(
                                                        'socialLogin', false);
                                                    storage.write('id', userId);
                                                    storage.write("token",
                                                        token.toString());

                                                    storage.write("CurrentEmail",
                                                        controller.email.text);
                                                    storage.write("userName",
                                                        userName.toString());

                                                    storage.write("remember",
                                                        isCheckedGlobal);

                                                    controller.email.clear();
                                                    controller.password.clear();
                                                    controller.generateFCMToken(
                                                        context);
                                                    if (Get.isRegistered<
                                                        NewsfeedController>()) {
                                                      Get.delete<
                                                          NewsfeedController>();
                                                      if (kDebugMode) {
                                                        print(
                                                            'newfees controller is removed at login  controller0');
                                                      }
                                                      Get.put(NewsfeedController(
                                                        linkId: controller
                                                                    .postId !=
                                                                null
                                                            ? controller.postId
                                                            : null,
                                                        profileId: controller
                                                                    .profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null,
                                                      ));
                                                    } else {
                                                      Get.put(NewsfeedController(
                                                        linkId: controller
                                                                    .postId !=
                                                                null
                                                            ? controller.postId
                                                            : null,
                                                        profileId: controller
                                                                    .profileId !=
                                                                null
                                                            ? controller.profileId
                                                            : null,
                                                      ));
                                                      if (kDebugMode) {
                                                        print(
                                                            'newfees controller is initalized at login  controller0');
                                                      }
                                                    }

                                                    // Get.put(NewsfeedController(
                                                    //   linkId: controller.postId != null ? controller.postId : null,
                                                    //   profileId: controller.profileId != null ? controller.profileId : null,
                                                    // ));

                                                    Get.find<NewsfeedController>()
                                                            .languageData =
                                                        await Get.find<
                                                                NewsfeedController>()
                                                            .getLanguages();
                                                    int index = Get.find<
                                                            NewsfeedController>()
                                                        .languagesList
                                                        .indexWhere((element) {
                                                      return Get.find<
                                                                  NewsfeedController>()
                                                              .languageData
                                                              .appLang
                                                              .id ==
                                                          element.id;
                                                    });

                                                    int index2 = Get.find<
                                                            NewsfeedController>()
                                                        .translationLanguage
                                                        .indexWhere((element) {
                                                      return Get.find<
                                                                  NewsfeedController>()
                                                              .languageData
                                                              .myLang
                                                              .id ==
                                                          element.id;
                                                    });

                                                    Get.find<NewsfeedController>()
                                                        .dropdownValue = Get.find<
                                                            NewsfeedController>()
                                                        .languagesList[index];

                                                    Get.find<NewsfeedController>()
                                                        .dropdownValue1 = Get.find<
                                                            NewsfeedController>()
                                                        .translationLanguage[index2];

                                                    // print("idhr sdfsdf");

                                                    // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
                                                    //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
                                                    //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
                                                    //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
                                                    // );
                                                    //
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
                                                    // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

                                                    Get.find<NewsfeedController>()
                                                            .selectedAppLanguageInfoId =
                                                        Get.find<
                                                                NewsfeedController>()
                                                            .languageData
                                                            .appLang
                                                            .id;

                                                    Get.find<NewsfeedController>()
                                                        .upDateLocale(Get.find<
                                                                NewsfeedController>()
                                                            .languageData
                                                            .appLang
                                                            .code);
                                                    Get.find<NewsfeedController>()
                                                        .update();

                                                    if (kIsWeb) {
                                                      if (id == 2) {
                                                        SingleTone.instance
                                                            .socialLogin = false;
                                                        // Navigator.pop(context);
                                                        // Routemaster.of(context).pop();

                                                        String userName =
                                                            shared.getString(
                                                                "userName");
                                                        // print({
                                                        //   "userName on mainScreen :  $userName"
                                                        // });
                                                        // print(
                                                        //     'postsid:${controller.postId}');
                                                        // print(
                                                        //     'profileId:${controller.profileId}');
                                                        Get.offNamed(FluroRouters
                                                            .mainScreen);

                                                        // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                                        //
                                                        //
                                                        //   "userName": shared.getString("userName"),
                                                        //   "postId": controller.postId != null
                                                        //       ? controller.postId
                                                        //       : null,
                                                        //   "profileId": controller.profileId != null
                                                        //       ? controller.profileId
                                                        //       : null
                                                        // });
                                                      } else {
                                                        SingleTone.instance
                                                            .socialLogin = false;
                                                        // Routemaster.of(context).pop();
                                                        Navigator.pop(context);

                                                        String userName =
                                                            shared.getString(
                                                                "userName");
                                                        // print({
                                                        //   "userName on mainScreen :  $userName"
                                                        // });
                                                        // print(
                                                        //     'postsid:${controller.postId}');
                                                        // print(
                                                        //     'profileId:${controller.profileId}');
                                                        Get.offNamed(FluroRouters
                                                            .mainScreen);

                                                        // Routemaster.of(context).replace(
                                                        //     AppRoute.mainScreen, queryParameters: {
                                                        //
                                                        //
                                                        //   "userName": shared.getString("userName"),
                                                        //   "postId": controller.postId != null
                                                        //       ? controller.postId
                                                        //       : null,
                                                        //   "profileId": controller.profileId != null
                                                        //       ? controller.profileId
                                                        //       : null
                                                        // });
                                                      }
                                                    } else {
                                                      SingleTone.instance
                                                          .socialLogin = false;
                                                      Get.back();
                                                      Get.offAll(MainScreen(isLoggedInFromPosh: true,),
                                                          arguments: {
                                                            "userName":
                                                                shared.getString(
                                                                    "userName"),
                                                            "postId": controller
                                                                        .postId !=
                                                                    null
                                                                ? controller
                                                                    .postId
                                                                : null,
                                                            "profileId": controller
                                                                        .profileId !=
                                                                    null
                                                                ? controller
                                                                    .profileId
                                                                : null
                                                          });
                                                    }

                                                    // Get.offAll(MainScreen(
                                                    //   userName: shared.getString("userName"),
                                                    //   postId: controller.postId != null
                                                    //       ? controller.postId
                                                    //       : null,
                                                    //   profileId: controller.profileId != null
                                                    //       ? controller.profileId
                                                    //       : null,
                                                    // ));
                                                    // Navigator.of(context).pushAndRemoveUntil(
                                                    //     MaterialPageRoute(
                                                    //         builder: (context) => MainScreen(
                                                    //               userName: userName,
                                                    //               postId: controller.postId != null
                                                    //                   ? controller.postId
                                                    //                   : null,
                                                    //               profileId: controller.profileId != null
                                                    //                   ? controller.profileId
                                                    //                   : null,
                                                    //             )),
                                                    //     (Route<dynamic> route) => false);
                                                    // Navigator.push(
                                                    //   context,
                                                    //   MaterialPageRoute(
                                                    //     builder: (BuildContext context) =>
                                                    //         MainScreen(userName: userName),
                                                    // ),
                                                    // );
                                                  } else if (responseCode ==
                                                      204) {
                                                    Fluttertoast.showToast(
                                                        msg: responseMessage,
                                                        toastLength:
                                                            Toast.LENGTH_LONG,
                                                        timeInSecForIosWeb: 5);
                                                  } else if (responseCode ==
                                                      205) {
                                                    Fluttertoast.showToast(
                                                        msg: responseMessage,
                                                        toastLength:
                                                            Toast.LENGTH_LONG,
                                                        timeInSecForIosWeb: 5);
                                                  } else {
                                                    Navigator.of(context).pop();

                                                    customDialog(
                                                      context,
                                                      isSuccess: true,
                                                      message: Strings
                                                          .emailOrPasswordIsIncorrect,
                                                    );
                                                  }
                                                },
                                              ),
                                            );
                                          } else if (responseCode == 205) {
                                            Fluttertoast.showToast(
                                                msg: responseMessage,
                                                toastLength: Toast.LENGTH_LONG,
                                                timeInSecForIosWeb: 5);
                                          } else {
                                            Navigator.of(context).pop();

                                            customDialog(
                                              context,
                                              isSuccess: true,
                                              message: Strings
                                                  .emailOrPasswordIsIncorrect,
                                            );
                                          }

                                          //Uncomment for captcha mobile step 2
                                      /*  } else {
                                          showDialog(
                                            context: context,barrierDismissible: false,
                                            builder: (ctx) => AlertDialog(
                                              title: Column(
                                                mainAxisAlignment: MainAxisAlignment.start,
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  const Text("Captcha"),
                                                  SizedBox(height: 20,),
                                                  const Text("Note: Please scroll horizontally\n if the checkbox is not visible!!!",style: TextStyle(fontSize: 12,fontWeight: FontWeight.w400,color: Colors.red,),),

                                                ],
                                              ),
                                              content: Container(height:200,
                                                  width: 200,
                                                  alignment: Alignment.centerRight,
                                                  child: WebViewWidget(controller: webviewController)),
                                                  // child:   WebViewScreen(String: webviewController.)),
                                              actions: <Widget>[
                                                TextButton(
                                                  onPressed: () {
                                                    DialogBuilder(context).hideOpenDialog();
                                                    Navigator.of(ctx).pop();
                                                  },
                                                  child: Container(
                                                    padding: const EdgeInsets.all(14),
                                                    child: const Text("Cancel"),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          );
                                        }*/
                                      }
                                    } else {
                                      setState(() {
                                        errorText = true;
                                      });
                                    }
                                    // }
                                  },
                                  verticalPadding: kIsWeb ? 20.0 : 15.0,
                                  horizontalPadding: Get.width / 14,
                                  focusNode: controller.focus4,
                                  roundedButtonColor: MyColors.werfieBlue,
                                ),
                        ),
                      )),
                ),
                SizedBox(height: 10),
                !kIsWeb
                    ? Platform.isIOS
                        ?
                        //Sign in with apple button
                        TextCustomButton(
                          callFromLogin: true,
                            id: Theme.of(context).brightness == Brightness.dark
                                ? 0
                                : 1,
                            buttonText: Strings.signInWithApple,
                            image: 'assets/images/apple.png',
                            onPressed: () async {
                              LoginController loginController;
                              if (Get.isRegistered<LoginController>()) {
                                loginController = Get.find<LoginController>();
                              } else {
                                loginController = Get.put(LoginController());
                              }
                              var response;
                              // doSignInApple();
                              UtilsMethods utillMethod = UtilsMethods();
                              AuthService authService = AuthService();
                              await authService.signInWithApple(scopes: [
                                Scope.email,
                                Scope.fullName
                              ]).then((value) async {
                                print('uid: ${value}');
                                print('uid: ${value.uid}');
                                print('uid: ${value.email}');
                                print('uid: ${value.displayName}');
                                if (value.email == null ||
                                    value.displayName == null ||
                                    value.uid == null ||
                                    value.email.isEmpty ||
                                    value.displayName.isEmpty ||
                                    value.uid.isEmpty) {
                                  Get.snackbar("Error",
                                      'Somthing went wrong with configuration. please try again');
                                } else if (value.email.contains("privaterelay")) {
                                  Get.snackbar("Alert",
                                      "Please allow email to continue with werfie");
                                  await FirebaseAuth.instance.signOut();

                                  print('uid: please allow email to continue');
                                } else {
                                  showDialog(
                                      barrierDismissible: false,
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          backgroundColor:
                                              Color(0xFFFFFFFF).withOpacity(0.2),
                                          shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(10.0))),
                                          insetPadding: EdgeInsets.symmetric(
                                              horizontal: 0, vertical: 0),
                                          contentPadding: EdgeInsets.zero,
                                          content: Container(
                                            height: 100,
                                            width: 80,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.spaceAround,
                                              children: [
                                                SpinKitCircle(
                                                  color: Theme.of(context)
                                                      .primaryColor,
                                                  size: 50.0,
                                                ),
                                                Text(
                                                  Strings.pleaseWait,
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                )
                                              ],
                                            ),
                                          ),
                                        );
                                      });
                                }
                                response = await controller.SocialLogin(
                                    queryParameters: {
                                      "email": value.email,
                                      "firstname": value.displayName,
                                      "login_type": 'apple',
                                      "social_id": value.uid,
                                    },
                                    token: {
                                      "Authorization": " Bearer ${Url.webAPIKey}"
                                    });
                                var jsonResponse =
                                    jsonDecode(response.toString());
                                // storage.write("email", value.email.toString());
                                // shared.setString("email", value.email.toString());

                                var responseCode = jsonResponse['meta']['code'];
                                var userName = jsonResponse['data']['username'];
                                var token = jsonResponse['data']['token'];
                                var userId = jsonResponse['data']['id'];
                                var email = jsonResponse['data']['email'];
                                shared = await SharedPreferences.getInstance();
                                if (responseCode == 200) {
                                  storage.write("email", email.toString());

                                  shared.setString("token", token.toString());
                                  shared.setString(
                                      "userName", userName.toString());
                                  storage.write('id', userId);
                                  storage.write("token", token.toString());
                                  shared.setBool('guestUser', true);
                                  shared.setBool('socialLogin', true);
                                  storage.write("userName", userName.toString());

                                  storage.write("remember", isCheckedGlobal);

                                  controller.generateFCMToken(context);
                                  controller.updateInitialWelcomeMsg(true);

                                  Get.put(NewsfeedController(
                                      // linkId: controller.postId != null ? controller.postId : null,
                                      // profileId: controller.profileId != null ? controller.profileId : null,
                                      ));
                                  Get.find<NewsfeedController>().languageData =
                                      await Get.find<NewsfeedController>()
                                          .getLanguages();
                                  Get.find<NewsfeedController>()
                                          .selectedAppLanguageInfoId =
                                      Get.find<NewsfeedController>()
                                          .languageData
                                          .appLang
                                          .id;

                                  Get.find<NewsfeedController>().upDateLocale(
                                      Get.find<NewsfeedController>()
                                          .languageData
                                          .appLang
                                          .code);
                                  Get.find<NewsfeedController>().update();
                                  {
                                    if (kIsWeb) {
                                      if (id == 2) {
                                        SingleTone.instance.socialLogin = true;
                                        Navigator.pop(context);
                                        // Routemaster.of(context).pop();
                                        String userName =
                                            shared.getString("userName");
                                        // print({
                                        //   "userName on mainScreen :  $userName"
                                        // });
                                        // print('postsid:${controller.postId}');
                                        // print(
                                        //     'profileId:${controller.profileId}');
                                        Get.offNamed(FluroRouters.mainScreen);
                                        // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                        //
                                        //
                                        //   "userName": shared.getString("userName"),
                                        //   "postId": controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   "profileId": controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null
                                        // });
                                      } else {
                                        SingleTone.instance.socialLogin = true;
                                        Navigator.pop(context);
                                        String userName =
                                            shared.getString("userName");
                                        // print({
                                        //   "userName on mainScreen :  $userName"
                                        // });
                                        // print('postsid:${controller.postId}');
                                        // print(
                                        //     'profileId:${controller.profileId}');
                                        Get.offNamed(FluroRouters.mainScreen);

                                        // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                        //
                                        //
                                        //   "userName": shared.getString("userName"),
                                        //   "postId": controller.postId != null
                                        //       ? controller.postId
                                        //       : null,
                                        //   "profileId": controller.profileId != null
                                        //       ? controller.profileId
                                        //       : null
                                        // });
                                      }
                                    } else {
                                      SingleTone.instance.socialLogin = true;
                                      print('route is else here');
                                      Get.back();

                                      Get.offAll(MainScreen(), arguments: {
                                        "userName": shared.getString("userName"),
                                        "postId": controller.postId != null
                                            ? controller.postId
                                            : null,
                                        "profileId": controller.profileId != null
                                            ? controller.profileId
                                            : null
                                      });
                                    }
                                  }
                                }
                              });

                              /* utillMethod.signInWithApple().then((value)  async {
                    print("user detaile");
                    print(value);

                    print(value.email);
                    print(value.identityToken);
                    print(value.givenName);
                    final signInWithAppleEndpoint = Uri(
                      scheme: 'https',
                      host: 'flutter-sign-in-with-apple-example.glitch.me',
                      path: '/sign_in_with_apple',
                      queryParameters: <String, String>{
                        'code': value.authorizationCode,
                        if (value.givenName != null)
                          'firstName': value.givenName,
                        if (value.familyName != null)
                          'lastName': value.familyName,
                        'useBundleId':
                        !kIsWeb && (Platform.isIOS || Platform.isMacOS)
                            ? 'true'
                            : 'false',
                        if (value.state != null) 'state': value.state,
                      },
                    );

                    final session = await http.Client().post(
                      signInWithAppleEndpoint,
                    );
                      print("<=================== SESSION ===============>");
                      print(session.body);
                    // print(value.user.displayName);
                    // print(value.user.phoneNumber);
                    // print(value.user.photoURL);
                  });*/
                            },
                          )
                        : SizedBox.shrink()
                    : TextCustomButton(
                  callFromLogin: true,
                        buttonText: Strings.signInWithApple,
                        id: 1,
                        image: 'assets/images/apple.png',
                        onPressed: () async {
                          LoginController controller;
                          if (Get.isRegistered<LoginController>()) {
                            controller = Get.find<LoginController>();
                          } else {
                            controller = Get.put(LoginController());
                          }
                          var response;
                          final appleProvider = AppleAuthProvider();

                          final userCredential = await FirebaseAuth.instance
                              .signInWithPopup(appleProvider);
                          final value = userCredential.user;
                          int id = 2;

                          if (value.email == null ||
                              value.displayName == null ||
                              value.uid == null ||
                              value.email.isEmpty ||
                              value.displayName.isEmpty ||
                              value.uid.isEmpty) {
                            Get.snackbar("Error",
                                'Somthing went wrong with configuration. please try again');
                          } else if (value.email.contains("privaterelay")) {
                            Get.snackbar("Alert",
                                "Please allow email to continue with werfie");
                            await FirebaseAuth.instance.signOut();
                          } else {
                            showDialog(
                                barrierDismissible: false,
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    backgroundColor:
                                        Color(0xFFFFFFFF).withOpacity(0.2),
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10.0))),
                                    insetPadding: EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 0),
                                    contentPadding: EdgeInsets.zero,
                                    content: Container(
                                      height: 100,
                                      width: 80,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          SpinKitCircle(
                                            color: Theme.of(context).primaryColor,
                                            size: 50.0,
                                          ),
                                          Text(
                                            Strings.pleaseWait,
                                            style: TextStyle(color: Colors.white),
                                          )
                                        ],
                                      ),
                                    ),
                                  );
                                });
                          }

                          response =
                              await controller.SocialLogin(queryParameters: {
                            "email": value.email,
                            "firstname": value.displayName,
                            "login_type": 'apple',
                            "social_id": value.uid,
                          }, token: {
                            "Authorization": " Bearer ${Url.webAPIKey}"
                          });
                          var jsonResponse = jsonDecode(response.toString());
                          // storage.write("email", value.email.toString());
                          // shared.setString("email", value.email.toString());

                          var responseCode = jsonResponse['meta']['code'];
                          var userName = jsonResponse['data']['username'];
                          var token = jsonResponse['data']['token'];
                          var userId = jsonResponse['data']['id'];
                          var email = jsonResponse['data']['email'];
                          shared = await SharedPreferences.getInstance();
                          if (responseCode == 200) {
                            storage.write("email", email.toString());

                            shared.setString("token", token.toString());
                            shared.setString("userName", userName.toString());
                            storage.write('id', userId);
                            storage.write("token", token.toString());
                            shared.setBool('guestUser', true);
                            shared.setBool('socialLogin', true);
                            storage.write("userName", userName.toString());

                            storage.write("remember", isCheckedGlobal);

                            controller.generateFCMToken(context);
                            controller.updateInitialWelcomeMsg(true);

                            Get.put(NewsfeedController(
                                // linkId: controller.postId != null ? controller.postId : null,
                                // profileId: controller.profileId != null ? controller.profileId : null,
                                ));
                            Get.find<NewsfeedController>().languageData =
                                await Get.find<NewsfeedController>()
                                    .getLanguages();
                            Get.find<NewsfeedController>()
                                    .selectedAppLanguageInfoId =
                                Get.find<NewsfeedController>()
                                    .languageData
                                    .appLang
                                    .id;

                            Get.find<NewsfeedController>().upDateLocale(
                                Get.find<NewsfeedController>()
                                    .languageData
                                    .appLang
                                    .code);
                            Get.find<NewsfeedController>().update();
                            {
                              if (kIsWeb) {
                                if (id == 2) {
                                  SingleTone.instance.socialLogin = true;
                                  Navigator.pop(context);
                                  // Routemaster.of(context).pop();
                                  String userName = shared.getString("userName");

                                  Get.offNamed(FluroRouters.mainScreen);
                                } else {
                                  SingleTone.instance.socialLogin = true;
                                  Navigator.pop(context);
                                  String userName = shared.getString("userName");
                                  // print({"userName on mainScreen :  $userName"});
                                  // print('postsid:${controller.postId}');
                                  // print('profileId:${controller.profileId}');
                                  Get.offNamed(FluroRouters.mainScreen);
                                }
                              } else {
                                SingleTone.instance.socialLogin = true;
                                print('route is else here');
                                Get.back();

                                Get.offAll(MainScreen(), arguments: {
                                  "userName": shared.getString("userName"),
                                  "postId": controller.postId != null
                                      ? controller.postId
                                      : null,
                                  "profileId": controller.profileId != null
                                      ? controller.profileId
                                      : null
                                });
                              }
                            }
                          }
                        },
                      ),

                SizedBox(height: 10),

                /// google Sign in Button
                Shortcuts(
                  shortcuts: {
                    LogicalKeySet(LogicalKeyboardKey.tab): GoogleSignupButton(),
                  },
                  child: Actions(
                    actions: {
                      GoogleSignupButton:
                          CallbackAction<GoogleSignupButton>(onInvoke: (_) {
                        controller.focus5.unfocus();
                        FocusScope.of(context).requestFocus(controller.focus1);
                      }),
                    },
                    child: SizedBox(
                      child: TextCustomButton(
                        callFromLogin: true,
                        buttonText: Strings.loginWithGoogle,
                        id: Theme.of(context).brightness == Brightness.dark
                            ? 0
                            : 1,
                        image: 'assets/images/google.png',
                        focusNode: controller.focus5,
                        onPressed: () async {
                          // var internetStatus=await UtilsMethods.checkInternet();
                          // if(internetStatus!=true){
                          //   UtilsMethods.toastMessageShow(Colors.red, Colors.red, Colors.red,
                          //     message: Strings.noInternetAvailable,
                          //   );
                          // }
                          // else{
                          var response;
                          UtilsMethods utillMethod = UtilsMethods();
                          await utillMethod
                              .signInWithGoogle()
                              .then((value) async {
                            /* if(!kIsWeb)*/ {
                              showDialog(
                                  barrierDismissible: false,
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      backgroundColor:
                                          Color(0xFFFFFFFF).withOpacity(0.2),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10.0))),
                                      insetPadding: EdgeInsets.symmetric(
                                          horizontal: 0, vertical: 0),
                                      contentPadding: EdgeInsets.zero,
                                      content: Container(
                                        height: 100,
                                        width: 80,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: [
                                            SpinKitCircle(
                                              color:
                                                  Theme.of(context).primaryColor,
                                              size: 50.0,
                                            ),
                                            Text(
                                              Strings.pleaseWait,
                                              style:
                                                  TextStyle(color: Colors.white),
                                            )
                                          ],
                                        ),
                                      ),
                                    );
                                  });
                            }
                            response =
                                await controller.SocialLogin(queryParameters: {
                              "email": value.email,
                              "firstname": value.displayName ?? "",
                              "login_type": 'google',
                              "social_id": value.uid,
                            }, token: {
                              "Authorization": " Bearer ${Url.webAPIKey}"
                            });
                                print("LOGIN WITH GGOGLE");
                                print(response);
                            var jsonResponse = jsonDecode(response.toString());
                            // storage.write("email", value.email.toString());
                            // shared.setString("email", value.email.toString());

                            var responseCode = jsonResponse['meta']['code'];
                            var userName = jsonResponse['data']['username'];
                            var token = jsonResponse['data']['token'];
                            var userId = jsonResponse['data']['id'];
                            var email = jsonResponse['data']['email'];
                            shared = await SharedPreferences.getInstance();
                            if (responseCode == 200) {
                              storage.write("email", email.toString());

                              shared.setString("token", token.toString());
                              shared.setString("userName", userName.toString());
                              storage.write('id', userId);
                              storage.write("token", token.toString());
                              shared.setBool('guestUser', true);
                              shared.setBool('socialLogin', true);
                              storage.write("userName", userName.toString());

                              storage.write("remember", isCheckedGlobal);

                              controller.generateFCMToken(context);
                              controller.updateInitialWelcomeMsg(true);

                              if (Get.isRegistered<NewsfeedController>()) {
                                Get.delete<NewsfeedController>();
                                if (kDebugMode) {
                                  print(
                                      'newfees controller is removed at login  controller0');
                                }
                                Get.put(NewsfeedController(
                                  linkId: controller.postId != null
                                      ? controller.postId
                                      : null,
                                  profileId: controller.profileId != null
                                      ? controller.profileId
                                      : null,
                                ));
                              } else {
                                Get.put(NewsfeedController(
                                  linkId: controller.postId != null
                                      ? controller.postId
                                      : null,
                                  profileId: controller.profileId != null
                                      ? controller.profileId
                                      : null,
                                ));
                                if (kDebugMode) {
                                  print(
                                      'newfees controller is initalized at login  controller0');
                                }
                              }

                              Get.find<NewsfeedController>().languageData =
                                  await Get.find<NewsfeedController>()
                                      .getLanguages();
                              Get.find<NewsfeedController>()
                                      .selectedAppLanguageInfoId =
                                  Get.find<NewsfeedController>()
                                      .languageData
                                      .appLang
                                      .id;

                              Get.find<NewsfeedController>().upDateLocale(
                                  Get.find<NewsfeedController>()
                                      .languageData
                                      .appLang
                                      .code);
                              Get.find<NewsfeedController>().update();
                              {
                                if (kIsWeb) {
                                  if (id == 2) {
                                    SingleTone.instance.socialLogin = true;
                                    Navigator.pop(context);
                                    // Routemaster.of(context).pop();
                                    String userName =
                                        shared.getString("userName");
                                    // print(
                                    //     {"userName on mainScreen :  $userName"});
                                    // print('postsid:${controller.postId}');
                                    // print('profileId:${controller.profileId}');
                                    Get.offNamed(FluroRouters.mainScreen);
                                    // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                    //
                                    //
                                    //   "userName": shared.getString("userName"),
                                    //   "postId": controller.postId != null
                                    //       ? controller.postId
                                    //       : null,
                                    //   "profileId": controller.profileId != null
                                    //       ? controller.profileId
                                    //       : null
                                    // });
                                  } else {
                                    SingleTone.instance.socialLogin = true;
                                    Navigator.pop(context);
                                    String userName =
                                        shared.getString("userName");
                                    // print(
                                    //     {"userName on mainScreen :  $userName"});
                                    // print('postsid:${controller.postId}');
                                    // print('profileId:${controller.profileId}');
                                    Get.offNamed(FluroRouters.mainScreen);

                                    // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
                                    //
                                    //
                                    //   "userName": shared.getString("userName"),
                                    //   "postId": controller.postId != null
                                    //       ? controller.postId
                                    //       : null,
                                    //   "profileId": controller.profileId != null
                                    //       ? controller.profileId
                                    //       : null
                                    // });
                                  }
                                  debugPrint(
                                      'Welcome Message Showing web 0 ${controller.isShowWelcomeMsg}');
                                } else {
                                  SingleTone.instance.socialLogin = true;
                                  print('route is else here');
                                  Get.back();

                                  Get.offAll(MainScreen(), arguments: {
                                    "userName": shared.getString("userName"),
                                    "postId": controller.postId != null
                                        ? controller.postId
                                        : null,
                                    "profileId": controller.profileId != null
                                        ? controller.profileId
                                        : null
                                  });
                                  debugPrint(
                                      'Welcome Message Showing 0 ${controller.isShowWelcomeMsg}');
                                }
                              }
                            }
                          });
                          // }
                        },
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                TextCustomButton(
                  callFromLogin: true,
                  buttonText: "Login with WorldNoor",
                  image: 'assets/worldnoor/worldnoor_logo.png',
                  id: Theme.of(context).brightness == Brightness.dark
                      ? 0
                      : 1,
                  onPressed: (){
                    //dialogLoginWithWorldNoor();
                    if(kIsWeb){
                      LoginWithWorldNoor().dialogLoginWithWorldNoorUsingCredentials(context);
                    }else {
                      LoginWithWorldNoor().dialogLoginWithWorldNoor(context,
                          futureBuilderGetDataFromWorldNoorApp: futureBuilderGetDataFromWorldNoorApp,
                          socialLoginWithPosh: socialLoginWithPosh);
                    }
                    },
                ),
                const SizedBox(height: 10),
                /* Container(
                height: 45,
                child: TextCustomButton(buttonText: 'Sign Up with Apple',id: 1,
                  image: 'assets/images/apple.png',
                  onPressed: (){

                  },
                ),
              ),*/
              ],
            ),
          ),
        ],
      ),
    );
  }

  verifyCaptchaToken(String token) async {
    Uri uri = Uri.parse('https://www.google.com/recaptcha/api/siteverify');
    final response = await http.post(uri, body: {
      'secret': '6LcIi0EoAAAAABSab2GFSPnihdHzMZ2-u9rYUOdY',
      'response': token,
    }, headers: {
      'Access-Control-Allow-Origin': '*'
    });
    final Map<String, dynamic> jsonResponse = json.decode(response.body);
    LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", jsonResponse);

    if (jsonResponse['success']) {
      LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", response.body);
      isCaptchaSelected = true;
      Navigator.of(context).pop();
      DialogBuilder(context).showLoadingIndicator();

      var apiresponse = await controller.login(queryParameters: {
        "email": controller.email.text,
        "password": controller.password.text
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });

      var jsonResponse = jsonDecode(apiresponse.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        shared.setString("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString("userName", userName.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', false);
        storage.write('id', userId);
        storage.write("token", token.toString());
        storage.write("email", email.toString());

        storage.write("CurrentEmail", controller.email.text);

        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.email.clear();
        controller.password.clear();
        controller.generateFCMToken(context);
        //  NewsfeedController newsfeedController;
        // newsfeedController=
        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();
          if (kDebugMode) {
            print('newfees controller is removed at login  controller1');
          }
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
                controller.profileId != null ? controller.profileId : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
                controller.profileId != null ? controller.profileId : null,
          ));

        }

        // newsfeedController .languageData= await newsfeedController.getLanguages();
        Get.find<NewsfeedController>().languageData =
            await Get.find<NewsfeedController>().getLanguages();
        int index =
            Get.find<NewsfeedController>().languagesList.indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.appLang.id ==
              element.id;
        });

        int index2 = Get.find<NewsfeedController>()
            .translationLanguage
            .indexWhere((element) {
          return Get.find<NewsfeedController>().languageData.myLang.id ==
              element.id;
        });

        Get.find<NewsfeedController>().dropdownValue =
            Get.find<NewsfeedController>().languagesList[index];

        Get.find<NewsfeedController>().dropdownValue1 =
            Get.find<NewsfeedController>().translationLanguage[index2];

        // print("idhr sdfsdf");

        // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
        //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
        //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
        //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
        // );
        //
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
        // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");

        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);
        Get.find<NewsfeedController>().update();

        if (kIsWeb) {
          if (id == 2) {
            SingleTone.instance.socialLogin = false;
            DialogBuilder(context).hideOpenDialog();

            // Navigator.pop(context);
            // Routemaster.of(context).pop();

            String userName = shared.getString("userName");
            // print({
            //   "userName on mainScreen :  $userName"
            // });
            // print(
            //     'postsid:${controller.postId}');
            // print(
            //     'profileId:${controller.profileId}');
            Get.offNamed(FluroRouters.mainScreen);

            // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
            //
            //
            //   "userName": shared.getString("userName"),
            //   "postId": controller.postId != null
            //       ? controller.postId
            //       : null,
            //   "profileId": controller.profileId != null
            //       ? controller.profileId
            //       : null
            // });
          } else {
            SingleTone.instance.socialLogin = false;
            // Routemaster.of(context).pop();
            // Navigator.pop(context);
            DialogBuilder(context).hideOpenDialog();

            String userName = shared.getString("userName");
            // print({
            //   "userName on mainScreen :  $userName"
            // });
            // print(
            //     'postsid:${controller.postId}');
            // print(
            //     'profileId:${controller.profileId}');
            Get.offNamed(FluroRouters.mainScreen);

            // Routemaster.of(context).replace(
            //     AppRoute.mainScreen, queryParameters: {
            //
            //
            //   "userName": shared.getString("userName"),
            //   "postId": controller.postId != null
            //       ? controller.postId
            //       : null,
            //   "profileId": controller.profileId != null
            //       ? controller.profileId
            //       : null
            // });
          }
        } else {
          SingleTone.instance.socialLogin = false;
          // Get.back();
          DialogBuilder(context).hideOpenDialog();

          Get.offAll(MainScreen(), arguments: {
            "userName": shared.getString("userName"),
            "postId": controller.postId != null ? controller.postId : null,
            "profileId":
                controller.profileId != null ? controller.profileId : null
          });
        }

        // Get.offAll(MainScreen(
        //   userName: shared.getString("userName"),
        //   postId: controller.postId != null
        //       ? controller.postId
        //       : null,
        //   profileId: controller.profileId != null
        //       ? controller.profileId
        //       : null,
        // ));
        // Navigator.of(context).pushAndRemoveUntil(
        //     MaterialPageRoute(
        //         builder: (context) => MainScreen(
        //               userName: userName,
        //               postId: controller.postId != null
        //                   ? controller.postId
        //                   : null,
        //               profileId: controller.profileId != null
        //                   ? controller.profileId
        //                   : null,
        //             )),
        //     (Route<dynamic> route) => false);
        // Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //     builder: (BuildContext context) =>
        //         MainScreen(userName: userName),
        // ),
        // );
      } else {
        // Navigator.of(context).pop();
        DialogBuilder(context).hideOpenDialog();

        customDialog(
          context,
          isSuccess: true,
          message: Strings.emailOrPasswordIsIncorrect,
        );
      }
    } else {
      LoggingUtils.printValue("API RESPONSE VERIFY CAPTCHA", response.body);

      isCaptchaSelected = false;
    }
  }

  Future<Map<String, dynamic>> getDataFromWorldNoorApp() async {
    var extraData;
    Map<String, dynamic> dataFromWorldNoorApp;
    try {
      final String result =
          await platform.invokeMethod('readDataFromWorldNoor');
      extraData = result;
      dataFromWorldNoorApp = json.decode(extraData);
      if (dataFromWorldNoorApp != null &&
          dataFromWorldNoorApp.isNotEmpty &&
          (dataFromWorldNoorApp["isAutoLogin"] as bool || widget.isAutoLogin)) {
        if(widget.isFromWorldNoorApp != 2)
          socialLoginWithPosh(dataFromWorldNoorApp);
      }
    } on PlatformException catch (e) {
      extraData = "Failed to get data: '${e.message}'.";
    }

    print("========> WORLD NOOR MAP DATA");
    print(dataFromWorldNoorApp);
    return dataFromWorldNoorApp;
  }

  socialLoginWithPosh(Map<String, dynamic> map) async {
    var response;

    try {
      DialogBuilder(context).showLoadingIndicator();
      response = await controller.SocialLogin(queryParameters: {
        "login_type": 'posh',
        "social_id": map["poshId"],
        "wntoken": map["token"]
      }, token: {
        "Authorization": " Bearer ${Url.webAPIKey}"
      });
      var jsonResponse = jsonDecode(response.toString());
      // storage.write("email", value.email.toString());
      // shared.setString("email", value.email.toString());

      var responseCode = jsonResponse['meta']['code'];
      var userName = jsonResponse['data']['username'];
      var token = jsonResponse['data']['token'];
      var userId = jsonResponse['data']['id'];
      var email = jsonResponse['data']['email'];
      shared = await SharedPreferences.getInstance();
      if (responseCode == 200) {
        storage.write("email", email.toString());

        shared.setString("token", token.toString());
        shared.setString("userName", userName.toString());
        storage.write('id', userId);
        storage.write("token", token.toString());
        shared.setBool('guestUser', true);
        shared.setBool('socialLogin', true);
        storage.write("userName", userName.toString());

        storage.write("remember", isCheckedGlobal);

        controller.generateFCMToken(context);
        controller.updateInitialWelcomeMsg(true);

        if (Get.isRegistered<NewsfeedController>()) {
          Get.delete<NewsfeedController>();
          if (kDebugMode) {
            print('newfees controller is removed at login  controller0');
          }
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
                controller.profileId != null ? controller.profileId : null,
          ));
        } else {
          Get.put(NewsfeedController(
            linkId: controller.postId != null ? controller.postId : null,
            profileId:
                controller.profileId != null ? controller.profileId : null,
          ));
        }

        Get.find<NewsfeedController>().languageData =
            await Get.find<NewsfeedController>().getLanguages();
        Get.find<NewsfeedController>().selectedAppLanguageInfoId =
            Get.find<NewsfeedController>().languageData.appLang.id;

        Get.find<NewsfeedController>().upDateLocale(
            Get.find<NewsfeedController>().languageData.appLang.code);
        Get.find<NewsfeedController>().update();
        {
          if (kIsWeb) {
            if (id == 2) {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              // Routemaster.of(context).pop();
              String userName = shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);
              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            } else {
              SingleTone.instance.socialLogin = true;
              Navigator.pop(context);
              String userName = shared.getString("userName");
              // print(
              //     {"userName on mainScreen :  $userName"});
              // print('postsid:${controller.postId}');
              // print('profileId:${controller.profileId}');
              Get.offNamed(FluroRouters.mainScreen);

              // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
              //
              //
              //   "userName": shared.getString("userName"),
              //   "postId": controller.postId != null
              //       ? controller.postId
              //       : null,
              //   "profileId": controller.profileId != null
              //       ? controller.profileId
              //       : null
              // });
            }
            debugPrint(
                'Welcome Message Showing web 0 ${controller.isShowWelcomeMsg}');
          } else {
            SingleTone.instance.socialLogin = true;
            print('route is else here');
            Get.back();
            DialogBuilder(context).hideOpenDialog();

            Get.offAll(
                MainScreen(
                  isLoggedInFromPosh: true,
                ),
                arguments: {
                  "userName": shared.getString("userName"),
                  "postId":
                      controller.postId != null ? controller.postId : null,
                  "profileId":
                      controller.profileId != null ? controller.profileId : null
                });
          }
        }
      } else {
        Fluttertoast.showToast(
          msg: jsonResponse['meta']['message'].toString(),
          toastLength: Toast.LENGTH_SHORT,
          // or Toast.LENGTH_LONG
          gravity: ToastGravity.BOTTOM,
          // Location of the toast message
          timeInSecForIosWeb: 1,
          // Time duration for which the message will be displayed
          backgroundColor: Colors.grey,
          textColor: Colors.white,
          fontSize: 16.0,
        );
        DialogBuilder(context).hideOpenDialog();
      }
    } catch (e) {
      print("EXCEPTION SOCIAL LOGIN WITH POSH MOBILE");
      Fluttertoast.showToast(
        msg: "Sorry for the inconvenience. Please try again later.",
        toastLength: Toast.LENGTH_SHORT,
        // or Toast.LENGTH_LONG
        gravity: ToastGravity.BOTTOM,
        // Location of the toast message
        timeInSecForIosWeb: 1,
        // Time duration for which the message will be displayed
        backgroundColor: Colors.grey,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      DialogBuilder(context).hideOpenDialog();
    }

    // }
  }

  login(String emailAndPhone,String password){


  }
}

class OtpDialog extends StatefulWidget {
  final Function(String otp) onSubmit;

  const OtpDialog({Key key, this.onSubmit}) : super(key: key);

  @override
  _OtpDialogState createState() => _OtpDialogState();
}

class _OtpDialogState extends State<OtpDialog> {
  final TextEditingController _otpController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'Two-factor authentication',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
      ),
      content: /*TextField(
        controller: _otpController,
        keyboardType: TextInputType.number,
        maxLength: 6,
        inputFormatters: [
          FilteringTextInputFormatter.digitsOnly,
        ],
        decoration: InputDecoration(hintText: 'Enter OTP'),
      )*/
          Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Enter 6-digits verification code Sent to your registered email',
            style: TextStyle(
              fontSize: 14,
            ),
          ),
          SizedBox(
            height: 20,
          ),
          PinCodeTextField(
            controller: _otpController,
            length: 6,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            obscureText: false,
            keyboardType: TextInputType.number,
            appContext: context,
            autoFocus: true,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            widget.onSubmit(_otpController.text);
          },
          child: Text('Submit'),
        ),
      ],
    );
  }
}

//
// Widget loginForm1(
//     BuildContext context, LoginController controller, formKey, id) {
//   SharedPreferences shared;
//
//   final storage = GetStorage();
//   bool isCheckedGlobal = false;
//
//   return Column(
//     mainAxisAlignment: MainAxisAlignment.center,
//     crossAxisAlignment: CrossAxisAlignment.center,
//     children: [
//       //  SizedBox(height: 30),
//       kIsWeb && id == 1
//           ? MouseRegion(
//               cursor: SystemMouseCursors.click,
//               child: GestureDetector(
//                 onTap: () async {
//                   shared = await SharedPreferences.getInstance();
//                   shared.setBool('guestUser', true);
//                   Routemaster.of(context).push(
//                     AppRoute.guestUserMainScreen,
//                   );
//                 },
//                 child: Align(
//                   alignment: Alignment.topLeft,
//                   child: Icon(
//                     Icons.cancel,
//                     size: 20,
//                     color: Colors.black,
//                   ),
//                 ),
//               ),
//             )
//           : SizedBox(),
//       kIsWeb
//           ? Align(
//               alignment: Alignment.center,
//               child: Text(
//                 'Login',
//                 style: Styles.baseTextTheme.headline2.copyWith(
//                   color: Theme.of(context).brightness == Brightness.dark
//                       ? Colors.white
//                       : Colors.black,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 20,
//                 ),
//               ),
//             )
//           : Container(
//               width: 250,
//               // height: 150,
//               // color: Colors.grey,
//               child: Image.asset(
//                 AppImages.logo,
//               ),
//             ),
//       !kIsWeb
//           ? Align(
//               alignment: Alignment.center,
//               child: Text(
//                 'Login',
//                 style: Styles.baseTextTheme.headline2.copyWith(
//                   color: Theme.of(context).brightness == Brightness.dark
//                       ? Colors.white
//                       : Colors.black,
//                   fontWeight: FontWeight.bold,
//                   fontSize: 20,
//                 ),
//               ),
//             )
//           : SizedBox(),
//       SizedBox(height: 10),
//       //  SizedBox(height: 30),
//       Form(
//         key: formKey,
//         child: Column(
//           children: [
//             Shortcuts(
//               shortcuts: {
//                 LogicalKeySet(LogicalKeyboardKey.tab): EnterName(),
//               },
//               child: Actions(
//                 actions: {
//                   EnterName: CallbackAction<EnterName>(onInvoke: (_) {
//                     controller.focus1.unfocus();
//                     FocusScope.of(context).requestFocus(controller.focus2);
//                   }),
//                 },
//                 child: Container(
//                   // height: 55,
//                   child: InputField(
//                     focusNode: controller.focus1,
//
//                     TextInputAction: TextInputAction.next,
//                     onChanged: (_) {},
//                     hint: Strings.enterYourEmail,
//
//                     onValueEntered: (_) {},
//                     // onValueEntered: (value) {
//                     //   print('value will be' + value);
//                     //   value = email.text;
//                     // },
//                     controller: controller.email,
//                     validator: FormBuilderValidators.compose([
//                       FormBuilderValidators.required(context,
//                           errorText: Strings.emailFieldCannotBeEmpty),
//                       FormBuilderValidators.email(context,
//                           errorText: Strings.emailFormatIsInvalid),
//                     ]),
//                     textInputType: TextInputType.emailAddress,
//                     fieldIcon: Icons.email,
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(height: 20),
//             Shortcuts(
//               shortcuts: {
//                 LogicalKeySet(LogicalKeyboardKey.tab): EnterPasswords(),
//               },
//               child: Actions(
//                 actions: {
//                   EnterPasswords: CallbackAction<EnterPasswords>(onInvoke: (_) {
//                     controller.focus2.unfocus();
//                     FocusScope.of(context).requestFocus(controller.focus3);
//                   }),
//                 },
//                 child: Container(
//                   // height: 55,
//                   child: InputPasswordField(
//                     focusNode: controller.focus2,
//                     nextNode: controller.focus4,
//                     TextInputAction: TextInputAction.next,
//                     // onPasswordEntered: (value) {
//                     //   value = password.text;
//                     // },
//                     text: Strings.enterYourPassword,
//                     controller: controller.password,
//                   //  errorText:passwordError ,
//                     validator: (value) {
//                       return UtilsMethods.validatePassword(value);
//                     },
//                   ),
//                 ),
//               ),
//             ),
//
//             SizedBox(height: 10),
//             // id==2?SizedBox():
//             Shortcuts(
//               shortcuts: {
//                 LogicalKeySet(LogicalKeyboardKey.tab): LostPassword(),
//               },
//               child: Actions(
//                 actions: {
//                   LostPassword: CallbackAction<LostPassword>(onInvoke: (_) {
//                     controller.focus3.unfocus();
//                     FocusScope.of(context).requestFocus(controller.focus4);
//                   }),
//                 },
//                 child: Align(
//                   alignment: Alignment.centerRight,
//                   child: Padding(
//                     padding: const EdgeInsets.only(right: 15.0),
//                     child: TextButton(
//                       onPressed: () {
//                         formKey.currentState?.reset();
//                         if (!kIsWeb) {
//                           Get.to(
//                             // MaterialPageRoute(
//                             //   builder: (context) =>
//                             ResetPasswordScreen(),
//                             // ),
//                           );
//                         } else {
//                           Navigator.pop(context);
//                           Get.toNamed(FluroRouters.resetPasswordScreen);
//                           /* Routemaster.of(context).push(
//                             AppRoute.resetPasswordScreen,
//                           );*/
//                         }
//                       },
//                       focusNode: controller.focus3,
//                       child: Text(
//                         Strings.lostPassword,
//                         style: TextStyle(
//                             color:
//                                 Theme.of(context).brightness == Brightness.dark
//                                     ? Colors.white
//                                     : Colors.black,
//                             fontWeight: FontWeight.w500,
//                             fontSize: 14),
//                         // style: TextStyle(
//                         //   color: Colors.black,
//                         //   fontSize: 13,
//                         // ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(height: 10),
//
//             /// login button
//             Shortcuts(
//               shortcuts: {
//                 LogicalKeySet(LogicalKeyboardKey.tab): LoginButton(),
//               },
//               child: Actions(
//                 actions: {
//                   LoginButton: CallbackAction<LoginButton>(onInvoke: (_) {
//                     controller.focus4.unfocus();
//                     FocusScope.of(context).requestFocus(controller.focus5);
//                   }),
//                 },
//                 child: Container(
//                   width: Get.width,
//                   child: RawKeyboardListener(
//                     focusNode: controller.LoginFocusNode,
//                     onKey: (RawKeyEvent event) async {
//                       if (event.logicalKey == LogicalKeyboardKey.enter) {
//                         print("Muhammad Hassan Raza");
//                         if (formKey.currentState.validate()) {
//                           /*    showDialog(
//                             // barrierDismissible: false,
//                               context: context,
//                               builder: (BuildContext context) {
//                                 return AlertDialog(
//                                   backgroundColor:
//                                   Color(0xFFFFFFFF).withOpacity(0.2),
//                                   shape: RoundedRectangleBorder(
//                                       borderRadius:
//                                       BorderRadius.all(Radius.circular(10.0))),
//                                   insetPadding: EdgeInsets.symmetric(
//                                       horizontal: 0, vertical: 0),
//                                   contentPadding: EdgeInsets.zero,
//                                   content: Container(
//                                     height: 100,
//                                     width: 80,
//                                     child: Column(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.spaceAround,
//                                       children: [
//                                         SpinKitCircle(
//                                           color: Theme.of(context).primaryColor,
//                                           size: 50.0,
//                                         ),
//                                         Text(
//                                           Strings.pleaseWait,
//                                           style: TextStyle(color: Colors.white),
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 );
//                               });*/
//                           DialogBuilder(context).showLoadingIndicator();
//
//                           var response = await controller.login(
//                               queryParameters: {
//                                 "email": controller.email.text,
//                                 "password": controller.password.text
//                               },
//                               token: {
//                                 "Authorization": " Bearer ${Url.webAPIKey}"
//                               });
//                           var jsonResponse = jsonDecode(response.toString());
//
//                           print("jsonResponse $jsonResponse");
//
//                           var responseCode = jsonResponse['meta']['code'];
//                           var userName = jsonResponse['data']['username'];
//                           var token = jsonResponse['data']['token'];
//                           print("token : $token");
//                           var userId = jsonResponse['data']['id'];
//
//                           var email = jsonResponse['data']['email'];
//
//                           shared = await SharedPreferences.getInstance();
//                           DialogBuilder(context).hideOpenDialog();
//
//                           if (responseCode == 200) {
//                             shared.setString("token", token.toString());
//                             shared.setString("userName", userName.toString());
//
//                             shared.setString("email", email.toString());
//
//                             storage.write("email", email.toString());
//
//                             shared.setBool('guestUser', true);
//                             shared.setBool('socialLogin', false);
//                             storage.write('id', userId);
//                             storage.write("token", token.toString());
//
//                             storage.write(
//                                 "CurrentEmail", controller.email.text);
//                             storage.write("userName", userName.toString());
//
//                             storage.write("remember", isCheckedGlobal);
//
//                             controller.email.clear();
//                             controller.password.clear();
//                             controller.generateFCMToken(context);
//                             Get.put(NewsfeedController(
//                                 // linkId: controller.postId != null ? controller.postId : null,
//                                 // profileId: controller.profileId != null ? controller.profileId : null,
//                                 ));
//
//                             Get.find<NewsfeedController>().languageData =
//                                 await Get.find<NewsfeedController>()
//                                     .getLanguages();
//                             int index = Get.find<NewsfeedController>()
//                                 .languagesList
//                                 .indexWhere((element) {
//                               return Get.find<NewsfeedController>()
//                                       .languageData
//                                       .appLang
//                                       .id ==
//                                   element.id;
//                             });
//
//                             int index2 = Get.find<NewsfeedController>()
//                                 .translationLanguage
//                                 .indexWhere((element) {
//                               return Get.find<NewsfeedController>()
//                                       .languageData
//                                       .myLang
//                                       .id ==
//                                   element.id;
//                             });
//
//                             Get.find<NewsfeedController>().dropdownValue =
//                                 Get.find<NewsfeedController>()
//                                     .languagesList[index];
//
//                             Get.find<NewsfeedController>().dropdownValue1 =
//                                 Get.find<NewsfeedController>()
//                                     .translationLanguage[index2];
//
//                             print("idhr sdfsdf");
//
//                             // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
//                             //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
//                             //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
//                             //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
//                             // );
//                             //
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
//
//                             Get.find<NewsfeedController>()
//                                     .selectedAppLanguageInfoId =
//                                 Get.find<NewsfeedController>()
//                                     .languageData
//                                     .appLang
//                                     .id;
//
//                             Get.find<NewsfeedController>().upDateLocale(
//                                 Get.find<NewsfeedController>()
//                                     .languageData
//                                     .appLang
//                                     .code);
//                             Get.find<NewsfeedController>().update();
//
//                             if (kIsWeb) {
//                               if (id == 2) {
//                                 SingleTone.instance.socialLogin = false;
//                                 // Navigator.pop(context);
//                                 // Routemaster.of(context).pop();
//
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//
//                                 // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               } else {
//                                 SingleTone.instance.socialLogin = false;
//                                 // Routemaster.of(context).pop();
//                                 Navigator.pop(context);
//
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//
//                                 // Routemaster.of(context).replace(
//                                 //     AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               }
//                             } else {
//                               SingleTone.instance.socialLogin = false;
//                               Get.back();
//                               Get.offAll(MainScreen(), arguments: {
//                                 "userName": shared.getString("userName"),
//                                 "postId": controller.postId != null
//                                     ? controller.postId
//                                     : null,
//                                 "profileId": controller.profileId != null
//                                     ? controller.profileId
//                                     : null
//                               });
//                             }
//
//                             // Get.offAll(MainScreen(
//                             //   userName: shared.getString("userName"),
//                             //   postId: controller.postId != null
//                             //       ? controller.postId
//                             //       : null,
//                             //   profileId: controller.profileId != null
//                             //       ? controller.profileId
//                             //       : null,
//                             // ));
//                             // Navigator.of(context).pushAndRemoveUntil(
//                             //     MaterialPageRoute(
//                             //         builder: (context) => MainScreen(
//                             //               userName: userName,
//                             //               postId: controller.postId != null
//                             //                   ? controller.postId
//                             //                   : null,
//                             //               profileId: controller.profileId != null
//                             //                   ? controller.profileId
//                             //                   : null,
//                             //             )),
//                             //     (Route<dynamic> route) => false);
//                             // Navigator.push(
//                             //   context,
//                             //   MaterialPageRoute(
//                             //     builder: (BuildContext context) =>
//                             //         MainScreen(userName: userName),
//                             // ),
//                             // );
//                           } else {
//                             Navigator.of(context).pop();
//
//                             customDialog(
//                               context,
//                               isSuccess: true,
//                               message: Strings.emailOrPasswordIsIncorrect,
//                             );
//                           }
//                         }
//                       }
//                     },
//                     child: RoundedButton(
//                       Strings.cLOGIN,
//                       () async {
//                         if (formKey.currentState.validate()) {
//                           /*   showDialog(
//                             // barrierDismissible: false,
//                               context: context,
//                               builder: (BuildContext context) {
//                                 return AlertDialog(
//                                   backgroundColor:
//                                   Color(0xFFFFFFFF).withOpacity(0.2),
//                                   shape: RoundedRectangleBorder(
//                                       borderRadius:
//                                       BorderRadius.all(Radius.circular(10.0))),
//                                   insetPadding: EdgeInsets.symmetric(
//                                       horizontal: 0, vertical: 0),
//                                   contentPadding: EdgeInsets.zero,
//                                   content: Container(
//                                     height: 100,
//                                     width: 80,
//                                     child: Column(
//                                       mainAxisAlignment:
//                                       MainAxisAlignment.spaceAround,
//                                       children: [
//                                         SpinKitCircle(
//                                           color: Theme.of(context).primaryColor,
//                                           size: 50.0,
//                                         ),
//                                         Text(
//                                           Strings.pleaseWait,
//                                           style: TextStyle(color: Colors.white),
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 );
//                               });*/
//                           DialogBuilder(context).showLoadingIndicator();
//
//                           var response = await controller.login(
//                               queryParameters: {
//                                 "email": controller.email.text,
//                                 "password": controller.password.text
//                               },
//                               token: {
//                                 "Authorization": " Bearer ${Url.webAPIKey}"
//                               });
//                           var jsonResponse = jsonDecode(response.toString());
//
//                           print("jsonResponse $jsonResponse");
//
//                           var responseCode = jsonResponse['meta']['code'];
//                           var userName = jsonResponse['data']['username'];
//                           var token = jsonResponse['data']['token'];
//                           print("token : $token");
//                           var userId = jsonResponse['data']['id'];
//                           var email = jsonResponse['data']['email'];
//                           shared = await SharedPreferences.getInstance();
//                           if (responseCode == 200) {
//                             shared.setString("email", email.toString());
//
//                             shared.setString("token", token.toString());
//                             shared.setString("userName", userName.toString());
//                             shared.setBool('guestUser', true);
//                             shared.setBool('socialLogin', false);
//                             storage.write('id', userId);
//                             storage.write("token", token.toString());
//                             storage.write("email", email.toString());
//
//                             storage.write(
//                                 "CurrentEmail", controller.email.text);
//
//                             storage.write("userName", userName.toString());
//
//                             storage.write("remember", isCheckedGlobal);
//
//                             controller.email.clear();
//                             controller.password.clear();
//                             controller.generateFCMToken(context);
//                             Get.put(NewsfeedController(
//                                 // linkId: controller.postId != null ? controller.postId : null,
//                                 // profileId: controller.profileId != null ? controller.profileId : null,
//                                 ));
//
//                             Get.find<NewsfeedController>().languageData =
//                                 await Get.find<NewsfeedController>()
//                                     .getLanguages();
//                             int index = Get.find<NewsfeedController>()
//                                 .languagesList
//                                 .indexWhere((element) {
//                               return Get.find<NewsfeedController>()
//                                       .languageData
//                                       .appLang
//                                       .id ==
//                                   element.id;
//                             });
//
//                             int index2 = Get.find<NewsfeedController>()
//                                 .translationLanguage
//                                 .indexWhere((element) {
//                               return Get.find<NewsfeedController>()
//                                       .languageData
//                                       .myLang
//                                       .id ==
//                                   element.id;
//                             });
//
//                             Get.find<NewsfeedController>().dropdownValue =
//                                 Get.find<NewsfeedController>()
//                                     .languagesList[index];
//
//                             Get.find<NewsfeedController>().dropdownValue1 =
//                                 Get.find<NewsfeedController>()
//                                     .translationLanguage[index2];
//
//                             print("idhr sdfsdf");
//
//                             // Get.find<NewsfeedController>(). dropdownValue = AppLanguage(
//                             //   id:  Get.find<NewsfeedController>().languageData.myLang.id,
//                             //   name:  Get.find<NewsfeedController>().languageData.myLang.name,
//                             //   code:  Get.find<NewsfeedController>().languageData.myLang.code,
//                             // );
//                             //
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.id }");
//                             // print("Get.find<NewsfeedController>(). dropdownValue  ${Get.find<NewsfeedController>(). dropdownValue.name }");
//
//                             Get.find<NewsfeedController>()
//                                     .selectedAppLanguageInfoId =
//                                 Get.find<NewsfeedController>()
//                                     .languageData
//                                     .appLang
//                                     .id;
//
//                             Get.find<NewsfeedController>().upDateLocale(
//                                 Get.find<NewsfeedController>()
//                                     .languageData
//                                     .appLang
//                                     .code);
//                             Get.find<NewsfeedController>().update();
//
//                             if (kIsWeb) {
//                               if (id == 2) {
//                                 SingleTone.instance.socialLogin = false;
//                                 DialogBuilder(context).hideOpenDialog();
//
//                                 // Navigator.pop(context);
//                                 // Routemaster.of(context).pop();
//
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//
//                                 // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               } else {
//                                 SingleTone.instance.socialLogin = false;
//                                 // Routemaster.of(context).pop();
//                                 // Navigator.pop(context);
//                                 DialogBuilder(context).hideOpenDialog();
//
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//
//                                 // Routemaster.of(context).replace(
//                                 //     AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               }
//                             } else {
//                               SingleTone.instance.socialLogin = false;
//                               // Get.back();
//                               DialogBuilder(context).hideOpenDialog();
//
//                               Get.offAll(MainScreen(), arguments: {
//                                 "userName": shared.getString("userName"),
//                                 "postId": controller.postId != null
//                                     ? controller.postId
//                                     : null,
//                                 "profileId": controller.profileId != null
//                                     ? controller.profileId
//                                     : null
//                               });
//                             }
//
//                             // Get.offAll(MainScreen(
//                             //   userName: shared.getString("userName"),
//                             //   postId: controller.postId != null
//                             //       ? controller.postId
//                             //       : null,
//                             //   profileId: controller.profileId != null
//                             //       ? controller.profileId
//                             //       : null,
//                             // ));
//                             // Navigator.of(context).pushAndRemoveUntil(
//                             //     MaterialPageRoute(
//                             //         builder: (context) => MainScreen(
//                             //               userName: userName,
//                             //               postId: controller.postId != null
//                             //                   ? controller.postId
//                             //                   : null,
//                             //               profileId: controller.profileId != null
//                             //                   ? controller.profileId
//                             //                   : null,
//                             //             )),
//                             //     (Route<dynamic> route) => false);
//                             // Navigator.push(
//                             //   context,
//                             //   MaterialPageRoute(
//                             //     builder: (BuildContext context) =>
//                             //         MainScreen(userName: userName),
//                             // ),
//                             // );
//                           } else {
//                             // Navigator.of(context).pop();
//                             DialogBuilder(context).hideOpenDialog();
//
//                             customDialog(
//                               context,
//                               isSuccess: true,
//                               message: Strings.emailOrPasswordIsIncorrect,
//                             );
//                           }
//                         }
//                       },
//                       verticalPadding: kIsWeb ? 20.0 : 15.0,
//                       horizontalPadding: Get.width / 14,
//                       focusNode: controller.focus4,
//                       roundedButtonColor: MyColors.werfieBlue,
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(height: 10),
//             !kIsWeb
//                 ? Platform.isIOS
//                     ?
//                     //Sign in with apple button
//                     TextCustomButton(
//                         buttonText: 'Sign in with Apple',
//                         id: 1,
//                         image: 'assets/images/apple.png',
//                         onPressed: () async {
//                           LoginController loginController;
//                           if (Get.isRegistered<LoginController>()) {
//                             loginController = Get.find<LoginController>();
//                           } else {
//                             loginController = Get.put(LoginController());
//                           }
//                           var response;
//                           // doSignInApple();
//                           UtilsMethods utillMethod = UtilsMethods();
//                           AuthService authService = AuthService();
//                           await authService.signInWithApple(scopes: [
//                             Scope.email,
//                             Scope.fullName
//                           ]).then((value) async {
//                             print('uid: ${value}');
//                             print('uid: ${value.uid}');
//                             print('uid: ${value.email}');
//                             print('uid: ${value.displayName}');
//                             if (value.email == null ||
//                                 value.displayName == null ||
//                                 value.uid == null ||
//                                 value.email.isEmpty ||
//                                 value.displayName.isEmpty ||
//                                 value.uid.isEmpty) {
//                               Get.snackbar("Error",
//                                   'Somthing went wrong with configuration. please try again');
//                             } else if (value.email.contains("privaterelay")) {
//                               Get.snackbar("Alert",
//                                   "Please allow email to continue with werfie");
//                               await FirebaseAuth.instance.signOut();
//
//                               print('uid: please allow email to continue');
//                             } else {
//                               showDialog(
//                                   // barrierDismissible: false,
//                                   context: context,
//                                   builder: (BuildContext context) {
//                                     return AlertDialog(
//                                       backgroundColor:
//                                           Color(0xFFFFFFFF).withOpacity(0.2),
//                                       shape: RoundedRectangleBorder(
//                                           borderRadius: BorderRadius.all(
//                                               Radius.circular(10.0))),
//                                       insetPadding: EdgeInsets.symmetric(
//                                           horizontal: 0, vertical: 0),
//                                       contentPadding: EdgeInsets.zero,
//                                       content: Container(
//                                         height: 100,
//                                         width: 80,
//                                         child: Column(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.spaceAround,
//                                           children: [
//                                             SpinKitCircle(
//                                               color: Theme.of(context)
//                                                   .primaryColor,
//                                               size: 50.0,
//                                             ),
//                                             Text(
//                                               Strings.pleaseWait,
//                                               style: TextStyle(
//                                                   color: Colors.white),
//                                             )
//                                           ],
//                                         ),
//                                       ),
//                                     );
//                                   });
//                             }
//                             response =
//                                 await controller.SocialLogin(queryParameters: {
//                               "email": value.email,
//                               "firstname": value.displayName,
//                               "login_type": 'apple',
//                               "social_id": value.uid,
//                             }, token: {
//                               "Authorization": " Bearer ${Url.webAPIKey}"
//                             });
//                             var jsonResponse = jsonDecode(response.toString());
//                             print("jsonResponse $jsonResponse");
//                             // storage.write("email", value.email.toString());
//                             // shared.setString("email", value.email.toString());
//
//                             var responseCode = jsonResponse['meta']['code'];
//                             var userName = jsonResponse['data']['username'];
//                             var token = jsonResponse['data']['token'];
//                             print("token : $token");
//                             var userId = jsonResponse['data']['id'];
//                             var email = jsonResponse['data']['email'];
//                             shared = await SharedPreferences.getInstance();
//                             if (responseCode == 200) {
//                               storage.write("email", email.toString());
//
//                               shared.setString("token", token.toString());
//                               shared.setString("userName", userName.toString());
//                               storage.write('id', userId);
//                               storage.write("token", token.toString());
//                               shared.setBool('guestUser', true);
//                               shared.setBool('socialLogin', true);
//                               storage.write("userName", userName.toString());
//
//                               storage.write("remember", isCheckedGlobal);
//
//                               controller.generateFCMToken(context);
//                               Get.put(NewsfeedController(
//                                   // linkId: controller.postId != null ? controller.postId : null,
//                                   // profileId: controller.profileId != null ? controller.profileId : null,
//                                   ));
//                               Get.find<NewsfeedController>().languageData =
//                                   await Get.find<NewsfeedController>()
//                                       .getLanguages();
//                               Get.find<NewsfeedController>()
//                                       .selectedAppLanguageInfoId =
//                                   Get.find<NewsfeedController>()
//                                       .languageData
//                                       .appLang
//                                       .id;
//
//                               Get.find<NewsfeedController>().upDateLocale(
//                                   Get.find<NewsfeedController>()
//                                       .languageData
//                                       .appLang
//                                       .code);
//                               Get.find<NewsfeedController>().update();
//                               {
//                                 if (kIsWeb) {
//                                   if (id == 2) {
//                                     SingleTone.instance.socialLogin = true;
//                                     Navigator.pop(context);
//                                     // Routemaster.of(context).pop();
//                                     String userName =
//                                         shared.getString("userName");
//                                     print({
//                                       "userName on mainScreen :  $userName"
//                                     });
//                                     print('postsid:${controller.postId}');
//                                     print('profileId:${controller.profileId}');
//                                     Get.offNamed(FluroRouters.mainScreen);
//                                     // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                     //
//                                     //
//                                     //   "userName": shared.getString("userName"),
//                                     //   "postId": controller.postId != null
//                                     //       ? controller.postId
//                                     //       : null,
//                                     //   "profileId": controller.profileId != null
//                                     //       ? controller.profileId
//                                     //       : null
//                                     // });
//                                   } else {
//                                     SingleTone.instance.socialLogin = true;
//                                     Navigator.pop(context);
//                                     String userName =
//                                         shared.getString("userName");
//                                     print({
//                                       "userName on mainScreen :  $userName"
//                                     });
//                                     print('postsid:${controller.postId}');
//                                     print('profileId:${controller.profileId}');
//                                     Get.offNamed(FluroRouters.mainScreen);
//
//                                     // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                     //
//                                     //
//                                     //   "userName": shared.getString("userName"),
//                                     //   "postId": controller.postId != null
//                                     //       ? controller.postId
//                                     //       : null,
//                                     //   "profileId": controller.profileId != null
//                                     //       ? controller.profileId
//                                     //       : null
//                                     // });
//                                   }
//                                 } else {
//                                   SingleTone.instance.socialLogin = true;
//                                   print('route is else here');
//                                   Get.back();
//
//                                   Get.offAll(MainScreen(), arguments: {
//                                     "userName": shared.getString("userName"),
//                                     "postId": controller.postId != null
//                                         ? controller.postId
//                                         : null,
//                                     "profileId": controller.profileId != null
//                                         ? controller.profileId
//                                         : null
//                                   });
//                                 }
//                               }
//                             }
//                           });
//
//                           /* utillMethod.signInWithApple().then((value)  async {
//                   print("user detaile");
//                   print(value);
//
//                   print(value.email);
//                   print(value.identityToken);
//                   print(value.givenName);
//                   final signInWithAppleEndpoint = Uri(
//                     scheme: 'https',
//                     host: 'flutter-sign-in-with-apple-example.glitch.me',
//                     path: '/sign_in_with_apple',
//                     queryParameters: <String, String>{
//                       'code': value.authorizationCode,
//                       if (value.givenName != null)
//                         'firstName': value.givenName,
//                       if (value.familyName != null)
//                         'lastName': value.familyName,
//                       'useBundleId':
//                       !kIsWeb && (Platform.isIOS || Platform.isMacOS)
//                           ? 'true'
//                           : 'false',
//                       if (value.state != null) 'state': value.state,
//                     },
//                   );
//
//                   final session = await http.Client().post(
//                     signInWithAppleEndpoint,
//                   );
//                     print("<=================== SESSION ===============>");
//                     print(session.body);
//                   // print(value.user.displayName);
//                   // print(value.user.phoneNumber);
//                   // print(value.user.photoURL);
//                 });*/
//                         },
//                       )
//                     : SizedBox.shrink()
//                 :                     TextCustomButton(
//               buttonText: 'Sign Up with Apple',
//               id: 1,
//               image: 'assets/images/apple.png',
//               onPressed: () async {
//                 LoginController controller;
//                 if (Get.isRegistered<LoginController>()) {
//                   controller = Get.find<LoginController>();
//                 } else {
//                   controller = Get.put(LoginController());
//                 }
//                 var response;
//                 final appleProvider = AppleAuthProvider();
//
//                 final userCredential = await FirebaseAuth.instance
//                     .signInWithPopup(appleProvider);
//                 final value = userCredential.user;
//                 int id = 2;
//
//                 if (value.email == null ||
//                     value.displayName == null ||
//                     value.uid == null ||
//                     value.email.isEmpty ||
//                     value.displayName.isEmpty ||
//                     value.uid.isEmpty) {
//                   Get.snackbar("Error",
//                       'Somthing went wrong with configuration. please try again');
//                 } else if (value.email.contains("privaterelay")) {
//                   Get.snackbar("Alert",
//                       "Please allow email to continue with werfie");
//                   await FirebaseAuth.instance.signOut();
//
//
//                 } else {
//                   showDialog(
//                     // barrierDismissible: false,
//                       context: context,
//                       builder: (BuildContext context) {
//                         return AlertDialog(
//                           backgroundColor:
//                           Color(0xFFFFFFFF).withOpacity(0.2),
//                           shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.all(
//                                   Radius.circular(10.0))),
//                           insetPadding: EdgeInsets.symmetric(
//                               horizontal: 0, vertical: 0),
//                           contentPadding: EdgeInsets.zero,
//                           content: Container(
//                             height: 100,
//                             width: 80,
//                             child: Column(
//                               mainAxisAlignment:
//                               MainAxisAlignment.spaceAround,
//                               children: [
//                                 SpinKitCircle(
//                                   color: Theme.of(context).primaryColor,
//                                   size: 50.0,
//                                 ),
//                                 Text(
//                                   Strings.pleaseWait,
//                                   style: TextStyle(color: Colors.white),
//                                 )
//                               ],
//                             ),
//                           ),
//                         );
//                       });
//                 }
//
//                 response =
//                 await controller.SocialLogin(queryParameters: {
//                   "email": value.email,
//                   "firstname": value.displayName,
//                   "login_type": 'apple',
//                   "social_id": value.uid,
//                 }, token: {
//                   "Authorization": " Bearer ${Url.webAPIKey}"
//                 });
//                 var jsonResponse = jsonDecode(response.toString());
//                 print("jsonResponse $jsonResponse");
//                 // storage.write("email", value.email.toString());
//                 // shared.setString("email", value.email.toString());
//
//                 var responseCode = jsonResponse['meta']['code'];
//                 var userName = jsonResponse['data']['username'];
//                 var token = jsonResponse['data']['token'];
//                 print("token : $token");
//                 var userId = jsonResponse['data']['id'];
//                 var email = jsonResponse['data']['email'];
//                 shared = await SharedPreferences.getInstance();
//                 if (responseCode == 200) {
//                   storage.write("email", email.toString());
//
//                   shared.setString("token", token.toString());
//                   shared.setString("userName", userName.toString());
//                   storage.write('id', userId);
//                   storage.write("token", token.toString());
//                   shared.setBool('guestUser', true);
//                   shared.setBool('socialLogin', true);
//                   storage.write("userName", userName.toString());
//
//                   storage.write("remember", isCheckedGlobal);
//
//                   controller.generateFCMToken(context);
//                   Get.put(NewsfeedController(
//                     // linkId: controller.postId != null ? controller.postId : null,
//                     // profileId: controller.profileId != null ? controller.profileId : null,
//                   ));
//                   Get.find<NewsfeedController>().languageData =
//                   await Get.find<NewsfeedController>()
//                       .getLanguages();
//                   Get.find<NewsfeedController>()
//                       .selectedAppLanguageInfoId =
//                       Get.find<NewsfeedController>()
//                           .languageData
//                           .appLang
//                           .id;
//
//                   Get.find<NewsfeedController>().upDateLocale(
//                       Get.find<NewsfeedController>()
//                           .languageData
//                           .appLang
//                           .code);
//                   Get.find<NewsfeedController>().update();
//                   {
//                     if (kIsWeb) {
//                       if (id == 2) {
//                         SingleTone.instance.socialLogin = true;
//                         Navigator.pop(context);
//                         // Routemaster.of(context).pop();
//                         String userName = shared.getString("userName");
//
//                         Get.offNamed(FluroRouters.mainScreen);
//
//                       } else {
//                         SingleTone.instance.socialLogin = true;
//                         Navigator.pop(context);
//                         String userName = shared.getString("userName");
//                         print({"userName on mainScreen :  $userName"});
//                         print('postsid:${controller.postId}');
//                         print('profileId:${controller.profileId}');
//                         Get.offNamed(FluroRouters.mainScreen);
//
//
//                       }
//                     } else {
//                       SingleTone.instance.socialLogin = true;
//                       print('route is else here');
//                       Get.back();
//
//                       Get.offAll(MainScreen(), arguments: {
//                         "userName": shared.getString("userName"),
//                         "postId": controller.postId != null
//                             ? controller.postId
//                             : null,
//                         "profileId": controller.profileId != null
//                             ? controller.profileId
//                             : null
//                       });
//                     }
//                   }
//                 }
//
//               },
//             ),
//
//             SizedBox(height: 10),
//
//             /// google Sign in Button
//             Shortcuts(
//               shortcuts: {
//                 LogicalKeySet(LogicalKeyboardKey.tab): GoogleSignupButton(),
//               },
//               child: Actions(
//                 actions: {
//                   GoogleSignupButton:
//                       CallbackAction<GoogleSignupButton>(onInvoke: (_) {
//                     controller.focus5.unfocus();
//                     FocusScope.of(context).requestFocus(controller.focus1);
//                   }),
//                 },
//                 child: Container(
//                   height: 45,
//                   // width: 80,
//                   child: TextCustomButton(
//                     buttonText: 'Login with Google',
//                     id: 1,
//                     image: 'assets/images/google.png',
//                     focusNode: controller.focus5,
//                     onPressed: () async {
//                       var response;
//                       UtilsMethods utillMethod = UtilsMethods();
//                       await utillMethod.signInWithGoogle().then((value) async {
//                         /* if(!kIsWeb)*/ {
//                           showDialog(
//                               // barrierDismissible: false,
//                               context: context,
//                               builder: (BuildContext context) {
//                                 return AlertDialog(
//                                   backgroundColor:
//                                       Color(0xFFFFFFFF).withOpacity(0.2),
//                                   shape: RoundedRectangleBorder(
//                                       borderRadius: BorderRadius.all(
//                                           Radius.circular(10.0))),
//                                   insetPadding: EdgeInsets.symmetric(
//                                       horizontal: 0, vertical: 0),
//                                   contentPadding: EdgeInsets.zero,
//                                   content: Container(
//                                     height: 100,
//                                     width: 80,
//                                     child: Column(
//                                       mainAxisAlignment:
//                                           MainAxisAlignment.spaceAround,
//                                       children: [
//                                         SpinKitCircle(
//                                           color: Theme.of(context).primaryColor,
//                                           size: 50.0,
//                                         ),
//                                         Text(
//                                           Strings.pleaseWait,
//                                           style: TextStyle(color: Colors.white),
//                                         )
//                                       ],
//                                     ),
//                                   ),
//                                 );
//                               });
//                         }
//                         response =
//                             await controller.SocialLogin(queryParameters: {
//                           "email": value.email,
//                           "firstname": value.displayName,
//                           "login_type": 'google',
//                           "social_id": value.uid,
//                         }, token: {
//                           "Authorization": " Bearer ${Url.webAPIKey}"
//                         });
//                         var jsonResponse = jsonDecode(response.toString());
//                         print("jsonResponse $jsonResponse");
//                         // storage.write("email", value.email.toString());
//                         // shared.setString("email", value.email.toString());
//
//                         var responseCode = jsonResponse['meta']['code'];
//                         var userName = jsonResponse['data']['username'];
//                         var token = jsonResponse['data']['token'];
//                         print("token : $token");
//                         var userId = jsonResponse['data']['id'];
//                         var email = jsonResponse['data']['email'];
//                         shared = await SharedPreferences.getInstance();
//                         if (responseCode == 200) {
//                           storage.write("email", email.toString());
//
//                           shared.setString("token", token.toString());
//                           shared.setString("userName", userName.toString());
//                           storage.write('id', userId);
//                           storage.write("token", token.toString());
//                           shared.setBool('guestUser', true);
//                           shared.setBool('socialLogin', true);
//                           storage.write("userName", userName.toString());
//
//                           storage.write("remember", isCheckedGlobal);
//
//                           controller.generateFCMToken(context);
//                           Get.put(NewsfeedController(
//                               // linkId: controller.postId != null ? controller.postId : null,
//                               // profileId: controller.profileId != null ? controller.profileId : null,
//                               ));
//                           Get.find<NewsfeedController>().languageData =
//                               await Get.find<NewsfeedController>()
//                                   .getLanguages();
//                           Get.find<NewsfeedController>()
//                                   .selectedAppLanguageInfoId =
//                               Get.find<NewsfeedController>()
//                                   .languageData
//                                   .appLang
//                                   .id;
//
//                           Get.find<NewsfeedController>().upDateLocale(
//                               Get.find<NewsfeedController>()
//                                   .languageData
//                                   .appLang
//                                   .code);
//                           Get.find<NewsfeedController>().update();
//                           {
//                             if (kIsWeb) {
//                               if (id == 2) {
//                                 SingleTone.instance.socialLogin = true;
//                                 Navigator.pop(context);
//                                 // Routemaster.of(context).pop();
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//                                 // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               } else {
//                                 SingleTone.instance.socialLogin = true;
//                                 Navigator.pop(context);
//                                 String userName = shared.getString("userName");
//                                 print({"userName on mainScreen :  $userName"});
//                                 print('postsid:${controller.postId}');
//                                 print('profileId:${controller.profileId}');
//                                 Get.offNamed(FluroRouters.mainScreen);
//
//                                 // Routemaster.of(context).replace(AppRoute.mainScreen, queryParameters: {
//                                 //
//                                 //
//                                 //   "userName": shared.getString("userName"),
//                                 //   "postId": controller.postId != null
//                                 //       ? controller.postId
//                                 //       : null,
//                                 //   "profileId": controller.profileId != null
//                                 //       ? controller.profileId
//                                 //       : null
//                                 // });
//                               }
//                             } else {
//                               SingleTone.instance.socialLogin = true;
//                               print('route is else here');
//                               Get.back();
//
//                               Get.offAll(MainScreen(), arguments: {
//                                 "userName": shared.getString("userName"),
//                                 "postId": controller.postId != null
//                                     ? controller.postId
//                                     : null,
//                                 "profileId": controller.profileId != null
//                                     ? controller.profileId
//                                     : null
//                               });
//                             }
//                           }
//                         }
//                       });
//                     },
//                   ),
//                 ),
//               ),
//             ),
//
//             SizedBox(height: 10),
//             /* Container(
//               height: 45,
//               child: TextCustomButton(buttonText: 'Sign Up with Apple',id: 1,
//                 image: 'assets/images/apple.png',
//                 onPressed: (){
//
//                 },
//               ),
//             ),*/
//           ],
//         ),
//       ),
//     ],
//   );
// }

class LostPassword extends Intent {}

class GoogleSignupButton extends Intent {}

class LoginButton extends Intent {}

class EnterPasswords extends Intent {}

class EnterName extends Intent {}

class CustomCheck extends StatefulWidget {
  final email;
  final password;
  bool globalCheck;

  CustomCheck({this.email = "", this.password = "", this.globalCheck});

  @override
  _CustomCheckState createState() => _CustomCheckState();
}

class _CustomCheckState extends State<CustomCheck> {
  bool isChecked = false;
  final storage = GetStorage();

  @override
  Widget build(BuildContext context) {
    return Checkbox(
        value: isChecked,
        onChanged: (value) {
          setState(() {
            isChecked = value;
            widget.globalCheck = value;
            if (isChecked) {
              storage.write("email", widget.email.toString());
              storage.write("password", widget.password.toString());
            } else {
              storage.remove("email");
              storage.remove("password");
            }
          });
        });
  }
}
