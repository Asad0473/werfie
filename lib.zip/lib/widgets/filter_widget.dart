import 'package:flutter/material.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/thread_post_card.dart';

import '../utils/colors.dart';

class FilterWidget extends StatelessWidget {
  final NewsfeedController controller;
  final GlobalKey<ScaffoldState> scaffoldKey;

  FilterWidget({this.controller, this.scaffoldKey});

  @override
  Widget build(BuildContext context) {
    return controller?.isFilter == true
        ? Center(
            child: CircularProgressIndicator(
            color: MyColors.BlueColor,
          ))
        : controller?.filteredPost?.length == 0 ||
                // ignore: null_aware_in_logical_operator
                controller?.filteredPost?.isEmpty
            ? Center(child: Text(Strings.noPosts))
            :
            // PagedL(
            //     emptyStateWidget: Text(Strings.noPosts),
            //     itemBuilder: _itemRow,
            //     padding: EdgeInsets.only(
            //         top: 16.00, left: 4.00, right: 4.00),
            //     loadingIndicator: Padding(
            //       padding: EdgeInsets.all(16.00),
            //       child: Center(
            //         child: CircularProgressIndicator(),
            //       ),
            //     ),
            //     itemDataProvider: _fetchData,
            //     list: controller.savedPostList,
            //     listSize:
            //     _checkPage(controller.savedPostList.length)),
            // Text("${ controller.filteredPost.length}")

            SingleChildScrollView(
                child: Column(
                  children:
                      List.generate(controller.filteredPost.length, (index) {
                    return controller.filteredPost[index].type == 'thread'
                        ? ThreadPostCard(
                            index: index,
                            post: controller?.filteredPost[index],
                            scaffoldKey: scaffoldKey,
                            controller: controller,
                          )
                        : PostCard(
                            index: index,
                            post: controller?.filteredPost[index],
                            scaffoldKey: scaffoldKey,
                            controller: controller,
                            // browseController: controller,
                          );
                  }),
                ),
              );
  }
// ignore: missing_return
// int _checkPage(int list) {
//   if (list != 0) {
//     int remain = list % 10;
//     print("Remaing" + remain.toString());
//     if (remain != 0) {
//       return 50000;
//     } else {
//       // ignore: division_optimization
//       int page = (list / 10).toInt();
//       print("Page" + page.toString());
//       if (page == 0 || page == 1) {
//         return 2;
//       } else {
//         return page++;
//       }
//     }
//   }
// }
//
// Widget _itemRow(BuildContext context, Post post) {
//   // ignore: can_be_null_after_null_aware
//   int index = controller?.filteredPost.indexWhere((element) {
//     return element.postId == post.postId;
//   });
//   if (index != -1)
//     return PostCard(
//       post: controller?.savedPostList[index],
//       scaffoldKey: _scaffoldKey,
//       controller: controller.newsFeedControloler,
//       savedController: controller,
//     );
//   return SizedBox();
// }
//
// Future<List<Post>> _fetchData(int page) async {
//   return await controller.filterUsers(pageNo: page,id: controller
//       .searchResult[controller.searchPeopleIndex].id,type:controller
//       .searchResult[controller.searchPeopleIndex].type );
// }
}
