import 'package:get_storage/get_storage.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:werfieapp/models/profile.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/screens/filter_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:validators/validators.dart';

import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/screens/hash_taga_details_screen.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/utils/hashtag_dialog.dart';

import '../models/post.dart';
import '../network/singleTone.dart';
import '../screens/hash_taga_werfs_screen.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import '../web_views/web_view_screen.dart';
import 'comments_screen.dart';

// ignore: non_constant_identifier_names

Widget RichTextView(BuildContext context,
    String text,

    bool readMore,
    NewsfeedController controller,
    id,
    Color commentColor,
    Post post,

    {final shouldGiveFixedHeight = false,
      bool showMomentScreen = false,
      bool editMomentScreen = false,
      String position,
      double width,
    }) {
  final mediaQueryData = MediaQuery.of(context);

  final scale = mediaQueryData.textScaleFactor.clamp(1.0, 1.5);


  return
    Container(

      // color: Colors.deepOrange,
      width: width,
      // MediaQuery.of(context).size.width >= 720 ?
      // kIsWeb ? controller.drawerLeftMoment ? MediaQuery.of(context).size.width >= 1000 ? 250 : 420
      //     : 420
      //     : 260
      //     : kIsWeb ? Get.width/ 1.7
      //     : Get.width,
      // color: MediaQuery.of(context).size.width >= 720 ? kIsWeb ? controller.drawerLeftMoment ? MediaQuery.of(context).size.width >= 1000 ? Colors.green : Colors.yellow: Colors.purple
      //     : Colors.pink: kIsWeb ? Colors.red
      //     : Colors.blue,
      //shouldGiveFixedHeight ? Get.width / 1.5 : double.infinity,
      alignment:

      //controller.languageData.myLang.code == "ar" || controller.languageData.myLang.code == "hi" && controller.languageData.autoTranslateSettings.autoTranslate == 1
      position == "ltr" ? Alignment.centerLeft : position == "rtl" ? Alignment
          .centerRight : Alignment.centerLeft,
      child:

      //
      // ScrollConfiguration(
      //   behavior: NoScrollBehavior(),
      //   child: SelectableText.rich(
      //
      //
      //
      //
      //
      //     TextSpan(
      //       // style: Theme.of(context).textTheme.headline3,
      //       children: medthodToGetString(text, controller , context, id,commentColor).map(
      //             (data) => data.callback == null
      //             ? TextSpan(
      //           text: data.text,
      //           // locale: Locale(controller.languageData.myLang.code),
      //           style: data.style,
      //         )
      //             : TextSpan(
      //           text: data.text,
      //           style: data.style,
      //               recognizer: TapGestureRecognizer()..onTap = () {
      //                 data.callback(context,data.text,post);
      //               },
      //
      //
      //
      //           // locale: Locale(controller.languageData.myLang.code),
      //           // recognizer: TapGestureRecognizer()..onTap =
      //           //       () {
      //           //
      //           //       data.callback(context, data.text.toString());
      //           //       print("hello");
      //           //
      //           //
      //           //       },
      //         ),
      //       ).toList(),
      //     ),
      //
      //
      //     // onTap: kIsWeb
      //     //     ? () async {
      //     //
      //     //
      //     //
      //     //
      //     //   onHomeChange = false;
      //     //   onBrowsChange = false;
      //     //   onTrendsChange = false;
      //     //   onBookMarksChange = false;
      //     //   onChatsChange = false;
      //     //   onProfileChange = false;
      //     //   onSettingChange = false;
      //     //   onListChange = false;
      //     //   onNotificationChange = false;
      //     //   onMoreChange = false;
      //     //   onMomentChange = false;
      //     //
      //     //   print("vvvv");
      //     //
      //     //
      //     //
      //     //
      //     //   controller.selectedPost = post;
      //     //   controller.postId = post.postId;
      //     //   controller.threadNumber = null;
      //     //   SingleTone.instance.post_Id = post.postId;
      //     //   controller.isPostDetails = true;
      //     //   controller.isTrendsScreen = false;
      //     //   controller.isNewsFeedScreen = false;
      //     //   controller.isBrowseScreen = false;
      //     //   controller.isNotificationScreen = false;
      //     //   controller.isProfileScreen = false;
      //     //   controller.isChatScreen = false;
      //     //   controller.isSavedPostScreen = false;
      //     //
      //     //   print('post id:${controller.postId}');
      //     //   print('singtone post id:${SingleTone.instance.post_Id}');
      //     //
      //     //   controller.update();
      //     // }
      //     //     : () async {
      //     //   controller.selectedPost = post;
      //     //   Navigator.push(
      //     //       context,
      //     //       MaterialPageRoute(builder: (BuildContext context) =>
      //     //           CommentsScreen(postId: post.postId, thread_no: null,)));
      //     //   controller.postId = post.postId;
      //     // },
      //     onTap: (){},
      //     showCursor: false,
      //     // textScaleFactor: scale,
      //     textAlign: position =="ltr" ? TextAlign.left: position =="rtl"?TextAlign.right:TextAlign.left,
      //     scrollPhysics: NeverScrollableScrollPhysics(),
      //
      //     // minLines: text.length>=100?7:null,
      //     //  maxLines: text.length>=100?9:null,
      //     // scrollPhysics:NeverScrollableScrollPhysics(
      //     //
      //     // ),
      //     toolbarOptions: ToolbarOptions(
      //        copy: true,
      //
      //     ),
      //     // overflow: readMore ? TextOverflow.visible : TextOverflow.ellipsis,
      //
      //   ),
      // ),


      SelectionArea(

        child: SelectableText.rich(


          TextSpan(
            // style: Theme.of(context).textTheme.headline3,
            children: medthodToGetString(
                text, controller, context, id, commentColor).map(
                  (data) =>
              data.callback == null
                  ? TextSpan(
                text: data.text,
                // locale: Locale(controller.languageData.myLang.code),
                style: data.style,
              )
                  : TextSpan(
                text: data.text,
                style: data.style,
                recognizer: TapGestureRecognizer()
                  ..onTap = () {
                    data.callback(context, data.text, post);
                  },


                // locale: Locale(controller.languageData.myLang.code),
                // recognizer: TapGestureRecognizer()..onTap =
                //       () {
                //
                //       data.callback(context, data.text.toString());
                //       print("hello");
                //
                //
                //       },
              ),
            ).toList(),
          ),
          textScaleFactor: scale,
          textAlign: position == "ltr" ? TextAlign.left : position == "rtl"
              ? TextAlign.right
              : TextAlign.left,
          // overflow: text.length>200?TextOverflow.ellipsis:TextOverflow.visible,
        ),
      ),


    );
}


Widget RichTextViewForDetailScreen(BuildContext context,
    String text,

    bool readMore,
    NewsfeedController controller,
    id,
    Color commentColor,
    Post post,

    {final shouldGiveFixedHeight = false,
      bool showMomentScreen = false,
      bool editMomentScreen = false,
      String position,
      double width,
    }) {
  final mediaQueryData = MediaQuery.of(context);

  final scale = mediaQueryData.textScaleFactor.clamp(1.0, 1.5);


  return Container(
      width: width,
      // MediaQuery.of(context).size.width >= 720 ?
      // kIsWeb ? controller.drawerLeftMoment ? MediaQuery.of(context).size.width >= 1000 ? 250 : 420
      //     : 420
      //     : 260
      //     : kIsWeb ? Get.width/ 1.7
      //     : Get.width,
      // color: MediaQuery.of(context).size.width >= 720 ? kIsWeb ? controller.drawerLeftMoment ? MediaQuery.of(context).size.width >= 1000 ? Colors.green : Colors.yellow: Colors.purple
      //     : Colors.pink: kIsWeb ? Colors.red
      //     : Colors.blue,
      //shouldGiveFixedHeight ? Get.width / 1.5 : double.infinity,
      alignment:

      //controller.languageData.myLang.code == "ar" || controller.languageData.myLang.code == "hi" && controller.languageData.autoTranslateSettings.autoTranslate == 1
      position == "ltr" ? Alignment.centerLeft : position == "rtl" ? Alignment
          .centerRight : Alignment.centerLeft,
      child:

      //
      // ScrollConfiguration(
      //   behavior: NoScrollBehavior(),
      //   child: SelectableText.rich(
      //
      //
      //
      //
      //
      //     TextSpan(
      //       // style: Theme.of(context).textTheme.headline3,
      //       children: medthodToGetString(text, controller , context, id,commentColor).map(
      //             (data) => data.callback == null
      //             ? TextSpan(
      //           text: data.text,
      //           // locale: Locale(controller.languageData.myLang.code),
      //           style: data.style,
      //         )
      //             : TextSpan(
      //           text: data.text,
      //           style: data.style,
      //               recognizer: TapGestureRecognizer()..onTap = () {
      //                 data.callback(context,data.text,post);
      //               },
      //
      //
      //
      //           // locale: Locale(controller.languageData.myLang.code),
      //           // recognizer: TapGestureRecognizer()..onTap =
      //           //       () {
      //           //
      //           //       data.callback(context, data.text.toString());
      //           //       print("hello");
      //           //
      //           //
      //           //       },
      //         ),
      //       ).toList(),
      //     ),
      //
      //
      //     // onTap: kIsWeb
      //     //     ? () async {
      //     //
      //     //
      //     //
      //     //
      //     //   onHomeChange = false;
      //     //   onBrowsChange = false;
      //     //   onTrendsChange = false;
      //     //   onBookMarksChange = false;
      //     //   onChatsChange = false;
      //     //   onProfileChange = false;
      //     //   onSettingChange = false;
      //     //   onListChange = false;
      //     //   onNotificationChange = false;
      //     //   onMoreChange = false;
      //     //   onMomentChange = false;
      //     //
      //     //   print("vvvv");
      //     //
      //     //
      //     //
      //     //
      //     //   controller.selectedPost = post;
      //     //   controller.postId = post.postId;
      //     //   controller.threadNumber = null;
      //     //   SingleTone.instance.post_Id = post.postId;
      //     //   controller.isPostDetails = true;
      //     //   controller.isTrendsScreen = false;
      //     //   controller.isNewsFeedScreen = false;
      //     //   controller.isBrowseScreen = false;
      //     //   controller.isNotificationScreen = false;
      //     //   controller.isProfileScreen = false;
      //     //   controller.isChatScreen = false;
      //     //   controller.isSavedPostScreen = false;
      //     //
      //     //   print('post id:${controller.postId}');
      //     //   print('singtone post id:${SingleTone.instance.post_Id}');
      //     //
      //     //   controller.update();
      //     // }
      //     //     : () async {
      //     //   controller.selectedPost = post;
      //     //   Navigator.push(
      //     //       context,
      //     //       MaterialPageRoute(builder: (BuildContext context) =>
      //     //           CommentsScreen(postId: post.postId, thread_no: null,)));
      //     //   controller.postId = post.postId;
      //     // },
      //     onTap: (){},
      //     showCursor: false,
      //     // textScaleFactor: scale,
      //     textAlign: position =="ltr" ? TextAlign.left: position =="rtl"?TextAlign.right:TextAlign.left,
      //     scrollPhysics: NeverScrollableScrollPhysics(),
      //
      //     // minLines: text.length>=100?7:null,
      //     //  maxLines: text.length>=100?9:null,
      //     // scrollPhysics:NeverScrollableScrollPhysics(
      //     //
      //     // ),
      //     toolbarOptions: ToolbarOptions(
      //        copy: true,
      //
      //     ),
      //     // overflow: readMore ? TextOverflow.visible : TextOverflow.ellipsis,
      //
      //   ),
      // ),

      SelectionArea(

        child: Text.rich(


          TextSpan(
            // style: Theme.of(context).textTheme.headline3,
            children: medthodToGetStrings(
                text, controller, context, id, commentColor).map(
                  (data) =>
              data.callback == null
                  ? TextSpan(
                text: data.text,
                // locale: Locale(controller.languageData.myLang.code),
                style: data.style,
              )
                  : TextSpan(
                text: data.text,
                style: data.style,
                recognizer: TapGestureRecognizer()
                  ..onTap = () {
                    data.callback(context, data.text, post);
                  },


                // locale: Locale(controller.languageData.myLang.code),
                // recognizer: TapGestureRecognizer()..onTap =
                //       () {
                //
                //       data.callback(context, data.text.toString());
                //       print("hello");
                //
                //
                //       },
              ),
            ).toList(),
          ),
          textScaleFactor: scale,
          textAlign: position == "ltr" ? TextAlign.left : position == "rtl"
              ? TextAlign.right
              : TextAlign.left,
          // maxLines:readMore ==false ? 7:null,
          // overflow: readMore ==false ? TextOverflow.ellipsis :TextOverflow.visible,
        ),
      )


  );
}


List<MyText> medthodToGetString(String str, NewsfeedController controller,
    BuildContext context, id, Color commentColor) {
  // String str = 'GitHub is a development google.com inspired #by the way you work. From google.com';
  List<MyText> textSpanList = [];
  List<String> divString = str.split(' ');

  // str.runes.forEach((int rune) {
  //   divString.add(new String.fromCharCode(rune));
  //   print(divString);
  // });


  divString.forEach((element) {
    if (element.trim().startsWith('#') || element.contains("#")) {
      textSpanList.add(
        MyText(
          text: element.startsWith("#") ? element + ' ' : element.contains("#") ? "#"+element.split("#")[1] +' ' : element +' ',
          // style: Theme.of(context).textTheme.bodyText1.copyWith(
          //       color: Colors.blue,
          //       fontFamily: 'OpenSans',
          //       fontSize: 15,
          //       // wordSpacing: 0.5,
          //       height: 1.2,
          //     ),
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          //  TextStyle(
          //   color: Colors.blue,
          //   fontFamily: 'OpenSans',
          //   fontSize: 16,
          // ),
          callback: (context, string, post) async {
            // print(string);

            if (kIsWeb) {
              Get.toNamed(
                  FluroRouters.mainScreen +
                      "/tagWerfs/" +
                      string.toString());
            } else {
              Get.to(HashTagWerfsScreen(
                tag: string.toString(),
                controller: controller,
              ));
              //LoggingUtils.printValue("tag value", tag);
            }

            // temporary comment for #hashtag details

     /*       if(kIsWeb==true) {
              controller.hashTag = string;
              Get.toNamed(FluroRouters.mainScreen +
                  "/tagInfo/" +
                  string.toString());
            }else{
              controller.hashTag = string;
              controller.update();
              Get.to(HashTagDetailsScreen(tag: string,));
            }*/
            // Get.toNamed(FluroRouters.mainScreen + '/tagInfo');
            // showDialog(
            //   context: context,
            //   builder: (BuildContext context) {
            //     return HashtagDialog(string);
            //   },
            // );
            // Gallback: (context, string) async {et.find<NewsfeedController>().isSearch = true

            // // temporary comment for #hashtag navigation
            // if(kIsWeb) {
            //   // Get.toNamed(FluroRouters.mainScreen + "/filters/"+string.toString());
            //   SingleTone.instance.searchId=0.toString();
            //   SingleTone.instance.searchType="tag";
            //   SingleTone.instance.searchTag=string;
            //   SingleTone.instance.searchTab="top";
            //   Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=true");
            //
            //   // Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${0.toString()}&type=${"tag"}&tag=${string}&tab=top");
            //
            //
            //  /* controller.isProfileScreen = false;
            //     controller.isFilterScreen = true;
            //      controller.searchText.text = string.trim();
            //
            //      print("%%%%%%%%$string");
            //     controller.isProfileScreen = false;
            //     controller.isSettingsScreen = false;
            //     controller.isSavedPostScreen = false;
            //     controller.isNewsFeedScreen = false;
            //     controller.isOtherUserProfileScreen = false;
            //     controller.isChatScreen = false;
            //     controller.isChatScreenWeb = false;
            //     controller.isBrowseScreen = false;
            //     controller.isClickWhoToFollow = false;
            //     controller.isFollwerScreen = false;
            //     controller.isPostDetails = false;
            //     controller.postUserId = 0;
            //     controller.isSearch = false;
            //
            //     controller.wait = true;
            //     controller.tagText = string;
            //     controller.update();
            //
            //       await controller.onSearchTextChanged(string,isSearchBar: false);
            //      controller.searchSelected = controller.searchResult[0];
            //     controller.searchSelected.id = 0;
            //     controller.searchSelected.type = "tag";
            //
            //
            //
            //
            //     await controller.filterUsers(
            //       id: 0.toString(),
            //       type: "tag",
            //       tag: string,
            //       // id: id,
            //       // type: controller.searchResult[0].type,
            //     );
            //     controller.isSearch = false;
            //     controller.searchResult = [];
            //
            //
            //     controller.update();*/
            //
            //   }
            // else{
            //   controller.wait = true;
            //   controller.update();
            //   Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (BuildContext context) => FilteredScreen(
            //         newsfeedController: Get.find<NewsfeedController>(),
            //       ),
            //     ),
            //   );
            //
            //   await controller.onSearchTextChanged(string,isSearchBar: false);
            //   controller.searchSelected = controller.searchResult[0];
            //   controller.searchSelected.id = 0;
            //   controller.searchSelected.type = "tag";
            //
            //     controller.searchText.text = string;
            //
            //
            //   await controller.filterUsers(
            //     id: 0.toString(),
            //     type: "tag",
            //     tag: string,
            //     // id: id,
            //     // type: controller.searchResult[0].type,
            //   );
            //   controller.searchResult = [];
            //
            //   controller.update();
            //
            // }
            // // temporary comment

          },
        ),
      );
    }
    else if (element.contains('\$')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          callback: (context, string, post) async {
            // Get.find<NewsfeedController>().isSearch = true;
            try {
              // controller.isProfileScreen = false;
              // controller.isFilterScreen = true;
              // controller.searchText.text = string;
              // controller.isProfileScreen = false;
              // controller.isSettingsScreen = false;
              // controller.isSavedPostScreen = false;
              // controller.isNewsFeedScreen = false;
              // controller.isOtherUserProfileScreen = false;
              // controller.isChatScreen = false;
              // controller.isChatScreenWeb = false;
              // controller.isBrowseScreen = false;
              // controller.isClickWhoToFollow = false;
              // controller.isFollwerScreen = false;
              // controller.isPostDetails = false;
              // controller.wait = true;
              // // controller.postUserId = id;
              // controller.postUserId = 0;
              // controller.tagText = string;
              // // controller.ty
              // kIsWeb
              //     ? controller.update()
              //     : Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (BuildContext context) => FilteredScreen(
              //       newsfeedController: Get.find<NewsfeedController>(),
              //     ),
              //   ),
              // );
              //
              // controller.update();
              // await controller.onSearchTextChanged(string);
              //
              // controller.searchSelected = controller.searchResult[0];
              // controller.searchSelected.id = 0;


              if (kIsWeb) {
                controller.isProfileScreen = false;
                controller.isFilterScreen = true;
                controller.searchText.text = string;
                controller.isProfileScreen = false;
                controller.isSettingsScreen = false;
                controller.isSavedPostScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isOtherUserProfileScreen = false;
                controller.isChatScreen = false;
                controller.isChatScreenWeb = false;
                controller.isBrowseScreen = false;
                controller.isClickWhoToFollow = false;
                controller.isFollwerScreen = false;
                controller.isPostDetails = false;
                controller.postUserId = 0;
                controller.isSearch = false;

                controller.wait = true;
                controller.tagText = string;
                SingleTone.instance.searchId = 0.toString();
                SingleTone.instance.searchType = "cash_tag";
                SingleTone.instance.searchTag = string;
                SingleTone.instance.searchTab = controller.seletedTab;
                Get.toNamed(FluroRouters.mainScreen +
                    "/filters/search?id=${SingleTone.instance
                        .searchId}&type=${SingleTone.instance
                        .searchType}&tag=${SingleTone.instance
                        .searchTag}&tab=${SingleTone.instance
                        .searchTab}&isSearch=true");

                /* controller.update();

                await controller.onSearchTextChanged(string,isSearchBar: false);
                controller.searchSelected = controller.searchResult[0];
                controller.searchSelected.id = 0;
                controller.searchSelected.type = "cash_tag";
                await controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                  // id: id,
                  // type: controller.searchResult[0].type,
                );
                controller.isSearch = false;
                controller.searchResult = [];


                controller.update();
*/
              }
              else {
                controller.wait = true;
                controller.update();

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) =>
                        FilteredScreen(
                          newsfeedController: Get.find<NewsfeedController>(),
                        ),
                  ),
                );

                await controller.onSearchTextChanged(
                    string, isSearchBar: false);
                controller.searchSelected = controller.searchResult[0];
                controller.searchSelected.id = 0;
                controller.searchSelected.type = "cash_tag";
                await controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                  // id: id,
                  // type: controller.searchResult[0].type,
                );
                controller.searchResult = [];

                controller.update();
              }
            } catch (_) {}
          },
        ),
      );
    }
    else if (element.contains('@')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),

          callback: (context, string, post) async {
            // Get.find<NewsfeedController>().isSearch = true;
            try {
              // print('String' + string);

              if ('@${GetStorage().read('userName')}'.trim() != string.trim()) {
                controller.otherUserName = string;
              }
              controller.isProfileScreen = false;
              controller.isFilterScreen = true;
              controller.searchText.text = string;
              controller.isProfileScreen = false;
              controller.isSettingsScreen = false;
              controller.isSavedPostScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isOtherUserProfileScreen = false;
              controller.isChatScreen = false;
              controller.isChatScreenWeb = false;
              controller.isBrowseScreen = false;
              controller.isClickWhoToFollow = false;
              controller.isFollwerScreen = false;
              controller.isPostDetails = false;
              controller.wait = true;
              // controller.postUserId = id;
              controller.postUserId = 0;
              controller.tagText = string;
              // controller.ty
              if (kIsWeb) {
                // controller.update();
                SingleTone.instance.searchId = 0.toString();
                SingleTone.instance.searchType = "user";
                SingleTone.instance.searchTag = string;
                SingleTone.instance.searchTab = controller.seletedTab;
                Get.toNamed(FluroRouters.mainScreen +
                    "/filters/search?id=${SingleTone.instance
                        .searchId}&type=${SingleTone.instance
                        .searchType}&tag=${SingleTone.instance
                        .searchTag}&tab=${SingleTone.instance
                        .searchTab}&isSearch=true");
              } else {
                Get.to(string.trim() !=
                    '@${GetStorage().read('userName')}'.trim()
                    ? OtherUsersProfile(
                  controller: Get.find<NewsfeedController>(),
                )
                    : ProfileScreen(
                  controller: Get.find<NewsfeedController>(),
                ));
              }

              // controller.update();
              // await controller.onSearchTextChanged(string);

              // controller.searchSelected = controller.searchResult[0];
              // controller.searchSelected.id = 0;
              // controller.searchSelected.type = "user";
              // await controller.filterUsers(
              //   id: 0.toString(),
              //   type: "user",
              //   tag: string,
              //   // id: id,
              //   // type: controller.searchResult[0].type,
              // );

              // Future.delayed(Duration(seconds: 0), () {
              //   kIsWeb
              //       ? controller.update()
              //       : Get.to(FilteredScreen(
              //           newsfeedController: Get.find<NewsfeedController>(),
              //         ));
              // });
            } catch (_) {
              // print('IN CATCH');
            }
          },
        ),
      );
    } else if (element.contains('.com') || element.contains('https') ||
        element.contains('http')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          callback: (context, string, post) async {
            // print("stringsdsada $string");



            if (!kIsWeb) {
              if(element.trim().toLowerCase().contains("https://werfie.com/home/")){
                await launchUrl(
                  Uri.parse(element),
                );
              }else {
                if (!element.trim().toLowerCase().startsWith('http') && !element.trim().toLowerCase().startsWith('https')) {
                  String url = "https://";
                  string = url + string;
                }
                else
                if (!element.trim().toLowerCase().contains('https') && !element.trim().toLowerCase().contains('www.') ||
                    !element.trim().toLowerCase().contains('http') && !element.trim().toLowerCase().contains('www.')) {
                  String url = "https://www.";
                  string = url + string;
                }


                print("url+string RICH TEXT${string}");

                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => WebViewScreen(webUrl: string.trim())),
                );
              }
            }
            else {
              if (await canLaunchUrl(Uri.parse(string.trim().toLowerCase()))) {

                  await launchUrl(Uri.parse(string.trim().toLowerCase(),),);

                // await launchUrl(Uri.parse(string.trim(),),
                // );
              } else {


                await launchUrl(
                  Uri.parse(string.trim().toLowerCase() == "werfie.com" ? 'https://${string.trim()}' : 'https://www.${string.trim()}',),
                );
              }
            }
          },
        ),
      );
    }

    else {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w400,
            color: commentColor,
              fontFamily: "OpenSans"
          ),

          callback: (context, string, post) {
            if (kIsWeb) {
              debugPrint("Rich text clicked");
              /*
              onHomeChange = false;
              onBrowsChange = false;
              onTrendsChange = false;
              onBookMarksChange = false;
              onChatsChange = false;
              onProfileChange = false;
              onSettingChange = false;
              onListChange = false;
              onNotificationChange = false;
              onMoreChange = false;
              onMomentChange = false;

              controller.selectedPost = post;
              controller.postId = post.postId;
              controller.threadNumber = null;
              SingleTone.instance.post_Id = post.postId;
              controller.isPostDetails = true;
              controller.isTrendsScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isBrowseScreen = false;
              controller.isNotificationScreen = false;
              controller.isProfileScreen = false;
              controller.isChatScreen = false;
              controller.isSavedPostScreen = false;

              // print('post id:${controller.postId}');
              // print('singtone post id:${SingleTone.instance.post_Id}');

              controller.update(); */
            }
            else {
              // controller.selectedPost = post;
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(builder: (BuildContext context) =>
              //         CommentsScreen(postId: post.postId, thread_no: null,)));
              // controller.postId = post.postId;
            }
          },
        ),
      );
    }
  });
  return textSpanList;
}

class MyText {
  final String text;
  final TextStyle style;
  final void Function(BuildContext, String, Post) callback;

  MyText({
    this.text,
    this.style,
    this.callback,
  });
}


List<MyText> medthodToGetStrings(String str, NewsfeedController controller,
    BuildContext context, id, Color commentColor) {
  // String str = 'GitHub is a development google.com inspired #by the way you work. From google.com';
  List<MyText> textSpanList = [];
  List<String> divString = str.split(' ');

  // str.runes.forEach((int rune) {
  //   divString.add(new String.fromCharCode(rune));
  //   print(divString);
  // });


  divString.forEach((element) {
    if (element.startsWith('#')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          // style: Theme.of(context).textTheme.bodyText1.copyWith(
          //       color: Colors.blue,
          //       fontFamily: 'OpenSans',
          //       fontSize: 15,
          //       // wordSpacing: 0.5,
          //       height: 1.2,
          //     ),
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          //  TextStyle(
          //   color: Colors.blue,
          //   fontFamily: 'OpenSans',
          //   fontSize: 16,
          // ),
          callback: (context, string, post) async {
            if (kIsWeb) {
              Get.toNamed(
                  FluroRouters.mainScreen +
                      "/tagWerfs/" +
                      string.toString());
            } else {
              Get.to(HashTagWerfsScreen(
                tag: string.toString(),
                controller: controller,
              ));
              //LoggingUtils.printValue("tag value", tag);
            }
            // temporary comment for #hashtag details

            /*   if(kIsWeb==true) {
              controller.hashTag = string;
              Get.toNamed(FluroRouters.mainScreen +
                  "/tagInfo/" +
                  string.toString());
            }else{
              controller.hashTag = string;
              controller.update();
              Get.to(HashTagDetailsScreen(tag: string,));
            }*/
            // Gallback: (context, string) async {et.find<NewsfeedController>().isSearch = true

            // // temporary comment for #hashtag navigation
            // if(kIsWeb) {
            //   // Get.toNamed(FluroRouters.mainScreen + "/filters/"+string.toString());
            //   SingleTone.instance.searchId=0.toString();
            //   SingleTone.instance.searchType="tag";
            //   SingleTone.instance.searchTag=string;
            //   SingleTone.instance.searchTab="top";
            //   Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${SingleTone.instance.searchId}&type=${SingleTone.instance.searchType}&tag=${SingleTone.instance.searchTag}&tab=${SingleTone.instance.searchTab}&isSearch=true");
            //
            //   // Get.toNamed(FluroRouters.mainScreen + "/filters/search?id=${0.toString()}&type=${"tag"}&tag=${string}&tab=top");
            //
            //
            //  /* controller.isProfileScreen = false;
            //     controller.isFilterScreen = true;
            //      controller.searchText.text = string.trim();
            //
            //      print("%%%%%%%%$string");
            //     controller.isProfileScreen = false;
            //     controller.isSettingsScreen = false;
            //     controller.isSavedPostScreen = false;
            //     controller.isNewsFeedScreen = false;
            //     controller.isOtherUserProfileScreen = false;
            //     controller.isChatScreen = false;
            //     controller.isChatScreenWeb = false;
            //     controller.isBrowseScreen = false;
            //     controller.isClickWhoToFollow = false;
            //     controller.isFollwerScreen = false;
            //     controller.isPostDetails = false;
            //     controller.postUserId = 0;
            //     controller.isSearch = false;
            //
            //     controller.wait = true;
            //     controller.tagText = string;
            //     controller.update();
            //
            //       await controller.onSearchTextChanged(string,isSearchBar: false);
            //      controller.searchSelected = controller.searchResult[0];
            //     controller.searchSelected.id = 0;
            //     controller.searchSelected.type = "tag";
            //
            //
            //
            //
            //     await controller.filterUsers(
            //       id: 0.toString(),
            //       type: "tag",
            //       tag: string,
            //       // id: id,
            //       // type: controller.searchResult[0].type,
            //     );
            //     controller.isSearch = false;
            //     controller.searchResult = [];
            //
            //
            //     controller.update();*/
            //
            //   }
            // else{
            //   controller.wait = true;
            //   controller.update();
            //   Navigator.push(
            //     context,
            //     MaterialPageRoute(
            //       builder: (BuildContext context) => FilteredScreen(
            //         newsfeedController: Get.find<NewsfeedController>(),
            //       ),
            //     ),
            //   );
            //
            //   await controller.onSearchTextChanged(string,isSearchBar: false);
            //   controller.searchSelected = controller.searchResult[0];
            //   controller.searchSelected.id = 0;
            //   controller.searchSelected.type = "tag";
            //
            //     controller.searchText.text = string;
            //
            //
            //   await controller.filterUsers(
            //     id: 0.toString(),
            //     type: "tag",
            //     tag: string,
            //     // id: id,
            //     // type: controller.searchResult[0].type,
            //   );
            //   controller.searchResult = [];
            //
            //   controller.update();
            //
            // }
            // // temporary comment

          },
        ),
      );
    }
    else if (element.contains('\$')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          callback: (context, string, post) async {
            // Get.find<NewsfeedController>().isSearch = true;
            try {
              // controller.isProfileScreen = false;
              // controller.isFilterScreen = true;
              // controller.searchText.text = string;
              // controller.isProfileScreen = false;
              // controller.isSettingsScreen = false;
              // controller.isSavedPostScreen = false;
              // controller.isNewsFeedScreen = false;
              // controller.isOtherUserProfileScreen = false;
              // controller.isChatScreen = false;
              // controller.isChatScreenWeb = false;
              // controller.isBrowseScreen = false;
              // controller.isClickWhoToFollow = false;
              // controller.isFollwerScreen = false;
              // controller.isPostDetails = false;
              // controller.wait = true;
              // // controller.postUserId = id;
              // controller.postUserId = 0;
              // controller.tagText = string;
              // // controller.ty
              // kIsWeb
              //     ? controller.update()
              //     : Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (BuildContext context) => FilteredScreen(
              //       newsfeedController: Get.find<NewsfeedController>(),
              //     ),
              //   ),
              // );
              //
              // controller.update();
              // await controller.onSearchTextChanged(string);
              //
              // controller.searchSelected = controller.searchResult[0];
              // controller.searchSelected.id = 0;


              if (kIsWeb) {
                controller.isProfileScreen = false;
                controller.isFilterScreen = true;
                controller.searchText.text = string;
                controller.isProfileScreen = false;
                controller.isSettingsScreen = false;
                controller.isSavedPostScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isOtherUserProfileScreen = false;
                controller.isChatScreen = false;
                controller.isChatScreenWeb = false;
                controller.isBrowseScreen = false;
                controller.isClickWhoToFollow = false;
                controller.isFollwerScreen = false;
                controller.isPostDetails = false;
                controller.postUserId = 0;
                controller.isSearch = false;

                controller.wait = true;
                controller.tagText = string;
                SingleTone.instance.searchId = 0.toString();
                SingleTone.instance.searchType = "cash_tag";
                SingleTone.instance.searchTag = string;
                SingleTone.instance.searchTab = controller.seletedTab;
                Get.toNamed(FluroRouters.mainScreen +
                    "/filters/search?id=${SingleTone.instance
                        .searchId}&type=${SingleTone.instance
                        .searchType}&tag=${SingleTone.instance
                        .searchTag}&tab=${SingleTone.instance
                        .searchTab}&isSearch=true");

                /* controller.update();

                await controller.onSearchTextChanged(string,isSearchBar: false);
                controller.searchSelected = controller.searchResult[0];
                controller.searchSelected.id = 0;
                controller.searchSelected.type = "cash_tag";
                await controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                  // id: id,
                  // type: controller.searchResult[0].type,
                );
                controller.isSearch = false;
                controller.searchResult = [];


                controller.update();
*/
              }
              else {
                controller.wait = true;
                controller.update();

                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (BuildContext context) =>
                        FilteredScreen(
                          newsfeedController: Get.find<NewsfeedController>(),
                        ),
                  ),
                );

                await controller.onSearchTextChanged(
                    string, isSearchBar: false);
                controller.searchSelected = controller.searchResult[0];
                controller.searchSelected.id = 0;
                controller.searchSelected.type = "cash_tag";
                await controller.filterUsers(
                  id: 0.toString(),
                  type: "cash_tag",
                  tag: string,
                  // id: id,
                  // type: controller.searchResult[0].type,
                );
                controller.searchResult = [];

                controller.update();
              }
            } catch (_) {}
          },
        ),
      );
    }
    else if (element.contains('@')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),

          callback: (context, string, post) async {
            // Get.find<NewsfeedController>().isSearch = true;
            try {
              // print('String' + string);

              if ('@${GetStorage().read('userName')}'.trim() != string.trim()) {
                controller.otherUserName = string;
              }
              controller.isProfileScreen = false;
              controller.isFilterScreen = true;
              controller.searchText.text = string;
              controller.isProfileScreen = false;
              controller.isSettingsScreen = false;
              controller.isSavedPostScreen = false;
              controller.isNewsFeedScreen = false;
              controller.isOtherUserProfileScreen = false;
              controller.isChatScreen = false;
              controller.isChatScreenWeb = false;
              controller.isBrowseScreen = false;
              controller.isClickWhoToFollow = false;
              controller.isFollwerScreen = false;
              controller.isPostDetails = false;
              controller.wait = true;
              // controller.postUserId = id;
              controller.postUserId = 0;
              controller.tagText = string;
              // controller.ty
              if (kIsWeb) {
                // controller.update();
                SingleTone.instance.searchId = 0.toString();
                SingleTone.instance.searchType = "user";
                SingleTone.instance.searchTag = string;
                SingleTone.instance.searchTab = controller.seletedTab;
                Get.toNamed(FluroRouters.mainScreen +
                    "/filters/search?id=${SingleTone.instance
                        .searchId}&type=${SingleTone.instance
                        .searchType}&tag=${SingleTone.instance
                        .searchTag}&tab=${SingleTone.instance
                        .searchTab}&isSearch=true");
              } else {
                Get.to(string.trim() !=
                    '@${GetStorage().read('userName')}'.trim()
                    ? OtherUsersProfile(
                  controller: Get.find<NewsfeedController>(),
                )
                    : ProfileScreen(
                  controller: Get.find<NewsfeedController>(),
                ));
              }

              // controller.update();
              // await controller.onSearchTextChanged(string);

              // controller.searchSelected = controller.searchResult[0];
              // controller.searchSelected.id = 0;
              // controller.searchSelected.type = "user";
              // await controller.filterUsers(
              //   id: 0.toString(),
              //   type: "user",
              //   tag: string,
              //   // id: id,
              //   // type: controller.searchResult[0].type,
              // );

              // Future.delayed(Duration(seconds: 0), () {
              //   kIsWeb
              //       ? controller.update()
              //       : Get.to(FilteredScreen(
              //           newsfeedController: Get.find<NewsfeedController>(),
              //         ));
              // });
            } catch (_) {
              // print('IN CATCH');
            }
          },
        ),
      );
    } else if (element.contains('.com') || element.contains('https') ||
        element.contains('http')) {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 15,
            height: 1.3,
            fontWeight: FontWeight.w500,
            color: controller.displayColor,
          ),
          callback: (context, string, post) async {
            // print("stringsdsada $string");


            if (!kIsWeb) {
              if (!element.startsWith('https') || !element.startsWith('http')) {
                String url = "https://";
                string = url + string;
              }
              else
              if (!element.contains('https') && !element.contains('www.') ||
                  !element.contains('http') && !element.contains('www.')) {
                String url = "https://www.";
                string = url + string;
              }





              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => WebViewScreen(webUrl: string)),
              );
            }
            else {
              if (await canLaunchUrl(Uri.parse(string.trim().toLowerCase()))) {
                print("url+string RICH TEXT TWO${string}");
                  await launchUrl(Uri.parse(string.trim(),));

                // await launchUrl(Uri.parse(string.trim(),),
                // );
              } else {
                await launchUrl(
                  Uri.parse(string.trim().toLowerCase() == "werfie.com" ? 'https://${string.trim()}' : 'https://www.${string.trim()}',),
                );
              }
            }
          },
        ),
      );
    }

    else {
      textSpanList.add(
        MyText(
          text: element + ' ',
          style: Styles.baseTextTheme.headline2.copyWith(
            fontSize: 16,
            height: 1.3,
            fontWeight: FontWeight.w400,
            color: commentColor,
              fontFamily: "OpenSans"
          ),

          callback: (context, string, post) {
            // if(kIsWeb)
            // {
            //
            //   onHomeChange = false;
            //   onBrowsChange = false;
            //   onTrendsChange = false;
            //   onBookMarksChange = false;
            //   onChatsChange = false;
            //   onProfileChange = false;
            //   onSettingChange = false;
            //   onListChange = false;
            //   onNotificationChange = false;
            //   onMoreChange = false;
            //   onMomentChange = false;
            //
            //   controller.selectedPost = post;
            //   controller.postId = post.postId;
            //   controller.threadNumber = null;
            //   SingleTone.instance.post_Id = post.postId;
            //   controller.isPostDetails = true;
            //   controller.isTrendsScreen = false;
            //   controller.isNewsFeedScreen = false;
            //   controller.isBrowseScreen = false;
            //   controller.isNotificationScreen = false;
            //   controller.isProfileScreen = false;
            //   controller.isChatScreen = false;
            //   controller.isSavedPostScreen = false;
            //
            //   print('post id:${controller.postId}');
            //   print('singtone post id:${SingleTone.instance.post_Id}');
            //
            //   controller.update();
            //
            //
            // }
            // else{
            //
            //
            //   controller.selectedPost = post;
            //   Navigator.push(
            //       context,
            //       MaterialPageRoute(builder: (BuildContext context) =>
            //           CommentsScreen(postId: post.postId, thread_no: null,)));
            //   controller.postId = post.postId;
            //
            // }

          },
        ),
      );
    }
  });
  return textSpanList;
}


class NoScrollBehavior extends ScrollBehavior {
  @override
  Widget buildViewportChrome(BuildContext context, Widget child,
      AxisDirection axisDirection) {
    return child;
  }

  @override
  ScrollPhysics getScrollPhysics(BuildContext context) {
    return const NeverScrollableScrollPhysics();
  }
}