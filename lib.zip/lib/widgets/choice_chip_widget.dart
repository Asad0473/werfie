import 'package:flutter/material.dart';

import '../utils/font.dart';

class ChoiceChipWidget extends StatelessWidget {
  ChoiceChipWidget({Key key, this.imageUrl, this.name, this.onDelete})
      : super(key: key);
  final Function() onDelete;
  final String imageUrl;
  final String name;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 35,
      padding: EdgeInsets.all(3),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.grey[200])),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(25),
            child: Image.network(
              imageUrl ?? 'https://via.placeholder.com/150',
              // height: MediaQuery.of(context).size.height / 3.8,
              height: 25,
              width: 25,
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(
            width: 5,
          ),
          Text(
            name,
            style: LightStyles.baseTextTheme.headline4.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
              fontWeight: FontWeight.w600,
              fontSize: 12,
            ),
            //TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
          ),
          SizedBox(
            width: 5,
          ),
          InkWell(
            child: Icon(
              Icons.close,
              size: 20,
              color: Colors.blue[200],
            ),
            onTap: () {
              onDelete();
            },
          )
        ],
      ),
    );
  }
}
