import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import '../utils/font.dart';
import '../utils/strings.dart';

/// widget to lazy load paged content
// class PagedListView<T> extends StatefulWidget {
//   final Widget emptyStateWidget;
//
//   final Widget Function(BuildContext, T) _itemBuilder;
//   final Widget _loadingIndicator;
//   final Future<List<T>> Function(int) _itemDataProvider;
//   final EdgeInsets _padding;
//   PagedListView({
//     @required Widget Function(BuildContext context, T value) itemBuilder,
//     @required Widget loadingIndicator,
//     @required Future<List<T>> Function(int page) itemDataProvider,
//     this.emptyStateWidget = const SizedBox(),
//     EdgeInsets padding = EdgeInsets.zero,
//     Key key,
//   })  : assert(itemBuilder != null &&
//       loadingIndicator != null &&
//       itemDataProvider != null),
//         _itemBuilder = itemBuilder,
//         _loadingIndicator = loadingIndicator,
//         _itemDataProvider = itemDataProvider,
//         _padding = padding,
//         super(key: key);
//
//   @override
//   _PagedListViewState<T> createState() => _PagedListViewState<T>();
// }
//
// class _PagedListViewState<T> extends State<PagedListView<T>> {
//
//   final List<T> _loadedData = List<T>();
//   int _pgCount = 1;
//   bool _end = false;
//   bool _loading = true;
//   bool _noData = false;
//
//   @override
//   Widget build(BuildContext context) {
//     // one extra item when loading to include indicator widget
//     final itemCount = _loading ? _loadedData.length + 1 : _loadedData.length;
//     final maxIndex = itemCount - 1;
//     return _noData
//         ? Center(
//       child: widget.emptyStateWidget,
//     )
//         : ListView.builder(
//       shrinkWrap: true,
//       padding: widget._padding,
//       itemCount: itemCount,
//       itemBuilder: (context, index) {
//         final isLastItem = index == maxIndex;
//         if (isLastItem) {
//           _loadMoreData();
//           if (_loading) {
//             return widget._loadingIndicator;
//           }
//         }
//         return widget._itemBuilder(context, _loadedData[index]);
//       },
//     );
//   }
//
//   void _loadMoreData() {
//     // if (!widget.controller.isCommentClick) {
//       if (!_end) {
//         if (!_loading) {
//           // making sure setState is called after build method is done
//           WidgetsBinding.instance.addPostFrameCallback((_) {
//             setState(() => _loading = true);
//           });
//         }
//         widget._itemDataProvider(_pgCount++).then((moreItems) {
//           // check if data is empty on very first page
//           // _pgCount is 2 as it was just incremented in above statement
//           if (moreItems.isEmpty && _pgCount == 2) {
//             WidgetsBinding.instance.addPostFrameCallback((_) {
//               setState(() => _noData = true);
//             });
//           } else {
//             // making sure setState is called after build method is done
//             WidgetsBinding.instance.addPostFrameCallback((_) {
//               setState(() {
//                 _loading = false;
//                 if (moreItems.isEmpty) {
//                   _end = true;
//                 } else {
//                   moreItems.forEach((element) {
//                     if(element != null)
//                     _loadedData.add(element);
//                     else{
//                       setState(() {
//                         _loading = false;
//                         _end = false;
//                       });
//                     }
//                   });
//                 }
//               });
//             });
//           }
//         }).catchError((e) {
//           setState(() => _loading = false);
//         });
//       }
//     }
//   // }
// }

// ignore: must_be_immutable
class PagedList<T> extends StatefulWidget {
  final Widget emptyStateWidget;

  final Widget Function(BuildContext, T) _itemBuilder;
  final Widget _loadingIndicator;
  final Future<List<T>> Function(int) _itemDataProvider;
  final EdgeInsets _padding;

  final List<T> list;

  PagedList({
    @required Widget Function(BuildContext context, T value) itemBuilder,
    @required Widget loadingIndicator,
    @required Future<List<T>> Function(int page) itemDataProvider,
    List<T> list,
    this.emptyStateWidget = const SizedBox(),
    EdgeInsets padding = EdgeInsets.zero,
    Key key,
  })  : assert(itemBuilder != null &&
            loadingIndicator != null &&
            itemDataProvider != null),
        _itemBuilder = itemBuilder,
        _loadingIndicator = loadingIndicator,
        _itemDataProvider = itemDataProvider,
        list = list,
        _padding = padding,
        super(key: key);

  @override
  _PagedListState<T> createState() => _PagedListState<T>();
}

class _PagedListState<T> extends State<PagedList<T>> {
  final List<T> _loadedData = [];
  int _pgCount = 2;
  bool _end = false;
  bool _loading = false;
  bool _noData = false;

  @override
  Widget build(BuildContext context) {
    if (_loadedData.isEmpty) _loadedData.addAll(widget.list);
    // one extra item when loading to include indicator widget
    final itemCount = _loading ? _loadedData.length + 1 : _loadedData.length;
    final maxIndex = itemCount - 1;
    return _noData
        ? Center(
            child: widget.emptyStateWidget,
          )
        : ListView.builder(
            // physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            padding: widget._padding,
            itemCount: itemCount,
            itemBuilder: (context, index) {
              final isLastItem = index == maxIndex;
              if (isLastItem && maxIndex >= 9) {
                _loadMoreData();
                if (_loading) {
                  return widget._loadingIndicator;
                }
              }
              return widget._itemBuilder(context, _loadedData[index]);
            },
          );
  }

  void _loadMoreData() {
    // if (!widget.controller.isCommentClick) {
    if (!_end) {
      if (!_loading) {
        // making sure setState is called after build method is done
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (this.mounted) {
            // check whether the state object is in tree
            setState(() => _loading = true);
          }
        });
      }
      widget._itemDataProvider(_pgCount++).then((moreItems) {
        // check if data is empty on very first page
        // _pgCount is 3 as it was just incremented in above statement
        if (moreItems.isEmpty && _pgCount == 3) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (this.mounted) {
              // check whether the state object is in tree
              setState(() => _noData = true);
            }
          });
        } else {
          // making sure setState is called after build method is done
          WidgetsBinding.instance.addPostFrameCallback((_) {
            // setState(() {
            _loading = false;
            if (moreItems.isEmpty) {
              _end = true;
            } else if (moreItems != null) {
              moreItems.forEach((element) {
                if (element != null) {
                  _loadedData.add(element);
                } else {
                  if (this.mounted) {
                    setState(() {
                      _loading = false;
                      _end = true;
                    }); // check whether the state object is in tree
                  }
                }
              });
            } else {
              if (this.mounted) {
                setState(() {
                  _loading = false;
                  _end = true;
                  if (_loadedData.isEmpty)
                    _noData = true;
                  else
                    _noData = false;
                });
              }
            }
            // });
          });
        }
      }).catchError((e) {
        setState(() => _loading = false);
      });
    }
  }
// }
}

// ignore: must_be_immutable
class PagedL extends StatefulWidget {
  final Widget emptyStateWidget;
  final Widget Function(BuildContext, Post) _itemBuilder;
  final Widget _loadingIndicator;
  final Future<List<Post>> Function(int) _itemDataProvider;
  final EdgeInsets _padding;
  List<Post> list;
  int listSize;
  bool newsFeedCheck;
  bool isForYou;

  PagedL({
    @required Widget Function(BuildContext context, Post value) itemBuilder,
    @required Widget loadingIndicator,
    @required Future<List<Post>> Function(int page) itemDataProvider,
    List<Post> list,
    int listSize,
    this.emptyStateWidget = const SizedBox(),
    EdgeInsets padding = EdgeInsets.zero,
    Key key,
    this.newsFeedCheck,
    this.isForYou = false
  })  : assert(itemBuilder != null &&
            loadingIndicator != null &&
            itemDataProvider != null),
        _itemBuilder = itemBuilder,
        _loadingIndicator = loadingIndicator,
        _itemDataProvider = itemDataProvider,
        list = list,
        listSize = listSize,
        _padding = padding,
        super(key: key);

  @override
  _PagedLState createState() => _PagedLState();
}

class _PagedLState extends State<PagedL> {
  final List<Post> _loadedData = [];
  int _pgCount = 2;
  ScrollController _scroll;

  bool _end = false;
  bool _loading = false;
  bool _noData = false;

  // ignore: unused_field
  bool _finalEnd = false;

  final controller = Get.find<NewsfeedController>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // print('OM INIT INIT');
    _scroll = ScrollController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scroll.addListener(() {
// nextPageTrigger will have a value equivalent to 80% of the list size.
        var nextPageTrigger ;
      if(widget.isForYou) {
        nextPageTrigger = 0.6 * _scroll.position.maxScrollExtent;
      }else{
        nextPageTrigger = 0.2 * _scroll.position.maxScrollExtent;
      }
        // print("listener start");

// _scrollController fetches the next paginated data when the current postion of the user on the screen has surpassed
        if (_scroll.position.pixels > nextPageTrigger) {
          // _loading = true;
          _loadMoreData();
        }
      });
    });
  }

  final FocusNode _focusNode = FocusNode();

  void _handleKeyEvent(RawKeyEvent event) {
    var offset = _scroll.offset;

    //Getting current position
    if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      setState(() {
        if (kReleaseMode) {
          //This block only runs when the application was compiled in release mode.
          _scroll.animateTo(offset - 100,
              duration: Duration(milliseconds: 200), curve: Curves.ease);
        } else {
          // This will only print useful information in debug mode.
          // print(_controller.position); to get information..
          _scroll.animateTo(offset - 100,
              duration: Duration(milliseconds: 200), curve: Curves.ease);
        }
      });
    } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      setState(() {
        if (kReleaseMode) {
          _scroll.animateTo(offset + 100,
              duration: Duration(milliseconds: 200), curve: Curves.ease);
        } else {
          _scroll.animateTo(offset + 100,
              duration: Duration(milliseconds: 200), curve: Curves.ease);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
//     print(widget.newsFeedCheck);
//     _scroll = ScrollController();
//
//     _scroll.addListener(() {
//       if(controller.isNewsfeedAdded){
//         print("new feed");
//         setState(() {
//           if(_scroll.hasClients) {
//             // _scroll.jumpTo(0.0);
//             _scroll.animateTo(_scroll.position.minScrollExtent);
//
//
//
//             controller.isNewsfeedAdded = false;
//           }
//         });
//
//       }
// /*// nextPageTrigger will have a value equivalent to 80% of the list size.
//       var nextPageTrigger = 0.8 * _scroll.position.maxScrollExtent;
//
// // _scrollController fetches the next paginated data when the current postion of the user on the screen has surpassed
//       if (_scroll.position.pixels > nextPageTrigger) {
//         _loadMoreData();
//       }*/
//
//
//
//     });



    if (_loadedData.isEmpty) {
      // print("<========= LOADED DATA ===========>");
      // print(_loadedData);
      if (widget.list.isEmpty) {
        _noData = true;
        setState(() {});
      } else {
        _loadedData.addAll(widget.list);

        setState(() {});
      }
    }

    if (_loadedData[0].postId != widget.list[0].postId) {
      // print("inside ifelse");
      _loadedData.clear();
      _loadedData.addAll(widget.list);
      setState(() {});
      // print(_loadedData[0].body);
    }
    // print("buulldllddlldldldlldldl");
    // print(_loadedData[0].postId.toString());
    // print(widget.list[0].postId.toString());
    // print(_loadedData[0].body.toString());
    // print(widget.list[0].body.toString());
    // print("buulldllddlldldldlldldl");
    // one extra item when loading to include indicator widget
    final itemCount = _loadedData.length;
    final maxIndex = itemCount - 1;

    // print("paged LLLLLLLLLLL" + widget.list[0].body);
    return
        // Column(
        // children: [
        // _finalEnd ? Text('No More') : SizedBox(),
        _noData
            ? Center(
                child: widget.emptyStateWidget,
              )
            :
            // Expanded(
            //             child:
            Stack(
                alignment: Alignment.topCenter,
                children: [
                  ListView.builder(
                    controller: _scroll,
                    // physics: ScrollPhysics(),
                    primary: false,
                    physics: const AlwaysScrollableScrollPhysics(),

                    // separatorBuilder: (_, __) {
                    //   return Container(
                    //     height: 2,
                    //     color: Colors.grey[200],
                    //   );
                    // },
                    // key: PageStorageKey<String>("page"),
                    shrinkWrap: true,
                    // cacheExtent: 1000,
                    padding: widget._padding,
                    itemCount: itemCount + (_end ? 0 : 1),
                    itemBuilder: (context, index) {
                      if (index == itemCount) {
                        // _loading=true;

                        if (_loading) {
                          return widget._loadingIndicator;
                        } else {
                          return Container();
                        }
                      }

                      /*    final isLastItem = index == maxIndex;
                      if (isLastItem && maxIndex >= 9) {
                        _loadMoreData();
                        if (_loading) {
                          return widget._loadingIndicator;
                        }
                      }*/
                      // print("_loadedData[0].body");
                      // print(_loadedData[0].body);
                      // print("_loadedData[0].body");

                      else {
                        return
                            // PageStorage(
                            //   bucket: bucket,
                            //   child:
                            widget._itemBuilder(context, _loadedData[index]);
                      }
                      // );
                    },
                    // ),
                    //           ),
                    //   ],
                  ),
                  !controller.isNewPost && controller.newPosts < 1
                      ? SizedBox()
                      : widget.newsFeedCheck == true
                          ? SizedBox(
                              width: 120,
                              height: 35,
                              child: ElevatedButton(
                                onPressed: () async {
                                  controller.isSearch = false;
                                  controller.isNewPost = false;
                                  controller.newPosts = 0;
                                  controller.socket.emit("unread_count_posts",{'user_id': controller.userId, "count": 0});

                                  // print(controller.postList[0].body);


                                  controller.postList =
                                      await controller.getNewsFeed(
                                          shouldUpdate: true, reload: true);

                                  // _scroll.animateTo(0, duration: Duration(milliseconds: 100), curve: Curves.bounceIn);
                                  controller.update(['post', 'postt']);
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      "${controller.newPosts} ",
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                      ),
                                    ),
                                    Text(
                                      controller.newPosts > 1
                                          ?
                                      Strings.newWerfs
                                          : Strings.werf,
                                      style: Styles.baseTextTheme.headline2
                                          .copyWith(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w400,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ],
                                ),
                                style: ButtonStyle(
                                    elevation: MaterialStateProperty.all(10),
                                    padding: MaterialStateProperty.all<
                                        EdgeInsetsGeometry>(EdgeInsets.all(5)),
                                    backgroundColor: MaterialStateProperty.all(
                                        controller.displayColor),
                                    shape: MaterialStateProperty.all<
                                            RoundedRectangleBorder>(
                                        RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(18.0),
                                      // side: BorderSide(color: Colors.red)
                                    ))),
                              ),
                            )
                          : SizedBox()
                ],
              );
  }

  void _loadMoreData() async {
    if (!_end) {
      if (!_loading) {
        // making sure setState is called after build method is done
        try {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (mounted) {
              setState(() => _loading = true);
            }
          });
        } catch (_) {}
        List<Post> listFor = [];
        await widget._itemDataProvider(_pgCount).then((value) {
          value.forEach((element) {
            _loadedData.removeWhere((item) => item.postId == element.postId);
            // _loadedData.add(element);
          });
          //print("previousId" + _loadedData.length.toString());
          listFor.addAll(value);
          //print("previousId" + _loadedData.length.toString());

          if (listFor != null && listFor.isNotEmpty) {
            try {
              if (mounted) {
                //print("previousId" + _loadedData.length.toString());
                // WidgetsBinding.instance.addPostFrameCallback((_) {

                _loadedData.addAll(listFor);
                _pgCount++;
                _loading = false;
                setState(() {
                  // });
                });
              }
            } catch (_) {}
            if (listFor.length < 10) {
              try {
                // WidgetsBinding.instance.addPostFrameCallback((_) {
                if (mounted) {
                  setState(() {
                    _end = true;
                  });
                }
                // });
              } catch (_) {}
            }
          } else {
            try {
              // WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted) {
                setState(() {
                  _end = true;
                  _loading = false;
                  _finalEnd = true;
                });
              }
              // });
            } catch (_) {}
          }
        });
      }
    } else {
      try {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            setState(() {
              _loading = false;
              _finalEnd = true;
            });
          }
        });
      } catch (_) {}
    }
  }
// }
}

final bucket = PageStorageBucket();
