import 'package:flutter/material.dart';
import 'package:werfieapp/constants/responsive.dart';
import 'package:werfieapp/utils/strings.dart';

import '../utils/font.dart';

class CustomAppBarWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).brightness == Brightness.dark
          ? Colors.black
          : Colors.white,
      iconTheme: IconThemeData(
        color: Color(0xFF4f515b),
      ),
      title: Container(
        height: 45,
        width: MediaQuery.of(context).size.width * 0.7,
        child: TextField(
          style: LightStyles.baseTextTheme.headline2.copyWith(
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black),
          cursorColor: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Colors.black,
          decoration: InputDecoration(
            hintText: Strings.search,
            hintStyle: LightStyles.baseTextTheme.headline3,
            prefixIcon: Icon(
              Icons.search,
              size: 20,
              color: Theme.of(context).brightness == Brightness.dark
                  ? Colors.white
                  : Colors.black,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(40),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(40),
              borderSide: BorderSide(
                width: 1,
                color: Colors.grey,
              ),
            ),
            fillColor: Colors.grey[250],
            filled: true,
          ),
        ),
      ),
      automaticallyImplyLeading: !Responsive.isDesktop(context) ? true : false,
    );
  }
}
