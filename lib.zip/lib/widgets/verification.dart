import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../network/controller/news_feed_controller.dart';
import '../utils/font.dart';

class Verification extends StatelessWidget {
  Verification({Key key}) : super(key: key);

  final newFeedController = Get.put(NewsfeedController());

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 500,
      width: 500,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(50),
      ),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: newFeedController.verificationCheck == false
            ? Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Image.asset(
                    'assets/images/start_verify.png',
                    height: 250,
                  ),
                  Text(
                    "Verification request",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontSize: 20,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Verification is for notable people or groups within a specific category. If that sounds like you, start a verification request.",
                    textAlign: TextAlign.center,
                    style: Styles.baseTextTheme.headline4.copyWith(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black,
                      fontSize: kIsWeb ? 14 : 12,
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () async {
                            await newFeedController.verificationAccount();
                            newFeedController.verificationCheck = true;
                            newFeedController.update();
                            Navigator.pop(context);
                          },
                          child: Text(
                            'Start request',
                            style: Theme.of(context)
                                .textTheme
                                .headline6
                                .copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15),
                          ),
                          style: ElevatedButton.styleFrom(
                            shadowColor: Colors.transparent,
                            primary: Colors.blue,
                            padding: EdgeInsets.symmetric(
                                vertical: 17, horizontal: 25),
                            elevation: 0.0,
                            shape: StadiumBorder(),
                            // minimumSize: Size(100, 40),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
      ),
    );
  }
}
