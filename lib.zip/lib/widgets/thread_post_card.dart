import 'dart:developer';

//import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:werfieapp/models/category.dart';
import 'package:werfieapp/models/reaction.dart';
import 'package:werfieapp/models/retweet.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/network/controller/browse_controller.dart';
import 'package:werfieapp/network/controller/other_users_controller.dart';
import 'package:werfieapp/network/controller/profile_controller.dart';
import 'package:werfieapp/network/controller/saved_post_controller.dart';
import 'package:werfieapp/screens/other_users_profile.dart';
import 'package:werfieapp/screens/quote_rewerf_mobile.dart';
import 'package:werfieapp/screens/user_profile.dart';
import 'package:werfieapp/services/database_helper.dart';
import 'package:werfieapp/utils/routes.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/utils/urls.dart';
import 'package:werfieapp/utils/utils_methods.dart';
import 'package:werfieapp/web_views/dialogbox_web.dart';
import 'package:werfieapp/widgets/audio_player.dart';

// import 'package:werfieapp/widgets/check_history.dart';
import 'package:werfieapp/widgets/chewie_videoplayer.dart';
import 'package:werfieapp/widgets/comments_screen.dart';
import 'package:werfieapp/widgets/newsfeed_carousel.dart';
import 'package:werfieapp/widgets/polls.dart';
import 'package:werfieapp/widgets/post_card.dart';
import 'package:werfieapp/widgets/quote_rewerf.dart';
import 'package:werfieapp/widgets/react_retweet_dialog.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

import 'package:werfieapp/widgets/post_text_description.dart';
import 'package:werfieapp/widgets/video_player.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:werfieapp/widgets/view_history.dart';
import '../models/create_post_model/create_post_model.dart';
import '../models/view_edit_history.dart';
import '../network/controller/mobile_comments_controller.dart';
import '../network/firebase_deeplinking.dart';
import '../network/singleTone.dart';
import '../screens/create_post_mobile.dart';
import '../utils/asset_string.dart';
import '../utils/colors.dart';
import '../utils/fluro_router.dart';
import '../utils/font.dart';
import '../web_views/web_main_screen.dart';
import '../web_views/web_view_screen.dart';
import 'blue_tick.dart';
import 'comments_listview.dart';

// ignore: must_be_immutable


final otherController = Get.put(OtherUserController());

final userData = GetStorage();


RxBool reactionValue = false.obs;

class ThreadPostCard extends StatelessWidget {
  final Post post;
  final int index;
  final NewsfeedController controller;
  final GlobalKey<ScaffoldState> scaffoldKey;
  final SavedPostController savedController;
  final BrowseController browseController;
  final OtherUserController otherUserController;
  final int savedItemId;
  List<Post> postList;
  bool saveCard = false;
  int deletePostId;
  int mute;

  ThreadPostCard({
    @required this.post,
    this.scaffoldKey,
    @required this.index,
    this.otherUserController,
    @required this.controller,
    this.savedController,
    this.browseController,
    this.savedItemId,
    this.postList,
    this.saveCard,
    this.deletePostId,
    this.mute
  });

  final commentTextController = TextEditingController();

  //FirebaseDeepLink firebaseDeepLink=FirebaseDeepLink();
  // var isLiked = false;
  var isCommentField = false;
  var isRetweetSuccess = false;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    String getDate;
    if (saveCard == true) {
      getDate = UtilsMethods.getDate(post.saveCreateAt);
    } else {
      getDate = UtilsMethods.getDate(post.postedOn);
    }

    var screenHeight = MediaQuery
        .of(context)
        .size
        .height;
    var screenWidth = MediaQuery
        .of(context)
        .size
        .width;
    // ignore: unused_local_variable
    var containerSizeForImage = Get.width / 3;
    return Stack(
      children: [
        Material(
          color: Theme
              .of(context)
              .scaffoldBackgroundColor,
          child: MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              // focusColor: Colors.transparent,
              // hoverColor: Colors.transparent,
              // highlightColor: Colors.transparent,
              onTap: kIsWeb
                  ? () async {
                /*onHomeChange = false;
                onBrowsChange = false;
                onTrendsChange = false;
                onBookMarksChange = false;
                onChatsChange = false;
                onProfileChange = false;
                onSettingChange = false;
                onListChange = false;
                onNotificationChange = false;
                onMoreChange = false;
                onMomentChange = false;



                print("vvvv");

                controller.selectedPost = post;
                controller.postId = post.postId;
                controller.threadNumber = null;
                SingleTone.instance.post_Id = post.postId;
                controller.isPostDetails = true;
                controller.isTrendsScreen = false;
                controller.isNewsFeedScreen = false;
                controller.isBrowseScreen = false;
                controller.isNotificationScreen = false;
                controller.isProfileScreen = false;
                controller.isChatScreen = false;
                controller.isSavedPostScreen = false;
                //  controller.selectedPost = post;
                if (controller.isSavedPostScreen) {
                  savedController.update();
                }
                if (controller.isBrowseScreen) {
                  browseController.update();
                }*/
                controller.postId = post.postId;
                SingleTone.instance.post_Id = post.postId;
                controller.threadNumber = null;
                // controller.selectedPost = post;
                controller.navRoute = "isPostDetail";
                // print("postcard");

                Get.toNamed(FluroRouters.mainScreen + "/postDetail/" +
                    post.postId.toString());
                // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());

                // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));


                // print('post id:${controller.postId}');
                // print('singtone post id:${SingleTone.instance.post_Id}');
                // controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId, isReload: true);
                // controller.update();
                // Get.toNamed(FluroRouters.werfDetailScreen+"/${post.postId}");

              }
                  : () async {
                controller.selectedPost = post;

                // controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                // controller.update();
                // Get.to(PostDetail(controller: controller, post: post));
                controller.commentController.clear();
                controller.selectedPost = post;
                Navigator.push(context, MaterialPageRoute(
                    builder: (BuildContext context) =>
                        CommentsScreen(postId: post.postId, thread_no: null,)));
                controller.postId = post.postId;

                //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                // controller.isPostDetails = true;
                // controller.postDetail =
                //     await controller.getSingleNewsFeedItem(post.postId);
              },
              child: Container(
                //  width : MediaQuery.of(context).size.width >= 700 ? 600 : kIsWeb ? MediaQuery.of(context).size.width >= 500 ? Get.width/ 1.0  : Get.width/ 1.5  : null,
                // decoration: BoxDecoration(
                //     border: Border.all(color: Colors.grey[300]),
                //     borderRadius: BorderRadius.circular(8.0)),
                margin: EdgeInsets.only(top: 0.0, bottom: 0, left: 4, right: 4),
                child: ListTile(
                  mouseCursor: MouseCursor.defer,
                  dense: true,
                  // tileColor: Colors.yellow,
                  // minVerticalPadding: 0.00,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 8,
                  ),
                  title: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  //PROFILE IMAGE
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10.00),
                                    child: MouseRegion(
                                      cursor: SystemMouseCursors.click,
                                      child: GestureDetector(
                                        onTap: () async {
                                          if (kIsWeb) {
                                            /*if (GetStorage().read('id') ==
                                                post.authorId){


                                              onProfileChange = true;
                                              controller.isTrendsScreen = false;
                                              controller.isNewsFeedScreen = false;
                                              controller.isBrowseScreen = false;
                                              controller.isNotificationScreen = false;
                                              controller.isChatScreen = false;
                                              controller.isSavedPostScreen = false;
                                              controller.isPostDetails = false;
                                              controller.isProfileScreen = true;
                                              controller.isOtherUserProfileScreen = false;


                                              if (Get.isRegistered<
                                                  ProfileController>()) {
                                                Get.find<ProfileController>(). isHiddenPost = false;
                                                Get.find<ProfileController>().isTweets = true;
                                                Get.find<ProfileController>().isTweetsReply = false;
                                                Get.find<ProfileController>().isMedia = false;
                                                Get.find<ProfileController>().isLikes = false;
                                                await Get.find<
                                                    ProfileController>()
                                                    .filterUsersPost(
                                                    "posts");

                                                Get
                                                    .find<
                                                    ProfileController>()
                                                    .userProfile =
                                                await controller
                                                    .getUserProfile();


                                                Get
                                                    .find<
                                                    ProfileController>()
                                                    .userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                      .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                      .value =
                                                      element.commentsCount;
                                                  element.reactionType
                                                      .value =
                                                      element.isLiked;
                                                  // element.comments.forEach((
                                                  //     element) {
                                                  //   element.reactionType
                                                  //       .value =
                                                  //       element.isLiked;
                                                  //   element.commentCount
                                                  //       .value = element
                                                  //       .simpleLikeCount;
                                                  // });
                                                  element.reactionType
                                                      .refresh();

                                                  // if (element.isLiked == true) {
                                                  //   element.like.value = true;
                                                  //   element.like.refresh();
                                                  // }
                                                });
                                                Get.find<
                                                    ProfileController>()
                                                    .update();
                                              }


                                              else{


                                                print("vvvvv");
                                                Get.put(ProfileController());
                                                Get.find<ProfileController>().userProfile = await controller.getUserProfile();

                                                Get.find<ProfileController>(). isHiddenPost = false;
                                                Get.find<ProfileController>().isTweets = true;
                                                Get.find<ProfileController>().isTweetsReply = false;
                                                Get.find<ProfileController>().isMedia = false;
                                                Get.find<ProfileController>().isLikes = false;
                                                await Get.find<ProfileController>().filterUsersPost("posts");
                                                Get.find<ProfileController>().userPosts.forEach((element) {
                                                  element.likeCount.value = element.simpleLikeCount;
                                                  element.rebuzzCount.value = element.retweetCount;
                                                  element.commentCount.value = element.commentsCount;
                                                  element.reactionType.value = element.isLiked;
                                                  // element.comments.forEach((element) {
                                                  //   element.reactionType.value = element.isLiked;
                                                  //   element.commentCount.value  = element.simpleLikeCount;
                                                  // });
                                                  element.reactionType.refresh();

                                                  // if (element.isLiked == true) {
                                                  //   element.like.value = true;
                                                  //   element.like.refresh();
                                                  // }
                                                });
                                                Get.find<ProfileController>().update();


                                              }




                                              controller.update();
                                            }
                                            else {
                                              controller.isTrendsScreen = false;
                                              controller.isNewsFeedScreen = false;
                                              controller.isBrowseScreen = false;
                                              controller.isNotificationScreen = false;
                                              controller.isChatScreen = false;
                                              controller.isSavedPostScreen = false;
                                              controller.isPostDetails = false;
                                              controller.isProfileScreen = false;
                                              controller.isOtherUserProfileScreen = true;
                                              if (Get.isRegistered<
                                                  OtherUserController>()) {
                                                Get.delete<OtherUserController>();
                                              }
                                              controller.otherUserName =
                                                  post.authorName;
                                              controller.otherUserId = post.authorId;

                                              controller.update();

                                              // print(post.userInfo.is_follow);
                                              controller.getOtherUserProfile(
                                                  controller.otherUserId,
                                                  postId: post.postId,
                                                  userInfod: post.userInfo
                                              );


                                              // controller.getOtherUserProfile(
                                              //     controller.otherUserId,
                                              //     postId: post.postId);
                                            }*/
                                            SingleTone.instance
                                                .userId = post
                                                .authorId.toString();

                                            Get.toNamed(FluroRouters
                                                .mainScreen +
                                                "/profile/" +
                                                post.authorId
                                                    .toString());
                                          }
                                          else {
                                            if (GetStorage().read('id') ==
                                                post.authorId) {
                                              controller.isTrendsScreen = false;
                                              controller.isNewsFeedScreen =
                                              false;
                                              controller.isBrowseScreen = false;
                                              controller.isNotificationScreen =
                                              false;
                                              controller.isChatScreen = false;
                                              controller.isSavedPostScreen =
                                              false;
                                              controller.isPostDetails = false;
                                              controller.isProfileScreen = true;
                                              controller
                                                  .isOtherUserProfileScreen =
                                              false;
                                              controller.update();


                                              if (Get.isRegistered<
                                                  ProfileController>()) {
                                                Get
                                                    .find<ProfileController>()
                                                    .isHiddenPost = false;
                                                Get
                                                    .find<ProfileController>()
                                                    .isTweets = true;
                                                Get
                                                    .find<ProfileController>()
                                                    .isTweetsReply = false;
                                                Get
                                                    .find<ProfileController>()
                                                    .isMedia = false;
                                                Get
                                                    .find<ProfileController>()
                                                    .isLikes = false;
                                                await Get.find<
                                                    ProfileController>()
                                                    .filterUsersPost("posts");

                                                Get
                                                    .find<ProfileController>()
                                                    .userProfile =
                                                await controller
                                                    .getUserProfile();


                                                Get
                                                    .find<ProfileController>()
                                                    .userPosts
                                                    .forEach((element) {
                                                  element.likeCount.value =
                                                      element
                                                          .simpleLikeCount;
                                                  element.rebuzzCount
                                                      .value =
                                                      element.retweetCount;
                                                  element.commentCount
                                                      .value =
                                                      element.commentsCount;
                                                  element.reactionType
                                                      .value =
                                                      element.isLiked;
                                                  // element.comments.forEach((
                                                  //     element) {
                                                  //   element.reactionType
                                                  //       .value =
                                                  //       element.isLiked;
                                                  //   element.commentCount
                                                  //       .value = element
                                                  //       .simpleLikeCount;
                                                  // });
                                                  element.reactionType
                                                      .refresh();

                                                  // if (element.isLiked == true) {
                                                  //   element.like.value = true;
                                                  //   element.like.refresh();
                                                  // }
                                                });
                                                Get.find<
                                                    ProfileController>()
                                                    .update();
                                              }


                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (
                                                          BuildContext context) =>
                                                          ProfileScreen(
                                                              controller: controller)));
                                            } else {
                                              controller.otherUserId =
                                                  post.authorId;
                                              if (Get.isRegistered<
                                                  OtherUserController>()) {
                                                Get.delete<
                                                    OtherUserController>();
                                              }
                                              print('USER INFO + ' +
                                                  post.userInfo.toJson()
                                                      .toString());
                                              controller.update();
                                              controller.getOtherUserProfile(
                                                  controller.otherUserId,
                                                  postId: post.postId);

                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (
                                                          BuildContext context) =>
                                                          OtherUsersProfile(
                                                            controller: controller,
                                                            userInfo: controller
                                                                .userInfo,
                                                          )));
                                            }
                                          }
                                        },
                                        child: CircleAvatar(
                                          backgroundImage: post.profileImage !=
                                              null
                                              ? NetworkImage(post.profileImage)
                                              : AssetImage(
                                              "assets/images/person_placeholder.png"),
                                          radius: 22,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 5),

                                  //USERNAME AND POST TIME
                                  Padding(
                                    padding: const EdgeInsets.only(
                                      top: 6.0,
                                      bottom: 8.0,
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment
                                          .start,
                                      mainAxisAlignment: MainAxisAlignment
                                          .start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            MouseRegion(
                                              cursor: SystemMouseCursors.click,
                                              child: GestureDetector(
                                                onTap: () async {
                                                  if (kIsWeb) {
                                                    SingleTone.instance
                                                        .userId = post
                                                        .authorId.toString();

                                                    Get.toNamed(FluroRouters
                                                        .mainScreen +
                                                        "/profile/" +
                                                        post.authorId
                                                            .toString());
                                                    /*  if (GetStorage().read('id') ==
                                                        post.authorId) {
                                                      controller.isTrendsScreen = false;
                                                      controller.isNewsFeedScreen =
                                                      false;
                                                      controller.isBrowseScreen = false;
                                                      controller.isNotificationScreen =
                                                      false;
                                                      controller.isChatScreen = false;
                                                      controller.isSavedPostScreen =
                                                      false;
                                                      controller.isPostDetails = false;
                                                      controller.isProfileScreen = true;
                                                      controller
                                                          .isOtherUserProfileScreen =
                                                      false;


                                                      if (Get.isRegistered<
                                                          ProfileController>()) {
                                                        Get.find<ProfileController>(). isHiddenPost = false;
                                                        Get.find<ProfileController>().isTweets = true;
                                                        Get.find<ProfileController>().isTweetsReply = false;
                                                        Get.find<ProfileController>().isMedia = false;
                                                        Get.find<ProfileController>().isLikes = false;
                                                        await Get.find<
                                                            ProfileController>()
                                                            .filterUsersPost(
                                                            "posts");

                                                        Get
                                                            .find<
                                                            ProfileController>()
                                                            .userProfile =
                                                        await controller
                                                            .getUserProfile();


                                                        Get
                                                            .find<
                                                            ProfileController>()
                                                            .userPosts
                                                            .forEach((element) {
                                                          element.likeCount.value =
                                                              element
                                                                  .simpleLikeCount;
                                                          element.rebuzzCount
                                                              .value =
                                                              element.retweetCount;
                                                          element.commentCount
                                                              .value =
                                                              element.commentsCount;
                                                          element.reactionType
                                                              .value =
                                                              element.isLiked;
                                                          // element.comments.forEach((
                                                          //     element) {
                                                          //   element.reactionType
                                                          //       .value =
                                                          //       element.isLiked;
                                                          //   element.commentCount
                                                          //       .value = element
                                                          //       .simpleLikeCount;
                                                          // });
                                                          element.reactionType
                                                              .refresh();

                                                          // if (element.isLiked == true) {
                                                          //   element.like.value = true;
                                                          //   element.like.refresh();
                                                          // }
                                                        });
                                                        Get.find<
                                                            ProfileController>()
                                                            .update();
                                                      }


                                                      else{


                                                        print("vvvvv");
                                                        Get.put(ProfileController());
                                                        Get.find<ProfileController>().userProfile = await controller.getUserProfile();

                                                        Get.find<ProfileController>(). isHiddenPost = false;
                                                        Get.find<ProfileController>().isTweets = true;
                                                        Get.find<ProfileController>().isTweetsReply = false;
                                                        Get.find<ProfileController>().isMedia = false;
                                                        Get.find<ProfileController>().isLikes = false;
                                                        await Get.find<ProfileController>().filterUsersPost("posts");
                                                        Get.find<ProfileController>().userPosts.forEach((element) {
                                                          element.likeCount.value = element.simpleLikeCount;
                                                          element.rebuzzCount.value = element.retweetCount;
                                                          element.commentCount.value = element.commentsCount;
                                                          element.reactionType.value = element.isLiked;
                                                          // element.comments.forEach((element) {
                                                          //   element.reactionType.value = element.isLiked;
                                                          //   element.commentCount.value  = element.simpleLikeCount;
                                                          // });
                                                          element.reactionType.refresh();

                                                          // if (element.isLiked == true) {
                                                          //   element.like.value = true;
                                                          //   element.like.refresh();
                                                          // }
                                                        });
                                                        Get.find<ProfileController>().update();


                                                      }

                                                      controller.update();
                                                    }
                                                    else {
                                                      // controller.isTrendsScreen = false;
                                                      // controller.isNewsFeedScreen =
                                                      // false;
                                                      // controller.isBrowseScreen = false;
                                                      // controller.isNotificationScreen =
                                                      // false;
                                                      // controller.isChatScreen = false;
                                                      // controller.isSavedPostScreen =
                                                      // false;
                                                      // controller.isPostDetails = false;
                                                      // controller.isProfileScreen =
                                                      // false;
                                                      // controller
                                                      //     .isOtherUserProfileScreen =
                                                      // true;
                                                      //
                                                      // controller.otherUserName =
                                                      //     post.username;
                                                      // controller.otherUserId =
                                                      //     post.authorId;
                                                      //
                                                      // controller.update();
                                                      // controller.getOtherUserProfile(
                                                      //     GetStorage().read('id'),
                                                      //     postId: post.postId);





                                                      controller.isTrendsScreen =
                                                      false;
                                                      controller.isNewsFeedScreen =
                                                      false;
                                                      controller.isBrowseScreen =
                                                      false;
                                                      controller
                                                          .isNotificationScreen =
                                                      false;
                                                      controller.isChatScreen =
                                                      false;
                                                      controller.isSavedPostScreen =
                                                      false;
                                                      controller.isPostDetails =
                                                      false;
                                                      controller.isProfileScreen =
                                                      false;
                                                      controller
                                                          .isOtherUserProfileScreen =
                                                      true;

                                                      controller.otherUserName =
                                                          post.username;
                                                      controller.otherUserId =
                                                          post.authorId;

                                                      controller.update();

                                                      if (Get.isRegistered<
                                                          OtherUserController>()) {
                                                        Get.delete<
                                                            OtherUserController>();
                                                      }


                                                      print(
                                                          post.userInfo.is_follow);
                                                      controller
                                                          .getOtherUserProfile(
                                                          controller.otherUserId,
                                                          postId: post.postId,
                                                          userInfod: post.userInfo
                                                      );

                                                    }*/
                                                  }
                                                  else {
                                                    if (GetStorage().read(
                                                        'id') ==
                                                        post.authorId) {
                                                      controller
                                                          .isTrendsScreen =
                                                      false;
                                                      controller
                                                          .isNewsFeedScreen =
                                                      false;
                                                      controller
                                                          .isBrowseScreen =
                                                      false;
                                                      controller
                                                          .isNotificationScreen =
                                                      false;
                                                      controller.isChatScreen =
                                                      false;
                                                      controller
                                                          .isSavedPostScreen =
                                                      false;
                                                      controller.isPostDetails =
                                                      false;
                                                      controller
                                                          .isProfileScreen =
                                                      true;
                                                      controller
                                                          .isOtherUserProfileScreen =
                                                      false;


                                                      controller.update();
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder:
                                                              (
                                                              BuildContext context) =>
                                                              ProfileScreen(
                                                                  controller:
                                                                  controller),
                                                        ),
                                                      );
                                                    } else {
                                                      controller.otherUserName =
                                                          post.username;
                                                      controller.otherUserId =
                                                          post.authorId;
                                                      controller
                                                          .getOtherUserProfile(
                                                          controller
                                                              .otherUserId,
                                                          postId: post.postId);
                                                      controller.update();
                                                      if (Get.isRegistered<
                                                          OtherUserController>()) {
                                                        Get.delete<
                                                            OtherUserController>();
                                                      }
                                                      Navigator.push(
                                                          context,
                                                          MaterialPageRoute(
                                                              builder: (
                                                                  BuildContext
                                                                  context) =>
                                                                  OtherUsersProfile(
                                                                    controller: controller,
                                                                    userInfo: controller
                                                                        .userInfo,
                                                                  )));
                                                    }
                                                  }
                                                },
                                                child: Row(
                                                  //  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Container(
                                                          width: post.authorName
                                                              .length >= 15
                                                              ? kIsWeb
                                                              ? 145
                                                              : 100
                                                              : null,
                                                          child: Text("${post
                                                              .authorName}",
                                                            maxLines: 1,
                                                            overflow: TextOverflow
                                                                .ellipsis,
                                                            style: TextStyle(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness
                                                                      .dark
                                                                  ? Colors
                                                                  .white
                                                                  : Colors
                                                                  .black,
                                                              fontWeight: FontWeight
                                                                  .bold,
                                                              fontSize: kIsWeb
                                                                  ? 15
                                                                  : 15,
                                                            ),
                                                          ),
                                                        ),
                                                        post.userInfo
                                                            .accountVerified ==
                                                            "verified" ?
                                                        Row(children: [
                                                          SizedBox(
                                                            width: 5,
                                                          ),
                                                          BlueTick(
                                                            height: 15,
                                                            width: 15,
                                                            iconSize: 10,
                                                          ),
                                                        ],) : SizedBox(),
                                                        SizedBox(width: 5,),
                                                        Row(
                                                          children: [
                                                            Container(
                                                              width: post
                                                                  .username
                                                                  .length >= 15
                                                                  ? kIsWeb
                                                                  ? 145
                                                                  : 100
                                                                  : null,
                                                              child: Text(
                                                                '@${post
                                                                    .username}',
                                                                // style: Theme
                                                                //     .of(context)
                                                                //     .brightness == Brightness.dark ?
                                                                // TextStyle(
                                                                //   color: Colors.white,
                                                                //   height: 1.2,
                                                                //   fontSize: 16,
                                                                //
                                                                // )
                                                                //     : TextStyle(
                                                                //     color: Colors.black,
                                                                //     height: 1.2,
                                                                //     fontSize: 16,
                                                                //
                                                                // ),
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 15
                                                                      : 15,
                                                                ),
                                                                softWrap: false,
                                                                maxLines: 1,
                                                                overflow: TextOverflow
                                                                    .ellipsis,
                                                              ),
                                                            ),

                                                          ],
                                                        ),
                                                        Padding(
                                                          padding: EdgeInsets
                                                              .only(bottom: 10,
                                                              left: 2),
                                                          child: Text(
                                                            ".",
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              fontSize: 20,
                                                              fontWeight: FontWeight
                                                                  .w500,
                                                            ),
                                                          ),
                                                        ),
                                                        Text('${getDate ==
                                                            null
                                                            ? ''
                                                            : getDate}',
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline2
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 15
                                                                : 15,
                                                          ),
                                                        ),
                                                      ],
                                                    ),

                                                    // SizedBox(width: 100,),
                                                    // /// post thread
                                                    // post.type=='thread'
                                                    // //&& controller.threadNumber==post.thread_no
                                                    //     ?
                                                    // Text('Post',
                                                    //   style: Theme.of(context)
                                                    //       .textTheme
                                                    //       .headline3,
                                                    // ):Text('')
                                                  ],
                                                ),
                                              ),
                                            ),
                                            // SizedBox(width: 8),
                                            // kIsWeb
                                            //     ? Text(
                                            //         Strings.postedUpdate,
                                            //         style: Theme.of(context)
                                            //             .textTheme
                                            //             .bodyText2
                                            //             .copyWith(height: 2.2),
                                            //       )
                                            //     : SizedBox(),

                                            // Spacer(),

                                          ],
                                        ),
                                        // Text(
                                        //   post.postedTimeAgo != null
                                        //       ? "${post.postedTimeAgo}"
                                        //       : "${post.postedOn.toString()}",
                                        //   style: Theme.of(context)
                                        //       .textTheme
                                        //       .bodyText2
                                        //       .copyWith(height: 1.2),
                                        // ),
                                        //Post Description
                                        SizedBox(height: 5),

                                        kIsWeb ? post.body.length > 0 ?

                                        GetBuilder<NewsfeedController>(
                                            id: 'translate',

                                            builder: (_) {
                                              return PostTextDescription(
                                                post: post,
                                                controller: controller,
                                                // showMomentScreen: showMomentScreen,
                                                // editMomentScreen: editMomentScreen,
                                                translationCheck: post
                                                    .translation.value,
                                                translationData: post
                                                    .translationData,
                                                width: MediaQuery
                                                    .of(context)
                                                    .size
                                                    .width >= 720
                                                    ? controller
                                                    .editMomentScreen == true ||
                                                    controller
                                                        .showMomentsScreen ==
                                                        true
                                                    ? 260
                                                    : 500
                                                    : Get.width / 1.7,

                                              );
                                            })
                                            : SizedBox()
                                            : SizedBox(),


                                        kIsWeb ? post.body.length > 0 ?
                                        post.translationLoader == true ?
                                        SizedBox(
                                          height: 20,
                                          width: 20,
                                          child: CircularProgressIndicator(
                                          ),
                                        ) :


                                        controller.languageData != null ?
                                        controller.languageData.myLang.id !=
                                            post.languageId ?
                                        Obx(() {
                                          return GestureDetector(
                                            onTap: () async {
                                              post.translationLoader = true;
                                              bool success = false;

                                              post.translationData =
                                              await controller
                                                  .newsFeedTranslation(
                                                  post.postId,
                                                  controller.languageData
                                                      .myLang.code);

                                              if (post.translationData !=
                                                  null) {
                                                post.translationLoader = false;
                                                if (post.translation
                                                    .value == false) {
                                                  print(
                                                      "controller.translationData.data[0].body ${controller
                                                          .translationData
                                                          .data[0].body}");
                                                  post.translation.value =
                                                  true;
                                                  controller.update(
                                                      ['translate']);
                                                }
                                                else if (post.translation
                                                    .value == true) {
                                                  post.translation.value =
                                                  false;
                                                  controller.update(
                                                      ['translate']);
                                                }
                                              }
                                              else {
                                                post.translationLoader = false;
                                                controller.update();
                                              }
                                            },

                                            child:

                                            post.translation.value == true ?
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  bottom: 10),
                                              child: Text(

                                                  "View Original",

                                                  style: TextStyle(
                                                      decoration: TextDecoration
                                                          .underline,
                                                      color: controller
                                                          .displayColor

                                                  )
                                              ),
                                            ) : Padding(
                                              padding: const EdgeInsets.only(
                                                  bottom: 10),
                                              child: Text(
                                                  Strings.viewTranslated,

                                                  style: TextStyle(
                                                      decoration: TextDecoration
                                                          .underline,
                                                      color: controller
                                                          .displayColor

                                                  )
                                              ),
                                            ),
                                          );
                                        }) : SizedBox() : SizedBox()
                                            : SizedBox() : SizedBox(),


                                        // kIsWeb
                                        //     ? post.body.length > 0
                                        //
                                        //     ? Padding(
                                        //   padding:  EdgeInsets.only(left:0 ),
                                        //   // child: GestureDetector(
                                        //   //     onTap: kIsWeb
                                        //   //       ? () async {
                                        //   //     controller.selectedPost = post;
                                        //   //     controller.postId = post.postId;
                                        //   //     controller.threadNumber = null;
                                        //   //     // SingleTone.instance.post_Id = post.postId;
                                        //   //     controller.isPostDetails = true;
                                        //   //     controller.isTrendsScreen = false;
                                        //   //     controller.isNewsFeedScreen = false;
                                        //   //     controller.isBrowseScreen = false;
                                        //   //     controller.isNotificationScreen = false;
                                        //   //     controller.isChatScreen = false;
                                        //   //     controller.isSavedPostScreen = false;
                                        //   //     //  controller.selectedPost = post;
                                        //   //     if (controller.isSavedPostScreen) {
                                        //   //       savedController.update();
                                        //   //     }
                                        //   //     if (controller.isBrowseScreen) {
                                        //   //       browseController.update();
                                        //   //     }
                                        //   //     print('post id:${controller.postId}');
                                        //   //     // print('singtone post id:${SingleTone.instance.post_Id}');
                                        //   //     controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload:true);
                                        //   //     controller.update();
                                        //   //
                                        //   //
                                        //   //   } : () async {
                                        //   //     controller.selectedPost = post;
                                        //   //
                                        //   //     // controller.postDetail =
                                        //   //     //     await controller.getSingleNewsFeedItem(post.postId);
                                        //   //     // controller.update();
                                        //   //     // Get.to(PostDetail(controller: controller, post: post));
                                        //   //     controller.selectedPost = post;
                                        //   //     Navigator.push(
                                        //   //         context,
                                        //   //         MaterialPageRoute(
                                        //   //             builder: (BuildContext context) =>
                                        //   //                 CommentsScreen(postId: post.postId, thread_no: null,)));
                                        //   //     controller.postId = post.postId;
                                        //   //     // controller.isPostDetails = true;
                                        //   //     // controller.postDetail =
                                        //   //     //     await controller.getSingleNewsFeedItem(post.postId);
                                        //   //   },
                                        //   //   child:
                                        //    child: PostTextDescription(
                                        //       post: post,
                                        //       controller: controller,
                                        //     ),
                                        //  // ),
                                        // )
                                        //     : SizedBox()
                                        //     : SizedBox(),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          ///POPUP MENU BUTTON
                          Expanded(
                            child:
                            controller.isNewsFeedScreen == false ||
                                controller.isNewsFeedScreen == null ? myPopMenu(
                                context, scaffoldKey, post, controller, index) :
                            controller.isSavedPostScreen == true ? sharePopMenu(
                                context, scaffoldKey, post, controller)
                                : controller.isBrowseScreen == false
                                ? myPopMenu(
                                context, scaffoldKey, post, controller, index)
                                : SizedBox(),
                          )
                        ],
                      ),


                      Row(
                        children: [
                          IntrinsicHeight(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 5),
                              child: Align(
                                alignment: Alignment.topLeft,
                                child: SizedBox(

                                  height: kIsWeb ? post.postFiles.length == 0
                                      ? Get.height * 0.1
                                      : Get.height * 0.5 :
                                  post.postFiles == null || post.postFiles.length == 0
                                      ? Get.height * 0.1
                                      : Get.height * 0.3,
                                  child: VerticalDivider(
                                    color: Colors.grey,
                                    thickness: 2,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                if (controller.getWhoLikedPost(
                                    post.followingLikes,
                                    post.followingRetweets) != '')
                                  Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(controller.getWhoLikedPost(
                                          post.followingLikes,
                                          post.followingRetweets),
                                        //  style: TextStyle(fontSize: 12),
                                        style: Theme
                                            .of(context)
                                            .brightness == Brightness.dark ?
                                        TextStyle(
                                            color: Colors.white, fontSize: 12)
                                            : TextStyle(
                                            color: Colors.black, fontSize: 12),

                                      )),

                                Padding(
                                  padding: EdgeInsets.only(
                                      top: 0.0,
                                      left: Get.width / 25,
                                      right: Get.width / 40),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment
                                        .start,
                                    children: [

                                      kIsWeb ? SizedBox()
                                          : post.body.length > 0


                                          ? GetBuilder<NewsfeedController>(
                                          id: 'translate',
                                          builder: (logic) {
                                            return PostTextDescription(
                                              post: post,
                                              controller: controller,
                                              translationCheck: post
                                                  .translation.value,
                                              translationData: post
                                                  .translationData,
                                              width: Get.width,

                                            );
                                          })
                                      // )
                                          : SizedBox(),
                                    /*  !kIsWeb
                                          ? post.body.length > 0 ?
                                      post.translationLoader == true ?
                                      SizedBox(
                                        height: 20,
                                        width: 20,
                                        child: CircularProgressIndicator(
                                        ),
                                      ) :

                                      controller.languageData != null ?
                                      controller.languageData.myLang
                                          .id != post.languageId ?
                                      Obx(() {
                                        return GestureDetector(
                                          onTap: () async {
                                            post.translationLoader = true;
                                            controller.updateControllers(
                                                deletePostId);
                                            bool success = false;

                                            post.translationData =
                                            await controller
                                                .newsFeedTranslation(
                                                post.postId,
                                                controller.languageData
                                                    .myLang.code);

                                            if (post.translationData != null) {
                                              post.translationLoader = false;
                                              controller.updateControllers(
                                                  deletePostId);
                                              if (post.translation.value ==
                                                  false) {
                                                print(
                                                    "controller.translationData.data[0].body ${controller
                                                        .translationData
                                                        .data[0].body}");
                                                post.translation.value =
                                                true;
                                                controller.update(
                                                    ['translate']);
                                              }
                                              else if (post.translation.value ==
                                                  true) {
                                                post.translation.value = false;

                                                controller.update(
                                                    ['translate']);
                                              }
                                            }
                                            else {
                                              post.translationLoader = false;
                                              controller.updateControllers(
                                                  deletePostId);
                                              controller.update();
                                            }
                                          },

                                          child:

                                          post.translation.value == true ?
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 10),
                                            child: Text(

                                               Strings.viewOriginal,

                                                style: TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                    color: controller
                                                        .displayColor

                                                )
                                            ),
                                          ) : Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 10),
                                            child: Text(
                                                Strings.viewTranslated,

                                                style: TextStyle(
                                                    decoration: TextDecoration
                                                        .underline,
                                                    color: controller
                                                        .displayColor

                                                )
                                            ),
                                          ),
                                        );
                                      }) : SizedBox() : SizedBox()
                                          : SizedBox() : SizedBox(),*/


                                      //  kIsWeb
                                      //      ? SizedBox()
                                      //      : post.body.length > 0
                                      //    //   ? GestureDetector(
                                      //    // onTap: kIsWeb
                                      //    //     ? () async {
                                      //    //   controller.selectedPost = post;
                                      //    //   controller.postId = post.postId;
                                      //    //   controller.threadNumber = null;
                                      //    //   // SingleTone.instance.post_Id = post.postId;
                                      //    //   controller.isPostDetails = true;
                                      //    //   controller.isTrendsScreen = false;
                                      //    //   controller.isNewsFeedScreen = false;
                                      //    //   controller.isBrowseScreen = false;
                                      //    //   controller.isNotificationScreen = false;
                                      //    //   controller.isChatScreen = false;
                                      //    //   controller.isSavedPostScreen = false;
                                      //    //   //  controller.selectedPost = post;
                                      //    //   if (controller.isSavedPostScreen) {
                                      //    //     savedController.update();
                                      //    //   }
                                      //    //   if (controller.isBrowseScreen) {
                                      //    //     browseController.update();
                                      //    //   }
                                      //    //   print('post id:${controller.postId}');
                                      //    //   // print('singtone post id:${SingleTone.instance.post_Id}');
                                      //    //   controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload:true);
                                      //    //   controller.update();
                                      //    //
                                      //    //
                                      //    // } : () async {
                                      //    //   controller.selectedPost = post;
                                      //    //
                                      //    //   // controller.postDetail =
                                      //    //   //     await controller.getSingleNewsFeedItem(post.postId);
                                      //    //   // controller.update();
                                      //    //   // Get.to(PostDetail(controller: controller, post: post));
                                      //    //   controller.selectedPost = post;
                                      //    //   Navigator.push(
                                      //    //       context,
                                      //    //       MaterialPageRoute(
                                      //    //           builder: (BuildContext context) =>
                                      //    //               CommentsScreen(postId: post.postId, thread_no: null,)));
                                      //    //   controller.postId = post.postId;
                                      //    //   // controller.isPostDetails = true;
                                      //    //   // controller.postDetail =
                                      //    //   //     await controller.getSingleNewsFeedItem(post.postId);
                                      //    // },
                                      //    //     child:
                                      //       ? PostTextDescription(
                                      //    post: post,
                                      //    controller: controller,
                                      // // ),
                                      //      )
                                      //      : SizedBox(),
                                      //  // post.body != null
                                      //  //     ? PostTextDescription(postText: "${post.body}")
                                      //  //     : Container(),
                                      //  //  SizedBox(
                                      //  //     height: 8,
                                      //   ),
                                      post.postFiles == null || post.postFiles.isEmpty ?
                                      post.body != null
                                          ? post.link != null
                                          ? GestureDetector(
                                        onTap: () async {
                                          if (!kIsWeb) {
                                            if (!post.link.contains('https') ||
                                                !post.link.contains('http')) {
                                              String url = "https://";
                                              post.link = url + post.link;
                                            }
                                            else
                                            if (!post.link.contains('https') &&
                                                !post.link.contains('www.') ||
                                                !post.link.contains('http') &&
                                                    !post.link.contains(
                                                        'www.')) {
                                              String url = "https://www.";
                                              post.link = url + post.link;
                                            }
                                            print("url+string ${ post.link}");

                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      WebViewScreen(
                                                          webUrl: post.link)),
                                            );
                                          }
                                          else {
                                            if (await canLaunchUrl(Uri.parse(
                                                post.link.toString()))) {
                                              await launchUrl(
                                                  Uri.parse(post.link.trim()));
                                            }
                                            else {
                                              await launchUrl(Uri.parse(
                                                  'https://${post.link
                                                      .trim()}'));
                                            }
                                          }


                                          // await launch(post.link.toString());
                                          // await ifcanLaunch(post.link.toString())
                                          //     ? await launch(post.link.toString())
                                          //     : ;
                                        },
                                        child: Card(
                                          elevation: 0,
                                          shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                                color: Colors.grey, width: 1),
                                            borderRadius: BorderRadius.circular(
                                                15),
                                          ),
                                          child: Row(
                                            children: [


                                              post.linkImage == null ?
                                              Expanded(
                                                flex: 1,
                                                child: Container(

                                                  height: kIsWeb
                                                      ? 125
                                                      : 90,
                                                  width: kIsWeb
                                                      ? 125 : 90,

                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius
                                                        .only(
                                                      topLeft: Radius.circular(
                                                          15),
                                                      bottomLeft: Radius
                                                          .circular(15),),
                                                    color: MyColors
                                                        .imagePlaceHolderBackgroundColor,
                                                    // borderRadius: BorderRadius.circular(20),
                                                    // image: DecorationImage(
                                                    //     image: AssetImage(
                                                    //         AppImages.imagePlaceHolder,
                                                    //     ),
                                                    //     ),
                                                  ),

                                                  child: Image.asset(
                                                    AppImages.imagePlaceHolder,
                                                    fit: BoxFit.contain,),
                                                ),
                                              ) :
                                              Expanded(
                                                flex: 1,
                                                child: Container(
                                                  height: kIsWeb
                                                      ? 125
                                                      : 90,
                                                  width: kIsWeb
                                                      ? 125 : 90,

                                                  // color: Colors.black,
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius
                                                        .only(
                                                      topLeft: Radius.circular(
                                                          15),
                                                      bottomLeft: Radius
                                                          .circular(15),),
                                                    color: Colors.black,
                                                    image: DecorationImage(
                                                        image: NetworkImage(post
                                                            .linkImage
                                                            .toString()),
                                                        fit: BoxFit.contain),
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                flex: 3,
                                                child: Container(
                                                  child: Column(
                                                      children: [
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                            top: 5,
                                                            left: 20,
                                                            right: 20,
                                                          ),
                                                          child:

                                                          post.linkTitle != null
                                                              ?
                                                          Text(post.linkTitle
                                                              .toString(),
                                                            overflow: TextOverflow
                                                                .ellipsis,
                                                            maxLines: 1,
                                                            // style: TextStyle(
                                                            //   color: Colors.black,
                                                            //   fontFamily: 'Cairo',
                                                            //   fontSize: 17,
                                                            //   fontWeight: FontWeight.w500,
                                                            // )
                                                            style: TextStyle(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness
                                                                      .dark
                                                                  ? Colors.white
                                                                  : Colors
                                                                  .black,
                                                              fontFamily: 'Cairo',
                                                              fontSize: kIsWeb
                                                                  ? 18
                                                                  : 17,
                                                              fontWeight: FontWeight
                                                                  .w500,
                                                            ),
                                                          )
                                                              : SizedBox(),
                                                        ),
                                                        post.linkMeta == null
                                                            ? SizedBox()
                                                            : Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                              top: 0,
                                                              left: 20,
                                                              right: 20),
                                                          child: Text(
                                                            post.linkMeta
                                                                .toString(),
                                                            maxLines: 1,
                                                            overflow:
                                                            TextOverflow
                                                                .ellipsis,
                                                            // style: TextStyle(
                                                            //   color: Colors.black,
                                                            //   fontFamily: 'Cairo',
                                                            //   fontSize: 16,
                                                            //   fontWeight: FontWeight.w500,
                                                            // ),

                                                            style: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark
                                                                ?
                                                            TextStyle(
                                                              color: Colors
                                                                  .white,
                                                              fontFamily: 'Cairo',
                                                              fontSize: 16,
                                                              fontWeight: FontWeight
                                                                  .w500,)
                                                                : TextStyle(
                                                              color: Colors
                                                                  .black,
                                                              fontFamily: 'Cairo',
                                                              fontSize: 16,
                                                              fontWeight: FontWeight
                                                                  .w500,),

                                                          ),
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                              top: 0,
                                                              left: 20,
                                                              right: 20,
                                                              bottom: 10),
                                                          child: Text(post.link
                                                              .toString(),
                                                            textAlign: TextAlign
                                                                .left,
                                                            maxLines: 1,
                                                            overflow: TextOverflow
                                                                .ellipsis,
                                                            // style: TextStyle(
                                                            //   color: Colors.grey[700],
                                                            //   fontFamily: 'Cairo',
                                                            //   fontSize: 14,
                                                            //   fontWeight: FontWeight.w400,
                                                            // )

                                                            style: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark
                                                                ?
                                                            TextStyle(
                                                              color: Colors
                                                                  .white,
                                                              fontFamily: 'Cairo',
                                                              fontSize: 14,
                                                              fontWeight: FontWeight
                                                                  .w400,)
                                                                : TextStyle(
                                                              color: Colors
                                                                  .grey[700],
                                                              fontFamily: 'Cairo',
                                                              fontSize: 14,
                                                              fontWeight: FontWeight
                                                                  .w400,),

                                                          ),
                                                        ),
                                                      ]
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                          : SizedBox()
                                          : SizedBox() : SizedBox(),
                                      // controller.urlOrNot(post.body.toString())
                                      //     ? ScrapCard(controller)
                                      //     // child: Expanded(child: urlFetch(controller)),
                                      //     : SizedBox()
                                      // SizedBox(),
                                      //  post.type=='thread'?
                                      //      Container():
                                     /* post.pollQuestionOne != null
                                          ? Polls(
                                          post: post, controller: controller)
                                          : SizedBox(),*/

                                      /// post images
                                      post.postType == 'image' &&
                                          post.postFiles != null && post.postFiles.length > 0
                                          ? ClipRRect(
                                        borderRadius: BorderRadius.circular(15),
                                        child: Align(
                                          alignment: Alignment.centerLeft,
                                          child: InkWell(
                                            onTap: () {
                                              controller.mapToList(post);
                                              showDialog(

                                                // useSafeArea: false,
                                                // barrierDismissible: false,
                                                context: context,
                                                builder: (
                                                    BuildContext context) {
                                                  return Shortcuts(
                                                    shortcuts: {
                                                      LogicalKeySet(
                                                          LogicalKeyboardKey
                                                              .escape): EscIntent()
                                                    },
                                                    child: NewsFeedCarousel(
                                                      imagesListForCarousel: controller
                                                          .imagesListForCarousel,
                                                      mediaIndex: 0,
                                                      controller: controller,
                                                      post: post,
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                            child: kIsWeb
                                                ? Stack(
                                              children: [
                                                ClipRRect(
                                                    borderRadius: BorderRadius
                                                        .circular(15),
                                                    child: ConstrainedBox(
                                                      constraints: BoxConstraints(
                                                        maxWidth: Get.width,
                                                        maxHeight: 650,
                                                        minHeight: 284,
                                                        minWidth: 384,
                                                      ),
                                                      child: Image.network(
                                                        post
                                                            .postFiles[0]['file_path'],
                                                        // height: kIsWeb ? 480 : 240,
                                                        fit: BoxFit.cover,
                                                        // width: Get.width,
                                                        errorBuilder: (
                                                            BuildContext context,
                                                            Object exception,
                                                            StackTrace stackTrace) {
                                                          return Icon(
                                                              Icons.error,
                                                              size: 40);
                                                        },
                                                      ),
                                                    )

                                                ),
                                                post
                                                    .postFiles[0]["description"] !=
                                                    null ?
                                                Positioned(
                                                  left: 10,
                                                  bottom: 10,
                                                  child: Container(
                                                    height: 20,
                                                    width: 30,
                                                    color: Colors.black,
                                                    child: PopupMenuButton(
                                                        tooltip: "",
                                                        offset: const Offset(0,
                                                            -128),
                                                        position: PopupMenuPosition
                                                            .over,
                                                        padding: EdgeInsets
                                                            .zero,
                                                        icon: Text(
                                                          Strings.alt,
                                                          style: Styles
                                                              .baseTextTheme
                                                              .headline1
                                                              .copyWith(
                                                            fontSize: kIsWeb
                                                                ? 12
                                                                : 12,
                                                            color: Colors.white,
                                                          ),
                                                        ),
                                                        splashRadius: 0.3,
                                                        shape: RoundedRectangleBorder(
                                                          borderRadius: BorderRadius
                                                              .circular(10),
                                                        ),
                                                        // Callback that sets the selected popup menu item.
                                                        onSelected: (
                                                            value) async {},
                                                        itemBuilder: (
                                                            BuildContext context) =>
                                                        [
                                                          PopupMenuItem(
                                                            padding: EdgeInsets
                                                                .all(0),
                                                            value: 1,
                                                            child: GetBuilder<
                                                                NewsfeedController>(
                                                                builder: (
                                                                    controller) {
                                                                  return Padding(
                                                                    padding: const EdgeInsets
                                                                        .all(
                                                                        8.0),
                                                                    child: Column(
                                                                      crossAxisAlignment: CrossAxisAlignment
                                                                          .start,
                                                                      children: [
                                                                        Text(
                                                                          Strings
                                                                              .ImageDescription,
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline1
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: kIsWeb
                                                                                ? 20
                                                                                : 15,
                                                                            fontWeight: FontWeight
                                                                                .bold,
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          post
                                                                              .postFiles[0]["description"],
                                                                          style: TextStyle(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          height: 10,
                                                                        ),
                                                                        Row(
                                                                          children: [
                                                                            Expanded(
                                                                              child: ElevatedButton(
                                                                                // key: LoginController.formKey,
                                                                                onPressed: () async {
                                                                                  Navigator
                                                                                      .pop(
                                                                                      context);
                                                                                },
                                                                                child: Text(
                                                                                  Strings
                                                                                      .dismiss,
                                                                                  style: Styles
                                                                                      .baseTextTheme
                                                                                      .headline2
                                                                                      .copyWith(
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .white
                                                                                        : Colors
                                                                                        .black,
                                                                                    fontSize: 14,
                                                                                    fontWeight: FontWeight
                                                                                        .bold,
                                                                                  ),
                                                                                ),
                                                                                style: ElevatedButton
                                                                                    .styleFrom(
                                                                                  shadowColor:
                                                                                  Colors
                                                                                      .transparent,
                                                                                  primary: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .black
                                                                                      : Colors
                                                                                      .white,
                                                                                  padding: EdgeInsets
                                                                                      .symmetric(

                                                                                      vertical: 20,
                                                                                      horizontal: 25),
                                                                                  elevation: 0.0,
                                                                                  shape: StadiumBorder(

                                                                                  ),
                                                                                  side: BorderSide(
                                                                                    width: 1,
                                                                                    color: MyColors
                                                                                        .grey,
                                                                                  ),
                                                                                  // minimumSize: Size(100, 40),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  );
                                                                }),
                                                          ),

                                                        ]
                                                    ),


                                                  ),
                                                ) : SizedBox(),
                                              ],
                                            )
                                                : Stack(
                                                children: [
                                                  ClipRRect(
                                                    borderRadius: BorderRadius
                                                        .circular(15),
                                                    child: ConstrainedBox(
                                                      constraints: BoxConstraints(
                                                        maxHeight: 500,
                                                        maxWidth: Get.width,
                                                        minHeight: 200,
                                                        minWidth: Get.width,
                                                      ),
                                                      child: Image.network(
                                                        post
                                                            .postFiles[0]['file_path'],
                                                        // height: kIsWeb ? 480 : 240,
                                                        fit: BoxFit.cover,
                                                        // width: Get.width,
                                                        errorBuilder: (
                                                            BuildContext context,
                                                            Object exception,
                                                            StackTrace stackTrace) {
                                                          return Icon(
                                                              Icons.error,
                                                              size: 40);
                                                        },
                                                      ),
                                                    ),
                                                  ),
                                                  post
                                                      .postFiles[0]["description"] !=
                                                      null ?
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          Get.bottomSheet(
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .scaffoldBackgroundColor,
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      20)
                                                              ),
                                                              padding: EdgeInsets
                                                                  .only(
                                                                left: 30,
                                                                right: 30,
                                                                top: 20,
                                                              ),
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  SizedBox(
                                                                      height: 2),
                                                                  Text(
                                                                    Strings
                                                                        .ImageDescription,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                      fontSize: 20,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    post
                                                                        .postFiles[0]["description"],
                                                                    style: TextStyle(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: ElevatedButton(
                                                                          // key: LoginController.formKey,
                                                                          onPressed: () async {
                                                                            Navigator
                                                                                .pop(
                                                                                context);
                                                                          },
                                                                          child: Text(
                                                                            Strings
                                                                                .dismiss,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                            shadowColor:
                                                                            Colors
                                                                                .transparent,
                                                                            primary: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .black
                                                                                : Colors
                                                                                .white,
                                                                            padding: EdgeInsets
                                                                                .symmetric(

                                                                                vertical: 10,
                                                                                horizontal: 5),
                                                                            elevation: 0.0,
                                                                            shape: StadiumBorder(

                                                                            ),
                                                                            side: BorderSide(
                                                                              width: 1,
                                                                              color: MyColors
                                                                                  .grey,
                                                                            ),
                                                                            // minimumSize: Size(100, 40),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },

                                                        child: Align(
                                                          alignment: Alignment
                                                              .center,
                                                          child: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                        ),
                                                      ),


                                                    ),
                                                  ) : SizedBox(),
                                                ]
                                            ),


                                          ),
                                        ),
                                      )
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length == 2 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount: post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              onTap: () {
                                                controller.mapToList(post);
                                                showDialog(
                                                  // barrierDismissible: false,
                                                  context: context,
                                                  builder: (
                                                      BuildContext context) {
                                                    return Shortcuts(
                                                      shortcuts: {
                                                        LogicalKeySet(
                                                            LogicalKeyboardKey
                                                                .escape): EscIntent(),
                                                      },
                                                      child: NewsFeedCarousel(
                                                        imagesListForCarousel: controller
                                                            .imagesListForCarousel,
                                                        mediaIndex: index,
                                                        controller: controller,
                                                        post: post,
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    height: kIsWeb ? 480 : 240,
                                                    decoration: BoxDecoration(
                                                        color: Colors
                                                            .transparent,
                                                        borderRadius: BorderRadius
                                                            .all(
                                                            Radius.circular(
                                                                15))),
                                                    child: ClipRRect(
                                                      borderRadius: BorderRadius
                                                          .all(
                                                          Radius.circular(15)),
                                                      child: Image.network(
                                                        post
                                                            .postFiles[index]['file_path'],
                                                        fit: BoxFit.cover,
                                                        height: kIsWeb
                                                            ? 480
                                                            : 240,

                                                      ),
                                                    ),
                                                  ),
                                                  post
                                                      .postFiles[index]["description"] !=
                                                      null ?
                                                  kIsWeb ?
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: PopupMenuButton(
                                                          tooltip: "",
                                                          offset: const Offset(
                                                              0, -128),
                                                          position: PopupMenuPosition
                                                              .over,
                                                          padding: EdgeInsets
                                                              .zero,
                                                          icon: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                          splashRadius: 0.3,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius
                                                                .circular(10),
                                                          ),
                                                          // Callback that sets the selected popup menu item.
                                                          onSelected: (
                                                              value) async {},
                                                          itemBuilder: (
                                                              BuildContext context) =>
                                                          [
                                                            PopupMenuItem(
                                                              padding: EdgeInsets
                                                                  .all(0),
                                                              value: 1,
                                                              child: GetBuilder<
                                                                  NewsfeedController>(
                                                                  builder: (
                                                                      controller) {
                                                                    return Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                      child: Column(
                                                                        crossAxisAlignment: CrossAxisAlignment
                                                                            .start,
                                                                        children: [
                                                                          Text(
                                                                            Strings
                                                                                .ImageDescription,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline1
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: kIsWeb
                                                                                  ? 20
                                                                                  : 15,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            post
                                                                                .postFiles[index]["description"],
                                                                            style: TextStyle(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            height: 10,
                                                                          ),
                                                                          Row(
                                                                            children: [
                                                                              Expanded(
                                                                                child: ElevatedButton(
                                                                                  // key: LoginController.formKey,
                                                                                  onPressed: () async {
                                                                                    Navigator
                                                                                        .pop(
                                                                                        context);
                                                                                  },
                                                                                  child: Text(
                                                                                    Strings
                                                                                        .dismiss,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline2
                                                                                        .copyWith(
                                                                                      color: Theme
                                                                                          .of(
                                                                                          context)
                                                                                          .brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .white
                                                                                          : Colors
                                                                                          .black,
                                                                                      fontSize: 14,
                                                                                      fontWeight: FontWeight
                                                                                          .bold,
                                                                                    ),
                                                                                  ),
                                                                                  style: ElevatedButton
                                                                                      .styleFrom(
                                                                                    shadowColor:
                                                                                    Colors
                                                                                        .transparent,
                                                                                    primary: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .black
                                                                                        : Colors
                                                                                        .white,
                                                                                    padding: EdgeInsets
                                                                                        .symmetric(

                                                                                        vertical: 20,
                                                                                        horizontal: 25),
                                                                                    elevation: 0.0,
                                                                                    shape: StadiumBorder(

                                                                                    ),
                                                                                    side: BorderSide(
                                                                                      width: 1,
                                                                                      color: MyColors
                                                                                          .grey,
                                                                                    ),
                                                                                    // minimumSize: Size(100, 40),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  }),
                                                            ),

                                                          ]
                                                      ),


                                                    ),
                                                  ) :
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          Get.bottomSheet(
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .scaffoldBackgroundColor,
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      20)
                                                              ),
                                                              padding: EdgeInsets
                                                                  .only(
                                                                left: 30,
                                                                right: 30,
                                                                top: 20,
                                                              ),
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  SizedBox(
                                                                      height: 2),
                                                                  Text(
                                                                    Strings
                                                                        .ImageDescription,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                      fontSize: 20,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    post
                                                                        .postFiles[index]["description"],
                                                                    style: TextStyle(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: ElevatedButton(
                                                                          // key: LoginController.formKey,
                                                                          onPressed: () async {
                                                                            Navigator
                                                                                .pop(
                                                                                context);
                                                                          },
                                                                          child: Text(
                                                                            Strings
                                                                                .dismiss,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                            shadowColor:
                                                                            Colors
                                                                                .transparent,
                                                                            primary: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .black
                                                                                : Colors
                                                                                .white,
                                                                            padding: EdgeInsets
                                                                                .symmetric(

                                                                                vertical: 10,
                                                                                horizontal: 5),
                                                                            elevation: 0.0,
                                                                            shape: StadiumBorder(

                                                                            ),
                                                                            side: BorderSide(
                                                                              width: 1,
                                                                              color: MyColors
                                                                                  .grey,
                                                                            ),
                                                                            // minimumSize: Size(100, 40),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },

                                                        child: Align(
                                                          alignment: Alignment
                                                              .center,
                                                          child: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                        ),
                                                      ),


                                                    ),
                                                  ) : SizedBox(),
                                                ],
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(
                                                1, index.isEven ? 1 : 1);
                                          })
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length == 3 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount: post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              onTap: () {
                                                controller.mapToList(post);
                                                showDialog(
                                                  // barrierDismissible: false,
                                                  context: context,
                                                  builder: (
                                                      BuildContext context) {
                                                    return Shortcuts(
                                                      shortcuts: {
                                                        LogicalKeySet(
                                                            LogicalKeyboardKey
                                                                .escape): EscIntent(),
                                                      },
                                                      child: NewsFeedCarousel(
                                                        imagesListForCarousel:
                                                        controller
                                                            .imagesListForCarousel,
                                                        mediaIndex: index,
                                                        controller: controller,
                                                        post: post,
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    height: Get.height,
                                                    width: Get.width,
                                                    decoration: BoxDecoration(
                                                        color: Colors
                                                            .transparent,
                                                        borderRadius: BorderRadius
                                                            .all(
                                                            Radius.circular(
                                                                15))),
                                                    child: ClipRRect(
                                                      borderRadius: BorderRadius
                                                          .all(
                                                          Radius.circular(15)),
                                                      child: Image.network(
                                                        post.postFiles[index]
                                                        ['file_path'],
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                  ),
                                                  post
                                                      .postFiles[index]["description"] !=
                                                      null ?
                                                  kIsWeb ?
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: PopupMenuButton(
                                                          tooltip: "",
                                                          offset: const Offset(
                                                              0, -128),
                                                          position: PopupMenuPosition
                                                              .over,
                                                          padding: EdgeInsets
                                                              .zero,
                                                          icon: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                          splashRadius: 0.3,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius
                                                                .circular(10),
                                                          ),
                                                          // Callback that sets the selected popup menu item.
                                                          onSelected: (
                                                              value) async {},
                                                          itemBuilder: (
                                                              BuildContext context) =>
                                                          [
                                                            PopupMenuItem(
                                                              padding: EdgeInsets
                                                                  .all(0),
                                                              value: 1,
                                                              child: GetBuilder<
                                                                  NewsfeedController>(
                                                                  builder: (
                                                                      controller) {
                                                                    return Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                      child: Column(
                                                                        crossAxisAlignment: CrossAxisAlignment
                                                                            .start,
                                                                        children: [
                                                                          Text(
                                                                            Strings
                                                                                .ImageDescription,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline1
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: kIsWeb
                                                                                  ? 20
                                                                                  : 15,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            post
                                                                                .postFiles[index]["description"],
                                                                            style: TextStyle(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            height: 10,
                                                                          ),
                                                                          Row(
                                                                            children: [
                                                                              Expanded(
                                                                                child: ElevatedButton(
                                                                                  // key: LoginController.formKey,
                                                                                  onPressed: () async {
                                                                                    Navigator
                                                                                        .pop(
                                                                                        context);
                                                                                  },
                                                                                  child: Text(
                                                                                    Strings
                                                                                        .dismiss,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline2
                                                                                        .copyWith(
                                                                                      color: Theme
                                                                                          .of(
                                                                                          context)
                                                                                          .brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .white
                                                                                          : Colors
                                                                                          .black,
                                                                                      fontSize: 14,
                                                                                      fontWeight: FontWeight
                                                                                          .bold,
                                                                                    ),
                                                                                  ),
                                                                                  style: ElevatedButton
                                                                                      .styleFrom(
                                                                                    shadowColor:
                                                                                    Colors
                                                                                        .transparent,
                                                                                    primary: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .black
                                                                                        : Colors
                                                                                        .white,
                                                                                    padding: EdgeInsets
                                                                                        .symmetric(

                                                                                        vertical: 20,
                                                                                        horizontal: 25),
                                                                                    elevation: 0.0,
                                                                                    shape: StadiumBorder(

                                                                                    ),
                                                                                    side: BorderSide(
                                                                                      width: 1,
                                                                                      color: MyColors
                                                                                          .grey,
                                                                                    ),
                                                                                    // minimumSize: Size(100, 40),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  }),
                                                            ),

                                                          ]
                                                      ),


                                                    ),
                                                  ) :
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          Get.bottomSheet(
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .scaffoldBackgroundColor,
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      20)
                                                              ),
                                                              padding: EdgeInsets
                                                                  .only(
                                                                left: 30,
                                                                right: 30,
                                                                top: 20,
                                                              ),
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  SizedBox(
                                                                      height: 2),
                                                                  Text(
                                                                    Strings
                                                                        .ImageDescription,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                      fontSize: 20,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    post
                                                                        .postFiles[index]["description"],
                                                                    style: TextStyle(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: ElevatedButton(
                                                                          // key: LoginController.formKey,
                                                                          onPressed: () async {
                                                                            Navigator
                                                                                .pop(
                                                                                context);
                                                                          },
                                                                          child: Text(
                                                                            Strings
                                                                                .dismiss,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                            shadowColor:
                                                                            Colors
                                                                                .transparent,
                                                                            primary: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .black
                                                                                : Colors
                                                                                .white,
                                                                            padding: EdgeInsets
                                                                                .symmetric(

                                                                                vertical: 10,
                                                                                horizontal: 5),
                                                                            elevation: 0.0,
                                                                            shape: StadiumBorder(

                                                                            ),
                                                                            side: BorderSide(
                                                                              width: 1,
                                                                              color: MyColors
                                                                                  .grey,
                                                                            ),
                                                                            // minimumSize: Size(100, 40),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },

                                                        child: Align(
                                                          alignment: Alignment
                                                              .center,
                                                          child: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                        ),
                                                      ),


                                                    ),
                                                  ) : SizedBox(),
                                                ],
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(
                                                1, index == 0 ? 1 : 0.5);
                                          })
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length == 4 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount: post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return InkWell(
                                              onTap: () {
                                                controller.mapToList(post);
                                                showDialog(
                                                  // barrierDismissible: false,
                                                  context: context,
                                                  builder:
                                                      (BuildContext context) {
                                                    return Shortcuts(
                                                      shortcuts: {
                                                        LogicalKeySet(
                                                            LogicalKeyboardKey
                                                                .escape): EscIntent()
                                                      },
                                                      child: NewsFeedCarousel(
                                                        imagesListForCarousel:
                                                        controller
                                                            .imagesListForCarousel,
                                                        mediaIndex: index,
                                                        controller: controller,
                                                        post: post,
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: Stack(
                                                children: [
                                                  Container(
                                                    height: Get.height,
                                                    width: Get.width,
                                                    decoration: BoxDecoration(
                                                        color: Colors
                                                            .transparent,
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                15))),
                                                    child: ClipRRect(
                                                      borderRadius:
                                                      BorderRadius.all(
                                                          Radius.circular(15)),
                                                      child: Image.network(
                                                        post.postFiles[index]
                                                        ['file_path'],
                                                        fit: BoxFit.cover,
                                                      ),
                                                    ),
                                                  ),
                                                  post
                                                      .postFiles[index]["description"] !=
                                                      null ?
                                                  kIsWeb ?
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: PopupMenuButton(
                                                          tooltip: "",
                                                          offset: const Offset(
                                                              0, -128),
                                                          position: PopupMenuPosition
                                                              .over,
                                                          padding: EdgeInsets
                                                              .zero,
                                                          icon: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                          splashRadius: 0.3,
                                                          shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius
                                                                .circular(10),
                                                          ),
                                                          // Callback that sets the selected popup menu item.
                                                          onSelected: (
                                                              value) async {},
                                                          itemBuilder: (
                                                              BuildContext context) =>
                                                          [
                                                            PopupMenuItem(
                                                              padding: EdgeInsets
                                                                  .all(0),
                                                              value: 1,
                                                              child: GetBuilder<
                                                                  NewsfeedController>(
                                                                  builder: (
                                                                      controller) {
                                                                    return Padding(
                                                                      padding: const EdgeInsets
                                                                          .all(
                                                                          8.0),
                                                                      child: Column(
                                                                        crossAxisAlignment: CrossAxisAlignment
                                                                            .start,
                                                                        children: [
                                                                          Text(
                                                                            Strings
                                                                                .ImageDescription,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline1
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: kIsWeb
                                                                                  ? 20
                                                                                  : 15,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          Text(
                                                                            post
                                                                                .postFiles[index]["description"],
                                                                            style: TextStyle(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                            ),
                                                                          ),
                                                                          SizedBox(
                                                                            height: 10,
                                                                          ),
                                                                          Row(
                                                                            children: [
                                                                              Expanded(
                                                                                child: ElevatedButton(
                                                                                  // key: LoginController.formKey,
                                                                                  onPressed: () async {
                                                                                    Navigator
                                                                                        .pop(
                                                                                        context);
                                                                                  },
                                                                                  child: Text(
                                                                                    Strings
                                                                                        .dismiss,
                                                                                    style: Styles
                                                                                        .baseTextTheme
                                                                                        .headline2
                                                                                        .copyWith(
                                                                                      color: Theme
                                                                                          .of(
                                                                                          context)
                                                                                          .brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .white
                                                                                          : Colors
                                                                                          .black,
                                                                                      fontSize: 14,
                                                                                      fontWeight: FontWeight
                                                                                          .bold,
                                                                                    ),
                                                                                  ),
                                                                                  style: ElevatedButton
                                                                                      .styleFrom(
                                                                                    shadowColor:
                                                                                    Colors
                                                                                        .transparent,
                                                                                    primary: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .black
                                                                                        : Colors
                                                                                        .white,
                                                                                    padding: EdgeInsets
                                                                                        .symmetric(

                                                                                        vertical: 20,
                                                                                        horizontal: 25),
                                                                                    elevation: 0.0,
                                                                                    shape: StadiumBorder(

                                                                                    ),
                                                                                    side: BorderSide(
                                                                                      width: 1,
                                                                                      color: MyColors
                                                                                          .grey,
                                                                                    ),
                                                                                    // minimumSize: Size(100, 40),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    );
                                                                  }),
                                                            ),

                                                          ]
                                                      ),


                                                    ),
                                                  ) :
                                                  Positioned(
                                                    left: 10,
                                                    bottom: 10,
                                                    child: Container(
                                                      height: 20,
                                                      width: 30,
                                                      color: Colors.black,
                                                      child: GestureDetector(
                                                        onTap: () {
                                                          Get.bottomSheet(
                                                            Container(
                                                              decoration: BoxDecoration(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .scaffoldBackgroundColor,
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      20)
                                                              ),
                                                              padding: EdgeInsets
                                                                  .only(
                                                                left: 30,
                                                                right: 30,
                                                                top: 20,
                                                              ),
                                                              child: Column(
                                                                crossAxisAlignment: CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  SizedBox(
                                                                      height: 2),
                                                                  Text(
                                                                    Strings
                                                                        .ImageDescription,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline1
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                      fontSize: 20,
                                                                      fontWeight: FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    post
                                                                        .postFiles[index]["description"],
                                                                    style: TextStyle(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                    ),
                                                                  ),
                                                                  SizedBox(
                                                                    height: 10,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: ElevatedButton(
                                                                          // key: LoginController.formKey,
                                                                          onPressed: () async {
                                                                            Navigator
                                                                                .pop(
                                                                                context);
                                                                          },
                                                                          child: Text(
                                                                            Strings
                                                                                .dismiss,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                            ),
                                                                          ),
                                                                          style: ElevatedButton
                                                                              .styleFrom(
                                                                            shadowColor:
                                                                            Colors
                                                                                .transparent,
                                                                            primary: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .black
                                                                                : Colors
                                                                                .white,
                                                                            padding: EdgeInsets
                                                                                .symmetric(

                                                                                vertical: 10,
                                                                                horizontal: 5),
                                                                            elevation: 0.0,
                                                                            shape: StadiumBorder(

                                                                            ),
                                                                            side: BorderSide(
                                                                              width: 1,
                                                                              color: MyColors
                                                                                  .grey,
                                                                            ),
                                                                            // minimumSize: Size(100, 40),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),

                                                                ],
                                                              ),
                                                            ),
                                                          );
                                                        },

                                                        child: Align(
                                                          alignment: Alignment
                                                              .center,
                                                          child: Text(
                                                            Strings.alt,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline1
                                                                .copyWith(
                                                              fontSize: kIsWeb
                                                                  ? 12
                                                                  : 12,
                                                              color: Colors
                                                                  .white,
                                                            ),
                                                          ),
                                                        ),
                                                      ),


                                                    ),
                                                  ) : SizedBox(),

                                                ],
                                              ),
                                            );
                                          },

                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(
                                                1, index.isEven ? 0.6 : 0.6);
                                          })

                                          : post.postType == 'gallery' &&
                                          post.postFiles.length > 4 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount:
                                          post.postFiles.length >= 5
                                              ? 4
                                              : post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return post.postFiles.length >= 5 &&
                                                index == 3
                                                ? InkWell(
                                              onTap: () {
                                                controller
                                                    .mapToList(post);
                                                showDialog(
                                                  // barrierDismissible: false,5
                                                  context: context,
                                                  builder:
                                                      (BuildContext
                                                  context) {
                                                    return Shortcuts(
                                                      shortcuts: {
                                                        LogicalKeySet(
                                                            LogicalKeyboardKey
                                                                .escape): EscIntent()
                                                      },
                                                      child: NewsFeedCarousel(
                                                        imagesListForCarousel:
                                                        controller
                                                            .imagesListForCarousel,
                                                        mediaIndex:
                                                        index,
                                                        controller:
                                                        controller,
                                                        post: post,
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: Colors
                                                        .transparent,
                                                    borderRadius: BorderRadius
                                                        .all(Radius
                                                        .circular(
                                                        15))),
                                                child: ClipRRect(
                                                  borderRadius:
                                                  BorderRadius
                                                      .all(Radius
                                                      .circular(
                                                      15)),
                                                  child: Stack(
                                                    fit: StackFit
                                                        .expand,
                                                    children: [
                                                      Image.network(
                                                        post.postFiles[
                                                        index]
                                                        [
                                                        'file_path'],
                                                        fit: BoxFit
                                                            .cover,
                                                      ),
                                                      if (post.postFiles
                                                          .length >=
                                                          5)
                                                        Container(
                                                          color: Colors
                                                              .black38,
                                                        ),
                                                      if (post.postFiles
                                                          .length >=
                                                          5)
                                                        Align(
                                                          alignment:
                                                          Alignment
                                                              .center,
                                                          child: Text(
                                                            '+${post.postFiles
                                                                .length - 4}',
                                                            // style: Theme.of(context).textTheme.headline3
                                                            //     .copyWith(color: Colors.white,
                                                            //   fontSize: 24,),

                                                            style: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark
                                                                ?
                                                            TextStyle(
                                                              color: Colors
                                                                  .white,
                                                              fontSize: 24,)
                                                                : TextStyle(
                                                              color: Colors
                                                                  .black,
                                                              fontSize: 24,),

                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            )
                                                : InkWell(
                                              onTap: () {
                                                controller
                                                    .mapToList(post);
                                                showDialog(
                                                  // barrierDismissible: false,6
                                                  context: context,
                                                  builder:
                                                      (BuildContext
                                                  context) {
                                                    return Shortcuts(
                                                      shortcuts: {
                                                        LogicalKeySet(
                                                            LogicalKeyboardKey
                                                                .escape): EscIntent()
                                                      },
                                                      child: NewsFeedCarousel(
                                                        imagesListForCarousel:
                                                        controller
                                                            .imagesListForCarousel,
                                                        mediaIndex:
                                                        index,
                                                        controller:
                                                        controller,
                                                        post: post,
                                                      ),
                                                    );
                                                  },
                                                );
                                              },
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    color: Colors
                                                        .transparent,
                                                    borderRadius: BorderRadius
                                                        .all(Radius
                                                        .circular(
                                                        15))),
                                                child: ClipRRect(
                                                  borderRadius:
                                                  BorderRadius
                                                      .all(Radius
                                                      .circular(
                                                      8)),
                                                  child:
                                                  Image.network(
                                                    post.postFiles[
                                                    index]
                                                    ['file_path'],
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(1,
                                                index.isEven ? 0.6 : 0.6);
                                          })
                                          : post.postType == 'video' &&
                                          post.postFiles.length == 1
                                          ? kIsWeb
                                          ? ChewieVideoPlayer(
                                        post: post,
                                        index: 0,
                                        thumbnailUrl: post
                                            .postFiles[0]
                                        [
                                        'thumbnail_path'] !=
                                            null
                                            ? post.postFiles[0]
                                        ['thumbnail_path']
                                            : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                      )
                                          : GestureDetector(
                                        onTap: () {
                                          controller
                                              .isVideoOnFullScreen =
                                          true;
                                          controller.update();
                                          print('TAP DETECTED');
                                          print('TAP DETECTED');
                                          print('TAP DETECTED');

                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return Material(
                                                  color: Colors
                                                      .black,
                                                  child:
                                                  StatefulBuilder(
                                                    builder: (BuildContext
                                                    context,
                                                        StateSetter
                                                        setState) {
                                                      return Container(
                                                        margin: EdgeInsets
                                                            .zero,
                                                        height:
                                                        screenHeight,
                                                        width:
                                                        screenWidth,
                                                        child:
                                                        Column(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                          children: [
                                                            Align(
                                                              alignment:
                                                              Alignment.topLeft,
                                                              child:
                                                              Container(
                                                                alignment: Alignment
                                                                    .centerLeft,
                                                                height: 50,
                                                                width: double
                                                                    .infinity,
                                                                color: Colors
                                                                    .black87,
                                                                margin: EdgeInsets
                                                                    .symmetric(
                                                                    horizontal: 20),
                                                                child: GestureDetector(
                                                                  onTap: () {
                                                                    controller
                                                                        .isVideoOnFullScreen =
                                                                    true;
                                                                    controller
                                                                        .update();
                                                                    Navigator
                                                                        .of(
                                                                        context)
                                                                        .pop();
                                                                  },
                                                                  child: Icon(
                                                                    Icons
                                                                        .arrow_back,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            Expanded(
                                                              child: ChewieVideoPlayer(
                                                                  thumbnailUrl: post
                                                                      .postFiles[0]['thumbnail_path'] !=
                                                                      null
                                                                      ? post
                                                                      .postFiles[0]['thumbnail_path']
                                                                      : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                                                  isFullScreenOnMobile: true,
                                                                  allowFullScreen: false,
                                                                  borderRadius: 0,
                                                                  // aspectRatio:
                                                                  //     4 / 3,
                                                                  post: post,
                                                                  index: 0),
                                                            ),
                                                            //Reaction Row
                                                            // Container(
                                                            //   width:
                                                            //   double.infinity,
                                                            //   height:
                                                            //   100,
                                                            //   color:
                                                            //   Colors.black,
                                                            //   margin:
                                                            //   EdgeInsets.symmetric(horizontal: 20),
                                                            //   child:
                                                            //   Row(
                                                            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                            //     children: [
                                                            //       Row(
                                                            //         children: [
                                                            //
                                                            //           Obx(() {
                                                            //             return Row(
                                                            //               children: [
                                                            //
                                                            //                 Tooltip(
                                                            //                   message: 'React',
                                                            //                   child: InkWell(
                                                            //                     onLongPress: (){
                                                            //
                                                            //
                                                            //
                                                            //                     },
                                                            //                     onTap: () async {
                                                            //
                                                            //                       if (post.reactionCheck == false) {
                                                            //
                                                            //                         controller.postList.forEach((element) {
                                                            //                           element.reactionCheck.value = false;
                                                            //                         });
                                                            //                         post.reactionCheck.value = true;
                                                            //
                                                            //
                                                            //
                                                            //
                                                            //                         print("post.reactionCheck.value ${post.reactionCheck.value}");
                                                            //                       }
                                                            //                       else if (post.reactionCheck == true) {
                                                            //                         post.reactionCheck.value = false;
                                                            //                         print("post.reactionCheck.value ${post.reactionCheck.value}");
                                                            //                       }
                                                            //
                                                            //
                                                            //                       // post.reactionCheck.value = false;
                                                            //                       // if(post.like.value == true)
                                                            //                       //   {
                                                            //                       //
                                                            //                       //
                                                            //                       //     post.reactionType.value = "like_simple_like";
                                                            //                       //   }
                                                            //                       // else if(post.like.value == false)
                                                            //                       //   {
                                                            //                       //     post.reactionType.value = "dislike_simple_dislike";
                                                            //                       //   }
                                                            //                       //
                                                            //                       // controller.likeUnlike(
                                                            //                       //   post.reactionType.value,
                                                            //                       //   post.postId,
                                                            //                       //   {
                                                            //                       //     'isLikedSocket': post.like.value,
                                                            //                       //     'totalLikes': post.likeCount.value
                                                            //                       //   },
                                                            //                       // );
                                                            //                       //
                                                            //                       // // ignore: unused_local_variable
                                                            //                       //
                                                            //                       // if (post.like.value) {
                                                            //                       //   post.like.value = false;
                                                            //                       //
                                                            //                       //   if (post.likeCount.value > 0) {
                                                            //                       //     // post.likeCount.value--;
                                                            //                       //   } else {
                                                            //                       //     post.likeCount.value = 0;
                                                            //                       //   }
                                                            //                       //
                                                            //                       //   post.likeCount.refresh();
                                                            //                       //   // controller.update();
                                                            //                       //   print(
                                                            //                       //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                                                            //                       // }
                                                            //                       // else {
                                                            //                       //   post.like.value = true;
                                                            //                       //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                                                            //                       //   // post.simpleLikeCount++;
                                                            //                       //   // post.likeCount.value++;
                                                            //                       //   post.likeCount.refresh();
                                                            //                       //   // controller.update();
                                                            //                       // }
                                                            //                       // // ignore: unused_local_variable
                                                            //                       //
                                                            //                       //  var response = await controller.likePost(post.postId,post.reactionType.value);
                                                            //                       //
                                                            //                       // // if (await UtilsMethods.checkInternet()) {
                                                            //                       // //
                                                            //                       // //   //   log('like response>>> $response'); //number of likes
                                                            //                       // //   //   var  postDetails= post;
                                                            //                       // //   //   postDetails.likeCount.value=response;
                                                            //                       // //   // var dbRes = await  DatabaseHelper.instance
                                                            //                       // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                                                            //                       // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                                                            //                       // // }
                                                            //                       // controller.postIndex = index;
                                                            //                       // controller.update();
                                                            //
                                                            //
                                                            //                     },
                                                            //                     child: post.reactionType.value =="love"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/love-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="like_simple_like"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/like-min.png',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value ==null?
                                                            //                     Image.asset(
                                                            //                       'assets/drawer_icons/not_like.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 25,
                                                            //                       height: 25,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="lough"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/laugh-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="smile"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/smile-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="thanks"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/thanks-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="excited"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/excited-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //
                                                            //                     ):
                                                            //                     post.reactionType.value =="cry"?
                                                            //                     Image.asset(
                                                            //                       'assets/reaction_gif/cry-min.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 30,
                                                            //                       height: 30,
                                                            //                     ):
                                                            //                     Image.asset(
                                                            //                       'assets/drawer_icons/not_like.png',
                                                            //                       // : 'assets/reaction_gif/like_gif.gif',
                                                            //                       width: 25,
                                                            //                       height: 25,
                                                            //
                                                            //                     ),
                                                            //
                                                            //                   ),
                                                            //                 ),
                                                            //
                                                            //
                                                            //
                                                            //
                                                            //                 SizedBox(width: 5),
                                                            //                 GestureDetector(
                                                            //                   onTap: () async {
                                                            //
                                                            //
                                                            //                     // print(data);
                                                            //                     if(kIsWeb)
                                                            //                     {
                                                            //                       showDialog(
                                                            //                           context: context,
                                                            //                           builder: (context) {
                                                            //                             return ReactRetweetDialog(
                                                            //                               'People who reacted',
                                                            //                               post: post,
                                                            //
                                                            //                               // reactions: data,
                                                            //                             );
                                                            //                           });
                                                            //
                                                            //                       // List<Reaction1> data =
                                                            //                       await controller.getWhoReacted(post.postId,reactionType: "all",allLikes: 0);
                                                            //                     }
                                                            //                     else{
                                                            //
                                                            //                       Navigator.push(
                                                            //                         context,
                                                            //                         MaterialPageRoute(builder: (context) => ReactRetweetDialog(
                                                            //                           'People who reacted',
                                                            //                           post: post,
                                                            //                           // reactions: data,
                                                            //                         ) ),
                                                            //                       );
                                                            //                       // List<Reaction1> data =
                                                            //
                                                            //                       print(post.postId);
                                                            //                       await controller.getWhoReacted(post.postId,reactionType: "all",allLikes: 0);
                                                            //                     }
                                                            //
                                                            //
                                                            //
                                                            //                   },
                                                            //                   child: Container(
                                                            //                     padding: const EdgeInsets.symmetric(
                                                            //                       horizontal: 5,
                                                            //                       vertical: 1,
                                                            //                     ),
                                                            //                     // decoration: BoxDecoration(
                                                            //                     //   color: Colors.grey[100],
                                                            //                     //   borderRadius: BorderRadius.circular(20),
                                                            //                     // ),
                                                            //                     child: Text(
                                                            //                       "${post.likeCount.value}",
                                                            //                       style: Theme.of(context).brightness == Brightness.dark ?
                                                            //                       TextStyle(color: Colors.black,
                                                            //                           fontSize: 14)
                                                            //                           : TextStyle(color: Colors.black,
                                                            //                         fontSize: 14,),
                                                            //                     ),
                                                            //                   ),
                                                            //                 ),
                                                            //               ],
                                                            //             );
                                                            //           }),
                                                            //
                                                            //           // Tooltip(
                                                            //           //   message: 'Like',
                                                            //           //   child: InkWell(
                                                            //           //       onTap: () async {
                                                            //           //         controller
                                                            //           //             .likeUnlike(
                                                            //           //           post.like
                                                            //           //               .value
                                                            //           //               ? 'unlike'
                                                            //           //               : 'like',
                                                            //           //           post.postId,
                                                            //           //           {
                                                            //           //             'isLikedSocket': post
                                                            //           //                 .like
                                                            //           //                 .value,
                                                            //           //             'totalLikes': post
                                                            //           //                 .likeCount
                                                            //           //                 .value
                                                            //           //           },
                                                            //           //         );
                                                            //           //
                                                            //           //         // ignore: unused_local_variable
                                                            //           //         print(
                                                            //           //             "likeeeeeeeeeeee");
                                                            //           //         var response = await controller.likePost(post.postId,"");
                                                            //           //         if (post.like
                                                            //           //             .value) {
                                                            //           //           post.like
                                                            //           //               .value =
                                                            //           //           false;
                                                            //           //
                                                            //           //           if (post
                                                            //           //               .likeCount
                                                            //           //               .value >
                                                            //           //               0) {
                                                            //           //             // post.likeCount.value--;
                                                            //           //           } else {
                                                            //           //             post
                                                            //           //                 .likeCount
                                                            //           //                 .value =
                                                            //           //             0;
                                                            //           //           }
                                                            //           //
                                                            //           //           post
                                                            //           //               .likeCount
                                                            //           //               .refresh();
                                                            //           //           // controller.update();
                                                            //           //           print(
                                                            //           //               "UPAR WALAAAAAAAAA " +
                                                            //           //                   post
                                                            //           //                       .like
                                                            //           //                       .value
                                                            //           //                       .toString());
                                                            //           //         } else {
                                                            //           //           post.like
                                                            //           //               .value =
                                                            //           //           true;
                                                            //           //           print(
                                                            //           //               "NEECHAY WALAAAAAAAAA " +
                                                            //           //                   post
                                                            //           //                       .like
                                                            //           //                       .value
                                                            //           //                       .toString());
                                                            //           //           // post.simpleLikeCount++;
                                                            //           //           // post.likeCount.value++;
                                                            //           //           post
                                                            //           //               .likeCount
                                                            //           //               .refresh();
                                                            //           //           // controller.update();
                                                            //           //         }
                                                            //           //
                                                            //           //         print(
                                                            //           //             "like called");
                                                            //           //         setState(() {});
                                                            //           //         // ignore: unused_local_variable
                                                            //           //
                                                            //           //         // controller.postIndex = index;
                                                            //           //         // controller.update();
                                                            //           //       },
                                                            //           //       child: Container(
                                                            //           //           width: 20,
                                                            //           //           height: 20,
                                                            //           //           child: Image
                                                            //           //               .asset(
                                                            //           //             !post.like
                                                            //           //                 .value
                                                            //           //                 ? 'assets/drawer_icons/not_like.png'
                                                            //           //                 : 'assets/drawer_icons/like_fill.png',
                                                            //           //             color: Colors
                                                            //           //                 .white,
                                                            //           //           ))
                                                            //           //     // Icon(
                                                            //           //     //     !post.isLiked ? Icons.thumb_up_alt_outlined : Icons.thumb_up),
                                                            //           //   ),
                                                            //           // ),
                                                            //
                                                            //           // SizedBox(width: 5),
                                                            //           // GestureDetector(
                                                            //           //   onTap: () async {
                                                            //           //     // List<Reaction1> data =
                                                            //           //     await controller
                                                            //           //         .getWhoReacted(
                                                            //           //         post.postId);
                                                            //           //     // print(data);
                                                            //           //     showDialog(
                                                            //           //         context: context,
                                                            //           //         builder: (
                                                            //           //             context) {
                                                            //           //           return ReactRetweetDialog(
                                                            //           //             'People who reacted',
                                                            //           //             // reactions: data,
                                                            //           //           );
                                                            //           //         });
                                                            //           //   },
                                                            //           //   child: Container(
                                                            //           //     padding: const EdgeInsets
                                                            //           //         .symmetric(
                                                            //           //       horizontal: 5,
                                                            //           //       vertical: 1,
                                                            //           //     ),
                                                            //           //     // decoration: BoxDecoration(
                                                            //           //     //   color: Colors.grey[100],
                                                            //           //     //   borderRadius: BorderRadius.circular(20),
                                                            //           //     // ),
                                                            //           //     child: Text(
                                                            //           //       "${post
                                                            //           //           .likeCount
                                                            //           //           .value}",
                                                            //           //       style: TextStyle(
                                                            //           //         color: Colors
                                                            //           //             .grey[600],
                                                            //           //         fontSize: 14,
                                                            //           //       ),
                                                            //           //     ),
                                                            //           //   ),
                                                            //           // ),
                                                            //         ],
                                                            //       ),
                                                            //       Row(
                                                            //         mainAxisAlignment: MainAxisAlignment.start,
                                                            //         children: [
                                                            //           Tooltip(
                                                            //             message: 'Reply',
                                                            //             child: InkWell(
                                                            //               onTap: () {
                                                            //                 if (!kIsWeb) {
                                                            //                   Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => CommentsScreen(postId: post.postId)));
                                                            //                   controller.postId = post.postId;
                                                            //
                                                            //                 } else {
                                                            //                   controller.postList.forEach((element) {
                                                            //                     element.isComment.value = false;
                                                            //                   });
                                                            //                   // controller.postIndex = ;
                                                            //                   post.isComment.value = true;
                                                            //                   // controller.getNewsFeed(reload: false);
                                                            //                   // controller.update();
                                                            //                   // controller.isCommentClick = false;
                                                            //                   if (Get.find<BrowseController>().browsePostList.isNotEmpty && Get.find<BrowseController>().browsePostList.length > 0) {
                                                            //                     Get.find<BrowseController>().browsePostList.forEach((element) {
                                                            //                       element.isComment.value = false;
                                                            //                     });
                                                            //                     // controller.postIndex = ;
                                                            //                     post.isComment.value = true;
                                                            //                   }
                                                            //                 }
                                                            //               },
                                                            //               child: Container(
                                                            //                 width: 20,
                                                            //                 height: 20,
                                                            //                 child: new Image.asset(
                                                            //                   'assets/drawer_icons/comments.png',
                                                            //
                                                            //                   // post.isRetweeted
                                                            //                   //     ? Theme.of(context).iconTheme.color
                                                            //                   //     :
                                                            //
                                                            //                   color: Colors.white,
                                                            //                 ),
                                                            //                 // Icon(Icons.comment_outlined,
                                                            //                 //     color: post.isRetweeted
                                                            //                 //         ? Theme.of(context).iconTheme.color
                                                            //                 //         : Colors.grey)
                                                            //                 // Text(
                                                            //                 //   Strings.comments,
                                                            //                 //   style: Theme.of(context).textTheme.bodyText2,
                                                            //               ),
                                                            //             ),
                                                            //           ),
                                                            //           GestureDetector(
                                                            //             onTap: () async {
                                                            //               // List<Retweet> data =
                                                            //               //     await controller.getWhoRetweeted(post.postId);
                                                            //               // print(data);
                                                            //               // showDialog(
                                                            //               //     context: context,
                                                            //               //     builder: (context) {
                                                            //               //       return ReactRetweetDialog(
                                                            //               //         Strings.peopleWhoRetweeted,
                                                            //               //         retweets: data,
                                                            //               //       );
                                                            //               //     });
                                                            //             },
                                                            //             child: Container(
                                                            //               padding: const EdgeInsets.symmetric(
                                                            //                 horizontal: 8,
                                                            //                 vertical: 1,
                                                            //               ),
                                                            //               // decoration: BoxDecoration(
                                                            //               //   color: Colors.grey[100],
                                                            //               //   borderRadius: BorderRadius.circular(20),
                                                            //               // ),
                                                            //               child: Text(
                                                            //                 post.commentCount.value.toString(),
                                                            //                 // style: TextStyle(
                                                            //                 //   color: Colors.grey[600],
                                                            //                 //   fontSize: 14,
                                                            //                 // ),
                                                            //
                                                            //                 style: Theme.of(context).brightness == Brightness.dark ?
                                                            //                 TextStyle(color: Colors.white,
                                                            //                   fontSize: 14)
                                                            //                     : TextStyle(color: Colors.grey[600],
                                                            //                   fontSize: 14),
                                                            //
                                                            //               ),
                                                            //             ),
                                                            //           ),
                                                            //         ],
                                                            //       ),
                                                            //       Row(
                                                            //         mainAxisAlignment: MainAxisAlignment.start,
                                                            //         children: [
                                                            //           post.isRetweeted == null
                                                            //               ? SizedBox()
                                                            //               : Tooltip(
                                                            //             message: Strings.rewerf,
                                                            //             child: InkWell(
                                                            //               onTap: post.rebuzz.value
                                                            //                   ? () async {
                                                            //                 controller.createDeleteBuzz("undo_retweet", post);
                                                            //
                                                            //                 // var response =
                                                            //                 //     await controller.undoRetweet(post.postId);
                                                            //                 // if (response == 'Undo retweeted Successfully')
                                                            //                 post.isRetweeted = false;
                                                            //                 post.rebuzz.value = false;
                                                            //                 // post.rebuzzCount.value--;
                                                            //                 post.rebuzzCount.refresh();
                                                            //                 // ignore: unused_local_variable
                                                            //                 var response = await controller.undoRetweet(post.postId);
                                                            //                 setState(() {});
                                                            //                 // controller.update();
                                                            //               }
                                                            //                   : () async {
                                                            //                 controller.createDeleteBuzz("retweet", post);
                                                            //                 // var response =
                                                            //                 //     await controller.addRetweet(post.postId);
                                                            //                 // if (response == 'Add retweet Successfully')
                                                            //                 post.isRetweeted = true;
                                                            //                 // post.rebuzzCount.value++;
                                                            //                 post.rebuzzCount.refresh();
                                                            //                 post.rebuzz.value = true;
                                                            //                 // ignore: unused_local_variable
                                                            //                 var response = await controller.addRetweet(post.postId);
                                                            //                 setState(() {});
                                                            //                 // controller.update();
                                                            //               },
                                                            //               child: Container(
                                                            //                 width: 20,
                                                            //                 height: 20,
                                                            //                 child: Image.asset(
                                                            //                   'assets/drawer_icons/rebuzz.png',
                                                            //                   color: post.rebuzz.value ? Theme.of(context).iconTheme.color : Colors.white,
                                                            //                 ),
                                                            //               ),
                                                            //               // Icon(Icons.repeat,Ftext
                                                            //               //     color: post.isRetweeted
                                                            //               //         ? Theme.of(context).iconTheme.color
                                                            //               //         : Colors.grey),
                                                            //             ),
                                                            //           ),
                                                            //           // Text(
                                                            //           //   Strings.reBuzz,
                                                            //           //   style: Theme.of(context).textTheme.bodyText2,
                                                            //           // ),
                                                            //           GestureDetector(
                                                            //             onTap: () async {
                                                            //               List<Retweet> data = await controller.getWhoRetweeted(post.postId);
                                                            //               print(data);
                                                            //               showDialog(
                                                            //                   context: context,
                                                            //                   builder: (context) {
                                                            //                     return ReactRetweetDialog(
                                                            //                       Strings.peopleWhoRetweeted,
                                                            //                       retweets: data,
                                                            //                     );
                                                            //                   });
                                                            //             },
                                                            //             child: Container(
                                                            //               padding: const EdgeInsets.symmetric(
                                                            //                 horizontal: 8,
                                                            //                 vertical: 1,
                                                            //               ),
                                                            //               // decoration: BoxDecoration(
                                                            //               //   color: Colors.grey[100],
                                                            //               //   borderRadius: BorderRadius.circular(20),
                                                            //               // ),
                                                            //               child: Text(
                                                            //                 post.rebuzzCount.value.toString(),
                                                            //                 // style: TextStyle(
                                                            //                 //   color: Colors.grey[600],
                                                            //                 //   fontSize: 14,
                                                            //                 // ),
                                                            //
                                                            //                 style: Theme.of(context).brightness == Brightness.dark ?
                                                            //                 TextStyle(color: Colors.white,
                                                            //                     fontSize: 14)
                                                            //                     : TextStyle(color: Colors.grey[600],
                                                            //                     fontSize: 14),
                                                            //
                                                            //               ),
                                                            //             ),
                                                            //           ),
                                                            //         ],
                                                            //       ),
                                                            //     ],
                                                            //   ),
                                                            // ),
                                                          ],
                                                        ),
                                                      );
                                                    },
                                                  ),
                                                );
                                              });
                                        },
                                        child: ChewieVideoPlayer( //2
                                            thumbnailUrl: post
                                                .postFiles[0]['thumbnail_path'] !=
                                                null
                                                ? post
                                                .postFiles[0]['thumbnail_path']
                                                : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                            isFullScreenOnMobile: true,
                                            allowFullScreen: false,
                                            borderRadius: 0,
                                            // aspectRatio:
                                            //     4 / 3,
                                            post: post,
                                            index: 0),
                                      )
                                          : post.postType == 'audio' &&
                                          post.postFiles.length == 1
                                          ? ChewieVideoPlayer(
                                        post: post,
                                        index: 0,
                                        isAudio: true,
                                      )
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length >
                                              1 &&
                                          post.postFiles[0]
                                          [
                                          'file_type'] ==
                                              'audio'
                                          ? Column(
                                        children: [
                                          for (var i = 0;
                                          i <
                                              post.postFiles
                                                  .length;
                                          i++)
                                            Padding(
                                                padding: const EdgeInsets
                                                    .symmetric(
                                                    vertical:
                                                    4.0),
                                                child: ChewieVideoPlayer(
                                                    post:
                                                    post,
                                                    index:
                                                    index)),
                                        ],
                                      )
                                          : post.postType ==
                                          'attachment' &&
                                          post.postFiles
                                              .length ==
                                              1
                                          ? ListTile(
                                        mouseCursor: MouseCursor.defer,
                                        onTap: () {
                                          launch(post
                                              .postFiles[0]
                                          [
                                          'file_path']);
                                        },
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                            BorderRadius
                                                .circular(
                                                10)),
                                        tileColor: Colors
                                            .grey[100],
                                        leading: SizedBox(
                                          height: 28,
                                          width: 28,
                                          child: Image.asset(
                                              'assets/images/document.png'),
                                        ),
                                        title: Text(
                                          "${post
                                              .postFiles[0]['original_name']}",
                                        ),
                                      )
                                          : post.postType ==
                                          'gallery' &&
                                          post.postFiles
                                              .length >
                                              1 &&
                                          post.postFiles[0]
                                          ['file_type'] ==
                                              'attachment'
                                          ? Column(
                                        children: [
                                          for (var i =
                                          0;
                                          i < post.postFiles.length;
                                          i++)
                                            Padding(
                                              padding:
                                              const EdgeInsets.symmetric(
                                                  vertical: 4.0),
                                              child:
                                              ListTile(
                                                mouseCursor: MouseCursor.defer,
                                                onTap:
                                                    () {
                                                  launch(post
                                                      .postFiles[i]['file_path']);
                                                },
                                                shape:
                                                RoundedRectangleBorder(
                                                    borderRadius: BorderRadius
                                                        .circular(10)),
                                                tileColor:
                                                Colors.grey[100],
                                                leading: SizedBox(
                                                    height: 28,
                                                    width: 28,
                                                    child: Image.asset(
                                                        'assets/images/document.png')),
                                                title:
                                                Text(
                                                  "${post
                                                      .postFiles[i]['original_name']}",
                                                ),
                                              ),
                                            ),
                                        ],
                                      )
                                          : Container(),
                                      SizedBox(
                                        height: 8.0,
                                      ),
                                      post.type == 'quote' &&
                                          post.quoteInfo != null
                                          ? InkWell(
                                        onTap: kIsWeb
                                            ? () async {
                                          print("qoute werf click");
                                          /*controller.isPostDetails = true;
                                  controller.isTrendsScreen = false;
                                  controller.isNewsFeedScreen = false;
                                  controller.isBrowseScreen = false;
                                  controller.isNotificationScreen = false;
                                  controller.isChatScreen = false;
                                  controller.isSavedPostScreen = false;
                                 // controller.selectedPost = post.quoteInfo.post;
                                  controller.postId = post.quoteInfo.postId;
                                  controller.threadNumber = null;
                                  SingleTone.instance.post_Id = post.postId;
                                  controller.isPostDetails = true;
                                  controller.isTrendsScreen = false;
                                  controller.isNewsFeedScreen = false;
                                  controller.isBrowseScreen = false;
                                  controller.isNotificationScreen = false;
                                  controller.isProfileScreen = false;
                                  controller.isChatScreen = false;
                                  controller.isSavedPostScreen = false;
                                  if (controller.isSavedPostScreen) {
                                    savedController.update();
                                  }
                                  if (controller.isBrowseScreen) {
                                    browseController.update();
                                  }
                                 // controller.selectedPost2 = await controller.getSingleNewsFeedItem(post.quoteInfo.postId);
                                  controller.update();
                                  controller.postDetail2 = await controller
                                      .getSingleNewsFeedItem(
                                      post.quoteInfo.postId);
                                  controller.update();*/
                                          Get.toNamed(FluroRouters.mainScreen +
                                              "/postDetail/" +
                                              post.quoteInfo.postId.toString());
                                          // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.quoteInfo.postId.toString());

                                          // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.quoteInfo.postId.toString()));

                                        }
                                            : () async {
                                          // controller.postDetail =
                                          //     await controller.getSingleNewsFeedItem(post.postId);
                                          // controller.update();
                                          // Get.to(PostDetail(controller: controller, post: post));
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (
                                                      BuildContext context) =>
                                                      CommentsScreen(
                                                          postId: post
                                                              .quoteInfo
                                                              .postId)));
                                          controller.postId =
                                              post.quoteInfo.postId;
                                          // controller.isPostDetails = true;
                                          // controller.postDetail =
                                          //     await controller.getSingleNewsFeedItem(post.postId);
                                        },
                                        child: Container(
                                          // width: 610,
                                          padding: EdgeInsets.only(
                                            left: 12,
                                            right: 16,
                                            bottom: 8,
                                            top: 2,
                                          ),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(
                                                12),
                                            border: Border.all(
                                              color: Colors.grey[300],
                                            ),
                                          ),
                                          child: Column(
                                            children: [
                                              Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                                crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                                children: [
                                                  Column(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    children: [
                                                      Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        children: [
                                                          //PROFILE IMAGE
                                                          Padding(
                                                            padding:
                                                            const EdgeInsets
                                                                .only(
                                                                top: 10.00),
                                                            child: CircleAvatar(
                                                              backgroundImage: post
                                                                  .quoteInfo
                                                                  .profileImage !=
                                                                  null
                                                                  ? NetworkImage(
                                                                  post
                                                                      .quoteInfo
                                                                      .profileImage)
                                                                  : AssetImage(
                                                                  "assets/images/person_placeholder.png"),
                                                              radius: 22,
                                                            ),
                                                          ),
                                                          SizedBox(width: 15),

                                                          //USERNAME AND POST TIME
                                                          Padding(
                                                            padding:
                                                            const EdgeInsets
                                                                .only(
                                                                top: 6.0),
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              mainAxisSize:
                                                              MainAxisSize.min,
                                                              children: [
                                                                Row(
                                                                  children: [
                                                                    Container(
                                                                      width: post
                                                                          .authorName
                                                                          .length >=
                                                                          15
                                                                          ? kIsWeb
                                                                          ? 145
                                                                          : 100
                                                                          : null,
                                                                      child: Text(
                                                                        post
                                                                            .quoteInfo
                                                                            .authorName,
                                                                        // style: Theme
                                                                        //     .of(
                                                                        //     context)
                                                                        //     .textTheme
                                                                        //     .headline3,
                                                                        style: TextStyle(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                          fontSize: kIsWeb
                                                                              ? 15
                                                                              : 15,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      width: 5,),
                                                                    Container(
                                                                      width: post
                                                                          .username
                                                                          .length >=
                                                                          15
                                                                          ? kIsWeb
                                                                          ? 145
                                                                          : 100
                                                                          : null,
                                                                      child: Text(
                                                                        '@${post
                                                                            .username}',
                                                                        // style: Theme
                                                                        //     .of(context)
                                                                        //     .brightness == Brightness.dark ?
                                                                        // TextStyle(
                                                                        //   color: Colors.white,
                                                                        //   height: 1.2,
                                                                        //   fontSize: 16,
                                                                        //
                                                                        // )
                                                                        //     : TextStyle(
                                                                        //     color: Colors.black,
                                                                        //     height: 1.2,
                                                                        //     fontSize: 16,
                                                                        //
                                                                        // ),
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline2
                                                                            .copyWith(
                                                                          fontSize: kIsWeb
                                                                              ? 15
                                                                              : 15,
                                                                        ),
                                                                        softWrap: false,
                                                                        maxLines: 1,
                                                                        overflow: TextOverflow
                                                                            .ellipsis,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),

                                                                // SizedBox(height: 10),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                  // POPUP MENU BUTTON
                                                ],
                                              ),
                                              SizedBox(height: 2),
                                              post.quoteInfo.body.length > 0
                                                  ? Padding(
                                                padding: MediaQuery
                                                    .of(context)
                                                    .size
                                                    .width >
                                                    720
                                                    ? EdgeInsets.only(left: 58)
                                                    : EdgeInsets.only(left: 58),
                                                child: Align(
                                                    alignment: Alignment
                                                        .topLeft,
                                                    child:
                                                    Text(post.quoteInfo.body)),
                                              )
                                                  : SizedBox(),
                                              post.quoteInfo.postType ==
                                                  'image' &&
                                                  post.quoteInfo.postFiles
                                                      .length > 0
                                                  ? ClipRRect(
                                                borderRadius:
                                                BorderRadius.only(
                                                    bottomLeft: Radius.circular(
                                                        15),
                                                    bottomRight: Radius
                                                        .circular(
                                                        15)),
                                                child: kIsWeb
                                                    ? Stack(
                                                  children: [
                                                    ConstrainedBox(
                                                      constraints: BoxConstraints(
                                                        maxWidth: Get.width,
                                                        maxHeight: 650,
                                                        minHeight: 284,
                                                        minWidth: 384,
                                                      ),
                                                      child: Image.network(
                                                        post.quoteInfo
                                                            .postFiles[0]
                                                        ['file_path'],
                                                        // height: kIsWeb ? 480 : 240,
                                                        fit: BoxFit.cover,
                                                        // width: Get.width,
                                                        errorBuilder: (
                                                            BuildContext context,
                                                            Object exception,
                                                            StackTrace stackTrace) {
                                                          return Icon(
                                                              Icons.error,
                                                              size: 40);
                                                        },
                                                      ),
                                                    ),
                                                    post.quoteInfo
                                                        .postFiles[0]["description"] !=
                                                        null ?
                                                    Positioned(
                                                      left: 10,
                                                      bottom: 10,
                                                      child: Container(
                                                        height: 20,
                                                        width: 30,
                                                        color: Colors.black,
                                                        child: PopupMenuButton(
                                                            offset: const Offset(
                                                                0, -128),
                                                            position: PopupMenuPosition
                                                                .over,
                                                            padding: EdgeInsets
                                                                .zero,
                                                            icon: Text(
                                                              Strings.alt,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline1
                                                                  .copyWith(
                                                                fontSize: kIsWeb
                                                                    ? 12
                                                                    : 12,
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                            ),
                                                            splashRadius: 0.3,
                                                            shape: RoundedRectangleBorder(
                                                              borderRadius: BorderRadius
                                                                  .circular(10),
                                                            ),
                                                            // Callback that sets the selected popup menu item.
                                                            onSelected: (
                                                                value) async {},
                                                            itemBuilder: (
                                                                BuildContext context) =>
                                                            [
                                                              PopupMenuItem(
                                                                padding: EdgeInsets
                                                                    .all(0),
                                                                value: 1,
                                                                child: GetBuilder<
                                                                    NewsfeedController>(
                                                                    builder: (
                                                                        controller) {
                                                                      return Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            8.0),
                                                                        child: Column(
                                                                          crossAxisAlignment: CrossAxisAlignment
                                                                              .start,
                                                                          children: [
                                                                            Text(
                                                                              Strings
                                                                                  .ImageDescription,
                                                                              style: Styles
                                                                                  .baseTextTheme
                                                                                  .headline1
                                                                                  .copyWith(
                                                                                color: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .white
                                                                                    : Colors
                                                                                    .black,
                                                                                fontSize: kIsWeb
                                                                                    ? 20
                                                                                    : 15,
                                                                                fontWeight: FontWeight
                                                                                    .bold,
                                                                              ),
                                                                            ),
                                                                            Text(
                                                                              post
                                                                                  .quoteInfo
                                                                                  .postFiles[0]["description"],
                                                                              style: TextStyle(
                                                                                color: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .white
                                                                                    : Colors
                                                                                    .black,
                                                                              ),
                                                                            ),
                                                                            SizedBox(
                                                                              height: 10,
                                                                            ),
                                                                            Row(
                                                                              children: [
                                                                                Expanded(
                                                                                  child: ElevatedButton(
                                                                                    // key: LoginController.formKey,
                                                                                    onPressed: () async {
                                                                                      Navigator
                                                                                          .pop(
                                                                                          context);
                                                                                    },
                                                                                    child: Text(
                                                                                      Strings
                                                                                          .dismiss,
                                                                                      style: Styles
                                                                                          .baseTextTheme
                                                                                          .headline2
                                                                                          .copyWith(
                                                                                        color: Theme
                                                                                            .of(
                                                                                            context)
                                                                                            .brightness ==
                                                                                            Brightness
                                                                                                .dark
                                                                                            ? Colors
                                                                                            .white
                                                                                            : Colors
                                                                                            .black,
                                                                                        fontSize: 14,
                                                                                        fontWeight: FontWeight
                                                                                            .bold,
                                                                                      ),
                                                                                    ),
                                                                                    style: ElevatedButton
                                                                                        .styleFrom(
                                                                                      shadowColor:
                                                                                      Colors
                                                                                          .transparent,
                                                                                      primary: Theme
                                                                                          .of(
                                                                                          context)
                                                                                          .brightness ==
                                                                                          Brightness
                                                                                              .dark
                                                                                          ? Colors
                                                                                          .black
                                                                                          : Colors
                                                                                          .white,
                                                                                      padding: EdgeInsets
                                                                                          .symmetric(

                                                                                          vertical: 20,
                                                                                          horizontal: 25),
                                                                                      elevation: 0.0,
                                                                                      shape: StadiumBorder(

                                                                                      ),
                                                                                      side: BorderSide(
                                                                                        width: 1,
                                                                                        color: MyColors
                                                                                            .grey,
                                                                                      ),
                                                                                      // minimumSize: Size(100, 40),
                                                                                    ),
                                                                                  ),
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          ],
                                                                        ),
                                                                      );
                                                                    }),
                                                              ),

                                                            ]
                                                        ),


                                                      ),
                                                    ) : SizedBox(),
                                                  ],
                                                )
                                                    : Stack(
                                                  children: [
                                                    ConstrainedBox(
                                                      constraints: BoxConstraints(
                                                        maxHeight: 500,
                                                        maxWidth: Get.width,
                                                        minHeight: 200,
                                                        minWidth: Get.width,
                                                      ),
                                                      child: Image.network(
                                                        post.quoteInfo
                                                            .postFiles[0]
                                                        ['file_path'],
                                                        // height: kIsWeb ? 480 : 240,
                                                        fit: BoxFit.cover,
                                                        // width: Get.width,
                                                        errorBuilder: (
                                                            BuildContext context,
                                                            Object exception,
                                                            StackTrace stackTrace) {
                                                          return Icon(
                                                              Icons.error,
                                                              size: 40);
                                                        },
                                                      ),
                                                    ),
                                                    post.quoteInfo
                                                        .postFiles[0]["description"] !=
                                                        null ?
                                                    Positioned(
                                                      left: 10,
                                                      bottom: 10,
                                                      child: Container(
                                                        height: 20,
                                                        width: 30,
                                                        color: Colors.black,
                                                        child: GestureDetector(
                                                          onTap: () {
                                                            Get.bottomSheet(
                                                              Container(
                                                                decoration: BoxDecoration(
                                                                    color: Theme
                                                                        .of(
                                                                        context)
                                                                        .scaffoldBackgroundColor,
                                                                    borderRadius: BorderRadius
                                                                        .circular(
                                                                        20)
                                                                ),
                                                                padding: EdgeInsets
                                                                    .only(
                                                                  left: 30,
                                                                  right: 30,
                                                                  top: 20,
                                                                ),
                                                                child: Column(
                                                                  crossAxisAlignment: CrossAxisAlignment
                                                                      .start,
                                                                  children: [
                                                                    SizedBox(
                                                                        height: 2),
                                                                    Text(
                                                                      Strings
                                                                          .ImageDescription,
                                                                      style: Styles
                                                                          .baseTextTheme
                                                                          .headline1
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 20,
                                                                        fontWeight: FontWeight
                                                                            .bold,
                                                                      ),
                                                                    ),
                                                                    Text(
                                                                      post
                                                                          .quoteInfo
                                                                          .postFiles[0]["description"],
                                                                      style: TextStyle(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      height: 10,
                                                                    ),
                                                                    Row(
                                                                      children: [
                                                                        Expanded(
                                                                          child: ElevatedButton(
                                                                            // key: LoginController.formKey,
                                                                            onPressed: () async {
                                                                              Navigator
                                                                                  .pop(
                                                                                  context);
                                                                            },
                                                                            child: Text(
                                                                              Strings
                                                                                  .dismiss,
                                                                              style: Styles
                                                                                  .baseTextTheme
                                                                                  .headline2
                                                                                  .copyWith(
                                                                                color: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .white
                                                                                    : Colors
                                                                                    .black,
                                                                                fontSize: 14,
                                                                                fontWeight: FontWeight
                                                                                    .bold,
                                                                              ),
                                                                            ),
                                                                            style: ElevatedButton
                                                                                .styleFrom(
                                                                              shadowColor:
                                                                              Colors
                                                                                  .transparent,
                                                                              primary: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .black
                                                                                  : Colors
                                                                                  .white,
                                                                              padding: EdgeInsets
                                                                                  .symmetric(

                                                                                  vertical: 10,
                                                                                  horizontal: 5),
                                                                              elevation: 0.0,
                                                                              shape: StadiumBorder(

                                                                              ),
                                                                              side: BorderSide(
                                                                                width: 1,
                                                                                color: MyColors
                                                                                    .grey,
                                                                              ),
                                                                              // minimumSize: Size(100, 40),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),

                                                                  ],
                                                                ),
                                                              ),
                                                            );
                                                          },

                                                          child: Align(
                                                            alignment: Alignment
                                                                .center,
                                                            child: Text(
                                                              Strings.alt,
                                                              style: Styles
                                                                  .baseTextTheme
                                                                  .headline1
                                                                  .copyWith(
                                                                fontSize: kIsWeb
                                                                    ? 12
                                                                    : 12,
                                                                color: Colors
                                                                    .white,
                                                              ),
                                                            ),
                                                          ),
                                                        ),


                                                      ),
                                                    ) : SizedBox(),
                                                  ],
                                                ),
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 2 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'image'
                                                  ? StaggeredGridView
                                                  .countBuilder(
                                                  crossAxisCount: 2,
                                                  crossAxisSpacing: 3,
                                                  mainAxisSpacing: 3,
                                                  shrinkWrap: true,
                                                  physics: ScrollPhysics(),
                                                  itemCount: post.quoteInfo
                                                      .postFiles.length,
                                                  itemBuilder: (context,
                                                      index) {
                                                    return Stack(
                                                      children: [
                                                        Container(


                                                          height: 480,
                                                          decoration: BoxDecoration(
                                                            color:
                                                            Colors.transparent,
                                                            borderRadius:
                                                            BorderRadius.only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                    15),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                    15)),),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                            BorderRadius.only(
                                                                bottomLeft: Radius
                                                                    .circular(
                                                                    15),
                                                                bottomRight: Radius
                                                                    .circular(
                                                                    15)),
                                                            child: Image
                                                                .network(
                                                              post.quoteInfo
                                                                  .postFiles[
                                                              index]['file_path'],
                                                              fit: BoxFit.cover,
                                                              height: 480,
                                                            ),
                                                          ),
                                                        ),
                                                        post.quoteInfo
                                                            .postFiles[index]["description"] !=
                                                            null ?
                                                        kIsWeb ?
                                                        Positioned(
                                                          left: 10,
                                                          bottom: 10,
                                                          child: Container(
                                                            height: 20,
                                                            width: 30,
                                                            color: Colors.black,
                                                            child: PopupMenuButton(
                                                                offset: const Offset(
                                                                    0, -128),
                                                                position: PopupMenuPosition
                                                                    .over,
                                                                padding: EdgeInsets
                                                                    .zero,
                                                                icon: Text(
                                                                  Strings.alt,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline1
                                                                      .copyWith(
                                                                    fontSize: kIsWeb
                                                                        ? 12
                                                                        : 12,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ),
                                                                splashRadius: 0.3,
                                                                shape: RoundedRectangleBorder(
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      10),
                                                                ),
                                                                // Callback that sets the selected popup menu item.
                                                                onSelected: (
                                                                    value) async {},
                                                                itemBuilder: (
                                                                    BuildContext context) =>
                                                                [
                                                                  PopupMenuItem(
                                                                    padding: EdgeInsets
                                                                        .all(0),
                                                                    value: 1,
                                                                    child: GetBuilder<
                                                                        NewsfeedController>(
                                                                        builder: (
                                                                            controller) {
                                                                          return Padding(
                                                                            padding: const EdgeInsets
                                                                                .all(
                                                                                8.0),
                                                                            child: Column(
                                                                              crossAxisAlignment: CrossAxisAlignment
                                                                                  .start,
                                                                              children: [
                                                                                Text(
                                                                                  Strings
                                                                                      .ImageDescription,
                                                                                  style: Styles
                                                                                      .baseTextTheme
                                                                                      .headline1
                                                                                      .copyWith(
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .white
                                                                                        : Colors
                                                                                        .black,
                                                                                    fontSize: kIsWeb
                                                                                        ? 20
                                                                                        : 15,
                                                                                    fontWeight: FontWeight
                                                                                        .bold,
                                                                                  ),
                                                                                ),
                                                                                Text(
                                                                                  post
                                                                                      .quoteInfo
                                                                                      .postFiles[index]["description"],
                                                                                  style: TextStyle(
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .white
                                                                                        : Colors
                                                                                        .black,
                                                                                  ),
                                                                                ),
                                                                                SizedBox(
                                                                                  height: 10,
                                                                                ),
                                                                                Row(
                                                                                  children: [
                                                                                    Expanded(
                                                                                      child: ElevatedButton(
                                                                                        // key: LoginController.formKey,
                                                                                        onPressed: () async {
                                                                                          Navigator
                                                                                              .pop(
                                                                                              context);
                                                                                        },
                                                                                        child: Text(
                                                                                          Strings
                                                                                              .dismiss,
                                                                                          style: Styles
                                                                                              .baseTextTheme
                                                                                              .headline2
                                                                                              .copyWith(
                                                                                            color: Theme
                                                                                                .of(
                                                                                                context)
                                                                                                .brightness ==
                                                                                                Brightness
                                                                                                    .dark
                                                                                                ? Colors
                                                                                                .white
                                                                                                : Colors
                                                                                                .black,
                                                                                            fontSize: 14,
                                                                                            fontWeight: FontWeight
                                                                                                .bold,
                                                                                          ),
                                                                                        ),
                                                                                        style: ElevatedButton
                                                                                            .styleFrom(
                                                                                          shadowColor:
                                                                                          Colors
                                                                                              .transparent,
                                                                                          primary: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .black
                                                                                              : Colors
                                                                                              .white,
                                                                                          padding: EdgeInsets
                                                                                              .symmetric(

                                                                                              vertical: 20,
                                                                                              horizontal: 25),
                                                                                          elevation: 0.0,
                                                                                          shape: StadiumBorder(

                                                                                          ),
                                                                                          side: BorderSide(
                                                                                            width: 1,
                                                                                            color: MyColors
                                                                                                .grey,
                                                                                          ),
                                                                                          // minimumSize: Size(100, 40),
                                                                                        ),
                                                                                      ),
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ],
                                                                            ),
                                                                          );
                                                                        }),
                                                                  ),

                                                                ]
                                                            ),


                                                          ),
                                                        ) :
                                                        Positioned(
                                                          left: 10,
                                                          bottom: 10,
                                                          child: Container(
                                                            height: 20,
                                                            width: 30,
                                                            color: Colors.black,
                                                            child: GestureDetector(
                                                              onTap: () {
                                                                Get.bottomSheet(
                                                                  Container(
                                                                    decoration: BoxDecoration(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .scaffoldBackgroundColor,
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            20)
                                                                    ),
                                                                    padding: EdgeInsets
                                                                        .only(
                                                                      left: 30,
                                                                      right: 30,
                                                                      top: 20,
                                                                    ),
                                                                    child: Column(
                                                                      crossAxisAlignment: CrossAxisAlignment
                                                                          .start,
                                                                      children: [
                                                                        SizedBox(
                                                                            height: 2),
                                                                        Text(
                                                                          Strings
                                                                              .ImageDescription,
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline1
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 20,
                                                                            fontWeight: FontWeight
                                                                                .bold,
                                                                          ),
                                                                        ),
                                                                        Text(
                                                                          post
                                                                              .quoteInfo
                                                                              .postFiles[index]["description"],
                                                                          style: TextStyle(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          height: 10,
                                                                        ),
                                                                        Row(
                                                                          children: [
                                                                            Expanded(
                                                                              child: ElevatedButton(
                                                                                // key: LoginController.formKey,
                                                                                onPressed: () async {
                                                                                  Navigator
                                                                                      .pop(
                                                                                      context);
                                                                                },
                                                                                child: Text(
                                                                                  Strings
                                                                                      .dismiss,
                                                                                  style: Styles
                                                                                      .baseTextTheme
                                                                                      .headline2
                                                                                      .copyWith(
                                                                                    color: Theme
                                                                                        .of(
                                                                                        context)
                                                                                        .brightness ==
                                                                                        Brightness
                                                                                            .dark
                                                                                        ? Colors
                                                                                        .white
                                                                                        : Colors
                                                                                        .black,
                                                                                    fontSize: 14,
                                                                                    fontWeight: FontWeight
                                                                                        .bold,
                                                                                  ),
                                                                                ),
                                                                                style: ElevatedButton
                                                                                    .styleFrom(
                                                                                  shadowColor:
                                                                                  Colors
                                                                                      .transparent,
                                                                                  primary: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .black
                                                                                      : Colors
                                                                                      .white,
                                                                                  padding: EdgeInsets
                                                                                      .symmetric(

                                                                                      vertical: 10,
                                                                                      horizontal: 5),
                                                                                  elevation: 0.0,
                                                                                  shape: StadiumBorder(

                                                                                  ),
                                                                                  side: BorderSide(
                                                                                    width: 1,
                                                                                    color: MyColors
                                                                                        .grey,
                                                                                  ),
                                                                                  // minimumSize: Size(100, 40),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ],
                                                                        ),

                                                                      ],
                                                                    ),
                                                                  ),
                                                                );
                                                              },

                                                              child: Align(
                                                                alignment: Alignment
                                                                    .center,
                                                                child: Text(
                                                                  Strings.alt,
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline1
                                                                      .copyWith(
                                                                    fontSize: kIsWeb
                                                                        ? 12
                                                                        : 12,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),


                                                          ),
                                                        ) : SizedBox(),

                                                      ],
                                                    );
                                                  },
                                                  staggeredTileBuilder: (
                                                      index) {
                                                    return StaggeredTile.count(
                                                        1,
                                                        index.isEven ? 1 : 1);
                                                  })
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 3 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'image'
                                                  ? StaggeredGridView
                                                  .countBuilder(
                                                crossAxisCount: 2,
                                                crossAxisSpacing: 3,
                                                mainAxisSpacing: 3,
                                                shrinkWrap: true,
                                                physics: ScrollPhysics(),
                                                itemCount: post.quoteInfo
                                                    .postFiles.length,
                                                itemBuilder:
                                                    (context, index) {
                                                  return Stack(
                                                    children: [
                                                      Container(
                                                        height: Get.height,
                                                        width: Get.width,
                                                        decoration: BoxDecoration(
                                                          color: Colors
                                                              .transparent,
                                                          borderRadius:
                                                          BorderRadius.only(
                                                              bottomLeft: Radius
                                                                  .circular(15),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  15)),),
                                                        child: ClipRRect(
                                                          borderRadius:
                                                          BorderRadius.only(
                                                              bottomLeft: Radius
                                                                  .circular(15),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  15)),
                                                          child: Image.network(
                                                            post.quoteInfo
                                                                .postFiles[
                                                            index]
                                                            ['file_path'],
                                                            fit: BoxFit.cover,
                                                          ),
                                                        ),
                                                      ),
                                                      post.quoteInfo
                                                          .postFiles[index]["description"] !=
                                                          null ?
                                                      kIsWeb ?
                                                      Positioned(
                                                        left: 10,
                                                        bottom: 10,
                                                        child: Container(
                                                          height: 20,
                                                          width: 30,
                                                          color: Colors.black,
                                                          child: PopupMenuButton(
                                                              offset: const Offset(
                                                                  0, -128),
                                                              position: PopupMenuPosition
                                                                  .over,
                                                              padding: EdgeInsets
                                                                  .zero,
                                                              icon: Text(
                                                                Strings.alt,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline1
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 12
                                                                      : 12,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                              splashRadius: 0.3,
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius
                                                                    .circular(
                                                                    10),
                                                              ),
                                                              // Callback that sets the selected popup menu item.
                                                              onSelected: (
                                                                  value) async {},
                                                              itemBuilder: (
                                                                  BuildContext context) =>
                                                              [
                                                                PopupMenuItem(
                                                                  padding: EdgeInsets
                                                                      .all(0),
                                                                  value: 1,
                                                                  child: GetBuilder<
                                                                      NewsfeedController>(
                                                                      builder: (
                                                                          controller) {
                                                                        return Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              8.0),
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment
                                                                                .start,
                                                                            children: [
                                                                              Text(
                                                                                Strings
                                                                                    .ImageDescription,
                                                                                style: Styles
                                                                                    .baseTextTheme
                                                                                    .headline1
                                                                                    .copyWith(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                  fontSize: kIsWeb
                                                                                      ? 20
                                                                                      : 15,
                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                ),
                                                                              ),
                                                                              Text(
                                                                                post
                                                                                    .quoteInfo
                                                                                    .postFiles[index]["description"],
                                                                                style: TextStyle(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                ),
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: ElevatedButton(
                                                                                      // key: LoginController.formKey,
                                                                                      onPressed: () async {
                                                                                        Navigator
                                                                                            .pop(
                                                                                            context);
                                                                                      },
                                                                                      child: Text(
                                                                                        Strings
                                                                                            .dismiss,
                                                                                        style: Styles
                                                                                            .baseTextTheme
                                                                                            .headline2
                                                                                            .copyWith(
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                          fontSize: 14,
                                                                                          fontWeight: FontWeight
                                                                                              .bold,
                                                                                        ),
                                                                                      ),
                                                                                      style: ElevatedButton
                                                                                          .styleFrom(
                                                                                        shadowColor:
                                                                                        Colors
                                                                                            .transparent,
                                                                                        primary: Theme
                                                                                            .of(
                                                                                            context)
                                                                                            .brightness ==
                                                                                            Brightness
                                                                                                .dark
                                                                                            ? Colors
                                                                                            .black
                                                                                            : Colors
                                                                                            .white,
                                                                                        padding: EdgeInsets
                                                                                            .symmetric(

                                                                                            vertical: 20,
                                                                                            horizontal: 25),
                                                                                        elevation: 0.0,
                                                                                        shape: StadiumBorder(

                                                                                        ),
                                                                                        side: BorderSide(
                                                                                          width: 1,
                                                                                          color: MyColors
                                                                                              .grey,
                                                                                        ),
                                                                                        // minimumSize: Size(100, 40),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        );
                                                                      }),
                                                                ),

                                                              ]
                                                          ),


                                                        ),
                                                      ) :
                                                      Positioned(
                                                        left: 10,
                                                        bottom: 10,
                                                        child: Container(
                                                          height: 20,
                                                          width: 30,
                                                          color: Colors.black,
                                                          child: GestureDetector(
                                                            onTap: () {
                                                              Get.bottomSheet(
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .scaffoldBackgroundColor,
                                                                      borderRadius: BorderRadius
                                                                          .circular(
                                                                          20)
                                                                  ),
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                    left: 30,
                                                                    right: 30,
                                                                    top: 20,
                                                                  ),
                                                                  child: Column(
                                                                    crossAxisAlignment: CrossAxisAlignment
                                                                        .start,
                                                                    children: [
                                                                      SizedBox(
                                                                          height: 2),
                                                                      Text(
                                                                        Strings
                                                                            .ImageDescription,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline1
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 20,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        post
                                                                            .quoteInfo
                                                                            .postFiles[index]["description"],
                                                                        style: TextStyle(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        height: 10,
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Expanded(
                                                                            child: ElevatedButton(
                                                                              // key: LoginController.formKey,
                                                                              onPressed: () async {
                                                                                Navigator
                                                                                    .pop(
                                                                                    context);
                                                                              },
                                                                              child: Text(
                                                                                Strings
                                                                                    .dismiss,
                                                                                style: Styles
                                                                                    .baseTextTheme
                                                                                    .headline2
                                                                                    .copyWith(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                ),
                                                                              ),
                                                                              style: ElevatedButton
                                                                                  .styleFrom(
                                                                                shadowColor:
                                                                                Colors
                                                                                    .transparent,
                                                                                primary: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .black
                                                                                    : Colors
                                                                                    .white,
                                                                                padding: EdgeInsets
                                                                                    .symmetric(

                                                                                    vertical: 10,
                                                                                    horizontal: 5),
                                                                                elevation: 0.0,
                                                                                shape: StadiumBorder(

                                                                                ),
                                                                                side: BorderSide(
                                                                                  width: 1,
                                                                                  color: MyColors
                                                                                      .grey,
                                                                                ),
                                                                                // minimumSize: Size(100, 40),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),

                                                                    ],
                                                                  ),
                                                                ),
                                                              );
                                                            },

                                                            child: Align(
                                                              alignment: Alignment
                                                                  .center,
                                                              child: Text(
                                                                Strings.alt,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline1
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 12
                                                                      : 12,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ),
                                                          ),


                                                        ),
                                                      ) : SizedBox(),
                                                    ],
                                                  );
                                                },
                                                staggeredTileBuilder:
                                                    (index) {
                                                  return StaggeredTile
                                                      .count(
                                                      1,
                                                      index == 0
                                                          ? 1
                                                          : 0.5);
                                                },
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 4 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'image'
                                                  ? StaggeredGridView
                                                  .countBuilder(
                                                crossAxisCount: 2,
                                                crossAxisSpacing: 3,
                                                mainAxisSpacing: 3,
                                                shrinkWrap: true,
                                                physics:
                                                ScrollPhysics(),
                                                itemCount: post
                                                    .quoteInfo
                                                    .postFiles
                                                    .length,
                                                itemBuilder:
                                                    (context, index) {
                                                  return Stack(
                                                    children: [
                                                      Container(
                                                        height: Get.height,
                                                        width: Get.width,
                                                        decoration: BoxDecoration(
                                                          color: Colors
                                                              .transparent,
                                                          borderRadius:
                                                          BorderRadius.only(
                                                              bottomLeft: Radius
                                                                  .circular(15),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  15)),),
                                                        child: ClipRRect(
                                                          borderRadius:
                                                          BorderRadius.only(
                                                              bottomLeft: Radius
                                                                  .circular(15),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  15)),
                                                          child:
                                                          Image.network(
                                                            post.quoteInfo
                                                                .postFiles[
                                                            index][
                                                            'file_path'],
                                                            fit: BoxFit
                                                                .cover,
                                                          ),
                                                        ),
                                                      ),
                                                      post.quoteInfo
                                                          .postFiles[index]["description"] !=
                                                          null ?
                                                      kIsWeb ?
                                                      Positioned(
                                                        left: 10,
                                                        bottom: 10,
                                                        child: Container(
                                                          height: 20,
                                                          width: 30,
                                                          color: Colors.black,
                                                          child: PopupMenuButton(
                                                              offset: const Offset(
                                                                  0, -128),
                                                              position: PopupMenuPosition
                                                                  .over,
                                                              padding: EdgeInsets
                                                                  .zero,
                                                              icon: Text(
                                                                Strings.alt,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline1
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 12
                                                                      : 12,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                              splashRadius: 0.3,
                                                              shape: RoundedRectangleBorder(
                                                                borderRadius: BorderRadius
                                                                    .circular(
                                                                    10),
                                                              ),
                                                              // Callback that sets the selected popup menu item.
                                                              onSelected: (
                                                                  value) async {},
                                                              itemBuilder: (
                                                                  BuildContext context) =>
                                                              [
                                                                PopupMenuItem(
                                                                  padding: EdgeInsets
                                                                      .all(0),
                                                                  value: 1,
                                                                  child: GetBuilder<
                                                                      NewsfeedController>(
                                                                      builder: (
                                                                          controller) {
                                                                        return Padding(
                                                                          padding: const EdgeInsets
                                                                              .all(
                                                                              8.0),
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment
                                                                                .start,
                                                                            children: [
                                                                              Text(
                                                                                Strings
                                                                                    .ImageDescription,
                                                                                style: Styles
                                                                                    .baseTextTheme
                                                                                    .headline1
                                                                                    .copyWith(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                  fontSize: kIsWeb
                                                                                      ? 20
                                                                                      : 15,
                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                ),
                                                                              ),
                                                                              Text(
                                                                                post
                                                                                    .quoteInfo
                                                                                    .postFiles[index]["description"],
                                                                                style: TextStyle(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                ),
                                                                              ),
                                                                              SizedBox(
                                                                                height: 10,
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  Expanded(
                                                                                    child: ElevatedButton(
                                                                                      // key: LoginController.formKey,
                                                                                      onPressed: () async {
                                                                                        Navigator
                                                                                            .pop(
                                                                                            context);
                                                                                      },
                                                                                      child: Text(
                                                                                        Strings
                                                                                            .dismiss,
                                                                                        style: Styles
                                                                                            .baseTextTheme
                                                                                            .headline2
                                                                                            .copyWith(
                                                                                          color: Theme
                                                                                              .of(
                                                                                              context)
                                                                                              .brightness ==
                                                                                              Brightness
                                                                                                  .dark
                                                                                              ? Colors
                                                                                              .white
                                                                                              : Colors
                                                                                              .black,
                                                                                          fontSize: 14,
                                                                                          fontWeight: FontWeight
                                                                                              .bold,
                                                                                        ),
                                                                                      ),
                                                                                      style: ElevatedButton
                                                                                          .styleFrom(
                                                                                        shadowColor:
                                                                                        Colors
                                                                                            .transparent,
                                                                                        primary: Theme
                                                                                            .of(
                                                                                            context)
                                                                                            .brightness ==
                                                                                            Brightness
                                                                                                .dark
                                                                                            ? Colors
                                                                                            .black
                                                                                            : Colors
                                                                                            .white,
                                                                                        padding: EdgeInsets
                                                                                            .symmetric(

                                                                                            vertical: 20,
                                                                                            horizontal: 25),
                                                                                        elevation: 0.0,
                                                                                        shape: StadiumBorder(

                                                                                        ),
                                                                                        side: BorderSide(
                                                                                          width: 1,
                                                                                          color: MyColors
                                                                                              .grey,
                                                                                        ),
                                                                                        // minimumSize: Size(100, 40),
                                                                                      ),
                                                                                    ),
                                                                                  ),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        );
                                                                      }),
                                                                ),

                                                              ]
                                                          ),


                                                        ),
                                                      ) :
                                                      Positioned(
                                                        left: 10,
                                                        bottom: 10,
                                                        child: Container(
                                                          height: 20,
                                                          width: 30,
                                                          color: Colors.black,
                                                          child: GestureDetector(
                                                            onTap: () {
                                                              Get.bottomSheet(
                                                                Container(
                                                                  decoration: BoxDecoration(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .scaffoldBackgroundColor,
                                                                      borderRadius: BorderRadius
                                                                          .circular(
                                                                          20)
                                                                  ),
                                                                  padding: EdgeInsets
                                                                      .only(
                                                                    left: 30,
                                                                    right: 30,
                                                                    top: 20,
                                                                  ),
                                                                  child: Column(
                                                                    crossAxisAlignment: CrossAxisAlignment
                                                                        .start,
                                                                    children: [
                                                                      SizedBox(
                                                                          height: 2),
                                                                      Text(
                                                                        Strings
                                                                            .ImageDescription,
                                                                        style: Styles
                                                                            .baseTextTheme
                                                                            .headline1
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 20,
                                                                          fontWeight: FontWeight
                                                                              .bold,
                                                                        ),
                                                                      ),
                                                                      Text(
                                                                        post
                                                                            .quoteInfo
                                                                            .postFiles[index]["description"],
                                                                        style: TextStyle(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        height: 10,
                                                                      ),
                                                                      Row(
                                                                        children: [
                                                                          Expanded(
                                                                            child: ElevatedButton(
                                                                              // key: LoginController.formKey,
                                                                              onPressed: () async {
                                                                                Navigator
                                                                                    .pop(
                                                                                    context);
                                                                              },
                                                                              child: Text(
                                                                                Strings
                                                                                    .dismiss,
                                                                                style: Styles
                                                                                    .baseTextTheme
                                                                                    .headline2
                                                                                    .copyWith(
                                                                                  color: Theme
                                                                                      .of(
                                                                                      context)
                                                                                      .brightness ==
                                                                                      Brightness
                                                                                          .dark
                                                                                      ? Colors
                                                                                      .white
                                                                                      : Colors
                                                                                      .black,
                                                                                  fontSize: 14,
                                                                                  fontWeight: FontWeight
                                                                                      .bold,
                                                                                ),
                                                                              ),
                                                                              style: ElevatedButton
                                                                                  .styleFrom(
                                                                                shadowColor:
                                                                                Colors
                                                                                    .transparent,
                                                                                primary: Theme
                                                                                    .of(
                                                                                    context)
                                                                                    .brightness ==
                                                                                    Brightness
                                                                                        .dark
                                                                                    ? Colors
                                                                                    .black
                                                                                    : Colors
                                                                                    .white,
                                                                                padding: EdgeInsets
                                                                                    .symmetric(

                                                                                    vertical: 10,
                                                                                    horizontal: 5),
                                                                                elevation: 0.0,
                                                                                shape: StadiumBorder(

                                                                                ),
                                                                                side: BorderSide(
                                                                                  width: 1,
                                                                                  color: MyColors
                                                                                      .grey,
                                                                                ),
                                                                                // minimumSize: Size(100, 40),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),

                                                                    ],
                                                                  ),
                                                                ),
                                                              );
                                                            },

                                                            child: Align(
                                                              alignment: Alignment
                                                                  .center,
                                                              child: Text(
                                                                Strings.alt,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline1
                                                                    .copyWith(
                                                                  fontSize: kIsWeb
                                                                      ? 12
                                                                      : 12,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                              ),
                                                            ),
                                                          ),


                                                        ),
                                                      ) : SizedBox(),
                                                    ],
                                                  );
                                                },
                                                staggeredTileBuilder:
                                                    (index) {
                                                  return StaggeredTile
                                                      .count(
                                                      1,
                                                      index.isEven
                                                          ? 0.6
                                                          : 0.6);
                                                },
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length > 4 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'image'
                                                  ? StaggeredGridView
                                                  .countBuilder(
                                                  crossAxisCount: 2,
                                                  crossAxisSpacing: 3,
                                                  mainAxisSpacing: 3,
                                                  shrinkWrap: true,
                                                  physics: ScrollPhysics(),
                                                  itemCount: post.quoteInfo
                                                      .postFiles
                                                      .length >= 5 ? 4 : post
                                                      .quoteInfo
                                                      .postFiles.length,
                                                  itemBuilder: (context,
                                                      index) {
                                                    return post.quoteInfo
                                                        .postFiles
                                                        .length >=
                                                        5 &&
                                                        index == 3
                                                        ? Container(
                                                      decoration: BoxDecoration(
                                                        color: Colors
                                                            .transparent,
                                                        borderRadius:
                                                        BorderRadius.only(
                                                            bottomLeft: Radius
                                                                .circular(15),
                                                            bottomRight: Radius
                                                                .circular(
                                                                15)),),
                                                      child:
                                                      ClipRRect(
                                                        borderRadius:
                                                        BorderRadius.only(
                                                          bottomLeft: Radius
                                                              .circular(15),
                                                          bottomRight: Radius
                                                              .circular(15),),
                                                        child: Image
                                                            .network(
                                                          post.quoteInfo
                                                              .postFiles[index]
                                                          [
                                                          'file_path'],
                                                          fit: BoxFit
                                                              .cover,
                                                        ),
                                                      ),
                                                    )
                                                        : Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors
                                                              .transparent,
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  15))),
                                                      child:
                                                      ClipRRect(
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                15)),
                                                        child: Image
                                                            .network(
                                                          post.quoteInfo
                                                              .postFiles[index]
                                                          [
                                                          'file_path'],
                                                          fit: BoxFit
                                                              .cover,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                  staggeredTileBuilder: (
                                                      index) {
                                                    return StaggeredTile
                                                        .count(
                                                        1,
                                                        index.isEven
                                                            ? 0.6
                                                            : 0.6);
                                                  })


                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length > 4 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'image'
                                                  ? StaggeredGridView
                                                  .countBuilder(
                                                  crossAxisCount: 2,
                                                  crossAxisSpacing: 3,
                                                  mainAxisSpacing: 3,
                                                  shrinkWrap: true,
                                                  physics: ScrollPhysics(),
                                                  itemCount: post.quoteInfo
                                                      .postFiles.length >= 5
                                                      ? 4
                                                      : post.quoteInfo.postFiles
                                                      .length,
                                                  itemBuilder: (context,
                                                      index) {
                                                    return post.quoteInfo
                                                        .postFiles
                                                        .length >=
                                                        5 &&
                                                        index == 3
                                                        ? Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors
                                                              .transparent,
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  15))),
                                                      child:
                                                      ClipRRect(
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                15)),
                                                        child: Image
                                                            .network(
                                                          post.quoteInfo
                                                              .postFiles[index]
                                                          [
                                                          'file_path'],
                                                          fit: BoxFit
                                                              .cover,
                                                        ),
                                                      ),
                                                    )
                                                        : Container(
                                                      decoration: BoxDecoration(
                                                          color: Colors
                                                              .transparent,
                                                          borderRadius:
                                                          BorderRadius.all(
                                                              Radius.circular(
                                                                  15))),
                                                      child:
                                                      ClipRRect(
                                                        borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(8)),
                                                        child: Image
                                                            .network(
                                                          post.quoteInfo
                                                              .postFiles[index]
                                                          [
                                                          'file_path'],
                                                          fit: BoxFit
                                                              .cover,
                                                        ),
                                                      ),
                                                    );
                                                  },
                                                  staggeredTileBuilder: (
                                                      index) {
                                                    return StaggeredTile
                                                        .count(
                                                        1,
                                                        index.isEven
                                                            ? 0.6
                                                            : 0.6);
                                                  })
                                                  : post.quoteInfo.postType ==
                                                  'video' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 1
                                                  ? ChewieVideoPlayer(
                                                quoteWerf: post
                                                    .quoteInfo,
                                                isQuoteWerfPlayer:
                                                true,
                                                index: 0,
                                                thumbnailUrl: post.quoteInfo
                                                    .postFiles[0]
                                                [
                                                'thumbnail_path'] !=
                                                    null
                                                    ? post.quoteInfo
                                                    .postFiles[0]
                                                [
                                                'thumbnail_path']
                                                    : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'audio' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 1
                                                  ? ChewieVideoPlayer(
                                                quoteWerf: post
                                                    .quoteInfo,
                                                index: 0,
                                                isAudio:
                                                true,
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length > 1 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'audio'
                                                  ? Column(
                                                children: [
                                                  for (var i = 0;
                                                  i < post.quoteInfo.postFiles
                                                      .length;
                                                  i++)
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 4.0),
                                                      child: ChewieVideoPlayer(
                                                        quoteWerf: post
                                                            .quoteInfo,
                                                        index: i,
                                                      ),
                                                    ),
                                                ],
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'attachment' &&
                                                  post.quoteInfo.postFiles
                                                      .length == 1
                                                  ? ListTile(
                                                mouseCursor: MouseCursor.defer,
                                                onTap:
                                                    () {
                                                  launch(post.quoteInfo
                                                      .postFiles[0]['file_path']);
                                                },
                                                shape:
                                                RoundedRectangleBorder(
                                                    borderRadius: BorderRadius
                                                        .circular(10)),
                                                tileColor:
                                                Colors.grey[100],
                                                leading:
                                                SizedBox(
                                                  height: 28,
                                                  width: 28,
                                                  child: Image.asset(
                                                      'assets/images/document.png'),
                                                ),
                                                title:
                                                Text(
                                                  "${post.quoteInfo
                                                      .postFiles[0]['original_name']}",
                                                ),
                                              )
                                                  : post.quoteInfo.postType ==
                                                  'gallery' &&
                                                  post.quoteInfo.postFiles
                                                      .length > 1 &&
                                                  post.quoteInfo
                                                      .postFiles[0]['file_type'] ==
                                                      'attachment'
                                                  ? Column(
                                                children: [
                                                  for (var i = 0; i < post
                                                      .quoteInfo.postFiles
                                                      .length; i++)
                                                    Padding(
                                                      padding: const EdgeInsets
                                                          .symmetric(
                                                          vertical: 4.0),
                                                      child: ListTile(
                                                        mouseCursor: MouseCursor
                                                            .defer,
                                                        onTap: () {
                                                          launch(post.quoteInfo
                                                              .postFiles[i]['file_path']);
                                                        },
                                                        shape: RoundedRectangleBorder(
                                                            borderRadius: BorderRadius
                                                                .circular(10)),
                                                        tileColor: Colors
                                                            .grey[100],
                                                        leading: SizedBox(
                                                            height: 28,
                                                            width: 28,
                                                            child: Image.asset(
                                                                'assets/images/document.png')),
                                                        title: Text(
                                                          "${post.quoteInfo
                                                              .postFiles[i]['original_name']}",
                                                        ),
                                                      ),
                                                    ),
                                                ],
                                              )
                                                  : Container(),
                                            ],
                                          ),
                                        ),
                                      )
                                          : SizedBox(),
                                      // SizedBox(
                                      //   height: 8.0,
                                      // ),
                                      ///mentionUserList
                                      post.postFiles != null && post.postFiles.length > 0 ?
                                      post.postFiles[0]['file_type'] == "image"
                                          ?
                                      post.postFiles[0]['mention_users'] != null
                                          ? InkWell(onTap: () {
                                        // controller.tagList.clear();
                                        controller.showTagUserDialog(
                                            context, Get.height, Get.width,
                                            post
                                                .postFiles[0]['mention_users'], () {


                                        });
                                      }, child: Row(
                                        children: [
                                          Icon(
                                            Icons.person, size: 15,
                                            color: Colors.blue,),
                                          Text(
                                            post.postFiles[0]['mention_users']
                                                .isNotEmpty ? "${post
                                                .postFiles[0]['mention_users']
                                                .length > 1
                                                ? post
                                                .postFiles[0]['mention_users'][0]["firstname"] +
                                                " and ${post
                                                    .postFiles[0]['mention_users']
                                                    .length - 1} Others"
                                                : "${post
                                                .postFiles[0]['mention_users'][0]["firstname"]}" } "
                                                : "Tag People",
                                            // style:TextStyle(color: Colors.blue,fontSize: 12)
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.blue,
                                              fontSize: 12,
                                            ),


                                          ),
                                        ],
                                      ))
                                          : SizedBox()
                                          : SizedBox() : SizedBox(),


                                      buildReactionRow(context, controller),
                                      // SizedBox(height: 5),
                                      // Container(
                                      //   color: Colors.grey,
                                      //   height: 1,
                                      // ),

                                      // SIMPLE COMMENT
                                      kIsWeb
                                          ? buildSimpleCommentField(
                                          controller, context, post)
                                          : SizedBox(),

                                      /// mention tag  widget
                                      !controller.mentionTag
                                          ? SizedBox()
                                          : Align(
                                        alignment: Alignment
                                            .centerLeft,
                                        child: Container(
                                          decoration:
                                          BoxDecoration(
                                            border: Border.all(
                                              color: Colors
                                                  .grey[300],
                                              width: 0.5,
                                            ),
                                            borderRadius:
                                            BorderRadius
                                                .circular(
                                                4),
                                          ),
                                          height: 150,
                                          width: 300,
                                          child: controller.tags.length ==
                                              0
                                              ? SpinKitWave(
                                            size: 30,
                                            color: Color(
                                                0xFFedab30),
                                          )
                                              : ListView
                                              .builder(
                                              itemCount: controller.tags.length,
                                              itemBuilder:
                                                  (context,
                                                  index) {
                                                return ListTile(
                                                  onTap:
                                                      () async {
                                                    //   temp='';
                                                    // print("textvalue " + _controller[controller.currentIndexText].text);
                                                    // print(temp);
                                                    print(controller
                                                        .tags[index]['title']);

                                                    /*     _controller[controller.currentIndexText].text =
                                                      _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                     ' ' +
                                                          widget.tags[index]['title'];*/
                                                    controller.tempValue =
                                                        controller.tempValue
                                                            .substring(0,
                                                            controller.tempValue
                                                                .length -
                                                                controller.temp
                                                                    .length);

                                                    controller.tempValue =
                                                        controller.tempValue +
                                                            ' ' + controller
                                                            .tags[index]['title'];


                                                    controller.commentController
                                                        .text = "";

                                                    controller.commentController
                                                        .text =
                                                        controller.tempValue;
                                                    // tempValue="";
                                                    controller.commentController
                                                        .selection =
                                                        TextSelection
                                                            .fromPosition(
                                                            TextPosition(
                                                                offset: controller
                                                                    .commentController
                                                                    .text
                                                                    .length));
                                                    // widget.focusNode
                                                    //     .requestFocus();
                                                    print(
                                                        'selection tag  ${ controller
                                                            .commentController
                                                            .selection}');
                                                    print(
                                                        'value temp${ controller
                                                            .commentController
                                                            .text}');

                                                    controller.mentionTag =
                                                    false;
                                                    //  widget.tags = [];
                                                    controller.update();
                                                  },
                                                  title:
                                                  Text(
                                                    controller
                                                        .tags[index]['title'],
                                                    style:
                                                    Styles.baseTextTheme
                                                        .headline2.copyWith(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontWeight: FontWeight
                                                          .w700,
                                                      fontSize: 15,
                                                    ),
                                                  ),
                                                );
                                              }),
                                        ),
                                      ),


                                      // SizedBox(
                                      //   height: 4,
                                      // ),
                                      kIsWeb
                                          ? CommentsListView(
                                          post, controller, index: index)
                                          : SizedBox(),
                                    ],
                                  ),
                                ),

                              ],
                            ),
                          )
                        ],
                      ),

                      /// show thread text

                      // index==0?
                      Column(
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(top: 10.00),
                                child: GestureDetector(
                                  onTap: () {},
                                  child: CircleAvatar(
                                    backgroundImage: post.profileImage != null
                                        ? NetworkImage(post.profileImage)
                                        : AssetImage(
                                        "assets/images/person_placeholder.png"),
                                    radius: 22,
                                  ),
                                ),
                              ),

                              SizedBox(width: 50,),

                              MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: GestureDetector(
                                    onTap: kIsWeb
                                        ? () async {
                                      gotoWerfDetailPage(context);
                                      return;
                                      debugPrint("Thread Clicked");
                                      controller.selectedPost = post;
                                      controller.postId = null;
                                      controller.threadNumber = post.thread_no;
                                      controller.isPostDetails = true;
                                      controller.isTrendsScreen = false;
                                      controller.isProfileScreen = false;
                                      controller.isNewsFeedScreen = false;
                                      controller.isBrowseScreen = false;
                                      controller.isNotificationScreen = false;
                                      controller.isChatScreen = false;
                                      controller.isSavedPostScreen = false;
                                      //  controller.selectedPost = post;
                                      if (controller.isSavedPostScreen) {
                                        savedController.update();
                                      }
                                      if (controller.isBrowseScreen) {
                                        browseController.update();
                                      }
                                      controller.commentController.clear();
                                      controller.update();
                                      // controller.postDetail2 =
                                      // await controller.getSingleNewsFeedItemThread(post.thread_no);
                                      controller.update();
                                    }
                                        : () async {
                                      controller.post = post;
                                      // return;
                                      if (SingleTone.instance.commentId == 1) {
                                        if (Get.isRegistered<
                                            MobileCommentsController>()) {
                                          Get.delete<
                                              MobileCommentsController>();
                                        }

                                        Route route = MaterialPageRoute(builder: (context) =>
                                            CommentsScreen(
                                              postId: post.postId, thread_no: null,));
                                        Navigator.pushReplacement(context, route);
                                      }
                                      else {
                                        controller.selectedPost = post;
                                        controller.commentController.clear();
                                        controller.selectedPost = post;
                                        Navigator.push(context, MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                CommentsScreen(
                                                    postId: post.postId, thread_no: null,post:post)));
                                        controller.postId = post.postId;

                                        //    controller.postDetail2 = await controller.getSingleNewsFeedItem(post.postId,isReload: true);
                                        // controller.isPostDetails = true;
                                        // controller.postDetail =
                                        //     await controller.getSingleNewsFeedItem(post.postId);
                                      }
                                      return;
                                      controller.selectedPost = post;

                                      // controller.postDetail =
                                      //     await controller.getSingleNewsFeedItem(post.postId);
                                      // controller.update();
                                      // Get.to(PostDetail(controller: controller, post: post));
                                      controller.selectedPost = post;
                                      controller.threadNumber = post.thread_no;
                                      controller.commentController.clear();
                                      controller.update();
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  CommentsScreen(
                                                    thread_no: post.thread_no,
                                                    postId: null,)));

                                      // controller.isPostDetails = true;
                                      // controller.postDetail =
                                      //     await controller.getSingleNewsFeedItem(post.postId);
                                    },
                                    child: Text(Strings.showThisThread,
                                      style: TextStyle(
                                          color: controller.displayColor,
                                          fontSize: 16
                                      ),
                                    )
                                ),
                              ),
                            ],
                          ),
                          SizedBox(),
                          Divider(
                            color:Colors.black12,
                            thickness: 0.5,
                          )



                        ],
                      )
                      // :
                      //
                      // index>0 && controller.postList[index-1].thread_no!=
                      //      controller.postList[index].thread_no?
                      // Column(
                      //   children: [
                      //     Row(
                      //       children: [
                      //         Padding(
                      //           padding: const EdgeInsets.only(top: 10.00),
                      //           child: GestureDetector(
                      //             onTap: () {
                      //
                      //
                      //             },
                      //             child: CircleAvatar(
                      //               backgroundImage: post.profileImage != null
                      //                   ? NetworkImage(post.profileImage)
                      //                   : AssetImage(
                      //                   "assets/images/person_placeholder.png"),
                      //               radius: 22,
                      //             ),
                      //           ),
                      //         ),
                      //
                      //         SizedBox(width: 50,),
                      //
                      //         GestureDetector(
                      //             onTap: kIsWeb
                      //                 ? () async {
                      //               controller.selectedPost = post;
                      //               controller.threadNumber=post.thread_no;
                      //               controller.postId=null;
                      //               controller.isPostDetails = true;
                      //               controller.isTrendsScreen = false;
                      //               controller.isNewsFeedScreen = false;
                      //               controller.isBrowseScreen = false;
                      //               controller.isNotificationScreen = false;
                      //               controller.isChatScreen = false;
                      //               controller.isSavedPostScreen = false;
                      //               controller.selectedPost = post;
                      //               if (controller.isSavedPostScreen) {
                      //                 savedController.update();
                      //               }
                      //               if (controller.isBrowseScreen) {
                      //                 browseController.update();
                      //               }
                      //
                      //               controller.postDetail2 =
                      //               await controller.getSingleNewsFeedItemThread(post.thread_no);
                      //               controller.update();
                      //             } : () async {
                      //               controller.selectedPost = post  ;
                      //               controller.threadNumber = post.thread_no;
                      //               controller.selectedPost = post ;
                      //               Navigator.push(
                      //                   context,
                      //                   MaterialPageRoute(
                      //                       builder: (BuildContext context) =>
                      //                           CommentsScreen(thread_no: post.thread_no,postId: null,)));
                      //
                      //               // controller.isPostDetails = true;
                      //               // controller.postDetail =
                      //               //     await controller.getSingleNewsFeedItem(post.postId);
                      //             },
                      //             child: Text('Show this thread',
                      //               style: TextStyle(
                      //                   color: Colors.blue,
                      //                   fontSize: 16
                      //               ),
                      //             )
                      //         ),
                      //       ],
                      //     ),
                      //     SizedBox(),
                      //     Divider()
                      //
                      //   ],
                      // )
                      //
                      //   // controller.postList.asMap().containsKey(index-1)?
                      //   // controller.postList[index-1].thread_no!=
                      //   //     controller.postList[index].thread_no?
                      //       :SizedBox()


                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        /// LIKE BUTTON
        Obx(() {
          return
            post.reactionCheck.value == true ?
            Positioned(
              bottom: 40,
              left: 40,
              child: MouseRegion(
                cursor: SystemMouseCursors.click,
                child: Container(
                  height: 45,
                  width: 260,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(50),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      SizedBox(width: 5),
                      GestureDetector(
                        onTap: () async {
                          // print("raection print idhr ");


                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikesxx: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          if (post.reactionType.value == 'like_simple_like') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == "love" ||
                              post.reactionType.value == "cry" ||
                              post.reactionType.value == "excited" || post
                              .reactionType.value == "lough" ||
                              post.reactionType
                                  .value == "smile" ||
                              post.reactionType.value ==
                                  "thanks") {
                            post.reactionType.value = "like_simple_like";
                          }


                          // post.reactionType.value = 'like_simple_like';

                          print("totalLikes: ${post.likeCount.value}");


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            } else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable



                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }


                          post.like.value = false;
                          post.reactionCheck.value = false;
                          await controller.likePost(
                              post.postId, post.reactionType.value, post: post);

                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }
                          controller.postIndex = index;

                          controller.update();
                        },


                        child: Image.asset(
                          AppImages.like,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),

                      GestureDetector(
                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }


                          if (post.reactionType.value == 'love') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == "like_simple_like" ||
                              post.reactionType.value == "cry" ||
                              post.reactionType.value == "excited" || post
                              .reactionType.value == "lough" ||
                              post.reactionType
                                  .value == "smile" ||
                              post.reactionType.value ==
                                  "thanks") {
                            post.reactionType.value = "love";
                          }


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            } else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable



                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;

                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);


                          // print("controller.counter ${controller.counter}");
                          // if(controller.counter == false)
                          // {
                          //   post.reactionType.value = null;
                          //
                          // }

                          // controller.update();


                          controller.postIndex = index;

                          controller.update();
                        },
                        child: Image.asset(
                          AppImages.love,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),

                      GestureDetector(
                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }
                          if (post.reactionType.value == 'lough') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == "like_simple_like" ||
                              post.reactionType.value == "love" ||
                              post.reactionType.value == "cry" || post
                              .reactionType.value == "excited" || post
                              .reactionType.value == "smile" ||
                              post.reactionType
                                  .value == "thanks") {
                            post.reactionType.value = "lough";
                          }

                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            } else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable



                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;

                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);

                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }
                          // controller.update();


                          controller.postIndex = index;

                          controller.update();
                        },


                        child: Image.asset(
                          AppImages.lough,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),

                      GestureDetector(
                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }


                          if (post.reactionType.value == 'excited') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == 'lough' ||
                              post.reactionType.value == "like_simple_like" ||
                              post.reactionType.value == "love" || post
                              .reactionType.value == "cry" || post.reactionType
                              .value == "smile" || post.reactionType.value ==
                              "thanks") {
                            post.reactionType.value = "excited";
                          }


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            } else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // ignore: unused_local_variable



                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }

                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;

                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);

                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }
                          // controller.update();


                          controller.postIndex = index;

                          controller.update();
                        },


                        child: Image.asset(
                          AppImages.excited,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),


                      GestureDetector(

                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }


                          if (post.reactionType.value == 'thanks') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value == 'excited' ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == 'lough' ||
                              post.reactionType.value == "like_simple_like" ||
                              post.reactionType.value == "love" || post
                              .reactionType.value == "cry" || post.reactionType
                              .value == "smile") {
                            post.reactionType.value = "thanks";
                          }


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            } else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;
                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);
                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }

                          controller.postIndex = index;
                          controller.update();
                        },


                        child: Image.asset(
                          AppImages.thanks,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),


                      GestureDetector(
                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }
                          if (post.reactionType.value == 'cry') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value == 'thanks' ||
                              post.reactionType.value == 'excited' ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" ||
                              post.reactionType.value == 'lough' || post
                              .reactionType.value == "like_simple_like" || post
                              .reactionType.value == "love" || post.reactionType
                              .value == "smile") {
                            post.reactionType.value = "cry";
                          }


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            }
                            else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;
                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);
                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }
                          controller.postIndex = index;
                          controller.update();
                        },
                        child: Image.asset(
                          AppImages.cry,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),

                      GestureDetector(
                        onTap: () async {
                          if (post.reactionType.value == null ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike") {
                            post.likeCount.value = post.likeCount.value + 1;


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              post.reactionType.value,
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          if (post.reactionType.value == 'smile') {
                            post.reactionType.value = "dislike_simple_dislike";
                          }
                          else if (post.reactionType.value == null ||
                              post.reactionType.value == 'cry' ||
                              post.reactionType.value == 'thanks' ||
                              post.reactionType.value == 'excited' ||
                              post.reactionType.value ==
                                  "dislike_simple_dislike" || post.reactionType
                              .value == 'lough' || post.reactionType.value ==
                              "like_simple_like" || post.reactionType.value ==
                              "love") {
                            post.reactionType.value = "smile";
                          }


                          if (post.reactionType.value ==
                              "dislike_simple_dislike") {
                            if (post.likeCount.value != 0) {
                              post.likeCount.value--;
                            }
                            else {
                              post.likeCount.value = 0;
                            }


                            print("totalLikes: ${ post.likeCount.value}");
                            controller.likeUnlike(
                              "unlike",
                              post.postId,
                              {
                                'isLikedSocket': true,
                                'totalLikes': post.likeCount.value
                              },
                            );
                          }

                          // if (post.likeCount.value > 0) {
                          //   // post.likeCount.value--;
                          // } else {
                          //   post.likeCount.value = 0;
                          // }
                          // post.likeCount.refresh();
                          post.like.value = false;
                          post.reactionCheck.value = false;
                          await controller.likePost(
                              post.postId, post.reactionType
                              .value, post: post);

                          if (controller.counter == 0) {
                            post.reactionType.value = null;
                          }
                          controller.postIndex = index;
                          controller.update();
                        },

                        child: Image.asset(
                          AppImages.smile,
                          height: 30.0,
                          width: 30.0,
                        ),
                      ),
                      SizedBox(width: 5),


                    ],
                  ),
                ),
              ),

            ) : SizedBox()
          ;
        })
      ],
    );
  }

  gotoWerfDetailPage(BuildContext context) async{

    if (SingleTone.instance.commentId == 1) {
      MobileCommentsController mobileController;
      if (Get.isRegistered<MobileCommentsController>()) {
        mobileController = await Get.find<MobileCommentsController>();
        controller.selectedPost2 = await mobileController.getSingleNewsFeedItem(post.postId, isReload: true);
        controller.getCommentsList = await mobileController.getCommentsPostLists(postId: post.postId);
      } else {
        mobileController = await Get.put(MobileCommentsController());
      }
    }

    controller.post = post;
    controller.postId = post.postId;
    SingleTone.instance.post_Id = post.postId;
    controller.navRoute = "isPostDetail";
    controller.detailPageCounter++;
    controller.threadNumber = null;
    // print("postcard");

    if (controller.navRoute == "isPostDetail") {
      Get.toNamed(FluroRouters.mainScreen + "/postDetail/" + post.postId.toString());
    } else {
      Get.toNamed(FluroRouters.mainScreen + "/postDetail/" + post.postId.toString());
    }
    // Get.toNamed(FluroRouters.mainScreen+"?page=postDetail&postId="+post.postId.toString());

    // Get.toNamed(FluroRouters.generateDetailRouterPath(page: "postDetail",id: post.postId.toString()));

    // print(
    //     'post id:${widget.controller.postId}');
    // print(
    //     'singtone post id:${SingleTone.instance.post_Id}');

    controller.selectedPost2 = await controller.getSingleNewsFeedItem(post.postId, isReload: true).whenComplete(() async {
      // if(widget.translationCheck==true)
      //   {
      //     widget.controller.isShowMoreCheck = true;
      //     widget.controller.update();
      //     var value  = await  widget.controller.newsFeedTranslation( widget.post.postId, widget.controller.languageData.myLang.code);
      //
      //     widget.controller.selectedPost2[0].translationData=value;
      //
      //
      //     widget. controller.selectedPost2[0].translation.value = true;
      //     print("post.translationData ${ widget.controller.selectedPost2[0].translationData.data[0].body}");
      //     widget.  controller.update(
      //         ['translate']);
      //
      //     widget.controller.isShowMoreCheck = false;
      //     widget.controller.update();
      //
      //
      //   }
    });

    if (post.translation.value == true && controller.selectedPost2.isNotEmpty) {
      controller.isShowMoreCheck = true;
      controller.update();
      // var value  = await  widget.controller.newsFeedTranslation( widget.post.postId, widget.controller.languageData.myLang.code);

      // print("post.translationData......... ${widget.controller.selectedPost2.length}");
      // print("post.translationData......... ${widget.post.translationData.data[0].body}");

      controller.selectedPost2[0].translationData = post.translationData;

      controller.selectedPost2[0].translation.value = true;
      // print("post.translationData ${ widget.controller.selectedPost2[0].translationData.data[0].body}");
      controller.update(['translate']);

      controller.isShowMoreCheck = false;
      controller.update();
    }
  }

  // PDF FILE BUILDER METHOD
  // ignore: missing_return
  Text buildPdfFile(int length) {
    print(length);
    for (var i = 0; i <= length; i++) {
      print('ITERATION' + i.toString());
      return Text(post.postFiles[i]['file_path']);
    }
  }

  // REACTION ROW BUILDER METHOD
  dynamic buildReactionRow(BuildContext context,
      NewsfeedController controller) {
    return Obx(() {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              SizedBox(
                width: 20,
                height: 20,
                child: Tooltip(
                  message: Strings.react,
                  child: InkWell(
                    onLongPress: () {},
                    onTap: () async {
                      if (post.reactionCheck == false) {
                        controller.postList.forEach((element) {
                          element.reactionCheck.value = false;
                        });

                        post.reactionCheck.value = true;
                        print("post.reactionCheck.value ${post.reactionCheck
                            .value}");
                      }
                      else if (post.reactionCheck == true) {
                        post.reactionCheck.value = false;
                        print("post.reactionCheck.value ${post.reactionCheck
                            .value}");
                      }


                      // post.reactionCheck.value = false;
                      // if(post.like.value == true)
                      //   {
                      //
                      //
                      //     post.reactionType.value = "like_simple_like";
                      //   }
                      // else if(post.like.value == false)
                      //   {
                      //     post.reactionType.value = "dislike_simple_dislike";
                      //   }
                      //
                      // controller.likeUnlike(
                      //   post.reactionType.value,
                      //   post.postId,
                      //   {
                      //     'isLikedSocket': post.like.value,
                      //     'totalLikes': post.likeCount.value
                      //   },
                      // );
                      //
                      // // ignore: unused_local_variable
                      //
                      // if (post.like.value) {
                      //   post.like.value = false;
                      //
                      //   if (post.likeCount.value > 0) {
                      //     // post.likeCount.value--;
                      //   } else {
                      //     post.likeCount.value = 0;
                      //   }
                      //
                      //   post.likeCount.refresh();
                      //   // controller.update();
                      //   print(
                      //       "UPAR WALAAAAAAAAA " + post.like.value.toString());
                      // }
                      // else {
                      //   post.like.value = true;
                      //   print("NEECHAY WALAAAAAAAAA " + post.like.value.toString());
                      //   // post.simpleLikeCount++;
                      //   // post.likeCount.value++;
                      //   post.likeCount.refresh();
                      //   // controller.update();
                      // }
                      // // ignore: unused_local_variable
                      //
                      //  var response = await controller.likePost(post.postId,post.reactionType.value);
                      //
                      // // if (await UtilsMethods.checkInternet()) {
                      // //
                      // //   //   log('like response>>> $response'); //number of likes
                      // //   //   var  postDetails= post;
                      // //   //   postDetails.likeCount.value=response;
                      // //   // var dbRes = await  DatabaseHelper.instance
                      // //   //       .update(DatabaseHelper.savedPostTable, postDetails.toLocalDBMap(),postDetails.postId,'post_id');
                      // //   // log('${postDetails.postId}  done updating ..... $dbRes');
                      // // }
                      // controller.postIndex = index;
                      // controller.update();


                    },
                    child: post.reactionType.value == "love" ?
                    Image.asset(
                      'assets/reaction_gif/love-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == "like_simple_like" ?
                    Image.asset(
                      'assets/reaction_gif/like-min.png',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == null ?
                    Image.asset(
                      'assets/post_card_icons/like.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 20,
                      height: 20,

                    ) :
                    post.reactionType.value == "lough" ?
                    Image.asset(
                      'assets/reaction_gif/laugh-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == "smile" ?
                    Image.asset(
                      'assets/reaction_gif/smile-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == "thanks" ?
                    Image.asset(
                      'assets/reaction_gif/thanks-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == "excited" ?
                    Image.asset(
                      'assets/reaction_gif/excited-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,

                    ) :
                    post.reactionType.value == "cry" ?
                    Image.asset(
                      'assets/reaction_gif/cry-min.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 30,
                      height: 30,
                    ) :
                    Image.asset(
                      'assets/post_card_icons/like.png',
                      // : 'assets/reaction_gif/like_gif.gif',
                      width: 20,
                      height: 20,

                    )

                  ),
                ),
              ),

              SizedBox(width: 5),
              GestureDetector(
                onTap: () async {
                  if (post.likeCount.value != 0) {
                    if (kIsWeb) {
                      showDialog(
                          context: context,
                          builder: (context) {
                            return ReactRetweetDialog(
                              Strings.peopleWhoReacted,
                              post: post,

                              // reactions: data,
                            );
                          });

                      // List<Reaction1> data =
                      await controller.getWhoReacted(
                          post.postId, reactionType: "all", allLikes: 0);
                    }
                    else {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) =>
                            ReactRetweetDialog(
                              Strings.people,
                              // reactions: data,
                            )),
                      );
                      // List<Reaction1> data =
                      await controller.getWhoReacted(
                          post.postId, reactionType: "all");
                    }
                  }
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 1,
                  ),
                  // decoration: BoxDecoration(
                  //   color: Colors.grey[100],
                  //   borderRadius: BorderRadius.circular(20),
                  // ),
                  child: Text(
                    "${post.likeCount.value}",
                    // style: TextStyle(
                    //   color: Colors.grey[600],
                    //   fontSize: 14,
                    // ),

                    style:TextStyle(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Color(0xFF536471),
                        fontSize: 12,
                        fontWeight: FontWeight.w400
                    ),

                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Tooltip(
                message: Strings.reply,
                child: InkWell(
                  onTap: () {
                    controller.commentController.clear();
                    controller.update();
                    if (!kIsWeb) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  CommentsScreen(postId: post.postId)));
                      controller.postId = post.postId;
                    } else {
                      controller.postList.forEach((element) {
                        element.isComment.value = false;
                      });
                      // controller.postIndex = ;
                      post.isComment.value = true;
                      // controller.getNewsFeed(reload: false);
                      // controller.update();
                      // controller.isCommentClick = false;
                      if (Get
                          .find<BrowseController>()
                          .browsePostList
                          .isNotEmpty &&
                          Get
                              .find<BrowseController>()
                              .browsePostList
                              .length >
                              0) {
                        Get
                            .find<BrowseController>()
                            .browsePostList
                            .forEach((element) {
                          element.isComment.value = false;
                        });
                        // controller.postIndex = ;
                        post.isComment.value = true;
                      }
                    }
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    child: Image.asset(
                      'assets/post_card_icons/comments.png',
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Color(0xFF536471),
                    ),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 1,
                ),
                // decoration: BoxDecoration(
                //   color: Colors.grey[100],
                //   borderRadius: BorderRadius.circular(20),
                // ),
                child: Text(
                  post.commentCount.value.toString(),
                  // style: TextStyle(
                  //   color: Colors.grey[600],
                  //   fontSize: 14,
                  // ),

                  style: TextStyle(
                      color: Theme
                          .of(context)
                          .brightness ==
                          Brightness.dark
                          ? Colors.white
                          : Color(0xFF536471),
                      fontSize: 12,
                      fontWeight: FontWeight.w400
                  ),

                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              post.isRetweeted == null
                  ? SizedBox()
                  : !kIsWeb
                  ? Tooltip(
                message: Strings.rewerf,
                child: GestureDetector(
                  onTap: () {
                    Get.bottomSheet(
                      Container(
                        height: 124,
                        decoration: BoxDecoration(
                          color: Theme
                              .of(context)
                              .scaffoldBackgroundColor,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                          ),
                        ),
                        padding: EdgeInsets.only(
                        //  left: 10,
                          top: 20,
                        ),
                        child: Column(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(height: 2),
                            Align(
                              alignment: Alignment.topLeft,
                              child: GestureDetector(
                                onTap: () async {
                                  if (post.rebuzz.value == false) {
                                    post.rebuzz.value = true;
                                  }
                                  else if (post.rebuzz.value == true) {
                                    post.rebuzz.value = false;
                                  }

                                  if (post.rebuzz.value == false) {
                                    Navigator.pop(context);
                                    controller.createDeleteBuzz(
                                        "undo_retweet", post);

                                    // var response =
                                    //     await controller.undoRetweet(post.postId);
                                    // if (response == 'Undo retweeted Successfully')
                                    post.isRetweeted = false;
                                    post.rebuzz.value = false;
                                    // post.rebuzzCount.value--;
                                    post.rebuzzCount.refresh();
                                    // ignore: unused_local_variable
                                    var response = await controller.undoRetweet(
                                        post.postId, post: post);
                                    controller.update();
                                  }
                                  else if (post.rebuzz.value == true) {
                                    Navigator.pop(context);
                                    print('here');
                                    controller.createDeleteBuzz(
                                        "retweet", post);
                                    // var response =
                                    //     await controller.addRetweet(post.postId);
                                    // if (response == 'Add retweet Successfully')
                                    post.isRetweeted = true;
                                    // post.rebuzzCount.value++;

                                    post.rebuzzCount.refresh();

                                    post.rebuzz.value = true;
                                    // ignore: unused_local_variable
                                    var response =
                                    await controller.addRetweet(
                                        post.postId, post: post);
                                    controller.update();
                                  };
                                },
                                child: Row(
                                  children: [
                                    Container(
                                      width: 20,
                                      height: 20,
                                      child: Image.asset(
                                        'assets/post_card_icons/rewerf.png',
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Color(0xFF536471),
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      Strings.rewerf,
                                      // style: Theme.of(context).textTheme.headline3
                                      //     .copyWith(fontWeight: FontWeight.bold),

                                      style: Theme
                                          .of(context)
                                          .brightness == Brightness.dark ?
                                      TextStyle(color: Colors.white,
                                          fontWeight: FontWeight.bold)
                                          : TextStyle(color: Colors.black,
                                          fontWeight: FontWeight.bold),

                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: 6),
                            GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        QuoteRewerfMobile(
                                          controller,
                                          controller.userProfile.profileImage,
                                          post: post,
                                          werfName: post.authorName,
                                          werfUsername: post.username,
                                        ),
                                  ),
                                );
                              },
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.edit_outlined,
                                      size: 20,
                                      color: Get.isDarkMode?Colors.white:Colors.grey,
                                    ),
                                    SizedBox(width: 10),
                                    Text(
                                      Strings.quoteRewerf,
                                      // style: Theme.of(context).textTheme.headline3
                                      //     .copyWith(fontWeight: FontWeight.bold,),

                                      style: Theme
                                          .of(context)
                                          .brightness == Brightness.dark ?
                                      TextStyle(color: Colors.white,
                                          fontWeight: FontWeight.bold)
                                          : TextStyle(color: Colors.black,
                                          fontWeight: FontWeight.bold),

                                    ),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: 8),
                          ],
                        ),
                      ),
                    );
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    child: Image.asset(
                      'assets/post_card_icons/rewerf.png',
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : Color(0xFF536471),
                    ),
                  ),
                ),
              )
                  : PopupMenuButton(
                tooltip: Strings.rewerf,
                onSelected: (value) async {
                  if (value == 1) {
                    if (post.rebuzz.value == false) {
                      post.rebuzz.value = true;
                    }
                    else if (post.rebuzz.value == true) {
                      post.rebuzz.value = false;
                    }

                    if (post.rebuzz.value) {
                      controller.createDeleteBuzz(
                          "undo_retweet", post);

                      // var response =
                      //     await controller.undoRetweet(post.postId);
                      // if (response == 'Undo retweeted Successfully')
                      post.isRetweeted = false;
                      post.rebuzz.value = false;
                      // post.rebuzzCount.value--;
                      post.rebuzzCount.refresh();
                      // ignore: unused_local_variable
                      var response =
                      await controller.undoRetweet(post.postId);
                      // controller.update();
                    } else {
                      print('here');
                      controller.createDeleteBuzz("retweet", post);
                      // var response =
                      //     await controller.addRetweet(post.postId);
                      // if (response == 'Add retweet Successfully')
                      post.isRetweeted = true;
                      // post.rebuzzCount.value++;
                      post.rebuzzCount.refresh();
                      post.rebuzz.value = true;
                      // ignore: unused_local_variable
                      var response =
                      await controller.addRetweet(post.postId);
                      // controller.update();
                    }
                    ;
                  }
                  if (value == 2) {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(10.0))),
                          insetPadding: EdgeInsets.symmetric(
                              horizontal: 0, vertical: 0),
                          contentPadding:
                          EdgeInsets.only(left: 5),
                          content: QuoteRewerf(
                            _scaffoldKey,
                            controller,
                            controller.userProfile.profileImage,
                            post: post,
                            werfName: post.authorName,
                            werfUsername: post.username,
                          ),
                        );
                      },
                      barrierDismissible: false,
                    );
                  }
                },
                itemBuilder: (context) =>
                [
                  PopupMenuItem(
                    value: 1,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 20,
                          height: 20,
                          child: Image.asset(
                            'assets/post_card_icons/rewerf.png',
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                        const SizedBox(width:10),
                        Text(
                          Strings.rewerf,
                          //  style: TextStyle(color: Colors.black, fontSize: 14),

                          style: Theme
                              .of(context)
                              .brightness == Brightness.dark ?
                          TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700)
                              : TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700),

                        )
                      ],
                      // mouseCursor: MouseCursor.defer,
                      // leading: ,
                      // title: ,
                    ),
                  ),
                  PopupMenuItem(
                    value: 2,
                    child:
                      Row(children: [
                        const Icon(
                            Icons.edit_outlined,
                            size: 20,
                          ),
                        const SizedBox(width:10),
                      Text(
                            Strings.quoteRewerf,
                            //  style: TextStyle(color: Colors.black, fontSize: 14),

                            style: Theme
                                .of(context)
                                .brightness == Brightness.dark ?
                            const TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700)
                                : const TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700),

                          ),
                      ],)
                    // ListTile(
                    //   mouseCursor: MouseCursor.defer,
                    //   leading: Icon(
                    //     Icons.edit_outlined,
                    //     size: 20,
                    //   ),
                    //   title: Text(
                    //     Strings.quoteRewerf,
                    //     //  style: TextStyle(color: Colors.black, fontSize: 14),
                    //
                    //     style: Theme
                    //         .of(context)
                    //         .brightness == Brightness.dark ?
                    //     TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700)
                    //         : TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700),
                    //
                    //   ),
                    // ),
                  ),
                ],
                child: Container(
                  width: 20,
                  height: 20,
                  child: Image.asset(
                    'assets/post_card_icons/rewerf.png',
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark
                        ? Colors.white
                        : Color(0xFF536471),
                  ),
                ),
              ),

              // Text(
              //   Strings.reBuzz,
              //   style: Theme.of(context).textTheme.bodyText2,
              // ),
              GestureDetector(
                onTap: () async {
                  List<Retweet> data =
                  await controller.getWhoRetweeted(post.postId);
                  print(data);
                  showDialog(
                      context: context,
                      builder: (context) {
                        return ReactRetweetDialog(
                          Strings.peopleWhoRetweeted,
                          retweets: data,
                        );
                      });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 1,
                  ),
                  // decoration: BoxDecoration(
                  //   color: Colors.grey[100],
                  //   borderRadius: BorderRadius.circular(20),
                  // ),
                  child: Text(
                    post.rebuzzCount.value.toString(),
                    //  style: TextStyle(color: Colors.grey[600], fontSize: 14,),

                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness ==
                            Brightness.dark
                            ? Colors.white
                            : Color(0xFF536471),
                        fontSize: 12,
                        fontWeight: FontWeight.w400
                    ),

                  ),
                ),
              ),
            ],
          ),
          Tooltip(
            message: Strings.view,
            child: InkWell(
              onTap: () async {
                if (post.userInfo.userId == userData.read("id")) {
                  await controller.getWerfAnalytics(post.postId);

                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        scrollable: true,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                                Radius.circular(10.0))),
                        insetPadding:
                        EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                        contentPadding: EdgeInsets.symmetric(horizontal: 15),
                        content: Container(
                          height: kIsWeb ? 525 : 450,
                          width: kIsWeb ? 500 : Get.width * 0.95,
                          child: SingleChildScrollView(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                ListTile(
                                  leading: GestureDetector(
                                    onTap: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Icon(Icons.close),
                                  ),
                                  title: Text(Strings.werfAnalytics,
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),),
                                ),
                                SizedBox(height: 12),
                                // Werf Section
                                Container(
                                  // height: 160,
                                  padding:
                                  EdgeInsets.only(
                                      left: 20, top: 20, bottom: 10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all(
                                      color: Colors.grey[300],
                                    ),
                                  ),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          controller.userProfile.profileImage ==
                                              null
                                              ? CircleAvatar(
                                              radius: 18,
                                              backgroundImage: AssetImage(
                                                  "assets/images/person_placeholder.png"))
                                              : ClipRRect(
                                            borderRadius:
                                            BorderRadius.circular(25),
                                            child: FadeInImage(
                                              fit: BoxFit.cover,
                                              width: 24,
                                              height: 24,
                                              placeholder: AssetImage(
                                                  'assets/images/person_placeholder.png'),
                                              image: NetworkImage(controller
                                                  .userProfile
                                                  .profileImage !=
                                                  null
                                                  ? controller
                                                  .userProfile.profileImage
                                                  : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                            ),
                                          ),
                                          SizedBox(width: 4),
                                          Text(
                                            controller.userProfile.firstname,
                                            // style: Theme
                                            //     .of(context)
                                            //     .textTheme
                                            //     .headline6
                                            //     .copyWith(fontSize: 18),
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: 18,
                                            ),
                                          ),


                                          SizedBox(width: 4),
                                          Text(
                                            '@${controller.userProfile
                                                .username}',
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          SizedBox(width: 4),
                                          Text('.'),
                                          SizedBox(width: 4),
                                          Text(
                                            DateFormat.MMMd().format(
                                                post.postedOn),

                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 10),
                                      if (post.body.length > 0)
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Text(post.body,
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),),
                                        ),
                                      post.postType == 'image' &&
                                          post.postFiles.length > 0
                                          ? ClipRRect(
                                        borderRadius: BorderRadius.circular(15),
                                        child: Container(
                                          height: 100,
                                          width: 100,
                                          color: Colors.grey[300],
                                          child: Align(
                                            alignment: Alignment.center,
                                            child: kIsWeb
                                                ? Image.network(
                                                post.postFiles[0]
                                                ['file_path'],
                                                height: 100,
                                                fit: BoxFit.cover,
                                                width: 100, errorBuilder:
                                                (BuildContext context,
                                                Object exception,
                                                StackTrace
                                                stackTrace) {
                                              return Icon(Icons.error,
                                                  size: 40);
                                            })
                                                : Image.network(
                                              post.postFiles[0]
                                              ['file_path'],
                                              height: 100,
                                              fit: BoxFit.cover,
                                              width: 100,
                                              errorBuilder: (BuildContext
                                              context,
                                                  Object exception,
                                                  StackTrace stackTrace) {
                                                return Icon(Icons.error,
                                                    size: 40);
                                              },
                                            ),
                                          ),
                                        ),
                                      )
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length == 2 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount: post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return Container(
                                              height: 100,
                                              decoration: BoxDecoration(
                                                  color: Colors.transparent,
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius.circular(
                                                          12))),
                                              child: ClipRRect(
                                                borderRadius:
                                                BorderRadius.all(
                                                    Radius.circular(0)),
                                                child: Image.network(
                                                  post.postFiles[index]
                                                  ['file_path'],
                                                  fit: BoxFit.cover,
                                                  height: 100,
                                                ),
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(
                                                1, index.isEven ? 1 : 1);
                                          })
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length == 3 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView.countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics: ScrollPhysics(),
                                          itemCount:
                                          post.postFiles.length,
                                          itemBuilder: (context, index) {
                                            return Container(
                                              height: 100,
                                              width: 100,
                                              decoration: BoxDecoration(
                                                  color:
                                                  Colors.transparent,
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius.circular(
                                                          15))),
                                              child: ClipRRect(
                                                borderRadius:
                                                BorderRadius.all(
                                                    Radius.circular(
                                                        15)),
                                                child: Image.network(
                                                  post.postFiles[index]
                                                  ['file_path'],
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder: (index) {
                                            return StaggeredTile.count(
                                                1, index == 0 ? 1 : 0.5);
                                          })
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length ==
                                              4 &&
                                          post.postFiles[0]['file_type'] ==
                                              'image'
                                          ? StaggeredGridView
                                          .countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics:
                                          ScrollPhysics(),
                                          itemCount: post.postFiles
                                              .length,
                                          itemBuilder:
                                              (context, index) {
                                            return Container(
                                              height: 100,
                                              width: 100,
                                              decoration: BoxDecoration(
                                                  color: Colors
                                                      .transparent,
                                                  borderRadius: BorderRadius
                                                      .all(Radius
                                                      .circular(
                                                      12))),
                                              child: ClipRRect(
                                                borderRadius: BorderRadius
                                                    .all(Radius
                                                    .circular(
                                                    12)),
                                                child:
                                                Image.network(
                                                  post.postFiles[
                                                  index][
                                                  'file_path'],
                                                  fit: BoxFit
                                                      .cover,
                                                ),
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder:
                                              (index) {
                                            return StaggeredTile
                                                .count(
                                                1,
                                                index.isEven
                                                    ? 0.6
                                                    : 0.6);
                                          })
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length >
                                              4 &&
                                          post.postFiles[0]
                                          ['file_type'] ==
                                              'image'
                                          ? StaggeredGridView
                                          .countBuilder(
                                          crossAxisCount: 2,
                                          crossAxisSpacing: 3,
                                          mainAxisSpacing: 3,
                                          shrinkWrap: true,
                                          physics:
                                          ScrollPhysics(),
                                          itemCount: post.postFiles.length >= 5
                                              ? 4
                                              : post.postFiles
                                              .length,
                                          itemBuilder: (context,
                                              index) {
                                            return post.postFiles
                                                .length >=
                                                5 &&
                                                index == 3
                                                ? Container(
                                              height:
                                              100,
                                              width:
                                              100,
                                              decoration: BoxDecoration(
                                                  color: Colors
                                                      .transparent,
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius.circular(15))),
                                              child:
                                              ClipRRect(
                                                borderRadius:
                                                BorderRadius.all(
                                                    Radius.circular(15)),
                                                child:
                                                Stack(
                                                  fit: StackFit
                                                      .expand,
                                                  children: [
                                                    Image.network(
                                                      post
                                                          .postFiles[index]['file_path'],
                                                      fit: BoxFit.cover,
                                                    ),
                                                    if (post.postFiles.length >=
                                                        5)
                                                      Container(
                                                        color: Colors.black38,
                                                      ),
                                                    if (post.postFiles.length >=
                                                        5)
                                                      Align(
                                                        alignment: Alignment
                                                            .center,
                                                        child: Text(
                                                          '+${post.postFiles
                                                              .length -
                                                              4}',
                                                          // style: Theme
                                                          //     .of(context)
                                                          //     .textTheme
                                                          //     .headline3
                                                          //     .copyWith(
                                                          //   color: Colors.white,
                                                          //   fontSize: 24,
                                                          // ),
                                                          style: TextStyle(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness.dark
                                                                ? Colors.white
                                                                : Colors.black,
                                                            fontSize: 24,
                                                          ),
                                                        ),
                                                      ),
                                                  ],
                                                ),
                                              ),
                                            )
                                                : Container(
                                              height:
                                              100,
                                              width:
                                              100,
                                              decoration: BoxDecoration(
                                                  color: Colors
                                                      .transparent,
                                                  borderRadius:
                                                  BorderRadius.all(
                                                      Radius.circular(15))),
                                              child:
                                              ClipRRect(
                                                borderRadius:
                                                BorderRadius.all(
                                                    Radius.circular(8)),
                                                child: Image
                                                    .network(
                                                  post.postFiles[index]
                                                  [
                                                  'file_path'],
                                                  fit: BoxFit
                                                      .cover,
                                                ),
                                              ),
                                            );
                                          },
                                          staggeredTileBuilder:
                                              (index) {
                                            return StaggeredTile
                                                .count(
                                                1,
                                                index.isEven
                                                    ? 0.6
                                                    : 0.6);
                                          })
                                          : post.postType == 'video' &&
                                          post.postFiles.length ==
                                              1
                                          ? Container(
                                        height: 100,
                                        width: 100,
                                        child: Image.network(post
                                            .postFiles[0]
                                        [
                                        'thumbnail_path'] !=
                                            null
                                            ? post.postFiles[
                                        0][
                                        'thumbnail_path']
                                            : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png'),
                                      )
                                      //     : post.postType == 'audio' &&
                                      //     post.postFiles.length ==
                                      //         1
                                      //     ? ChewieVideoPlayer( //8
                                      //   post: post,
                                      //   index: 0,
                                      //   isAudio: true,
                                      // )
                                      //
                                      //     : post.postType ==
                                      //     'gallery' &&
                                      //     post.postFiles.length > 1 &&
                                      //     post.postFiles[0]['file_type'] == 'audio'
                                      //     ? Column(
                                      //   children: [
                                      //     for (var i = 0; i < post.postFiles.length; i++)
                                      //       Padding(
                                      //           padding:
                                      //           const EdgeInsets.symmetric(
                                      //               vertical: 4.0),
                                      //           child: ChewieVideoPlayer( //9
                                      //               post: post, index: index)),
                                      //   ],
                                      // )


                                          : post.postType == 'attachment' &&
                                          post.postFiles.length == 1
                                          ? ListTile(

                                        onTap:
                                            () {
                                          launch(post.postFiles[0]
                                          [
                                          'file_path']);
                                        },
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                            BorderRadius.circular(10)),
                                        tileColor: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors
                                            .black
                                            : Colors.white
                                        ,
                                        leading:
                                        SizedBox(
                                          height:
                                          28,
                                          width:
                                          28,
                                          child:
                                          Image.asset(
                                              'assets/images/document.png'),
                                        ),
                                        title:
                                        Text(
                                          "${post
                                              .postFiles[0]['original_name']}",
                                          style: TextStyle(
                                            color: Theme
                                                .of(context)
                                                .brightness == Brightness.dark
                                                ? Colors.white
                                                : Colors.black,
                                          ),
                                        ),
                                      )
                                          : post.postType == 'gallery' &&
                                          post.postFiles.length > 1 &&
                                          post.postFiles[0]['file_type'] ==
                                              'attachment'
                                          ? Column(
                                        children: [
                                          for (var i = 0; i <
                                              post.postFiles.length; i++)
                                            Padding(
                                              padding: const EdgeInsets
                                                  .symmetric(
                                                  vertical: 4.0),
                                              child: ListTile(

                                                onTap: () {
                                                  launch(
                                                      post
                                                          .postFiles[i]['file_path']);
                                                },
                                                shape: RoundedRectangleBorder(
                                                    borderRadius: BorderRadius
                                                        .circular(10)),
                                                tileColor: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.black
                                                    : Colors.white
                                                ,
                                                leading: SizedBox(height: 28,
                                                    width: 28,
                                                    child: Image.asset(
                                                        'assets/images/document.png')),
                                                title: Text(
                                                  "${post
                                                      .postFiles[i]['original_name']}",
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ),
                                            ),
                                        ],
                                      )
                                          : Container(),
                                    ],
                                  ),
                                ),

                                SizedBox(height: 12),
                                // Like and Rewerfs Section
                                Container(
                                  padding: EdgeInsets.symmetric(vertical: 16),
                                  height: 84,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(15),
                                    border: Border.all(
                                      color: Colors.grey[300],
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment
                                        .spaceAround,
                                    children: [
                                      Column(
                                        children: [
                                          Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                                'assets/drawer_icons/not_like.png'),
                                          ),
                                          SizedBox(height: 4),
                                          Text(post.likeCount.toString(),
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),),

                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Container(
                                            width: 20,
                                            height: 20,
                                            child: new Image.asset(
                                              'assets/drawer_icons/comments.png',
                                              color: Colors.grey,
                                            ),
                                          ),
                                          SizedBox(height: 4),
                                          Text(post.commentCount.toString(),
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          Container(
                                            width: 20,
                                            height: 20,
                                            child: Image.asset(
                                                'assets/drawer_icons/rebuzz.png',
                                                color: post.rebuzz.value
                                                    ? Theme
                                                    .of(context)
                                                    .iconTheme
                                                    .color
                                                    : Colors.grey),
                                          ),
                                          SizedBox(height: 4),
                                          Text(post.rebuzzCount.toString(),
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 16),
                                Container(
                                  height: 68,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment
                                        .spaceAround,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(Strings.impressions,
                                                    // style: TextStyle(
                                                    //     fontSize: kIsWeb ? 16 : 14)
                                                    style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: kIsWeb
                                                          ? 16
                                                          : 14,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(width: 2),
                                                GestureDetector(
                                                    onTap: () {},
                                                    child: Icon(
                                                      Icons.info_outline,
                                                      color: Colors.grey,
                                                      size: kIsWeb ? 16 : 12,
                                                    )),
                                              ],
                                            ),
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                  controller.werfAnalytics
                                                      .impressions !=
                                                      null
                                                      ? controller
                                                      .werfAnalytics.impressions
                                                      .toString()
                                                      : 0,
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 16 : 14,
                                                  ),)),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(Strings.engagements,
                                                    style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: kIsWeb
                                                          ? 16
                                                          : 14,
                                                    ),),
                                                ),

                                                SizedBox(width: 2),
                                                GestureDetector(
                                                    onTap: () {},
                                                    child: Icon(
                                                      Icons.info_outline,
                                                      color: Colors.grey,
                                                      size: kIsWeb ? 16 : 12,
                                                    )),
                                              ],
                                            ),
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                  (post.simpleLikeCount +
                                                      post.commentsCount +
                                                      post.retweetCount +
                                                      controller.werfAnalytics
                                                          .detailExpands +
                                                      controller.werfAnalytics
                                                          .newFollowers)
                                                      .toString(),
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 16 : 14,
                                                  ),)),
                                          ],
                                        ),
                                      ),
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(Strings.detailExpands,
                                                    style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: kIsWeb
                                                          ? 16
                                                          : 14,
                                                    ),),
                                                ),
                                                SizedBox(width: 2),
                                                GestureDetector(
                                                    onTap: () {},
                                                    child: Icon(
                                                      Icons.info_outline,
                                                      color: Colors.grey,
                                                      size: kIsWeb ? 16 : 12,
                                                    )),
                                              ],
                                            ),
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                  controller.werfAnalytics
                                                      .detailExpands !=
                                                      null
                                                      ? controller.werfAnalytics
                                                      .detailExpands
                                                      .toString()
                                                      : 0,
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 16 : 14,
                                                  ),)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 16),
                                Container(
                                  height: 68,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    mainAxisAlignment: MainAxisAlignment
                                        .spaceAround,
                                    children: [
                                      Spacer(),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(
                                                    Strings.newFollowers,
                                                    style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: kIsWeb
                                                          ? 16
                                                          : 14,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(width: 2),
                                                GestureDetector(
                                                    onTap: () {},
                                                    child: Icon(
                                                      Icons.info_outline,
                                                      color: Colors.grey,
                                                      size: kIsWeb ? 16 : 12,
                                                    )),
                                              ],
                                            ),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Text(
                                                controller.werfAnalytics
                                                    .newFollowers !=
                                                    null
                                                    ? controller
                                                    .werfAnalytics.newFollowers
                                                    .toString()
                                                    : 0,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),),
                                            ),
                                          ],
                                        ),
                                      ),
                                      SizedBox(width: 4),
                                      Expanded(
                                        child: Column(
                                          children: [
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Text(Strings.profileVisits,
                                                    style: TextStyle(
                                                      color: Theme
                                                          .of(context)
                                                          .brightness ==
                                                          Brightness.dark
                                                          ? Colors.white
                                                          : Colors.black,
                                                      fontSize: kIsWeb
                                                          ? 16
                                                          : 14,
                                                    ),),
                                                ),

                                                SizedBox(width: 2),
                                                GestureDetector(
                                                    onTap: () {},
                                                    child: Icon(
                                                      Icons.info_outline,
                                                      color: Colors.grey,
                                                      size: kIsWeb ? 16 : 12,
                                                    )),
                                              ],
                                            ),
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Text(
                                                  controller.werfAnalytics
                                                      .profileVisits !=
                                                      null
                                                      ? controller.werfAnalytics
                                                      .profileVisits
                                                      .toString()
                                                      : 0,
                                                  style: TextStyle(
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors.white
                                                        : Colors.black,
                                                    fontSize: kIsWeb ? 16 : 14,
                                                  ),)),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    barrierDismissible: false,
                  );
                } else {
                  if (kIsWeb) {
                    showDialog(
                        context: context,
                        builder: (BuildContext con) {
                          return Shortcuts(
                            shortcuts: {

                              LogicalKeySet(
                                  LogicalKeyboardKey.escape): EscIntent()
                            },
                            child: AlertDialog(
                                backgroundColor: Theme
                                    .of(context)
                                    .brightness == Brightness.dark ? MyColors
                                    .liteDark : Colors.white,
                                insetPadding: EdgeInsets.symmetric(
                                    horizontal: 0, vertical: 0),
                                contentPadding: EdgeInsets.symmetric(
                                    horizontal: 10),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(25.0))),
                                content: SingleChildScrollView(
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 15, right: 15, top: 15),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? MyColors.liteDark
                                            : Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(50)
                                        ),
                                      ),
                                      height: 250,
                                      width: 400,
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          GestureDetector(
                                            onTap: () {
                                              Navigator.pop(context);
                                            },
                                            child: Actions(
                                              actions: {
                                                EscIntent: CallbackAction<
                                                    EscIntent>(
                                                    onInvoke: (Intent) =>
                                                        Navigator.of(context)
                                                            .pop())
                                              },
                                              child: Focus(
                                                autofocus: true,
                                                focusNode: FocusNode(),
                                                child: MouseRegion(
                                                  cursor: SystemMouseCursors
                                                      .click,
                                                  child: Icon(
                                                    Icons.cancel_outlined,
                                                    color: Theme
                                                        .of(context)
                                                        .brightness ==
                                                        Brightness.dark
                                                        ? Colors
                                                        .white
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(height: 30),
                                          Text(
                                            Strings.views,
                                            style: Styles.baseTextTheme
                                                .headline3.copyWith(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark ? Colors
                                                    .white : Colors.black,
                                                fontSize: 18,
                                                fontWeight: FontWeight.w900

                                            ),
                                          ),
                                          post.postViews == null ?
                                          Text(
                                            Strings.werfSeenCountMsg,
                                            style: Styles.baseTextTheme
                                                .subtitle1.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness ==
                                                  Brightness.dark ? Colors
                                                  .white : Colors.black,


                                            ),
                                          ) :
                                          Text(
                                            "${Strings
                                                .thisWerfSeen} ${post.postViews
                                                .toString()} ${Strings
                                                .times}",
                                            style: Styles.baseTextTheme
                                                .subtitle1.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness ==
                                                  Brightness.dark ? Colors
                                                  .white : Colors.black,


                                            ),
                                          ),


                                          SizedBox(
                                            height: 20,
                                          ),
                                          Align(
                                            alignment: Alignment.center,
                                            child: ElevatedButton(

                                              // key: LoginController.formKey,
                                              onPressed: () async {
                                                Navigator.pop(context);
                                              },
                                              child: Text(
                                                Strings.dismiss,
                                                style: Styles.baseTextTheme
                                                    .headline2.copyWith(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark ? Colors
                                                      .white : Colors.white,
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                              style: ElevatedButton.styleFrom(
                                                shadowColor:
                                                Colors.transparent,
                                                primary: controller
                                                    .displayColor,
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 25,
                                                    horizontal: 100),
                                                elevation: 0.0,
                                                shape: StadiumBorder(),
                                                // minimumSize: Size(100, 40),
                                              ),
                                            ),
                                          ),


                                          SizedBox(
                                            height: 20,
                                          ),


                                        ],
                                      ),


                                    ),
                                  ),
                                )

                              //     Deactivation(
                              //   context2: context,
                              // ),
                            ),
                          );
                        });
                  }
                  else {
                    Get.bottomSheet(
                      Container(
                        decoration: BoxDecoration(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? MyColors.liteDark
                              : Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(15),
                            topRight: Radius.circular(15),
                          ),
                        ),
                        height: 200,

                        child: Padding(
                          padding: const EdgeInsets.only(left: 15, right: 15),
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              SizedBox(height: 30),
                              Text(
                                Strings.views,
                                style: Styles.baseTextTheme.headline3
                                    .copyWith(
                                    color: Theme
                                        .of(context)
                                        .brightness == Brightness.dark
                                        ? Colors
                                        .white
                                        : Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900

                                ),
                              ),
                              post.postViews == null ?
                              Text(
                                Strings.werfSeenCountMsg,
                                style: Styles.baseTextTheme.subtitle1
                                    .copyWith(
                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .white : Colors.black,


                                ),
                              ) :
                              Text(
                                "${Strings
                                    .thisWerfSeen} ${post.postViews
                                    .toString()} ${Strings
                                    .times}",
                                style: Styles.baseTextTheme.subtitle1
                                    .copyWith(
                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark ? Colors
                                      .white : Colors.black,


                                ),
                              ),


                              SizedBox(
                                height: 20,
                              ),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(

                                      // key: LoginController.formKey,
                                      onPressed: () async {
                                        Navigator.pop(context);
                                      },
                                      child: Text(
                                        Strings.dismiss,
                                        style: Styles.baseTextTheme.headline2
                                            .copyWith(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.white,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      style: ElevatedButton.styleFrom(
                                        shadowColor:
                                        Colors.transparent,
                                        primary: controller.displayColor,
                                        padding: EdgeInsets.symmetric(
                                            vertical: 15,
                                            horizontal: 10),
                                        elevation: 0.0,
                                        shape: StadiumBorder(),
                                        // minimumSize: Size(100, 40),
                                      ),
                                    ),
                                  ),
                                ],
                              ),


                              SizedBox(
                                height: 20,
                              ),


                            ],
                          ),
                        ),


                      ),
                    );
                  }
                }
              },

              child: Row(
                  children: [

                    Container(
                      width: 20,
                      height: 20,
                      child: Image.asset(
                        'assets/post_card_icons/impression.png',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Color(0xFF536471),
                      ),
                    ),
                    SizedBox(
                      width: 3,
                    ),
                    post.postViews != null ?
                    Text(
                      post.postViews.toString(),
                      style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Color(0xFF536471),
                        fontSize: 12,
                        fontWeight: FontWeight.w400,
                      ),

                    ) : Text(""),

                  ]
              ),
            ),
          ),


          PopupMenuButton(
              tooltip: Strings.share,
              position: PopupMenuPosition.under,
              padding: EdgeInsets.zero,
              icon: Container(
                width: 20,
                height: 20,
                child: Image.asset(
                  'assets/post_card_icons/share.png',
                  color: Theme
                      .of(context)
                      .brightness == Brightness.dark
                      ? Colors.white
                      : Color(0xFF536471),
                ),
              ),

              color: Theme
                  .of(context)
                  .brightness == Brightness.dark ? Colors.black : Colors.white,
              // Callback that sets the selected popup menu item.
              onSelected: (value) async {
                // if (value == 1) {
                //   // ignore: unused_local_variable
                //   bool isSuccess = await controller.savePost(post.postId);
                //   if (isSuccess) {
                //     post.saved = true;
                //     UtilsMethods.toastMessageShow(
                //         controller.displayColor,
                //         controller.displayColor,
                //         controller.displayColor,
                //         message: 'Werf saved successfully!');
                //   }
                //   if (!isSuccess) {
                //     UtilsMethods.toastMessageShow(
                //         controller.displayColor,
                //         controller.displayColor,
                //         controller.displayColor,
                //         message: 'There was an error in saving this werf!');
                //     // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //     //   content: Text('There was an error in saving this werf!',
                //     //     style: TextStyle(
                //     //       color: Theme
                //     //           .of(context)
                //     //           .brightness == Brightness.dark
                //     //           ? Colors.white
                //     //           : Colors.black,
                //     //     ),
                //     //   ),
                //     // ),
                //     // );
                //   }
                //
                //   // Get.showSnackbar(buildSnackBar(
                //   //     isSuccess
                //   //         ? 'Your Update is saved Successfull'
                //   //         : 'An Error Occured While Saving your update',
                //   //     context));
                //   // controller.update();
                // }
                // else if (value == 2) {
                //   bool isSuccess = await controller.unSavePost(post.postId);
                //
                //
                //   if (isSuccess) {
                //     post.saved = false;
                //     UtilsMethods.toastMessageShow(
                //         controller.displayColor,
                //         controller.displayColor,
                //         controller.displayColor,
                //         message: Strings.werfUnsaved);
                //   }
                //   if (!isSuccess) {
                //     UtilsMethods.toastMessageShow(
                //         controller.displayColor,
                //         controller.displayColor,
                //         controller.displayColor,
                //         message: 'There was an error in Unsaving this werf!');
                //     // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //     //   content: Text('There was an error in Unsaving this werf!',
                //     //     style: TextStyle(
                //     //       color: Theme.of(context).brightness == Brightness.dark
                //     //           ? Colors.white
                //     //           : Colors.black,
                //     //     ),
                //     //   ),
                //     // ),
                //     // );
                //   }
                // }
                //
                //
                // else
                if (value == 3) {
                  // kIsWeb ?
                  // showReposrtUserDialog(
                  //     context, post.authorId.toString(), controller) :

                  // String genterate = await FirebaseDeepLink().createDynamicLink( short:true,link:'/post?postId='+
                  String genterate = 'https://werfie.com/home/postDetail/' +
                      post.postId.toString();
                  // toStringpost.postId.toString());

                  // UtilsMethods.share(genterate, 'Werf');


                  Clipboard.setData(ClipboardData(text: genterate)).then((_) {
                    Fluttertoast.showToast(
                        msg: Strings.werfLinkCopiedSuccessfully,
                        toastLength:
                        Toast.LENGTH_SHORT,
                        gravity: ToastGravity.TOP,
                        timeInSecForIosWeb:
                        1,
                        backgroundColor: controller.displayColor,

                        textColor: Colors.white,
                        webPosition: "center",
                        webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                        fontSize: 16.0);
                  });

                  // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                  // UtilsMethods.share(
                  //     genterate,
                  //     'post');
                  // print('post Id at share' + post.postId.toString());
                  // print('linkgenerate:${genterate}');


                  // UtilsMethods.toastMessageShow(
                  //     controller.displayColor,
                  //     controller.displayColor,
                  //     controller.displayColor,
                  //     message: 'Werf link copied successfully');


                  controller.update();
                }

                else if (value == 4) {
                  if (!kIsWeb) {
                    // kIsWeb ?
                    // showReposrtUserDialog(
                    //     context, post.authorId.toString(), controller) :

                    String genterate = 'https://werfie.com/home/postDetail/' +
                        post.postId.toString();

                    UtilsMethods.share(genterate, 'Werf');


                    // String genterate = await FirebaseDeepLink().createDynamicLink(short: false, link: 'https://werfie.com?postId=' + post.postId.toString());
                    // UtilsMethods.share(
                    //     genterate,
                    //     'post');
                    // print('post Id at share' + post.postId.toString());
                    // print('linkgenerate:${genterate}');


                    controller.update();
                  }
                  else {
                    UtilsMethods.toastMessageShow(
                        controller.displayColor,
                        controller.displayColor,
                        controller.displayColor,
                        message: Strings.shareWerf);
                  }
                }
              },
              itemBuilder: (BuildContext context) =>
              [
                // /// BOOKMARK SECTION
                // if(post.saved == false || post.saved == null)
                //   PopupMenuItem(
                //     value: 1,
                //     child: Row(
                //       children: [
                //         Container(
                //             width: 20,
                //             height: 20,
                //             child: SvgPicture.asset(
                //               'assets/svg_drawer_icons/saved.svg',
                //               color: Theme
                //                   .of(context)
                //                   .brightness == Brightness.dark
                //                   ? Colors.white
                //                   : Colors.black,
                //             )
                //         ),
                //         SizedBox(width: 5,),
                //         Text(Strings.bookmark,
                //           style: TextStyle(
                //               color: Theme
                //                   .of(context)
                //                   .brightness == Brightness.dark
                //                   ? Colors.white
                //                   : Colors
                //                   .black,
                //               fontSize: 14
                //           ),
                //         ),
                //       ],
                //     ),),
                //
                // if(post.saved == true)
                //   PopupMenuItem(
                //     value: 2,
                //     child: Row(
                //
                //       children: [
                //         Container(
                //             width: 20,
                //             height: 20,
                //             child: SvgPicture.asset(
                //               'assets/svg_drawer_icons/saved.svg',
                //               color: Theme
                //                   .of(context)
                //                   .brightness == Brightness.dark
                //                   ? Colors.white
                //                   : Colors.black,
                //             )
                //         ),
                //         SizedBox(width: 5,),
                //         Text(Strings.removeWerfFromBookMark,
                //           style: TextStyle(
                //               color: Theme
                //                   .of(context)
                //                   .brightness == Brightness.dark
                //                   ? Colors.white
                //                   : Colors
                //                   .black,
                //               fontSize: 14
                //           ),
                //         ),
                //       ],
                //     ),),

                PopupMenuItem(
                  value: 3,
                  child: Row(
                      children: [
                        Container(
                            width: 20,
                            height: 20,
                            child: Image.asset(
                              AppImages.copylink,
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                            )
                        ),
                        SizedBox(width: 5),
                        Text(
                          Strings.copylinkToWerf,
                          style:
                          TextStyle(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors
                                  .black,
                              fontSize: 14
                          ),),
                      ]),),
                if(!kIsWeb)

                  PopupMenuItem(
                    value: 4,
                    child: Row(
                        children: [
                          Container(
                              width: 20,
                              height: 20,
                              child: Image.asset(
                                AppImages.share,
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors.black,
                              )
                          ),
                          SizedBox(width: 5),
                          Text(
                            Strings.shareWerf,
                            style:
                            TextStyle(
                                color: Theme
                                    .of(context)
                                    .brightness == Brightness.dark
                                    ? Colors.white
                                    : Colors
                                    .black,
                                fontSize: 14
                            ),),
                        ]),),


              ]
          ),
          /// BOOKMARK AND UNBOOKMARK SECTION
          GetBuilder<NewsfeedController>(builder: (context) =>
              Tooltip(
                message: post.saved == false || post.saved == null
                    ? Strings.addBookmark
                    : Strings.removeBookmark,
                child: InkWell(
                  onTap: () async {
                    bool isSuccess;
                    if (post.saved == false || post.saved == null) {
                      isSuccess = await controller.savePost(post.postId);
                    } else {
                      isSuccess = await controller.unSavePost(post.postId);
                    }

                    if (isSuccess) {
                      post.saved = !post.saved;
                      UtilsMethods.toastMessageShow(
                        controller.displayColor,
                        controller.displayColor,
                        controller.displayColor,
                        message: post.saved
                            ? Strings.werfSavedSuccessfully
                            : Strings.werfUnsavedSuccessfully,
                      );
                    } else {
                      UtilsMethods.toastMessageShow(
                        controller.displayColor,
                        controller.displayColor,
                        controller.displayColor,
                        message: post.saved
                            ? Strings.thereWasAnErrorInUnSavingThisWerf
                            : Strings.thereWasAnErrorInSavingThisWerf,
                      );
                    }
                  },
                  child: Container(
                    width: 20,
                    height: 20,
                    child: Image.asset(
                      post.saved == false || post.saved == null ? 'assets/post_card_icons/bookmark.png' : 'assets/post_card_icons/bookmark_fill.png',
                      color: Theme
                          .of(Get.context)
                          .brightness == Brightness.dark
                          ? Colors.white
                          : post.saved == false || post.saved == null ? Color(0xFF536471) : Color(0xFF1D9BF0),
                    ),
                  ),
                ),
              )),



        ],
      );
    });
  }


  // Simple Comment BUILDER METHOD
  dynamic buildSimpleCommentField(NewsfeedController controller,
      BuildContext context, Post post) {
    return Obx(() {
      return post.isComment.value
          ? LeaveAComment(controller, post)
          : Container();
    });
  }

  Widget myPopMenu(BuildContext context, scaffoldKey, Post post,
      NewsfeedController controller, int index) {
    int ind = 0;
    return Align(
      alignment: Alignment.topRight,
      child: PopupMenuButton(
          initialValue: 13,
          padding: EdgeInsets.zero,
          tooltip: Strings.showMenu,
          child: Icon(
            Icons.more_horiz,
            size: kIsWeb ? 30 : 19,
            color: Colors.grey,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: Colors.white,
          onSelected: (value) async {
            print(value);
            if (value == 1) {
              showDialogBox(context, post.postId, controller);
              controller.update();
            } else if (value == 2) {
              controller.hidePost(post.postId);
              // controller.update();
            } else if (value == 3) {
              // ignore: unused_local_variable
              bool isSuccess = await controller.savePost(post.postId);
              if (isSuccess) {
                post.saved = true;
                UtilsMethods.toastMessageShow(
                  controller.displayColor,
                  controller.displayColor,
                  controller.displayColor,
                  message: Strings.werfSavedSuccessfully,);
              }
              if (!isSuccess) {
                UtilsMethods.toastMessageShow(
                  controller.displayColor,
                  controller.displayColor,
                  controller.displayColor,
                  message: Strings.thereWasAnErrorInSavingThisWerf,);
                // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //     content: Text('There was an error in saving this werf!')));
              }

              // Get.showSnackbar(buildSnackBar(
              //     isSuccess
              //         ? 'Your Update is saved Successfull'
              //         : 'An Error Occured While Saving your update',
              //     context));
              // controller.update();
            } else if (value == 4) {
              bool isSuccess = await controller.blockUser(post.authorId);
              if (isSuccess) {
                UtilsMethods.toastMessageShow(
                  controller.displayColor,
                  controller.displayColor,
                  controller.displayColor,
                  message: Strings.userBlockedSuccessfully,);
                // ScaffoldMessenger.of(context).showSnackBar(
                //     SnackBar(content: Text('User blocked successfully!')));
                controller.update(['postt', 'post']);
              }
              if (!isSuccess) {
                UtilsMethods.toastMessageShow(
                  controller.displayColor,
                  controller.displayColor,
                  controller.displayColor,
                  message: Strings.thereWasAnErrorInBlockingThisUser,);
                // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //     content:
                //     Text('There was an error in blocking this user!')));
              }
            } else if (value == 5) {
              showReposrtUserDialog(
                  context, post.authorId.toString(), controller);
              controller.update();
            }
            //
            // else if (value == 6) {
            //   // kIsWeb ?
            //   // showReposrtUserDialog(
            //   //     context, post.authorId.toString(), controller) :
            //   // UtilsMethods.share(
            //   //     'https://werfie.com?postId='+ post.postId.toString(),
            //   //     'post');
            //
            //   // String genterate = await  firebaseDeepLink.createDynamicLink(
            //   //     short: false,
            //   //     link: 'https://werfie.com?postId='+ post.postId.toString());
            //   // UtilsMethods.share(
            //   //     genterate,
            //   //     'post');
            //   // print('post Id at share'+post.postId.toString());
            //   // print('linkgenerate:${genterate}');
            //   controller.update();
            // }
            else if (value == 7) {


              /*  await UtilsMethods.share(
                  "https://werfie.com/profile?profileId=" +
                      post.authorId.toString(),
                  'profile');*/

              // String genterate = 'https://werfie.com/profile?profileId='+
              String genterate = 'https://werfie.com/home/profile/' +
                  // post.authorId.toString()+"&profilePostId="+post.postId.toString();
                  post.authorId.toString();

              /*           String genterate = await FirebaseDeepLink().createDynamicLink(short: true, link: 'https://werfieapp.page.link/vhUX/profile?profileId='
                   +
                  post.authorId.toString());*/
              Clipboard.setData(ClipboardData(text: genterate)).then((_) {
                Fluttertoast.showToast(
                  // msg: 'Link Copy profile Successfully',
                    msg: Strings.profileLinkCopy,
                    toastLength:
                    Toast.LENGTH_SHORT,
                    gravity: ToastGravity.TOP,
                    timeInSecForIosWeb:
                    1,
                    backgroundColor: controller.displayColor,

                    textColor: Colors.white,
                    webPosition: "center",
                    webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                    fontSize: 16.0);
              });
              // await Clipboard.setData(ClipboardData(text: genterate));
              print("profileurl" + genterate);
              /*      await UtilsMethods.share(
                  genterate,
                  'profile');*/

              controller.update();
            }


            else if (value == 8) {
              ///bug
              showDialog(
                  context: context,
                  builder: (BuildContext con) {
                    return AlertDialog(


                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        backgroundColor: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? MyColors.liteDark
                            : Colors.white,
                        contentPadding: EdgeInsets.zero,
                        content: Padding(
                          padding: const EdgeInsets.only(
                              left: 20, right: 20, top: 20),
                          child: Container(
                            height: 250,
                            width: 250,
                            child: SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "${Strings.deleteWerf}?",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                    ),
                                  ),
                                  Text(
                                    Strings
                                        .ThisCantBeUndoneAndItWillBeRemovedFromYourProfileTheTimelineOfAnyAccountsThatFollowYouAndFromWerfieSearchResults,
                                    style: TextStyle(
                                      height: 1.2,
                                      fontSize: 14,
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? MyColors.grey
                                          : Colors.black,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: ElevatedButton(
                                          // key: LoginController.formKey,
                                          onPressed: () async {
                                            print("deletePostId $deletePostId");
                                            Navigator.pop(context);
                                            controller.deletePost(
                                                post.postId, postList: postList,
                                                id: deletePostId);
                                            controller.update();
                                          },
                                          child: Text(
                                            Strings.delete,
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              color: Colors.white,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            shadowColor:
                                            Colors.transparent,
                                            primary: Colors.red,
                                            padding: EdgeInsets.symmetric(

                                                vertical: 20,
                                                horizontal: 25),
                                            elevation: 0.0,
                                            shape: StadiumBorder(),
                                            // minimumSize: Size(100, 40),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    children: [
                                      Expanded(
                                        child: ElevatedButton(
                                          // key: LoginController.formKey,
                                          onPressed: () async {
                                            Navigator.pop(context);
                                          },
                                          child: Text(
                                            Strings.cancel,
                                            style: Styles.baseTextTheme
                                                .headline2.copyWith(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            shadowColor:
                                            Colors.transparent,
                                            primary: Theme
                                                .of(context)
                                                .brightness == Brightness.dark
                                                ? Colors.black
                                                : Colors.white,
                                            padding: EdgeInsets.symmetric(

                                                vertical: 20,
                                                horizontal: 25),
                                            elevation: 0.0,
                                            shape: StadiumBorder(

                                            ),
                                            side: BorderSide(
                                              width: 1,
                                              color: MyColors.grey,
                                            ),
                                            // minimumSize: Size(100, 40),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),


                                ],
                              ),
                            ),


                          ),
                        )

                      //     Deactivation(
                      //   context2: context,
                      // ),
                    );
                  });
              // controller.update();
            } else if (value == 9) {
              // bool isAnalyticsLoading = false;
              await controller.getWerfAnalytics(post.postId);

              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    scrollable: true,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                            Radius.circular(10.0))),
                    insetPadding:
                    EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                    contentPadding: EdgeInsets.symmetric(horizontal: 15),
                    content: Container(
                      height: kIsWeb ? 525 : 450,
                      width: kIsWeb ? 500 : Get.width * 0.95,
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            ListTile(
                              leading: GestureDetector(
                                onTap: () {
                                  Navigator.of(context).pop();
                                },
                                child: Icon(Icons.close),
                              ),
                              title: Text(Strings.werfAnalytics,
                                style: TextStyle(
                                  color: Theme
                                      .of(context)
                                      .brightness == Brightness.dark
                                      ? Colors.white
                                      : Colors.black,
                                ),),
                            ),
                            SizedBox(height: 12),
                            // Werf Section
                            Container(
                              // height: 160,
                              padding:
                              EdgeInsets.only(left: 20, top: 20, bottom: 10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(
                                  color: Colors.grey[300],
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      controller.userProfile.profileImage ==
                                          null
                                          ? CircleAvatar(
                                          radius: 18,
                                          backgroundImage: AssetImage(
                                              "assets/images/person_placeholder.png"))
                                          : ClipRRect(
                                        borderRadius:
                                        BorderRadius.circular(25),
                                        child: FadeInImage(
                                          fit: BoxFit.cover,
                                          width: 24,
                                          height: 24,
                                          placeholder: AssetImage(
                                              'assets/images/person_placeholder.png'),
                                          image: NetworkImage(controller
                                              .userProfile
                                              .profileImage !=
                                              null
                                              ? controller
                                              .userProfile.profileImage
                                              : "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
                                        ),
                                      ),
                                      SizedBox(width: 4),
                                      Text(
                                        controller.userProfile.firstname,
                                        // style: Theme
                                        //     .of(context)
                                        //     .textTheme
                                        //     .headline6
                                        //     .copyWith(fontSize: 18),
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                          fontSize: 18,
                                        ),
                                      ),


                                      SizedBox(width: 4),
                                      Text(
                                        '@${controller.userProfile.username}',
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                      ),
                                      SizedBox(width: 4),
                                      Text('.'),
                                      SizedBox(width: 4),
                                      Text(
                                        DateFormat.MMMd().format(post.postedOn),

                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 10),
                                  if (post.body.length > 0)
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(post.body,
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),),
                                    ),
                                  post.postType == 'image' &&
                                      post.postFiles.length > 0
                                      ? ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Container(
                                      height: 100,
                                      width: 100,
                                      color: Colors.grey[300],
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: kIsWeb
                                            ? Image.network(
                                            post.postFiles[0]
                                            ['file_path'],
                                            height: 100,
                                            fit: BoxFit.cover,
                                            width: 100, errorBuilder:
                                            (BuildContext context,
                                            Object exception,
                                            StackTrace
                                            stackTrace) {
                                          return Icon(Icons.error,
                                              size: 40);
                                        })
                                            : Image.network(
                                          post.postFiles[0]
                                          ['file_path'],
                                          height: 100,
                                          fit: BoxFit.cover,
                                          width: 100,
                                          errorBuilder: (BuildContext
                                          context,
                                              Object exception,
                                              StackTrace stackTrace) {
                                            return Icon(Icons.error,
                                                size: 40);
                                          },
                                        ),
                                      ),
                                    ),
                                  )
                                      : post.postType == 'gallery' &&
                                      post.postFiles.length == 2 &&
                                      post.postFiles[0]['file_type'] ==
                                          'image'
                                      ? StaggeredGridView.countBuilder(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 3,
                                      mainAxisSpacing: 3,
                                      shrinkWrap: true,
                                      physics: ScrollPhysics(),
                                      itemCount: post.postFiles.length,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          height: 100,
                                          decoration: BoxDecoration(
                                              color: Colors.transparent,
                                              borderRadius:
                                              BorderRadius.all(
                                                  Radius.circular(
                                                      12))),
                                          child: ClipRRect(
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(0)),
                                            child: Image.network(
                                              post.postFiles[index]
                                              ['file_path'],
                                              fit: BoxFit.cover,
                                              height: 100,
                                            ),
                                          ),
                                        );
                                      },
                                      staggeredTileBuilder: (index) {
                                        return StaggeredTile.count(
                                            1, index.isEven ? 1 : 1);
                                      })
                                      : post.postType == 'gallery' &&
                                      post.postFiles.length == 3 &&
                                      post.postFiles[0]['file_type'] ==
                                          'image'
                                      ? StaggeredGridView.countBuilder(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 3,
                                      mainAxisSpacing: 3,
                                      shrinkWrap: true,
                                      physics: ScrollPhysics(),
                                      itemCount:
                                      post.postFiles.length,
                                      itemBuilder: (context, index) {
                                        return Container(
                                          height: 100,
                                          width: 100,
                                          decoration: BoxDecoration(
                                              color:
                                              Colors.transparent,
                                              borderRadius:
                                              BorderRadius.all(
                                                  Radius.circular(
                                                      15))),
                                          child: ClipRRect(
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(
                                                    15)),
                                            child: Image.network(
                                              post.postFiles[index]
                                              ['file_path'],
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                        );
                                      },
                                      staggeredTileBuilder: (index) {
                                        return StaggeredTile.count(
                                            1, index == 0 ? 1 : 0.5);
                                      })
                                      : post.postType == 'gallery' &&
                                      post.postFiles.length ==
                                          4 &&
                                      post.postFiles[0]['file_type'] ==
                                          'image'
                                      ? StaggeredGridView
                                      .countBuilder(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 3,
                                      mainAxisSpacing: 3,
                                      shrinkWrap: true,
                                      physics:
                                      ScrollPhysics(),
                                      itemCount: post.postFiles
                                          .length,
                                      itemBuilder:
                                          (context, index) {
                                        return Container(
                                          height: 100,
                                          width: 100,
                                          decoration: BoxDecoration(
                                              color: Colors
                                                  .transparent,
                                              borderRadius: BorderRadius
                                                  .all(Radius
                                                  .circular(
                                                  12))),
                                          child: ClipRRect(
                                            borderRadius: BorderRadius
                                                .all(Radius
                                                .circular(
                                                12)),
                                            child:
                                            Image.network(
                                              post.postFiles[
                                              index][
                                              'file_path'],
                                              fit: BoxFit
                                                  .cover,
                                            ),
                                          ),
                                        );
                                      },
                                      staggeredTileBuilder:
                                          (index) {
                                        return StaggeredTile
                                            .count(
                                            1,
                                            index.isEven
                                                ? 0.6
                                                : 0.6);
                                      })
                                      : post.postType == 'gallery' &&
                                      post.postFiles.length >
                                          4 &&
                                      post.postFiles[0]
                                      ['file_type'] ==
                                          'image'
                                      ? StaggeredGridView
                                      .countBuilder(
                                      crossAxisCount: 2,
                                      crossAxisSpacing: 3,
                                      mainAxisSpacing: 3,
                                      shrinkWrap: true,
                                      physics:
                                      ScrollPhysics(),
                                      itemCount: post.postFiles.length >= 5
                                          ? 4
                                          : post.postFiles
                                          .length,
                                      itemBuilder: (context,
                                          index) {
                                        return post.postFiles
                                            .length >=
                                            5 &&
                                            index == 3
                                            ? Container(
                                          height:
                                          100,
                                          width:
                                          100,
                                          decoration: BoxDecoration(
                                              color: Colors
                                                  .transparent,
                                              borderRadius:
                                              BorderRadius.all(
                                                  Radius.circular(15))),
                                          child:
                                          ClipRRect(
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(15)),
                                            child:
                                            Stack(
                                              fit: StackFit
                                                  .expand,
                                              children: [
                                                Image.network(
                                                  post
                                                      .postFiles[index]['file_path'],
                                                  fit: BoxFit.cover,
                                                ),
                                                if (post.postFiles.length >=
                                                    5)
                                                  Container(
                                                    color: Colors.black38,
                                                  ),
                                                if (post.postFiles.length >=
                                                    5)
                                                  Align(
                                                    alignment: Alignment.center,
                                                    child: Text(
                                                      '+${post.postFiles
                                                          .length -
                                                          4}',
                                                      // style: Theme
                                                      //     .of(context)
                                                      //     .textTheme
                                                      //     .headline3
                                                      //     .copyWith(
                                                      //   color: Colors.white,
                                                      //   fontSize: 24,
                                                      // ),
                                                      style: TextStyle(
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                        fontSize: 24,
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        )
                                            : Container(
                                          height:
                                          100,
                                          width:
                                          100,
                                          decoration: BoxDecoration(
                                              color: Colors
                                                  .transparent,
                                              borderRadius:
                                              BorderRadius.all(
                                                  Radius.circular(15))),
                                          child:
                                          ClipRRect(
                                            borderRadius:
                                            BorderRadius.all(
                                                Radius.circular(8)),
                                            child: Image
                                                .network(
                                              post.postFiles[index]
                                              [
                                              'file_path'],
                                              fit: BoxFit
                                                  .cover,
                                            ),
                                          ),
                                        );
                                      },
                                      staggeredTileBuilder:
                                          (index) {
                                        return StaggeredTile
                                            .count(
                                            1,
                                            index.isEven
                                                ? 0.6
                                                : 0.6);
                                      })
                                      : post.postType == 'video' &&
                                      post.postFiles.length ==
                                          1
                                      ? Container(
                                    height: 100,
                                    width: 100,
                                    child: Image.network(post
                                        .postFiles[0]
                                    [
                                    'thumbnail_path'] !=
                                        null
                                        ? post.postFiles[
                                    0][
                                    'thumbnail_path']
                                        : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png'),
                                  )
                                  //     : post.postType == 'audio' &&
                                  //     post.postFiles.length ==
                                  //         1
                                  //     ? ChewieVideoPlayer( //8
                                  //   post: post,
                                  //   index: 0,
                                  //   isAudio: true,
                                  // )
                                  //
                                  //     : post.postType ==
                                  //     'gallery' &&
                                  //     post.postFiles.length > 1 &&
                                  //     post.postFiles[0]['file_type'] == 'audio'
                                  //     ? Column(
                                  //   children: [
                                  //     for (var i = 0; i < post.postFiles.length; i++)
                                  //       Padding(
                                  //           padding:
                                  //           const EdgeInsets.symmetric(
                                  //               vertical: 4.0),
                                  //           child: ChewieVideoPlayer( //9
                                  //               post: post, index: index)),
                                  //   ],
                                  // )


                                      : post.postType == 'attachment' &&
                                      post.postFiles.length == 1
                                      ? ListTile(

                                    onTap:
                                        () {
                                      launch(post.postFiles[0]
                                      [
                                      'file_path']);
                                    },
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                        BorderRadius.circular(10)),
                                    tileColor: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ? Colors
                                        .black : Colors.white
                                    ,
                                    leading:
                                    SizedBox(
                                      height:
                                      28,
                                      width:
                                      28,
                                      child:
                                      Image.asset('assets/images/document.png'),
                                    ),
                                    title:
                                    Text(
                                      "${post.postFiles[0]['original_name']}",
                                      style: TextStyle(
                                        color: Theme
                                            .of(context)
                                            .brightness == Brightness.dark
                                            ? Colors.white
                                            : Colors.black,
                                      ),
                                    ),
                                  )
                                      : post.postType == 'gallery' &&
                                      post.postFiles.length > 1 &&
                                      post.postFiles[0]['file_type'] ==
                                          'attachment'
                                      ? Column(
                                    children: [
                                      for (var i = 0; i <
                                          post.postFiles.length; i++)
                                        Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 4.0),
                                          child: ListTile(

                                            onTap: () {
                                              launch(
                                                  post
                                                      .postFiles[i]['file_path']);
                                            },
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius
                                                    .circular(10)),
                                            tileColor: Theme
                                                .of(context)
                                                .brightness == Brightness.dark
                                                ? Colors.black
                                                : Colors.white
                                            ,
                                            leading: SizedBox(height: 28,
                                                width: 28,
                                                child: Image.asset(
                                                    'assets/images/document.png')),
                                            title: Text(
                                              "${post
                                                  .postFiles[i]['original_name']}",
                                              style: TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  )
                                      : Container(),
                                ],
                              ),
                            ),

                            SizedBox(height: 12),
                            // Like and Rewerfs Section
                            Container(
                              padding: EdgeInsets.symmetric(vertical: 16),
                              height: 84,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                border: Border.all(
                                  color: Colors.grey[300],
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceAround,
                                children: [
                                  Column(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        child: Image.asset(
                                            'assets/drawer_icons/not_like.png'),
                                      ),
                                      SizedBox(height: 4),
                                      Text(post.likeCount.toString(),
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),),

                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        child: new Image.asset(
                                          'assets/drawer_icons/comments.png',
                                          color: Colors.grey,
                                        ),
                                      ),
                                      SizedBox(height: 4),
                                      Text(post.commentCount.toString(),
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        child: Image.asset(
                                            'assets/drawer_icons/rebuzz.png',
                                            color: post.rebuzz.value
                                                ? Theme
                                                .of(context)
                                                .iconTheme
                                                .color
                                                : Colors.grey),
                                      ),
                                      SizedBox(height: 4),
                                      Text(post.rebuzzCount.toString(),
                                        style: TextStyle(
                                          color: Theme
                                              .of(context)
                                              .brightness == Brightness.dark
                                              ? Colors.white
                                              : Colors.black,
                                        ),),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 16),
                            Container(
                              height: 68,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceAround,
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(Strings.impressions,
                                                // style: TextStyle(
                                                //     fontSize: kIsWeb ? 16 : 14)
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),
                                              ),
                                            ),
                                            SizedBox(width: 2),
                                            GestureDetector(
                                                onTap: () {},
                                                child: Icon(
                                                  Icons.info_outline,
                                                  color: Colors.grey,
                                                  size: kIsWeb ? 16 : 12,
                                                )),
                                          ],
                                        ),
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              controller.werfAnalytics
                                                  .impressions !=
                                                  null
                                                  ? controller
                                                  .werfAnalytics.impressions
                                                  .toString()
                                                  : 0,
                                              style: TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 16 : 14,
                                              ),)),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(Strings.engagements,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),),
                                            ),

                                            SizedBox(width: 2),
                                            GestureDetector(
                                                onTap: () {},
                                                child: Icon(
                                                  Icons.info_outline,
                                                  color: Colors.grey,
                                                  size: kIsWeb ? 16 : 12,
                                                )),
                                          ],
                                        ),
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              (post.simpleLikeCount +
                                                  post.commentsCount +
                                                  post.retweetCount +
                                                  controller.werfAnalytics
                                                      .detailExpands +
                                                  controller.werfAnalytics
                                                      .newFollowers)
                                                  .toString(),
                                              style: TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 16 : 14,
                                              ),)),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(Strings.detailExpands,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),),
                                            ),
                                            SizedBox(width: 2),
                                            GestureDetector(
                                                onTap: () {},
                                                child: Icon(
                                                  Icons.info_outline,
                                                  color: Colors.grey,
                                                  size: kIsWeb ? 16 : 12,
                                                )),
                                          ],
                                        ),
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              controller.werfAnalytics
                                                  .detailExpands !=
                                                  null
                                                  ? controller.werfAnalytics
                                                  .detailExpands
                                                  .toString()
                                                  : 0,
                                              style: TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 16 : 14,
                                              ),)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 16),
                            Container(
                              height: 68,
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceAround,
                                children: [
                                  Spacer(),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                      CrossAxisAlignment.center,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                Strings.newFollowers,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),
                                              ),
                                            ),
                                            SizedBox(width: 2),
                                            GestureDetector(
                                                onTap: () {},
                                                child: Icon(
                                                  Icons.info_outline,
                                                  color: Colors.grey,
                                                  size: kIsWeb ? 16 : 12,
                                                )),
                                          ],
                                        ),
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                            controller.werfAnalytics
                                                .newFollowers !=
                                                null
                                                ? controller
                                                .werfAnalytics.newFollowers
                                                .toString()
                                                : 0,
                                            style: TextStyle(
                                              color: Theme
                                                  .of(context)
                                                  .brightness == Brightness.dark
                                                  ? Colors.white
                                                  : Colors.black,
                                              fontSize: kIsWeb ? 16 : 14,
                                            ),),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(Strings.profileVisits,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness.dark
                                                      ? Colors.white
                                                      : Colors.black,
                                                  fontSize: kIsWeb ? 16 : 14,
                                                ),),
                                            ),

                                            SizedBox(width: 2),
                                            GestureDetector(
                                                onTap: () {},
                                                child: Icon(
                                                  Icons.info_outline,
                                                  color: Colors.grey,
                                                  size: kIsWeb ? 16 : 12,
                                                )),
                                          ],
                                        ),
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              controller.werfAnalytics
                                                  .profileVisits !=
                                                  null
                                                  ? controller.werfAnalytics
                                                  .profileVisits
                                                  .toString()
                                                  : 0,
                                              style: TextStyle(
                                                color: Theme
                                                    .of(context)
                                                    .brightness ==
                                                    Brightness.dark
                                                    ? Colors.white
                                                    : Colors.black,
                                                fontSize: kIsWeb ? 16 : 14,
                                              ),)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                barrierDismissible: false,
              );
            } else if (value == 10) {
              if (post.userInfo.is_follow == false) {
                post.userInfo.is_follow = true;
                controller.update();
                await controller.addFollowing(post.authorId, "follow",
                    postId: post.postId);
              } else if (post.userInfo.is_follow == true) {
                post.userInfo.is_follow = false;
                await controller.addFollowing(post.authorId, "unFollow",
                    postId: post.postId);
                controller.update();
              }
            }
            else if (value == 11) {
              List<Post> userPosts = [];


              print("<....?$index");
              // post[index].

              if (post.pinPost == 1) {
                // Get.find<ProfileController>().userPosts.clear();
                // controller.update();
                // Get.find<ProfileController>().update();

                // Get.find<ProfileController>().userPosts.replaceRange(0, Get.find<ProfileController>().userPosts.length,Get.find<ProfileController>().tempUserPosts);

                // Get.find<ProfileController>().userPosts = Get.find<ProfileController>().tempUserPosts.toList();
                // Get.find<ProfileController>().userPosts = Get.find<ProfileController>().tempUserPosts;
                // Get.find<ProfileController>().tempUserPosts.forEach((element) {
                //   // if(element.pinPost !=0)
                //   // {
                //   //   print("enter");
                //   //   element.pinPost =0;
                //   //   Get.find<ProfileController>().update();
                //   //   controller.update();
                //   // }
                //   Get.find<ProfileController>().userPosts.replaceRange(0,length,element);
                // });
                Post obj = Post();
                obj = Get
                    .find<ProfileController>()
                    .userPosts[index];
                Get
                    .find<ProfileController>()
                    .userPosts
                    .removeAt(index);
                post.pinPost = 0;
                int index_ = userData.read("index");
                Get
                    .find<ProfileController>()
                    .userPosts
                    .insert(index_, obj);
                controller.update();
                Get.find<ProfileController>().update();


                // int length = Get.find<ProfileController>().userPosts.length;
                // print(length);
                // Post obj = Post();
                // obj = Get.find<ProfileController>().userPosts[index];
                //
                // Get.find<ProfileController>().userPosts.removeAt(index);
                //
                // Get.find<ProfileController>().userPosts.insert(length,obj);


                controller.pinUnPinPost(postId: post.postId, pinUnPinPost: 0);
                // controller.checkPin = true;
                Get.find<ProfileController>().update();
                // controller.update();

                // }
              }
              else if (post.pinPost == 0) {
                Post obj = Post();
                obj = Get
                    .find<ProfileController>()
                    .userPosts[index];
                Get
                    .find<ProfileController>()
                    .userPosts
                    .removeAt(index);
                userData.write("index", index);
                Get
                    .find<ProfileController>()
                    .userPosts
                    .insert(0, obj);
                Get
                    .find<ProfileController>()
                    .userPosts
                    .forEach((element) {
                  if (element.pinPost != 0) {
                    print("enter");
                    element.pinPost = 0;
                    Get.find<ProfileController>().update();
                    controller.update();
                  }
                });
                post.pinPost = 1;
                Get.find<ProfileController>().update();
                controller.update();
                controller.pinUnPinPost(postId: post.postId, pinUnPinPost: 1);
                Get.find<ProfileController>().update();
                // controller.update();
              }
            }
            else if (value == 12) {
              if (!kIsWeb) {
                controller.modelList2 = [];
                controller.modelList2.insert(0, ModelClass.fromJson(
                    {
                      'body': '',
                      'poll_ques_first': null,
                      'poll_ques_first': null,
                      'poll_ques_third': null,
                      'poll_ques_fourth': null,
                      'files': [],
                      'link_meta': '',
                      'link': '',
                      'link_image': '',
                      'link_title': '',
                      'days': '',
                      'minutes': '',
                      'hours': '',
                      'location': '',
                      'lat': '',
                      'lng': '',
                      'type': "thread",
                      "post_id": 0,
                    }
                ));
                Get.to(
                    CreatePostMobile(
                        controller, post: post
                    )
                );
              }
              else {
                controller.modelList2 = [];
                controller.modelList2.insert(0, ModelClass.fromJson(
                    {
                      'body': '',
                      'poll_ques_first': null,
                      'poll_ques_first': null,
                      'poll_ques_third': null,
                      'poll_ques_fourth': null,
                      'files': [],
                      'link_meta': '',
                      'link': '',
                      'link_image': '',
                      'link_title': '',
                      'days': '',
                      'minutes': '',
                      'hours': '',
                      'location': '',
                      'lat': '',
                      'lng': '',
                      'type': "thread",
                      "post_id": 0,
                    }
                ));
                showDialog(
                  context: context,
                  builder:
                      (BuildContext context) {
                    // controller.mediaData.clear();
                    // controller.update();
                    return AlertDialog(
                      shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.all(
                              Radius.circular(
                                  10.0))),
                      insetPadding:
                      EdgeInsets.symmetric(
                          horizontal: 0,
                          vertical: 0),
                      contentPadding:
                      EdgeInsets.symmetric(
                          horizontal: 12),
                      // content:
                      // // kIsWeb
                      // //     ?
                      // DialogboxWeb(
                      //     controller,
                      //     controller.userProfile.profileImage,
                      //    false,
                      //      true,
                      //     post:post,
                      //
                      // ),
                    );
                  },
                  barrierDismissible: false,
                );
              }

              // == controller.userId?

            }
            else if (value == 13) {
              if (!kIsWeb) {
                ViewEditHistory viewEditHistory;
                viewEditHistory =
                await controller.getPostHistory(postId: post.postId);

                //print("data");
                //print(viewEditHistory.data[0].description);


                // controller.isNewsFeedScreen = false;
                // controller.update();

                if (viewEditHistory.data.isNotEmpty) {
                  Get.bottomSheet(
                    BottomSheet(
                      enableDrag: false,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(30),
                        ),
                      ),
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      onClosing: () {},
                      builder: (context) =>
                          SizedBox(
                            // height: 400,  // Get.height / 1.2,
                            child: CheckHistory(
                              viewEditHistory: viewEditHistory,
                            ),
                          ),
                    ),


                  );
                }
              }
              else {
                ViewEditHistory viewEditHistory;
                viewEditHistory =
                await controller.getPostHistory(postId: post.postId);

                //print("data");
                // print(viewEditHistory.data[0].description);

                // print( "scaffoldkey receive from user profile in popmenu:   ${scaffoldKey.currentContext}");

                if (viewEditHistory == null) {
                  UtilsMethods.toastMessageShow(
                    controller.displayColor,
                    controller.displayColor,
                    controller.displayColor,
                    message: Strings.noEditHistory,);
                }
                else if (viewEditHistory.data.isNotEmpty) {
                  print(scaffoldKey.currentContext);
                  showDialog(
                    context: scaffoldKey.currentContext,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        shape: RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.all(
                                Radius.circular(
                                    10.0))),
                        insetPadding:
                        EdgeInsets.symmetric(
                            horizontal: 0,
                            vertical: 0),
                        contentPadding:
                        EdgeInsets.symmetric(
                            horizontal: 12),
                        content: Container(
                          height: MediaQuery
                              .of(context)
                              .size
                              .height * 0.5,
                          width: 400,
                          child: CheckHistory(
                            viewEditHistory: viewEditHistory,
                          ),
                        ),
                      );
                    },
                    // barrierDismissible: false,
                  );
                }
              }
            }

            else if (value == 14) {
              String msg = await controller.muteUnMute(
                  postType: post.type, userID: post.authorId);


              Get
                  .find<NewsfeedController>()
                  .userInfo =
              await controller.getOtherUserProfile(post.authorId);


              otherController.userPosts.forEach((element) {
                element.mute = Get
                    .find<NewsfeedController>()
                    .userInfo
                    .muted;
                print("element.mute  ${element.mute}");
              });

              //
              // if(post.mute == false)
              // {
              //   post.mute = true;
              //
              // }
              // else{
              //
              //   post.mute = false;
              // }

              otherController.update();
              Get.find<NewsfeedController>().update();

              if (msg != null) {
                UtilsMethods.toastMessageShow(
                  controller.displayColor,
                  controller.displayColor,
                  controller.displayColor,
                  message: msg,);
              }

              controller.postList = await controller.getNewsFeed();
              if (controller.postList != null) {
                controller.isNewsfeedLoading = false;

                controller.update();
              }

              // print(" muted value");


            }

            else if (value == 15) {
              bool isSuccess = await controller.unSavePost(post.postId);
              if (isSuccess) {
                post.saved = false;
                UtilsMethods.toastMessageShow(
                    controller.displayColor,
                    controller.displayColor,
                    controller.displayColor,
                    message: Strings.werfUnsaved);
              }
              if (!isSuccess) {
                UtilsMethods.toastMessageShow(
                    controller.displayColor,
                    controller.displayColor,
                    controller.displayColor,
                    message: Strings.thereWasAnErrorInUnSavingThisWerf);
                // ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                //   content: Text('There was an error in Unsaving this werf!',
                //     style: TextStyle(
                //       color: Theme.of(context).brightness == Brightness.dark
                //           ? Colors.white
                //           : Colors.black,
                //     ),
                //   ),
                // ),
                // );
              }
            }
          },
          itemBuilder: (context) =>
          post.username == controller.userName ? post.saved == null ||
              post.saved ?
          [
            // PopupMenuItem(
            //   value: 13,
            //   child: Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/history.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text('View Edit History',
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            PopupMenuItem(
              value: 2,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/hide_Werf.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.hide,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),
            ),
            PopupMenuItem(
                value: 8,
                child: Row(

                  children: [
                    Icon(
                      Icons.delete,
                      color: Colors.red,
                      size: 20,
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.deleteWerf,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),
            PopupMenuItem(
              value: 11,
              child: post.pinPost == 0 ? Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/push_pin.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.pintoYourProfile,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ) :
              post.pinPost == 1
                  ? Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/push_pinFILL.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.unPinFromProfile,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              )
                  : Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/push_pin.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.pintoYourProfile,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),
            ),
            PopupMenuItem(
                value: 9,
                child: Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: Image.asset(
                          AppImages.analytics,
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.viewWerfAnalytics,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),


            // if(post.type == "post" && post.canEdit == true)
            // PopupMenuItem(
            //   value: 12,
            //   child: post.authorId == controller.userId ? Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/edit.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text(
            //         "Edit Werf",
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ) : null,
            // ),


            // if(post.saved == null)
            //   PopupMenuItem(
            //     value: 3,
            //     child: Row(
            //
            //       children: [
            //         Container(
            //             width: 20,
            //             height: 20,
            //             child: SvgPicture.asset(
            //               'assets/popup_munu_icons/savewerf_icons.svg',
            //               color: Theme
            //                   .of(context)
            //                   .brightness == Brightness.dark
            //                   ? Colors.white
            //                   : Colors.black,
            //             )
            //         ),
            //         SizedBox(width: 5,),
            //         Text('Save Werf',
            //           style: TextStyle(
            //               color: Theme
            //                   .of(context)
            //                   .brightness == Brightness.dark
            //                   ? Colors.white
            //                   : Colors
            //                   .black,
            //               fontSize: 14
            //           ),
            //         ),
            //       ],
            //     ),),

            // if(post.saved == true)
            //   PopupMenuItem(
            //       value: 15,
            //       child: Row(
            //         children: [
            //           Icon(Icons.save,
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             size: 20,
            //           ),
            //           SizedBox(width: 5),
            //           Text(
            //             Strings.unsaveWerf,
            //             style: TextStyle(
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors
            //                     .black,
            //                 fontSize: 14
            //             ),
            //           ),
            //         ],
            //       )),

            // if(!kIsWeb)
            //   PopupMenuItem(
            //     value: 6,
            //     child: Row(
            //         children: [
            //           Container(
            //               width: 20,
            //               height: 20,
            //               child: SvgPicture.asset(
            //                 'assets/popup_munu_icons/share.svg',
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors.black,
            //               )
            //           ),
            //           SizedBox(width: 5),
            //           Text(
            //             'Share werf',
            //             style:
            //             TextStyle(
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors
            //                     .black,
            //                 fontSize: 14
            //             ),),
            //         ]),),

          ] : [

            ///hh
            // PopupMenuItem(
            //   value: 13,
            //   child: Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/history.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text('View Edit History',
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // PopupMenuItem(
            //   value: 3,
            //   child: Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/savewerf_icons.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text('Save Werf',
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ),),
            PopupMenuItem(
              value: 2,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/hide_Werf.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.hide,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
                value: 8,
                child: Row(

                  children: [
                    Icon(
                      Icons.delete,
                      color: Colors.red,
                      size: 20,
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.deleteWerf,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),
            PopupMenuItem(
                value: 9,
                child: Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: Image.asset(
                          AppImages.analytics,
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.viewWerfAnalytics,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),
            PopupMenuItem(
                value: 11,
                child: post.pinPost == 0 ? Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/push_pin.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text(
                      Strings.pintoYourProfile,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                ) :
                post.pinPost == 1 ? Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/push_pinFILL.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    Text(
                     Strings.unPinFromProfile,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                ) : Row(

                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/push_pin.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    Text(
                      Strings.pintoYourProfile,
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )
            ),
            // PopupMenuItem(
            //     enabled: post.type == "post" && post.canEdit == true
            //         ? true
            //         : false,
            //     value: 12,
            //     child: Text('Edit Werf',
            //       style: TextStyle(
            //           color: Theme
            //               .of(context)
            //               .brightness == Brightness.dark ? Colors.white : Colors
            //               .black,
            //           fontSize: 14
            //       ),)
            // ),
            // if(post.type == "post" && post.canEdit == true)
            // PopupMenuItem(
            //   value: 12,
            //   child: post.authorId == controller.userId ? Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/edit.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text(
            //         "Edit Werf",
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ) : null,
            // ),

            // if(!kIsWeb)
            //   PopupMenuItem(
            //     value: 6,
            //     child: Row(
            //         children: [
            //           Container(
            //               width: 20,
            //               height: 20,
            //               child: SvgPicture.asset(
            //                 'assets/popup_munu_icons/share.svg',
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors.black,
            //               )
            //           ),
            //           SizedBox(width: 5),
            //           Text(
            //             'Share werf',
            //             style:
            //             TextStyle(
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors
            //                     .black,
            //                 fontSize: 14
            //             ),),
            //         ]),),


          ] : !post.saved
              ? [
            // PopupMenuItem(
            //   value: 13,
            //   child: Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/history.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text('View Edit History',
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            PopupMenuItem(
                value: 10,
                child: post.userInfo.is_follow == true
                    ? Row(
                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/unfollow.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    SizedBox(width: 5,),
                    Text("${Strings.unFollow} ${post.userInfo.firstname}",
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )
                    : Row(
                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/follow.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    Text("${Strings.follow} ${post.userInfo.firstname}",
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )
            ),
            // PopupMenuItem(
            //   value: 3,
            //   child: Row(
            //
            //     children: [
            //       Container(
            //           width: 20,
            //           height: 20,
            //           child: SvgPicture.asset(
            //             'assets/popup_munu_icons/savewerf_icons.svg',
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors.black,
            //           )
            //       ),
            //       SizedBox(width: 5,),
            //       Text('Save Werf',
            //         style: TextStyle(
            //             color: Theme
            //                 .of(context)
            //                 .brightness == Brightness.dark
            //                 ? Colors.white
            //                 : Colors
            //                 .black,
            //             fontSize: 14
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            PopupMenuItem(
              value: 1,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/reportflagicon.svg',
                        color: Colors.red,
                      )
                  ),
                  SizedBox(width: 5,),
                  Text(
                    Strings.reportWerf,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 2,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/hide_Werf.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    Strings.hideWerf,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 4,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/block_user.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    "${Strings.block} ${post.userInfo.firstname}",
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 5,
              child: Row(

                children: [
                  Container(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/reportWerf_icon.svg',
                        color: Colors.red,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    "${Strings.report} ${post.userInfo.firstname}",
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
                value: 14,
                child: post.mute == false || post.mute == null
                    ? Row(
                  children: [
                    Container(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/unMute.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    SizedBox(
                      width: 150,
                      child: Text(

                         '${Strings.mute} ${post.userInfo.firstname}',
                        overflow: TextOverflow.ellipsis,
                        style:
                        TextStyle(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.w700,
                            fontSize: 14
                        ),
                      ),
                    ),
                  ],
                )
                    : Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/Mute.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),

                    SizedBox(
                      width: 150,
                      child: Text(

                        '${Strings.unMute} ${post.userInfo.firstname}',
                        overflow: TextOverflow.ellipsis,
                        style:
                        TextStyle(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.w700,
                            fontSize: 14
                        ),
                      ),
                    )

                  ],
                )
            ),
            PopupMenuItem(
                value: 7,
                child: Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/copy_lint.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5),
                    Text(
                      Strings.copyProfileLink,
                      style:
                      TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),

          ] : [
            // PopupMenuItem(
            //     value: 13,
            //     child: Row(
            //       children: [
            //         Container(
            //             width: 20,
            //             height: 20,
            //             child: SvgPicture.asset(
            //               'assets/popup_munu_icons/history.svg',
            //               color: Theme
            //                   .of(context)
            //                   .brightness == Brightness.dark
            //                   ? Colors.white
            //                   : Colors.black,
            //             )
            //         ),
            //         SizedBox(width: 5,),
            //         Text('View Edit History',
            //           style: TextStyle(
            //               color: Theme
            //                   .of(context)
            //                   .brightness == Brightness.dark
            //                   ? Colors.white
            //                   : Colors
            //                   .black,
            //               fontSize: 14
            //           ),
            //         ),
            //       ],
            //     )),

            PopupMenuItem(
                value: 10,
                child: post.userInfo.is_follow == true
                    ? Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/unfollow.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    Text("${Strings.unFollow} ${post.userInfo.firstname}",
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )
                    : Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/follow.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),
                    Text("${Strings.follow} ${post.userInfo.firstname}",
                      style: TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )
            ),
            // PopupMenuItem(
            //     value: 15,
            //     child: Row(
            //       children: [
            //         Icon(Icons.save,
            //           color: Theme
            //               .of(context)
            //               .brightness == Brightness.dark
            //               ? Colors.white
            //               : Colors
            //               .black,
            //           size: 20,
            //         ),
            //         SizedBox(width: 5),
            //         Text(
            //           Strings.unsaveWerf,
            //           style: TextStyle(
            //               color: Theme
            //                   .of(context)
            //                   .brightness == Brightness.dark
            //                   ? Colors.white
            //                   : Colors
            //                   .black,
            //               fontSize: 14
            //           ),
            //         ),
            //       ],
            //     )),
            PopupMenuItem(
              value: 1,
              child: Row(

                children: [
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/reportflagicon.svg',
                        color: Colors.red,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    Strings.reportWerf,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 2,
              child: Row(

                children: [
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/hide_Werf.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    Strings.hideWerf,
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 4,
              child: Row(

                children: [
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/block_user.svg',
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors.black,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                    "${Strings.block} ${post.userInfo.firstname}",
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
              value: 5,
              child: Row(

                children: [
                  SizedBox(
                      width: 20,
                      height: 20,
                      child: SvgPicture.asset(
                        'assets/popup_munu_icons/reportWerf_icon.svg',
                        color: Colors.red,
                      )
                  ),
                  const SizedBox(width: 5,),
                  Text(
                   "${Strings.report} ${post.userInfo.firstname}",
                    style: TextStyle(
                        color: Theme
                            .of(context)
                            .brightness == Brightness.dark
                            ? Colors.white
                            : Colors
                            .black,
                        fontWeight: FontWeight.w700,
                        fontSize: 14
                    ),
                  ),
                ],
              ),),
            PopupMenuItem(
                value: 14,
                child: post.mute == false || post.mute == null
                    ? Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/unMute.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),

                    SizedBox(
                      width: 150,
                      child: Text(
                          '${Strings.mute} ${post.authorName}',
                          overflow: TextOverflow.ellipsis,
                          style:
                          TextStyle(
                              color: Theme
                                  .of(context)
                                  .brightness == Brightness.dark
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight: FontWeight.w700,
                              fontSize: 14

                          )
                      ),
                    )

                  ],
                )
                    : Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/Mute.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5,),


                    SizedBox(
                      width: 150,
                      child: Text(
                        '${Strings.unMute} ${post.authorName}',
                        overflow: TextOverflow.ellipsis,
                        style:
                        TextStyle(
                            color: Theme
                                .of(context)
                                .brightness == Brightness.dark
                                ? Colors.white
                                : Colors.black,
                            fontWeight: FontWeight.w700,
                            fontSize: 14
                        ),
                      ),
                    )

                  ],
                )
            ),

            // if (!kIsWeb)
            //   PopupMenuItem(
            //     value: 6,
            //     child: Row(
            //         children: [
            //           Container(
            //               width: 20,
            //               height: 20,
            //               child: SvgPicture.asset(
            //                 'assets/popup_munu_icons/share.svg',
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors.black,
            //               )
            //           ),
            //           SizedBox(width: 5),
            //           Text(
            //             'Share werf',
            //             style:
            //             TextStyle(
            //                 color: Theme
            //                     .of(context)
            //                     .brightness == Brightness.dark
            //                     ? Colors.white
            //                     : Colors
            //                     .black,
            //                 fontSize: 14
            //             ),),
            //         ]),),

            PopupMenuItem(
                value: 7,
                child: Row(
                  children: [
                    SizedBox(
                        width: 20,
                        height: 20,
                        child: SvgPicture.asset(
                          'assets/popup_munu_icons/copy_lint.svg',
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors.black,
                        )
                    ),
                    const SizedBox(width: 5),
                    Text(
                      Strings.copyProfileLink,
                      style:
                      TextStyle(
                          color: Theme
                              .of(context)
                              .brightness == Brightness.dark
                              ? Colors.white
                              : Colors
                              .black,
                          fontWeight: FontWeight.w700,
                          fontSize: 14
                      ),
                    ),
                  ],
                )),


            //       post.username == controller.userName ? post.saved == null ||
            //           post.saved ? [
            //         PopupMenuItem(
            //             value: 2,
            //             child: Text(
            //               Strings.hide,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 8,
            //             child: Text(
            //               'Delete werf',
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //           value: 11,
            //           child: post.pinPost == 0 ? Text('Pin to your profile',
            //             style: Theme.of(context).brightness == Brightness.dark ?
            //             TextStyle(color: Colors.white,
            //                 fontSize:  14
            //             )
            //                 : TextStyle(  color: Colors.black, fontSize:  14,
            //             ),) :
            //           post.pinPost == 1 ? Text(
            //             'UnPin from profile',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ) : Text(
            //             'Pin to your profile',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),
            //         ),
            //         post.type == "post" && post.canEdit == true ? PopupMenuItem(
            //           value: 12,
            //           child: post.authorId == controller.userId ? Text('Edit Post',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )) : null,
            //         ) : null,
            //         PopupMenuItem(
            //           value: 13,
            //           child: Text('View Edit History',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),),
            //
            //       ] : [
            //         PopupMenuItem(
            //             value: 3,
            //             child: Text(
            //               'Save Werf',
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 2,
            //             child: Text(
            //               Strings.hide,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 8,
            //             child: Text(
            //               'Delete werf',
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 9,
            //             child: Text(
            //               'View Werf Analytics',
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //           value: 11,
            //           child: post.pinPost == 0 ? Text('Pin to your profile',
            //             style: Theme.of(context).brightness == Brightness.dark ?
            //             TextStyle(color: Colors.white,
            //                 fontSize:  14
            //             )
            //                 : TextStyle(  color: Colors.black, fontSize:  14,
            //             ),) :
            //           post.pinPost == 1 ? Text(
            //             'UnPin from profile',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ) : Text(
            //             'Pin to your profile',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),
            //         ),
            //         post.type == "post" && post.canEdit == true ? PopupMenuItem(
            //           value: 12,
            //           child: post.authorId == controller.userId ? Text('Edit Post',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )) : null,
            //         ) : null,
            //         PopupMenuItem(
            //           value: 13,
            //           child: Text('View Edit History',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),),
            //       ]
            //           : !post.saved
            //           ? [
            //         PopupMenuItem(
            //           value: 10,
            //           child: post.userInfo.is_follow == true
            //               ? Text(
            //             'Unfollow',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           )
            //               : Text(
            //             'Follow',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),
            //         ),
            //         PopupMenuItem(
            //           value: 3,
            //           child: Text(
            //             'Save Werf',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),
            //         ),
            //         PopupMenuItem(
            //             value: 1,
            //             child: Text(
            //               Strings.reportWerf,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 2,
            //             child: Text(
            //               Strings.hideWerf,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 4,
            //             child: Text(
            //               Strings.blockUser,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 5,
            //             child: Text(
            //               Strings.reportUser,
            //               style: TextStyle(color: Colors.black, fontSize: 14),
            //             )),
            //         PopupMenuItem(
            //           value: 13,
            //           child: Text('View Edit History',
            //               style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //           ),),
            //
            //
            //         PopupMenuItem(
            //             value: 14,
            //             child: post.mute == false || post.mute == null
            //                 ? Row(
            //               children: [
            //                 Icon(
            //                     Icons.volume_off
            //                 ),
            //
            //                 Text(
            //                   'Mute ' + post.username,
            //                   overflow: TextOverflow.ellipsis,
            //                     style: Theme.of(context).brightness == Brightness.dark ?
            //                     TextStyle(color: Colors.white,
            //                         fontSize:  14
            //                     )
            //                         : TextStyle(  color: Colors.black, fontSize:  14,
            //                     )
            //                 ),
            //               ],
            //             )
            //                 : Row(
            //               children: [
            //                 Icon(
            //                     Icons.volume_up
            //                 ),
            //                 Text(
            //                   'UnMute ' + post.username,
            //                   overflow: TextOverflow.ellipsis,
            //                     style: Theme.of(context).brightness == Brightness.dark ?
            //                     TextStyle(color: Colors.white,
            //                         fontSize:  14
            //                     )
            //                         : TextStyle(  color: Colors.black, fontSize:  14,
            //                     )
            //                 ),
            //               ],
            //             )
            //         ),
            //
            //
            //         if (!kIsWeb)
            //           PopupMenuItem(
            //               value: 6,
            //               child: Text(
            //                 'Share werf',
            //                   style: Theme.of(context).brightness == Brightness.dark ?
            //                   TextStyle(color: Colors.white,
            //                       fontSize:  14
            //                   )
            //                       : TextStyle(  color: Colors.black, fontSize:  14,
            //                   )
            //               )),
            //         PopupMenuItem(
            //             value: 7,
            //             child: Text(
            //               'Copy profile link',
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //
            //       ]
            //           : [
            //         PopupMenuItem(
            //             value: 1,
            //             child: Text(
            //               Strings.reportWerf,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 2,
            //             child: Text(
            //               Strings.hideWerf,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 4,
            //             child: Text(
            //               Strings.blockUser,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //         PopupMenuItem(
            //             value: 5,
            //             child: Text(
            //               Strings.reportUser,
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //                 TextStyle(color: Colors.white,
            //                     fontSize:  14
            //                 )
            //                     : TextStyle(  color: Colors.black, fontSize:  14,
            //                 )
            //             )),
            //
            //
            //         PopupMenuItem(
            //             value: 14,
            //             child: post.mute == false || post.mute == null
            //                 ? Row(
            //               children: [
            //                 Icon(
            //                     Icons.volume_off
            //                 ),
            //
            //                 Text(
            //                   'Mute ' + post.username,
            //                   overflow: TextOverflow.ellipsis,
            //                     style: Theme.of(context).brightness == Brightness.dark ?
            //                     TextStyle(color: Colors.white,
            //                         fontSize:  14
            //                     )
            //                         : TextStyle(  color: Colors.black, fontSize:  14,
            //                     )
            //                 ),
            //               ],
            //             )
            //                 : Row(
            //               children: [
            //                 Icon(
            //                     Icons.volume_up
            //                 ),
            //                 Text(
            //                   'UnMute ' + post.username,
            //                   overflow: TextOverflow.ellipsis,
            //                     style: Theme.of(context).brightness == Brightness.dark ?
            //                     TextStyle(color: Colors.white,
            //                         fontSize:  14
            //                     )
            //                         : TextStyle(  color: Colors.black, fontSize:  14,
            //                     )
            //                 ),
            //               ],
            //             )
            //         ),
            //         if (!kIsWeb)
            //           PopupMenuItem(
            //               value: 6,
            //               child: Text(
            //                 'Share werf',
            //                 style:
            //                 style: Theme.of(context).brightness == Brightness.dark ?
            //               TextStyle(color: Colors.white,
            //                   fontSize:  14
            //               )
            //                   : TextStyle(  color: Colors.black, fontSize:  14,
            //               )
            //               )),
            //         PopupMenuItem(
            //             value: 7,
            //             child: Text('Copy profile link',
            // style: Theme.of(context).brightness == Brightness.dark ?
            // TextStyle(color: Colors.white,
            // fontSize:  14
            // )
            //     : TextStyle(  color: Colors.black, fontSize:  14,
            // )
            //             )),
          ]
      ),
    );
  }

  //
  // GetBar<Object> buildSnackBar(String snackText, BuildContext context) {
  //   return GetBar<SnackBar>(
  //     borderRadius: 18,
  //     messageText: Text(
  //       snackText,
  //       style:
  //           Theme.of(context).textTheme.headline3.copyWith(color: Colors.white),
  //     ),
  //     backgroundColor: Color(0xFF0157d3),
  //     duration: Duration(seconds: 3),
  //     animationDuration: Duration(microseconds: 1000),
  //     snackStyle: SnackStyle.GROUNDED,
  //   );
  // }

  Widget sharePopMenu(BuildContext context,
      scaffoldKey,
      Post post,
      NewsfeedController controller,) {
    // print(controller.localeCode);
    // print('dsadsdasdasdasdsadasdasdas');
    return Align(
      alignment: Alignment.topRight,
      child: PopupMenuButton(
          enableFeedback: false,
          padding: kIsWeb
              ? EdgeInsets.zero
              : EdgeInsets.only(
              right: controller.localeCode == 'ar' ||
                  controller.localeCode == 'fa'
                  ? 0
                  : 50,
              left: controller.localeCode != 'ar' &&
                  controller.localeCode != 'fa'
                  ? 0
                  : 50),
          icon: const Icon(
            Icons.share,
            color: Colors.grey,
            size: kIsWeb ? 24 : 18,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
          color: Colors.white,
          onSelected: (value) async {
            print(value);

            if (value == 1) {
              UtilsMethods.share(
                  'https://werfie.com/home/postDetail/' +
                      post.postId.toString(),
                  'Post');
              // print(sha);

            }
            else if (value == 7) {
              Fluttertoast.showToast(
                // msg: 'Link Copy profile Successfully',
                  msg: Strings.profileLinkCopy,
                  toastLength:
                  Toast.LENGTH_SHORT,
                  gravity: ToastGravity.TOP,
                  timeInSecForIosWeb:
                  1,
                  backgroundColor: controller.displayColor,

                  textColor: Colors.white,
                  webPosition: "center",
                  webBgColor: "linear-gradient(to right, #2769d9, #2769d9)",
                  fontSize: 16.0);

              await UtilsMethods.share(
                // "https://werfie.com/profile?profileId=" + post.authorId.toString(),
                  'https://werfie.com/home/profile/' +
                      // post.authorId.toString()+"&profilePostId="+post.postId.toString();
                      post.authorId.toString(),
                  'profile');

              controller.update();
            }
            else if (value == 2) {
              Clipboard.setData(
                ClipboardData(
                  text: 'https://werfie.com/home/postDetail/' +
                      post.postId.toString(),),
              );
              // ScaffoldMessenger.of(context).showSnackBar(
              //   SnackBar(
              //     content: Text('Link copied to clipboard!'),
              //   ),
              // );
              // UtilsMethods.share(
              //     "https://werfie.com/post?postId=" + post.postId.toString(),
              //     'Post');
              // print('https://werfie.com?postId=' + post.postId.toString());
              controller.update();
            } else if (value == 3) {
              Get.find<SavedPostController>().removePost(savedItemId);
            }
          },
          itemBuilder: (context) =>
          [
            PopupMenuItem(
                value: 1,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.share,
                      color: Colors.grey,
                      size: 16,
                    ),
                    const SizedBox(width: 20),
                    Text(
                      Strings.shareLinkVia,
                      //  style: TextStyle(color: Colors.grey, fontSize: 14),

                      style: Theme
                          .of(context)
                          .brightness == Brightness.dark ?
                      const TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700,)
                          : const TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700,),

                    ),
                  ],
                )),
            PopupMenuItem(
                value: 2,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.link,
                      color: Colors.grey,
                      size: 16,
                    ),
                    const SizedBox(width: 20),
                    Text(
                      Strings.copyLink,
                      //  style: TextStyle(color: Colors.grey, fontSize: 14),

                      style: Theme
                          .of(context)
                          .brightness == Brightness.dark ?
                      const TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700,)
                          : const TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700,),

                    ),
                  ],
                )),
            PopupMenuItem(
                value: 3,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.delete,
                      color: Colors.red,
                      size: 16,
                    ),
                    SizedBox(width: 20),
                    Text(
                     Strings.removeFromBookmarks,
                      //  style: TextStyle(color: Colors.grey, fontSize: 14),

                      style: Theme
                          .of(context)
                          .brightness == Brightness.dark ?
                      const TextStyle(color: Colors.white, fontSize: 14,fontWeight: FontWeight.w700,)
                          : const TextStyle(color: Colors.black, fontSize: 14,fontWeight: FontWeight.w700,),

                    )
                  ],
                )),
          ]),
    );
  }

  showDialogBox(context, postId, NewsfeedController controller) {
    final reportText = TextEditingController();
    bool isCategory = false;
    final _formKey = GlobalKey<FormState>();
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return Container(
                    width: Get.width / 4.5,
                    height: kIsWeb ? Get.width / 4.5 : Get.height * 0.4,
                    padding: const EdgeInsets.all(10),
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: TextFormField(
                                maxLines: 5,
                                validator: (value) {
                                  if (value.isEmpty)
                                    Strings.enterDescriptionFieldIsRequired;;
                                  return null;
                                },
                                controller: reportText,
                                minLines: 3,
                                onChanged: (val) {
                                  val = reportText.text;
                                },
                                keyboardType: TextInputType.multiline,
                                decoration: InputDecoration(
                                  hintText: Strings.enterDescription,
                                  isDense: true,
                                  focusedErrorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Colors.grey[200],
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Colors.grey[200],
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Colors.grey[200],
                                    ),
                                  ),
                                  errorBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: Colors.red,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(
                                  left: 10, right: 10, top: 0, bottom: 25),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 10, horizontal: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    color:
                                    isCategory ? Colors.red : Colors.grey[200],
                                  ),
                                  borderRadius: BorderRadius.circular(10)),
                              width: Get.width,
                              height: 55,
                              child: DropdownButton<CategoryModel>(
                                isExpanded: true,
                                underline: Container(
                                  height: 0.0,
                                ),
                                hint: Text(
                                    controller.selectedCategory == null ||
                                        controller.selectedCategory == ""
                                        ? Strings.selectCategory
                                        : controller.selectedCategory),
                                items: controller.categoryList
                                    .map((CategoryModel value) {
                                  return DropdownMenuItem<CategoryModel>(
                                    value: value,
                                    child:  Text(value.name),
                                  );
                                }).toList(),
                                onChanged: (CategoryModel _) {
                                  setState(() {
                                    controller.selectedCategory = _.name;
                                    controller.selectcategoryId = _.id;
                                  });
                                },
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  MaterialButton(
                                      color: Colors.grey,
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      child: Text(
                                        Strings.cancel,
                                        //  style: TextStyle(color: Colors.black, fontSize: 14.0),

                                        style: Theme
                                            .of(context)
                                            .brightness == Brightness.dark ?
                                        const TextStyle(
                                            color: Colors.white, fontSize: 14)
                                            : const TextStyle(
                                            color: Colors.black, fontSize: 14),

                                      )),
                                  MaterialButton(
                                      color: Colors.blueAccent,
                                      onPressed: () async {
                                        if (_formKey.currentState.validate()) {
                                          await controller.blockUser(
                                              post.authorId);
                                          if (controller.selectcategoryId !=
                                              null) {
                                            setState(() {
                                              isCategory = false;
                                            });
                                            int response =
                                            await controller.reportPost(
                                                controller.selectcategoryId,
                                                postId,
                                                reportText.text);

                                            if (response == 200) {
                                              Navigator.of(context).pop();
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: Strings.werfReportedSuccssfully);
                                              // ScaffoldMessenger.of(context)
                                              //     .showSnackBar(SnackBar(
                                              //     content: Text(
                                              //         'Werf reported successfully!')));
                                            }
                                            if (response == 400) {
                                              Navigator.of(context).pop();
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: Strings.youHaveAlreadyReportedWerf);
                                              // ScaffoldMessenger.of(context)
                                              //     .showSnackBar(SnackBar(
                                              //     content: Text(
                                              //         'You have already reported this werf!')));
                                            }
                                          } else {
                                            setState(() {
                                              isCategory = true;
                                            });
                                          }
                                        }
                                      },
                                      child: Text(
                                        Strings.report,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 14.0),
                                      )),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                }),
          );
        });
  }

  showReposrtUserDialog(context, userId, NewsfeedController controller) {
    final reportText = TextEditingController();
    bool isCategory = false;
    final _formKey = GlobalKey<FormState>();
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0)),
            child: StatefulBuilder(
                builder: (BuildContext context, StateSetter setState) {
                  return Container(
                    width: Get.width / 4.5,
                    height: kIsWeb ? Get.width / 8 : 300,
                    padding: const EdgeInsets.all(10),
                    child: Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              margin: const EdgeInsets.only(
                                  left: 10, right: 10, top: 0, bottom: 25),
                              padding: const EdgeInsets.symmetric(
                                  vertical: 10, horizontal: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                    color:
                                    isCategory ? Colors.red : Colors.grey[200],
                                  ),
                                  borderRadius: BorderRadius.circular(10)),
                              width: Get.width,
                              height: 55,
                              child: DropdownButton<CategoryModel>(
                                isExpanded: true,
                                underline: Container(
                                  height: 0.0,
                                ),
                                hint: Text(
                                    controller.selectedCategory == null ||
                                        controller.selectedCategory == ""
                                        ? Strings.selectCategory
                                        : controller.selectedCategory),
                                items: controller.categoryList
                                    .map((CategoryModel value) {
                                  return DropdownMenuItem<CategoryModel>(
                                    value: value,
                                    child: new Text(value.name),
                                  );
                                }).toList(),
                                onChanged: (CategoryModel _) {
                                  setState(() {
                                    controller.selectedCategory = _.name;
                                    controller.selectcategoryId = _.id;
                                  });
                                },
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment
                                    .spaceBetween,
                                children: [
                                  MaterialButton(
                                      color: Colors.grey,
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      child: Text(
                                        Strings.cancel,
                                        // style: TextStyle(color: Colors.black, fontSize: 14.0),

                                        style: Theme
                                            .of(context)
                                            .brightness == Brightness.dark ?
                                        const TextStyle(
                                            color: Colors.white, fontSize: 14)
                                            : const TextStyle(
                                            color: Colors.black, fontSize: 14),

                                      )),
                                  MaterialButton(
                                      color: Colors.blueAccent,
                                      onPressed: () async {
                                        if (_formKey.currentState.validate()) {
                                          if (controller.selectcategoryId !=
                                              null) {
                                            setState(() {
                                              isCategory = false;
                                            });
                                            int response =
                                            await controller.reportUser(
                                              post.authorId,
                                              controller.selectcategoryId,
                                            );
                                            if (response == 200) {
                                              Navigator.of(context).pop();
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: Strings.userReportedSuccessfully);
                                              // ScaffoldMessenger.of(context)
                                              //     .showSnackBar(SnackBar(
                                              //     content: Text(
                                              //         'User reported successfully!')));
                                            }
                                            if (response == 400) {
                                              Navigator.of(context).pop();
                                              UtilsMethods.toastMessageShow(
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  controller.displayColor,
                                                  message: Strings.thereWasAnErrorInReportingThisUser);
                                              // ScaffoldMessenger.of(context)
                                              //     .showSnackBar(SnackBar(
                                              //     content: Text(
                                              //         'There was an error in reporting this user!')));
                                            }
                                          } else {
                                            setState(() {
                                              isCategory = true;
                                            });
                                          }
                                        }
                                      },
                                      child: Text(
                                        Strings.report,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontSize: 14.0),
                                      )),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                }),
          );
        });
  }

  // Widget urlFetch(NewsfeedController controller) {
  //   // if(widget.controller.scrapUrl.contains('.com')){
  //   //   return
  //   return FutureBuilder<ScrappingData>(
  //     future: controller.urlScraping(controller.scrapUrl),
  //     builder: (context, snapshot) {
  //       if (snapshot.hasData) {
  //         return cardScrap(context, snapshot.data);
  //       } else if (snapshot.hasError) {
  //         print(snapshot.error.toString());
  //         return Container();
  //       }
  //       return Container(
  //         child: Center(
  //           child: CircularProgressIndicator(),
  //         ),
  //       );
  //     },
  //   );
  //
  //   // }else{
  //   //   return Container();
  //   // }
  // }

  Widget cardScrap(BuildContext context, ScrappingData data) {
    // _validURL = true;
    if (data.title != '429 Too Many Requests') {
      return Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: GestureDetector(
          onTap: () {
            // Get.to(MenuListPage(
            //   restaurantId: id,
            // ));
          },
          child: Expanded(
            child: Card(
              elevation: 4,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
              ),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(
                  Radius.circular(5.0),
                ),
                child: SizedBox(
                  height: 80,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 0),
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0.0),
                              image: DecorationImage(
                                  image: data.images[0] != null
                                      ? NetworkImage(data.images[0].toString())
                                      : AssetImage(
                                      "assets/images/person_placeholder.png"),
                                  fit: BoxFit.cover)),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                const EdgeInsets.only(right: 8.0, top: 8.0),
                                child: InkWell(
                                  onTap: () {},
                                  child: const SizedBox(
                                    height: 4,
                                    child: Align(
                                        alignment: Alignment.topRight,
                                        child: Icon(Icons.cancel)),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 20,
                                  child: Text(data.title.toString(),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 17,
                                    //   fontWeight: FontWeight.w500,
                                    // )

                                    style: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ?
                                    const TextStyle(color: Colors.white, fontSize: 17,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: "Cairo"
                                    )
                                        : const TextStyle(
                                      color: Colors.black, fontSize: 17,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: "Cairo",
                                    ),

                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 18,
                                  child: Text(
                                    data.meta.toString(),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 16,
                                    //   fontWeight: FontWeight.w500,
                                    // ),

                                    style: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ?
                                    const TextStyle(color: Colors.white, fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: "Cairo"
                                    )
                                        : const TextStyle(
                                      color: Colors.black, fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: "Cairo",
                                    ),

                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 18,
                                  child: Text(data.link.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    // style: TextStyle(
                                    //   color: Colors.grey[700],
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 14,
                                    //   fontWeight: FontWeight.w400,
                                    // )

                                    style: Theme
                                        .of(context)
                                        .brightness == Brightness.dark ?
                                    const TextStyle(color: Colors.white, fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: "Cairo"
                                    )
                                        : TextStyle(
                                      color: Colors.grey[700], fontSize: 14,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: "Cairo",
                                    ),


                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    } else {
      return Container();
    }
  }
}

// class  extends StatelessWidget {
class ScrapCard extends StatelessWidget {
  final NewsfeedController controller;

  ScrapCard(this.controller);

//
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<ScrappingData>(
      future: controller.urlScraping(controller.scrapUrl),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return Container(
            height: Get.height / 1.7,
            width: Get.width,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(20.0)),
              color: Colors.white,
            ),
            child: InkWell(
              onTap: () async {
                await canLaunch(snapshot.data.link.toString())
                    ? await launch(snapshot.data.link.toString())
                    : throw 'Could not launch ${snapshot.data.link}';
              },
              child: Card(
                elevation: 4,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20.0)),
                ),
                child: Column(
                  children: [
                    Container(
                      height: Get.height / 2.1,
                      width: Get.width,

                      // color: Colors.black,
                      decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(20.0),
                            topRight: Radius.circular(20.0),
                          ),
                          image: DecorationImage(
                              image: snapshot.data.images[0] != null
                                  ? NetworkImage(
                                  snapshot.data.images[0].toString())
                                  : AssetImage(
                                  "assets/images/person_placeholder.png"),
                              fit: BoxFit.cover)),
                    ),
                    Padding(
                      padding:
                      const EdgeInsets.only(top: 5, left: 20, right: 20),
                      child: Expanded(
                        child: Text(snapshot.data.title.toString(),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 1,
                          // style: TextStyle(
                          //   color: Colors.black,
                          //   fontFamily: 'Cairo',
                          //   fontSize: 17,
                          //   fontWeight: FontWeight.w500,
                          // )

                          style: Theme
                              .of(context)
                              .brightness == Brightness.dark ?
                          const TextStyle(color: Colors.white, fontSize: 17,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Cairo"
                          )
                              : const TextStyle(color: Colors.black, fontSize: 17,
                            fontWeight: FontWeight.w500,
                            fontFamily: "Cairo",
                          ),

                        ),
                      ),
                    ),
                    Padding(
                        padding:
                        const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: Expanded(
                          child: Text(
                            snapshot.data.meta.toString(),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            // style: TextStyle(
                            //   color: Colors.black,
                            //   fontFamily: 'Cairo',
                            //   fontSize: 16,
                            //   fontWeight: FontWeight.w500,
                            // ),

                            style: Theme
                                .of(context)
                                .brightness == Brightness.dark ?
                            const TextStyle(color: Colors.white, fontSize: 16,
                                fontWeight: FontWeight.w500,
                                fontFamily: "Cairo"
                            )
                                : const TextStyle(color: Colors.black, fontSize: 16,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Cairo",
                            ),

                          ),
                        )),
                    Padding(
                      padding:
                      const EdgeInsets.only(top: 0, left: 20, right: 20),
                      child: Expanded(
                        child: Text(snapshot.data.link.toString(),
                          textAlign: TextAlign.left,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          // style: TextStyle(
                          //   color: Colors.grey[700],
                          //   fontFamily: 'Cairo',
                          //   fontSize: 14,
                          //   fontWeight: FontWeight.w400,
                          // )

                          style: Theme
                              .of(context)
                              .brightness == Brightness.dark ?
                          const TextStyle(color: Colors.white, fontSize: 14,
                              fontWeight: FontWeight.w400,
                              fontFamily: "Cairo"
                          )
                              : TextStyle(color: Colors.grey[700], fontSize: 14,
                            fontWeight: FontWeight.w400,
                            fontFamily: "Cairo",
                          ),

                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // color: Colors.black,
          );
          // return cardScrap(context, snapshot.data);
        } else if (snapshot.hasError) {
          print(snapshot.error.toString());
          return Container();
        }
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }
}

// ignore: must_be_immutable
class LeaveAComment extends StatefulWidget {
  final NewsfeedController controller;
  Post post;

  // final TextEditingController commentTextController;


  LeaveAComment(this.controller, this.post);

  @override
  _LeaveACommentState createState() => _LeaveACommentState();
}

class _LeaveACommentState extends State<LeaveAComment> {

  var focus1 = FocusNode();
  var focus2 = FocusNode();


  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 0),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          widget.controller.userProfile == null
              ? SizedBox(
              width: 24,
              child: Center(
                child: SpinKitCircle(
                  color: Colors.grey,
                  size: 40,
                ),
              ))
              : widget.controller.userProfile.profileImage == null
              ? const CircleAvatar(
              radius: 18,
              backgroundImage:
              AssetImage("assets/images/person_placeholder.png"))
              : ClipRRect(
            borderRadius: BorderRadius.circular(25),
            child: FadeInImage(
              fit: BoxFit.cover,
              width: 36,
              height: 36,
              placeholder: const AssetImage(
                  'assets/images/person_placeholder.png'),
              image: NetworkImage(widget.controller.userProfile.profileImage ?? "https://www.seekpng.com/png/detail/966-9665317_placeholder-image-person-jpg.png"),
            ),
          ),
          const SizedBox(
            width: 12,
          ),

          /// code here
          Expanded(
            child: Container(
              height: 55,

              child: HashTagTextField(
                focusNode: focus1,
                onSubmitted: (_) =>
                    FocusScope.of(context).requestFocus(focus2),


                basicStyle: LightStyles.baseTextTheme.headline2.copyWith(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark
                        ? Colors.white
                        : Colors.black
                ),
                cursorColor: Theme
                    .of(context)
                    .brightness == Brightness.dark ? Colors.black : Colors
                    .black,
                onTap: () {
                  print('CCCLLIIVVKK FFIIEELLDD');
                },
                controller: widget.controller.commentController,
                textAlignVertical: TextAlignVertical.bottom,
                decoratedStyle: LightStyles.baseTextTheme.headline2.copyWith(
                    color: Theme
                        .of(context)
                        .brightness == Brightness.dark
                        ? Colors.blue
                        : Colors.blue
                ),
                decoration: InputDecoration(
                  contentPadding: const EdgeInsets.only(
                      left: 20, top: 10, bottom: 20),
                  hintText: Strings.leaveAComment,
                  hintStyle: LightStyles.baseTextTheme.headline3,

                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40),
                    borderSide: const BorderSide(
                        color: Colors.grey,
                        width: 1
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(40),
                    borderSide: const BorderSide(
                      width: 1,
                      color: Colors.grey,
                    ),
                  ),
                  fillColor: Colors.grey[250],
                  filled: true,
                ),
                onChanged: (value) async {
                  // if (widget.controller.commentController.text.length > 0)
                  //   setState(() {
                  //     widget.controller.postText = true;
                  //   });
                  // else
                  //   setState(() {
                  //     widget.controller.postText = false;
                  //   });


                  widget.controller.tempValue = value;

                  // print(getHashTags(value));


                  // if (value.length > 0 && widget.commentTextController.text.trim().isNotEmpty)


                  if (value.length < 2) {
                    /// user tag and mention tag
                    widget.controller.mentionUser = false;
                    widget.controller.mentionTag = false;
                    widget.controller.temp = '';
                    widget.controller.tempUsername = '';
                    widget.controller.tags.clear();

                    /// end
                    // visibility = true;

                    widget.controller.update();
                    // setState(() {});
                  }

                  /// user # tag and @ mention user
                  if (value.length >
                      0) {
                    int tempLength = 0;
                    //  temp='';
                    // tempUsername = '';
                    ///hash tag
                    if (value[value
                        .length -
                        1] ==
                        '#') {
                      // temp = '';
                      print(
                          'if  ${value[value.length - 1]}');
                      widget.controller.temp = value[
                      value.length -
                          1];
                      if (kDebugMode) {
                        print('1  # : ${widget.controller.temp}');
                      }
                    } else if (widget.controller.temp !=
                        '' &&
                        value[value.length -
                            1] !=
                            ' ') {
                      // temp = '';
                      print(
                          'if else value ${value[value.length - 1]}');

                      widget.controller.temp = widget.controller.temp +
                          value[value
                              .length -
                              1];
                      if (kDebugMode) {
                        print('2  # : ' +
                          widget.controller.temp);
                      }
                    } else if (value[
                    value.length -
                        1] ==
                        ' ') {
                      if (kDebugMode) {
                        print('3   # :' +
                          widget.controller.temp);
                      }
                      widget.controller.temp = '';
                      widget.controller.mentionUser =
                      false;
                      widget.controller.mentionTag =
                      false;
                    }
                    if (widget.controller.temp.length > 1) {
                      if (kDebugMode) {
                        print('temp value # : ${widget.controller.temp}');
                      }
                      widget.controller.tags.clear();
                      if (kDebugMode) {
                        print('hashtag temp value :${widget.controller.temp}');
                      }

                      widget.controller.tags =
                      await widget.controller.searchTags(widget.controller
                          .temp.substring(1));
                      //  await   print('hastag api value:${widget.tags}');
                      if (widget.controller.tags[0] == false) {
                        widget.controller.tags.clear();
                        widget.controller.mentionTag =
                        false;
                        //  temp='';
                        widget.controller.update();
                      } else {
                        // widget.controller.mentionUser =
                        // false;
                        widget.controller.mentionTag = true;
                        widget.controller.update();
                      }
                    }
                    if (kDebugMode) {
                      print(
                        "temp store value#: ${widget.controller.temp}");
                    }

                    /// @ mention user
                    /*   if (value[value
                        .length -
                        1] ==
                        '@') {
                      widget.controller. mentionUser =
                      false;
                      widget.controller.update();
                      widget.controller.tempUsername =
                          widget.controller. tempUsername +
                              value[value
                                  .length -
                                  1];
                      print('1   @: ' +
                          widget.controller.tempUsername);
                    } else if (widget.controller.tempUsername !=
                        '' &&
                        value[value.length -
                            1] !=
                            ' ') {
                      widget.controller.tempUsername =
                          widget.controller.tempUsername +
                              value[value
                                  .length -
                                  1];
                      print('2  @ : ' +
                          widget.controller. tempUsername);
                    } else if (value[
                    value.length -
                        1] ==
                        ' ') {
                      print('3   @ :' +
                          widget.controller. tempUsername);
                      widget.controller. tempUsername = '';
                      widget.controller.mentionUser =
                      false;
                      widget.controller. mentionTag =
                      false;
                    }
                    if (widget.controller.tempUsername
                        .length >
                        1) {
                      print('temp value @ : ' +
                          widget.controller.tempUsername);

                      widget.controller. users.clear();
                      widget.controller. users =
                          await widget
                          .controller
                          .searchChatUser(
                            widget.controller. tempUsername
                            .substring(
                            1),
                      );
                      if (widget.controller.users[
                      0] ==
                          false) {
                        widget.controller. users
                            .clear();
                        widget.controller.mentionUser =
                        false;
                        widget.controller.update();
                        // setState(() {});
                      } else {
                        widget.controller.  mentionUser =
                        true;
                        widget.controller.update();
                        // setState(() {});
                      }
                    }*/
                    // _controller[controller.currentIndexText].text=selectedHashTag;
                    ///
                  }
                },
              ),
            ),
          ),
        ],
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 12.0, left: 50, bottom: 4),
        child: Row(
          children: [
            ElevatedButton(
              focusNode: focus2,
              onFocusChange: (bool value) async {
                if (kDebugMode) {
                  print("buttom  ${value}");
                }
                if (value == true) {
                  widget.post.isComment.value = false;
                  widget.post.commentCount.value =
                      widget.post.commentCount.value + 1;
                  if (widget.controller.commentController.text.isNotEmpty) {
                    var response = await widget.controller.createComment(
                        widget.controller.commentController.text, widget.post);
                    if (response['meta']['code'] == 200) {
                      widget.controller.createDeleteComment(
                          widget.post.postId,
                          widget.controller.userProfile.profileImage,
                          widget.controller.commentController.text,
                          "create", {
                        'audio_file_url': null,
                        'audio_path': null,
                        'author': {
                          'firstname': widget.controller.userProfile.firstname,
                          'id': GetStorage().read('id'),
                          'lastname': widget.controller.userProfile.lastname,
                          'profile_image': widget.controller.userProfile == null
                              ? "assets/images/person_placeholder.png"
                              : widget.controller.userProfile.profileImage ?? "assets/images/person_placeholder.png",
                          'username': widget.controller.userName,
                        },
                        'body': response["data"]["body"],
                        'id': response["data"]["id"],
                        'isLiked': false,
                        'postId': response["data"]["post_id"],
                        'replies': [],
                        'repliesCount': 0,
                        'user_id': response["data"]["user_id"],
                        'commented_time_ago': response["data"]
                        ["commented_time_ago"],
                        'created_at': response["data"]["created_at"],
                        'in_reply_to_id': response["data"]["in_reply_to_id"],
                        'language_id': response["data"]["language_id"],
                        'link': null,
                        'link_image': null,
                        'link_meta': null,
                        'link_title': null,
                        'post_type_id': response["data"]["post_type_id"],
                        'processing_status': null,
                        'simple_dislike_count': 0,
                        'simple_like_count': 0,
                        'speech_to_text': null,
                        'status': null,
                        'updated_at': response["data"]["updated_at"],
                      });
                      // widget.post.commentCount.value =
                      //     widget.post.commentCount.value + 1;

                      widget.controller.commentController.clear();
                      widget.post.commentCount.value =
                          widget.post.commentCount.value - 1;

                      widget.controller.isCommentField.value = false;

                      // widget.controller.postList = await widget.controller.getNewsFeed();
                      // widget.controller.update();
                    }


                    // Navigator.pop(context);
                  }
                }
              },
              style: ButtonStyle(
                padding: MaterialStateProperty.all(
                  const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 10,
                  ),
                ),
                shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(40),
                  ),
                ),
                backgroundColor: MaterialStateProperty.all(
                  widget.controller.displayColor,
                ),
              ),
              onPressed: () async {
                widget.post.isComment.value = false;
                widget.post.commentCount.value =
                    widget.post.commentCount.value + 1;


                if (widget.controller.commentController.text.isNotEmpty) {
                  var response = await widget.controller.createComment(
                      widget.controller.commentController.text, widget.post);
                  if (response['meta']['code'] == 200) {
                    widget.controller.createDeleteComment(
                        widget.post.postId,
                        widget.controller.userProfile.profileImage,
                        widget.controller.commentController.text,
                        "create", {
                      'audio_file_url': null,
                      'audio_path': null,
                      'author': {
                        'firstname': widget.controller.userProfile.firstname,
                        'id': GetStorage().read('id'),
                        'lastname': widget.controller.userProfile.lastname,
                        'profile_image': widget.controller.userProfile == null
                            ? "assets/images/person_placeholder.png"
                            : widget.controller.userProfile.profileImage ?? "assets/images/person_placeholder.png",
                        'username': widget.controller.userName,
                      },
                      'body': response["data"]["body"],
                      'id': response["data"]["id"],
                      'isLiked': false,
                      'postId': response["data"]["post_id"],
                      'replies': [],
                      'repliesCount': 0,
                      'user_id': response["data"]["user_id"],
                      'commented_time_ago': response["data"]
                      ["commented_time_ago"],
                      'created_at': response["data"]["created_at"],
                      'in_reply_to_id': response["data"]["in_reply_to_id"],
                      'language_id': response["data"]["language_id"],
                      'link': null,
                      'link_image': null,
                      'link_meta': null,
                      'link_title': null,
                      'post_type_id': response["data"]["post_type_id"],
                      'processing_status': null,
                      'simple_dislike_count': 0,
                      'simple_like_count': 0,
                      'speech_to_text': null,
                      'status': null,
                      'updated_at': response["data"]["updated_at"],
                    });
                    widget.post.commentCount.value =
                        widget.post.commentCount.value - 1;
                    // widget.post.commentCount.value =
                    //     widget.post.commentCount.value + 1;
                    widget.controller.commentController.clear();

                    widget.controller.isCommentField.value = false;

                    // widget.controller.postList = await widget.controller.getNewsFeed();
                    // widget.controller.update();
                  }

                  // Navigator.pop(context);
                }
              },
              child: Text(
                Strings.post,
                style: Styles.baseTextTheme.headline4.copyWith(
                  fontSize: 14,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(width: 20),
            InkWell(
                onTap: () {
                  widget.controller.postList.forEach((element) {
                    element.isComment.value = false;
                  });
                  if (Get
                      .find<BrowseController>()
                      .browsePostList
                      .isNotEmpty &&
                      Get
                          .find<BrowseController>()
                          .browsePostList
                          .length > 0) {
                    Get
                        .find<BrowseController>()
                        .browsePostList
                        .forEach((element) {
                      element.isComment.value = false;
                    });
                  }
                },
                child: Text(
                    Strings.cancel,
                    style: Styles.baseTextTheme.headline4.copyWith(
                      color: Theme
                          .of(context)
                          .brightness == Brightness.dark ? Colors.white : Colors
                          .black,
                      fontSize: 14,
                    ))),
            const SizedBox(width: 60),
            widget.controller.postText
                ? widget.controller.urlOrNot(
                widget.controller.commentController.text)
                ? Expanded(child: urlFetch(widget.controller))
                : Container()
                : Container(),
          ],
        ),
      ),
    );
  }

  Widget urlFetch(NewsfeedController controller) {
    // if(widget.controller.scrapUrl.contains('.com')){
    //   return
    return FutureBuilder<ScrappingData>(
      future: controller.urlScraping(controller.scrapUrl),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return cardScrap(context, snapshot.data);
        } else if (snapshot.hasError) {
          print(snapshot.error.toString());
          return Container();
        }
        return Container(
          child: Center(
            child: CircularProgressIndicator(
              color: MyColors.BlueColor,),
          ),
        );
      },
    );

    // }else{
    //   return Container();
    // }
  }

  Widget cardScrap(BuildContext context, ScrappingData data) {
    // _validURL = true;
    if (data.title != '429 Too Many Requests') {
      return Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: GestureDetector(
          onTap: () {
            // Get.to(MenuListPage(
            //   restaurantId: id,
            // ));
          },
          child: Expanded(
            child: Card(
              elevation: 4,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
              ),
              child: ClipRRect(
                borderRadius: const BorderRadius.all(
                  Radius.circular(5.0),
                ),
                child: SizedBox(
                  height: 80,

                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 0),
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(0.0),
                              image: DecorationImage(
                                  image: data.images[0] != null
                                      ? NetworkImage(data.images[0].toString())
                                      : const AssetImage(
                                      "assets/images/person_placeholder.png"),
                                  fit: BoxFit.cover)),
                        ),
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                const EdgeInsets.only(right: 8.0, top: 8.0),
                                child: InkWell(
                                  onTap: () {},
                                  child: const SizedBox(
                                    height: 4,
                                    child: Align(
                                        alignment: Alignment.topRight,
                                        child: Icon(Icons.cancel)),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 20,
                                  child: Text(data.title.toString(),
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 17,
                                    //   fontWeight: FontWeight.w500,
                                    // )
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontFamily: 'Cairo',
                                      fontSize: 17,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 18,
                                  child: Text(
                                    data.meta.toString(),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    // style: TextStyle(
                                    //   color: Colors.black,
                                    //   fontFamily: 'Cairo',
                                    //   fontSize: 16,
                                    //   fontWeight: FontWeight.w500,
                                    // ),
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.black,
                                      fontFamily: 'Cairo',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 8.00),
                                child: SizedBox(
                                  height: 18,
                                  child: Text(data.link.toString(),
                                    textAlign: TextAlign.left,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: Theme
                                          .of(context)
                                          .brightness == Brightness.dark
                                          ? Colors.white
                                          : Colors.grey[600],
                                      fontFamily: 'Cairo',
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    } else {
      return Container();
    }
  }
}
