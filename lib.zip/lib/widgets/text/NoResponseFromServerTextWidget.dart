import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:werfieapp/utils/strings.dart';

import '../../utils/colors.dart';

class NoResponseFromServerTextWidget extends StatelessWidget {
  const NoResponseFromServerTextWidget({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      padding: const EdgeInsets.all(kIsWeb ? 10 : 20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: kIsWeb ? 50 : 60,
            color: Theme.of(context).brightness == Brightness.dark
                ? Colors.white
                : MyColors.werfieBlue,
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            Strings.noResponseFromServerMsg,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontWeight: kIsWeb ? FontWeight.bold : FontWeight.bold,
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : MyColors.werfieBlue,
                fontSize: kIsWeb ? 18 : 16),
          ),
        ],
      ),
    );
  }
}
