import 'package:flutter/material.dart';
import 'package:werfieapp/models/post.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';

class CommentsListView extends StatelessWidget {
  final Post post;
  final int index;
  final NewsfeedController controller;

  CommentsListView(this.post, this.controller, {this.index});

  final commentTextController = TextEditingController();

  // final DummyData dataController = Get.find();

  @override
  Widget build(BuildContext context) {
    return
      // post.comments.length > 1
      //   ?
      // Obx(
      //       () =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // post.comments.length  <= 2
          //     ? SizedBox()
          //     : TextButton(
          //         onPressed: () async {
          //           controller.postDetail =
          //               await controller.getSingleNewsFeedItem(post.postId);
          //           controller.isTrendsScreen = false;
          //           controller.isNewsFeedScreen = false;
          //           controller.isQuestScreen = false;
          //           controller.isNotificationScreen = false;
          //           controller.isChatScreen = false;
          //           controller.isSavedPostScreen = false;
          //           controller.isPostDetails = true;

          //           controller.update();
          //         },
          //         child:
          //             // !dataController.showAllComments.value
          //             //     ?
          //             Text(
          //           Strings.showMoreComments,
          //           style: TextStyle(
          //             color: Color(0xFF0157d3),
          //           ),
          //         )
          //         // : Text(
          //         //     'Show less comments',
          //         //     style: TextStyle(
          //         //       color: Color(0xFF0157d3),
          //         //     ),
          //         //   ),
          //         ),
          SizedBox(
            height: 6,
          ),
          // Obx((){
          //   return
          controller.isPostDetails
              ? SizedBox()
          // ? ListView.separated(
          //     shrinkWrap: true,
          //     itemBuilder: (context, index) {
          //       return SingleComment(
          //         post,
          //         index,
          //         this.controller,
          //       );
          //     },
          //     separatorBuilder: (context, index) {
          //       return SizedBox(
          //         height: 12,
          //       );
          //     },
          //     itemCount: post.comments.length,
          //   )

              : SizedBox()
          // ;
          // }),
        ],
        // ),
      );
    // : ListView.separated(
    //     physics: NeverScrollableScrollPhysics(),
    //     itemCount: post.comments.length,
    //     separatorBuilder: (context, index) {
    //       return SizedBox(
    //         height: 12,
    //       );
    //     },
    //     shrinkWrap: true,
    //     itemBuilder: (context, index) {
    //       return SingleComment(
    //         post,
    //         index,
    //         this.controller,
    //       );
    //     },
    //   );
  }
}
