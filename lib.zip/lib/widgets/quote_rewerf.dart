import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart' as _dio;
import 'package:dotted_border/dotted_border.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dropzone/flutter_dropzone.dart';
import 'package:flutter_keyboard_visibility/flutter_keyboard_visibility.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:hashtagable/widgets/hashtag_text_field.dart';
import 'package:image_picker/image_picker.dart';
// import 'package:flutter/foundation.dart' show kIsWeb;

import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:werfieapp/components/rounded_button.dart';
import 'package:werfieapp/models/scrapping.dart';
import 'package:werfieapp/network/controller/news_feed_controller.dart';
import 'package:werfieapp/utils/strings.dart';
import 'package:werfieapp/widgets/post_image_description.dart';
import 'package:werfieapp/widgets/post_text_description.dart';
import 'package:werfieapp/widgets/web_createpostModule/create_PostWeb.dart';

import '../dummy_data.dart';
import '../models/FileBytesModel.dart';
import '../models/create_post_model/create_post_model.dart';
import '../models/map_autocomplete_model/map_auto_complete_model.dart';
import '../models/post.dart';
import '../network/controller/google_search_location.dart';
import '../network/singleTone.dart';
import '../screens/your_account_screen.dart';
import '../utils/colors.dart';
import '../utils/emojis.dart';
import '../utils/font.dart';
import '../utils/utils_methods.dart';
import 'chewie_videoplayer.dart';


// ignore: must_be_immutable

var argumentData = Get.arguments;

class QuoteRewerf extends StatefulWidget {
  bool isPostScheduled = false;
  DateTime dateTimeData;
  List postsForDeletions = [];
  bool mentionUser = false;
  bool mentionTag = false;
  final GlobalKey<ScaffoldState> _scaffoldKey;
  Post post;

  // ignore: unused_field
  // final GlobalKey<ScaffoldState> _scaffoldKey;
  final NewsfeedController controller;
  final String profileImageUrl;
  List<dynamic> users = [];
  List<dynamic> tags = [];
  String werfUsername;
  String werfName;
  String werfProfileImage;
  String postType;

  var focusNode = FocusNode();

  QuoteRewerf(this._scaffoldKey, this.controller, this.profileImageUrl,
      {this.werfName,
        this.werfProfileImage,
        this.postType,
        this.werfUsername,
        this.post});

  @override
  _QuoteRewerfState createState() => _QuoteRewerfState();
}

class _QuoteRewerfState extends State<QuoteRewerf>
    with SingleTickerProviderStateMixin {
  int isEditCheckForImage = -1;
  int isEditCheckForPdf = 0;
  int isEditCheckForVideo = 0;
  bool isEdit = false;
  int postId = 0;
  List EditimageThumbnailsList = [];

  ScrollController scrollController = ScrollController();

  bool visibility = false;
  bool threadCreated = false;
  bool closeIcon = false;


  // int listLength = 20;
  List<FocusNode> fNode1 = List<FocusNode>.generate(
      20, (int index) => FocusNode());
  List<FocusNode> fNode2 = List<FocusNode>.generate(
      20, (int index) => FocusNode());

  FocusNode focusNodeText = FocusNode();
  FocusNode focusNode = FocusNode();

  //
  // List<FocusNode> fNode1 ;
  // List<FocusNode> fNode2;


  var checkFocus = false.obs;
  bool editImageCheck = false;

  /// emojis variable
  bool isEmojiVisible = false;
  bool isKeyboardVisible = false;
  int _selectedTab = 0;
  StreamSubscription<bool> keyboardSubscription;
  TabController _tabController;
  List<bool> showPolls = [];
  ScrollController _scrollController;

  bool isPortrait = false;
  double width = 0,
      height = 0;


  List<TextEditingController> _controller = List.generate(
      30, (i) => TextEditingController());

  // List<TextEditingController> _controller = [];

  var controller = Get.find<NewsfeedController>();

  List<PlatformFile> _paths;
  List<PlatformFile> listFiles = [];
  bool _loadingPath = false;
  final bool _multiPick = true;
  bool isTagSelected = false;

  @override
  void initState() {
    // controller.modelList2[0].imageCounter=0;
    // controller.modelList2[0].descriptionCounter = 0;
    // if(controller.modelList2[0].imageDescriptionController.length>0){
    //
    //   controller.modelList2[0].imageDescriptionController.forEach((element) {
    //     element.clear();
    //   });
    // }

    fNode2[0].requestFocus();

    controller.usersList = [];
    // for (int i = 0; i < 30; i++) _controller.add(TextEditingController());
    bool b = false;
    for (int i = 0; i < 30; i++) {
      showPolls.add(b);
    }
    widget.dateTimeData = DateTime.now();
    _tabController = TabController(vsync: this, length: emojis.length);
    _scrollController = ScrollController();
    var keyboardVisibilityController = KeyboardVisibilityController();
    keyboardSubscription =
        keyboardVisibilityController.onChange.listen((bool visible) {
          if (visible && isEmojiVisible) {
            isEmojiVisible = false;
            if (this.mounted) {
              // check whether the state object is in tree
              setState(() {
                // make changes here
              });
            }
          } else {}
        });

    // if (widget.post != null) {
    //   // controller.modelList2[0].postId = widget.post.postId;
    //
    //   widget.controller.postText = true;
    //   isEdit = true;
    //   print(isEdit);
    //   postId = widget.post.postId;
    //   print("widget post ${widget.post.type}");
    //   if (widget.post.body.isNotEmpty) {
    //     print("bodyy");
    //     _controller[0].text = widget.post.body;
    //     postTextController.text = widget.post.body;
    //     print(widget.post.body);
    //     print(widget.controller.modelList2[0].bodyText);
    //   }
    //   if (widget.post.location != null) {
    //     controller.modelList2[0].location = widget.post.location;
    //     controller.modelList2[0].lat = widget.post.lat;
    //     controller.modelList2[0].lng = widget.post.lng;
    //
    //     print(widget.controller.modelList2[0].location);
    //     print(widget.controller.modelList2[0].lat);
    //     print(widget.controller.modelList2[0].lng);
    //
    //     print("location");
    //     SingleTone.instance.selectedLocation = widget.post.location;
    //   }
    //   if (widget.post.postFiles.isNotEmpty) {
    //     print(" widget  ${widget.post.postFiles}");
    //
    //     if (widget.post.postFiles[0]["file_type"] == "image") {
    //       widget.post.postFiles.forEach((element) {
    //         imageThumbnail = element["file_path"];
    //         EditimageThumbnailsList.add(imageThumbnail);
    //
    //         imageThumbnailsList.add(imageThumbnail);
    //
    //         print(widget.post.postFiles);
    //         isEditCheckForImage = 0;
    //         editImageCheck = true;
    //         controller.modelList2[controller.currentIndexText].isImageAttached  = true;
    //         isEdit = true;
    //         print('bool check$isMediaAttached');
    //         print('bool check edit image:$editImageCheck');
    //         print(" list of images ${imageThumbnailsList}");
    //       });
    //
    //       int length = widget.post.postFiles.length;
    //       print("length: $length");
    //       // var details = new Files();
    //       int length3 = imageThumbnailsList.length;
    //       print("length4546: $length3");
    //
    //       print("inside if");
    //
    //       for (int i = 0; i < length3; i++) {
    //         // print(" inside condition media data");
    //         // details['url'] = imageThumbnailsList[i];
    //         // details['thumbnail_url'] = widget.post.postFiles[i]["thumbnail_url"];
    //         // details['name'] = widget.post.postFiles[i]["original_name"];
    //         // details['size'] =  widget.post.postFiles[i]["size"];
    //         controller.modelList2[0].mediaData2.add(Files.fromJson({
    //           'url': imageThumbnailsList[i],
    //           'thumbnail_url': widget.post.postFiles[i]["thumbnail_url"],
    //           'name': widget.post.postFiles[i]["original_name"],
    //           'size': widget.post.postFiles[i]["size"],
    //         }));
    //
    //         controller.modelList2[0].mediaData2.forEach((element) {
    //           print("Data");
    //           print(element.url);
    //           print(element.size);
    //           print(element.name);
    //           print(element.thumbnailUrl);
    //         });
    //       }
    //     } else if (widget.post.postFiles[0]["file_type"] == "attachment") {
    //       pdfName = widget.post.postFiles[0]["file_path"];
    //       isEditCheckForPdf = 1;
    //       widget.controller.mediaData.clear();
    //       print(widget.controller.mediaData);
    //       print("attach");
    //       controller.modelList2[controller.currentIndexText].isMediaAttached  = true;
    //       print("pdf ${pdfName}");
    //       controller.modelList2[0].mediaData2.add(Files.fromJson({
    //         'url': pdfName,
    //         'thumbnail_url': widget.post.postFiles[0]["thumbnail_path"],
    //         'name': widget.post.postFiles[0]["original_name"],
    //         'size': widget.post.postFiles[0]["size"],
    //       }));
    //     } else if (widget.post.postFiles[0]["file_type"] == "video") {
    //       videoThumbnail = widget.post.postFiles[0]["file_path"];
    //
    //       controller.modelList2[controller.currentIndexText].isMediaAttached  = true;
    //       print("video ${videoThumbnail}");
    //
    //       controller.modelList2[0].mediaData2.add(Files.fromJson({
    //         'url': videoThumbnail,
    //         'thumbnail_url': widget.post.postFiles[0]["thumbnail_path"],
    //         'name': widget.post.postFiles[0]["original_name"],
    //         'size': widget.post.postFiles[0]["size"],
    //       }));
    //
    //       controller.modelList2[0].mediaData2.forEach((element) {
    //         print("Data");
    //         print(element.url);
    //         print(element.size);
    //         print(element.name);
    //         print(element.thumbnailUrl);
    //       });
    //     }
    //   }
    // }
    // else {
    controller.modelList2 = [];
    controller.modelList2.add(ModelClass.fromJson({
      'body': '',
      'poll_ques_first': null,
      'poll_ques_first': null,
      'poll_ques_third': null,
      'poll_ques_fourth': null,
      //  selectType: "Public",
      'files': [],
      'link_meta': '',
      'link': '',
      'link_image': '',
      'link_title': '',
      'days': '',
      'minutes': '',
      'hours': '',
      'location': '',
      'lat': '',
      'lng': '',
      'poll_thread': false,
      'type': 'quote',
      "quote_id": widget.post.postId.toString()
    }));
    //print("hello");
    widget.controller.postText = false;
    isEditCheckForImage = -1;
    isEdit = false;
    //print("isCheckEdit: $isEditCheckForImage");
    //}

    super.initState();
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        //print("hello");

        //print(checkFocus);

        checkFocus.value = true;

        controller.postText = true;
        controller.update();

        print(checkFocus);
      } else {
        checkFocus.value = false;
        print(checkFocus);
      }
    });

    selectedDateTime = DateTime.now().toString();
    // if (int.parse(selectedMonthValue) < 10) {
    //   selectedMonthValue = "0" + selectedMonthValue;
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }
    // if (int.parse(selectedDayValue) < 10) {
    //   selectedDayValue = "0" + selectedDayValue;
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }
    // if (int.parse(selectedHourValue) < 10) {
    //   selectedHourValue = "0" + selectedHourValue;
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }
    // if (int.parse(selectedMinutesValue) < 10) {
    //   selectedMinutesValue = "0" + selectedMinutesValue;
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }
    //   else {
    //   selectedDateTime =
    //       "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
    //           " $selectedHourValue:$selectedMinutesValue:00";
    // }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    _controller[widget.controller.currentIndexText].addListener(() {
      if (_controller[widget.controller.currentIndexText].text.isNotEmpty) {
        controller.postText = true;
        controller.update();
    controller.modelList2[widget.controller.currentIndexText].bodyText =
            _controller[widget.controller.currentIndexText].text;
      } else {
        controller.postText = false;
        controller.update();
      }
    });
    controller.peopleList = controller.peopleList;

    width = MediaQuery
        .of(context)
        .size
        .width;
    height = MediaQuery
        .of(context)
        .size
        .height;
    isPortrait = height > width ? true : false;
    _tabController.addListener(() {
      _selectedTab = _tabController.index;
      if (!isPortrait) {
        _scrollController.jumpTo(_selectedTab * height * .075);
      }
      if (this.mounted) {
        // check whether the state object is in tree
        setState(() {
          // make changes here
        });
      }
      // setState(() {});
    });
  }

  /// controllers dispose
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  /* List<XFile> pickedFile =  await dataController.multiImageSelected();



  // PickedFile pickedFile = await dataController.getImage();

    widget.controller.postText = true;
   // widget.controller.update();

    //imageBytes = await pickedFile.readAsBytes();

    */
  /*
    isMediaUploading = true;
    await controller.multiImageSeleted(userData);
    Get.back();
    print("pick image ${imageThumbnailsList}");
    visibility = true;
    isMediaUploading = false;
    isMediaAttached = false;
    setState((){
    });


    // if (imageBytes != null) {
    //   _pickedImage.insert(0, imageBytes);
    //   isMediaUploading = true;
    //   setState(() {
    //
    //   });
    //   print('NAHI ATA IDHAR');
    //   imageThumbnailsList =  await controller.multiImageSeleted(pickedFile);
    //   Get.back();
    // //  imageThumbnailsList.add(imageThumbnail);
    //   imageThumbnail = '';
    //   imageBytes.toList().clear();
    //   print('I D H A R A J A T A H A I');
    //   print("pick image ${imageThumbnailsList}");
    //   visibility = true;
    //   isMediaUploading = false;
    //    isMediaAttached = false;
    //   setState((){
    //
    //   });
    //
    // }
  }*/

  GoogleSearchLocation locationController = Get.put(GoogleSearchLocation());

  final DummyData dataController = Get.find();
  bool isMediaUploading = false;

  var postTextController = TextEditingController();
  String link, linkTitle, linkMeta, linkImage;
  String scheduleMonthValue = DateTime
      .now()
      .month
      .toString();
  String scheduleDayValue = DateTime
      .now()
      .day
      .toString();
  String scheduleYearValue = DateTime
      .now()
      .year
      .toString();
  String scheduleHourValue = DateTime
      .now()
      .hour
      .toString();
  String selectedMonthValue = DateTime
      .now()
      .month
      .toString();
  String selectedDayValue = DateTime
      .now()
      .day
      .toString();
  String selectedYearValue = DateTime
      .now()
      .year
      .toString();
  String selectedHourValue = DateTime
      .now()
      .hour
      .toString();

  String scheduleMinutesValue = DateTime
      .now()
      .minute
      .toString();
  String selectedMinutesValue = DateTime
      .now()
      .minute
      .toString();
  bool monthValidatedSuccessfully = true;
  bool dayValidatedSuccessfully = true;
  bool hourValidatedSuccessfully = true;
  bool minutesValidatedSuccessfully = true;
  bool showScheduledWerfs = false;
  bool isEditable = false;
  bool isCheckBoxSelected = false;
  List<Uint8List> _pickedImage = [];
  List<Uint8List> _pickedPdfs = [];
  File _pickedVideo;
  PlatformFile _pickedDocument;
  bool isMediaAttached = false;

  bool isImageAttached = false;

  File videoPicker;
  File pickedMedia;
  Uint8List pickedAudio;
  PickedFile pickedMediaFile;
  Uint8List imageBytes, videoBytes, pdfBytes;
  List<String> _pdfFilesName = [];
  Map<String, dynamic> _pdfs;
  PickedFile singleVideoFile;
  List<File> videoFiles = [];
  List<Uint8List> _pickedVideos = [];
  List<String> _pickedVideosName = [];
  List<String> _pickedVideosMemeType = [];

  List<Uint8List> _pickedAudios = [];

  // ignore: unused_field
  bool _validURL = false;

  // bool showPolls = false;
  int option = 2;
  bool onHover = false;
  bool isOptionThree = false;
  bool isOptionTwo = true;
  List<int> days = [0, 1, 2, 3, 4, 5, 6, 7];
  bool saveCard = false;
  String pollDays = '0';
  String pollHours = '0';
  String pollMinutes = '0';
  String pollQuestionOne, pollQuestionTwo, pollQuestionThree, pollQuestionFour;
  String txtOption1 = '';
  String txtOption2 = '';
  String txtOption3 = '';
  String txtOption4 = '';
  bool apiCalled = false;
  String videoThumbnail = '';
  String imageThumbnail = '';
  String pdfName = '';
  String audioUrl = '';
  List imageThumbnailsList = [];
  String temp = '';
  String tempValue = '';
  String selectedHashTag = '';
  String tempUsername = '';
  final ScrollController scrollControllerBehaviour = ScrollController();
  List<int> years = [2022, 2023, 2024];
  List<String> months = [
    'Jan',
    'Feb',
    'Mar',
    'April',
    'May',
    'June',
    'July',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  List<int> minutes = [
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
    33,
    34,
    35,
    36,
    37,
    38,
    39,
    40,
    41,
    42,
    43,
    44,
    45,
    46,
    47,
    48,
    49,
    50,
    51,
    52,
    53,
    54,
    55,
    56,
    57,
    58,
    59
  ];


  DropzoneViewController dropzoneViewController;


  int counter = 0;


  bool dragValue = false;


  acceptFile(dynamic event) async {
    if (dragValue == true) {
      dragValue = false;
      setState(() {

      });
    }

    // listFiles = [];

    print(event);

    final bytes = await dropzoneViewController.getFileData(event);
    final mime = await dropzoneViewController.getFileMIME(event);
    final name = await dropzoneViewController.getFilename(event);


    var fileType = mime.split('/');
    // print('file type ${fileType[0]}');


    List<_dio.MultipartFile> files = [];
    List<FileBytesModel> listFiles =[];


    if (fileType[0] == "image" &&
        controller.modelList2[controller.currentIndexText].isMediaAttached ==
            false) {
      files.add(_dio.MultipartFile.fromBytes(bytes, filename: name));
      listFiles.add(FileBytesModel(bytes, name));
      // print('file type ${mime}');
      // counter++;
      // print(counter);
      print(
          "image sdfsdfsdf ${controller.modelList2[controller.currentIndexText]
              .mediaData2.length}");

      print(files);
      dragGetImage(files,listFiles);
    }
    else if (fileType[0] == "video" &&
        controller.modelList2[controller.currentIndexText].mediaData2.length ==
            0 &&
        controller.modelList2[controller.currentIndexText].isImageAttached ==
            false && isMediaUploading == false) {
      // print("video pr aya hai");
      // print('file type ${fileType[0]}');
      dragGetVideo(bytes,mime,name);
    }
    else
    if (controller.modelList2[controller.currentIndexText].mediaData2.length ==
        0 &&
        controller.modelList2[controller.currentIndexText].isImageAttached ==
            false && isMediaUploading == false) {
      print("bbbbb  ${controller.modelList2[controller.currentIndexText]
          .mediaData2.length}");

      _pdfs = {'fileBytes': bytes, 'pdfFileName': name, 'pdfFileExt': mime};
      dragGetFile(_pdfs);
    }
    else {
      controller.update();

      UtilsMethods.toastMessageShow(
        controller.displayColor,
        controller.displayColor,
        controller.displayColor,
        message: Strings.pleaseChooseEither1VideoOr1Pdf,

      );
    }
  }

  String selectedDateTime;

  dragGetImage(List<_dio.MultipartFile> files, List<FileBytesModel> listFiles) async {
    // listFiles = [];


    controller.modelList2[controller.currentIndexText].isImageAttached = true;

    setState(() => _loadingPath = true);

    if (!mounted) return;
    setState(() {
      _loadingPath = false;
    });

    // files = listFiles.map((path) => _dio.MultipartFile.fromBytes(path.bytes, filename: path.name,))
    //     .toList();
    if (kDebugMode) {
      print(files.length);
    }
    Map<String, dynamic> userData = {};
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }
    // setState(() {
    //
    // });

    isMediaUploading = true;
    await controller.multiImageSeleted(userData, 1,null,listBytes: listFiles);

    widget.controller.postText = true;

    widget.controller.update();

    widget.controller.mediaApiCheck = false;
    print('image from api url:${imageThumbnail}');
    imageThumbnailsList.add(imageThumbnail);
    print(imageThumbnailsList);
    print('I D H A R A J A T A H A I');
    // isMediaAttached = true;
    visibility = true;
    isMediaUploading = false;
    setState(() {});
  }

  dragGetVideo(var videoBytes,String memeType,String name) async {
    widget.controller.postText = true;
    widget.controller.update();

    if (videoBytes != null) {
      _pickedVideos.add(videoBytes);
      _pickedVideosName.add(name);
      _pickedVideosMemeType.add(memeType);

      isMediaUploading = true;
      setState(() {});
      videoThumbnail =
      await Get.find<NewsfeedController>().uploadMedia(_pickedVideos[0], 1,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
      widget.controller.mediaApiCheck = false;

      if (videoThumbnail != null) {
        print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          controller.modelList2[controller.currentIndexText].isMediaAttached =
          true;
          isMediaUploading = false;
        });
      } else {
        print('IN ELSE BLOCK');
      }
    }
  }

  dragGetFile(Map<String, dynamic> _pdfs) async {
    // _pdfs = await dataController.getFile();

    widget.controller.postText = true;
    widget.controller.update();

    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (!ext.contains('pdf')) {
        UtilsMethods.toastMessageShow(
          controller.displayColor,
          controller.displayColor,
          controller.displayColor,
          message: Strings.fileTypeIsNotAllowed,
        );
      } else {
        isMediaUploading = true;
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        setState(() {});
        pdfName = await Get.find<NewsfeedController>().uploadMedia(
            _pickedPdfs[0], 1, type: 'file', fileName: _pdfFilesName[0],fileType: 'pdf');
        widget.controller.mediaApiCheck = false;

        controller.modelList2[controller.currentIndexText].isMediaAttached =
        true;
        print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;

        setState(() {});
      }
    }
  }

  callGetImage() async {
    // isImageAttached = true;

    listFiles = [];

    setState(() => _loadingPath = true);
    try {
      _paths = (
          await FilePicker.platform.pickFiles(
            type: FileType.custom,
            allowedExtensions: ['jpg', 'jpeg', 'png', 'webp'],
            allowMultiple: _multiPick,
          ))?.files;
      if (_paths == null || _paths.isEmpty) {
        setState(() => _loadingPath = false);
        return;
      }
    } on PlatformException catch (e) {
      if (kDebugMode) {
        print("Unsupported operation" + e.toString());
        setState(() => _loadingPath = false);
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      setState(() => _loadingPath = false);
    }
    if (!mounted) return;
    setState(() {
      _loadingPath = false;
      if (kDebugMode) {
        print(_paths.first.extension);
        print(_paths.first.size);
      }
      // if (_paths.first.size > 1999999) {
      //   print("File size must not exceed 2 MB");
      // } else {
      listFiles.addAll(_paths);
      print(listFiles.length.toString() + "images length");
      // }
    });

    List<_dio.MultipartFile> files = [];
    files = listFiles.map((path) =>
        _dio.MultipartFile.fromBytes(path.bytes, filename: path.name,))
        .toList();
    if (kDebugMode) {
      print(files.length);
    }
    Map<String, dynamic> userData = {};
    if (files.isNotEmpty) {
      userData.addAll({'files[]': files});
    }
    // setState(() {
    //
    // });

    isMediaUploading = true;
    await controller.multiImageSeleted(userData, 1,listFiles);

    widget.controller.postText = true;
    controller.modelList2[controller.currentIndexText].isImageAttached = true;
    widget.controller.update();

    widget.controller.mediaApiCheck = false;
    print('image from api url:${imageThumbnail}');
    imageThumbnailsList.add(imageThumbnail);
    print(imageThumbnailsList);
    print('I D H A R A J A T A H A I');
    // isMediaAttached = true;
    visibility = true;
    isMediaUploading = false;
    setState(() {});
  }

  callGetVideo() async {
    // File pickedMedia;
    Map<String,dynamic> map = await dataController.getVideo();
    videoBytes = await map['bytes'];

    widget.controller.postText = true;

    widget.controller.update();
    // _pickedVideo = pickedMedia.path;
    // print(videoBytes.toString());
    // _pickedImage.add(videoBytes);
    // _pickedVideos.add(videoBytes);
    print(_pickedImage);
    if (videoBytes != null) {
      _pickedVideos.add(videoBytes);
      _pickedVideosName.add(map['name']);
      _pickedVideosMemeType.add(map['memeType']);

      isMediaUploading = true;

      setState(() {});
      videoThumbnail =
      await Get.find<NewsfeedController>().uploadMedia(_pickedVideos[0], 1,fileType: 'mp4',fileName: _pickedVideosName[0],memeType: _pickedVideosMemeType[0]);
      widget.controller.mediaApiCheck = false;

      if (videoThumbnail != null) {
        print('IN CREATE POST ' + videoThumbnail);
        setState(() {
          visibility = true;
          controller.modelList2[controller.currentIndexText].isMediaAttached =
          true;
          // isMediaAttached = true;
          isMediaUploading = false;
        });
      } else {
        print('IN ELSE BLOCK');
      }
    }
  }

  callGetFile() async {
    _pdfs = await dataController.getFile();

    widget.controller.postText = true;
    widget.controller.update();
    // pickedMedia = await dataController.getImageWeb();
    // _pickedPdfs.add(_pdfs['fileBytes']);
    // _pdfFilesName.add(_pdfs['pdfFileName']);
    // print('NAHI ATA IDHAR');
    if (_pickedPdfs != null && _pdfFilesName != null) {
      String ext = _pdfs['pdfFileExt'].toString();

      if (ext!='pdf') {
        UtilsMethods.toastMessageShow(
          controller.displayColor,
          controller.displayColor,
          controller.displayColor,
          message: Strings.fileTypeIsNotAllowed,
        );
      } else {
        isMediaUploading = true;
        _pickedPdfs.add(_pdfs['fileBytes']);
        _pdfFilesName.add(_pdfs['pdfFileName']);
        setState(() {});
        pdfName = await Get.find<NewsfeedController>().uploadMedia(
            _pickedPdfs[0], 1,
            type: 'file',
            fileName: _pdfFilesName[0],fileType: 'pdf');
        widget.controller.mediaApiCheck = false;

        controller.modelList2[controller.currentIndexText].isMediaAttached =
        true;
        //isMediaAttached = true;
        print(_pickedPdfs.length);
        isMediaUploading = false;
        visibility = true;

        setState(() {});
      }
    }
  }

  callGetAudio() async {
    pickedAudio = await dataController.getAudio();
    // print(pickedAudio.path);

    if (pickedAudio != null) {
      isMediaUploading = true;

      _pickedAudios.add(pickedAudio);
      setState(() {});
      audioUrl =
      await Get.find<NewsfeedController>().uploadMedia(_pickedAudios[0], 1,fileType: 'mp3');

      // isMediaAttached = true;
      isMediaUploading = false;

      setState(() {});
    } else {
      print('NANANANANA');
    }
  }

  buildPollOptions({@required int optionNumber, //  @required int indexOf
  }) {
    if (optionNumber == 1 || optionNumber == 4) {
      return Padding(
        padding: EdgeInsets.only(top: 6.0, bottom: 6.0, right: 34, left: 10),
        child: TextFormField(
          onChanged: (value) {
            if (optionNumber == 1) {
              //  txtOption1[controller.currentIndexText]=value;
              controller.modelList2[controller.currentIndexText]
                  .poll_ques_first = value;
              //  print('value pool ${txtOption1[controller.currentIndexText]}');
              print(
                  'model values in pool 1: ${controller.modelList2[controller
                      .currentIndexText].poll_ques_first}');
            } else {
              //  txtOption4[controller.currentIndexText]=value;
              controller.modelList2[controller.currentIndexText]
                  .poll_ques_fourth = value;
              // print('value pool ${txtOption4[controller.currentIndexText]}');
              print(
                  'model values in pool 4: ${controller.modelList2[controller
                      .currentIndexText].poll_ques_fourth}');
            }
          },
          // controller: optionNumber == 1 ? txtOption1 : txtOption4,
          inputFormatters: [
            LengthLimitingTextInputFormatter(25),
          ],
          style: Styles.baseTextTheme.headline4.copyWith(
            color: Get.isDarkMode?Colors.white
                : Colors.black,
            fontSize: 14,
          ),
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            labelText: '${Strings.choice} $optionNumber',
            labelStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Get.isDarkMode? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            hintText: optionNumber == 4
                ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                : '${Strings.choice} $optionNumber',
            hintStyle: Styles.baseTextTheme.headline4.copyWith(
              color: Get.isDarkMode? Colors.white
                  : Colors.black,
              fontSize: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: const BorderRadius.all(
                const Radius.circular(0.0),
              ),
              borderSide: BorderSide(
                width: 1,
                style: BorderStyle.none,
                color: Get.isDarkMode? Colors.white
                    : Colors.grey,
              ),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.only(
          top: 8.0,
          bottom: 8.0,
          left: 10,
          right: optionNumber == 2 && !isOptionTwo
              ? 34
              : option == 3 || option == 2 && isOptionTwo
              ? 10
              : option == 3 && !isOptionTwo
              ? 34
              : 34),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              onChanged: (value) {
                if (optionNumber == 2) {
                  // txtOption2[controller.currentIndexText]=value;
                  controller.modelList2[controller.currentIndexText]
                      .poll_ques_second = value;
                  print(
                      'model values in pool 2: ${controller
                          .modelList2[controller.currentIndexText]
                          .poll_ques_second}');
                } else {
                  // txtOption3[controller.currentIndexText]=value;
                  controller.modelList2[controller.currentIndexText]
                      .poll_ques_third = value;
                  print(
                      'model values in pool 3: ${controller
                          .modelList2[controller.currentIndexText]
                          .poll_ques_third}');
                }

                setState(() {});
              },
              // controller: optionNumber == 2 ? txtOption2 : txtOption3,
              inputFormatters: [
                LengthLimitingTextInputFormatter(25),
              ],
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: const BorderRadius.all(
                    const Radius.circular(0.0),
                  ),
                  borderSide: BorderSide(
                    width: 1,
                    style: BorderStyle.none,
                    color: Get.isDarkMode? Colors.white
                        : Colors.grey,
                  ),
                ),
                contentPadding:
                EdgeInsets.symmetric(horizontal: 6, vertical: 6),
                labelText: '${Strings.choice} $optionNumber',
                labelStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Get.isDarkMode? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
                hintText: optionNumber == 3
                    ? '${Strings.choice} $optionNumber' + '${Strings.optionalPoll}'
                    : '${Strings.choice} $optionNumber',
                hintStyle: Styles.baseTextTheme.headline4.copyWith(
                  color: Get.isDarkMode? Colors.white
                      : Colors.black,
                  fontSize: 14,
                ),
              ),
              style: Styles.baseTextTheme.headline4.copyWith(
                color: Get.isDarkMode? Colors.white
                    : Colors.black,
                fontSize: 14,
              ),
            ),
          ),
          optionNumber == 2 && option == 2 && isOptionTwo
              ? Align(
            alignment: Alignment.topCenter,
            child: InkWell(
              onTap: () {
                option = optionNumber + 1;
                isOptionTwo = false;
                setState(() {});
              },
              child: Icon(
                Icons.add,
                color: Get.isDarkMode? Colors.white
                    : Colors.black,
              ),
            ),
          )
              : SizedBox(),
          !isOptionTwo && option == 3 && optionNumber == 3
              ? Align(
            alignment: Alignment.topCenter,
            child: InkWell(
              onTap: () {
                option = optionNumber + 1;
                isOptionTwo = false;
                setState(() {});
              },
              child: Icon(
                Icons.add,
                color: Get.isDarkMode? Colors.white
                    : Colors.black,
              ),
            ),
          )
              : SizedBox(),
        ],
      ),
    );
  }

  static List<String> getHashTags(String text) {
    RegExp reg = RegExp(
        r"([#])\w+|(https?|ftp|file|#)://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]*");
    Iterable<Match> _matches = reg.allMatches(text);
    List<String> resultMatches = <String>[];
    for (Match match in _matches) {
      if (match
          .group(0)
          .isNotEmpty) {
        var tag = match.group(0);
        resultMatches.add(tag);
      }
    }
    return resultMatches;
  }

  @override
  Widget build(BuildContext context) {
    String getDate;
    if (saveCard == true) {
      getDate = UtilsMethods.getDate(widget.post.saveCreateAt);
    }
    else {
      getDate = UtilsMethods.getDate(widget.post.postedOn);
    }

    final cross = (MediaQuery
        .of(context)
        .size
        .width * .025).round();
    print('CHECK BOOLEAN ' + widget.isPostScheduled.toString());
    print("checkFocus${checkFocus}");

    return
      RawKeyboardListener(
          autofocus: true,
          focusNode: FocusNode(),
          onKey: (event) {
            if (event.isKeyPressed(LogicalKeyboardKey.escape)) {
              Navigator.of(context).pop();
            }
          },
          child: Container(
            height: 650,
            width: 800 /* MediaQuery.of(context).size.width * 0.4*/,
            child: Scaffold(
              body: Container(
                padding: EdgeInsets.only(bottom: 8),
                child: apiCalled
                    ? Center(
                  child: Container(
                      height: 300,
                      width: 300,
                      padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                      alignment: Alignment.center,
                      child: SizedBox(
                        height: 40,
                        width: 40,
                        child: CircularProgressIndicator(
                          color: MyColors.BlueColor,
                          // value: 40,
                        ),
                      )),
                )
                    :
                Theme(
                  data: ThemeData(scrollbarTheme: ScrollbarThemeData(
                      radius: Radius.circular(10),
                      thumbColor: MaterialStateProperty.all(Colors.black26),
                      trackColor: MaterialStateProperty.all(Colors.black12),
                      trackBorderColor: MaterialStateProperty.all(
                          Color(0xFFf7f9f9)),
                      showTrackOnHover: true,
                      trackVisibility: MaterialStateProperty.all(true),
                      thickness: MaterialStateProperty.all(7),
                      minThumbLength: 100)),
                  child: SingleChildScrollView(
                    child: Stack(
                      // overflow: Overflow.visible,
                      children: [

                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          //  mainAxisSize: MainAxisSize.min,
                          children: [


                            SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  child: Text(
                                   Strings.rewerf,
                                    style:
                                    Styles.baseTextTheme.headline2.copyWith(
                                      color: Get.isDarkMode? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      // fontSize: 16,
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 50,
                                  padding: EdgeInsets.only(right: 15),
                                  child: Align(
                                    // alignment: Alignment.topRi,
                                    child: CircleAvatar(
                                      radius: 11,
                                      backgroundColor:
                                      Get.isDarkMode? Colors.white
                                          : Colors.black,
                                      child: CircleAvatar(
                                        radius: 10,
                                        backgroundColor:
                                        Get.isDarkMode? Colors.black
                                            : Colors.white,
                                        child: IconButton(
                                          highlightColor: Colors.transparent,
                                          splashColor: Colors.transparent,
                                          hoverColor: Colors.transparent,
                                          padding: EdgeInsets.all(0),
                                          icon: Icon(
                                            Icons.close,
                                            color: Get.isDarkMode? Colors.white
                                                : Colors.black,
                                            size: 14,
                                          ),
                                          onPressed: () {
                                            widget.controller.mediaApiCheck =
                                            false;
                                            SingleTone.instance
                                                .selectedLocation =
                                            null;
                                            setState(() {});
                                            Navigator.of(context).pop();
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            ///threading

                            widget.controller.mediaApiCheck == true
                                ? Center(
                              child: Container(
                                  height: 300,
                                  width: 300,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 5),
                                  alignment: Alignment.center,
                                  child: SizedBox(
                                    height: 40,
                                    width: 40,
                                    child: CircularProgressIndicator(
                                      color: MyColors.BlueColor,
                                      // value: 40,
                                    ),
                                  )),
                            )
                                : Stack(
                              children: [
                                Container(
                                  height: 400,
                                  width: 500,
                                  padding: EdgeInsets.only(top: 10, bottom: 10),
                                  child: DottedBorder(
                                    color: dragValue == true
                                        ? Colors.blue
                                        : Colors.transparent,
                                    dashPattern: [8, 4],
                                    radius: Radius.circular(5),
                                    strokeWidth: 1,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(

                                        children: [
                                          Expanded(
                                            child:

                                            kIsWeb ?


                                            DropzoneView(

                                              operation: DragOperation.copy,
                                              cursor: CursorType.grab,
                                              onHover: () {
                                                print(
                                                    controller
                                                        .currentIndexText);

                                                print("asdasd");

                                                if (dragValue == false) {
                                                  dragValue = true;
                                                  setState(() {

                                                  });
                                                }
                                              },
                                              onLeave: () {
                                                if (dragValue == true) {
                                                  dragValue = false;
                                                  setState(() {

                                                  });
                                                }
                                              },
                                              onLoaded: () =>
                                                  print(""),
                                              onError: (err) =>
                                                  print(
                                                      ''),
                                              // onDropMultiple: acceptFile ,
                                              onDrop: acceptFile,
                                              // onDropMultiple:acceptMultipleFile ,
                                              onCreated: (controller) =>
                                              this.dropzoneViewController =
                                                  controller,

                                            ) : Container(),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),

                              ConstrainedBox(
                                constraints: BoxConstraints(

                                  minWidth: 500 /*MediaQuery.of(context).size.width * 0.4*/,
                                  minHeight: 500,
                                  maxWidth: 500 /*MediaQuery.of(context).size.width * 0.4*/,
                                  maxHeight: 500,
                                ),
                                child: ListView.builder(

                                  itemCount: 1,
                                  itemBuilder: (context, ind) {
                                    print("ind $ind");
                                    return


                                        InkWell(
                                          focusColor: Colors.transparent,
                                          onTap: () {},
                                          onHover: (value) {
                                            controller.currentIndexText = ind;


                                            print(
                                                "controller.currentIndexText ${controller
                                                    .currentIndexText}");
                                            setState(() {

                                            });
                                            controller.update();
                                          },
                                          child: Container(
                                            margin: EdgeInsets.all(5),
                                            child: GestureDetector(
                                              onTap: () {
                                                widget.controller
                                                    .currentIndexText = ind;
                                                setState(() {});
                                              },
                                              child:

                                              Column(
                                                children: [


                                                  ///  scdeudle  widget
                                                  widget.isPostScheduled
                                                      ? ListTile(
                                                    minVerticalPadding: 0.0,
                                                    horizontalTitleGap: 0.0,
                                                    leading: Container(
                                                      width: 20,
                                                      height: 20,
                                                      child:
                                                      SvgPicture.asset(
                                                        // _pickedPdfs.length > 0 ||
                                                        //     _pickedAudios.length > 0 ||
                                                        //     _pickedVideos.length > 0
                                                        //     ?
                                                        'assets/post_icons/calendar.svg',
                                                        fit: BoxFit.cover,
                                                        height: 200,
                                                        width: 200,
                                                        color: _pickedVideos
                                                            .isNotEmpty ||
                                                            controller
                                                                .modelList2[controller
                                                                .currentIndexText]
                                                                .isMediaAttached ||
                                                            showPolls[
                                                            controller
                                                                .currentIndexText]
                                                            ? Colors
                                                            .grey[400]
                                                            : controller
                                                            .displayColor,
                                                        // : Colors.purple,
                                                      ),
                                                    ),
                                                    title: Text(
                                                      '${Strings.thisPostIsScheduledFor} ${DateFormat
                                                          .yMMMMd()
                                                          .add_jm()
                                                          .format(DateFormat(
                                                          "yyyy-MM-dd HH:mm:ss")
                                                          .parse(
                                                          selectedDateTime))}',
                                                      // 'This post is scheduled for ${DateFormat.yMMMMd().add_jm().format(widget.dateTimeData)}',
                                                    ),
                                                    subtitle:
                                                    GestureDetector(
                                                      onTap: () {
                                                        widget.isPostScheduled =
                                                        false;
                                                        setState(() {});
                                                      },
                                                      child: Text(
                                                       Strings.clear,
                                                        style: TextStyle(
                                                          decoration:
                                                          TextDecoration
                                                              .underline,
                                                        ),

                                                        // style: Theme.of(context).brightness == Brightness.dark ?
                                                        // TextStyle(color: Colors.white, decoration: TextDecoration.underline)
                                                        //     : TextStyle(color: Colors.black, decoration: TextDecoration.underline),
                                                      ),
                                                    ),
                                                  )
                                                      : SizedBox(),

                                                  ///

                                                  ///
                                                  /// text  field
                                                  ListTile(
                                                    contentPadding:
                                                    EdgeInsets.only(left: 6),
                                                    trailing:
                                                    closeIcon == false ||
                                                        ind == 0
                                                        ? SizedBox()
                                                        : GestureDetector(
                                                      onTap: () {
                                                        print(
                                                            'print string :${widget
                                                                .controller
                                                                .modelList2[ind]
                                                                .bodyText}');
                                                        setState(() {
                                                          if ((widget.controller
                                                              .modelList2[ind]
                                                              .bodyText ==
                                                              null ||
                                                              controller
                                                                  .modelList2[ind]
                                                                  .bodyText
                                                                  .length ==
                                                                  0) &&
                                                              controller
                                                                  .modelList2[
                                                              ind]
                                                                  .mediaData2
                                                                  .isEmpty) {
                                                            //controller.modelList2.remove(ind);
                                                            //controller.modelList2[ind];
                                                            print(
                                                                " ind number   ${ind}");
                                                            print(
                                                                " ind number   ${widget
                                                                    .controller
                                                                    .currentIndexText}");

                                                            if (widget
                                                                .controller
                                                                .currentIndexText >
                                                                0) {
                                                              widget
                                                                  .controller
                                                                  .currentIndexText =
                                                                  widget
                                                                      .controller
                                                                      .currentIndexText -
                                                                      1;
                                                            }

                                                            controller
                                                                .modelList2
                                                                .remove(
                                                                controller
                                                                    .modelList2[ind]);
                                                          }
                                                        });
                                                      },
                                                      child: Icon(
                                                        Icons.clear,
                                                        size: 30,
                                                        color: Theme
                                                            .of(context)
                                                            .brightness ==
                                                            Brightness
                                                                .dark
                                                            ? Colors
                                                            .white
                                                            : Colors
                                                            .black,
                                                      ),
                                                    ),
                                                    leading: widget.controller
                                                        .userProfile ==
                                                        null
                                                        ? Container(
                                                        width: 24,
                                                        child: Center(
                                                          child:
                                                          SpinKitCircle(
                                                            color:
                                                            Colors.grey,
                                                            size: 40,
                                                          ),
                                                        ))
                                                        : widget
                                                        .controller
                                                        .userProfile
                                                        .profileImage ==
                                                        null
                                                        ? CircleAvatar(
                                                        radius: 22,
                                                        backgroundImage:
                                                        AssetImage(
                                                            "assets/images/person_placeholder.png"))
                                                        : ClipRRect(
                                                      borderRadius:
                                                      BorderRadius
                                                          .circular(
                                                          30),
                                                      child: FadeInImage(
                                                          fit: BoxFit
                                                              .cover,
                                                          width: 40,
                                                          height: 40,
                                                          placeholder:
                                                          AssetImage(
                                                              'assets/images/person_placeholder.png'),
                                                          image: NetworkImage(
                                                              widget
                                                                  .controller
                                                                  .userProfile
                                                                  .profileImage !=
                                                                  null
                                                                  ? widget
                                                                  .controller
                                                                  .userProfile
                                                                  .profileImage
                                                                  : "assets/images/person_placeholder.png")),
                                                    ),
                                                    title: GestureDetector(
                                                      onTap: () {
                                                        widget.controller
                                                            .currentIndexText =
                                                            ind;
                                                        print(
                                                            "check media length  ${widget
                                                                .controller
                                                                .modelList2[widget
                                                                .controller
                                                                .currentIndexText]
                                                                .mediaData2
                                                                .length}");
                                                        setState(() {});
                                                        controller
                                                            .modelList2[controller
                                                            .currentIndexText]
                                                            .isMediaAttached =
                                                        false;
                                                      },

                                                      child: HashTagTextField(
                                                        autofocus: true,
                                                        onChanged: (value) {
                                                          if (value.contains(
                                                              "#") &&
                                                              value.contains(
                                                                  "@")) {
                                                            setState(() {
                                                              widget
                                                                  .mentionUser =
                                                              false;
                                                              widget
                                                                  .mentionTag =
                                                              false;
                                                            });
                                                          }

                                                          widget.controller
                                                              .currentIndexText =
                                                              ind;
                                                          setState(() {});

                                                          print(_controller[ind]
                                                              .text);

                                                          controller
                                                              .modelList2[ind]
                                                              .bodyText =
                                                              _controller[ind]
                                                                  .text;

                                                        if (value.length >
                                                              0 &&
                                                              _controller[ind]
                                                                  .text
                                                                  .trim()
                                                                  .isNotEmpty)
                                                            setState(() {
                                                              widget.controller
                                                                  .postText =
                                                              true;
                                                              if (widget
                                                                  .isPostScheduled) {
                                                                visibility =
                                                                false;
                                                              } else {
                                                                visibility =
                                                                true;
                                                              }
                                                              closeIcon = false;
                                                            });
                                                          else
                                                            setState(() {
                                                              widget.controller
                                                                  .postText =
                                                              false;
                                                              visibility =
                                                              false;
                                                              closeIcon = true;
                                                            });
                                                          if (value.length <
                                                              2) {
                                                            /// user tag and mention tag
                                                            widget.mentionUser =
                                                            false;
                                                            widget.mentionTag =
                                                            false;
                                                            temp = '';
                                                            tempUsername = '';
                                                            widget.tags.clear();

                                                            /// end
                                                            visibility = true;
                                                            setState(() {});
                                                          }
                                                        },

                                                        /// Called when detection (word starts with #, or # and @) is being typed
                                                        onDetectionTyped:
                                                            (text) async {

                                                          if (!text.contains(
                                                              "#") ||
                                                              !text.contains(
                                                                  "@")) {
                                                            setState(() {
                                                              widget
                                                                  .mentionUser =
                                                              false;
                                                              widget
                                                                  .mentionTag =
                                                              false;
                                                            });
                                                          }

                                                          if (text
                                                              .contains("#")) {
                                                            tempValue = text;

                                                            print(
                                                                'start with #');
                                                            widget.mentionUser =
                                                            false;
                                                            widget.tags =
                                                            await widget
                                                                .controller
                                                                .searchTags(
                                                                tempValue
                                                                    .substring(
                                                                    1));
                                                            if (widget.tags
                                                                .length <=
                                                                0) {
                                                              widget.tags
                                                                  .clear();
                                                              widget
                                                                  .mentionTag =
                                                              false;
                                                              //  temp='';
                                                              setState(() {});
                                                            } else {
                                                              widget
                                                                  .mentionUser =
                                                              false;
                                                              widget
                                                                  .mentionTag =
                                                              true;

                                                              setState(() {});
                                                            }
                                                          } else if (text
                                                              .contains("@")) {
                                                            tempValue = text;

                                                          print("start with @" +
                                                              tempValue
                                                                  .substring(
                                                                  1));
                                                          widget.mentionTag =
                                                          false;
                                                          widget.users =
                                                          await widget
                                                              .controller
                                                              .searchChatUser(
                                                            tempValue
                                                                .substring(1),
                                                            type:
                                                            "mention_users",
                                                          );
                                                          if (widget.users
                                                              .length <=
                                                              0) {
                                                            widget.users
                                                                .clear();
                                                            widget.mentionUser =
                                                            false;
                                                            setState(() {});
                                                          } else {
                                                            widget.mentionUser =
                                                            true;
                                                            setState(() {});
                                                          }
                                                        }
                                                      },

                                                        /// Called when detection is fully typed
                                                        onDetectionFinished:
                                                            () {
                                                          print(
                                                              "detection finishedd");
                                                          // tempValue="";

                                                          setState(() {
                                                            widget.mentionUser =
                                                            false;
                                                            widget.mentionTag =
                                                            false;
                                                          });

/*
                                                            setState(() {
                                                              widget.mentionTag=false;
                                                              widget.mentionUser=false;

                                                            });*/
                                                        },
                                                        // scrollController: scrollController,
                                                        // focusNode:
                                                        //     focusNodeText,
                                                        decorateAtSign: true,
                                                        focusNode: fNode2[ind],
                                                        // autofocus: true,
                                                        onTap: () {
                                                          widget.controller
                                                              .currentIndexText =
                                                              ind;

                                                          setState(() {});
                                                        },
                                                        basicStyle: LightStyles
                                                            .baseTextTheme
                                                            .headline2
                                                            .copyWith(
                                                          color: Get.isDarkMode? Colors.white
                                                              : Colors.black,
                                                          fontWeight:
                                                          FontWeight.w500,
                                                          fontSize: 20,
                                                        ),
                                                        cursorColor: Theme
                                                            .of(
                                                            context)
                                                            .brightness ==
                                                            Brightness.dark
                                                            ? Colors.white
                                                            : Colors.black,
                                                        maxLength: 5000,

                                                        maxLines: showPolls[widget
                                                            .controller
                                                            .currentIndexText]
                                                            ? null
                                                            : widget
                                                            .mentionUser ||
                                                            widget.mentionTag
                                                            ? null
                                                            : null,
                                                        keyboardType:
                                                        TextInputType
                                                            .multiline,


                                                        maxLengthEnforcement: MaxLengthEnforcement
                                                            .enforced,
                                                        controller: _controller[ind] /*isEdit == true?postTextController:controller.modelList2[0].textEditingController*/,
                                                        decoratedStyle: LightStyles
                                                            .baseTextTheme
                                                            .headline2.copyWith(
                                                          color: Colors.blue,
                                                          fontWeight: FontWeight
                                                              .w500,
                                                          fontSize: 20,
                                                        ),
                                                        decoration: InputDecoration(
                                                          counterStyle: TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                          contentPadding: EdgeInsets
                                                              .only(top: 16),
                                                          hintText: showPolls[controller
                                                              .currentIndexText]
                                                              ? Strings.askAQuestion
                                                              : Strings
                                                              .writeSomethingHere,
                                                          border: InputBorder
                                                              .none,
                                                          hintStyle: LightStyles
                                                              .baseTextTheme
                                                              .headline3
                                                              .copyWith(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),


                                                  /// mention tag  widget
                                                  !widget.mentionTag
                                                      ? SizedBox()
                                                      : Align(
                                                    alignment: Alignment
                                                        .centerLeft,
                                                    child: Container(
                                                      decoration:
                                                      BoxDecoration(
                                                        border: Border.all(
                                                          color: Colors
                                                              .grey[300],
                                                          width: 0.5,
                                                        ),
                                                        borderRadius:
                                                        BorderRadius
                                                            .circular(
                                                            4),
                                                      ),
                                                      height: 150,
                                                      width: 300,
                                                      child: widget.tags
                                                          .length ==
                                                          0
                                                          ? SpinKitWave(
                                                        size: 30,
                                                        color: Color(
                                                            0xFFedab30),
                                                      )
                                                          : ListView
                                                          .builder(
                                                          itemCount: widget
                                                              .tags
                                                              .length,
                                                          itemBuilder:
                                                              (context,
                                                              index) {
                                                            return ListTile(
                                                              onTap:
                                                                  () async {
                                                                //   temp='';
                                                                print(
                                                                    "textvalue " +
                                                                        _controller[controller
                                                                            .currentIndexText]
                                                                            .text);
                                                                print(
                                                                    tempValue);
                                                                print(widget
                                                                    .tags[index]['title']);

                                                                /*     _controller[controller.currentIndexText].text =
                                                          _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                         ' ' +
                                                              widget.tags[index]['title'];*/
                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .text =
                                                                    _controller[controller
                                                                        .currentIndexText]
                                                                        .text
                                                                        .substring(
                                                                        0,
                                                                        _controller[controller
                                                                            .currentIndexText]
                                                                            .text
                                                                            .length -
                                                                            tempValue
                                                                                .length);
                                                                print(
                                                                    "tempvalue" +
                                                                        _controller[controller
                                                                            .currentIndexText]
                                                                            .text);
                                                                tempValue =
                                                                    widget
                                                                        .tags[index]['title'] ??
                                                                        "";
                                                                print(
                                                                    "tempvalue" +
                                                                        tempValue);

                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .text =
                                                                    _controller[controller
                                                                        .currentIndexText]
                                                                        .text +
                                                                        " " +
                                                                        tempValue +
                                                                        " ";
                                                                // tempValue="";
                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .selection =
                                                                    TextSelection
                                                                        .fromPosition(
                                                                        TextPosition(
                                                                            offset: _controller[controller
                                                                                .currentIndexText]
                                                                                .text
                                                                                .length));
                                                                widget.tags
                                                                    .clear();
                                                                widget
                                                                    .mentionTag =
                                                                false;
                                                                //  widget.tags = [];
                                                                tempValue =
                                                                "";
                                                                focusNodeText
                                                                    .requestFocus();

                                                                setState(() {});
                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .selection =
                                                                    TextSelection
                                                                        .fromPosition(
                                                                        TextPosition(
                                                                            offset: _controller[controller
                                                                                .currentIndexText]
                                                                                .text
                                                                                .length));

                                                                // widget.focusNode
                                                                //     .requestFocus();
                                                                print(
                                                                    'selection tag  ${_controller[controller
                                                                        .currentIndexText]
                                                                        .selection}');
                                                                print(
                                                                    'value temp${_controller[controller
                                                                        .currentIndexText]
                                                                        .text}');
                                                              },
                                                              title:
                                                              Text(
                                                                widget
                                                                    .tags[index]['title'] ??
                                                                    "",
                                                                style:
                                                                Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                      ? Colors
                                                                      .white
                                                                      : Colors
                                                                      .black,
                                                                  fontWeight: FontWeight
                                                                      .w700,
                                                                  fontSize: 15,
                                                                ),
                                                              ),
                                                            );
                                                          }),
                                                    ),
                                                  ),

                                                  /// mention user  widget
                                                  !widget.mentionUser
                                                      ? SizedBox()
                                                      : Align(
                                                    alignment: Alignment
                                                        .centerLeft,
                                                    child: Container(
                                                      decoration:
                                                      BoxDecoration(
                                                        border: Border.all(
                                                          color: Colors
                                                              .grey[300],
                                                          width: 0.5,
                                                        ),
                                                        borderRadius:
                                                        BorderRadius
                                                            .circular(
                                                            4),
                                                      ),
                                                      height: 150,
                                                      width: 300,
                                                      child: widget.users
                                                          .length ==
                                                          0
                                                          ? SpinKitWave(
                                                        size: 30,
                                                        color: Color(
                                                            0xFFedab30),
                                                      )
                                                          : ListView
                                                          .builder(
                                                          itemCount: widget
                                                              .users
                                                              .length,
                                                          itemBuilder:
                                                              (context,
                                                              index) {
                                                            return ListTile(
                                                              onTap:
                                                                  () async {
                                                                /*     _controller[controller.currentIndexText].text =
                                                          _controller[controller.currentIndexText].text.replaceAll(temp, "")+
                                                         ' ' +
                                                              widget.tags[index]['title'];*/
                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .text =
                                                                    _controller[controller
                                                                        .currentIndexText]
                                                                        .text
                                                                        .substring(
                                                                        0,
                                                                        _controller[controller
                                                                            .currentIndexText]
                                                                            .text
                                                                            .length -
                                                                            tempValue
                                                                                .length);
                                                                print(
                                                                    "tempvalue" +
                                                                        _controller[controller
                                                                            .currentIndexText]
                                                                            .text);
                                                                tempValue =
                                                                widget.users !=
                                                                    null ||
                                                                    widget.users
                                                                        .length >
                                                                        0
                                                                    ? widget
                                                                    .users[index]['username'] ??
                                                                    ""
                                                                    : "";
                                                                print(
                                                                    "tempvalue" +
                                                                        tempValue);

                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .text =
                                                                    _controller[controller
                                                                        .currentIndexText]
                                                                        .text +
                                                                        " " +
                                                                        tempValue +
                                                                        " ";
                                                                // tempValue="";
                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .selection =
                                                                    TextSelection
                                                                        .fromPosition(
                                                                        TextPosition(
                                                                            offset: _controller[controller
                                                                                .currentIndexText]
                                                                                .text
                                                                                .length));
                                                                widget.users
                                                                    .clear();
                                                                widget
                                                                    .mentionUser =
                                                                false;
                                                                //  widget.tags = [];

                                                                tempValue =
                                                                "";
                                                                focusNodeText
                                                                    .requestFocus();
                                                                setState(() {});
                                                                // widget.focusNode
                                                                //     .requestFocus();

                                                                _controller[controller
                                                                    .currentIndexText]
                                                                    .selection =
                                                                    TextSelection
                                                                        .fromPosition(
                                                                        TextPosition(
                                                                            offset: _controller[controller
                                                                                .currentIndexText]
                                                                                .text
                                                                                .length));
                                                              },
                                                              title:
                                                              Text(
                                                                widget
                                                                    .users[index]['username'] ??
                                                                    "",
                                                                style:
                                                                Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                      ? Colors
                                                                      .white
                                                                      : Colors
                                                                      .black,
                                                                  fontWeight: FontWeight
                                                                      .w700,
                                                                  fontSize: 15,
                                                                ),
                                                              ),
                                                            );
                                                          }),
                                                    ),
                                                  ),

                                                  /// end mention user

                                                  widget.controller.postText
                                                      ? widget.controller
                                                      .urlOrNot(
                                                      _controller[controller
                                                          .currentIndexText]
                                                          .text)
                                                      ?

                                                  _controller[controller.currentIndexText].text[1]!="@"?
                                                  Container(
                                                    child: urlFetch(),
                                                  )
                                                      : Container()
                                                      : Container():Container(),

                                                  ///show pools
                                                  showPolls[ind]
                                                      ? Align(
                                                    alignment:
                                                    Alignment.center,
                                                    child: Container(
                                                      width: 600,

                                                      margin:
                                                      EdgeInsets.only(
                                                          bottom: 16,
                                                          top: 16),
                                                      decoration:
                                                      BoxDecoration(

                                                        // color: Colors.redAccent,
                                                          borderRadius: BorderRadius
                                                              .circular(10),
                                                          border: Border
                                                              .all(
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness
                                                                    .dark
                                                                ? Colors
                                                                .white
                                                                : Colors
                                                                .grey,
                                                            width: 1,
                                                          )),
                                                      child: Column(
                                                        children: [
                                                          SizedBox(
                                                              height: 10),
                                                          buildPollOptions(
                                                            optionNumber: 1,
                                                            //   indexOf: ind,
                                                          ),
                                                          buildPollOptions(
                                                            optionNumber: 2,
                                                            // indexOf: ind,
                                                          ),
                                                          option == 3 ||
                                                              option ==
                                                                  4
                                                              ? buildPollOptions(
                                                            optionNumber:
                                                            3,
                                                            //   indexOf: ind,
                                                          )
                                                              : SizedBox(),
                                                          option == 4
                                                              ? buildPollOptions(
                                                            optionNumber:
                                                            4,
                                                            // indexOf: ind,
                                                          )
                                                              : SizedBox(),
                                                          SizedBox(
                                                            height: 6,
                                                          ),
                                                          Container(
                                                            height: 1,
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness
                                                                    .dark
                                                                ? Colors
                                                                .white
                                                                : Colors
                                                                .grey,
                                                          ),
                                                          SizedBox(
                                                            height: 3,
                                                          ),
                                                          Padding(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                vertical:
                                                                6.0,
                                                                horizontal:
                                                                10),
                                                            child: Align(
                                                              alignment:
                                                              Alignment
                                                                  .centerLeft,
                                                              child: Text(
                                                                Strings.pollLength,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline4
                                                                    .copyWith(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                      ? Colors
                                                                      .white
                                                                      : Colors
                                                                      .black,
                                                                  fontSize:
                                                                  14,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 6,
                                                          ),
                                                          Padding(
                                                            padding: EdgeInsets
                                                                .symmetric(
                                                                vertical:
                                                                6.0,
                                                                horizontal:
                                                                10),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceBetween,
                                                              children: [

                                                                /// pools days selected button
                                                                ButtonTheme(
                                                                  materialTapTargetSize:
                                                                  MaterialTapTargetSize
                                                                      .padded,
                                                                  child:
                                                                  Expanded(
                                                                    child: DropdownButtonFormField<
                                                                        String>(
                                                                      icon:
                                                                      Icon(Icons
                                                                          .keyboard_arrow_down),
                                                                      isExpanded:
                                                                      true,
                                                                      decoration:
                                                                      InputDecoration(
                                                                        border:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //width: 1,
                                                                            //  style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            // width: 1,
                                                                            // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            // width: 1,
                                                                            //  style: BorderStyle.none,
                                                                            color: controller
                                                                                .displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText:
                                                                        Strings.day,
                                                                        labelStyle:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      value:
                                                                      0
                                                                          .toString(),
                                                                      hint:
                                                                      Text(
                                                                       Strings.day,
                                                                        style:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                      items:
                                                                      days.map((
                                                                          int value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value: value
                                                                              .toString(),
                                                                          child: Text(
                                                                            value
                                                                                .toString(),
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline4
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      })
                                                                          .toList(),
                                                                      onChanged:
                                                                          (
                                                                          days) {
                                                                        pollDays =
                                                                            days;
                                                                        controller
                                                                          ..modelList2[controller
                                                                              .currentIndexText]
                                                                              .days = days;
                                                                        setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 10,
                                                                ),

                                                                /// pools hour selected button
                                                                ButtonTheme(
                                                                  materialTapTargetSize:
                                                                  MaterialTapTargetSize
                                                                      .padded,
                                                                  child:
                                                                  Expanded(
                                                                    child: DropdownButtonFormField<
                                                                        String>(
                                                                      icon:
                                                                      Icon(Icons
                                                                          .keyboard_arrow_down),
                                                                      isExpanded:
                                                                      true,
                                                                      decoration:
                                                                      InputDecoration(
                                                                        border:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            // width: 1,
                                                                            // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //width: 1,
                                                                            // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //  width: 1,
                                                                            //  style: BorderStyle.none,
                                                                            color: controller
                                                                                .displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText:
                                                                        Strings.hours,
                                                                        labelStyle:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      value:
                                                                      0
                                                                          .toString(),
                                                                      hint:
                                                                      Text(
                                                                        Strings.hours,
                                                                        style:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                      items: List
                                                                          .generate(
                                                                          24,
                                                                              (
                                                                              index) =>
                                                                          index)
                                                                          .map((
                                                                          int
                                                                          value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value: value
                                                                              .toString(),
                                                                          child: Text(
                                                                            value
                                                                                .toString(),
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline4
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      })
                                                                          .toList(),
                                                                      onChanged:
                                                                          (
                                                                          hours) {
                                                                        pollHours =
                                                                            hours;
                                                                        controller
                                                                            .modelList2[controller
                                                                            .currentIndexText]
                                                                            .hours =
                                                                            hours;
                                                                        setState(() {});
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 10,
                                                                ),

                                                                /// pools mint selected button
                                                                ButtonTheme(
                                                                  materialTapTargetSize:
                                                                  MaterialTapTargetSize
                                                                      .padded,
                                                                  child:
                                                                  Expanded(
                                                                    child: DropdownButtonFormField<
                                                                        String>(
                                                                      icon:
                                                                      Icon(Icons
                                                                          .keyboard_arrow_down),
                                                                      isExpanded:
                                                                      true,
                                                                      decoration:
                                                                      InputDecoration(
                                                                        border:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //  width: 1,
                                                                            // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        disabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //   width: 1,
                                                                            //  style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey,
                                                                          ),
                                                                        ),
                                                                        enabledBorder:
                                                                        OutlineInputBorder(
                                                                          borderRadius: BorderRadius
                                                                              .circular(
                                                                              10),
                                                                          borderSide: BorderSide(
                                                                            //width: 1,
                                                                            //  style: BorderStyle.none,
                                                                            color: controller
                                                                                .displayColor,
                                                                          ),
                                                                        ),
                                                                        labelText:
                                                                        Strings.minutes,
                                                                        labelStyle:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      value: pollHours ==
                                                                          '0' &&
                                                                          pollDays ==
                                                                              '0'
                                                                          ? 5
                                                                          .toString()
                                                                          : 0
                                                                          .toString(),
                                                                      hint:
                                                                      Text(
                                                                        Strings.minutes,
                                                                        style:
                                                                        Styles
                                                                            .baseTextTheme
                                                                            .headline4
                                                                            .copyWith(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          fontSize: 14,
                                                                        ),
                                                                      ),
                                                                      alignment:
                                                                      Alignment
                                                                          .bottomCenter,
                                                                      items: pollHours ==
                                                                          '0' &&
                                                                          pollDays ==
                                                                              '0'
                                                                          ? minutes
                                                                          .map((
                                                                          int value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value: value
                                                                              .toString(),
                                                                          child: Text(
                                                                            value
                                                                                .toString(),
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline4
                                                                                .copyWith(
                                                                              color: Theme
                                                                                  .of(
                                                                                  context)
                                                                                  .brightness ==
                                                                                  Brightness
                                                                                      .dark
                                                                                  ? Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontSize: 14,
                                                                            ),
                                                                          ),
                                                                        );
                                                                      })
                                                                          .toList()

                                                                      /// pool mint list generate
                                                                          : List
                                                                          .generate(
                                                                          60, (
                                                                          index) => index)
                                                                          .map((
                                                                          int value) {
                                                                        return DropdownMenuItem<
                                                                            String>(
                                                                          value: value
                                                                              .toString(),
                                                                          child: Text(
                                                                              value
                                                                                  .toString()),
                                                                        );
                                                                      })
                                                                          .toList(),
                                                                      onChanged:
                                                                          (
                                                                          minutes) {
                                                                        pollMinutes =
                                                                            minutes;
                                                                        controller
                                                                            .modelList2[controller
                                                                            .currentIndexText]
                                                                            .minutes =
                                                                            minutes;
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: 6,
                                                          ),
                                                          Container(
                                                            height: 1,
                                                            color: Theme
                                                                .of(context)
                                                                .brightness ==
                                                                Brightness
                                                                    .dark
                                                                ? Colors
                                                                .white
                                                                : Colors
                                                                .grey,
                                                          ),

                                                          /// remove pool button
                                                          InkWell(
                                                            hoverColor:
                                                            Colors.red[
                                                            100],
                                                            onTap: () {
                                                              showPolls[controller
                                                                  .currentIndexText] =
                                                              false;
                                                              option = 2;
                                                              isOptionTwo =
                                                              true;
                                                              controller
                                                                  .modelList2[
                                                              controller
                                                                  .currentIndexText]
                                                                  .poolThread =
                                                              false;

                                                              setState(
                                                                      () {});
                                                            },
                                                            child:
                                                            Container(
                                                              alignment:
                                                              Alignment
                                                                  .center,
                                                              margin: EdgeInsets
                                                                  .symmetric(
                                                                  vertical:
                                                                  6),
                                                              width: 600,
                                                              height: 40,
                                                              child: Text(
                                                                Strings.removePoll,
                                                                style: Theme
                                                                    .of(
                                                                    context)
                                                                    .textTheme
                                                                    .headline3
                                                                    .copyWith(
                                                                  fontSize:
                                                                  18,
                                                                  color:
                                                                  Colors
                                                                      .redAccent,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  )
                                                      : SizedBox(),

                                                  /// threadimages
                                                  controller.modelList2[ind]
                                                      .mediaData2.length > 0 &&
                                                      !controller
                                                          .modelList2[ind]
                                                          .mediaData2[0]
                                                          .name
                                                          .contains('.pdf') &&
                                                      (widget.controller
                                                          .modelList2[ind]
                                                          .mediaData2[0]
                                                          .thumbnailUrl ==
                                                          null ||
                                                          controller
                                                              .modelList2[ind]
                                                              .mediaData2[0]
                                                              .thumbnailUrl
                                                              .isEmpty)
                                                      ? ConstrainedBox(
                                                    constraints:
                                                    BoxConstraints
                                                        .expand(
                                                        height: 300,
                                                        width: 350),
                                                    child: Container(
                                                      height: controller
                                                          .modelList2[
                                                      ind]
                                                          .mediaData2
                                                          .length <
                                                          2
                                                          ? 300
                                                          : 350,
                                                      // width: 180,
                                                      child: StaggeredGridView
                                                          .countBuilder(
                                                          crossAxisSpacing:
                                                          5,
                                                          mainAxisSpacing:
                                                          5,
                                                          itemCount: controller
                                                              .modelList2[
                                                          ind]
                                                              .mediaData2
                                                              .length,
                                                          crossAxisCount:
                                                          controller
                                                              .modelList2[ind]
                                                              .mediaData2
                                                              .length <
                                                              2
                                                              ? 1
                                                              : 2,
                                                          itemBuilder:
                                                              (context,
                                                              index) {
                                                            return !widget
                                                                .controller
                                                                .modelList2[ind]
                                                                .mediaData2
                                                                .asMap()
                                                                .containsKey(
                                                                index)
                                                                ? Container(
                                                              height:
                                                              100,
                                                              alignment:
                                                              Alignment.center,
                                                              child:
                                                              Column(
                                                                crossAxisAlignment: CrossAxisAlignment
                                                                    .center,
                                                                children: [
                                                                  CircularProgressIndicator(
                                                                    color: MyColors
                                                                        .BlueColor,
                                                                  ),
                                                                  SizedBox(
                                                                      height: 6),
                                                                  Text(
                                                                    Strings.uploading,
                                                                    style: TextStyle(
                                                                        color: MyColors
                                                                            .BlueColor,
                                                                        fontWeight: FontWeight
                                                                            .w700),
                                                                  ),
                                                                ],
                                                              ),
                                                            )
                                                                : Container(
                                                              // height: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 300,
                                                              // width: controller.modelList2[ind].mediaData2.length < 2 ? 350 : 160,
                                                              height:
                                                              300,
                                                              width:
                                                              350,
                                                              child:
                                                              Stack(
                                                                children: [
                                                                  Container(
                                                                    decoration: BoxDecoration(
                                                                      borderRadius: BorderRadius
                                                                          .circular(
                                                                          15),
                                                                    ),
                                                                    // height: controller.modelList2[ind].mediaData2.length < 2 ? 250 : 300,
                                                                    // width: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 200,
                                                                    height: 250,
                                                                    width: 350,
                                                                    child: ClipRRect(
                                                                      borderRadius: BorderRadius
                                                                          .circular(
                                                                          15),
                                                                      child: Image
                                                                          .network(
                                                                        controller
                                                                            .modelList2[ind]
                                                                            .mediaData2[index]
                                                                            .url,
                                                                        fit: BoxFit
                                                                            .cover,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    left: 10,
                                                                    top: 10,
                                                                    child: Align(
                                                                      alignment: Alignment
                                                                          .topLeft,
                                                                      child: CircleAvatar(
                                                                        radius: 14,
                                                                        backgroundColor: Color(
                                                                            0xFF4b4f53),
                                                                        child: IconButton(
                                                                          padding: EdgeInsets
                                                                              .zero,
                                                                          icon: Icon(
                                                                            Icons
                                                                                .close_rounded,
                                                                            size: 16,
                                                                            color: Colors
                                                                                .white,
                                                                          ),
                                                                          onPressed: () {
                                                                            controller
                                                                                .modelList2[controller
                                                                                .currentIndexText]
                                                                                .isImageAttached =
                                                                            false;
                                                                            isImageAttached =
                                                                            false;

                                                                            // if(counter!=0)
                                                                            //   {
                                                                            //     counter--;
                                                                            //   }

                                                                            if (controller
                                                                                .modelList2[controller
                                                                                .currentIndexText]
                                                                                .bodyText
                                                                                .isEmpty &&
                                                                                widget
                                                                                    .post
                                                                                    .quoteInfo
                                                                                    .postFiles
                                                                                    .isEmpty) {
                                                                              widget
                                                                                  .controller
                                                                                  .postText =
                                                                              false;
                                                                              widget
                                                                                  .controller
                                                                                  .update();
                                                                            }


                                                                            print(
                                                                                "image");
                                                                            widget
                                                                                .controller
                                                                                .mediaData
                                                                                .clear();
                                                                            widget
                                                                                .controller
                                                                                .update();
                                                                            if (widget
                                                                                .controller
                                                                                .modelList2[ind]
                                                                                .mediaData2
                                                                                .length ==
                                                                                1) {
                                                                              print(
                                                                                  "image 2 attached if condition ");
                                                                              // isMediaAttached = false;

                                                                              setState(() {});
                                                                            }
                                                                            print(
                                                                                'images length:${widget
                                                                                    .controller
                                                                                    .modelList2[ind]
                                                                                    .mediaData2
                                                                                    .length}');


                                                                            if (controller
                                                                                .modelList2[0]
                                                                                .imageCounter !=
                                                                                null &&
                                                                                controller
                                                                                    .modelList2[0]
                                                                                    .imageCounter >=
                                                                                    0) {
                                                                              print(
                                                                                  "image index ${index}");
                                                                              controller
                                                                                  .modelList2[0]
                                                                                  .imageDescriptionController
                                                                                  .remove(
                                                                                  controller
                                                                                      .modelList2[0]
                                                                                      .imageDescriptionController[index]);
                                                                              if (controller
                                                                                  .modelList2[ind]
                                                                                  .imageCounter >=
                                                                                  1) {
                                                                                controller
                                                                                    .modelList2[0]
                                                                                    .imageCounter--;
                                                                              }


                                                                              widget
                                                                                  .controller
                                                                                  .update();
                                                                            }
                                                                            if (controller
                                                                                .modelList2[0]
                                                                                .descriptionCounter !=
                                                                                null &&
                                                                                controller
                                                                                    .modelList2[0]
                                                                                    .descriptionCounter >
                                                                                    1) {
                                                                              controller
                                                                                  .modelList2[0]
                                                                                  .descriptionCounter--;
                                                                              widget
                                                                                  .controller
                                                                                  .update();
                                                                            }


                                                                            controller
                                                                                .modelList2[ind]
                                                                                .mediaData2
                                                                                .remove(
                                                                                widget
                                                                                    .controller
                                                                                    .modelList2[ind]
                                                                                    .mediaData2[index]);
                                                                            // imageThumbnailsList.removeAt(index);
                                                                            setState(() {
                                                                              if (widget
                                                                                  .controller
                                                                                  .modelList2[ind]
                                                                                  .mediaData2
                                                                                  .isEmpty) {
                                                                                visibility =
                                                                                false;
                                                                              }
                                                                            });
                                                                          },
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            );
                                                          },
                                                          staggeredTileBuilder:
                                                              (index) {
                                                            return StaggeredTile
                                                                .count(
                                                                1,
                                                                controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .length < 2
                                                                    ? index
                                                                    .isEven
                                                                    ? 1.2
                                                                    : 1.2
                                                                    : controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .length < 3
                                                                    ? index
                                                                    .isEven
                                                                    ? 1.2
                                                                    : 1.2
                                                                    : controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .length < 4
                                                                    ? index == 0
                                                                    ? 1.2
                                                                    : 0.6
                                                                    : index
                                                                    .isEven
                                                                    ? 0.7
                                                                    : 0.7);
                                                          }),
                                                      // ListView.separated(
                                                      //     shrinkWrap: true,
                                                      //     separatorBuilder: (_, __) {
                                                      //       return SizedBox(width: 4);
                                                      //     },
                                                      //     scrollDirection: Axis.horizontal,
                                                      //     itemCount: controller.modelList2[ind].mediaData2.length,
                                                      //     itemBuilder: (context, index) {
                                                      //       return !widget.controller.modelList2[ind].mediaData2.asMap().containsKey(index)
                                                      //           ? Container(
                                                      //         height:
                                                      //         100,
                                                      //         alignment:
                                                      //         Alignment.center,
                                                      //         child:
                                                      //         Column(
                                                      //           crossAxisAlignment: CrossAxisAlignment.center,
                                                      //           children: [
                                                      //             CircularProgressIndicator(color: MyColors.BlueColor,),
                                                      //             SizedBox(height: 6),
                                                      //             Text(
                                                      //               'Uploading...',
                                                      //               style: TextStyle(color: MyColors.BlueColor, fontWeight: FontWeight.w700),
                                                      //             ),
                                                      //           ],
                                                      //         ),
                                                      //       )
                                                      //           : Container(
                                                      //         height: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 300,
                                                      //         width: controller.modelList2[ind].mediaData2.length < 2 ? 350 : 160,
                                                      //         child:
                                                      //         Stack(
                                                      //           children: [
                                                      //             Container(
                                                      //               decoration: BoxDecoration(
                                                      //                 borderRadius: BorderRadius.circular(15),
                                                      //               ),
                                                      //               height: controller.modelList2[ind].mediaData2.length < 2 ? 300 : 200,
                                                      //               width: controller.modelList2[ind].mediaData2.length < 2 ? 350 : 160,
                                                      //               child: ClipRRect(
                                                      //                 borderRadius: BorderRadius.circular(15),
                                                      //                 child: Image.network(
                                                      //                   controller.modelList2[ind].mediaData2[index].url,
                                                      //                   fit: BoxFit.fill,
                                                      //                 ),
                                                      //               ),
                                                      //             ),
                                                      //             Positioned(
                                                      //               left: 10,
                                                      //               top: 10,
                                                      //               child: Align(
                                                      //                 alignment: Alignment.topLeft,
                                                      //                 child: CircleAvatar(
                                                      //                   radius: 14,
                                                      //                   backgroundColor: Color(0xFF4b4f53),
                                                      //                   child: IconButton(
                                                      //                     padding: EdgeInsets.zero,
                                                      //                     icon: Icon(
                                                      //                       Icons.close_rounded,
                                                      //                       size: 16,
                                                      //                       color: Colors.white,
                                                      //                     ),
                                                      //                     onPressed: () {
                                                      //                       widget.controller.postText = false;
                                                      //                       widget.controller.update();
                                                      //
                                                      //                       print("image");
                                                      //                       widget.controller.mediaData.clear();
                                                      //                       widget.controller.update();
                                                      //                       if (widget.controller.modelList2[ind].mediaData2.length == 1) {
                                                      //                         print("image 2 attached if condition ");
                                                      //                         isMediaAttached = false;
                                                      //
                                                      //                         setState(() {});
                                                      //                       }
                                                      //                       print('images length:${widget.controller.modelList2[ind].mediaData2.length}');
                                                      //
                                                      //                       controller.modelList2[ind].mediaData2.remove(widget.controller.modelList2[ind].mediaData2[index]);
                                                      //                       // imageThumbnailsList.removeAt(index);
                                                      //                       setState(() {
                                                      //                         if (widget.controller.modelList2[ind].mediaData2.isEmpty) {
                                                      //                           visibility = false;
                                                      //                         }
                                                      //                       });
                                                      //                     },
                                                      //                   ),
                                                      //                 ),
                                                      //               ),
                                                      //             ),
                                                      //           ],
                                                      //         ),
                                                      //       );
                                                      //     }),
                                                    ),
                                                  )

                                                  ///threadvideo
                                                      : controller
                                                      .modelList2[ind]
                                                      .mediaData2.length >
                                                      0 &&
                                                      controller.modelList2[ind]
                                                          .mediaData2[0]
                                                          .thumbnailUrl !=
                                                          null &&
                                                      controller.modelList2[ind]
                                                          .mediaData2[0].name ==
                                                          "media"
                                                      ? Align(
                                                    alignment: Alignment
                                                        .center,
                                                    child:
                                                    ConstrainedBox(
                                                      constraints:
                                                      BoxConstraints
                                                          .expand(
                                                          height:
                                                          300,
                                                          width:
                                                          350),
                                                      child: SizedBox(
                                                        // height: controller.modelList2[ind].mediaData2.isEmpty ? 100 : MediaQuery.of(context).size.height / 4,
                                                        height: controller
                                                            .modelList2[
                                                        ind]
                                                            .mediaData2
                                                            .isEmpty
                                                            ? 100
                                                            : 300,
                                                        width: controller
                                                            .modelList2[
                                                        ind]
                                                            .mediaData2
                                                            .isEmpty
                                                            ? 100
                                                            : double
                                                            .infinity,
                                                        child:
                                                        Container(
                                                          child: Stack(
                                                            children: [
                                                              Container(
                                                                decoration:
                                                                BoxDecoration(
                                                                  borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                      15),
                                                                ),
                                                                // height: controller.modelList2[ind].mediaData2.isEmpty ? 100 : MediaQuery.of(context).size.height / 4,
                                                                height: controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .isEmpty
                                                                    ? 100
                                                                    : 250,
                                                                width: controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .isEmpty
                                                                    ? 100
                                                                    : double
                                                                    .infinity,
                                                                child: widget
                                                                    .controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .isEmpty
                                                                    ? Align(
                                                                  alignment: Alignment
                                                                      .center,
                                                                  child: Container(
                                                                    // width: 62,
                                                                    // height: 72,
                                                                      child: Column(
                                                                        children: [
                                                                          CircularProgressIndicator(
                                                                            color: MyColors
                                                                                .BlueColor,
                                                                          ),
                                                                          SizedBox(
                                                                              height: 6),
                                                                          Text(
                                                                            'Uploading...',
                                                                            style: TextStyle(
                                                                                color: MyColors
                                                                                    .BlueColor,
                                                                                fontWeight: FontWeight
                                                                                    .w700),
                                                                          ),
                                                                        ],
                                                                      )),
                                                                )
                                                                    : ClipRRect(
                                                                  borderRadius: BorderRadius
                                                                      .circular(
                                                                      15),
                                                                  child: Image
                                                                      .network(
                                                                    controller
                                                                        .modelList2[ind]
                                                                        .mediaData2[0]
                                                                        .thumbnailUrl ??
                                                                        'https://via.placeholder.com/150',
                                                                    // height: MediaQuery.of(context).size.height / 3.8,
                                                                    height: 250,
                                                                    width: double
                                                                        .infinity,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left:
                                                                10,
                                                                top: 10,
                                                                child: controller
                                                                    .modelList2[ind]
                                                                    .mediaData2
                                                                    .isEmpty
                                                                    ? SizedBox()
                                                                    : Align(
                                                                  alignment: Alignment
                                                                      .topLeft,
                                                                  child: CircleAvatar(
                                                                    radius: 14,
                                                                    backgroundColor: Color(
                                                                        0xFF4b4f53),
                                                                    child: IconButton(
                                                                      padding: EdgeInsets
                                                                          .zero,
                                                                      icon: Icon(
                                                                        Icons
                                                                            .close_rounded,
                                                                        size: 16,
                                                                        color: Colors
                                                                            .white,
                                                                      ),
                                                                      onPressed: () {
                                                                        print(
                                                                            "enter video");

                                                                        // controller.modelList2[ind].mediaData2.clear();

                                                                        // if (controller.modelList2[ind].mediaData2.length == 1) {
                                                                        //   isMediaAttached = false;
                                                                        //   setState(
                                                                        //           () {});
                                                                        // }

                                                                        controller
                                                                            .modelList2[ind]
                                                                            .mediaData2
                                                                            .clear();
                                                                        _pickedVideos
                                                                            .clear();
                                                                        _pickedVideosMemeType.clear();
                                                                        _pickedVideosName.clear();


                                                                        // controller.modelList2[0].mediaData2.forEach((element) {
                                                                        //   print("Data");
                                                                        //   print(element.url);
                                                                        //   print(element.size);
                                                                        //   print(element.name);
                                                                        //   print(element.thumbnailUrl);
                                                                        // });

                                                                        controller
                                                                            .modelList2[controller
                                                                            .currentIndexText]
                                                                            .isMediaAttached =
                                                                        false;
                                                                        // isMediaAttached = false;

                                                                        if (controller
                                                                            .modelList2[controller
                                                                            .currentIndexText]
                                                                            .bodyText
                                                                            .isEmpty) {
                                                                          widget
                                                                              .controller
                                                                              .postText =
                                                                          false;
                                                                          widget
                                                                              .controller
                                                                              .update();
                                                                        }

                                                                        //  videoWidgetKey =0;
                                                                        visibility =
                                                                        false;
                                                                        setState(() {});

                                                                        // widget.controller.mediaData.clear();
                                                                        widget
                                                                            .controller
                                                                            .update();
                                                                      },
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  )

                                                  // ///threadaudio
                                                  //     : controller.modelList2[ind].mediaData2.length > 0 && controller.modelList2[ind].mediaData2!= null
                                                  //     ? audioUrl.isEmpty
                                                  //     ? Container(
                                                  //     width: 100,
                                                  //     height: 100,
                                                  //     child: Column(
                                                  //       children: [
                                                  //         CircularProgressIndicator(),
                                                  //         SizedBox(height: 6),
                                                  //         Text(
                                                  //           'Uploading...',
                                                  //           style: TextStyle(
                                                  //               color: Color(
                                                  //                   0xFFedab30),
                                                  //               fontWeight:
                                                  //               FontWeight
                                                  //                   .w700),
                                                  //         ),
                                                  //       ],
                                                  //     ))
                                                  //     : Stack(
                                                  //   children: [
                                                  //     Container(
                                                  //       child:
                                                  //       ChewieAudioPlayer(
                                                  //         audioUrl: audioUrl,
                                                  //       ),
                                                  //     ),
                                                  //     Positioned(
                                                  //       right: 6,
                                                  //       top: 10,
                                                  //       child: CircleAvatar(
                                                  //         radius: 14,
                                                  //         backgroundColor:
                                                  //         Colors.grey,
                                                  //         child: IconButton(
                                                  //           padding:
                                                  //           EdgeInsets.zero,
                                                  //           icon: Icon(
                                                  //             Icons
                                                  //                 .close_rounded,
                                                  //             size: 16,
                                                  //             color:
                                                  //             Colors.white,
                                                  //           ),
                                                  //           onPressed: () {
                                                  //             widget.controller
                                                  //                 .mediaData
                                                  //                 .clear();
                                                  //             if (controller.modelList2[ind].mediaData2.length == 1) {
                                                  //               isMediaAttached = false;
                                                  //
                                                  //               setState(() {});
                                                  //             }
                                                  //             print(controller.modelList2[ind].mediaData2.length);
                                                  //             controller.modelList2[ind].mediaData2.remove(
                                                  //                 controller.modelList2[ind].mediaData2[0]);
                                                  //             audioUrl = '';
                                                  //             setState(() {});
                                                  //           },
                                                  //         ),
                                                  //       ),
                                                  //     ),
                                                  //   ],
                                                  // )

                                                  ///threadpdf
                                                      : controller
                                                      .modelList2[
                                                  ind]
                                                      .mediaData2
                                                      .length >
                                                      0
                                                      ? controller
                                                      .modelList2[ind]
                                                      .mediaData2[0]
                                                      .name
                                                      .isNotEmpty &&
                                                      controller.modelList2[ind]
                                                          .mediaData2[0].name
                                                          .contains('.pdf')
                                                  //  ?
                                                      ? controller
                                                      .modelList2[ind]
                                                      .mediaData2.length == 0
                                                      ? Container(width: 100,
                                                      height: 100,
                                                      child: CircularProgressIndicator(
                                                          color: MyColors
                                                              .BlueColor))
                                                      : Align(
                                                    alignment:
                                                    Alignment.centerLeft,
                                                    child:
                                                    ConstrainedBox(
                                                      constraints: BoxConstraints
                                                          .expand(
                                                          height: 300,
                                                          width: 350),
                                                      child:
                                                      SizedBox(
                                                        height:
                                                        100,
                                                        width:
                                                        320,
                                                        child: ListView
                                                            .separated(
                                                            scrollDirection: Axis
                                                                .horizontal,
                                                            itemBuilder: (
                                                                context,
                                                                index) {
                                                              return Container(
                                                                height: 100,
                                                                width: 320,
                                                                child: Stack(
                                                                  children: [
                                                                    Container(
                                                                      height: 250,
                                                                      width: 320,
                                                                      child: ListTile(
                                                                        leading: Image
                                                                            .asset(
                                                                            'assets/images/document.png'),
                                                                        title: Text(
                                                                            widget
                                                                                .controller
                                                                                .modelList2[ind]
                                                                                .mediaData2[0]
                                                                                .name),
                                                                        trailing: CircleAvatar(
                                                                          radius: 14,
                                                                          backgroundColor: Colors
                                                                              .grey,
                                                                          child: IconButton(
                                                                            padding: EdgeInsets
                                                                                .zero,
                                                                            icon: Icon(
                                                                              Icons
                                                                                  .close_rounded,
                                                                              size: 16,
                                                                              color: Colors
                                                                                  .white,
                                                                            ),
                                                                            onPressed: () {
                                                                              if (controller
                                                                                  .modelList2[controller
                                                                                  .currentIndexText]
                                                                                  .bodyText
                                                                                  .isEmpty) {
                                                                                widget
                                                                                    .controller
                                                                                    .postText =
                                                                                false;
                                                                                widget
                                                                                    .controller
                                                                                    .update();
                                                                              }
                                                                              controller
                                                                                  .modelList2[ind]
                                                                                  .mediaData2
                                                                                  .clear();
                                                                              controller
                                                                                  .modelList2[controller
                                                                                  .currentIndexText]
                                                                                  .isMediaAttached =
                                                                              false;
                                                                              // isMediaAttached = false;
                                                                              visibility =
                                                                              false;
                                                                              setState(() {});
                                                                            },
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              );
                                                            },
                                                            separatorBuilder: (
                                                                _,
                                                                __) {
                                                              return SizedBox(
                                                                  width: 4);
                                                            },
                                                            itemCount: controller
                                                                .modelList2[ind]
                                                                .mediaData2
                                                                .length),
                                                      ),
                                                    ),
                                                  )
                                                      : Container()
                                                      : Container(),


                                                  ///thread tag people and add description
                                                  controller.modelList2[ind]
                                                      .mediaData2.length > 0 &&
                                                      !controller
                                                          .modelList2[ind]
                                                          .mediaData2[0].name
                                                          .contains('.pdf') &&
                                                      (widget.controller
                                                          .modelList2[ind]
                                                          .mediaData2[0]
                                                          .thumbnailUrl ==
                                                          null ||
                                                          controller
                                                              .modelList2[ind]
                                                              .mediaData2[0]
                                                              .thumbnailUrl
                                                              .isEmpty) ?
                                                  Row(
                                                    children: [
                                                      InkWell(
                                                          onTap: () {
                                                            controller.tagList
                                                                .clear();
                                                            controller
                                                                .showCustomDialog(
                                                              context,
                                                              height,
                                                              width,
                                                                  () {
                                                                setState(() {
                                                                  controller
                                                                      .tagList =
                                                                      controller
                                                                          .tagList;
                                                                });
                                                              },
                                                              0,
                                                            );
                                                          },
                                                          child: Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .person,
                                                                size: 20,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                              // Text(controller.tagList.isNotEmpty? "${controller.tagList.length >1?controller.tagList[0].firstname + " and ${controller.tagList.length-1} Others":"${controller.tagList[0].firstname}" } " :"Tag People",style:TextStyle(color: Colors.blue,fontSize: 12)),
                                                              Text(
                                                                  controller
                                                                      .modelList2[
                                                                  ind]
                                                                      .mediaData2[
                                                                  0]
                                                                      .mentionUserList
                                                                      .isNotEmpty
                                                                      ? "${controller
                                                                      .modelList2[ind]
                                                                      .mediaData2[0]
                                                                      .mentionUserList
                                                                      .length >
                                                                      1
                                                                      ? controller
                                                                      .modelList2[ind]
                                                                      .mediaData2[0]
                                                                      .mentionUserList[0]
                                                                      .firstname +
                                                                      " and ${controller
                                                                          .modelList2[ind]
                                                                          .mediaData2[0]
                                                                          .mentionUserList
                                                                          .length -
                                                                          1} Others"
                                                                      : "${controller
                                                                      .modelList2[ind]
                                                                      .mediaData2[0]
                                                                      .mentionUserList[0]
                                                                      .firstname}"} "
                                                                      : "Tag People",
                                                                  style: TextStyle(
                                                                      color: controller
                                                                          .displayColor,
                                                                      fontSize:
                                                                      14)),
                                                            ],
                                                          )),
                                                      SizedBox(
                                                        width: 20,
                                                      ),

                                                      controller.modelList2[0]
                                                          .descriptionCounter !=
                                                          null && controller
                                                          .modelList2[ind]
                                                          .mediaData2.length ==
                                                          1 &&
                                                          controller
                                                              .modelList2[0]
                                                              .descriptionCounter ==
                                                              1 &&
                                                          controller
                                                              .modelList2[0]
                                                              .mediaData2[0]
                                                              .description
                                                              .isNotEmpty ?
                                                      InkWell(
                                                          onTap: () {
                                                            showDialog(
                                                                context: context,
                                                                builder: (
                                                                    BuildContext con) {
                                                                  return Shortcuts(
                                                                    shortcuts: {

                                                                      LogicalKeySet(
                                                                          LogicalKeyboardKey
                                                                              .escape): EscIntent()
                                                                    },
                                                                    child: AlertDialog(
                                                                        backgroundColor: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? MyColors
                                                                            .liteDark
                                                                            : Colors
                                                                            .white,
                                                                        insetPadding: EdgeInsets
                                                                            .symmetric(
                                                                            horizontal: 0,
                                                                            vertical: 0),
                                                                        contentPadding: EdgeInsets
                                                                            .zero,
                                                                        shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius
                                                                                .all(
                                                                                Radius
                                                                                    .circular(
                                                                                    10.0))
                                                                        ),
                                                                        content: SingleChildScrollView(
                                                                          child: PostImageDescription(
                                                                            ind: ind,

                                                                          ),
                                                                        )

                                                                      //     Deactivation(
                                                                      //   context2: context,
                                                                      // ),
                                                                    ),
                                                                  );
                                                                });
                                                          },
                                                          child: Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .note_add,
                                                                size: 20,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                              SizedBox(
                                                                width: 2,
                                                              ),
                                                              Container(
                                                                width: 100,
                                                                child: Text(
                                                                  controller
                                                                      .modelList2[ind]
                                                                      .mediaData2[0]
                                                                      .description,
                                                                  style: TextStyle(
                                                                    color: controller
                                                                        .displayColor,
                                                                    fontSize: 14,

                                                                  ),
                                                                  overflow: TextOverflow
                                                                      .ellipsis,

                                                                ),
                                                              ),
                                                            ],
                                                          )) :
                                                      controller.modelList2[0]
                                                          .descriptionCounter !=
                                                          null && controller
                                                          .modelList2[ind]
                                                          .mediaData2.length >
                                                          1 &&
                                                          controller
                                                              .modelList2[0]
                                                              .descriptionCounter >=
                                                              1 ?
                                                      InkWell(
                                                          onTap: () {
                                                            showDialog(
                                                                context: context,
                                                                builder: (
                                                                    BuildContext con) {
                                                                  return Shortcuts(
                                                                    shortcuts: {

                                                                      LogicalKeySet(
                                                                          LogicalKeyboardKey
                                                                              .escape): EscIntent()
                                                                    },
                                                                    child: AlertDialog(
                                                                        backgroundColor: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? MyColors
                                                                            .liteDark
                                                                            : Colors
                                                                            .white,
                                                                        insetPadding: EdgeInsets
                                                                            .symmetric(
                                                                            horizontal: 0,
                                                                            vertical: 0),
                                                                        contentPadding: EdgeInsets
                                                                            .zero,
                                                                        shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius
                                                                                .all(
                                                                                Radius
                                                                                    .circular(
                                                                                    10.0))
                                                                        ),
                                                                        content: SingleChildScrollView(
                                                                          child: PostImageDescription(
                                                                            ind: ind,

                                                                          ),
                                                                        )

                                                                      //     Deactivation(
                                                                      //   context2: context,
                                                                      // ),
                                                                    ),
                                                                  );
                                                                });
                                                          },
                                                          child: Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .note_add,
                                                                size: 20,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                              SizedBox(
                                                                width: 2,
                                                              ),
                                                              Text(
                                                                  "${controller
                                                                      .modelList2[0]
                                                                      .descriptionCounter} ${Strings.ImageDescription}",
                                                                  style: TextStyle(
                                                                      color: controller
                                                                          .displayColor,
                                                                      fontSize:
                                                                      14)),
                                                            ],
                                                          )
                                                      ) :

                                                      InkWell(
                                                          onTap: () {
                                                            showDialog(
                                                                context: context,
                                                                builder: (
                                                                    BuildContext con) {
                                                                  return Shortcuts(
                                                                    shortcuts: {

                                                                      LogicalKeySet(
                                                                          LogicalKeyboardKey
                                                                              .escape): EscIntent()
                                                                    },
                                                                    child: AlertDialog(
                                                                        backgroundColor: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? MyColors
                                                                            .liteDark
                                                                            : Colors
                                                                            .white,
                                                                        insetPadding: EdgeInsets
                                                                            .symmetric(
                                                                            horizontal: 0,
                                                                            vertical: 0),
                                                                        contentPadding: EdgeInsets
                                                                            .zero,
                                                                        shape: RoundedRectangleBorder(
                                                                            borderRadius: BorderRadius
                                                                                .all(
                                                                                Radius
                                                                                    .circular(
                                                                                    10.0))
                                                                        ),
                                                                        content: SingleChildScrollView(
                                                                          child: PostImageDescription(
                                                                            ind: ind,
                                                                            addDescriptionCheck: 1,

                                                                          ),
                                                                        )

                                                                      //     Deactivation(
                                                                      //   context2: context,
                                                                      // ),
                                                                    ),
                                                                  );
                                                                });
                                                          },
                                                          child: Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .note_add,
                                                                size: 20,
                                                                color: controller
                                                                    .displayColor,
                                                              ),
                                                              SizedBox(
                                                                width: 2,
                                                              ),
                                                              Text(
                                                                Strings. addDescription,
                                                                  style: TextStyle(
                                                                      color: controller
                                                                          .displayColor,
                                                                      fontSize:
                                                                      14)),
                                                            ],
                                                          )),
                                                    ],
                                                  )
                                                      : SizedBox(),

                                                  ///threadlocation
                                                  controller.modelList2[ind]
                                                      .location !=
                                                      ""
                                                      ? Row(
                                                    children: [
                                                      Icon(Icons
                                                          .location_on_outlined),
                                                      Text(widget
                                                          .controller
                                                          .modelList2[ind]
                                                          .location),
                                                      SizedBox(
                                                        width: 15,
                                                      ),
                                                      InkWell(
                                                        onTap: () {
                                                          controller
                                                              .modelList2[
                                                          ind]
                                                              .location = "";
                                                          // SingleTone.instance.selectedLocation = null;
                                                          Get
                                                              .find<
                                                              NewsfeedController>()
                                                              .postText =
                                                          false;
                                                          Get.find<
                                                              NewsfeedController>()
                                                              .update();
                                                          setState(() {});
                                                        },
                                                        child: Icon(
                                                          Icons.clear,
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                      : SizedBox(),


                                                  // QuoteWerf
                                                  Container(
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius
                                                          .circular(15),
                                                      border: Border.all(
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                    child: Column(
                                                      children: [
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(left: 10,
                                                              bottom: 10),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment
                                                                .start,
                                                            crossAxisAlignment: CrossAxisAlignment
                                                                .start,
                                                            children: [
                                                              Padding(
                                                                padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 10.00),
                                                                child: CircleAvatar(
                                                                  backgroundImage: widget
                                                                      .post
                                                                      .profileImage !=
                                                                      null
                                                                      ? NetworkImage(
                                                                      widget
                                                                          .post
                                                                          .profileImage)
                                                                      : AssetImage(
                                                                      "assets/images/person_placeholder.png"),
                                                                  radius: 22,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width: 5),

                                                              //USERNAME AND POST TIME
                                                              Padding(
                                                                padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 10.0),
                                                                child: Column(
                                                                  crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                                  mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .start,
                                                                  children: [
                                                                    Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                      crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                      children: [
                                                                        Container(
                                                                          width: widget
                                                                              .werfName
                                                                              .length >=
                                                                              15
                                                                              ? kIsWeb
                                                                              ? 145
                                                                              : 100
                                                                              : null,
                                                                          child: Text(
                                                                            widget
                                                                                .werfName,
                                                                            // style: Theme.of(context)
                                                                            //     .textTheme
                                                                            //     .headline3,
                                                                            maxLines: 1,
                                                                            overflow: TextOverflow
                                                                                .ellipsis,
                                                                            style: TextStyle(
                                                                              color: Get.isDarkMode==true?
                                                                              Colors
                                                                                  .white
                                                                                  : Colors
                                                                                  .black,
                                                                              fontWeight: FontWeight
                                                                                  .bold,
                                                                              fontSize: kIsWeb
                                                                                  ? 15
                                                                                  : 15,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          width: 3,),
                                                                        Container(
                                                                          width: widget
                                                                              .werfUsername
                                                                              .length >=
                                                                              15
                                                                              ? kIsWeb
                                                                              ? 145
                                                                              : 100
                                                                              : null,
                                                                          child: Text(
                                                                            "@${widget
                                                                                .werfUsername}",
                                                                            // style: Theme.of(context)
                                                                            //     .textTheme
                                                                            //     .bodyText2
                                                                            //     .copyWith(height: 1.2),
                                                                            maxLines: 1,
                                                                            overflow: TextOverflow
                                                                                .ellipsis,
                                                                            style: Styles
                                                                                .baseTextTheme
                                                                                .headline2
                                                                                .copyWith(
                                                                              fontSize: kIsWeb
                                                                                  ? 15
                                                                                  : 15,
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        SizedBox(
                                                                          width: 3,),
                                                                        Text(
                                                                          '${getDate ==
                                                                              null
                                                                              ? ''
                                                                              : getDate}',
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline2
                                                                              .copyWith(
                                                                            fontSize: kIsWeb
                                                                                ? 15
                                                                                : 15,
                                                                          ),
                                                                        ),
                                                                      ],

                                                                    ),

                                                                    SizedBox(
                                                                        height: 5),
                                                                    widget.post
                                                                        .body
                                                                        .length >
                                                                        0
                                                                        ? PostTextDescription(
                                                                      post: widget
                                                                          .post,
                                                                      controller: controller,
                                                                      width: MediaQuery
                                                                          .of(
                                                                          context)
                                                                          .size
                                                                          .width >=
                                                                          720
                                                                          ? 400
                                                                          : Get
                                                                          .width /
                                                                          1.7,

                                                                    )
                                                                        : SizedBox(),
                                                                  ],
                                                                ),
                                                              ),
                                                              // POPUP MENU BUTTON
                                                            ],
                                                          ),
                                                        ),
                                                        SizedBox(height: 5),

                                                        widget.post.postType ==
                                                            'image' &&
                                                            widget.post
                                                                .postFiles
                                                                .length > 0
                                                            ? ClipRRect(
                                                          borderRadius: BorderRadius
                                                              .only(
                                                              bottomLeft: Radius
                                                                  .circular(15),
                                                              bottomRight: Radius
                                                                  .circular(
                                                                  15)),
                                                          child: Container(
                                                            decoration: BoxDecoration(
                                                              color: Colors
                                                                  .grey[300],
                                                              borderRadius: BorderRadius
                                                                  .only(
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                      15),
                                                                  bottomRight: Radius
                                                                      .circular(
                                                                      15)),
                                                            ),
                                                            height: kIsWeb
                                                                ? 480
                                                                : 240,
                                                            width: Get.width,

                                                            child: Align(
                                                                alignment: Alignment
                                                                    .center,
                                                                child: Image
                                                                    .network(
                                                                    widget.post
                                                                        .postFiles[0]
                                                                    ['file_path'],
                                                                    height: kIsWeb
                                                                        ? 480
                                                                        : 240,
                                                                    fit: BoxFit
                                                                        .cover,
                                                                    width: Get
                                                                        .width)),
                                                          ),
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' &&
                                                            widget.post
                                                                .postFiles
                                                                .length == 2 &&
                                                            widget.post
                                                                .postFiles[0]['file_type'] ==
                                                                'image'
                                                            ? StaggeredGridView
                                                            .countBuilder(
                                                            crossAxisCount: 2,
                                                            crossAxisSpacing: 3,
                                                            mainAxisSpacing: 3,
                                                            shrinkWrap: true,
                                                            physics: ScrollPhysics(),
                                                            itemCount: widget
                                                                .post
                                                                .postFiles
                                                                .length,
                                                            itemBuilder: (
                                                                context,
                                                                index) {
                                                              return Container(
                                                                height: 480,
                                                                decoration: BoxDecoration(
                                                                  color: Colors
                                                                      .transparent,
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),),
                                                                child: ClipRRect(
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),
                                                                  child: Image
                                                                      .network(
                                                                    widget.post
                                                                        .postFiles[index]
                                                                    ['file_path'],
                                                                    fit: BoxFit
                                                                        .cover,
                                                                    height: 480,
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                            staggeredTileBuilder: (
                                                                index) {
                                                              return StaggeredTile
                                                                  .count(
                                                                  1,
                                                                  index.isEven
                                                                      ? 1
                                                                      : 1);
                                                            })
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' &&
                                                            widget.post
                                                                .postFiles
                                                                .length == 3 &&
                                                            widget.post
                                                                .postFiles[0]['file_type'] ==
                                                                'image'
                                                            ? StaggeredGridView
                                                            .countBuilder(
                                                          crossAxisCount: 2,
                                                          crossAxisSpacing: 3,
                                                          mainAxisSpacing: 3,
                                                          shrinkWrap: true,
                                                          physics: ScrollPhysics(),
                                                          itemCount:
                                                          widget.post.postFiles
                                                              .length,
                                                          itemBuilder: (context,
                                                              index) {
                                                            return Container(
                                                              decoration: BoxDecoration(
                                                                color: Colors
                                                                    .transparent,
                                                                borderRadius: BorderRadius
                                                                    .only(
                                                                    bottomLeft: Radius
                                                                        .circular(
                                                                        15),
                                                                    bottomRight: Radius
                                                                        .circular(
                                                                        15)),),
                                                              child: ClipRRect(
                                                                borderRadius: BorderRadius
                                                                    .only(
                                                                    bottomLeft: Radius
                                                                        .circular(
                                                                        15),
                                                                    bottomRight: Radius
                                                                        .circular(
                                                                        15)),
                                                                child: Image
                                                                    .network(
                                                                  widget.post
                                                                      .postFiles[index]
                                                                  ['file_path'],
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                          staggeredTileBuilder: (
                                                              index) {
                                                            return StaggeredTile
                                                                .count(
                                                                1, index == 0
                                                                ? 1
                                                                : 0.5);
                                                          },
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' &&
                                                            widget.post
                                                                .postFiles
                                                                .length ==
                                                                4 &&
                                                            widget.post
                                                                .postFiles[0]['file_type'] ==
                                                                'image'
                                                            ? StaggeredGridView
                                                            .countBuilder(
                                                          crossAxisCount: 2,
                                                          crossAxisSpacing: 3,
                                                          mainAxisSpacing: 3,
                                                          shrinkWrap: true,
                                                          physics: ScrollPhysics(),
                                                          itemCount: widget
                                                              .post.postFiles
                                                              .length,
                                                          itemBuilder: (context,
                                                              index) {
                                                            return Container(
                                                              decoration: BoxDecoration(
                                                                color:
                                                                Colors
                                                                    .transparent,
                                                                borderRadius: BorderRadius
                                                                    .only(
                                                                    bottomLeft: Radius
                                                                        .circular(
                                                                        15),
                                                                    bottomRight: Radius
                                                                        .circular(
                                                                        15)),),
                                                              child: ClipRRect(
                                                                borderRadius: BorderRadius
                                                                    .only(
                                                                    bottomLeft: Radius
                                                                        .circular(
                                                                        15),
                                                                    bottomRight: Radius
                                                                        .circular(
                                                                        15)),
                                                                child: Image
                                                                    .network(
                                                                  widget.post
                                                                      .postFiles[
                                                                  index]['file_path'],
                                                                  fit: BoxFit
                                                                      .cover,
                                                                ),
                                                              ),
                                                            );
                                                          },
                                                          staggeredTileBuilder: (
                                                              index) {
                                                            return StaggeredTile
                                                                .count(1,
                                                                index.isEven
                                                                    ? 0.6
                                                                    : 0.6);
                                                          },
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' &&
                                                            widget.post
                                                                .postFiles
                                                                .length >
                                                                4 &&
                                                            widget.post
                                                                .postFiles[0]['file_type'] ==
                                                                'image'
                                                            ? StaggeredGridView
                                                            .countBuilder(
                                                            crossAxisCount: 2,
                                                            crossAxisSpacing: 3,
                                                            mainAxisSpacing: 3,
                                                            shrinkWrap: true,
                                                            physics:
                                                            ScrollPhysics(),
                                                            itemCount:
                                                            widget.post
                                                                .postFiles
                                                                .length >= 5
                                                                ? 4
                                                                : widget
                                                                .post
                                                                .postFiles
                                                                .length,
                                                            itemBuilder:
                                                                (context,
                                                                index) {
                                                              return widget
                                                                  .post
                                                                  .postFiles
                                                                  .length >=
                                                                  5 &&
                                                                  index == 3
                                                                  ? Container(
                                                                decoration: BoxDecoration(
                                                                  color: Colors
                                                                      .transparent,
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),),
                                                                child:
                                                                ClipRRect(
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),
                                                                  child: Image
                                                                      .network(
                                                                    widget.post
                                                                        .postFiles[index]
                                                                    [
                                                                    'file_path'],
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              )
                                                                  : Container(
                                                                decoration: BoxDecoration(
                                                                  color: Colors
                                                                      .transparent,
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),),
                                                                child:
                                                                ClipRRect(
                                                                  borderRadius: BorderRadius
                                                                      .only(
                                                                      bottomLeft: Radius
                                                                          .circular(
                                                                          15),
                                                                      bottomRight: Radius
                                                                          .circular(
                                                                          15)),
                                                                  child: Image
                                                                      .network(
                                                                    widget.post
                                                                        .postFiles[index]
                                                                    [
                                                                    'file_path'],
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              );
                                                            },
                                                            staggeredTileBuilder:
                                                                (index) {
                                                              return StaggeredTile
                                                                  .count(
                                                                  1,
                                                                  index.isEven
                                                                      ? 0.6
                                                                      : 0.6);
                                                            })
                                                            : widget.post
                                                            .postType ==
                                                            'video' &&
                                                            widget.post
                                                                .postFiles
                                                                .length ==
                                                                1
                                                            ? ChewieVideoPlayer(
                                                          post: widget.post,
                                                          index: 0,
                                                          thumbnailUrl: widget
                                                              .post
                                                              .postFiles[0]
                                                          [
                                                          'thumbnail_path'] !=
                                                              null
                                                              ? widget.post
                                                              .postFiles[0]
                                                          [
                                                          'thumbnail_path']
                                                              : 'https://www.johnbanks.co.uk/img/used-cars/video-thumbnail.png',
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'audio' &&
                                                            widget
                                                                .post
                                                                .postFiles
                                                                .length ==
                                                                1
                                                            ? ChewieVideoPlayer(
                                                          post: widget.post,
                                                          index: 0,
                                                          isAudio: true,
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' &&
                                                            widget
                                                                .post
                                                                .postFiles
                                                                .length >
                                                                1 &&
                                                            widget.post
                                                                .postFiles[0]
                                                            ['file_type'] ==
                                                                'audio'
                                                            ? Column(
                                                          children: [
                                                            for (var i =
                                                            0;
                                                            i <
                                                                widget
                                                                    .post
                                                                    .postFiles
                                                                    .length;
                                                            i++)
                                                              Padding(
                                                                padding: const EdgeInsets
                                                                    .symmetric(
                                                                    vertical:
                                                                    4.0),
                                                                child:
                                                                ChewieVideoPlayer(
                                                                  post: widget
                                                                      .post,
                                                                  index:
                                                                  i,
                                                                ),
                                                              ),
                                                          ],
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'attachment' &&
                                                            widget
                                                                .post.postFiles
                                                                .length == 1
                                                            ? ListTile(
                                                          onTap: () {
                                                            launch(widget
                                                                .post
                                                                .postFiles[0]['file_path']);
                                                          },
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                  10)),
                                                          tileColor:
                                                          Colors.grey[
                                                          100],
                                                          leading:
                                                          SizedBox(
                                                            height:
                                                            28,
                                                            width: 28,
                                                            child: Image
                                                                .asset(
                                                                'assets/images/document.png'),
                                                          ),
                                                          title: Text(
                                                              "${widget.post
                                                                  .postFiles[0]['original_name']}",
                                                              style: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness
                                                                      .dark
                                                                  ?
                                                              TextStyle(
                                                                  color: Colors
                                                                      .white,
                                                                  fontWeight: FontWeight
                                                                      .bold
                                                              )
                                                                  : TextStyle(
                                                                  color: Colors
                                                                      .black,
                                                                  fontWeight: FontWeight
                                                                      .bold
                                                              )
                                                          ),
                                                        )
                                                            : widget.post
                                                            .postType ==
                                                            'gallery' && widget
                                                            .post.postFiles
                                                            .length > 1 &&
                                                            widget
                                                                .post
                                                                .postFiles[0]['file_type'] ==
                                                                'attachment'
                                                            ? Column(
                                                          children: [
                                                            for (var i = 0;
                                                            i < widget.post
                                                                .postFiles
                                                                .length;
                                                            i++)
                                                              Padding(
                                                                padding: const EdgeInsets
                                                                    .symmetric(
                                                                    vertical: 4.0),
                                                                child: ListTile(
                                                                  onTap: () {
                                                                    launch(
                                                                        widget
                                                                            .post
                                                                            .postFiles[i]['file_path']);
                                                                  },
                                                                  shape: RoundedRectangleBorder(
                                                                      borderRadius: BorderRadius
                                                                          .circular(
                                                                          10)),
                                                                  tileColor: Colors
                                                                      .grey[100],
                                                                  leading: SizedBox(
                                                                      height: 28,
                                                                      width: 28,
                                                                      child: Image
                                                                          .asset(
                                                                          'assets/images/document.png')),
                                                                  title: Text(
                                                                      "${widget
                                                                          .post
                                                                          .postFiles[i]['original_name']}",
                                                                      style: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ?
                                                                      TextStyle(
                                                                          color: Colors
                                                                              .white,
                                                                          fontWeight: FontWeight
                                                                              .bold
                                                                      )
                                                                          : TextStyle(
                                                                          color: Colors
                                                                              .black,
                                                                          fontWeight: FontWeight
                                                                              .bold
                                                                      )
                                                                  ),
                                                                ),
                                                              ),
                                                          ],
                                                        )
                                                            : Container(),
                                                      ],
                                                    ),
                                                  ),

                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                    },
                                  ),
                                ),
                              ],
                            ),

                            /// optionsformedia
                            widget.controller.mediaApiCheck != true
                                ? Column(
                              children: [
                                Align(
                                  alignment: controller.languageData.appLang
                                      .id ==
                                      2 ? Alignment.topRight : Alignment
                                      .topLeft,
                                  child: Container(
                                    // decoration: BoxDecoration(
                                    //     borderRadius: BorderRadius.circular(20.0),
                                    //     color: Colors.transparent,
                                    //     border: Border.all(color: Colors.grey[300])),
                                    child:
                                    DropdownButton<String>(
                                      underline: Container(
                                        height: 0,
                                      ),
                                      icon: Visibility(
                                          visible: false,
                                          child: Icon(Icons
                                              .arrow_downward)),
                                      dropdownColor: Theme
                                          .of(
                                          context)
                                          .brightness ==
                                          Brightness.dark
                                          ? Colors.black
                                          : Colors.white,
                                      style: TextStyle(
                                        color: controller
                                            .displayColor,
                                        fontSize: 15,
                                        fontWeight:
                                        FontWeight.bold,
                                      ),
                                      hint: Row(
                                        mainAxisAlignment: MainAxisAlignment
                                            .start,
                                        children: [
                                          controller.modelList2[0].selectType ==
                                              Strings.everyOne
                                              ? Icon(
                                            Icons
                                                .public_outlined,
                                            color: controller
                                                .displayColor,
                                            size: 20,
                                          )
                                              : controller.modelList2[0]
                                              .selectType ==
                                              "People you Follow"
                                              ? Icon(
                                            Icons
                                                .person_add_alt_outlined,
                                            color: controller
                                                .displayColor,
                                            size: 20,
                                          )
                                              : controller.modelList2[0]
                                              .selectType ==
                                              "Only people you mention"
                                              ? Icon(
                                            Icons
                                                .alternate_email_outlined,
                                            color:
                                            controller.displayColor,
                                            size:
                                            20,
                                          )
                                              : Icon(
                                            Icons
                                                .public_outlined,
                                            color:
                                            controller.displayColor,
                                            size:
                                            20,
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          Text(
                                              controller.modelList2[0]
                                                  .selectType ==
                                                  null ||
                                                  controller.modelList2[0]
                                                      .selectType ==
                                                      ""
                                                  ? Strings.everyOne
                                                  : "${controller.modelList2[0]
                                                  .selectType}",
                                              style: TextStyle(
                                                color: controller
                                                    .displayColor,
                                                fontSize: 15,
                                                fontWeight:
                                                FontWeight
                                                    .bold,
                                              )),
                                        ],

                                      ),
                                      items: <String>[
                                        Strings.everyOne,
                                        Strings.peopleYouFollow,
                                        Strings.onlyPeopleYouMention
                                      ].map((String value) {
                                        return DropdownMenuItem<
                                            String>(
                                          value: value,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment
                                                .start,

                                            children: [
                                              CircleAvatar(
                                                radius: 20,
                                                backgroundColor:
                                                controller
                                                    .displayColor,
                                                child: value ==
                                                    Strings.everyOne
                                                    ? Icon(
                                                  Icons
                                                      .public_outlined,
                                                  color: Colors
                                                      .white,
                                                  size: 20,
                                                )
                                                    : value ==
                                                    "People you Follow"
                                                    ? Icon(
                                                  Icons
                                                      .person_add_alt_outlined,
                                                  color:
                                                  Colors.white,
                                                  size:
                                                  20,
                                                )
                                                    : value ==
                                                    "Only people you mention"
                                                    ? Icon(
                                                  Icons
                                                      .alternate_email_outlined,
                                                  color: Colors.white,
                                                  size: 20,
                                                )
                                                    : null,
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                value,
                                                style: TextStyle(
                                                  color: Theme
                                                      .of(context)
                                                      .brightness ==
                                                      Brightness
                                                          .dark
                                                      ? Colors
                                                      .white
                                                      : Colors
                                                      .black,
                                                  fontSize: 15,
                                                  fontWeight:
                                                  FontWeight
                                                      .bold,
                                                ),
                                              ),
                                            ],

                                          ),
                                        );
                                      }).toList(),
                                      onChanged: (_) {
                                        setState(() {
                                          controller.modelList2[0].selectType =
                                              _;

                                          print(
                                              "widget.controller.selectType ${controller
                                                  .modelList2[0].selectType}");
                                        });
                                        if (_ == "Everyone") {
                                          controller.modelList2[0]
                                              .selectedType =
                                          "public";
                                        } else if (_ == "People you follow") {
                                          controller.modelList2[0]
                                              .selectedType =
                                          "follow_followers";
                                        } else
                                        if (_ == "Only people you mention") {
                                          controller.modelList2[0]
                                              .selectedType =
                                          "mention_users";
                                        } else {
                                          controller.modelList2[0]
                                              .selectedType =
                                          "public";
                                        }
                                      },
                                    ),
                                  ),
                                ),
                                Row(
                                  mainAxisAlignment:
                                  MainAxisAlignment.spaceBetween,
                                  children: [

                                    ///imageicon
                                    /// edit image button
                                    isEdit == true && editImageCheck == true
                                        ? InkWell(
                                      onTap: editImageCheck == false
                                          ? () {}
                                          : callGetImage,
                                      child: Container(
                                          width: 25,
                                          height: 25,
                                          child: SvgPicture.asset(
                                              'assets/post_icons/image.svg',
                                              height: 150,
                                              color: editImageCheck == false ||
                                                  controller
                                                      .modelList2[controller
                                                      .currentIndexText]
                                                      .isMediaAttached == true
                                                  ? Colors.grey[400]
                                                  : MyColors.werfieBlue)),
                                    )
                                        : InkWell(
                                      onTap: widget.controller.modelList2[widget
                                          .controller.currentIndexText]
                                          .mediaData2
                                          .length > 0 &&
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .isMediaAttached == true ||
                                          showPolls[controller
                                              .currentIndexText] ==
                                              true
                                          ? () {}
                                          : callGetImage,
                                      child: Container(
                                          width: 25,
                                          height: 25,
                                          child: SvgPicture.asset(
                                            // _pickedPdfs.length > 0 ||
                                            //     _pickedAudios.length > 0 ||
                                            //     _pickedVideos.length > 0
                                            //     ?
                                            'assets/post_icons/image.svg',

                                            color: /*_pickedVideos.isNotEmpty || isMediaAttached || showPolls ?*/
                                            controller
                                                .modelList2[widget
                                                .controller
                                                .currentIndexText]
                                                .mediaData2
                                                .length >
                                                0 &&
                                                controller.modelList2[controller
                                                    .currentIndexText]
                                                    .isMediaAttached ==
                                                    true ||
                                                showPolls[controller
                                                    .currentIndexText] ==
                                                    true
                                            //  ||editImageCheck==false

                                                ? Colors.grey[400]
                                                : controller
                                                .displayColor,
                                            //  : Color(0xFF47b867),
                                            // : 'assets/post_icons/image_color.png',
                                          )
                                        // Image.asset(_pickedPdfs.length > 0 ||
                                        //     _pickedAudios.length > 0 ||
                                        //     _pickedVideos.length > 0
                                        //     ? 'assets/post_icons/image.png'
                                        //     : 'assets/post_icons/image_color.png'),
                                      ),
                                    ),

                                    ///videoicon
                                    InkWell(
                                      onTap:

                                      widget.controller
                                          .modelList2[widget
                                          .controller
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0 &&
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .isMediaAttached == true ||
                                          showPolls[controller
                                              .currentIndexText] == true ||
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .isImageAttached == true
                                          ? () {}
                                      // _pickedVideos.isNotEmpty ||
                                      //     isMediaAttached ||
                                      //     showPolls
                                      //     ? () {}
                                      //     : _pickedPdfs.length > 0 ||
                                      //     _pickedAudios.length > 0 ||
                                      //     _pickedImage.length > 0
                                      //     ? () {}
                                      //     :
                                          : callGetVideo,
                                      child: Container(
                                          width: 25,
                                          height: 25,
                                          child: SvgPicture.asset(
                                            // _pickedPdfs.length > 0 ||
                                            //     _pickedAudios.length > 0 ||
                                            //     _pickedVideos.length > 0
                                            //     ?
                                            'assets/post_icons/video.svg',

                                            color:
                                            /* _pickedVideos.isNotEmpty || isMediaAttached || showPolls*/
                                            controller
                                                .modelList2[widget
                                                .controller
                                                .currentIndexText]
                                                .mediaData2
                                                .length >
                                                0
                                                //     && isMediaAttached ==true
                                                ||
                                                showPolls[controller
                                                    .currentIndexText] ==
                                                    true
                                                ? Colors.grey[400]
                                                : controller.displayColor,
                                            //  : Color(0xFFef5994),
                                            // : 'assets/post_icons/image_color.png',
                                          )
                                        // Image.asset(_pickedPdfs.length > 0 ||
                                        //     _pickedAudios.length > 0 ||
                                        //     _pickedImage.length > 0
                                        //     ? 'assets/post_icons/video.png'
                                        //     : 'assets/post_icons/video_color.png'),
                                      ),
                                    ),
                                    // SizedBox(
                                    //   width: Get.width * 0.01,
                                    //   // width: Get.width / 50,
                                    // ),
                                    // ///audioicon
                                    // InkWell(
                                    //   onTap: _pickedVideos.isNotEmpty ||
                                    //       isMediaAttached ||
                                    //       showPolls
                                    //       ? () {}
                                    //       : _pickedPdfs.length > 0 ||
                                    //       _pickedVideos.length > 0 ||
                                    //       _pickedImage.length > 0
                                    //       ? () {}
                                    //       : callGetAudio,
                                    //   child: Container(
                                    //       width: 25,
                                    //       height: 25,
                                    //       child: SvgPicture.asset(
                                    //         // _pickedPdfs.length > 0 ||
                                    //         //     _pickedAudios.length > 0 ||
                                    //         //     _pickedVideos.length > 0
                                    //         //     ?
                                    //         'assets/post_icons/mic.svg',
                                    //         color: _pickedVideos.isNotEmpty ||
                                    //             isMediaAttached ||
                                    //             showPolls
                                    //             ? Colors.grey[400]
                                    //             : Color(0xFFedc01c),
                                    //         // : 'assets/post_icons/image_color.png',
                                    //       )
                                    //     // Image.asset(_pickedPdfs.length > 0 ||
                                    //     //     _pickedVideos.length > 0 ||
                                    //     //     _pickedImage.length > 0
                                    //     //     ? 'assets/post_icons/mic.png'
                                    //     //     : 'assets/post_icons/mic_color.png'),
                                    //   ),
                                    // ),
                                    ///pdficon
                                    InkWell(
                                      onTap: widget
                                          .controller
                                          .modelList2[widget
                                          .controller
                                          .currentIndexText]
                                          .mediaData2
                                          .length >
                                          0
                                          //   && isMediaAttached ==true
                                          ||
                                          showPolls[controller
                                              .currentIndexText] ==
                                              true
                                          || controller.modelList2[controller
                                              .currentIndexText]
                                              .isImageAttached == true
                                          ? () {}
                                      /*_pickedVideos.isNotEmpty ||
                                        isMediaAttached ||
                                        showPolls
                                        ? () {}
                                        : _pickedAudios.length > 0 ||
                                        _pickedVideos.length > 0 ||
                                        _pickedImage.length > 0
                                        ? () {}
                                        : */
                                          : callGetFile,
                                      child: Container(
                                          width: 25,
                                          height: 25,
                                          child: SvgPicture.asset(
                                            // _pickedPdfs.length > 0 ||
                                            //     _pickedAudios.length > 0 ||
                                            //     _pickedVideos.length > 0
                                            //     ?
                                            'assets/post_icons/attach_500.svg',
                                            color: /*_pickedVideos.isNotEmpty || isMediaAttached || showPolls ? Colors.grey[400] :*/
                                            controller
                                                .modelList2[widget
                                                .controller
                                                .currentIndexText]
                                                .mediaData2
                                                .length >
                                                0 ||
                                                showPolls[controller
                                                    .currentIndexText] ==
                                                    true ||
                                                controller.modelList2[controller
                                                    .currentIndexText]
                                                    .isImageAttached == true
                                                ? Colors.grey[400]
                                                : controller.displayColor,
                                            // : Color(0xFF6e89c5),
                                            // : 'assets/post_icons/image_color.png',
                                          )
                                        // Image.asset(_pickedAudios.length > 0 ||
                                        //     _pickedVideos.length > 0 ||
                                        //     _pickedImage.length > 0
                                        //     ? 'assets/post_icons/attach.png'
                                        //     : 'assets/post_icons/attach_color.png'),
                                      ),
                                    ),

                                    // ///poll icon
                                    // ///
                                    // InkWell(
                                    //   onTap:
                                    //   // isMediaUploading
                                    //   controller.modelList2[widget.controller.currentIndexText].mediaData2.length > 0
                                    //       ? () {}
                                    //       :
                                    //   //_pickedVideos.isNotEmpty ||
                                    //   //   isMediaAttached ||
                                    //   showPolls[controller.currentIndexText] || widget.isPostScheduled
                                    //       ? () {}
                                    //       : () {
                                    //
                                    //     print(_controller.length);
                                    //     print("controller.currentIndexText poll ${controller.currentIndexText}");
                                    //     // _controller[controller.currentIndexText] = TextEditingController();
                                    //     showPolls[controller.currentIndexText] = true;
                                    //     controller.modelList2[controller.currentIndexText].poolThread = true;
                                    //     setState(() {});
                                    //   },
                                    //   child: Container(
                                    //     height: 25,
                                    //     width: 25,
                                    //     child: SvgPicture.asset(
                                    //       // _pickedPdfs.length > 0 ||
                                    //       //     _pickedAudios.length > 0 ||
                                    //       //     _pickedVideos.length > 0
                                    //       //     ?
                                    //       'assets/post_icons/polls.svg',
                                    //
                                    //       color:
                                    //       //  isMediaUploading
                                    //       controller
                                    //           .modelList2[widget
                                    //           .controller
                                    //           .currentIndexText]
                                    //           .mediaData2
                                    //           .length >
                                    //           0
                                    //           ? Colors.grey[400]
                                    //           :
                                    //       // _pickedVideos.isNotEmpty ||
                                    //       //  isMediaAttached ||
                                    //       widget.isPostScheduled ||
                                    //           showPolls[controller
                                    //               .currentIndexText]
                                    //           ? Colors.grey[400]
                                    //           : controller.displayColor,
                                    //       //  : Colors.green,
                                    //     ),
                                    //   ),
                                    // ),

                                    ///schdeuleicon

                                    InkWell(
                                      onTap: controller.modelList2[widget
                                          .controller.currentIndexText]
                                          .mediaData2
                                          .length > 0
                                          ||
                                          controller.modelList2[0].selectType ==
                                              "People you follow"
                                          ||
                                          controller.modelList2[0].selectType ==
                                              "Only people you mention"
                                      //  ||
                                      //   showPolls
                                          ? () {}
                                          : () async {
                                        bool val = await showDialog(
                                          context: context,
                                          builder: (context) {
                                            selectedDateTime =
                                                DateTime.now()
                                                    .toString();

                                            return AlertDialog(
                                              content: StatefulBuilder(
                                                  builder: (context,
                                                      setState) {
                                                    return AnimatedContainer(
                                                      curve:
                                                      Curves.easeIn,
                                                      width: Get.width *
                                                          0.35,
                                                      duration: Duration(
                                                          microseconds:
                                                          500000),
                                                      height:
                                                      showScheduledWerfs
                                                          ? Get.height *
                                                          0.8
                                                          : 480,
                                                      child: Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .start,
                                                        children: [
                                                          Row(
                                                            children: [
                                                              GestureDetector(
                                                                  onTap:
                                                                      () {
                                                                    Navigator
                                                                        .pop(
                                                                        context,
                                                                        false);
                                                                  },
                                                                  child:
                                                                  Icon(
                                                                    Icons
                                                                        .close,
                                                                    color: Theme
                                                                        .of(
                                                                        context)
                                                                        .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                        ? Colors
                                                                        .white
                                                                        : Colors
                                                                        .black,
                                                                  )),
                                                              SizedBox(
                                                                  width:
                                                                  12),
                                                              Text(
                                                                Strings
                                                                    .schedule,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                      ? Colors
                                                                      .white
                                                                      : Colors
                                                                      .black,
                                                                  //   fontSize: kIsWeb ? 16 : 14,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .bold,
                                                                ),
                                                              ),
                                                              Spacer(),
                                                              RoundedButton(
                                                                Strings
                                                                    .confirm,

                                                                // hourValidatedSuccessfully &&
                                                                //         minutesValidatedSuccessfully &&
                                                                //         monthValidatedSuccessfully &&
                                                                //         dayValidatedSuccessfully
                                                                //     ? null
                                                                //     :
                                                                    () {
                                                                  if (monthValidatedSuccessfully) {
                                                                    widget
                                                                        .isPostScheduled =
                                                                    true;

                                                                    //  visibility=false;

                                                                    Navigator
                                                                        .pop(
                                                                        context,
                                                                        true);
                                                                  }
                                                                },
                                                                horizontalPadding:
                                                                20.0,
                                                                verticalPadding:
                                                                0.0,
                                                                roundedButtonColor:
                                                                controller
                                                                    .displayColor,
                                                              ),
                                                            ],
                                                          ),
                                                          // ListTile(
                                                          // //  horizontalTitleGap: 30.0,
                                                          //   leading: Icon(
                                                          //       Icons.calendar_today,
                                                          //     color: Color(0xFF586976),
                                                          //   ),
                                                          //   title: Text(
                                                          //       'Will send on ${selectedDayValue}, ${selectedMonthValue != null ? selectedMonthValue : DateFormat('MMM').format(DateTime.now())} ,${selectedYearValue} at ${selectedHourValue}:${selectedMinutesValue}',
                                                          //           style: Styles.baseTextTheme.headline2.copyWith(
                                                          //            // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                          //             fontSize: kIsWeb ? 14 : 14,
                                                          //             fontWeight: FontWeight.w400,
                                                          //           ),
                                                          //   ),
                                                          // ),
                                                          SizedBox(
                                                            height: 20,
                                                          ),

                                                          Row(
                                                            children: [
                                                              Icon(
                                                                Icons
                                                                    .calendar_today,
                                                                color: Color(
                                                                    0xFF586976),
                                                              ),
                                                              SizedBox(
                                                                width: 20,
                                                              ),
                                                              Text(
                                                                '${Strings.willPostOn} ${DateFormat
                                                                    .yMMMMd()
                                                                    .add_jm()
                                                                    .format(
                                                                    DateFormat(
                                                                        "yyyy-MM-dd HH:mm:ss")
                                                                        .parse(
                                                                        selectedDateTime))}',
                                                                // 'Will Post on ${DateFormat("yyyy-MM-dd hh:mm ").parse(selectedDateTime)}',
                                                                // 'Will Post on ${DateFormat.yMMMMd().add_jm().format(widget.dateTimeData)}',
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline2
                                                                    .copyWith(
                                                                  // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                  fontSize: kIsWeb
                                                                      ? 14
                                                                      : 14,
                                                                  fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 10,
                                                          ),
                                                          Text(
                                                            Strings.date,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              //  color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize:
                                                              kIsWeb
                                                                  ? 16
                                                                  : 14,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w500,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                              height: 10),
                                                          /* Date DropDown Section */
                                                          Row(
                                                            mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .spaceBetween,
                                                            children: [
                                                              // Drop Down Button for Month
                                                              ButtonTheme(
                                                                materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                                child:
                                                                Expanded(
                                                                  flex: 2,
                                                                  child: DropdownButtonFormField<
                                                                      String>(
                                                                    icon:
                                                                    Icon(Icons
                                                                        .keyboard_arrow_down),
                                                                    isExpanded:
                                                                    true,

                                                                    decoration:
                                                                    InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical: 8,
                                                                          horizontal: 16),
                                                                      border:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .grey,
                                                                          //  width: 1,
                                                                          // style: BorderStyle.none,
                                                                        ),
                                                                      ),
                                                                      disabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          color: Theme
                                                                              .of(
                                                                              context)
                                                                              .brightness ==
                                                                              Brightness
                                                                                  .dark
                                                                              ? Colors
                                                                              .white
                                                                              : Colors
                                                                              .grey,
                                                                          // width: 1,
                                                                          // style: BorderStyle.none,
                                                                        ),
                                                                      ),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          color: controller
                                                                              .displayColor,
                                                                          //  width: 1,
                                                                          //  style: BorderStyle.none,
                                                                        ),
                                                                      ),
                                                                      labelText:
                                                                      Strings.month,
                                                                      labelStyle:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint:
                                                                    Text(
                                                                      months[DateTime
                                                                          .now()
                                                                          .month -
                                                                          1],
                                                                      style:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),

                                                                    alignment:
                                                                    Alignment
                                                                        .bottomCenter,
                                                                    items:
                                                                    months.map((
                                                                        String value) {
                                                                      return DropdownMenuItem<
                                                                          String>(
                                                                        value: value,
                                                                        child: Text(
                                                                          value
                                                                              .toString(),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged:
                                                                        (
                                                                        month) {
                                                                      /*        int selectedMonthIndex = months.indexWhere((element) =>
                                                                element ==
                                                                    month);
                                                                int currentMonthIndex = months.indexWhere((element) =>
                                                                element ==
                                                                    months[DateTime.now().month - 1]);
                                                                selectedMonthValue =
                                                                    (months.indexWhere((element) => element == month) + 1).toString();
                                                                scheduleMonthValue =
                                                                    (months.indexWhere((element) => element == month) + 1).toString();
                                                                print('SELECTED  $selectedMonthIndex' +
                                                                    ' : ' +
                                                                    'CURRENT $currentMonthIndex');*/

                                                                      selectedMonthValue =
                                                                          (months
                                                                              .indexWhere((
                                                                              element) =>
                                                                          element ==
                                                                              month) +
                                                                              1)
                                                                              .toString();

                                                                      selectedDateTime =
                                                                          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
                                                                              " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(
                                                                          selectedDateTime)) {
                                                                        monthValidatedSuccessfully =
                                                                        true;
                                                                      } else {
                                                                        monthValidatedSuccessfully =
                                                                        false;
                                                                      }
                                                                      setState(() {});

                                                                      // setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width:
                                                                  12),
                                                              // Drop Down Button for Day
                                                              ButtonTheme(
                                                                materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                                child:
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<
                                                                      String>(
                                                                    icon:
                                                                    Icon(Icons
                                                                        .keyboard_arrow_down),
                                                                    isExpanded:
                                                                    true,
                                                                    decoration:
                                                                    InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical: 8,
                                                                          horizontal: 16),
                                                                      border:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //width: 1,
                                                                          // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      disabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          // width: 1,
                                                                          //  style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          // width: 1,
                                                                          //  style: BorderStyle.none,
                                                                          color: controller
                                                                              .displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText:
                                                                     Strings.day,
                                                                      labelStyle:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint:
                                                                    Text(
                                                                      selectedDayValue,
                                                                      style:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment:
                                                                    Alignment
                                                                        .bottomCenter,
                                                                    items: List
                                                                        .generate(
                                                                        31,
                                                                            (
                                                                            index) =>
                                                                        index +
                                                                            1)
                                                                        .map((
                                                                        int
                                                                        value) {
                                                                      return DropdownMenuItem<
                                                                          String>(
                                                                        value: value
                                                                            .toString(),
                                                                        child: Text(
                                                                          value
                                                                              .toString(),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged:
                                                                        (day) {
                                                                      selectedDayValue =
                                                                          day;
                                                                      scheduleDayValue =
                                                                          day;
                                                                      int currentDay =
                                                                          DateTime
                                                                              .now()
                                                                              .day;
                                                                      selectedDateTime =
                                                                          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
                                                                              " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(
                                                                          selectedDateTime)) {
                                                                        monthValidatedSuccessfully =
                                                                        true;
                                                                      } else {
                                                                        monthValidatedSuccessfully =
                                                                        false;
                                                                      }
                                                                      setState(() {});
                                                                      // }
                                                                    },
                                                                  ),
                                                                ),
                                                              ),

                                                              SizedBox(
                                                                  width:
                                                                  12),

                                                              // Drop Down Button for Year
                                                              ButtonTheme(
                                                                materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                                child:
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<
                                                                      String>(
                                                                    icon:
                                                                    Icon(Icons
                                                                        .keyboard_arrow_down),
                                                                    isExpanded:
                                                                    true,
                                                                    decoration:
                                                                    InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical: 8,
                                                                          horizontal: 12),
                                                                      border:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //  width: 1,
                                                                          // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      disabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //  width: 1,
                                                                          // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //width: 1,
                                                                          // style: BorderStyle.none,
                                                                          color: controller
                                                                              .displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText:
                                                                      Strings.year,
                                                                      labelStyle:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint:
                                                                    Text(
                                                                      DateTime
                                                                          .now()
                                                                          .year
                                                                          .toString(),
                                                                      style:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment:
                                                                    Alignment
                                                                        .bottomCenter,
                                                                    items:
                                                                    years.map((
                                                                        int value) {
                                                                      return DropdownMenuItem<
                                                                          String>(
                                                                        value: value
                                                                            .toString(),
                                                                        child: Text(
                                                                          value
                                                                              .toString(),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged:
                                                                        (year) {
                                                                      selectedYearValue =
                                                                          year;

                                                                      scheduleYearValue =
                                                                          year;

                                                                      selectedDateTime =
                                                                          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
                                                                              " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(
                                                                          selectedDateTime)) {
                                                                        monthValidatedSuccessfully =
                                                                        true;
                                                                      } else {
                                                                        monthValidatedSuccessfully =
                                                                        false;
                                                                      }
                                                                      setState(() {});
                                                                      //

                                                                      print(
                                                                          'Scheduled Year ' +
                                                                              scheduleYearValue
                                                                                  .toString());
                                                                      // setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                          !monthValidatedSuccessfully
                                                              ? Text(
                                                            Strings.youCannotScheduleAWerfInThePast,
                                                            style:
                                                            TextStyle(
                                                              color:
                                                              Colors.red,
                                                              fontSize: kIsWeb
                                                                  ? 14
                                                                  : 12,
                                                            ),
                                                          )
                                                              : SizedBox(),
                                                          SizedBox(
                                                              height: 20),
                                                          /* Time DropDown Section */
                                                          Text(
                                                            Strings.time,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize:
                                                              kIsWeb
                                                                  ? 16
                                                                  : 14,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w500,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                              height: 10),
                                                          Row(
                                                            children: [
                                                              /* DropDown Button For Hours */
                                                              ButtonTheme(
                                                                materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                                child:
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<
                                                                      String>(
                                                                    icon:
                                                                    Icon(Icons
                                                                        .keyboard_arrow_down),
                                                                    isExpanded:
                                                                    true,
                                                                    decoration:
                                                                    InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical: 8,
                                                                          horizontal: 16),
                                                                      border:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          // width: 1,
                                                                          //  style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      disabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //  width: 1,
                                                                          //  style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //  width: 1,
                                                                          // style: BorderStyle.none,
                                                                          color: controller
                                                                              .displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText:
                                                                      Strings.hours,
                                                                      labelStyle:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint:
                                                                    Text(
                                                                      selectedHourValue,
                                                                      style:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment:
                                                                    Alignment
                                                                        .bottomCenter,
                                                                    items: List
                                                                        .generate(
                                                                        24,
                                                                            (
                                                                            index) =>
                                                                        index)
                                                                        .map((
                                                                        int
                                                                        value) {
                                                                      return DropdownMenuItem<
                                                                          String>(
                                                                        value: value
                                                                            .toString(),
                                                                        child: Text(
                                                                          value
                                                                              .toString(),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged:
                                                                        (hour) {
                                                                      selectedHourValue =
                                                                          hour;
                                                                      scheduleHourValue =
                                                                          hour;

                                                                      selectedDateTime =
                                                                          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
                                                                              " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(
                                                                          selectedDateTime)) {
                                                                        monthValidatedSuccessfully =
                                                                        true;
                                                                      } else {
                                                                        monthValidatedSuccessfully =
                                                                        false;
                                                                      }
                                                                      setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              /* DropDown Button For Minutes */
                                                              SizedBox(
                                                                  width:
                                                                  12),
                                                              ButtonTheme(
                                                                materialTapTargetSize:
                                                                MaterialTapTargetSize
                                                                    .padded,
                                                                child:
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: DropdownButtonFormField<
                                                                      String>(
                                                                    icon:
                                                                    Icon(Icons
                                                                        .keyboard_arrow_down),
                                                                    isExpanded:
                                                                    true,
                                                                    decoration:
                                                                    InputDecoration(
                                                                      contentPadding:
                                                                      EdgeInsets
                                                                          .symmetric(
                                                                          vertical: 8,
                                                                          horizontal: 16),
                                                                      border:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          // width: 1,
                                                                          // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      disabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          // width: 1,
                                                                          // style: BorderStyle.none,
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .grey),
                                                                      ),
                                                                      enabledBorder:
                                                                      OutlineInputBorder(
                                                                        borderRadius: BorderRadius
                                                                            .circular(
                                                                            10),
                                                                        borderSide: BorderSide(
                                                                          //   width: 1,
                                                                          //  style: BorderStyle.none,
                                                                          color: controller
                                                                              .displayColor,
                                                                        ),
                                                                      ),
                                                                      labelText:
                                                                      Strings.minutes,
                                                                      labelStyle:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    // value: 0.toString(),
                                                                    hint:
                                                                    Text(
                                                                      selectedMinutesValue,
                                                                      style:
                                                                      Styles
                                                                          .baseTextTheme
                                                                          .headline4
                                                                          .copyWith(
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                        fontSize: 14,
                                                                      ),
                                                                    ),
                                                                    alignment:
                                                                    Alignment
                                                                        .bottomCenter,
                                                                    items: List
                                                                        .generate(
                                                                        60,
                                                                            (
                                                                            index) =>
                                                                        index)
                                                                        .map((
                                                                        int
                                                                        value) {
                                                                      return DropdownMenuItem<
                                                                          String>(
                                                                        value: value
                                                                            .toString(),
                                                                        child: Text(
                                                                          value
                                                                              .toString(),
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            color: Theme
                                                                                .of(
                                                                                context)
                                                                                .brightness ==
                                                                                Brightness
                                                                                    .dark
                                                                                ? Colors
                                                                                .white
                                                                                : Colors
                                                                                .black,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      );
                                                                    }).toList(),
                                                                    onChanged:
                                                                        (
                                                                        minute) {
                                                                      selectedMinutesValue =
                                                                          minute;
                                                                      scheduleMinutesValue =
                                                                          minute;
                                                                      print(
                                                                          "value$minute");
                                                                      selectedDateTime =
                                                                          "$selectedYearValue-$selectedMonthValue-$selectedDayValue" +
                                                                              " $selectedHourValue:$selectedMinutesValue:00";

                                                                      if (compareSelectedDatetime(
                                                                          selectedDateTime)) {
                                                                        monthValidatedSuccessfully =
                                                                        true;
                                                                      } else {
                                                                        monthValidatedSuccessfully =
                                                                        false;
                                                                      }
                                                                      setState(() {});
                                                                    },
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                  width:
                                                                  12),
                                                              Expanded(
                                                                  flex: 1,
                                                                  child:
                                                                  SizedBox()),
                                                            ],
                                                          ),
                                                          /*     if (!dayValidatedSuccessfully)
                                                                        Text(
                                                                          'You cannot schedule a Werf in the past',
                                                                          style:
                                                                              TextStyle(
                                                                            color: Colors
                                                                                .red,
                                                                            fontSize:
                                                                                kIsWeb
                                                                                    ? 14
                                                                                    : 12,
                                                                          ),
                                                                        )
                                                                      else
                                                                        SizedBox(),*/
                                                          SizedBox(
                                                              height: 20),
                                                          Text(
                                                            Strings.timeZone,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                              fontSize:
                                                              kIsWeb
                                                                  ? 16
                                                                  : 14,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w500,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                              height: 10),
                                                          Text(
                                                            DateTime
                                                                .now()
                                                                .timeZoneName,
                                                            style: Styles
                                                                .baseTextTheme
                                                                .headline2
                                                                .copyWith(
                                                              color: Theme
                                                                  .of(context)
                                                                  .brightness ==
                                                                  Brightness
                                                                      .dark
                                                                  ? Colors
                                                                  .white
                                                                  : Colors
                                                                  .black,
                                                              //fontSize: kIsWeb ? 16 : 14,
                                                              fontWeight:
                                                              FontWeight
                                                                  .bold,
                                                            ),
                                                          ),
                                                          Divider(
                                                              height: 1),
                                                          // GestureDetector(
                                                          //   onTap:
                                                          //       () async {
                                                          //     widget
                                                          //         .controller
                                                          //         .noScheduledPost =
                                                          //     true;
                                                          //     isEditable =
                                                          //     false;
                                                          //     showScheduledWerfs =
                                                          //     !showScheduledWerfs;
                                                          //     setState(
                                                          //             () {});
                                                          //     widget.controller
                                                          //         .scheduledPosts =
                                                          //     await widget
                                                          //         .controller
                                                          //         .getScheduledPosts();
                                                          //     widget.controller
                                                          //         .noScheduledPost =
                                                          //     false;
                                                          //
                                                          //     setState(
                                                          //             () {});
                                                          //   },
                                                          //   child:
                                                          //   ListTile(
                                                          //     title: Text(
                                                          //       'Scheduled Werfs',
                                                          //       style: Styles
                                                          //           .baseTextTheme
                                                          //           .headline2
                                                          //           .copyWith(
                                                          //         color: Theme
                                                          //             .of(
                                                          //             context)
                                                          //             .brightness ==
                                                          //             Brightness
                                                          //                 .dark
                                                          //             ? Colors
                                                          //             .white
                                                          //             : Colors
                                                          //             .black,
                                                          //         fontSize: kIsWeb
                                                          //             ? 16
                                                          //             : 14,
                                                          //         fontWeight:
                                                          //         FontWeight
                                                          //             .w500,
                                                          //       ),
                                                          //     ),
                                                          //     trailing: Icon(
                                                          //         showScheduledWerfs
                                                          //             ? Icons
                                                          //             .expand_less
                                                          //             : Icons
                                                          //             .expand_more),
                                                          //   ),
                                                          // ),
                                                          if (showScheduledWerfs)
                                                            widget.controller
                                                                .noScheduledPost
                                                                ? CircularProgressIndicator()
                                                                : widget
                                                                .controller
                                                                .scheduledPosts
                                                                .isEmpty
                                                                ? Center(
                                                              child: Text(
                                                               Strings.youHaveNoScheduledWerfs,
                                                                style: Styles
                                                                    .baseTextTheme
                                                                    .headline4
                                                                    .copyWith(
                                                                  color: Theme
                                                                      .of(
                                                                      context)
                                                                      .brightness ==
                                                                      Brightness
                                                                          .dark
                                                                      ? Colors
                                                                      .white
                                                                      : Colors
                                                                      .black,
                                                                  fontSize: kIsWeb
                                                                      ? 14
                                                                      : 12,
                                                                ),
                                                              ),
                                                            )
                                                                : Expanded(
                                                              child: Column(
                                                                children: [
                                                                  GestureDetector(
                                                                      onTap: () {
                                                                        isEditable =
                                                                        !isEditable;
                                                                        setState(() {});
                                                                      },
                                                                      child: Align(
                                                                        alignment: Alignment
                                                                            .topRight,
                                                                        child: Text(
                                                                          isEditable
                                                                              ? Strings
                                                                              .cancel
                                                                              : Strings
                                                                              .edit,
                                                                          style: TextStyle(
                                                                              color: Colors
                                                                                  .blue,
                                                                              decoration: TextDecoration
                                                                                  .underline),
                                                                        ),
                                                                      )),
                                                                  Expanded(
                                                                    child: ListView
                                                                        .separated(
                                                                        shrinkWrap: true,
                                                                        itemBuilder: (
                                                                            context,
                                                                            index) {
                                                                          var dateTime = DateFormat(
                                                                              "yyyy-MM-dd HH:mm:ss")
                                                                              .parse(
                                                                              widget
                                                                                  .controller
                                                                                  .scheduledPosts[index]
                                                                                  .postingTime,
                                                                              true);
                                                                          var postingTime = dateTime
                                                                              .toLocal();
                                                                          postingTime =
                                                                              DateFormat(
                                                                                  'yyyy-MM-dd HH:mm')
                                                                                  .parse(
                                                                                  postingTime
                                                                                      .toString());

                                                                          return ListTile(
                                                                            leading: isEditable
                                                                                ? Checkbox(
                                                                                value: widget
                                                                                    .controller
                                                                                    .scheduledPosts[index]
                                                                                    .isScheduledPostSelectedForDeletion,
                                                                                onChanged: (
                                                                                    value) {
                                                                                  if (widget
                                                                                      .postsForDeletions
                                                                                      .contains(
                                                                                      widget
                                                                                          .controller
                                                                                          .scheduledPosts[index]
                                                                                          .id)) {
                                                                                    int ind = widget
                                                                                        .postsForDeletions
                                                                                        .indexWhere((
                                                                                        element) =>
                                                                                    element ==
                                                                                        widget
                                                                                            .controller
                                                                                            .scheduledPosts[index]
                                                                                            .id);

                                                                                    widget
                                                                                        .postsForDeletions
                                                                                        .removeAt(
                                                                                        ind);
                                                                                  } else {
                                                                                    widget
                                                                                        .postsForDeletions
                                                                                        .add(
                                                                                        widget
                                                                                            .controller
                                                                                            .scheduledPosts[index]
                                                                                            .id);
                                                                                  }
                                                                                  widget
                                                                                      .controller
                                                                                      .scheduledPosts[index]
                                                                                      .isScheduledPostSelectedForDeletion =
                                                                                  !widget
                                                                                      .controller
                                                                                      .scheduledPosts[index]
                                                                                      .isScheduledPostSelectedForDeletion;
                                                                                  widget
                                                                                      .controller
                                                                                      .update();
                                                                                  setState(() {});
                                                                                })
                                                                                : SizedBox(),
                                                                            title: Text(
                                                                                '${Strings.willSendOn} ${DateFormat(
                                                                                    'dd MMMM, yyyy HH:mm')
                                                                                    .format(
                                                                                    postingTime)}'),
                                                                            subtitle: Text(
                                                                                widget
                                                                                    .controller
                                                                                    .scheduledPosts[index]
                                                                                    .body),
                                                                          );
                                                                        },
                                                                        separatorBuilder: (
                                                                            _,
                                                                            __) {
                                                                          return Divider(
                                                                              height: 1);
                                                                        },
                                                                        itemCount: widget
                                                                            .controller
                                                                            .scheduledPosts
                                                                            .length),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          isEditable
                                                              ? ListTile(
                                                            leading:
                                                            Text(Strings.selectAll),
                                                            trailing:
                                                            GestureDetector(
                                                              onTap:
                                                                  () {
                                                                print('List ' +
                                                                    widget
                                                                        .postsForDeletions
                                                                        .toString());
                                                                widget
                                                                    .controller
                                                                    .deleteScheduledPosts(
                                                                  widget
                                                                      .postsForDeletions,
                                                                  context,
                                                                );
                                                                // widget
                                                                //     .postsForDeletions
                                                                //     .clear();
                                                              },
                                                              child:
                                                              Text(Strings
                                                                  .delete),
                                                            ),
                                                          )
                                                              : SizedBox(),
                                                        ],
                                                      ),
                                                    );
                                                  }),
                                            );
                                          },
                                        );
                                        if (val) {
                                          print(
                                              "getValueFromSchedule" +
                                                  val.toString());
                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 25,
                                        height: 25,
                                        child: SvgPicture.asset(
                                          // _pickedPdfs.length > 0 ||
                                          //     _pickedAudios.length > 0 ||
                                          //     _pickedVideos.length > 0
                                          //     ?
                                          'assets/post_icons/calendar.svg',

                                          color: controller.modelList2[widget
                                              .controller.currentIndexText]
                                              .mediaData2.length > 0
                                              || controller.modelList2[0]
                                                  .selectType ==
                                                  "People you follow"
                                              || controller.modelList2[0]
                                                  .selectType ==
                                                  "Only people you mention"
                                          //   isMediaUploading
                                              ? controller.displayColor
                                              .withOpacity(0.6)
                                              :
                                          //  _pickedVideos.isNotEmpty ||
                                          isMediaAttached ||
                                              showPolls[controller
                                                  .currentIndexText]
                                              ? controller.displayColor
                                              .withOpacity(0.6)
                                              : controller.displayColor,
                                          //  : Colors.purple,
                                        ),
                                      ),
                                    ),

                                    ///locationicon
                                    InkWell(
                                      onTap: () {
                                        locationController
                                            .locationTextController
                                            .clear();
                                        showDialog(
                                            context: context,
                                            builder: (context) {
                                              return AlertDialog(
                                                contentPadding: EdgeInsets.zero,
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                  BorderRadius.circular(15),
                                                ),
                                                content: StatefulBuilder(
                                                    builder:
                                                        (context, setState) {
                                                      return Container(
                                                        width: 500,
                                                        height: 500,
                                                        child: Padding(
                                                          padding:
                                                          const EdgeInsets.only(
                                                              left: 10,
                                                              top: 10,
                                                              right: 10),
                                                          child: Column(
                                                            children: [
                                                              Row(
                                                                mainAxisAlignment:
                                                                MainAxisAlignment
                                                                    .spaceBetween,
                                                                children: [
                                                                  IconButton(
                                                                      onPressed:
                                                                          () {
                                                                        Navigator
                                                                            .pop(
                                                                            context);
                                                                      },
                                                                      icon: Icon(
                                                                        Icons
                                                                            .clear,
                                                                        color: Theme
                                                                            .of(
                                                                            context)
                                                                            .brightness ==
                                                                            Brightness
                                                                                .dark
                                                                            ? Colors
                                                                            .white
                                                                            : Colors
                                                                            .black,
                                                                      )),
                                                                  Text(
                                                                    Strings
                                                                        .tagLocation,
                                                                    style: Styles
                                                                        .baseTextTheme
                                                                        .headline2
                                                                        .copyWith(
                                                                      color: Theme
                                                                          .of(
                                                                          context)
                                                                          .brightness ==
                                                                          Brightness
                                                                              .dark
                                                                          ? Colors
                                                                          .white
                                                                          : Colors
                                                                          .black,
                                                                      //fontSize: kIsWeb ? 16 : 14,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .bold,
                                                                    ),
                                                                  ),
                                                                  Spacer(),
                                                                  ElevatedButton(
                                                                    onPressed:
                                                                        () {},
                                                                    child: Text(
                                                                      Strings
                                                                          .done,
                                                                      style:
                                                                      TextStyle(
                                                                        color: Colors
                                                                            .white,
                                                                        fontSize:
                                                                        14,
                                                                      ),
                                                                    ),
                                                                    style: ElevatedButton
                                                                        .styleFrom(
                                                                      padding: EdgeInsets
                                                                          .only(
                                                                          left: 15,
                                                                          right: 15,
                                                                          top: 15,
                                                                          bottom:
                                                                          15),
                                                                      primary:
                                                                      controller
                                                                          .displayColor,
                                                                      shape: new RoundedRectangleBorder(
                                                                          borderRadius:
                                                                          new BorderRadius
                                                                              .circular(
                                                                              20.0)),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: 20,
                                                              ),
                                                              Obx(() {
                                                                return TextFormField(
                                                                  focusNode:
                                                                  focusNode,
                                                                  cursorRadius:
                                                                  const Radius
                                                                      .circular(
                                                                      500),
                                                                  style: Styles
                                                                      .baseTextTheme
                                                                      .headline4
                                                                      .copyWith(
                                                                    color: Theme
                                                                        .of(
                                                                        context)
                                                                        .brightness ==
                                                                        Brightness
                                                                            .dark
                                                                        ? Colors
                                                                        .white
                                                                        : Colors
                                                                        .black,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                    fontSize: 14,
                                                                  ),
                                                                  onEditingComplete:
                                                                      () {
                                                                    FocusScope
                                                                        .of(
                                                                        context)
                                                                        .requestFocus(
                                                                        FocusNode());
                                                                  },
                                                                  controller:
                                                                  locationController
                                                                      .locationTextController,
                                                                  onChanged:
                                                                      (value) {
                                                                    locationController
                                                                        .callApi(
                                                                        value);
                                                                    print(
                                                                        locationController
                                                                            .locationTextController
                                                                            .text
                                                                            .length);
                                                                    print(
                                                                        value);
                                                                  },
                                                                  decoration:
                                                                  InputDecoration(
                                                                    hintText:
                                                                    Strings
                                                                        .searchLocation,
                                                                    hintStyle: Styles
                                                                        .baseTextTheme
                                                                        .headline4
                                                                        .copyWith(
                                                                      // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500,
                                                                      fontSize: 14,
                                                                    ),
                                                                    prefixIcon:
                                                                    checkFocus
                                                                        .value ==
                                                                        false
                                                                        ? Row(
                                                                      mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                      children: [
                                                                        SizedBox(
                                                                          width: 10,
                                                                        ),
                                                                        Icon(
                                                                          Icons
                                                                              .search,
                                                                          color: Color(
                                                                              0xFF586976),
                                                                        ),
                                                                        SizedBox(
                                                                          width: 5,
                                                                        ),
                                                                        Text(
                                                                          Strings
                                                                              .searchLocation,
                                                                          style: Styles
                                                                              .baseTextTheme
                                                                              .headline4
                                                                              .copyWith(
                                                                            // color: Theme.of(context).brightness == Brightness.dark ? Colors.white : Colors.black,
                                                                            fontWeight: FontWeight
                                                                                .w500,
                                                                            fontSize: 14,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    )
                                                                        : Icon(
                                                                      Icons
                                                                          .search,
                                                                      color:
                                                                      Color(
                                                                          0xFF586976),
                                                                    ),
                                                                    suffixIcon: locationController
                                                                        .locationTextController
                                                                        .text
                                                                        .length >
                                                                        0
                                                                        ? IconButton(
                                                                        icon:
                                                                        Icon(
                                                                          Icons
                                                                              .clear,
                                                                          color:Get.isDarkMode? Colors
                                                                              .white
                                                                              : Colors
                                                                              .black,
                                                                          size:
                                                                          30,
                                                                        ),
                                                                        onPressed:
                                                                            () {
                                                                          locationController
                                                                              .locationTextController
                                                                              .clear();
                                                                        })
                                                                        : null,

                                                                    //   filled: true,

                                                                    // contentPadding: EdgeInsets.only(top: 20,left: 10),
                                                                    focusedBorder:
                                                                    OutlineInputBorder(
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          30.0),
                                                                      borderSide:
                                                                      BorderSide(
                                                                        width: 2,
                                                                        color: Colors
                                                                            .blue,
                                                                      ),
                                                                    ),

                                                                    enabledBorder:
                                                                    OutlineInputBorder(
                                                                      borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                          30.0),
                                                                      borderSide:
                                                                      BorderSide(
                                                                        color: Colors
                                                                            .grey,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                );
                                                              }),
                                                              Expanded(
                                                                child: Container(
                                                                  // height: Get.height * 0.6,
                                                                    child: locationController
                                                                        .searchPlaces
                                                                        .value !=
                                                                        null
                                                                        ? Obx(() =>
                                                                        listview(
                                                                            context,
                                                                            locationController
                                                                                .searchPlaces
                                                                                .value))
                                                                        : Text(
                                                                        '')),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    }),
                                              );
                                            });
                                      },
                                      child: Container(
                                        width: 25,
                                        height: 25,
                                        child: SvgPicture.asset(
                                          'assets/post_icons/location.svg',
                                          fit: BoxFit.fill,
                                          height: 150,
                                          width: 150,
                                          color: /*_pickedVideos.isNotEmpty || isMediaAttached || showPolls ? Colors.grey[400] :*/
                                          controller.displayColor,
                                        ),
                                      ),
                                    ),

                                    ///smileicon
                                    InkWell(
                                      onTap: () {
                                        //print("hello");
                                        if (isEmojiVisible) {
                                          widget.controller.focusNode
                                              .requestFocus();
                                          //print("in emjoji");
                                          // controller.postText = true;
                                          // controller.update();

                                          setState(() {});
                                        } else if (!isEmojiVisible) {
                                          print("un emjoji");
                                          FocusScope.of(context).unfocus();

                                          setState(() {});
                                        }
                                        isEmojiVisible = !isEmojiVisible;
                                        if (this.mounted) {
                                          // check whether the state object is in tree
                                          setState(() {
                                            // make changes here
                                          });
                                        }
                                      },
                                      child: Container(
                                        width: 25,
                                        height: 25,
                                        child: SvgPicture.asset(
                                          'assets/post_icons/emoji.svg',
                                          fit: BoxFit.fill,
                                          height: 150,
                                          width: 150,
                                          color: controller.displayColor,
                                        ),
                                      ),
                                    ),

                                    ///threadicon and visibility
                                    // isEdit != true || widget.isPostScheduled
                                    //     ? visibility
                                    //     ? InkWell(
                                    //   onTap: () async {
                                    //     setState(() {
                                    //       threadCreated = true;
                                    //       if (widget
                                    //           .controller
                                    //           .modelList2
                                    //           .isNotEmpty) {
                                    //         controller.modelList2[0]
                                    //             .postType = "thread";
                                    //         controller.modelList2.add(
                                    //             ModelClass.fromJson({
                                    //               'body': '',
                                    //               'poll_ques_first': null,
                                    //               'poll_ques_first': null,
                                    //               'poll_ques_third': null,
                                    //               'poll_ques_fourth':
                                    //               null,
                                    //               'files': [],
                                    //               'link_meta': '',
                                    //               'link': '',
                                    //               'link_image': '',
                                    //               'link_title': '',
                                    //               'days': '',
                                    //               'minutes': '',
                                    //               'hours': '',
                                    //               'location': '',
                                    //               'lat': '',
                                    //               'lng': '',
                                    //               'type': "thread",
                                    //               'poll_thread': controller
                                    //                   .modelList2[
                                    //               controller
                                    //                   .currentIndexText]
                                    //                   .poll_ques_first ==
                                    //                   null
                                    //                   ? false
                                    //                   : true
                                    //             }));
                                    //
                                    //       } else {
                                    //         controller.modelList2.add(
                                    //           ModelClass.fromJson({
                                    //             'body': '',
                                    //             'poll_ques_first': null,
                                    //             'poll_ques_first': null,
                                    //             'poll_ques_third': null,
                                    //             'poll_ques_fourth':
                                    //             null,
                                    //             'files': [],
                                    //             'link_meta': '',
                                    //             'link': '',
                                    //             'link_image': '',
                                    //             'link_title': '',
                                    //             'days': '',
                                    //             'minutes': '',
                                    //             'hours': '',
                                    //             'location': '',
                                    //             'lat': '',
                                    //             'lng': '',
                                    //             'type': "post",
                                    //           }),
                                    //
                                    //
                                    //         );
                                    //       }
                                    //       // print('lenghth of listy${widget.controller.modelList2.length}');
                                    //       // print('index of the list ${widget.controller.currentIndexText}');
                                    //       // // isMediaAttached=false;
                                    //       // _pickedVideos=[];
                                    //       // visibility=false;
                                    //       // isMediaAttached = true;
                                    //       // closeIcon=true;
                                    //       print(
                                    //           'lenghth of listy:${controller.modelList2.length}');
                                    //       print(
                                    //           'index of the list: ${controller.currentIndexText}');
                                    //
                                    //       print("controller.currentIndexText bbbb ${controller.currentIndexText} ");
                                    //
                                    //
                                    //       widget.isPostScheduled = false;
                                    //       controller.currentIndexText = controller.currentIndexText + 1;
                                    //       controller.modelList2[controller.currentIndexText].isMediaAttached  = false;
                                    //       controller.modelList2[controller.currentIndexText].poolThread = false;
                                    //
                                    //       //  showPolls[controller.currentIndexText] = false;
                                    //       _pickedVideos = [];
                                    //       visibility = false;
                                    //       closeIcon = true;
                                    //       setState(() {
                                    //
                                    //       });
                                    //     });
                                    //   },
                                    //   child: Container(
                                    //     height: 25,
                                    //     width: 25,
                                    //     decoration: BoxDecoration(
                                    //         shape: BoxShape.circle,
                                    //         color: controller
                                    //             .displayColor),
                                    //     child: Icon(
                                    //       Icons.add,
                                    //       color: Colors.white,
                                    //       size: 20,
                                    //     ),
                                    //   ),
                                    // )
                                    //     : Container(
                                    //   height: 25,
                                    //   width: 25,
                                    //   decoration: BoxDecoration(
                                    //       shape: BoxShape.circle,
                                    //       color: Colors.grey),
                                    //   child: Icon(
                                    //     Icons.add,
                                    //     color: Colors.white,
                                    //     size: 20,
                                    //   ),
                                    // )
                                    //     : SizedBox(),

                                    SizedBox(
                                      //width: 8,
                                      width: Get.width * 0.004,
                                    ),
                                    widget.isPostScheduled
                                        ? ElevatedButton(
                                      child: Text(
                                        Strings.schedule,
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.white),
                                      ),
                                      style: ButtonStyle(
                                        padding:
                                        MaterialStateProperty.all(
                                          EdgeInsets.symmetric(
                                              horizontal: 30,
                                              vertical: 2),
                                        ),
                                        backgroundColor: MaterialStateProperty
                                            .all(widget
                                            .controller
                                            .postText ==
                                            false &&
                                            controller.modelList2[controller
                                                .currentIndexText]
                                                .isMediaAttached == false
                                            ? Colors.blueGrey
                                            : widget.controller
                                            .postText ==
                                            true &&
                                            isMediaUploading ==
                                                true &&
                                            controller
                                                .modelList2[controller
                                                .currentIndexText]
                                                .bodyText
                                                .isEmpty &&
                                            controller
                                                .modelList2[controller
                                                .currentIndexText]
                                                .poll_ques_first
                                                .isEmpty &&
                                            controller
                                                .modelList2[controller
                                                .currentIndexText]
                                                .poll_ques_second
                                                .isEmpty
                                            ? controller.displayColor
                                            .withOpacity(0.5)
                                            : controller
                                            .displayColor),
                                        shape: MaterialStateProperty.all<
                                            RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                            borderRadius:
                                            BorderRadius.circular(40),
                                          ),
                                        ),
                                      ),
                                      onPressed: widget.controller
                                          .postText ==
                                          false &&
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .isMediaAttached == false
                                          ? null
                                          : widget.controller.postText ==
                                          true &&
                                          isMediaUploading == true
                                          ? null
                                          : () async {
                                        // widget.controller.isLoading = true;
                                        apiCalled = true;
                                        setState(() {});
                                        widget.controller.schedulePost(
                                            context,
                                            bodyText: controller.modelList2[0]
                                                .bodyText,
                                            fileName: _pdfFilesName.length > 0
                                                ? _pdfFilesName
                                                : null,
                                            // imageWebBytes: _pickedImage.isNotEmpty ? _pickedImage
                                            //     : _pickedVideos.isNotEmpty ? _pickedVideos
                                            //     : _pickedAudios != null
                                            //     ? _pickedAudios
                                            //     : _pickedPdfs,
                                            payload: controller.modelList2,
                                            link: link != null ? link : '',
                                            linkImage: linkImage != null
                                                ? linkImage
                                                : '',
                                            linkMeta: linkMeta != null
                                                ? linkMeta
                                                : '',
                                            linkTitle: linkTitle != null
                                                ? linkTitle
                                                : '',
                                            postingTime: selectedDateTime
                                                .toString()
                                        );
                                        Navigator.of(context)
                                            .pop();
                                        // Navigator.pop(context);
                                      },
                                    )
                                        : RoundedButton(
                                      threadCreated == false ||
                                          controller.modelList2.length == 1
                                          ? isEdit == true
                                          ? Strings.editWerf
                                          : Strings.werf
                                          : Strings.allwerf,
                                      widget.controller.postText == false &&
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .isMediaAttached == false
                                          ? null
                                          : widget.controller.postText ==
                                          true &&
                                          isMediaUploading == true ? null
                                          : showPolls[controller
                                          .currentIndexText] &&
                                          widget.controller.postText == true
                                          &&
                                          txtOption1.isEmpty &&
                                          txtOption2.isEmpty
                                          && controller.modelList2[controller
                                              .currentIndexText].bodyText
                                              .isEmpty
                                          && controller.modelList2[controller
                                              .currentIndexText]
                                              .poll_ques_first == "" &&
                                          controller.modelList2[controller
                                              .currentIndexText]
                                              .poll_ques_second == ""
                                          ? () {}
                                          :

                                          () async {
                                        // print(txtOption1);
                                        // print(txtOption2);
                                        // print(pollHours);
                                        // print(pollDays);
                                        // print(pollMinutes);

                                        ///edit post
                                        List<ModelClass>EditList = [];
                                        List<ModelClass>showPoolList = [];

                                        if (isEdit == true) {
                                          EditList.insert(
                                              0,
                                              ModelClass
                                                  .fromJson({
                                                'body': '',
                                                'poll_ques_first':
                                                null,
                                                'poll_ques_second':
                                                null,
                                                'poll_ques_third':
                                                null,
                                                'poll_ques_fourth':
                                                null,
                                                'files': [],
                                                'link_meta':
                                                '',
                                                'link': '',
                                                'link_image':
                                                '',
                                                'link_title':
                                                '',
                                                'days': '',
                                                'minutes':
                                                '',
                                                'hours': '',
                                                'location':
                                                '',
                                                'lat': '',
                                                'lng': '',
                                                'type':
                                                "post",
                                                "post_id":
                                                0,
                                              }));

                                          EditList[0].location =
                                              controller.modelList2[0].location;
                                          EditList[0].lat =
                                              controller.modelList2[0].lat;
                                          EditList[0].lng =
                                              controller.modelList2[0].lng;

                                          print(
                                              "eidt pay aya hai");

                                          int length = controller.modelList2[0]
                                              .mediaData2.length;
                                          print(
                                              "length: $length");

                                          for (int i = 0;
                                          i < length;
                                          i++) {
                                            EditList[0].mediaData2.add(
                                                Files.fromJson({
                                                  'url': controller
                                                      .modelList2[0]
                                                      .mediaData2[i].url,
                                                  'thumbnail_url': controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .thumbnailUrl,
                                                  'name': widget.controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .name,
                                                  'size': widget.controller
                                                      .modelList2[0]
                                                      .mediaData2[i]
                                                      .size,
                                                  // 'mention_user_ids':widget.controller.modelList2[0].mediaData2[i].size,
                                                }));
                                          }


                                          EditList[0]
                                              .bodyText =
                                              controller
                                                  .modelList2[
                                              0]
                                                  .bodyText;
                                          EditList[0]
                                              .postId =
                                              widget.post
                                                  .postId;
                                          EditList[0]
                                              .postType =
                                          "post";
                                        } else if (showPolls[0] == true &&
                                            threadCreated == false) {
                                          showPoolList.insert(0,
                                              ModelClass
                                                  .fromJson({
                                                'body': controller
                                                    .modelList2[0]
                                                    .bodyText,
                                                'poll_ques_first': controller
                                                    .modelList2[0]
                                                    .poll_ques_first,
                                                'poll_ques_second': controller
                                                    .modelList2[0]
                                                    .poll_ques_second,
                                                'poll_ques_third': controller
                                                    .modelList2[0]
                                                    .poll_ques_third ==
                                                    null
                                                    ? null
                                                    : controller.modelList2[0]
                                                    .poll_ques_third,
                                                'poll_ques_fourth': controller
                                                    .modelList2[0]
                                                    .poll_ques_fourth ==
                                                    null
                                                    ? null
                                                    : controller.modelList2[0]
                                                    .poll_ques_fourth,
                                                'files':
                                                [],
                                                'link_meta':
                                                '',
                                                'link':
                                                '',
                                                'link_image':
                                                '',
                                                'link_title':
                                                '',
                                                'days':
                                                '',
                                                'minutes':
                                                '',
                                                'hours':
                                                '',
                                                'location':
                                                '',
                                                'lat':
                                                '',
                                                'lng':
                                                '',
                                                'type':
                                                'poll',
                                              }));
                                        }

                                        print("post id");
                                        print(
                                            'AUDIO BYTES WHEN ON PRESSED IS ACTIVATED  ' +
                                                _pickedAudios
                                                    .toString());

                                        // widget.controller.isLoading = true;
                                        // widget.controller.update();

                                        apiCalled = true;
                                        setState(() {});
                                        var responseCode;

                                        {
                                          controller
                                              .modelList2
                                              .forEach(
                                                  (ele) {
                                                ele.mediaData2
                                                    .forEach(
                                                        (element) {
                                                      element
                                                          .mentionUserList
                                                          .clear();
                                                    });
                                              });


                                          if (isEdit == false) {
                                            controller.modelList2.forEach((
                                                element) {
                                              print(
                                                  "before element.bodyText ${ element
                                                      .bodyText}");
                                              element.bodyText =
                                                  element.bodyText.replaceAll(
                                                      "\n", " " + "\n");

                                              print(
                                                  "after element.bodyText ${ element
                                                      .bodyText}");
                                            });
                                          }
                                          else {
                                            EditList.forEach((element) {
                                              print(
                                                  "before element.bodyText ${ element
                                                      .bodyText}");
                                              element.bodyText =
                                                  element.bodyText.replaceAll(
                                                      "\n", " " + "\n");

                                              print(
                                                  "after element.bodyText ${ element
                                                      .bodyText}");
                                            });
                                          }


                                          //lll
                                          // var responseCode = await widget.controller.createQuoteWerf(
                                          //     quoteId: widget.post.postId.toString(),
                                          //     bodyText: postTextController.text,
                                          //     // files: pickedMedia,
                                          //     fileName: _pdfFilesName.length > 0
                                          //         ? _pdfFilesName
                                          //         : null,
                                          //     imageWebBytes: _pickedImage.isNotEmpty ? _pickedImage : _pickedVideos.isNotEmpty ? _pickedVideos : _pickedAudios.isNotEmpty ? _pickedAudios : _pickedPdfs,
                                          //     selectType: widget
                                          //         .controller
                                          //         .selectedType ==
                                          //         "Public"
                                          //         ? "public"
                                          //         : widget.controller
                                          //         .selectedType,
                                          //     link: link != null
                                          //         ? link
                                          //         : '',
                                          //     linkImage: linkImage != null
                                          //         ? linkImage
                                          //         : '',
                                          //     linkMeta: linkMeta != null
                                          //         ? linkMeta
                                          //         : '',
                                          //     linkTitle: linkTitle != null
                                          //         ? linkTitle
                                          //         : '',
                                          //     mediaData: widget.controller.mediaData);


                                          responseCode =
                                          await controller.createPost(
                                              payload: isEdit == true
                                                  ? EditList
                                                  : showPolls[0] == true &&
                                                  threadCreated == false
                                                  ? showPoolList
                                                  : controller.modelList2,
                                              postId: isEdit == true ? widget
                                                  .post
                                                  .postId : 0);
                                          print("post created");
                                        }
                                        _pickedImage = [];
                                        apiCalled = false;
                                        controller
                                            .currentIndexText = 0;
                                        Navigator.pop(
                                            context);
                                        widget.controller
                                            .isNewsfeedLoading =
                                        false;
                                        widget.controller
                                            .update();
                                        // widget.controller.isLoading = false;
                                        // widget.controller.update();
                                        print('RESPONSEE' +
                                            responseCode
                                                .toString());
                                      },
                                      horizontalPadding: 36.0,
                                      verticalPadding: 0.0,
                                      roundedButtonColor:
                                      controller.displayColor,
                                    ),
                                  ],
                                ),
                              ],
                            )
                                : SizedBox(),
                          ],
                        ),

                        Positioned(
                          left: 200,
                          top: 200,
                          child: Offstage(
                              offstage: !isEmojiVisible,
                              child: Container(
                                  height: 250,
                                  width: 250,
                                  margin: const EdgeInsets.all(5),
                                  padding: const EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.white,
                                      ),
                                      borderRadius: BorderRadius.circular(10)),
                                  child: DefaultTabController(
                                      length: emojis.length,
                                      child: isPortrait
                                          ? Column(children: [
                                        Container(
                                            margin:
                                            const EdgeInsets.symmetric(
                                                horizontal: 2),
                                            child: EmojiTabBar(
                                                tabController:
                                                _tabController)),
                                        const Divider(
                                            color: Colors.black45,
                                            height: 5,
                                            thickness: .5),
                                        EmojisList(
                                            controller: controller,
                                            cross: cross,
                                            textController: _controller[
                                            widget.controller
                                                .currentIndexText],
                                            // controller: controller,
                                            emojiSelected: () {
                                              print("emoji called");
                                              widget.controller.postText =
                                              true;
                                              widget.controller.update();
                                              setState(() {});
                                            },
                                            tabController: _tabController)
                                      ])
                                          : Row(children: [
                                        emojiSideBar(),
                                        EmojisList(
                                            controller: controller,
                                            cross: cross,
                                            textController: _controller[
                                            widget.controller
                                                .currentIndexText],
                                            // controller: controller,
                                            emojiSelected: () {
                                              print("emoji calledd");
                                              widget.controller.postText =
                                              true;
                                              widget.controller.update();
                                              setState(() {});
                                            },
                                            tabController: _tabController)
                                      ])))),
                        ),


                      ],
                    ),
                  ),
                ),
              ),
            ),
          ));
  }

  bool compareSelectedDatetime(String selectedDatetime) {
    DateTime parseDate =
    new DateFormat("yyyy-MM-dd HH:mm:ss").parse(selectedDatetime);
    DateTime currentDatetime =
    new DateFormat("yyyy-MM-dd HH:mm:ss").parse(DateTime.now().toString());
    bool isValidDate = parseDate.isAfter(currentDatetime);
    print("isValidate" + isValidDate.toString());

    return isValidDate;
  }

  Widget urlFetch() {
    if (widget.controller.scrapUrl.contains('.com')) {
      return FutureBuilder<ScrappingData>(
        future: widget.controller.urlScraping(widget.controller.scrapUrl),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            link = snapshot.data.link;
            controller.modelList2[controller.currentIndexText].link =
                snapshot.data.link;
            linkTitle = snapshot.data.title;
            controller.modelList2[controller.currentIndexText].linkTitle =
                snapshot.data.title;
            linkMeta = snapshot.data.meta;
            controller.modelList2[controller.currentIndexText].linkMeta =
                snapshot.data.meta;

            if (snapshot.data.images == null || snapshot.data.images.isEmpty) {
              linkImage =
              "https://www.challengetires.com/assets/img/placeholder.jpg";
            }
            else {
              linkImage = snapshot.data.images[0];
            }
            controller.modelList2[controller.currentIndexText].linkImage =
                linkImage;
            return cardScrap(context, snapshot.data);
          } else if (snapshot.hasError) {
            print(snapshot.error.toString());
            return Container();
          }
          return Container(
            child: Center(
              child: CircularProgressIndicator(),
            ),
          );
        },
      );
    } else {
      return Container();
    }
  }

/*  Widget urlFetch() {
    // if(widget.controller.scrapUrl.contains('.com')){
    //   return
    return FutureBuilder<ScrappingData>(
      future: widget.controller.urlScraping(widget.controller.scrapUrl),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          link = snapshot.data.link;
          linkTitle = snapshot.data.title;
          linkMeta = snapshot.data.meta;
          linkImage =
              snapshot.data.images.isNotEmpty && snapshot.data.images.length > 0
                  ? snapshot.data.images[0]
                  : '';
          return cardScrap(context, snapshot.data);
        } else if (snapshot.hasError) {
          print(snapshot.error.toString());
          return Container();
        }
        return Container(
          child: Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );

    // }else{
    //   return Container();
    // }
  }*/

  Widget cardScrap(BuildContext context, ScrappingData data) {
    // _validURL = true;
    if (data.title != '429 Too Many Requests') {
      return Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: GestureDetector(
          onTap: () {
            // Get.to(MenuListPage(
            //   restaurantId: id,
            // ));
          },
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(20.0)),
            ),
            child: Column(
              children: [
                // data.images.length > 0 ? data.images[0] != null
                //     ? Image.network(
                //     data.images[0].toString(),
                //   fit: BoxFit.cover,
                // )
                //     : Image.asset(
                //     "assets/images/person_placeholder.png")
                //     : Image.asset(
                //     "assets/images/person_placeholder.png"),

                Container(
                  height: kIsWeb ? Get.height / 2.9 : Get.height / 4.5,
                  width: Get.width,
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20.0),
                        topRight: Radius.circular(20.0),
                      ),
                      image: DecorationImage(
                          image: data.images.length > 0
                              ? data.images[0] != null
                              ? NetworkImage(data.images[0].toString())
                              : AssetImage(
                              "assets/images/person_placeholder.png")
                              : AssetImage(
                              "assets/images/person_placeholder.png"),
                          fit: BoxFit.contain)),
                ),

                Padding(
                  padding: const EdgeInsets.only(
                    top: 5,
                    left: 20,
                    right: 20,
                  ),
                  child: data.title != null
                      ? Text(data.title.toString(),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Cairo',
                        fontSize: 17,
                        fontWeight: FontWeight.w500,
                      ))
                      : SizedBox(),
                ),
                // Padding(
                //     padding: const EdgeInsets.only(top: 0, left: 20, right: 20),
                //     child:
                //     data.meta!=null?
                //         Text(
                //       data.meta.toString(),
                //       maxLines: 1,
                //       overflow: TextOverflow.ellipsis,
                //       style: TextStyle(
                //         color: Colors.black,
                //         fontFamily: 'Cairo',
                //         fontSize: 16,
                //         fontWeight: FontWeight.w500,
                //       ),
                //     ):SizedBox()
                // ),
                Padding(
                  padding: const EdgeInsets.only(
                      top: 0, left: 20, right: 20, bottom: 10),
                  child: data.link != null
                      ? Text(data.link.toString(),
                      textAlign: TextAlign.left,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontFamily: 'Cairo',
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                      ))
                      : SizedBox(),
                ),
              ],
            ),
          ),

          // Card(
          //   elevation: 4,
          //   shape: RoundedRectangleBorder(
          //     borderRadius: BorderRadius.all(Radius.circular(5.0)),
          //   ),
          //   child: ClipRRect(
          //     borderRadius: BorderRadius.all(
          //       Radius.circular(5.0),
          //     ),
          //     child: Container(
          //       height: 80,
          //       child: Row(
          //         children: [
          //           Padding(
          //             padding: const EdgeInsets.only(left: 0),
          //             child: Container(
          //               height: 80,
          //               width: 80,
          //               decoration: BoxDecoration(
          //                   borderRadius: BorderRadius.circular(0.0),
          //                   image: DecorationImage(
          //                       image: data.images[0] != null
          //                           ? NetworkImage(data.images[0].toString())
          //                           : AssetImage(
          //                               "assets/images/person_placeholder.png"),
          //                       fit: BoxFit.cover)),
          //             ),
          //           ),
          //           Expanded(
          //             child: Padding(
          //               padding: const EdgeInsets.only(left: 12),
          //               child: Column(
          //                 crossAxisAlignment: CrossAxisAlignment.start,
          //                 mainAxisAlignment: MainAxisAlignment.start,
          //                 children: [
          //                   Padding(
          //                     padding:
          //                         const EdgeInsets.only(right: 8.0, top: 8.0),
          //                     child: InkWell(
          //                       onTap: () {},
          //                       child: SizedBox(
          //                         height: 4,
          //                         child: Align(
          //                             alignment: Alignment.topRight,
          //                             child: Icon(Icons.cancel)),
          //                       ),
          //                     ),
          //                   ),
          //                   Padding(
          //                     padding: const EdgeInsets.only(right: 8.00),
          //                     child: SizedBox(
          //                       height: 20,
          //                       child: Text(data.title.toString(),
          //                           overflow: TextOverflow.ellipsis,
          //                           maxLines: 1,
          //                           style: TextStyle(
          //                             color: Colors.black,
          //                             fontFamily: 'Cairo',
          //                             fontSize: 17,
          //                             fontWeight: FontWeight.w500,
          //                           )),
          //                     ),
          //                   ),
          //                   Padding(
          //                     padding: const EdgeInsets.only(right: 8.00),
          //                     child: SizedBox(
          //                       height: 18,
          //                       child: Text(
          //                         data.meta.toString(),
          //                         maxLines: 1,
          //                         overflow: TextOverflow.ellipsis,
          //                         style: TextStyle(
          //                           color: Colors.black,
          //                           fontFamily: 'Cairo',
          //                           fontSize: 16,
          //                           fontWeight: FontWeight.w500,
          //                         ),
          //                       ),
          //                     ),
          //                   ),
          //                   Padding(
          //                     padding: const EdgeInsets.only(right: 8.00),
          //                     child: SizedBox(
          //                       height: 18,
          //                       child: Text(data.link.toString(),
          //                           textAlign: TextAlign.left,
          //                           maxLines: 1,
          //                           overflow: TextOverflow.ellipsis,
          //                           style: TextStyle(
          //                             color: Colors.grey[700],
          //                             fontFamily: 'Cairo',
          //                             fontSize: 14,
          //                             fontWeight: FontWeight.w400,
          //                           )),
          //                     ),
          //                   ),
          //                 ],
          //               ),
          //             ),
          //           ),
          //         ],
          //       ),
          //     ),
          //   ),
          // ),
        ),
      );
    } else {
      return Container();
    }
  }

  Widget _location({@required StructuredFormatting data,
    @required BuildContext context,
    @required int index}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 20,
                ),
                ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 200),
                  child: Text(
                    data.maintext,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: "assets/fonts/Arial-Bold.ttf",
                    ),
                  ),
                ),
                const SizedBox(
                  height: 2,
                ),
                data.secondarytext != null
                    ? Text(data.secondarytext,
                    //secnT(data: data),
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: MyColors.grey,
                      fontFamily: "assets/fonts/Regular.ttf",
                    ))
                    : Text(""),
                // Text(
                //   secnT(data: data),
                //   textAlign: TextAlign.left,
                //   style: TextStyle(
                //     color: Colorss.grey,
                //     fontFamily: "assets/fonts/Regular.ttf",
                //   ),
                // ),
              ],
            )),
        Divider(
          thickness: 2,
        ),
      ],
    );
  }

  String secnT({@required StructuredFormatting data}) {
    if (data.secondarytext != null) {
      return data.secondarytext;
    }
    locationController.update();
    return '';
  }

  Widget listview(BuildContext context, AutoComplete data) {
    return Container(
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: data.predict.length,
        padding: const EdgeInsets.only(top: 5),
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () async {
              print(
                  "index location ${Get
                      .find<NewsfeedController>()
                      .currentIndexText}");

              print("location ayie nhi");

              Get
                  .find<NewsfeedController>()
                  .modelList2[Get
                  .find<NewsfeedController>()
                  .currentIndexText]
                  .location = data.predict[index].structuredformatting.maintext;
              Get
                  .find<NewsfeedController>()
                  .modelList2[Get
                  .find<NewsfeedController>()
                  .currentIndexText]
                  .lat = locationController.lat.value.toString();
              Get
                  .find<NewsfeedController>()
                  .modelList2[Get
                  .find<NewsfeedController>()
                  .currentIndexText]
                  .lng = locationController.lng.value.toString();
              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              // SingleTone.instance.lat = locationController.lat.value;
              // SingleTone.instance.lng = locationController.lng.value;
              Get
                  .find<NewsfeedController>()
                  .postText = true;

              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              // SingleTone.instance.lat = locationController.lat.value;
              // SingleTone.instance.lng = locationController.lng.value;
              // SingleTone.instance.selectedLocation = data.predict[index].structuredformatting.maintext;
              //
              // locationController.mainText = data.predict[index].structuredformatting.maintext;
              // locationController.secondaryText = data.predict[index].structuredformatting.secondarytext;
              // locationController.callApi(' ');
              // locationController.locationTextController.text = locationController.mainText;
              // // Selectedlocation(context: context);
              // locationController.update();
              // FocusScope.of(context).requestFocus(new FocusNode());
              // await locationController.callApiLatLong(data.predict[index].placeid);

              setState(() {});

              Navigator.pop(context);
            },
            child: _location(
              data: data.predict[index].structuredformatting,
              context: context,
              index: index,
            ),
          );
        },
      ),
    );
  }

  SizedBox emojiSideBar() {
    return SizedBox(
        width: 50,
        child: ListView.builder(
            controller: _scrollController,
            itemCount: emojis.length,
            itemBuilder: (context, index) {
              final x = emojis[index].split(' ');
              return GestureDetector(
                  onTap: () {
                    _selectedTab = index;
                    _tabController.animateTo(index);
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(2),
                      margin: const EdgeInsets.all(2),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: _selectedTab == index
                              ? Colors.grey.shade300
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10)),
                      child: Text(x[0], style: const TextStyle(fontSize: 25))));
            }));
  }
// Uri.tryParse(postTextController.text)?.hasAbsolutePath
}

class EmojiTabBar extends StatelessWidget {
  const EmojiTabBar({
    Key key,
    this.tabController,
  }) : super(key: key);
  final TabController tabController;

  @override
  Widget build(BuildContext context) {
    return TabBar(
        controller: tabController,
        isScrollable: true,
        labelColor: Colors.black,
        unselectedLabelColor: Colors.blue[700],
        labelStyle: const TextStyle(fontSize: 25),
        unselectedLabelStyle: const TextStyle(fontSize: 20),
        labelPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 1),
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: BoxDecoration(
            color: Colors.grey.withOpacity(.3),
            borderRadius: BorderRadius.circular(10)),
        tabs: emojis.map((e) {
          final x = e.split(' ');
          return Tab(
              child: SizedBox(width: 35, child: Center(child: Text(x[0]))));
        }).toList());
  }
}

class EmojisList extends StatelessWidget {
  EmojisList({Key key,
    this.cross,
    TextEditingController textController,
    this.tabController,
    this.emojiSelected,
    this.controller})
      : _textController = textController,
        super(key: key);

  final int cross;
  final TextEditingController _textController;
  final TabController tabController;
  final NewsfeedController controller;
  Function() emojiSelected;

  @override
  Widget build(BuildContext context) {
    return Expanded(
        child: TabBarView(
            controller: tabController,
            children: emojis.map((e) {
              final x = e.split(' ');
              return GridView.builder(
                  itemCount: x.length,
                  scrollDirection: Axis.vertical,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: kIsWeb ? 8 : cross,
                      mainAxisSpacing: 2,
                      crossAxisSpacing: 2),
                  itemBuilder: (context, index) =>
                      GestureDetector(
                          onTap: () {
                            // controller.FocusScope.of(context).unfocus();
                            // controller.focusNode.requestFocus();

                            //print("hello");

                            _textController.text =
                                _textController.text + x[index];
                            emojiSelected();
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: kIsWeb
                                      ? Colors.transparent
                                      : Colors.green.shade50,
                                  borderRadius: BorderRadius.circular(10)),
                              alignment: Alignment.center,
                              child: FittedBox(
                                  child: Text(x[index],
                                      style: const TextStyle(fontSize: 30))))));
            }).toList()));
  }
}
